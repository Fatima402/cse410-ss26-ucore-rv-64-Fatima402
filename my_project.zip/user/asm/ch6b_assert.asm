
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_assert:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a099                	j	1046 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

/// 测试文件基本读写，输出　Test file0 OK! 就算正确。

int main()
{
    1002:	1141                	addi	sp,sp,-16
    1004:	e406                	sd	ra,8(sp)
    1006:	e022                	sd	s0,0(sp)
	int a = 0;
	int b = 1;
	assert(a == b);
    1008:	3ca010ef          	jal	ra,23d2 <getpid>
    100c:	842a                	mv	s0,a0
    100e:	00001517          	auipc	a0,0x1
    1012:	6a250513          	addi	a0,a0,1698 # 26b0 <enable_deadlock_detect+0x10>
    1016:	292010ef          	jal	ra,22a8 <basename>
    101a:	872a                	mv	a4,a0
    101c:	86a2                	mv	a3,s0
    101e:	47b5                	li	a5,13
    1020:	00001617          	auipc	a2,0x1
    1024:	6d860613          	addi	a2,a2,1752 # 26f8 <enable_deadlock_detect+0x58>
    1028:	45fd                	li	a1,31
    102a:	00001517          	auipc	a0,0x1
    102e:	6d650513          	addi	a0,a0,1750 # 2700 <enable_deadlock_detect+0x60>
    1032:	16e000ef          	jal	ra,11a0 <printf>
    1036:	557d                	li	a0,-1
    1038:	3ca010ef          	jal	ra,2402 <exit>
	return 0;
    103c:	60a2                	ld	ra,8(sp)
    103e:	6402                	ld	s0,0(sp)
    1040:	4501                	li	a0,0
    1042:	0141                	addi	sp,sp,16
    1044:	8082                	ret

0000000000001046 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1046:	1141                	addi	sp,sp,-16
    1048:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    104a:	fb9ff0ef          	jal	ra,1002 <main>
    104e:	3b4010ef          	jal	ra,2402 <exit>
	return 0;
    1052:	60a2                	ld	ra,8(sp)
    1054:	4501                	li	a0,0
    1056:	0141                	addi	sp,sp,16
    1058:	8082                	ret

000000000000105a <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    105a:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    105c:	4605                	li	a2,1
    105e:	00f10593          	addi	a1,sp,15
    1062:	4501                	li	a0,0
{
    1064:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1066:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    106a:	354010ef          	jal	ra,23be <read>
    106e:	4785                	li	a5,1
    1070:	00f51763          	bne	a0,a5,107e <getchar+0x24>
		return byte;
    1074:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1078:	60e2                	ld	ra,24(sp)
    107a:	6105                	addi	sp,sp,32
    107c:	8082                	ret
		return EOF;
    107e:	557d                	li	a0,-1
    1080:	bfe5                	j	1078 <getchar+0x1e>

0000000000001082 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1082:	00001517          	auipc	a0,0x1
    1086:	7a652503          	lw	a0,1958(a0) # 2828 <buffer_len>
    108a:	e111                	bnez	a0,108e <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    108c:	8082                	ret
{
    108e:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1090:	862a                	mv	a2,a0
    1092:	00001597          	auipc	a1,0x1
    1096:	79e58593          	addi	a1,a1,1950 # 2830 <buffer>
    109a:	4505                	li	a0,1
{
    109c:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    109e:	32a010ef          	jal	ra,23c8 <write>
}
    10a2:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10a4:	2501                	sext.w	a0,a0
}
    10a6:	0141                	addi	sp,sp,16
    10a8:	8082                	ret

00000000000010aa <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10aa:	00001797          	auipc	a5,0x1
    10ae:	7607af23          	sw	zero,1918(a5) # 2828 <buffer_len>
}
    10b2:	8082                	ret

00000000000010b4 <__fflush>:
	if (buffer_len == 0)
    10b4:	00001517          	auipc	a0,0x1
    10b8:	77452503          	lw	a0,1908(a0) # 2828 <buffer_len>
    10bc:	e511                	bnez	a0,10c8 <__fflush+0x14>
	buffer_len = 0;
    10be:	00001797          	auipc	a5,0x1
    10c2:	7607a523          	sw	zero,1898(a5) # 2828 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10c6:	8082                	ret
{
    10c8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ca:	862a                	mv	a2,a0
    10cc:	00001597          	auipc	a1,0x1
    10d0:	76458593          	addi	a1,a1,1892 # 2830 <buffer>
    10d4:	4505                	li	a0,1
{
    10d6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10d8:	2f0010ef          	jal	ra,23c8 <write>
	return r >= 0 ? 0 : r;
    10dc:	0005079b          	sext.w	a5,a0
}
    10e0:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10e2:	0017a793          	slti	a5,a5,1
    10e6:	40f007bb          	negw	a5,a5
    10ea:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10ec:	00001797          	auipc	a5,0x1
    10f0:	7207ae23          	sw	zero,1852(a5) # 2828 <buffer_len>
	return r >= 0 ? 0 : r;
    10f4:	2501                	sext.w	a0,a0
}
    10f6:	0141                	addi	sp,sp,16
    10f8:	8082                	ret

00000000000010fa <fflush>:

int fflush(int fd)
{
    10fa:	1101                	addi	sp,sp,-32
    10fc:	e822                	sd	s0,16(sp)
    10fe:	ec06                	sd	ra,24(sp)
    1100:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1102:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1104:	4401                	li	s0,0
	if (fd == 1) {
    1106:	00e50863          	beq	a0,a4,1116 <fflush+0x1c>
}
    110a:	60e2                	ld	ra,24(sp)
    110c:	8522                	mv	a0,s0
    110e:	6442                	ld	s0,16(sp)
    1110:	64a2                	ld	s1,8(sp)
    1112:	6105                	addi	sp,sp,32
    1114:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1116:	00001497          	auipc	s1,0x1
    111a:	71248493          	addi	s1,s1,1810 # 2828 <buffer_len>
    111e:	1084a703          	lw	a4,264(s1)
    1122:	02a70e63          	beq	a4,a0,115e <fflush+0x64>
	if (buffer_len == 0)
    1126:	4080                	lw	s0,0(s1)
    1128:	c00d                	beqz	s0,114a <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    112a:	8622                	mv	a2,s0
    112c:	00001597          	auipc	a1,0x1
    1130:	70458593          	addi	a1,a1,1796 # 2830 <buffer>
    1134:	294010ef          	jal	ra,23c8 <write>
	return r >= 0 ? 0 : r;
    1138:	0005079b          	sext.w	a5,a0
    113c:	0017a793          	slti	a5,a5,1
    1140:	40f007bb          	negw	a5,a5
    1144:	8d7d                	and	a0,a0,a5
    1146:	0005041b          	sext.w	s0,a0
}
    114a:	60e2                	ld	ra,24(sp)
    114c:	8522                	mv	a0,s0
    114e:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1150:	00001797          	auipc	a5,0x1
    1154:	6c07ac23          	sw	zero,1752(a5) # 2828 <buffer_len>
}
    1158:	64a2                	ld	s1,8(sp)
    115a:	6105                	addi	sp,sp,32
    115c:	8082                	ret
			mutex_lock(buffer_lock);
    115e:	10c4a503          	lw	a0,268(s1)
    1162:	4de010ef          	jal	ra,2640 <mutex_lock>
	if (buffer_len == 0)
    1166:	4080                	lw	s0,0(s1)
    1168:	e811                	bnez	s0,117c <fflush+0x82>
			mutex_unlock(buffer_lock);
    116a:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    116e:	00001797          	auipc	a5,0x1
    1172:	6a07ad23          	sw	zero,1722(a5) # 2828 <buffer_len>
			mutex_unlock(buffer_lock);
    1176:	4d6010ef          	jal	ra,264c <mutex_unlock>
    117a:	bf41                	j	110a <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    117c:	8622                	mv	a2,s0
    117e:	00001597          	auipc	a1,0x1
    1182:	6b258593          	addi	a1,a1,1714 # 2830 <buffer>
    1186:	4505                	li	a0,1
    1188:	240010ef          	jal	ra,23c8 <write>
	return r >= 0 ? 0 : r;
    118c:	0005079b          	sext.w	a5,a0
    1190:	0017a793          	slti	a5,a5,1
    1194:	40f007bb          	negw	a5,a5
    1198:	8d7d                	and	a0,a0,a5
    119a:	0005041b          	sext.w	s0,a0
	return r;
    119e:	b7f1                	j	116a <fflush+0x70>

00000000000011a0 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11a0:	7131                	addi	sp,sp,-192
    11a2:	e0da                	sd	s6,64(sp)
    11a4:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11a6:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11a8:	013c                	addi	a5,sp,136
{
    11aa:	f0ca                	sd	s2,96(sp)
    11ac:	ecce                	sd	s3,88(sp)
    11ae:	e8d2                	sd	s4,80(sp)
    11b0:	e4d6                	sd	s5,72(sp)
    11b2:	fc86                	sd	ra,120(sp)
    11b4:	f8a2                	sd	s0,112(sp)
    11b6:	f4a6                	sd	s1,104(sp)
    11b8:	89aa                	mv	s3,a0
    11ba:	e52e                	sd	a1,136(sp)
    11bc:	e932                	sd	a2,144(sp)
    11be:	ed36                	sd	a3,152(sp)
    11c0:	f13a                	sd	a4,160(sp)
    11c2:	f942                	sd	a6,176(sp)
    11c4:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11c6:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11c8:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11cc:	00001a17          	auipc	s4,0x1
    11d0:	65ca0a13          	addi	s4,s4,1628 # 2828 <buffer_len>
    11d4:	4a85                	li	s5,1
	buf[i++] = '0';
    11d6:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11da:	0009c783          	lbu	a5,0(s3)
    11de:	18078663          	beqz	a5,136a <printf+0x1ca>
    11e2:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11e4:	19278d63          	beq	a5,s2,137e <printf+0x1de>
    11e8:	0015c783          	lbu	a5,1(a1)
    11ec:	0585                	addi	a1,a1,1
    11ee:	fbfd                	bnez	a5,11e4 <printf+0x44>
    11f0:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11f2:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    11f6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    11fa:	1b578863          	beq	a5,s5,13aa <printf+0x20a>
		len = out_unlocked(s, l);
    11fe:	85a2                	mv	a1,s0
    1200:	854e                	mv	a0,s3
    1202:	42a000ef          	jal	ra,162c <out_unlocked>
		out(f, a, l);
		if (l)
    1206:	1c041063          	bnez	s0,13c6 <printf+0x226>
			continue;
		if (s[1] == 0)
    120a:	0014c783          	lbu	a5,1(s1)
    120e:	14078e63          	beqz	a5,136a <printf+0x1ca>
			break;
		switch (s[1]) {
    1212:	07300713          	li	a4,115
    1216:	1ce78863          	beq	a5,a4,13e6 <printf+0x246>
    121a:	1af76863          	bltu	a4,a5,13ca <printf+0x22a>
    121e:	06400713          	li	a4,100
    1222:	22e78063          	beq	a5,a4,1442 <printf+0x2a2>
    1226:	07000713          	li	a4,112
    122a:	1ee79563          	bne	a5,a4,1414 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    122e:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1230:	00001797          	auipc	a5,0x1
    1234:	70878793          	addi	a5,a5,1800 # 2938 <digits>
	buf[i++] = '0';
    1238:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    123c:	6298                	ld	a4,0(a3)
    123e:	06a1                	addi	a3,a3,8
    1240:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1242:	00471393          	slli	t2,a4,0x4
    1246:	00871293          	slli	t0,a4,0x8
    124a:	00c71f93          	slli	t6,a4,0xc
    124e:	01071f13          	slli	t5,a4,0x10
    1252:	01471e93          	slli	t4,a4,0x14
    1256:	01871e13          	slli	t3,a4,0x18
    125a:	01c71893          	slli	a7,a4,0x1c
    125e:	02471813          	slli	a6,a4,0x24
    1262:	02871513          	slli	a0,a4,0x28
    1266:	02c71593          	slli	a1,a4,0x2c
    126a:	03071613          	slli	a2,a4,0x30
    126e:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1272:	03c75413          	srli	s0,a4,0x3c
    1276:	01c7531b          	srliw	t1,a4,0x1c
    127a:	03c3d393          	srli	t2,t2,0x3c
    127e:	03c2d293          	srli	t0,t0,0x3c
    1282:	03cfdf93          	srli	t6,t6,0x3c
    1286:	03cf5f13          	srli	t5,t5,0x3c
    128a:	03cede93          	srli	t4,t4,0x3c
    128e:	03ce5e13          	srli	t3,t3,0x3c
    1292:	03c8d893          	srli	a7,a7,0x3c
    1296:	03c85813          	srli	a6,a6,0x3c
    129a:	9171                	srli	a0,a0,0x3c
    129c:	91f1                	srli	a1,a1,0x3c
    129e:	9271                	srli	a2,a2,0x3c
    12a0:	92f1                	srli	a3,a3,0x3c
    12a2:	95be                	add	a1,a1,a5
    12a4:	963e                	add	a2,a2,a5
    12a6:	96be                	add	a3,a3,a5
    12a8:	943e                	add	s0,s0,a5
    12aa:	93be                	add	t2,t2,a5
    12ac:	92be                	add	t0,t0,a5
    12ae:	9fbe                	add	t6,t6,a5
    12b0:	9f3e                	add	t5,t5,a5
    12b2:	9ebe                	add	t4,t4,a5
    12b4:	9e3e                	add	t3,t3,a5
    12b6:	98be                	add	a7,a7,a5
    12b8:	933e                	add	t1,t1,a5
    12ba:	983e                	add	a6,a6,a5
    12bc:	953e                	add	a0,a0,a5
    12be:	0005c983          	lbu	s3,0(a1)
    12c2:	00044403          	lbu	s0,0(s0)
    12c6:	00064583          	lbu	a1,0(a2)
    12ca:	0003c383          	lbu	t2,0(t2)
    12ce:	0006c603          	lbu	a2,0(a3)
    12d2:	0002c283          	lbu	t0,0(t0)
    12d6:	000fcf83          	lbu	t6,0(t6)
    12da:	000f4f03          	lbu	t5,0(t5)
    12de:	000ece83          	lbu	t4,0(t4)
    12e2:	000e4e03          	lbu	t3,0(t3)
    12e6:	0008c883          	lbu	a7,0(a7)
    12ea:	00034303          	lbu	t1,0(t1)
    12ee:	00084803          	lbu	a6,0(a6)
    12f2:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12f6:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12fa:	92f1                	srli	a3,a3,0x3c
    12fc:	8b3d                	andi	a4,a4,15
    12fe:	96be                	add	a3,a3,a5
    1300:	97ba                	add	a5,a5,a4
    1302:	00810d23          	sb	s0,26(sp)
    1306:	00710da3          	sb	t2,27(sp)
    130a:	00510e23          	sb	t0,28(sp)
    130e:	01f10ea3          	sb	t6,29(sp)
    1312:	01e10f23          	sb	t5,30(sp)
    1316:	01d10fa3          	sb	t4,31(sp)
    131a:	03c10023          	sb	t3,32(sp)
    131e:	031100a3          	sb	a7,33(sp)
    1322:	02610123          	sb	t1,34(sp)
    1326:	030101a3          	sb	a6,35(sp)
    132a:	02a10223          	sb	a0,36(sp)
    132e:	033102a3          	sb	s3,37(sp)
    1332:	02b10323          	sb	a1,38(sp)
    1336:	02c103a3          	sb	a2,39(sp)
    133a:	0006c683          	lbu	a3,0(a3)
    133e:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1342:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1346:	02d10423          	sb	a3,40(sp)
    134a:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    134e:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1352:	11578263          	beq	a5,s5,1456 <printf+0x2b6>
		len = out_unlocked(s, l);
    1356:	45c9                	li	a1,18
    1358:	0828                	addi	a0,sp,24
    135a:	2d2000ef          	jal	ra,162c <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    135e:	00248993          	addi	s3,s1,2
		if (!*s)
    1362:	0009c783          	lbu	a5,0(s3)
    1366:	e6079ee3          	bnez	a5,11e2 <printf+0x42>
	}
	va_end(ap);
    136a:	70e6                	ld	ra,120(sp)
    136c:	7446                	ld	s0,112(sp)
    136e:	74a6                	ld	s1,104(sp)
    1370:	7906                	ld	s2,96(sp)
    1372:	69e6                	ld	s3,88(sp)
    1374:	6a46                	ld	s4,80(sp)
    1376:	6aa6                	ld	s5,72(sp)
    1378:	6b06                	ld	s6,64(sp)
    137a:	6129                	addi	sp,sp,192
    137c:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    137e:	0005c783          	lbu	a5,0(a1)
    1382:	84ae                	mv	s1,a1
    1384:	01278963          	beq	a5,s2,1396 <printf+0x1f6>
    1388:	b5ad                	j	11f2 <printf+0x52>
    138a:	0024c783          	lbu	a5,2(s1)
    138e:	0585                	addi	a1,a1,1
    1390:	0489                	addi	s1,s1,2
    1392:	e72790e3          	bne	a5,s2,11f2 <printf+0x52>
    1396:	0014c783          	lbu	a5,1(s1)
    139a:	ff2788e3          	beq	a5,s2,138a <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    139e:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13a2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13a6:	e5579ce3          	bne	a5,s5,11fe <printf+0x5e>
		mutex_lock(buffer_lock);
    13aa:	10ca2503          	lw	a0,268(s4)
    13ae:	292010ef          	jal	ra,2640 <mutex_lock>
		len = out_unlocked(s, l);
    13b2:	85a2                	mv	a1,s0
    13b4:	854e                	mv	a0,s3
    13b6:	276000ef          	jal	ra,162c <out_unlocked>
		mutex_unlock(buffer_lock);
    13ba:	10ca2503          	lw	a0,268(s4)
    13be:	28e010ef          	jal	ra,264c <mutex_unlock>
		if (l)
    13c2:	e40404e3          	beqz	s0,120a <printf+0x6a>
    13c6:	89a6                	mv	s3,s1
    13c8:	bd09                	j	11da <printf+0x3a>
		switch (s[1]) {
    13ca:	07800713          	li	a4,120
    13ce:	04e79363          	bne	a5,a4,1414 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13d2:	67c2                	ld	a5,16(sp)
    13d4:	45c1                	li	a1,16
		s += 2;
    13d6:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13da:	4388                	lw	a0,0(a5)
    13dc:	07a1                	addi	a5,a5,8
    13de:	e83e                	sd	a5,16(sp)
    13e0:	5f8000ef          	jal	ra,19d8 <printint.constprop.0>
		s += 2;
    13e4:	bfbd                	j	1362 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13e6:	67c2                	ld	a5,16(sp)
    13e8:	6380                	ld	s0,0(a5)
    13ea:	07a1                	addi	a5,a5,8
    13ec:	e83e                	sd	a5,16(sp)
    13ee:	1c040163          	beqz	s0,15b0 <printf+0x410>
			l = strnlen(a, 200);
    13f2:	0c800593          	li	a1,200
    13f6:	8522                	mv	a0,s0
    13f8:	3f7000ef          	jal	ra,1fee <strnlen>
	if (buffer_lock_enabled == 1) {
    13fc:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1400:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1404:	19578663          	beq	a5,s5,1590 <printf+0x3f0>
		len = out_unlocked(s, l);
    1408:	8522                	mv	a0,s0
    140a:	222000ef          	jal	ra,162c <out_unlocked>
		s += 2;
    140e:	00248993          	addi	s3,s1,2
    1412:	bf81                	j	1362 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1414:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1418:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    141c:	0f578663          	beq	a5,s5,1508 <printf+0x368>
		len = out_unlocked(s, l);
    1420:	0828                	addi	a0,sp,24
    1422:	316000ef          	jal	ra,1738 <out_unlocked.constprop.0>
			putchar(s[1]);
    1426:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    142a:	108a2783          	lw	a5,264(s4)
	char byte = c;
    142e:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1432:	05578163          	beq	a5,s5,1474 <printf+0x2d4>
		len = out_unlocked(s, l);
    1436:	0828                	addi	a0,sp,24
    1438:	300000ef          	jal	ra,1738 <out_unlocked.constprop.0>
		s += 2;
    143c:	00248993          	addi	s3,s1,2
    1440:	b70d                	j	1362 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1442:	67c2                	ld	a5,16(sp)
    1444:	45a9                	li	a1,10
		s += 2;
    1446:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    144a:	4388                	lw	a0,0(a5)
    144c:	07a1                	addi	a5,a5,8
    144e:	e83e                	sd	a5,16(sp)
    1450:	588000ef          	jal	ra,19d8 <printint.constprop.0>
		s += 2;
    1454:	b739                	j	1362 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1456:	10ca2503          	lw	a0,268(s4)
		s += 2;
    145a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    145e:	1e2010ef          	jal	ra,2640 <mutex_lock>
		len = out_unlocked(s, l);
    1462:	45c9                	li	a1,18
    1464:	0828                	addi	a0,sp,24
    1466:	1c6000ef          	jal	ra,162c <out_unlocked>
		mutex_unlock(buffer_lock);
    146a:	10ca2503          	lw	a0,268(s4)
    146e:	1de010ef          	jal	ra,264c <mutex_unlock>
		s += 2;
    1472:	bdc5                	j	1362 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1474:	10ca2503          	lw	a0,268(s4)
    1478:	1c8010ef          	jal	ra,2640 <mutex_lock>
		buffer[buffer_len++] = c;
    147c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1480:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1484:	0017861b          	addiw	a2,a5,1
    1488:	97d2                	add	a5,a5,s4
    148a:	00ca2023          	sw	a2,0(s4)
    148e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1492:	00c6cc63          	blt	a3,a2,14aa <printf+0x30a>
    1496:	47a9                	li	a5,10
    1498:	06f40663          	beq	s0,a5,1504 <printf+0x364>
		mutex_unlock(buffer_lock);
    149c:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14a0:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14a4:	1a8010ef          	jal	ra,264c <mutex_unlock>
		s += 2;
    14a8:	bd6d                	j	1362 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14aa:	10000793          	li	a5,256
    14ae:	00f61e63          	bne	a2,a5,14ca <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14b2:	00001597          	auipc	a1,0x1
    14b6:	37e58593          	addi	a1,a1,894 # 2830 <buffer>
    14ba:	4505                	li	a0,1
    14bc:	70d000ef          	jal	ra,23c8 <write>
	buffer_len = 0;
    14c0:	00001797          	auipc	a5,0x1
    14c4:	3607a423          	sw	zero,872(a5) # 2828 <buffer_len>
			if (r < 0) {
    14c8:	bfd1                	j	149c <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14ca:	709000ef          	jal	ra,23d2 <getpid>
    14ce:	842a                	mv	s0,a0
    14d0:	00001517          	auipc	a0,0x1
    14d4:	26850513          	addi	a0,a0,616 # 2738 <enable_deadlock_detect+0x98>
    14d8:	5d1000ef          	jal	ra,22a8 <basename>
    14dc:	872a                	mv	a4,a0
    14de:	00001617          	auipc	a2,0x1
    14e2:	21a60613          	addi	a2,a2,538 # 26f8 <enable_deadlock_detect+0x58>
    14e6:	05400793          	li	a5,84
    14ea:	86a2                	mv	a3,s0
    14ec:	45fd                	li	a1,31
    14ee:	00001517          	auipc	a0,0x1
    14f2:	28a50513          	addi	a0,a0,650 # 2778 <enable_deadlock_detect+0xd8>
    14f6:	cabff0ef          	jal	ra,11a0 <printf>
    14fa:	557d                	li	a0,-1
    14fc:	707000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    1500:	000a2603          	lw	a2,0(s4)
    1504:	de41                	beqz	a2,149c <printf+0x2fc>
    1506:	b775                	j	14b2 <printf+0x312>
		mutex_lock(buffer_lock);
    1508:	10ca2503          	lw	a0,268(s4)
    150c:	134010ef          	jal	ra,2640 <mutex_lock>
		buffer[buffer_len++] = c;
    1510:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1514:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1518:	0017861b          	addiw	a2,a5,1
    151c:	97d2                	add	a5,a5,s4
    151e:	00ca2023          	sw	a2,0(s4)
    1522:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1526:	02c6d163          	bge	a3,a2,1548 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    152a:	10000793          	li	a5,256
    152e:	02f61263          	bne	a2,a5,1552 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1532:	00001597          	auipc	a1,0x1
    1536:	2fe58593          	addi	a1,a1,766 # 2830 <buffer>
    153a:	4505                	li	a0,1
    153c:	68d000ef          	jal	ra,23c8 <write>
	buffer_len = 0;
    1540:	00001797          	auipc	a5,0x1
    1544:	2e07a423          	sw	zero,744(a5) # 2828 <buffer_len>
		mutex_unlock(buffer_lock);
    1548:	10ca2503          	lw	a0,268(s4)
    154c:	100010ef          	jal	ra,264c <mutex_unlock>
    1550:	bdd9                	j	1426 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1552:	681000ef          	jal	ra,23d2 <getpid>
    1556:	842a                	mv	s0,a0
    1558:	00001517          	auipc	a0,0x1
    155c:	1e050513          	addi	a0,a0,480 # 2738 <enable_deadlock_detect+0x98>
    1560:	549000ef          	jal	ra,22a8 <basename>
    1564:	872a                	mv	a4,a0
    1566:	00001617          	auipc	a2,0x1
    156a:	19260613          	addi	a2,a2,402 # 26f8 <enable_deadlock_detect+0x58>
    156e:	05400793          	li	a5,84
    1572:	86a2                	mv	a3,s0
    1574:	45fd                	li	a1,31
    1576:	00001517          	auipc	a0,0x1
    157a:	20250513          	addi	a0,a0,514 # 2778 <enable_deadlock_detect+0xd8>
    157e:	c23ff0ef          	jal	ra,11a0 <printf>
    1582:	557d                	li	a0,-1
    1584:	67f000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    1588:	000a2603          	lw	a2,0(s4)
    158c:	de55                	beqz	a2,1548 <printf+0x3a8>
    158e:	b755                	j	1532 <printf+0x392>
		mutex_lock(buffer_lock);
    1590:	10ca2503          	lw	a0,268(s4)
    1594:	e42e                	sd	a1,8(sp)
		s += 2;
    1596:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    159a:	0a6010ef          	jal	ra,2640 <mutex_lock>
		len = out_unlocked(s, l);
    159e:	65a2                	ld	a1,8(sp)
    15a0:	8522                	mv	a0,s0
    15a2:	08a000ef          	jal	ra,162c <out_unlocked>
		mutex_unlock(buffer_lock);
    15a6:	10ca2503          	lw	a0,268(s4)
    15aa:	0a2010ef          	jal	ra,264c <mutex_unlock>
		s += 2;
    15ae:	bb55                	j	1362 <printf+0x1c2>
				a = "(null)";
    15b0:	00001417          	auipc	s0,0x1
    15b4:	18040413          	addi	s0,s0,384 # 2730 <enable_deadlock_detect+0x90>
    15b8:	bd2d                	j	13f2 <printf+0x252>

00000000000015ba <enable_thread_io_buffer>:
{
    15ba:	1101                	addi	sp,sp,-32
    15bc:	e822                	sd	s0,16(sp)
    15be:	ec06                	sd	ra,24(sp)
    15c0:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15c2:	00001417          	auipc	s0,0x1
    15c6:	26640413          	addi	s0,s0,614 # 2828 <buffer_len>
    15ca:	05a010ef          	jal	ra,2624 <mutex_create>
    15ce:	10a42623          	sw	a0,268(s0)
    15d2:	00054a63          	bltz	a0,15e6 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15d6:	4785                	li	a5,1
}
    15d8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15da:	10f42423          	sw	a5,264(s0)
}
    15de:	6442                	ld	s0,16(sp)
    15e0:	64a2                	ld	s1,8(sp)
    15e2:	6105                	addi	sp,sp,32
    15e4:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15e6:	5ed000ef          	jal	ra,23d2 <getpid>
    15ea:	84aa                	mv	s1,a0
    15ec:	00001517          	auipc	a0,0x1
    15f0:	14c50513          	addi	a0,a0,332 # 2738 <enable_deadlock_detect+0x98>
    15f4:	4b5000ef          	jal	ra,22a8 <basename>
    15f8:	872a                	mv	a4,a0
    15fa:	04800793          	li	a5,72
    15fe:	86a6                	mv	a3,s1
    1600:	00001517          	auipc	a0,0x1
    1604:	1b850513          	addi	a0,a0,440 # 27b8 <enable_deadlock_detect+0x118>
    1608:	00001617          	auipc	a2,0x1
    160c:	0f060613          	addi	a2,a2,240 # 26f8 <enable_deadlock_detect+0x58>
    1610:	45fd                	li	a1,31
    1612:	b8fff0ef          	jal	ra,11a0 <printf>
    1616:	557d                	li	a0,-1
    1618:	5eb000ef          	jal	ra,2402 <exit>
	buffer_lock_enabled = 1;
    161c:	4785                	li	a5,1
}
    161e:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1620:	10f42423          	sw	a5,264(s0)
}
    1624:	6442                	ld	s0,16(sp)
    1626:	64a2                	ld	s1,8(sp)
    1628:	6105                	addi	sp,sp,32
    162a:	8082                	ret

000000000000162c <out_unlocked>:
{
    162c:	7159                	addi	sp,sp,-112
    162e:	f486                	sd	ra,104(sp)
    1630:	f0a2                	sd	s0,96(sp)
    1632:	eca6                	sd	s1,88(sp)
    1634:	e8ca                	sd	s2,80(sp)
    1636:	e4ce                	sd	s3,72(sp)
    1638:	e0d2                	sd	s4,64(sp)
    163a:	fc56                	sd	s5,56(sp)
    163c:	f85a                	sd	s6,48(sp)
    163e:	f45e                	sd	s7,40(sp)
    1640:	f062                	sd	s8,32(sp)
    1642:	ec66                	sd	s9,24(sp)
    1644:	e86a                	sd	s10,16(sp)
    1646:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1648:	0e058663          	beqz	a1,1734 <out_unlocked+0x108>
    164c:	842a                	mv	s0,a0
    164e:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1652:	4981                	li	s3,0
    1654:	00001d17          	auipc	s10,0x1
    1658:	1d4d0d13          	addi	s10,s10,468 # 2828 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    165c:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1660:	00001b17          	auipc	s6,0x1
    1664:	1d0b0b13          	addi	s6,s6,464 # 2830 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1668:	10000a93          	li	s5,256
    166c:	00001c97          	auipc	s9,0x1
    1670:	0ccc8c93          	addi	s9,s9,204 # 2738 <enable_deadlock_detect+0x98>
    1674:	00001c17          	auipc	s8,0x1
    1678:	084c0c13          	addi	s8,s8,132 # 26f8 <enable_deadlock_detect+0x58>
    167c:	00001b97          	auipc	s7,0x1
    1680:	0fcb8b93          	addi	s7,s7,252 # 2778 <enable_deadlock_detect+0xd8>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1684:	4a29                	li	s4,10
    1686:	a031                	j	1692 <out_unlocked+0x66>
    1688:	09468863          	beq	a3,s4,1718 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    168c:	0405                	addi	s0,s0,1
    168e:	04848163          	beq	s1,s0,16d0 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1692:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1696:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    169a:	0017861b          	addiw	a2,a5,1
    169e:	97ea                	add	a5,a5,s10
    16a0:	00cd2023          	sw	a2,0(s10)
    16a4:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16a8:	fec950e3          	bge	s2,a2,1688 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16ac:	05561263          	bne	a2,s5,16f0 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16b0:	85da                	mv	a1,s6
    16b2:	4505                	li	a0,1
    16b4:	515000ef          	jal	ra,23c8 <write>
    16b8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16ba:	00001797          	auipc	a5,0x1
    16be:	1607a723          	sw	zero,366(a5) # 2828 <buffer_len>
			if (r < 0) {
    16c2:	06054763          	bltz	a0,1730 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16c6:	0405                	addi	s0,s0,1
			ret += r;
    16c8:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16cc:	fc8493e3          	bne	s1,s0,1692 <out_unlocked+0x66>
}
    16d0:	70a6                	ld	ra,104(sp)
    16d2:	7406                	ld	s0,96(sp)
    16d4:	64e6                	ld	s1,88(sp)
    16d6:	6946                	ld	s2,80(sp)
    16d8:	6a06                	ld	s4,64(sp)
    16da:	7ae2                	ld	s5,56(sp)
    16dc:	7b42                	ld	s6,48(sp)
    16de:	7ba2                	ld	s7,40(sp)
    16e0:	7c02                	ld	s8,32(sp)
    16e2:	6ce2                	ld	s9,24(sp)
    16e4:	6d42                	ld	s10,16(sp)
    16e6:	6da2                	ld	s11,8(sp)
    16e8:	854e                	mv	a0,s3
    16ea:	69a6                	ld	s3,72(sp)
    16ec:	6165                	addi	sp,sp,112
    16ee:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16f0:	4e3000ef          	jal	ra,23d2 <getpid>
    16f4:	8daa                	mv	s11,a0
    16f6:	8566                	mv	a0,s9
    16f8:	3b1000ef          	jal	ra,22a8 <basename>
    16fc:	872a                	mv	a4,a0
    16fe:	8662                	mv	a2,s8
    1700:	05400793          	li	a5,84
    1704:	86ee                	mv	a3,s11
    1706:	45fd                	li	a1,31
    1708:	855e                	mv	a0,s7
    170a:	a97ff0ef          	jal	ra,11a0 <printf>
    170e:	557d                	li	a0,-1
    1710:	4f3000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    1714:	000d2603          	lw	a2,0(s10)
    1718:	da35                	beqz	a2,168c <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    171a:	85da                	mv	a1,s6
    171c:	4505                	li	a0,1
    171e:	4ab000ef          	jal	ra,23c8 <write>
    1722:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1724:	00001797          	auipc	a5,0x1
    1728:	1007a223          	sw	zero,260(a5) # 2828 <buffer_len>
			if (r < 0) {
    172c:	f8055de3          	bgez	a0,16c6 <out_unlocked+0x9a>
    1730:	89aa                	mv	s3,a0
    1732:	bf79                	j	16d0 <out_unlocked+0xa4>
	int ret = 0;
    1734:	4981                	li	s3,0
    1736:	bf69                	j	16d0 <out_unlocked+0xa4>

0000000000001738 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1738:	1101                	addi	sp,sp,-32
    173a:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    173c:	00001497          	auipc	s1,0x1
    1740:	0ec48493          	addi	s1,s1,236 # 2828 <buffer_len>
    1744:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1746:	ec06                	sd	ra,24(sp)
    1748:	e822                	sd	s0,16(sp)
		char c = s[i];
    174a:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    174e:	0017861b          	addiw	a2,a5,1
    1752:	97a6                	add	a5,a5,s1
    1754:	00e78423          	sb	a4,8(a5)
    1758:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    175a:	0ff00793          	li	a5,255
    175e:	00c7cc63          	blt	a5,a2,1776 <out_unlocked.constprop.0+0x3e>
    1762:	47a9                	li	a5,10
    1764:	06f70c63          	beq	a4,a5,17dc <out_unlocked.constprop.0+0xa4>
    1768:	4601                	li	a2,0
}
    176a:	60e2                	ld	ra,24(sp)
    176c:	6442                	ld	s0,16(sp)
    176e:	64a2                	ld	s1,8(sp)
    1770:	8532                	mv	a0,a2
    1772:	6105                	addi	sp,sp,32
    1774:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1776:	10000793          	li	a5,256
    177a:	02f61563          	bne	a2,a5,17a4 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    177e:	00001597          	auipc	a1,0x1
    1782:	0b258593          	addi	a1,a1,178 # 2830 <buffer>
    1786:	4505                	li	a0,1
    1788:	441000ef          	jal	ra,23c8 <write>
}
    178c:	60e2                	ld	ra,24(sp)
    178e:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1790:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1794:	00001797          	auipc	a5,0x1
    1798:	0807aa23          	sw	zero,148(a5) # 2828 <buffer_len>
}
    179c:	64a2                	ld	s1,8(sp)
    179e:	8532                	mv	a0,a2
    17a0:	6105                	addi	sp,sp,32
    17a2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17a4:	42f000ef          	jal	ra,23d2 <getpid>
    17a8:	842a                	mv	s0,a0
    17aa:	00001517          	auipc	a0,0x1
    17ae:	f8e50513          	addi	a0,a0,-114 # 2738 <enable_deadlock_detect+0x98>
    17b2:	2f7000ef          	jal	ra,22a8 <basename>
    17b6:	872a                	mv	a4,a0
    17b8:	00001617          	auipc	a2,0x1
    17bc:	f4060613          	addi	a2,a2,-192 # 26f8 <enable_deadlock_detect+0x58>
    17c0:	05400793          	li	a5,84
    17c4:	86a2                	mv	a3,s0
    17c6:	45fd                	li	a1,31
    17c8:	00001517          	auipc	a0,0x1
    17cc:	fb050513          	addi	a0,a0,-80 # 2778 <enable_deadlock_detect+0xd8>
    17d0:	9d1ff0ef          	jal	ra,11a0 <printf>
    17d4:	557d                	li	a0,-1
    17d6:	42d000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    17da:	4090                	lw	a2,0(s1)
    17dc:	d659                	beqz	a2,176a <out_unlocked.constprop.0+0x32>
    17de:	b745                	j	177e <out_unlocked.constprop.0+0x46>

00000000000017e0 <putchar>:
{
    17e0:	7139                	addi	sp,sp,-64
    17e2:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17e4:	00001497          	auipc	s1,0x1
    17e8:	04448493          	addi	s1,s1,68 # 2828 <buffer_len>
    17ec:	1084a703          	lw	a4,264(s1)
{
    17f0:	f822                	sd	s0,48(sp)
	char byte = c;
    17f2:	0ff57413          	zext.b	s0,a0
{
    17f6:	fc06                	sd	ra,56(sp)
	char byte = c;
    17f8:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    17fc:	4785                	li	a5,1
    17fe:	00f70d63          	beq	a4,a5,1818 <putchar+0x38>
		len = out_unlocked(s, l);
    1802:	01f10513          	addi	a0,sp,31
    1806:	f33ff0ef          	jal	ra,1738 <out_unlocked.constprop.0>
}
    180a:	70e2                	ld	ra,56(sp)
    180c:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    180e:	862a                	mv	a2,a0
}
    1810:	74a2                	ld	s1,40(sp)
    1812:	8532                	mv	a0,a2
    1814:	6121                	addi	sp,sp,64
    1816:	8082                	ret
		mutex_lock(buffer_lock);
    1818:	10c4a503          	lw	a0,268(s1)
    181c:	625000ef          	jal	ra,2640 <mutex_lock>
		buffer[buffer_len++] = c;
    1820:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1822:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1826:	0017861b          	addiw	a2,a5,1
    182a:	97a6                	add	a5,a5,s1
    182c:	c090                	sw	a2,0(s1)
    182e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1832:	02c6c263          	blt	a3,a2,1856 <putchar+0x76>
    1836:	47a9                	li	a5,10
    1838:	06f40d63          	beq	s0,a5,18b2 <putchar+0xd2>
    183c:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    183e:	10c4a503          	lw	a0,268(s1)
    1842:	e432                	sd	a2,8(sp)
    1844:	609000ef          	jal	ra,264c <mutex_unlock>
    1848:	6622                	ld	a2,8(sp)
}
    184a:	70e2                	ld	ra,56(sp)
    184c:	7442                	ld	s0,48(sp)
    184e:	74a2                	ld	s1,40(sp)
    1850:	8532                	mv	a0,a2
    1852:	6121                	addi	sp,sp,64
    1854:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1856:	10000793          	li	a5,256
    185a:	02f61063          	bne	a2,a5,187a <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    185e:	00001597          	auipc	a1,0x1
    1862:	fd258593          	addi	a1,a1,-46 # 2830 <buffer>
    1866:	4505                	li	a0,1
    1868:	361000ef          	jal	ra,23c8 <write>
    186c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1870:	00001797          	auipc	a5,0x1
    1874:	fa07ac23          	sw	zero,-72(a5) # 2828 <buffer_len>
			if (r < 0) {
    1878:	b7d9                	j	183e <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    187a:	359000ef          	jal	ra,23d2 <getpid>
    187e:	842a                	mv	s0,a0
    1880:	00001517          	auipc	a0,0x1
    1884:	eb850513          	addi	a0,a0,-328 # 2738 <enable_deadlock_detect+0x98>
    1888:	221000ef          	jal	ra,22a8 <basename>
    188c:	872a                	mv	a4,a0
    188e:	00001617          	auipc	a2,0x1
    1892:	e6a60613          	addi	a2,a2,-406 # 26f8 <enable_deadlock_detect+0x58>
    1896:	05400793          	li	a5,84
    189a:	86a2                	mv	a3,s0
    189c:	45fd                	li	a1,31
    189e:	00001517          	auipc	a0,0x1
    18a2:	eda50513          	addi	a0,a0,-294 # 2778 <enable_deadlock_detect+0xd8>
    18a6:	8fbff0ef          	jal	ra,11a0 <printf>
    18aa:	557d                	li	a0,-1
    18ac:	357000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    18b0:	4090                	lw	a2,0(s1)
    18b2:	d651                	beqz	a2,183e <putchar+0x5e>
    18b4:	b76d                	j	185e <putchar+0x7e>

00000000000018b6 <puts>:
{
    18b6:	7139                	addi	sp,sp,-64
    18b8:	f822                	sd	s0,48(sp)
    18ba:	f426                	sd	s1,40(sp)
    18bc:	fc06                	sd	ra,56(sp)
    18be:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18c0:	00001417          	auipc	s0,0x1
    18c4:	f6840413          	addi	s0,s0,-152 # 2828 <buffer_len>
{
    18c8:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ca:	638000ef          	jal	ra,1f02 <strlen>
	if (buffer_lock_enabled == 1) {
    18ce:	10842703          	lw	a4,264(s0)
    18d2:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18d4:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18d6:	04f70563          	beq	a4,a5,1920 <puts+0x6a>
		len = out_unlocked(s, l);
    18da:	8526                	mv	a0,s1
    18dc:	d51ff0ef          	jal	ra,162c <out_unlocked>
    18e0:	892a                	mv	s2,a0
    18e2:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18e4:	00095963          	bgez	s2,18f6 <puts+0x40>
}
    18e8:	70e2                	ld	ra,56(sp)
    18ea:	7442                	ld	s0,48(sp)
    18ec:	7902                	ld	s2,32(sp)
    18ee:	8526                	mv	a0,s1
    18f0:	74a2                	ld	s1,40(sp)
    18f2:	6121                	addi	sp,sp,64
    18f4:	8082                	ret
	if (buffer_lock_enabled == 1) {
    18f6:	10842703          	lw	a4,264(s0)
	char byte = c;
    18fa:	44a9                	li	s1,10
    18fc:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1900:	4785                	li	a5,1
    1902:	02f70e63          	beq	a4,a5,193e <puts+0x88>
		len = out_unlocked(s, l);
    1906:	01f10513          	addi	a0,sp,31
    190a:	e2fff0ef          	jal	ra,1738 <out_unlocked.constprop.0>
}
    190e:	70e2                	ld	ra,56(sp)
    1910:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1912:	41f5549b          	sraiw	s1,a0,0x1f
}
    1916:	7902                	ld	s2,32(sp)
    1918:	8526                	mv	a0,s1
    191a:	74a2                	ld	s1,40(sp)
    191c:	6121                	addi	sp,sp,64
    191e:	8082                	ret
		mutex_lock(buffer_lock);
    1920:	e42a                	sd	a0,8(sp)
    1922:	10c42503          	lw	a0,268(s0)
    1926:	51b000ef          	jal	ra,2640 <mutex_lock>
		len = out_unlocked(s, l);
    192a:	65a2                	ld	a1,8(sp)
    192c:	8526                	mv	a0,s1
    192e:	cffff0ef          	jal	ra,162c <out_unlocked>
    1932:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1934:	10c42503          	lw	a0,268(s0)
    1938:	515000ef          	jal	ra,264c <mutex_unlock>
    193c:	b75d                	j	18e2 <puts+0x2c>
		mutex_lock(buffer_lock);
    193e:	10c42503          	lw	a0,268(s0)
    1942:	4ff000ef          	jal	ra,2640 <mutex_lock>
		buffer[buffer_len++] = c;
    1946:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1948:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    194c:	0017861b          	addiw	a2,a5,1
    1950:	97a2                	add	a5,a5,s0
    1952:	c010                	sw	a2,0(s0)
    1954:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1958:	06c6dc63          	bge	a3,a2,19d0 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    195c:	10000793          	li	a5,256
    1960:	02f61c63          	bne	a2,a5,1998 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1964:	00001597          	auipc	a1,0x1
    1968:	ecc58593          	addi	a1,a1,-308 # 2830 <buffer>
    196c:	4505                	li	a0,1
    196e:	25b000ef          	jal	ra,23c8 <write>
			if (r < 0) {
    1972:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1974:	00001797          	auipc	a5,0x1
    1978:	ea07aa23          	sw	zero,-332(a5) # 2828 <buffer_len>
			if (r < 0) {
    197c:	04054c63          	bltz	a0,19d4 <puts+0x11e>
			if (r < buffer_len) {
    1980:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1982:	10c42503          	lw	a0,268(s0)
    1986:	4c7000ef          	jal	ra,264c <mutex_unlock>
}
    198a:	70e2                	ld	ra,56(sp)
    198c:	7442                	ld	s0,48(sp)
    198e:	7902                	ld	s2,32(sp)
    1990:	8526                	mv	a0,s1
    1992:	74a2                	ld	s1,40(sp)
    1994:	6121                	addi	sp,sp,64
    1996:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1998:	23b000ef          	jal	ra,23d2 <getpid>
    199c:	84aa                	mv	s1,a0
    199e:	00001517          	auipc	a0,0x1
    19a2:	d9a50513          	addi	a0,a0,-614 # 2738 <enable_deadlock_detect+0x98>
    19a6:	103000ef          	jal	ra,22a8 <basename>
    19aa:	872a                	mv	a4,a0
    19ac:	00001617          	auipc	a2,0x1
    19b0:	d4c60613          	addi	a2,a2,-692 # 26f8 <enable_deadlock_detect+0x58>
    19b4:	05400793          	li	a5,84
    19b8:	86a6                	mv	a3,s1
    19ba:	45fd                	li	a1,31
    19bc:	00001517          	auipc	a0,0x1
    19c0:	dbc50513          	addi	a0,a0,-580 # 2778 <enable_deadlock_detect+0xd8>
    19c4:	fdcff0ef          	jal	ra,11a0 <printf>
    19c8:	557d                	li	a0,-1
    19ca:	239000ef          	jal	ra,2402 <exit>
	if (buffer_len == 0)
    19ce:	4010                	lw	a2,0(s0)
    19d0:	da45                	beqz	a2,1980 <puts+0xca>
    19d2:	bf49                	j	1964 <puts+0xae>
    19d4:	54fd                	li	s1,-1
    19d6:	b775                	j	1982 <puts+0xcc>

00000000000019d8 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19d8:	715d                	addi	sp,sp,-80
    19da:	e486                	sd	ra,72(sp)
    19dc:	e0a2                	sd	s0,64(sp)
    19de:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19e0:	14054363          	bltz	a0,1b26 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19e4:	02b577bb          	remuw	a5,a0,a1
    19e8:	00001617          	auipc	a2,0x1
    19ec:	f5060613          	addi	a2,a2,-176 # 2938 <digits>
	buf[16] = 0;
    19f0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19f4:	0005871b          	sext.w	a4,a1
    19f8:	1782                	slli	a5,a5,0x20
    19fa:	9381                	srli	a5,a5,0x20
    19fc:	97b2                	add	a5,a5,a2
    19fe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a02:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a06:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a0a:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a0c:	0eb56763          	bltu	a0,a1,1afa <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a10:	02e877bb          	remuw	a5,a6,a4
    1a14:	1782                	slli	a5,a5,0x20
    1a16:	9381                	srli	a5,a5,0x20
    1a18:	97b2                	add	a5,a5,a2
    1a1a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a1e:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a22:	02f10323          	sb	a5,38(sp)
    1a26:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a28:	0ce86963          	bltu	a6,a4,1afa <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a2c:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a30:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a34:	1582                	slli	a1,a1,0x20
    1a36:	9181                	srli	a1,a1,0x20
    1a38:	95b2                	add	a1,a1,a2
    1a3a:	0005c583          	lbu	a1,0(a1)
    1a3e:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a42:	0007859b          	sext.w	a1,a5
    1a46:	16e6e563          	bltu	a3,a4,1bb0 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a4a:	02e7f6bb          	remuw	a3,a5,a4
    1a4e:	1682                	slli	a3,a3,0x20
    1a50:	9281                	srli	a3,a3,0x20
    1a52:	96b2                	add	a3,a3,a2
    1a54:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a58:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a5c:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a60:	16e5e163          	bltu	a1,a4,1bc2 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a64:	02e876bb          	remuw	a3,a6,a4
    1a68:	1682                	slli	a3,a3,0x20
    1a6a:	9281                	srli	a3,a3,0x20
    1a6c:	96b2                	add	a3,a3,a2
    1a6e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a72:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a76:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a7a:	14e86d63          	bltu	a6,a4,1bd4 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a7e:	02e5f6bb          	remuw	a3,a1,a4
    1a82:	1682                	slli	a3,a3,0x20
    1a84:	9281                	srli	a3,a3,0x20
    1a86:	96b2                	add	a3,a3,a2
    1a88:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a8c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a90:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a94:	10e5e563          	bltu	a1,a4,1b9e <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1a98:	02e876bb          	remuw	a3,a6,a4
    1a9c:	1682                	slli	a3,a3,0x20
    1a9e:	9281                	srli	a3,a3,0x20
    1aa0:	96b2                	add	a3,a3,a2
    1aa2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aa6:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1aaa:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1aae:	14e86263          	bltu	a6,a4,1bf2 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1ab2:	02e5f6bb          	remuw	a3,a1,a4
    1ab6:	1682                	slli	a3,a3,0x20
    1ab8:	9281                	srli	a3,a3,0x20
    1aba:	96b2                	add	a3,a3,a2
    1abc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ac0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ac4:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ac8:	14e5e463          	bltu	a1,a4,1c10 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1acc:	02e876bb          	remuw	a3,a6,a4
    1ad0:	1682                	slli	a3,a3,0x20
    1ad2:	9281                	srli	a3,a3,0x20
    1ad4:	96b2                	add	a3,a3,a2
    1ad6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ada:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ade:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1ae2:	14e86063          	bltu	a6,a4,1c22 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1ae6:	1782                	slli	a5,a5,0x20
    1ae8:	9381                	srli	a5,a5,0x20
    1aea:	97b2                	add	a5,a5,a2
    1aec:	0007c703          	lbu	a4,0(a5)
    1af0:	4799                	li	a5,6
    1af2:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1af6:	10054763          	bltz	a0,1c04 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1afa:	00001497          	auipc	s1,0x1
    1afe:	d2e48493          	addi	s1,s1,-722 # 2828 <buffer_len>
    1b02:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b06:	0828                	addi	a0,sp,24
    1b08:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b0a:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b0c:	00f50433          	add	s0,a0,a5
    1b10:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b12:	06e68463          	beq	a3,a4,1b7a <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b16:	8522                	mv	a0,s0
    1b18:	b15ff0ef          	jal	ra,162c <out_unlocked>
}
    1b1c:	60a6                	ld	ra,72(sp)
    1b1e:	6406                	ld	s0,64(sp)
    1b20:	74e2                	ld	s1,56(sp)
    1b22:	6161                	addi	sp,sp,80
    1b24:	8082                	ret
		x = -xx;
    1b26:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b2a:	02b877bb          	remuw	a5,a6,a1
    1b2e:	00001617          	auipc	a2,0x1
    1b32:	e0a60613          	addi	a2,a2,-502 # 2938 <digits>
	buf[16] = 0;
    1b36:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b3a:	0005871b          	sext.w	a4,a1
    1b3e:	1782                	slli	a5,a5,0x20
    1b40:	9381                	srli	a5,a5,0x20
    1b42:	97b2                	add	a5,a5,a2
    1b44:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b48:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b4c:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b50:	08b86b63          	bltu	a6,a1,1be6 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b54:	02e8f7bb          	remuw	a5,a7,a4
    1b58:	1782                	slli	a5,a5,0x20
    1b5a:	9381                	srli	a5,a5,0x20
    1b5c:	97b2                	add	a5,a5,a2
    1b5e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b62:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b66:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b6a:	ece8f1e3          	bgeu	a7,a4,1a2c <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b6e:	02d00793          	li	a5,45
    1b72:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b76:	47b5                	li	a5,13
    1b78:	b749                	j	1afa <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b7a:	10c4a503          	lw	a0,268(s1)
    1b7e:	e42e                	sd	a1,8(sp)
    1b80:	2c1000ef          	jal	ra,2640 <mutex_lock>
		len = out_unlocked(s, l);
    1b84:	65a2                	ld	a1,8(sp)
    1b86:	8522                	mv	a0,s0
    1b88:	aa5ff0ef          	jal	ra,162c <out_unlocked>
		mutex_unlock(buffer_lock);
    1b8c:	10c4a503          	lw	a0,268(s1)
    1b90:	2bd000ef          	jal	ra,264c <mutex_unlock>
}
    1b94:	60a6                	ld	ra,72(sp)
    1b96:	6406                	ld	s0,64(sp)
    1b98:	74e2                	ld	s1,56(sp)
    1b9a:	6161                	addi	sp,sp,80
    1b9c:	8082                	ret
		buf[i--] = digits[x % base];
    1b9e:	47a9                	li	a5,10
	if (sign)
    1ba0:	f4055de3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ba4:	02d00793          	li	a5,45
    1ba8:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bac:	47a5                	li	a5,9
    1bae:	b7b1                	j	1afa <printint.constprop.0+0x122>
    1bb0:	47b5                	li	a5,13
	if (sign)
    1bb2:	f40554e3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bb6:	02d00793          	li	a5,45
    1bba:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1bbe:	47b1                	li	a5,12
    1bc0:	bf2d                	j	1afa <printint.constprop.0+0x122>
    1bc2:	47b1                	li	a5,12
	if (sign)
    1bc4:	f2055be3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bc8:	02d00793          	li	a5,45
    1bcc:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bd0:	47ad                	li	a5,11
    1bd2:	b725                	j	1afa <printint.constprop.0+0x122>
    1bd4:	47ad                	li	a5,11
	if (sign)
    1bd6:	f20552e3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bda:	02d00793          	li	a5,45
    1bde:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1be2:	47a9                	li	a5,10
    1be4:	bf19                	j	1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be6:	02d00793          	li	a5,45
    1bea:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bee:	47b9                	li	a5,14
    1bf0:	b729                	j	1afa <printint.constprop.0+0x122>
    1bf2:	47a5                	li	a5,9
	if (sign)
    1bf4:	f00553e3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf8:	02d00793          	li	a5,45
    1bfc:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c00:	47a1                	li	a5,8
    1c02:	bde5                	j	1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c04:	02d00793          	li	a5,45
    1c08:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c0c:	4795                	li	a5,5
    1c0e:	b5f5                	j	1afa <printint.constprop.0+0x122>
    1c10:	47a1                	li	a5,8
	if (sign)
    1c12:	ee0554e3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c16:	02d00793          	li	a5,45
    1c1a:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c1e:	479d                	li	a5,7
    1c20:	bde9                	j	1afa <printint.constprop.0+0x122>
    1c22:	479d                	li	a5,7
	if (sign)
    1c24:	ec055be3          	bgez	a0,1afa <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c28:	02d00793          	li	a5,45
    1c2c:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c30:	4799                	li	a5,6
    1c32:	b5e1                	j	1afa <printint.constprop.0+0x122>

0000000000001c34 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c34:	02000793          	li	a5,32
    1c38:	00f50663          	beq	a0,a5,1c44 <isspace+0x10>
    1c3c:	355d                	addiw	a0,a0,-9
    1c3e:	00553513          	sltiu	a0,a0,5
    1c42:	8082                	ret
    1c44:	4505                	li	a0,1
}
    1c46:	8082                	ret

0000000000001c48 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c48:	fd05051b          	addiw	a0,a0,-48
}
    1c4c:	00a53513          	sltiu	a0,a0,10
    1c50:	8082                	ret

0000000000001c52 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c52:	02000613          	li	a2,32
    1c56:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c58:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c5c:	ff77869b          	addiw	a3,a5,-9
    1c60:	04c78c63          	beq	a5,a2,1cb8 <atoi+0x66>
    1c64:	0007871b          	sext.w	a4,a5
    1c68:	04d5f863          	bgeu	a1,a3,1cb8 <atoi+0x66>
		s++;
	switch (*s) {
    1c6c:	02b00693          	li	a3,43
    1c70:	04d78963          	beq	a5,a3,1cc2 <atoi+0x70>
    1c74:	02d00693          	li	a3,45
    1c78:	06d78263          	beq	a5,a3,1cdc <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c7c:	fd07061b          	addiw	a2,a4,-48
    1c80:	47a5                	li	a5,9
    1c82:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c84:	4e01                	li	t3,0
	while (isdigit(*s))
    1c86:	04c7e963          	bltu	a5,a2,1cd8 <atoi+0x86>
	int n = 0, neg = 0;
    1c8a:	4501                	li	a0,0
	while (isdigit(*s))
    1c8c:	4825                	li	a6,9
    1c8e:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c92:	0025179b          	slliw	a5,a0,0x2
    1c96:	9fa9                	addw	a5,a5,a0
    1c98:	fd07031b          	addiw	t1,a4,-48
    1c9c:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ca0:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ca4:	0685                	addi	a3,a3,1
    1ca6:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1caa:	0006071b          	sext.w	a4,a2
    1cae:	feb870e3          	bgeu	a6,a1,1c8e <atoi+0x3c>
	return neg ? n : -n;
    1cb2:	000e0563          	beqz	t3,1cbc <atoi+0x6a>
}
    1cb6:	8082                	ret
		s++;
    1cb8:	0505                	addi	a0,a0,1
    1cba:	bf79                	j	1c58 <atoi+0x6>
	return neg ? n : -n;
    1cbc:	4113053b          	subw	a0,t1,a7
    1cc0:	8082                	ret
	while (isdigit(*s))
    1cc2:	00154703          	lbu	a4,1(a0)
    1cc6:	47a5                	li	a5,9
		s++;
    1cc8:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ccc:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cd0:	4e01                	li	t3,0
	while (isdigit(*s))
    1cd2:	2701                	sext.w	a4,a4
    1cd4:	fac7fbe3          	bgeu	a5,a2,1c8a <atoi+0x38>
    1cd8:	4501                	li	a0,0
}
    1cda:	8082                	ret
	while (isdigit(*s))
    1cdc:	00154703          	lbu	a4,1(a0)
    1ce0:	47a5                	li	a5,9
		s++;
    1ce2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ce6:	fd07061b          	addiw	a2,a4,-48
    1cea:	2701                	sext.w	a4,a4
    1cec:	fec7e6e3          	bltu	a5,a2,1cd8 <atoi+0x86>
		neg = 1;
    1cf0:	4e05                	li	t3,1
    1cf2:	bf61                	j	1c8a <atoi+0x38>

0000000000001cf4 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cf4:	16060d63          	beqz	a2,1e6e <memset+0x17a>
    1cf8:	40a007b3          	neg	a5,a0
    1cfc:	8b9d                	andi	a5,a5,7
    1cfe:	00778693          	addi	a3,a5,7
    1d02:	482d                	li	a6,11
    1d04:	0ff5f713          	zext.b	a4,a1
    1d08:	fff60593          	addi	a1,a2,-1
    1d0c:	1706e263          	bltu	a3,a6,1e70 <memset+0x17c>
    1d10:	16d5ea63          	bltu	a1,a3,1e84 <memset+0x190>
    1d14:	16078563          	beqz	a5,1e7e <memset+0x18a>
    1d18:	00e50023          	sb	a4,0(a0)
    1d1c:	4685                	li	a3,1
    1d1e:	00150593          	addi	a1,a0,1
    1d22:	14d78c63          	beq	a5,a3,1e7a <memset+0x186>
    1d26:	00e500a3          	sb	a4,1(a0)
    1d2a:	4689                	li	a3,2
    1d2c:	00250593          	addi	a1,a0,2
    1d30:	14d78d63          	beq	a5,a3,1e8a <memset+0x196>
    1d34:	00e50123          	sb	a4,2(a0)
    1d38:	468d                	li	a3,3
    1d3a:	00350593          	addi	a1,a0,3
    1d3e:	12d78b63          	beq	a5,a3,1e74 <memset+0x180>
    1d42:	00e501a3          	sb	a4,3(a0)
    1d46:	4691                	li	a3,4
    1d48:	00450593          	addi	a1,a0,4
    1d4c:	14d78163          	beq	a5,a3,1e8e <memset+0x19a>
    1d50:	00e50223          	sb	a4,4(a0)
    1d54:	4695                	li	a3,5
    1d56:	00550593          	addi	a1,a0,5
    1d5a:	12d78c63          	beq	a5,a3,1e92 <memset+0x19e>
    1d5e:	00e502a3          	sb	a4,5(a0)
    1d62:	469d                	li	a3,7
    1d64:	00650593          	addi	a1,a0,6
    1d68:	12d79763          	bne	a5,a3,1e96 <memset+0x1a2>
    1d6c:	00750593          	addi	a1,a0,7
    1d70:	00e50323          	sb	a4,6(a0)
    1d74:	481d                	li	a6,7
    1d76:	00871693          	slli	a3,a4,0x8
    1d7a:	01071893          	slli	a7,a4,0x10
    1d7e:	8ed9                	or	a3,a3,a4
    1d80:	01871313          	slli	t1,a4,0x18
    1d84:	0116e6b3          	or	a3,a3,a7
    1d88:	0066e6b3          	or	a3,a3,t1
    1d8c:	02071893          	slli	a7,a4,0x20
    1d90:	02871e13          	slli	t3,a4,0x28
    1d94:	0116e6b3          	or	a3,a3,a7
    1d98:	40f60333          	sub	t1,a2,a5
    1d9c:	03071893          	slli	a7,a4,0x30
    1da0:	01c6e6b3          	or	a3,a3,t3
    1da4:	0116e6b3          	or	a3,a3,a7
    1da8:	03871e13          	slli	t3,a4,0x38
    1dac:	97aa                	add	a5,a5,a0
    1dae:	ff837893          	andi	a7,t1,-8
    1db2:	01c6e6b3          	or	a3,a3,t3
    1db6:	98be                	add	a7,a7,a5
    1db8:	e394                	sd	a3,0(a5)
    1dba:	07a1                	addi	a5,a5,8
    1dbc:	ff179ee3          	bne	a5,a7,1db8 <memset+0xc4>
    1dc0:	ff837893          	andi	a7,t1,-8
    1dc4:	011587b3          	add	a5,a1,a7
    1dc8:	010886bb          	addw	a3,a7,a6
    1dcc:	0b130663          	beq	t1,a7,1e78 <memset+0x184>
    1dd0:	00e78023          	sb	a4,0(a5)
    1dd4:	0016859b          	addiw	a1,a3,1
    1dd8:	08c5fb63          	bgeu	a1,a2,1e6e <memset+0x17a>
    1ddc:	00e780a3          	sb	a4,1(a5)
    1de0:	0026859b          	addiw	a1,a3,2
    1de4:	08c5f563          	bgeu	a1,a2,1e6e <memset+0x17a>
    1de8:	00e78123          	sb	a4,2(a5)
    1dec:	0036859b          	addiw	a1,a3,3
    1df0:	06c5ff63          	bgeu	a1,a2,1e6e <memset+0x17a>
    1df4:	00e781a3          	sb	a4,3(a5)
    1df8:	0046859b          	addiw	a1,a3,4
    1dfc:	06c5f963          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e00:	00e78223          	sb	a4,4(a5)
    1e04:	0056859b          	addiw	a1,a3,5
    1e08:	06c5f363          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e0c:	00e782a3          	sb	a4,5(a5)
    1e10:	0066859b          	addiw	a1,a3,6
    1e14:	04c5fd63          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e18:	00e78323          	sb	a4,6(a5)
    1e1c:	0076859b          	addiw	a1,a3,7
    1e20:	04c5f763          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e24:	00e783a3          	sb	a4,7(a5)
    1e28:	0086859b          	addiw	a1,a3,8
    1e2c:	04c5f163          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e30:	00e78423          	sb	a4,8(a5)
    1e34:	0096859b          	addiw	a1,a3,9
    1e38:	02c5fb63          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e3c:	00e784a3          	sb	a4,9(a5)
    1e40:	00a6859b          	addiw	a1,a3,10
    1e44:	02c5f563          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e48:	00e78523          	sb	a4,10(a5)
    1e4c:	00b6859b          	addiw	a1,a3,11
    1e50:	00c5ff63          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e54:	00e785a3          	sb	a4,11(a5)
    1e58:	00c6859b          	addiw	a1,a3,12
    1e5c:	00c5f963          	bgeu	a1,a2,1e6e <memset+0x17a>
    1e60:	00e78623          	sb	a4,12(a5)
    1e64:	26b5                	addiw	a3,a3,13
    1e66:	00c6f463          	bgeu	a3,a2,1e6e <memset+0x17a>
    1e6a:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e6e:	8082                	ret
    1e70:	46ad                	li	a3,11
    1e72:	bd79                	j	1d10 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e74:	480d                	li	a6,3
    1e76:	b701                	j	1d76 <memset+0x82>
    1e78:	8082                	ret
    1e7a:	4805                	li	a6,1
    1e7c:	bded                	j	1d76 <memset+0x82>
    1e7e:	85aa                	mv	a1,a0
    1e80:	4801                	li	a6,0
    1e82:	bdd5                	j	1d76 <memset+0x82>
    1e84:	87aa                	mv	a5,a0
    1e86:	4681                	li	a3,0
    1e88:	b7a1                	j	1dd0 <memset+0xdc>
    1e8a:	4809                	li	a6,2
    1e8c:	b5ed                	j	1d76 <memset+0x82>
    1e8e:	4811                	li	a6,4
    1e90:	b5dd                	j	1d76 <memset+0x82>
    1e92:	4815                	li	a6,5
    1e94:	b5cd                	j	1d76 <memset+0x82>
    1e96:	4819                	li	a6,6
    1e98:	bdf9                	j	1d76 <memset+0x82>

0000000000001e9a <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1e9a:	00054783          	lbu	a5,0(a0)
    1e9e:	0005c703          	lbu	a4,0(a1)
    1ea2:	00e79863          	bne	a5,a4,1eb2 <strcmp+0x18>
    1ea6:	0505                	addi	a0,a0,1
    1ea8:	0585                	addi	a1,a1,1
    1eaa:	fbe5                	bnez	a5,1e9a <strcmp>
    1eac:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1eae:	9d19                	subw	a0,a0,a4
    1eb0:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1eb2:	0007851b          	sext.w	a0,a5
    1eb6:	bfe5                	j	1eae <strcmp+0x14>

0000000000001eb8 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1eb8:	ca15                	beqz	a2,1eec <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1eba:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ebe:	167d                	addi	a2,a2,-1
    1ec0:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ec4:	eb99                	bnez	a5,1eda <strncmp+0x22>
    1ec6:	a815                	j	1efa <strncmp+0x42>
    1ec8:	00a68e63          	beq	a3,a0,1ee4 <strncmp+0x2c>
    1ecc:	0505                	addi	a0,a0,1
    1ece:	00f71b63          	bne	a4,a5,1ee4 <strncmp+0x2c>
    1ed2:	00054783          	lbu	a5,0(a0)
    1ed6:	cf89                	beqz	a5,1ef0 <strncmp+0x38>
    1ed8:	85b2                	mv	a1,a2
    1eda:	0005c703          	lbu	a4,0(a1)
    1ede:	00158613          	addi	a2,a1,1
    1ee2:	f37d                	bnez	a4,1ec8 <strncmp+0x10>
		;
	return *l - *r;
    1ee4:	0007851b          	sext.w	a0,a5
    1ee8:	9d19                	subw	a0,a0,a4
    1eea:	8082                	ret
		return 0;
    1eec:	4501                	li	a0,0
}
    1eee:	8082                	ret
	return *l - *r;
    1ef0:	0015c703          	lbu	a4,1(a1)
    1ef4:	4501                	li	a0,0
    1ef6:	9d19                	subw	a0,a0,a4
    1ef8:	8082                	ret
    1efa:	0005c703          	lbu	a4,0(a1)
    1efe:	4501                	li	a0,0
    1f00:	b7e5                	j	1ee8 <strncmp+0x30>

0000000000001f02 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f02:	00757793          	andi	a5,a0,7
    1f06:	cf89                	beqz	a5,1f20 <strlen+0x1e>
    1f08:	87aa                	mv	a5,a0
    1f0a:	a029                	j	1f14 <strlen+0x12>
    1f0c:	0785                	addi	a5,a5,1
    1f0e:	0077f713          	andi	a4,a5,7
    1f12:	cb01                	beqz	a4,1f22 <strlen+0x20>
		if (!*s)
    1f14:	0007c703          	lbu	a4,0(a5)
    1f18:	fb75                	bnez	a4,1f0c <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f1a:	40a78533          	sub	a0,a5,a0
}
    1f1e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f20:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f22:	6394                	ld	a3,0(a5)
    1f24:	00001597          	auipc	a1,0x1
    1f28:	8ec5b583          	ld	a1,-1812(a1) # 2810 <enable_deadlock_detect+0x170>
    1f2c:	00001617          	auipc	a2,0x1
    1f30:	8ec63603          	ld	a2,-1812(a2) # 2818 <enable_deadlock_detect+0x178>
    1f34:	a019                	j	1f3a <strlen+0x38>
    1f36:	6794                	ld	a3,8(a5)
    1f38:	07a1                	addi	a5,a5,8
    1f3a:	00b68733          	add	a4,a3,a1
    1f3e:	fff6c693          	not	a3,a3
    1f42:	8f75                	and	a4,a4,a3
    1f44:	8f71                	and	a4,a4,a2
    1f46:	db65                	beqz	a4,1f36 <strlen+0x34>
	for (; *s; s++)
    1f48:	0007c703          	lbu	a4,0(a5)
    1f4c:	d779                	beqz	a4,1f1a <strlen+0x18>
    1f4e:	0017c703          	lbu	a4,1(a5)
    1f52:	0785                	addi	a5,a5,1
    1f54:	d379                	beqz	a4,1f1a <strlen+0x18>
    1f56:	0017c703          	lbu	a4,1(a5)
    1f5a:	0785                	addi	a5,a5,1
    1f5c:	fb6d                	bnez	a4,1f4e <strlen+0x4c>
    1f5e:	bf75                	j	1f1a <strlen+0x18>

0000000000001f60 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f60:	00757713          	andi	a4,a0,7
{
    1f64:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f66:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f6a:	cb19                	beqz	a4,1f80 <memchr+0x20>
    1f6c:	ce25                	beqz	a2,1fe4 <memchr+0x84>
    1f6e:	0007c703          	lbu	a4,0(a5)
    1f72:	04b70e63          	beq	a4,a1,1fce <memchr+0x6e>
    1f76:	0785                	addi	a5,a5,1
    1f78:	0077f713          	andi	a4,a5,7
    1f7c:	167d                	addi	a2,a2,-1
    1f7e:	f77d                	bnez	a4,1f6c <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f80:	4501                	li	a0,0
	if (n && *s != c) {
    1f82:	c235                	beqz	a2,1fe6 <memchr+0x86>
    1f84:	0007c703          	lbu	a4,0(a5)
    1f88:	04b70363          	beq	a4,a1,1fce <memchr+0x6e>
		size_t k = ONES * c;
    1f8c:	00001517          	auipc	a0,0x1
    1f90:	89453503          	ld	a0,-1900(a0) # 2820 <enable_deadlock_detect+0x180>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f94:	471d                	li	a4,7
		size_t k = ONES * c;
    1f96:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f9a:	02c77a63          	bgeu	a4,a2,1fce <memchr+0x6e>
    1f9e:	00001897          	auipc	a7,0x1
    1fa2:	8728b883          	ld	a7,-1934(a7) # 2810 <enable_deadlock_detect+0x170>
    1fa6:	00001817          	auipc	a6,0x1
    1faa:	87283803          	ld	a6,-1934(a6) # 2818 <enable_deadlock_detect+0x178>
    1fae:	431d                	li	t1,7
    1fb0:	a029                	j	1fba <memchr+0x5a>
		     w++, n -= SS)
    1fb2:	1661                	addi	a2,a2,-8
    1fb4:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fb6:	02c37963          	bgeu	t1,a2,1fe8 <memchr+0x88>
    1fba:	6398                	ld	a4,0(a5)
    1fbc:	8f29                	xor	a4,a4,a0
    1fbe:	011706b3          	add	a3,a4,a7
    1fc2:	fff74713          	not	a4,a4
    1fc6:	8f75                	and	a4,a4,a3
    1fc8:	01077733          	and	a4,a4,a6
    1fcc:	d37d                	beqz	a4,1fb2 <memchr+0x52>
{
    1fce:	853e                	mv	a0,a5
    1fd0:	97b2                	add	a5,a5,a2
    1fd2:	a021                	j	1fda <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fd4:	0505                	addi	a0,a0,1
    1fd6:	00f50763          	beq	a0,a5,1fe4 <memchr+0x84>
    1fda:	00054703          	lbu	a4,0(a0)
    1fde:	feb71be3          	bne	a4,a1,1fd4 <memchr+0x74>
    1fe2:	8082                	ret
	return n ? (void *)s : 0;
    1fe4:	4501                	li	a0,0
}
    1fe6:	8082                	ret
	return n ? (void *)s : 0;
    1fe8:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1fea:	f275                	bnez	a2,1fce <memchr+0x6e>
}
    1fec:	8082                	ret

0000000000001fee <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1fee:	1101                	addi	sp,sp,-32
    1ff0:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1ff2:	862e                	mv	a2,a1
{
    1ff4:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    1ff6:	4581                	li	a1,0
{
    1ff8:	e426                	sd	s1,8(sp)
    1ffa:	ec06                	sd	ra,24(sp)
    1ffc:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    1ffe:	f63ff0ef          	jal	ra,1f60 <memchr>
	return p ? p - s : n;
    2002:	c519                	beqz	a0,2010 <strnlen+0x22>
}
    2004:	60e2                	ld	ra,24(sp)
    2006:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2008:	8d05                	sub	a0,a0,s1
}
    200a:	64a2                	ld	s1,8(sp)
    200c:	6105                	addi	sp,sp,32
    200e:	8082                	ret
    2010:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2012:	8522                	mv	a0,s0
}
    2014:	6442                	ld	s0,16(sp)
    2016:	64a2                	ld	s1,8(sp)
    2018:	6105                	addi	sp,sp,32
    201a:	8082                	ret

000000000000201c <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    201c:	00a5c7b3          	xor	a5,a1,a0
    2020:	8b9d                	andi	a5,a5,7
    2022:	eb95                	bnez	a5,2056 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2024:	0075f793          	andi	a5,a1,7
    2028:	e7b1                	bnez	a5,2074 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    202a:	6198                	ld	a4,0(a1)
    202c:	00000617          	auipc	a2,0x0
    2030:	7e463603          	ld	a2,2020(a2) # 2810 <enable_deadlock_detect+0x170>
    2034:	00000817          	auipc	a6,0x0
    2038:	7e483803          	ld	a6,2020(a6) # 2818 <enable_deadlock_detect+0x178>
    203c:	a029                	j	2046 <stpcpy+0x2a>
    203e:	05a1                	addi	a1,a1,8
    2040:	e118                	sd	a4,0(a0)
    2042:	6198                	ld	a4,0(a1)
    2044:	0521                	addi	a0,a0,8
    2046:	00c707b3          	add	a5,a4,a2
    204a:	fff74693          	not	a3,a4
    204e:	8ff5                	and	a5,a5,a3
    2050:	0107f7b3          	and	a5,a5,a6
    2054:	d7ed                	beqz	a5,203e <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2056:	0005c783          	lbu	a5,0(a1)
    205a:	00f50023          	sb	a5,0(a0)
    205e:	c785                	beqz	a5,2086 <stpcpy+0x6a>
    2060:	0015c783          	lbu	a5,1(a1)
    2064:	0505                	addi	a0,a0,1
    2066:	0585                	addi	a1,a1,1
    2068:	00f50023          	sb	a5,0(a0)
    206c:	fbf5                	bnez	a5,2060 <stpcpy+0x44>
		;
	return d;
}
    206e:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2070:	0505                	addi	a0,a0,1
    2072:	df45                	beqz	a4,202a <stpcpy+0xe>
			if (!(*d = *s))
    2074:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2078:	0585                	addi	a1,a1,1
    207a:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    207e:	00f50023          	sb	a5,0(a0)
    2082:	f7fd                	bnez	a5,2070 <stpcpy+0x54>
}
    2084:	8082                	ret
    2086:	8082                	ret

0000000000002088 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2088:	00a5c7b3          	xor	a5,a1,a0
    208c:	8b9d                	andi	a5,a5,7
    208e:	1a079863          	bnez	a5,223e <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2092:	0075f793          	andi	a5,a1,7
    2096:	16078463          	beqz	a5,21fe <stpncpy+0x176>
    209a:	ea01                	bnez	a2,20aa <stpncpy+0x22>
    209c:	a421                	j	22a4 <stpncpy+0x21c>
    209e:	167d                	addi	a2,a2,-1
    20a0:	0505                	addi	a0,a0,1
    20a2:	14070e63          	beqz	a4,21fe <stpncpy+0x176>
    20a6:	1a060863          	beqz	a2,2256 <stpncpy+0x1ce>
    20aa:	0005c783          	lbu	a5,0(a1)
    20ae:	0585                	addi	a1,a1,1
    20b0:	0075f713          	andi	a4,a1,7
    20b4:	00f50023          	sb	a5,0(a0)
    20b8:	f3fd                	bnez	a5,209e <stpncpy+0x16>
    20ba:	4805                	li	a6,1
    20bc:	1a061863          	bnez	a2,226c <stpncpy+0x1e4>
    20c0:	40a007b3          	neg	a5,a0
    20c4:	8b9d                	andi	a5,a5,7
    20c6:	4681                	li	a3,0
    20c8:	18061a63          	bnez	a2,225c <stpncpy+0x1d4>
    20cc:	00778713          	addi	a4,a5,7
    20d0:	45ad                	li	a1,11
    20d2:	18b76363          	bltu	a4,a1,2258 <stpncpy+0x1d0>
    20d6:	1ae6eb63          	bltu	a3,a4,228c <stpncpy+0x204>
    20da:	1a078363          	beqz	a5,2280 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20de:	00050023          	sb	zero,0(a0)
    20e2:	4685                	li	a3,1
    20e4:	00150713          	addi	a4,a0,1
    20e8:	18d78f63          	beq	a5,a3,2286 <stpncpy+0x1fe>
    20ec:	000500a3          	sb	zero,1(a0)
    20f0:	4689                	li	a3,2
    20f2:	00250713          	addi	a4,a0,2
    20f6:	18d78e63          	beq	a5,a3,2292 <stpncpy+0x20a>
    20fa:	00050123          	sb	zero,2(a0)
    20fe:	468d                	li	a3,3
    2100:	00350713          	addi	a4,a0,3
    2104:	16d78c63          	beq	a5,a3,227c <stpncpy+0x1f4>
    2108:	000501a3          	sb	zero,3(a0)
    210c:	4691                	li	a3,4
    210e:	00450713          	addi	a4,a0,4
    2112:	18d78263          	beq	a5,a3,2296 <stpncpy+0x20e>
    2116:	00050223          	sb	zero,4(a0)
    211a:	4695                	li	a3,5
    211c:	00550713          	addi	a4,a0,5
    2120:	16d78d63          	beq	a5,a3,229a <stpncpy+0x212>
    2124:	000502a3          	sb	zero,5(a0)
    2128:	469d                	li	a3,7
    212a:	00650713          	addi	a4,a0,6
    212e:	16d79863          	bne	a5,a3,229e <stpncpy+0x216>
    2132:	00750713          	addi	a4,a0,7
    2136:	00050323          	sb	zero,6(a0)
    213a:	40f80833          	sub	a6,a6,a5
    213e:	ff887593          	andi	a1,a6,-8
    2142:	97aa                	add	a5,a5,a0
    2144:	95be                	add	a1,a1,a5
    2146:	0007b023          	sd	zero,0(a5)
    214a:	07a1                	addi	a5,a5,8
    214c:	feb79de3          	bne	a5,a1,2146 <stpncpy+0xbe>
    2150:	ff887593          	andi	a1,a6,-8
    2154:	9ead                	addw	a3,a3,a1
    2156:	00b707b3          	add	a5,a4,a1
    215a:	12b80863          	beq	a6,a1,228a <stpncpy+0x202>
    215e:	00078023          	sb	zero,0(a5)
    2162:	0016871b          	addiw	a4,a3,1
    2166:	0ec77863          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    216a:	000780a3          	sb	zero,1(a5)
    216e:	0026871b          	addiw	a4,a3,2
    2172:	0ec77263          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    2176:	00078123          	sb	zero,2(a5)
    217a:	0036871b          	addiw	a4,a3,3
    217e:	0cc77c63          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    2182:	000781a3          	sb	zero,3(a5)
    2186:	0046871b          	addiw	a4,a3,4
    218a:	0cc77663          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    218e:	00078223          	sb	zero,4(a5)
    2192:	0056871b          	addiw	a4,a3,5
    2196:	0cc77063          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    219a:	000782a3          	sb	zero,5(a5)
    219e:	0066871b          	addiw	a4,a3,6
    21a2:	0ac77a63          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21a6:	00078323          	sb	zero,6(a5)
    21aa:	0076871b          	addiw	a4,a3,7
    21ae:	0ac77463          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21b2:	000783a3          	sb	zero,7(a5)
    21b6:	0086871b          	addiw	a4,a3,8
    21ba:	08c77e63          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21be:	00078423          	sb	zero,8(a5)
    21c2:	0096871b          	addiw	a4,a3,9
    21c6:	08c77863          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21ca:	000784a3          	sb	zero,9(a5)
    21ce:	00a6871b          	addiw	a4,a3,10
    21d2:	08c77263          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21d6:	00078523          	sb	zero,10(a5)
    21da:	00b6871b          	addiw	a4,a3,11
    21de:	06c77c63          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21e2:	000785a3          	sb	zero,11(a5)
    21e6:	00c6871b          	addiw	a4,a3,12
    21ea:	06c77663          	bgeu	a4,a2,2256 <stpncpy+0x1ce>
    21ee:	00078623          	sb	zero,12(a5)
    21f2:	26b5                	addiw	a3,a3,13
    21f4:	06c6f163          	bgeu	a3,a2,2256 <stpncpy+0x1ce>
    21f8:	000786a3          	sb	zero,13(a5)
    21fc:	8082                	ret
			;
		if (!n || !*s)
    21fe:	c645                	beqz	a2,22a6 <stpncpy+0x21e>
    2200:	0005c783          	lbu	a5,0(a1)
    2204:	ea078be3          	beqz	a5,20ba <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2208:	479d                	li	a5,7
    220a:	02c7ff63          	bgeu	a5,a2,2248 <stpncpy+0x1c0>
    220e:	00000897          	auipc	a7,0x0
    2212:	6028b883          	ld	a7,1538(a7) # 2810 <enable_deadlock_detect+0x170>
    2216:	00000817          	auipc	a6,0x0
    221a:	60283803          	ld	a6,1538(a6) # 2818 <enable_deadlock_detect+0x178>
    221e:	431d                	li	t1,7
    2220:	6198                	ld	a4,0(a1)
    2222:	011707b3          	add	a5,a4,a7
    2226:	fff74693          	not	a3,a4
    222a:	8ff5                	and	a5,a5,a3
    222c:	0107f7b3          	and	a5,a5,a6
    2230:	ef81                	bnez	a5,2248 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2232:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2234:	1661                	addi	a2,a2,-8
    2236:	05a1                	addi	a1,a1,8
    2238:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    223a:	fec363e3          	bltu	t1,a2,2220 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    223e:	e609                	bnez	a2,2248 <stpncpy+0x1c0>
    2240:	a08d                	j	22a2 <stpncpy+0x21a>
    2242:	167d                	addi	a2,a2,-1
    2244:	0505                	addi	a0,a0,1
    2246:	ca01                	beqz	a2,2256 <stpncpy+0x1ce>
    2248:	0005c783          	lbu	a5,0(a1)
    224c:	0585                	addi	a1,a1,1
    224e:	00f50023          	sb	a5,0(a0)
    2252:	fbe5                	bnez	a5,2242 <stpncpy+0x1ba>
		;
tail:
    2254:	b59d                	j	20ba <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2256:	8082                	ret
    2258:	472d                	li	a4,11
    225a:	bdb5                	j	20d6 <stpncpy+0x4e>
    225c:	00778713          	addi	a4,a5,7
    2260:	45ad                	li	a1,11
    2262:	fff60693          	addi	a3,a2,-1
    2266:	e6b778e3          	bgeu	a4,a1,20d6 <stpncpy+0x4e>
    226a:	b7fd                	j	2258 <stpncpy+0x1d0>
    226c:	40a007b3          	neg	a5,a0
    2270:	8832                	mv	a6,a2
    2272:	8b9d                	andi	a5,a5,7
    2274:	4681                	li	a3,0
    2276:	e4060be3          	beqz	a2,20cc <stpncpy+0x44>
    227a:	b7cd                	j	225c <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    227c:	468d                	li	a3,3
    227e:	bd75                	j	213a <stpncpy+0xb2>
    2280:	872a                	mv	a4,a0
    2282:	4681                	li	a3,0
    2284:	bd5d                	j	213a <stpncpy+0xb2>
    2286:	4685                	li	a3,1
    2288:	bd4d                	j	213a <stpncpy+0xb2>
    228a:	8082                	ret
    228c:	87aa                	mv	a5,a0
    228e:	4681                	li	a3,0
    2290:	b5f9                	j	215e <stpncpy+0xd6>
    2292:	4689                	li	a3,2
    2294:	b55d                	j	213a <stpncpy+0xb2>
    2296:	4691                	li	a3,4
    2298:	b54d                	j	213a <stpncpy+0xb2>
    229a:	4695                	li	a3,5
    229c:	bd79                	j	213a <stpncpy+0xb2>
    229e:	4699                	li	a3,6
    22a0:	bd69                	j	213a <stpncpy+0xb2>
    22a2:	8082                	ret
    22a4:	8082                	ret
    22a6:	8082                	ret

00000000000022a8 <basename>:

char *basename(char *s)
{
    22a8:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22aa:	c54d                	beqz	a0,2354 <basename+0xac>
    22ac:	00054783          	lbu	a5,0(a0)
		return ".";
    22b0:	00000517          	auipc	a0,0x0
    22b4:	55850513          	addi	a0,a0,1368 # 2808 <enable_deadlock_detect+0x168>
	if (!s || !*s)
    22b8:	e391                	bnez	a5,22bc <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22ba:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22bc:	0076f713          	andi	a4,a3,7
    22c0:	87b6                	mv	a5,a3
    22c2:	cf51                	beqz	a4,235e <basename+0xb6>
    22c4:	0785                	addi	a5,a5,1
    22c6:	0077f713          	andi	a4,a5,7
    22ca:	c729                	beqz	a4,2314 <basename+0x6c>
		if (!*s)
    22cc:	0007c703          	lbu	a4,0(a5)
    22d0:	fb75                	bnez	a4,22c4 <basename+0x1c>
	return s - a;
    22d2:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22d4:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22d6:	cf8d                	beqz	a5,2310 <basename+0x68>
    22d8:	00f68733          	add	a4,a3,a5
    22dc:	02f00593          	li	a1,47
    22e0:	a031                	j	22ec <basename+0x44>
		s[i] = 0;
    22e2:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22e6:	17fd                	addi	a5,a5,-1
    22e8:	177d                	addi	a4,a4,-1
    22ea:	c39d                	beqz	a5,2310 <basename+0x68>
    22ec:	00074603          	lbu	a2,0(a4)
    22f0:	feb609e3          	beq	a2,a1,22e2 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22f4:	02f00613          	li	a2,47
    22f8:	a011                	j	22fc <basename+0x54>
    22fa:	cb99                	beqz	a5,2310 <basename+0x68>
    22fc:	853e                	mv	a0,a5
    22fe:	17fd                	addi	a5,a5,-1
    2300:	00f68733          	add	a4,a3,a5
    2304:	00074703          	lbu	a4,0(a4)
    2308:	fec719e3          	bne	a4,a2,22fa <basename+0x52>
	return s + i;
    230c:	9536                	add	a0,a0,a3
    230e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2310:	8536                	mv	a0,a3
    2312:	8082                	ret
    2314:	6390                	ld	a2,0(a5)
    2316:	00000517          	auipc	a0,0x0
    231a:	4fa53503          	ld	a0,1274(a0) # 2810 <enable_deadlock_detect+0x170>
    231e:	00000597          	auipc	a1,0x0
    2322:	4fa5b583          	ld	a1,1274(a1) # 2818 <enable_deadlock_detect+0x178>
    2326:	fff64713          	not	a4,a2
    232a:	962a                	add	a2,a2,a0
    232c:	8f71                	and	a4,a4,a2
    232e:	8f6d                	and	a4,a4,a1
    2330:	eb11                	bnez	a4,2344 <basename+0x9c>
    2332:	6790                	ld	a2,8(a5)
    2334:	07a1                	addi	a5,a5,8
    2336:	00a60733          	add	a4,a2,a0
    233a:	fff64613          	not	a2,a2
    233e:	8f71                	and	a4,a4,a2
    2340:	8f6d                	and	a4,a4,a1
    2342:	db65                	beqz	a4,2332 <basename+0x8a>
	for (; *s; s++)
    2344:	0007c703          	lbu	a4,0(a5)
    2348:	d749                	beqz	a4,22d2 <basename+0x2a>
    234a:	0017c703          	lbu	a4,1(a5)
    234e:	0785                	addi	a5,a5,1
    2350:	ff6d                	bnez	a4,234a <basename+0xa2>
    2352:	b741                	j	22d2 <basename+0x2a>
		return ".";
    2354:	00000517          	auipc	a0,0x0
    2358:	4b450513          	addi	a0,a0,1204 # 2808 <enable_deadlock_detect+0x168>
    235c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    235e:	6290                	ld	a2,0(a3)
    2360:	00000517          	auipc	a0,0x0
    2364:	4b053503          	ld	a0,1200(a0) # 2810 <enable_deadlock_detect+0x170>
    2368:	00000597          	auipc	a1,0x0
    236c:	4b05b583          	ld	a1,1200(a1) # 2818 <enable_deadlock_detect+0x178>
    2370:	fff64713          	not	a4,a2
    2374:	962a                	add	a2,a2,a0
    2376:	8f71                	and	a4,a4,a2
    2378:	8f6d                	and	a4,a4,a1
    237a:	df45                	beqz	a4,2332 <basename+0x8a>
    237c:	b7f9                	j	234a <basename+0xa2>

000000000000237e <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    237e:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2382:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2384:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2388:	2501                	sext.w	a0,a0
    238a:	8082                	ret

000000000000238c <close>:

int close(int fd)
{
	if (fd == 1) {
    238c:	4785                	li	a5,1
    238e:	00f50863          	beq	a0,a5,239e <close+0x12>
	register long a7 __asm__("a7") = n;
    2392:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2396:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    239a:	2501                	sext.w	a0,a0
    239c:	8082                	ret
{
    239e:	1101                	addi	sp,sp,-32
    23a0:	ec06                	sd	ra,24(sp)
    23a2:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23a4:	cdffe0ef          	jal	ra,1082 <__write_buffer>
		__clear_buffer();
    23a8:	d03fe0ef          	jal	ra,10aa <__clear_buffer>
    23ac:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23ae:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23b2:	00000073          	ecall
}
    23b6:	60e2                	ld	ra,24(sp)
    23b8:	2501                	sext.w	a0,a0
    23ba:	6105                	addi	sp,sp,32
    23bc:	8082                	ret

00000000000023be <read>:
	register long a7 __asm__("a7") = n;
    23be:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23c2:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23c6:	8082                	ret

00000000000023c8 <write>:
	register long a7 __asm__("a7") = n;
    23c8:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23cc:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23d0:	8082                	ret

00000000000023d2 <getpid>:
	register long a7 __asm__("a7") = n;
    23d2:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23d6:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23da:	2501                	sext.w	a0,a0
    23dc:	8082                	ret

00000000000023de <getppid>:
	register long a7 __asm__("a7") = n;
    23de:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23e2:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23e6:	2501                	sext.w	a0,a0
    23e8:	8082                	ret

00000000000023ea <sched_yield>:
	register long a7 __asm__("a7") = n;
    23ea:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23ee:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23f2:	2501                	sext.w	a0,a0
    23f4:	8082                	ret

00000000000023f6 <fork>:
	register long a7 __asm__("a7") = n;
    23f6:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    23fa:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    23fe:	2501                	sext.w	a0,a0
    2400:	8082                	ret

0000000000002402 <exit>:

void exit(int code)
{
    2402:	1141                	addi	sp,sp,-16
    2404:	e406                	sd	ra,8(sp)
    2406:	e022                	sd	s0,0(sp)
    2408:	842a                	mv	s0,a0
	__write_buffer();
    240a:	c79fe0ef          	jal	ra,1082 <__write_buffer>
	__clear_buffer();
    240e:	c9dfe0ef          	jal	ra,10aa <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2412:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2416:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2418:	00000073          	ecall
	syscall(SYS_exit, code);
}
    241c:	60a2                	ld	ra,8(sp)
    241e:	6402                	ld	s0,0(sp)
    2420:	0141                	addi	sp,sp,16
    2422:	8082                	ret

0000000000002424 <waitpid>:
	register long a7 __asm__("a7") = n;
    2424:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2428:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    242c:	2501                	sext.w	a0,a0
    242e:	8082                	ret

0000000000002430 <exec>:
	register long a7 __asm__("a7") = n;
    2430:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2434:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2438:	2501                	sext.w	a0,a0
    243a:	8082                	ret

000000000000243c <get_mtime>:

int64 get_mtime()
{
    243c:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    243e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2442:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2444:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2446:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    244a:	2501                	sext.w	a0,a0
    244c:	ed01                	bnez	a0,2464 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    244e:	6722                	ld	a4,8(sp)
    2450:	3e800793          	li	a5,1000
    2454:	6682                	ld	a3,0(sp)
    2456:	02f75733          	divu	a4,a4,a5
    245a:	02d78533          	mul	a0,a5,a3
    245e:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2460:	0141                	addi	sp,sp,16
    2462:	8082                	ret
	return -1;
    2464:	557d                	li	a0,-1
    2466:	bfed                	j	2460 <get_mtime+0x24>

0000000000002468 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2468:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    246c:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2470:	2501                	sext.w	a0,a0
    2472:	8082                	ret

0000000000002474 <sleep>:

int sleep(unsigned long long time)
{
    2474:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2476:	880a                	mv	a6,sp
{
    2478:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    247a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    247e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2480:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2482:	00000073          	ecall
	if (err == 0) {
    2486:	2501                	sext.w	a0,a0
    2488:	ed31                	bnez	a0,24e4 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    248a:	6722                	ld	a4,8(sp)
    248c:	3e800793          	li	a5,1000
    2490:	6682                	ld	a3,0(sp)
    2492:	02f75733          	divu	a4,a4,a5
    2496:	02d787b3          	mul	a5,a5,a3
    249a:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    249c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24a2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a4:	00000073          	ecall
	if (err == 0) {
    24a8:	2501                	sext.w	a0,a0
    24aa:	e915                	bnez	a0,24de <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24ac:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24ae:	3e800693          	li	a3,1000
    24b2:	a819                	j	24c8 <sleep+0x54>
	__asm_syscall("r"(a7))
    24b4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24b8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24bc:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24be:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c0:	00000073          	ecall
	if (err == 0) {
    24c4:	2501                	sext.w	a0,a0
    24c6:	ed01                	bnez	a0,24de <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24c8:	6722                	ld	a4,8(sp)
    24ca:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24cc:	07c00893          	li	a7,124
    24d0:	02d75733          	divu	a4,a4,a3
    24d4:	02f687b3          	mul	a5,a3,a5
    24d8:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24da:	fcc7ede3          	bltu	a5,a2,24b4 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24de:	4501                	li	a0,0
    24e0:	0141                	addi	sp,sp,16
    24e2:	8082                	ret
    24e4:	57fd                	li	a5,-1
    24e6:	bf5d                	j	249c <sleep+0x28>

00000000000024e8 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24e8:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24ec:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24f0:	2501                	sext.w	a0,a0
    24f2:	8082                	ret

00000000000024f4 <set_priority>:
	register long a7 __asm__("a7") = n;
    24f4:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    24f8:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    24fc:	2501                	sext.w	a0,a0
    24fe:	8082                	ret

0000000000002500 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2500:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2504:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2508:	2501                	sext.w	a0,a0
    250a:	8082                	ret

000000000000250c <munmap>:
	register long a7 __asm__("a7") = n;
    250c:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2510:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2514:	2501                	sext.w	a0,a0
    2516:	8082                	ret

0000000000002518 <wait>:

int wait(int *code)
{
    2518:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    251a:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    251e:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2520:	00000073          	ecall
	return waitpid(-1, code);
}
    2524:	2501                	sext.w	a0,a0
    2526:	8082                	ret

0000000000002528 <spawn>:
	register long a7 __asm__("a7") = n;
    2528:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    252c:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2530:	2501                	sext.w	a0,a0
    2532:	8082                	ret

0000000000002534 <pipe>:
	register long a7 __asm__("a7") = n;
    2534:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2538:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    253c:	2501                	sext.w	a0,a0
    253e:	8082                	ret

0000000000002540 <mailread>:
	register long a7 __asm__("a7") = n;
    2540:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2544:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2548:	2501                	sext.w	a0,a0
    254a:	8082                	ret

000000000000254c <mailwrite>:
	register long a7 __asm__("a7") = n;
    254c:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2550:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2554:	2501                	sext.w	a0,a0
    2556:	8082                	ret

0000000000002558 <fstat>:
	register long a7 __asm__("a7") = n;
    2558:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    255c:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2560:	2501                	sext.w	a0,a0
    2562:	8082                	ret

0000000000002564 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2564:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2566:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    256a:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    256c:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2570:	2501                	sext.w	a0,a0
    2572:	8082                	ret

0000000000002574 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2574:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2576:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    257a:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    257c:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2580:	2501                	sext.w	a0,a0
    2582:	8082                	ret

0000000000002584 <link>:

int link(char *old_path, char *new_path)
{
    2584:	87aa                	mv	a5,a0
    2586:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2588:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    258c:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2590:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2592:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2596:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2598:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    259c:	2501                	sext.w	a0,a0
    259e:	8082                	ret

00000000000025a0 <unlink>:

int unlink(char *path)
{
    25a0:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25a2:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25a6:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25aa:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ac:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25b0:	2501                	sext.w	a0,a0
    25b2:	8082                	ret

00000000000025b4 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25b4:	00000797          	auipc	a5,0x0
    25b8:	3a47b783          	ld	a5,932(a5) # 2958 <_GLOBAL_OFFSET_TABLE_+0x8>
    25bc:	439c                	lw	a5,0(a5)
    25be:	c799                	beqz	a5,25cc <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25c0:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c4:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret
{
    25cc:	1101                	addi	sp,sp,-32
    25ce:	ec06                	sd	ra,24(sp)
    25d0:	e42e                	sd	a1,8(sp)
    25d2:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25d4:	fe7fe0ef          	jal	ra,15ba <enable_thread_io_buffer>
    25d8:	65a2                	ld	a1,8(sp)
    25da:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25dc:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e0:	00000073          	ecall
}
    25e4:	60e2                	ld	ra,24(sp)
    25e6:	2501                	sext.w	a0,a0
    25e8:	6105                	addi	sp,sp,32
    25ea:	8082                	ret

00000000000025ec <gettid>:
	register long a7 __asm__("a7") = n;
    25ec:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25f0:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25f4:	2501                	sext.w	a0,a0
    25f6:	8082                	ret

00000000000025f8 <waittid>:

int waittid(int tid)
{
    25f8:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    25fa:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    25fe:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2602:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2604:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2606:	00e51e63          	bne	a0,a4,2622 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    260a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    260e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2612:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2616:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2618:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    261c:	2501                	sext.w	a0,a0
	while (ret == -2) {
    261e:	fee506e3          	beq	a0,a4,260a <waittid+0x12>
	}
	return ret;
}
    2622:	8082                	ret

0000000000002624 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2624:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2628:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    262a:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    262e:	2501                	sext.w	a0,a0
    2630:	8082                	ret

0000000000002632 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2632:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2636:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2638:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    263c:	2501                	sext.w	a0,a0
    263e:	8082                	ret

0000000000002640 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2640:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2644:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2648:	2501                	sext.w	a0,a0
    264a:	8082                	ret

000000000000264c <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    264c:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2650:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2654:	2501                	sext.w	a0,a0
    2656:	8082                	ret

0000000000002658 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2658:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    265c:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2660:	2501                	sext.w	a0,a0
    2662:	8082                	ret

0000000000002664 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2664:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2668:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    266c:	2501                	sext.w	a0,a0
    266e:	8082                	ret

0000000000002670 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2670:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2674:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2678:	2501                	sext.w	a0,a0
    267a:	8082                	ret

000000000000267c <condvar_create>:
	register long a7 __asm__("a7") = n;
    267c:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2680:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2684:	2501                	sext.w	a0,a0
    2686:	8082                	ret

0000000000002688 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2688:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    268c:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2690:	2501                	sext.w	a0,a0
    2692:	8082                	ret

0000000000002694 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2694:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2698:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    269c:	2501                	sext.w	a0,a0
    269e:	8082                	ret

00000000000026a0 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26a0:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26a4:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26a8:	2501                	sext.w	a0,a0
    26aa:	8082                	ret
