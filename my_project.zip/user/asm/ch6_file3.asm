
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6_file3:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a2f5                	j	11ec <__start_main>

0000000000001002 <repeat>:
#include <unistd.h>

/// 测试大量 open/unlink，输出 Test mass open/unlink OK! 就算正确。

void repeat(char *target, const char *template, int times)
{
    1002:	7179                	addi	sp,sp,-48
    1004:	f022                	sd	s0,32(sp)
    1006:	e44e                	sd	s3,8(sp)
    1008:	842a                	mv	s0,a0
    100a:	89b2                	mv	s3,a2
	int len = strlen(template);
    100c:	852e                	mv	a0,a1
{
    100e:	e052                	sd	s4,0(sp)
    1010:	f406                	sd	ra,40(sp)
    1012:	ec26                	sd	s1,24(sp)
    1014:	e84a                	sd	s2,16(sp)
    1016:	8a2e                	mv	s4,a1
	int len = strlen(template);
    1018:	090010ef          	jal	ra,20a8 <strlen>
	for (int i = 0; i < times; i++)
    101c:	01305e63          	blez	s3,1038 <repeat+0x36>
    1020:	0005091b          	sext.w	s2,a0
    1024:	4481                	li	s1,0
		stpncpy(target + len * i, template, len);
    1026:	8522                	mv	a0,s0
    1028:	864a                	mv	a2,s2
    102a:	85d2                	mv	a1,s4
	for (int i = 0; i < times; i++)
    102c:	2485                	addiw	s1,s1,1
		stpncpy(target + len * i, template, len);
    102e:	200010ef          	jal	ra,222e <stpncpy>
	for (int i = 0; i < times; i++)
    1032:	944a                	add	s0,s0,s2
    1034:	fe9999e3          	bne	s3,s1,1026 <repeat+0x24>
}
    1038:	70a2                	ld	ra,40(sp)
    103a:	7402                	ld	s0,32(sp)
    103c:	64e2                	ld	s1,24(sp)
    103e:	6942                	ld	s2,16(sp)
    1040:	69a2                	ld	s3,8(sp)
    1042:	6a02                	ld	s4,0(sp)
    1044:	6145                	addi	sp,sp,48
    1046:	8082                	ret

0000000000001048 <main>:
char test_str[4096];
int main()
{
	char fname[] = "fname3-0";
    1048:	00002797          	auipc	a5,0x2
    104c:	99878793          	addi	a5,a5,-1640 # 29e0 <enable_deadlock_detect+0x19a>
    1050:	6398                	ld	a4,0(a5)
    1052:	0087c783          	lbu	a5,8(a5)
{
    1056:	7119                	addi	sp,sp,-128
	puts("build");
    1058:	00002517          	auipc	a0,0x2
    105c:	80050513          	addi	a0,a0,-2048 # 2858 <enable_deadlock_detect+0x12>
{
    1060:	fc86                	sd	ra,120(sp)
	char fname[] = "fname3-0";
    1062:	e03a                	sd	a4,0(sp)
    1064:	00f10423          	sb	a5,8(sp)
{
    1068:	f0ca                	sd	s2,96(sp)
    106a:	ecce                	sd	s3,88(sp)
    106c:	e8d2                	sd	s4,80(sp)
    106e:	e4d6                	sd	s5,72(sp)
    1070:	e0da                	sd	s6,64(sp)
    1072:	fc5e                	sd	s7,56(sp)
    1074:	f862                	sd	s8,48(sp)
    1076:	f466                	sd	s9,40(sp)
    1078:	f06a                	sd	s10,32(sp)
    107a:	ec6e                	sd	s11,24(sp)
    107c:	f8a2                	sd	s0,112(sp)
    107e:	f4a6                	sd	s1,104(sp)
	puts("build");
    1080:	1dd000ef          	jal	ra,1a5c <puts>
	repeat(test_str,
    1084:	03200613          	li	a2,50
    1088:	00001597          	auipc	a1,0x1
    108c:	7d858593          	addi	a1,a1,2008 # 2860 <enable_deadlock_detect+0x1a>
    1090:	00002517          	auipc	a0,0x2
    1094:	a5850513          	addi	a0,a0,-1448 # 2ae8 <test_str>
    1098:	f6bff0ef          	jal	ra,1002 <repeat>
	       "some random long long long long long long long long string",
	       50);
	int len = strlen(test_str);
    109c:	00002517          	auipc	a0,0x2
    10a0:	a4c50513          	addi	a0,a0,-1460 # 2ae8 <test_str>
    10a4:	004010ef          	jal	ra,20a8 <strlen>
    10a8:	892a                	mv	s2,a0
	puts("start iteration");
    10aa:	00001517          	auipc	a0,0x1
    10ae:	7f650513          	addi	a0,a0,2038 # 28a0 <enable_deadlock_detect+0x5a>
    10b2:	1ab000ef          	jal	ra,1a5c <puts>
	for (int i = 0; i < 10; i++) {
		fname[7] = '0' + i; // change fname to "fname%d"
		int fd = open(fname, O_CREATE | O_WRONLY);
		assert(fd > 0);
		for (int j = 0; j < 50; j++) {
			write(fd, test_str, len);
    10b6:	2901                	sext.w	s2,s2
	for (int i = 0; i < 10; i++) {
    10b8:	4a01                	li	s4,0
    10ba:	8a8a                	mv	s5,sp
		assert(fd > 0);
    10bc:	00001c97          	auipc	s9,0x1
    10c0:	7f4c8c93          	addi	s9,s9,2036 # 28b0 <enable_deadlock_detect+0x6a>
    10c4:	00002c17          	auipc	s8,0x2
    10c8:	834c0c13          	addi	s8,s8,-1996 # 28f8 <enable_deadlock_detect+0xb2>
    10cc:	00002d97          	auipc	s11,0x2
    10d0:	834d8d93          	addi	s11,s11,-1996 # 2900 <enable_deadlock_detect+0xba>
			write(fd, test_str, len);
    10d4:	00002997          	auipc	s3,0x2
    10d8:	a1498993          	addi	s3,s3,-1516 # 2ae8 <test_str>
		}
		close(fd);
		assert_eq(unlink(fname), 0);
    10dc:	00002d17          	auipc	s10,0x2
    10e0:	854d0d13          	addi	s10,s10,-1964 # 2930 <enable_deadlock_detect+0xea>
		assert(open(fname, O_RDONLY) < 0);
		printf("test iteration %d\n", i);
    10e4:	00002b97          	auipc	s7,0x2
    10e8:	8c4b8b93          	addi	s7,s7,-1852 # 29a8 <enable_deadlock_detect+0x162>
	for (int i = 0; i < 10; i++) {
    10ec:	4b29                	li	s6,10
		fname[7] = '0' + i; // change fname to "fname%d"
    10ee:	030a079b          	addiw	a5,s4,48
		int fd = open(fname, O_CREATE | O_WRONLY);
    10f2:	20100593          	li	a1,513
    10f6:	8556                	mv	a0,s5
		fname[7] = '0' + i; // change fname to "fname%d"
    10f8:	00f103a3          	sb	a5,7(sp)
		int fd = open(fname, O_CREATE | O_WRONLY);
    10fc:	428010ef          	jal	ra,2524 <open>
    1100:	84aa                	mv	s1,a0
		assert(fd > 0);
    1102:	08a05a63          	blez	a0,1196 <main+0x14e>
	for (int i = 0; i < 10; i++) {
    1106:	03200413          	li	s0,50
		for (int j = 0; j < 50; j++) {
    110a:	347d                	addiw	s0,s0,-1
			write(fd, test_str, len);
    110c:	864a                	mv	a2,s2
    110e:	85ce                	mv	a1,s3
    1110:	8526                	mv	a0,s1
    1112:	45c010ef          	jal	ra,256e <write>
		for (int j = 0; j < 50; j++) {
    1116:	f875                	bnez	s0,110a <main+0xc2>
		close(fd);
    1118:	8526                	mv	a0,s1
    111a:	418010ef          	jal	ra,2532 <close>
		assert_eq(unlink(fname), 0);
    111e:	8556                	mv	a0,s5
    1120:	626010ef          	jal	ra,2746 <unlink>
    1124:	e959                	bnez	a0,11ba <main+0x172>
		assert(open(fname, O_RDONLY) < 0);
    1126:	4581                	li	a1,0
    1128:	8556                	mv	a0,s5
    112a:	3fa010ef          	jal	ra,2524 <open>
    112e:	02054763          	bltz	a0,115c <main+0x114>
    1132:	446010ef          	jal	ra,2578 <getpid>
    1136:	842a                	mv	s0,a0
    1138:	8566                	mv	a0,s9
    113a:	314010ef          	jal	ra,244e <basename>
    113e:	872a                	mv	a4,a0
    1140:	02200793          	li	a5,34
    1144:	00002517          	auipc	a0,0x2
    1148:	82450513          	addi	a0,a0,-2012 # 2968 <enable_deadlock_detect+0x122>
    114c:	86a2                	mv	a3,s0
    114e:	8662                	mv	a2,s8
    1150:	45fd                	li	a1,31
    1152:	1f4000ef          	jal	ra,1346 <printf>
    1156:	557d                	li	a0,-1
    1158:	450010ef          	jal	ra,25a8 <exit>
		printf("test iteration %d\n", i);
    115c:	85d2                	mv	a1,s4
    115e:	855e                	mv	a0,s7
	for (int i = 0; i < 10; i++) {
    1160:	2a05                	addiw	s4,s4,1
		printf("test iteration %d\n", i);
    1162:	1e4000ef          	jal	ra,1346 <printf>
	for (int i = 0; i < 10; i++) {
    1166:	f96a14e3          	bne	s4,s6,10ee <main+0xa6>
	}
	puts("Test mass open/unlink OK!");
    116a:	00002517          	auipc	a0,0x2
    116e:	85650513          	addi	a0,a0,-1962 # 29c0 <enable_deadlock_detect+0x17a>
    1172:	0eb000ef          	jal	ra,1a5c <puts>
	return 0;
}
    1176:	70e6                	ld	ra,120(sp)
    1178:	7446                	ld	s0,112(sp)
    117a:	74a6                	ld	s1,104(sp)
    117c:	7906                	ld	s2,96(sp)
    117e:	69e6                	ld	s3,88(sp)
    1180:	6a46                	ld	s4,80(sp)
    1182:	6aa6                	ld	s5,72(sp)
    1184:	6b06                	ld	s6,64(sp)
    1186:	7be2                	ld	s7,56(sp)
    1188:	7c42                	ld	s8,48(sp)
    118a:	7ca2                	ld	s9,40(sp)
    118c:	7d02                	ld	s10,32(sp)
    118e:	6de2                	ld	s11,24(sp)
    1190:	4501                	li	a0,0
    1192:	6109                	addi	sp,sp,128
    1194:	8082                	ret
		assert(fd > 0);
    1196:	3e2010ef          	jal	ra,2578 <getpid>
    119a:	842a                	mv	s0,a0
    119c:	8566                	mv	a0,s9
    119e:	2b0010ef          	jal	ra,244e <basename>
    11a2:	872a                	mv	a4,a0
    11a4:	47f1                	li	a5,28
    11a6:	856e                	mv	a0,s11
    11a8:	86a2                	mv	a3,s0
    11aa:	8662                	mv	a2,s8
    11ac:	45fd                	li	a1,31
    11ae:	198000ef          	jal	ra,1346 <printf>
    11b2:	557d                	li	a0,-1
    11b4:	3f4010ef          	jal	ra,25a8 <exit>
    11b8:	b7b9                	j	1106 <main+0xbe>
		assert_eq(unlink(fname), 0);
    11ba:	3be010ef          	jal	ra,2578 <getpid>
    11be:	842a                	mv	s0,a0
    11c0:	8566                	mv	a0,s9
    11c2:	28c010ef          	jal	ra,244e <basename>
    11c6:	84aa                	mv	s1,a0
    11c8:	8556                	mv	a0,s5
    11ca:	57c010ef          	jal	ra,2746 <unlink>
    11ce:	882a                	mv	a6,a0
    11d0:	4881                	li	a7,0
    11d2:	856a                	mv	a0,s10
    11d4:	02100793          	li	a5,33
    11d8:	8726                	mv	a4,s1
    11da:	86a2                	mv	a3,s0
    11dc:	8662                	mv	a2,s8
    11de:	45fd                	li	a1,31
    11e0:	166000ef          	jal	ra,1346 <printf>
    11e4:	557d                	li	a0,-1
    11e6:	3c2010ef          	jal	ra,25a8 <exit>
    11ea:	bf35                	j	1126 <main+0xde>

00000000000011ec <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    11ec:	1141                	addi	sp,sp,-16
    11ee:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    11f0:	e59ff0ef          	jal	ra,1048 <main>
    11f4:	3b4010ef          	jal	ra,25a8 <exit>
	return 0;
    11f8:	60a2                	ld	ra,8(sp)
    11fa:	4501                	li	a0,0
    11fc:	0141                	addi	sp,sp,16
    11fe:	8082                	ret

0000000000001200 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1200:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1202:	4605                	li	a2,1
    1204:	00f10593          	addi	a1,sp,15
    1208:	4501                	li	a0,0
{
    120a:	ec06                	sd	ra,24(sp)
	char byte = 0;
    120c:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1210:	354010ef          	jal	ra,2564 <read>
    1214:	4785                	li	a5,1
    1216:	00f51763          	bne	a0,a5,1224 <getchar+0x24>
		return byte;
    121a:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    121e:	60e2                	ld	ra,24(sp)
    1220:	6105                	addi	sp,sp,32
    1222:	8082                	ret
		return EOF;
    1224:	557d                	li	a0,-1
    1226:	bfe5                	j	121e <getchar+0x1e>

0000000000001228 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1228:	00003517          	auipc	a0,0x3
    122c:	8c052503          	lw	a0,-1856(a0) # 3ae8 <buffer_len>
    1230:	e111                	bnez	a0,1234 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1232:	8082                	ret
{
    1234:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1236:	862a                	mv	a2,a0
    1238:	00003597          	auipc	a1,0x3
    123c:	8b858593          	addi	a1,a1,-1864 # 3af0 <buffer>
    1240:	4505                	li	a0,1
{
    1242:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1244:	32a010ef          	jal	ra,256e <write>
}
    1248:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    124a:	2501                	sext.w	a0,a0
}
    124c:	0141                	addi	sp,sp,16
    124e:	8082                	ret

0000000000001250 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1250:	00003797          	auipc	a5,0x3
    1254:	8807ac23          	sw	zero,-1896(a5) # 3ae8 <buffer_len>
}
    1258:	8082                	ret

000000000000125a <__fflush>:
	if (buffer_len == 0)
    125a:	00003517          	auipc	a0,0x3
    125e:	88e52503          	lw	a0,-1906(a0) # 3ae8 <buffer_len>
    1262:	e511                	bnez	a0,126e <__fflush+0x14>
	buffer_len = 0;
    1264:	00003797          	auipc	a5,0x3
    1268:	8807a223          	sw	zero,-1916(a5) # 3ae8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    126c:	8082                	ret
{
    126e:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1270:	862a                	mv	a2,a0
    1272:	00003597          	auipc	a1,0x3
    1276:	87e58593          	addi	a1,a1,-1922 # 3af0 <buffer>
    127a:	4505                	li	a0,1
{
    127c:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    127e:	2f0010ef          	jal	ra,256e <write>
	return r >= 0 ? 0 : r;
    1282:	0005079b          	sext.w	a5,a0
}
    1286:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1288:	0017a793          	slti	a5,a5,1
    128c:	40f007bb          	negw	a5,a5
    1290:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1292:	00003797          	auipc	a5,0x3
    1296:	8407ab23          	sw	zero,-1962(a5) # 3ae8 <buffer_len>
	return r >= 0 ? 0 : r;
    129a:	2501                	sext.w	a0,a0
}
    129c:	0141                	addi	sp,sp,16
    129e:	8082                	ret

00000000000012a0 <fflush>:

int fflush(int fd)
{
    12a0:	1101                	addi	sp,sp,-32
    12a2:	e822                	sd	s0,16(sp)
    12a4:	ec06                	sd	ra,24(sp)
    12a6:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    12a8:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    12aa:	4401                	li	s0,0
	if (fd == 1) {
    12ac:	00e50863          	beq	a0,a4,12bc <fflush+0x1c>
}
    12b0:	60e2                	ld	ra,24(sp)
    12b2:	8522                	mv	a0,s0
    12b4:	6442                	ld	s0,16(sp)
    12b6:	64a2                	ld	s1,8(sp)
    12b8:	6105                	addi	sp,sp,32
    12ba:	8082                	ret
		if (buffer_lock_enabled == 1) {
    12bc:	00003497          	auipc	s1,0x3
    12c0:	82c48493          	addi	s1,s1,-2004 # 3ae8 <buffer_len>
    12c4:	1084a703          	lw	a4,264(s1)
    12c8:	02a70e63          	beq	a4,a0,1304 <fflush+0x64>
	if (buffer_len == 0)
    12cc:	4080                	lw	s0,0(s1)
    12ce:	c00d                	beqz	s0,12f0 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    12d0:	8622                	mv	a2,s0
    12d2:	00003597          	auipc	a1,0x3
    12d6:	81e58593          	addi	a1,a1,-2018 # 3af0 <buffer>
    12da:	294010ef          	jal	ra,256e <write>
	return r >= 0 ? 0 : r;
    12de:	0005079b          	sext.w	a5,a0
    12e2:	0017a793          	slti	a5,a5,1
    12e6:	40f007bb          	negw	a5,a5
    12ea:	8d7d                	and	a0,a0,a5
    12ec:	0005041b          	sext.w	s0,a0
}
    12f0:	60e2                	ld	ra,24(sp)
    12f2:	8522                	mv	a0,s0
    12f4:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    12f6:	00002797          	auipc	a5,0x2
    12fa:	7e07a923          	sw	zero,2034(a5) # 3ae8 <buffer_len>
}
    12fe:	64a2                	ld	s1,8(sp)
    1300:	6105                	addi	sp,sp,32
    1302:	8082                	ret
			mutex_lock(buffer_lock);
    1304:	10c4a503          	lw	a0,268(s1)
    1308:	4de010ef          	jal	ra,27e6 <mutex_lock>
	if (buffer_len == 0)
    130c:	4080                	lw	s0,0(s1)
    130e:	e811                	bnez	s0,1322 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1310:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1314:	00002797          	auipc	a5,0x2
    1318:	7c07aa23          	sw	zero,2004(a5) # 3ae8 <buffer_len>
			mutex_unlock(buffer_lock);
    131c:	4d6010ef          	jal	ra,27f2 <mutex_unlock>
    1320:	bf41                	j	12b0 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1322:	8622                	mv	a2,s0
    1324:	00002597          	auipc	a1,0x2
    1328:	7cc58593          	addi	a1,a1,1996 # 3af0 <buffer>
    132c:	4505                	li	a0,1
    132e:	240010ef          	jal	ra,256e <write>
	return r >= 0 ? 0 : r;
    1332:	0005079b          	sext.w	a5,a0
    1336:	0017a793          	slti	a5,a5,1
    133a:	40f007bb          	negw	a5,a5
    133e:	8d7d                	and	a0,a0,a5
    1340:	0005041b          	sext.w	s0,a0
	return r;
    1344:	b7f1                	j	1310 <fflush+0x70>

0000000000001346 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1346:	7131                	addi	sp,sp,-192
    1348:	e0da                	sd	s6,64(sp)
    134a:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    134c:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    134e:	013c                	addi	a5,sp,136
{
    1350:	f0ca                	sd	s2,96(sp)
    1352:	ecce                	sd	s3,88(sp)
    1354:	e8d2                	sd	s4,80(sp)
    1356:	e4d6                	sd	s5,72(sp)
    1358:	fc86                	sd	ra,120(sp)
    135a:	f8a2                	sd	s0,112(sp)
    135c:	f4a6                	sd	s1,104(sp)
    135e:	89aa                	mv	s3,a0
    1360:	e52e                	sd	a1,136(sp)
    1362:	e932                	sd	a2,144(sp)
    1364:	ed36                	sd	a3,152(sp)
    1366:	f13a                	sd	a4,160(sp)
    1368:	f942                	sd	a6,176(sp)
    136a:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    136c:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    136e:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1372:	00002a17          	auipc	s4,0x2
    1376:	776a0a13          	addi	s4,s4,1910 # 3ae8 <buffer_len>
    137a:	4a85                	li	s5,1
	buf[i++] = '0';
    137c:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1380:	0009c783          	lbu	a5,0(s3)
    1384:	18078663          	beqz	a5,1510 <printf+0x1ca>
    1388:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    138a:	19278d63          	beq	a5,s2,1524 <printf+0x1de>
    138e:	0015c783          	lbu	a5,1(a1)
    1392:	0585                	addi	a1,a1,1
    1394:	fbfd                	bnez	a5,138a <printf+0x44>
    1396:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1398:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    139c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13a0:	1b578863          	beq	a5,s5,1550 <printf+0x20a>
		len = out_unlocked(s, l);
    13a4:	85a2                	mv	a1,s0
    13a6:	854e                	mv	a0,s3
    13a8:	42a000ef          	jal	ra,17d2 <out_unlocked>
		out(f, a, l);
		if (l)
    13ac:	1c041063          	bnez	s0,156c <printf+0x226>
			continue;
		if (s[1] == 0)
    13b0:	0014c783          	lbu	a5,1(s1)
    13b4:	14078e63          	beqz	a5,1510 <printf+0x1ca>
			break;
		switch (s[1]) {
    13b8:	07300713          	li	a4,115
    13bc:	1ce78863          	beq	a5,a4,158c <printf+0x246>
    13c0:	1af76863          	bltu	a4,a5,1570 <printf+0x22a>
    13c4:	06400713          	li	a4,100
    13c8:	22e78063          	beq	a5,a4,15e8 <printf+0x2a2>
    13cc:	07000713          	li	a4,112
    13d0:	1ee79563          	bne	a5,a4,15ba <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    13d4:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13d6:	00003797          	auipc	a5,0x3
    13da:	82278793          	addi	a5,a5,-2014 # 3bf8 <digits>
	buf[i++] = '0';
    13de:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    13e2:	6298                	ld	a4,0(a3)
    13e4:	06a1                	addi	a3,a3,8
    13e6:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13e8:	00471393          	slli	t2,a4,0x4
    13ec:	00871293          	slli	t0,a4,0x8
    13f0:	00c71f93          	slli	t6,a4,0xc
    13f4:	01071f13          	slli	t5,a4,0x10
    13f8:	01471e93          	slli	t4,a4,0x14
    13fc:	01871e13          	slli	t3,a4,0x18
    1400:	01c71893          	slli	a7,a4,0x1c
    1404:	02471813          	slli	a6,a4,0x24
    1408:	02871513          	slli	a0,a4,0x28
    140c:	02c71593          	slli	a1,a4,0x2c
    1410:	03071613          	slli	a2,a4,0x30
    1414:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1418:	03c75413          	srli	s0,a4,0x3c
    141c:	01c7531b          	srliw	t1,a4,0x1c
    1420:	03c3d393          	srli	t2,t2,0x3c
    1424:	03c2d293          	srli	t0,t0,0x3c
    1428:	03cfdf93          	srli	t6,t6,0x3c
    142c:	03cf5f13          	srli	t5,t5,0x3c
    1430:	03cede93          	srli	t4,t4,0x3c
    1434:	03ce5e13          	srli	t3,t3,0x3c
    1438:	03c8d893          	srli	a7,a7,0x3c
    143c:	03c85813          	srli	a6,a6,0x3c
    1440:	9171                	srli	a0,a0,0x3c
    1442:	91f1                	srli	a1,a1,0x3c
    1444:	9271                	srli	a2,a2,0x3c
    1446:	92f1                	srli	a3,a3,0x3c
    1448:	95be                	add	a1,a1,a5
    144a:	963e                	add	a2,a2,a5
    144c:	96be                	add	a3,a3,a5
    144e:	943e                	add	s0,s0,a5
    1450:	93be                	add	t2,t2,a5
    1452:	92be                	add	t0,t0,a5
    1454:	9fbe                	add	t6,t6,a5
    1456:	9f3e                	add	t5,t5,a5
    1458:	9ebe                	add	t4,t4,a5
    145a:	9e3e                	add	t3,t3,a5
    145c:	98be                	add	a7,a7,a5
    145e:	933e                	add	t1,t1,a5
    1460:	983e                	add	a6,a6,a5
    1462:	953e                	add	a0,a0,a5
    1464:	0005c983          	lbu	s3,0(a1)
    1468:	00044403          	lbu	s0,0(s0)
    146c:	00064583          	lbu	a1,0(a2)
    1470:	0003c383          	lbu	t2,0(t2)
    1474:	0006c603          	lbu	a2,0(a3)
    1478:	0002c283          	lbu	t0,0(t0)
    147c:	000fcf83          	lbu	t6,0(t6)
    1480:	000f4f03          	lbu	t5,0(t5)
    1484:	000ece83          	lbu	t4,0(t4)
    1488:	000e4e03          	lbu	t3,0(t3)
    148c:	0008c883          	lbu	a7,0(a7)
    1490:	00034303          	lbu	t1,0(t1)
    1494:	00084803          	lbu	a6,0(a6)
    1498:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    149c:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14a0:	92f1                	srli	a3,a3,0x3c
    14a2:	8b3d                	andi	a4,a4,15
    14a4:	96be                	add	a3,a3,a5
    14a6:	97ba                	add	a5,a5,a4
    14a8:	00810d23          	sb	s0,26(sp)
    14ac:	00710da3          	sb	t2,27(sp)
    14b0:	00510e23          	sb	t0,28(sp)
    14b4:	01f10ea3          	sb	t6,29(sp)
    14b8:	01e10f23          	sb	t5,30(sp)
    14bc:	01d10fa3          	sb	t4,31(sp)
    14c0:	03c10023          	sb	t3,32(sp)
    14c4:	031100a3          	sb	a7,33(sp)
    14c8:	02610123          	sb	t1,34(sp)
    14cc:	030101a3          	sb	a6,35(sp)
    14d0:	02a10223          	sb	a0,36(sp)
    14d4:	033102a3          	sb	s3,37(sp)
    14d8:	02b10323          	sb	a1,38(sp)
    14dc:	02c103a3          	sb	a2,39(sp)
    14e0:	0006c683          	lbu	a3,0(a3)
    14e4:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    14e8:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14ec:	02d10423          	sb	a3,40(sp)
    14f0:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    14f4:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    14f8:	11578263          	beq	a5,s5,15fc <printf+0x2b6>
		len = out_unlocked(s, l);
    14fc:	45c9                	li	a1,18
    14fe:	0828                	addi	a0,sp,24
    1500:	2d2000ef          	jal	ra,17d2 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1504:	00248993          	addi	s3,s1,2
		if (!*s)
    1508:	0009c783          	lbu	a5,0(s3)
    150c:	e6079ee3          	bnez	a5,1388 <printf+0x42>
	}
	va_end(ap);
    1510:	70e6                	ld	ra,120(sp)
    1512:	7446                	ld	s0,112(sp)
    1514:	74a6                	ld	s1,104(sp)
    1516:	7906                	ld	s2,96(sp)
    1518:	69e6                	ld	s3,88(sp)
    151a:	6a46                	ld	s4,80(sp)
    151c:	6aa6                	ld	s5,72(sp)
    151e:	6b06                	ld	s6,64(sp)
    1520:	6129                	addi	sp,sp,192
    1522:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1524:	0005c783          	lbu	a5,0(a1)
    1528:	84ae                	mv	s1,a1
    152a:	01278963          	beq	a5,s2,153c <printf+0x1f6>
    152e:	b5ad                	j	1398 <printf+0x52>
    1530:	0024c783          	lbu	a5,2(s1)
    1534:	0585                	addi	a1,a1,1
    1536:	0489                	addi	s1,s1,2
    1538:	e72790e3          	bne	a5,s2,1398 <printf+0x52>
    153c:	0014c783          	lbu	a5,1(s1)
    1540:	ff2788e3          	beq	a5,s2,1530 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1544:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1548:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    154c:	e5579ce3          	bne	a5,s5,13a4 <printf+0x5e>
		mutex_lock(buffer_lock);
    1550:	10ca2503          	lw	a0,268(s4)
    1554:	292010ef          	jal	ra,27e6 <mutex_lock>
		len = out_unlocked(s, l);
    1558:	85a2                	mv	a1,s0
    155a:	854e                	mv	a0,s3
    155c:	276000ef          	jal	ra,17d2 <out_unlocked>
		mutex_unlock(buffer_lock);
    1560:	10ca2503          	lw	a0,268(s4)
    1564:	28e010ef          	jal	ra,27f2 <mutex_unlock>
		if (l)
    1568:	e40404e3          	beqz	s0,13b0 <printf+0x6a>
    156c:	89a6                	mv	s3,s1
    156e:	bd09                	j	1380 <printf+0x3a>
		switch (s[1]) {
    1570:	07800713          	li	a4,120
    1574:	04e79363          	bne	a5,a4,15ba <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1578:	67c2                	ld	a5,16(sp)
    157a:	45c1                	li	a1,16
		s += 2;
    157c:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1580:	4388                	lw	a0,0(a5)
    1582:	07a1                	addi	a5,a5,8
    1584:	e83e                	sd	a5,16(sp)
    1586:	5f8000ef          	jal	ra,1b7e <printint.constprop.0>
		s += 2;
    158a:	bfbd                	j	1508 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    158c:	67c2                	ld	a5,16(sp)
    158e:	6380                	ld	s0,0(a5)
    1590:	07a1                	addi	a5,a5,8
    1592:	e83e                	sd	a5,16(sp)
    1594:	1c040163          	beqz	s0,1756 <printf+0x410>
			l = strnlen(a, 200);
    1598:	0c800593          	li	a1,200
    159c:	8522                	mv	a0,s0
    159e:	3f7000ef          	jal	ra,2194 <strnlen>
	if (buffer_lock_enabled == 1) {
    15a2:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    15a6:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    15aa:	19578663          	beq	a5,s5,1736 <printf+0x3f0>
		len = out_unlocked(s, l);
    15ae:	8522                	mv	a0,s0
    15b0:	222000ef          	jal	ra,17d2 <out_unlocked>
		s += 2;
    15b4:	00248993          	addi	s3,s1,2
    15b8:	bf81                	j	1508 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    15ba:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15be:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    15c2:	0f578663          	beq	a5,s5,16ae <printf+0x368>
		len = out_unlocked(s, l);
    15c6:	0828                	addi	a0,sp,24
    15c8:	316000ef          	jal	ra,18de <out_unlocked.constprop.0>
			putchar(s[1]);
    15cc:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    15d0:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15d4:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    15d8:	05578163          	beq	a5,s5,161a <printf+0x2d4>
		len = out_unlocked(s, l);
    15dc:	0828                	addi	a0,sp,24
    15de:	300000ef          	jal	ra,18de <out_unlocked.constprop.0>
		s += 2;
    15e2:	00248993          	addi	s3,s1,2
    15e6:	b70d                	j	1508 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    15e8:	67c2                	ld	a5,16(sp)
    15ea:	45a9                	li	a1,10
		s += 2;
    15ec:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    15f0:	4388                	lw	a0,0(a5)
    15f2:	07a1                	addi	a5,a5,8
    15f4:	e83e                	sd	a5,16(sp)
    15f6:	588000ef          	jal	ra,1b7e <printint.constprop.0>
		s += 2;
    15fa:	b739                	j	1508 <printf+0x1c2>
		mutex_lock(buffer_lock);
    15fc:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1600:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1604:	1e2010ef          	jal	ra,27e6 <mutex_lock>
		len = out_unlocked(s, l);
    1608:	45c9                	li	a1,18
    160a:	0828                	addi	a0,sp,24
    160c:	1c6000ef          	jal	ra,17d2 <out_unlocked>
		mutex_unlock(buffer_lock);
    1610:	10ca2503          	lw	a0,268(s4)
    1614:	1de010ef          	jal	ra,27f2 <mutex_unlock>
		s += 2;
    1618:	bdc5                	j	1508 <printf+0x1c2>
		mutex_lock(buffer_lock);
    161a:	10ca2503          	lw	a0,268(s4)
    161e:	1c8010ef          	jal	ra,27e6 <mutex_lock>
		buffer[buffer_len++] = c;
    1622:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1626:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    162a:	0017861b          	addiw	a2,a5,1
    162e:	97d2                	add	a5,a5,s4
    1630:	00ca2023          	sw	a2,0(s4)
    1634:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1638:	00c6cc63          	blt	a3,a2,1650 <printf+0x30a>
    163c:	47a9                	li	a5,10
    163e:	06f40663          	beq	s0,a5,16aa <printf+0x364>
		mutex_unlock(buffer_lock);
    1642:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1646:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    164a:	1a8010ef          	jal	ra,27f2 <mutex_unlock>
		s += 2;
    164e:	bd6d                	j	1508 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1650:	10000793          	li	a5,256
    1654:	00f61e63          	bne	a2,a5,1670 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1658:	00002597          	auipc	a1,0x2
    165c:	49858593          	addi	a1,a1,1176 # 3af0 <buffer>
    1660:	4505                	li	a0,1
    1662:	70d000ef          	jal	ra,256e <write>
	buffer_len = 0;
    1666:	00002797          	auipc	a5,0x2
    166a:	4807a123          	sw	zero,1154(a5) # 3ae8 <buffer_len>
			if (r < 0) {
    166e:	bfd1                	j	1642 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1670:	709000ef          	jal	ra,2578 <getpid>
    1674:	842a                	mv	s0,a0
    1676:	00001517          	auipc	a0,0x1
    167a:	38250513          	addi	a0,a0,898 # 29f8 <enable_deadlock_detect+0x1b2>
    167e:	5d1000ef          	jal	ra,244e <basename>
    1682:	872a                	mv	a4,a0
    1684:	00001617          	auipc	a2,0x1
    1688:	27460613          	addi	a2,a2,628 # 28f8 <enable_deadlock_detect+0xb2>
    168c:	05400793          	li	a5,84
    1690:	86a2                	mv	a3,s0
    1692:	45fd                	li	a1,31
    1694:	00001517          	auipc	a0,0x1
    1698:	3a450513          	addi	a0,a0,932 # 2a38 <enable_deadlock_detect+0x1f2>
    169c:	cabff0ef          	jal	ra,1346 <printf>
    16a0:	557d                	li	a0,-1
    16a2:	707000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    16a6:	000a2603          	lw	a2,0(s4)
    16aa:	de41                	beqz	a2,1642 <printf+0x2fc>
    16ac:	b775                	j	1658 <printf+0x312>
		mutex_lock(buffer_lock);
    16ae:	10ca2503          	lw	a0,268(s4)
    16b2:	134010ef          	jal	ra,27e6 <mutex_lock>
		buffer[buffer_len++] = c;
    16b6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ba:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16be:	0017861b          	addiw	a2,a5,1
    16c2:	97d2                	add	a5,a5,s4
    16c4:	00ca2023          	sw	a2,0(s4)
    16c8:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16cc:	02c6d163          	bge	a3,a2,16ee <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    16d0:	10000793          	li	a5,256
    16d4:	02f61263          	bne	a2,a5,16f8 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    16d8:	00002597          	auipc	a1,0x2
    16dc:	41858593          	addi	a1,a1,1048 # 3af0 <buffer>
    16e0:	4505                	li	a0,1
    16e2:	68d000ef          	jal	ra,256e <write>
	buffer_len = 0;
    16e6:	00002797          	auipc	a5,0x2
    16ea:	4007a123          	sw	zero,1026(a5) # 3ae8 <buffer_len>
		mutex_unlock(buffer_lock);
    16ee:	10ca2503          	lw	a0,268(s4)
    16f2:	100010ef          	jal	ra,27f2 <mutex_unlock>
    16f6:	bdd9                	j	15cc <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    16f8:	681000ef          	jal	ra,2578 <getpid>
    16fc:	842a                	mv	s0,a0
    16fe:	00001517          	auipc	a0,0x1
    1702:	2fa50513          	addi	a0,a0,762 # 29f8 <enable_deadlock_detect+0x1b2>
    1706:	549000ef          	jal	ra,244e <basename>
    170a:	872a                	mv	a4,a0
    170c:	00001617          	auipc	a2,0x1
    1710:	1ec60613          	addi	a2,a2,492 # 28f8 <enable_deadlock_detect+0xb2>
    1714:	05400793          	li	a5,84
    1718:	86a2                	mv	a3,s0
    171a:	45fd                	li	a1,31
    171c:	00001517          	auipc	a0,0x1
    1720:	31c50513          	addi	a0,a0,796 # 2a38 <enable_deadlock_detect+0x1f2>
    1724:	c23ff0ef          	jal	ra,1346 <printf>
    1728:	557d                	li	a0,-1
    172a:	67f000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    172e:	000a2603          	lw	a2,0(s4)
    1732:	de55                	beqz	a2,16ee <printf+0x3a8>
    1734:	b755                	j	16d8 <printf+0x392>
		mutex_lock(buffer_lock);
    1736:	10ca2503          	lw	a0,268(s4)
    173a:	e42e                	sd	a1,8(sp)
		s += 2;
    173c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1740:	0a6010ef          	jal	ra,27e6 <mutex_lock>
		len = out_unlocked(s, l);
    1744:	65a2                	ld	a1,8(sp)
    1746:	8522                	mv	a0,s0
    1748:	08a000ef          	jal	ra,17d2 <out_unlocked>
		mutex_unlock(buffer_lock);
    174c:	10ca2503          	lw	a0,268(s4)
    1750:	0a2010ef          	jal	ra,27f2 <mutex_unlock>
		s += 2;
    1754:	bb55                	j	1508 <printf+0x1c2>
				a = "(null)";
    1756:	00001417          	auipc	s0,0x1
    175a:	29a40413          	addi	s0,s0,666 # 29f0 <enable_deadlock_detect+0x1aa>
    175e:	bd2d                	j	1598 <printf+0x252>

0000000000001760 <enable_thread_io_buffer>:
{
    1760:	1101                	addi	sp,sp,-32
    1762:	e822                	sd	s0,16(sp)
    1764:	ec06                	sd	ra,24(sp)
    1766:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1768:	00002417          	auipc	s0,0x2
    176c:	38040413          	addi	s0,s0,896 # 3ae8 <buffer_len>
    1770:	05a010ef          	jal	ra,27ca <mutex_create>
    1774:	10a42623          	sw	a0,268(s0)
    1778:	00054a63          	bltz	a0,178c <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    177c:	4785                	li	a5,1
}
    177e:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1780:	10f42423          	sw	a5,264(s0)
}
    1784:	6442                	ld	s0,16(sp)
    1786:	64a2                	ld	s1,8(sp)
    1788:	6105                	addi	sp,sp,32
    178a:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    178c:	5ed000ef          	jal	ra,2578 <getpid>
    1790:	84aa                	mv	s1,a0
    1792:	00001517          	auipc	a0,0x1
    1796:	26650513          	addi	a0,a0,614 # 29f8 <enable_deadlock_detect+0x1b2>
    179a:	4b5000ef          	jal	ra,244e <basename>
    179e:	872a                	mv	a4,a0
    17a0:	04800793          	li	a5,72
    17a4:	86a6                	mv	a3,s1
    17a6:	00001517          	auipc	a0,0x1
    17aa:	2d250513          	addi	a0,a0,722 # 2a78 <enable_deadlock_detect+0x232>
    17ae:	00001617          	auipc	a2,0x1
    17b2:	14a60613          	addi	a2,a2,330 # 28f8 <enable_deadlock_detect+0xb2>
    17b6:	45fd                	li	a1,31
    17b8:	b8fff0ef          	jal	ra,1346 <printf>
    17bc:	557d                	li	a0,-1
    17be:	5eb000ef          	jal	ra,25a8 <exit>
	buffer_lock_enabled = 1;
    17c2:	4785                	li	a5,1
}
    17c4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17c6:	10f42423          	sw	a5,264(s0)
}
    17ca:	6442                	ld	s0,16(sp)
    17cc:	64a2                	ld	s1,8(sp)
    17ce:	6105                	addi	sp,sp,32
    17d0:	8082                	ret

00000000000017d2 <out_unlocked>:
{
    17d2:	7159                	addi	sp,sp,-112
    17d4:	f486                	sd	ra,104(sp)
    17d6:	f0a2                	sd	s0,96(sp)
    17d8:	eca6                	sd	s1,88(sp)
    17da:	e8ca                	sd	s2,80(sp)
    17dc:	e4ce                	sd	s3,72(sp)
    17de:	e0d2                	sd	s4,64(sp)
    17e0:	fc56                	sd	s5,56(sp)
    17e2:	f85a                	sd	s6,48(sp)
    17e4:	f45e                	sd	s7,40(sp)
    17e6:	f062                	sd	s8,32(sp)
    17e8:	ec66                	sd	s9,24(sp)
    17ea:	e86a                	sd	s10,16(sp)
    17ec:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    17ee:	0e058663          	beqz	a1,18da <out_unlocked+0x108>
    17f2:	842a                	mv	s0,a0
    17f4:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    17f8:	4981                	li	s3,0
    17fa:	00002d17          	auipc	s10,0x2
    17fe:	2eed0d13          	addi	s10,s10,750 # 3ae8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1802:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1806:	00002b17          	auipc	s6,0x2
    180a:	2eab0b13          	addi	s6,s6,746 # 3af0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    180e:	10000a93          	li	s5,256
    1812:	00001c97          	auipc	s9,0x1
    1816:	1e6c8c93          	addi	s9,s9,486 # 29f8 <enable_deadlock_detect+0x1b2>
    181a:	00001c17          	auipc	s8,0x1
    181e:	0dec0c13          	addi	s8,s8,222 # 28f8 <enable_deadlock_detect+0xb2>
    1822:	00001b97          	auipc	s7,0x1
    1826:	216b8b93          	addi	s7,s7,534 # 2a38 <enable_deadlock_detect+0x1f2>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    182a:	4a29                	li	s4,10
    182c:	a031                	j	1838 <out_unlocked+0x66>
    182e:	09468863          	beq	a3,s4,18be <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1832:	0405                	addi	s0,s0,1
    1834:	04848163          	beq	s1,s0,1876 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1838:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    183c:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1840:	0017861b          	addiw	a2,a5,1
    1844:	97ea                	add	a5,a5,s10
    1846:	00cd2023          	sw	a2,0(s10)
    184a:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    184e:	fec950e3          	bge	s2,a2,182e <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1852:	05561263          	bne	a2,s5,1896 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1856:	85da                	mv	a1,s6
    1858:	4505                	li	a0,1
    185a:	515000ef          	jal	ra,256e <write>
    185e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1860:	00002797          	auipc	a5,0x2
    1864:	2807a423          	sw	zero,648(a5) # 3ae8 <buffer_len>
			if (r < 0) {
    1868:	06054763          	bltz	a0,18d6 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    186c:	0405                	addi	s0,s0,1
			ret += r;
    186e:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1872:	fc8493e3          	bne	s1,s0,1838 <out_unlocked+0x66>
}
    1876:	70a6                	ld	ra,104(sp)
    1878:	7406                	ld	s0,96(sp)
    187a:	64e6                	ld	s1,88(sp)
    187c:	6946                	ld	s2,80(sp)
    187e:	6a06                	ld	s4,64(sp)
    1880:	7ae2                	ld	s5,56(sp)
    1882:	7b42                	ld	s6,48(sp)
    1884:	7ba2                	ld	s7,40(sp)
    1886:	7c02                	ld	s8,32(sp)
    1888:	6ce2                	ld	s9,24(sp)
    188a:	6d42                	ld	s10,16(sp)
    188c:	6da2                	ld	s11,8(sp)
    188e:	854e                	mv	a0,s3
    1890:	69a6                	ld	s3,72(sp)
    1892:	6165                	addi	sp,sp,112
    1894:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1896:	4e3000ef          	jal	ra,2578 <getpid>
    189a:	8daa                	mv	s11,a0
    189c:	8566                	mv	a0,s9
    189e:	3b1000ef          	jal	ra,244e <basename>
    18a2:	872a                	mv	a4,a0
    18a4:	8662                	mv	a2,s8
    18a6:	05400793          	li	a5,84
    18aa:	86ee                	mv	a3,s11
    18ac:	45fd                	li	a1,31
    18ae:	855e                	mv	a0,s7
    18b0:	a97ff0ef          	jal	ra,1346 <printf>
    18b4:	557d                	li	a0,-1
    18b6:	4f3000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    18ba:	000d2603          	lw	a2,0(s10)
    18be:	da35                	beqz	a2,1832 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    18c0:	85da                	mv	a1,s6
    18c2:	4505                	li	a0,1
    18c4:	4ab000ef          	jal	ra,256e <write>
    18c8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18ca:	00002797          	auipc	a5,0x2
    18ce:	2007af23          	sw	zero,542(a5) # 3ae8 <buffer_len>
			if (r < 0) {
    18d2:	f8055de3          	bgez	a0,186c <out_unlocked+0x9a>
    18d6:	89aa                	mv	s3,a0
    18d8:	bf79                	j	1876 <out_unlocked+0xa4>
	int ret = 0;
    18da:	4981                	li	s3,0
    18dc:	bf69                	j	1876 <out_unlocked+0xa4>

00000000000018de <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    18de:	1101                	addi	sp,sp,-32
    18e0:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    18e2:	00002497          	auipc	s1,0x2
    18e6:	20648493          	addi	s1,s1,518 # 3ae8 <buffer_len>
    18ea:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    18ec:	ec06                	sd	ra,24(sp)
    18ee:	e822                	sd	s0,16(sp)
		char c = s[i];
    18f0:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    18f4:	0017861b          	addiw	a2,a5,1
    18f8:	97a6                	add	a5,a5,s1
    18fa:	00e78423          	sb	a4,8(a5)
    18fe:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1900:	0ff00793          	li	a5,255
    1904:	00c7cc63          	blt	a5,a2,191c <out_unlocked.constprop.0+0x3e>
    1908:	47a9                	li	a5,10
    190a:	06f70c63          	beq	a4,a5,1982 <out_unlocked.constprop.0+0xa4>
    190e:	4601                	li	a2,0
}
    1910:	60e2                	ld	ra,24(sp)
    1912:	6442                	ld	s0,16(sp)
    1914:	64a2                	ld	s1,8(sp)
    1916:	8532                	mv	a0,a2
    1918:	6105                	addi	sp,sp,32
    191a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    191c:	10000793          	li	a5,256
    1920:	02f61563          	bne	a2,a5,194a <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1924:	00002597          	auipc	a1,0x2
    1928:	1cc58593          	addi	a1,a1,460 # 3af0 <buffer>
    192c:	4505                	li	a0,1
    192e:	441000ef          	jal	ra,256e <write>
}
    1932:	60e2                	ld	ra,24(sp)
    1934:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1936:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    193a:	00002797          	auipc	a5,0x2
    193e:	1a07a723          	sw	zero,430(a5) # 3ae8 <buffer_len>
}
    1942:	64a2                	ld	s1,8(sp)
    1944:	8532                	mv	a0,a2
    1946:	6105                	addi	sp,sp,32
    1948:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    194a:	42f000ef          	jal	ra,2578 <getpid>
    194e:	842a                	mv	s0,a0
    1950:	00001517          	auipc	a0,0x1
    1954:	0a850513          	addi	a0,a0,168 # 29f8 <enable_deadlock_detect+0x1b2>
    1958:	2f7000ef          	jal	ra,244e <basename>
    195c:	872a                	mv	a4,a0
    195e:	00001617          	auipc	a2,0x1
    1962:	f9a60613          	addi	a2,a2,-102 # 28f8 <enable_deadlock_detect+0xb2>
    1966:	05400793          	li	a5,84
    196a:	86a2                	mv	a3,s0
    196c:	45fd                	li	a1,31
    196e:	00001517          	auipc	a0,0x1
    1972:	0ca50513          	addi	a0,a0,202 # 2a38 <enable_deadlock_detect+0x1f2>
    1976:	9d1ff0ef          	jal	ra,1346 <printf>
    197a:	557d                	li	a0,-1
    197c:	42d000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    1980:	4090                	lw	a2,0(s1)
    1982:	d659                	beqz	a2,1910 <out_unlocked.constprop.0+0x32>
    1984:	b745                	j	1924 <out_unlocked.constprop.0+0x46>

0000000000001986 <putchar>:
{
    1986:	7139                	addi	sp,sp,-64
    1988:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    198a:	00002497          	auipc	s1,0x2
    198e:	15e48493          	addi	s1,s1,350 # 3ae8 <buffer_len>
    1992:	1084a703          	lw	a4,264(s1)
{
    1996:	f822                	sd	s0,48(sp)
	char byte = c;
    1998:	0ff57413          	zext.b	s0,a0
{
    199c:	fc06                	sd	ra,56(sp)
	char byte = c;
    199e:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    19a2:	4785                	li	a5,1
    19a4:	00f70d63          	beq	a4,a5,19be <putchar+0x38>
		len = out_unlocked(s, l);
    19a8:	01f10513          	addi	a0,sp,31
    19ac:	f33ff0ef          	jal	ra,18de <out_unlocked.constprop.0>
}
    19b0:	70e2                	ld	ra,56(sp)
    19b2:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    19b4:	862a                	mv	a2,a0
}
    19b6:	74a2                	ld	s1,40(sp)
    19b8:	8532                	mv	a0,a2
    19ba:	6121                	addi	sp,sp,64
    19bc:	8082                	ret
		mutex_lock(buffer_lock);
    19be:	10c4a503          	lw	a0,268(s1)
    19c2:	625000ef          	jal	ra,27e6 <mutex_lock>
		buffer[buffer_len++] = c;
    19c6:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19c8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19cc:	0017861b          	addiw	a2,a5,1
    19d0:	97a6                	add	a5,a5,s1
    19d2:	c090                	sw	a2,0(s1)
    19d4:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d8:	02c6c263          	blt	a3,a2,19fc <putchar+0x76>
    19dc:	47a9                	li	a5,10
    19de:	06f40d63          	beq	s0,a5,1a58 <putchar+0xd2>
    19e2:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    19e4:	10c4a503          	lw	a0,268(s1)
    19e8:	e432                	sd	a2,8(sp)
    19ea:	609000ef          	jal	ra,27f2 <mutex_unlock>
    19ee:	6622                	ld	a2,8(sp)
}
    19f0:	70e2                	ld	ra,56(sp)
    19f2:	7442                	ld	s0,48(sp)
    19f4:	74a2                	ld	s1,40(sp)
    19f6:	8532                	mv	a0,a2
    19f8:	6121                	addi	sp,sp,64
    19fa:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19fc:	10000793          	li	a5,256
    1a00:	02f61063          	bne	a2,a5,1a20 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a04:	00002597          	auipc	a1,0x2
    1a08:	0ec58593          	addi	a1,a1,236 # 3af0 <buffer>
    1a0c:	4505                	li	a0,1
    1a0e:	361000ef          	jal	ra,256e <write>
    1a12:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a16:	00002797          	auipc	a5,0x2
    1a1a:	0c07a923          	sw	zero,210(a5) # 3ae8 <buffer_len>
			if (r < 0) {
    1a1e:	b7d9                	j	19e4 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a20:	359000ef          	jal	ra,2578 <getpid>
    1a24:	842a                	mv	s0,a0
    1a26:	00001517          	auipc	a0,0x1
    1a2a:	fd250513          	addi	a0,a0,-46 # 29f8 <enable_deadlock_detect+0x1b2>
    1a2e:	221000ef          	jal	ra,244e <basename>
    1a32:	872a                	mv	a4,a0
    1a34:	00001617          	auipc	a2,0x1
    1a38:	ec460613          	addi	a2,a2,-316 # 28f8 <enable_deadlock_detect+0xb2>
    1a3c:	05400793          	li	a5,84
    1a40:	86a2                	mv	a3,s0
    1a42:	45fd                	li	a1,31
    1a44:	00001517          	auipc	a0,0x1
    1a48:	ff450513          	addi	a0,a0,-12 # 2a38 <enable_deadlock_detect+0x1f2>
    1a4c:	8fbff0ef          	jal	ra,1346 <printf>
    1a50:	557d                	li	a0,-1
    1a52:	357000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    1a56:	4090                	lw	a2,0(s1)
    1a58:	d651                	beqz	a2,19e4 <putchar+0x5e>
    1a5a:	b76d                	j	1a04 <putchar+0x7e>

0000000000001a5c <puts>:
{
    1a5c:	7139                	addi	sp,sp,-64
    1a5e:	f822                	sd	s0,48(sp)
    1a60:	f426                	sd	s1,40(sp)
    1a62:	fc06                	sd	ra,56(sp)
    1a64:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a66:	00002417          	auipc	s0,0x2
    1a6a:	08240413          	addi	s0,s0,130 # 3ae8 <buffer_len>
{
    1a6e:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a70:	638000ef          	jal	ra,20a8 <strlen>
	if (buffer_lock_enabled == 1) {
    1a74:	10842703          	lw	a4,264(s0)
    1a78:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a7a:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1a7c:	04f70563          	beq	a4,a5,1ac6 <puts+0x6a>
		len = out_unlocked(s, l);
    1a80:	8526                	mv	a0,s1
    1a82:	d51ff0ef          	jal	ra,17d2 <out_unlocked>
    1a86:	892a                	mv	s2,a0
    1a88:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a8a:	00095963          	bgez	s2,1a9c <puts+0x40>
}
    1a8e:	70e2                	ld	ra,56(sp)
    1a90:	7442                	ld	s0,48(sp)
    1a92:	7902                	ld	s2,32(sp)
    1a94:	8526                	mv	a0,s1
    1a96:	74a2                	ld	s1,40(sp)
    1a98:	6121                	addi	sp,sp,64
    1a9a:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a9c:	10842703          	lw	a4,264(s0)
	char byte = c;
    1aa0:	44a9                	li	s1,10
    1aa2:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1aa6:	4785                	li	a5,1
    1aa8:	02f70e63          	beq	a4,a5,1ae4 <puts+0x88>
		len = out_unlocked(s, l);
    1aac:	01f10513          	addi	a0,sp,31
    1ab0:	e2fff0ef          	jal	ra,18de <out_unlocked.constprop.0>
}
    1ab4:	70e2                	ld	ra,56(sp)
    1ab6:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ab8:	41f5549b          	sraiw	s1,a0,0x1f
}
    1abc:	7902                	ld	s2,32(sp)
    1abe:	8526                	mv	a0,s1
    1ac0:	74a2                	ld	s1,40(sp)
    1ac2:	6121                	addi	sp,sp,64
    1ac4:	8082                	ret
		mutex_lock(buffer_lock);
    1ac6:	e42a                	sd	a0,8(sp)
    1ac8:	10c42503          	lw	a0,268(s0)
    1acc:	51b000ef          	jal	ra,27e6 <mutex_lock>
		len = out_unlocked(s, l);
    1ad0:	65a2                	ld	a1,8(sp)
    1ad2:	8526                	mv	a0,s1
    1ad4:	cffff0ef          	jal	ra,17d2 <out_unlocked>
    1ad8:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1ada:	10c42503          	lw	a0,268(s0)
    1ade:	515000ef          	jal	ra,27f2 <mutex_unlock>
    1ae2:	b75d                	j	1a88 <puts+0x2c>
		mutex_lock(buffer_lock);
    1ae4:	10c42503          	lw	a0,268(s0)
    1ae8:	4ff000ef          	jal	ra,27e6 <mutex_lock>
		buffer[buffer_len++] = c;
    1aec:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1aee:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1af2:	0017861b          	addiw	a2,a5,1
    1af6:	97a2                	add	a5,a5,s0
    1af8:	c010                	sw	a2,0(s0)
    1afa:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1afe:	06c6dc63          	bge	a3,a2,1b76 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b02:	10000793          	li	a5,256
    1b06:	02f61c63          	bne	a2,a5,1b3e <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b0a:	00002597          	auipc	a1,0x2
    1b0e:	fe658593          	addi	a1,a1,-26 # 3af0 <buffer>
    1b12:	4505                	li	a0,1
    1b14:	25b000ef          	jal	ra,256e <write>
			if (r < 0) {
    1b18:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b1a:	00002797          	auipc	a5,0x2
    1b1e:	fc07a723          	sw	zero,-50(a5) # 3ae8 <buffer_len>
			if (r < 0) {
    1b22:	04054c63          	bltz	a0,1b7a <puts+0x11e>
			if (r < buffer_len) {
    1b26:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b28:	10c42503          	lw	a0,268(s0)
    1b2c:	4c7000ef          	jal	ra,27f2 <mutex_unlock>
}
    1b30:	70e2                	ld	ra,56(sp)
    1b32:	7442                	ld	s0,48(sp)
    1b34:	7902                	ld	s2,32(sp)
    1b36:	8526                	mv	a0,s1
    1b38:	74a2                	ld	s1,40(sp)
    1b3a:	6121                	addi	sp,sp,64
    1b3c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b3e:	23b000ef          	jal	ra,2578 <getpid>
    1b42:	84aa                	mv	s1,a0
    1b44:	00001517          	auipc	a0,0x1
    1b48:	eb450513          	addi	a0,a0,-332 # 29f8 <enable_deadlock_detect+0x1b2>
    1b4c:	103000ef          	jal	ra,244e <basename>
    1b50:	872a                	mv	a4,a0
    1b52:	00001617          	auipc	a2,0x1
    1b56:	da660613          	addi	a2,a2,-602 # 28f8 <enable_deadlock_detect+0xb2>
    1b5a:	05400793          	li	a5,84
    1b5e:	86a6                	mv	a3,s1
    1b60:	45fd                	li	a1,31
    1b62:	00001517          	auipc	a0,0x1
    1b66:	ed650513          	addi	a0,a0,-298 # 2a38 <enable_deadlock_detect+0x1f2>
    1b6a:	fdcff0ef          	jal	ra,1346 <printf>
    1b6e:	557d                	li	a0,-1
    1b70:	239000ef          	jal	ra,25a8 <exit>
	if (buffer_len == 0)
    1b74:	4010                	lw	a2,0(s0)
    1b76:	da45                	beqz	a2,1b26 <puts+0xca>
    1b78:	bf49                	j	1b0a <puts+0xae>
    1b7a:	54fd                	li	s1,-1
    1b7c:	b775                	j	1b28 <puts+0xcc>

0000000000001b7e <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1b7e:	715d                	addi	sp,sp,-80
    1b80:	e486                	sd	ra,72(sp)
    1b82:	e0a2                	sd	s0,64(sp)
    1b84:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1b86:	14054363          	bltz	a0,1ccc <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1b8a:	02b577bb          	remuw	a5,a0,a1
    1b8e:	00002617          	auipc	a2,0x2
    1b92:	06a60613          	addi	a2,a2,106 # 3bf8 <digits>
	buf[16] = 0;
    1b96:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b9a:	0005871b          	sext.w	a4,a1
    1b9e:	1782                	slli	a5,a5,0x20
    1ba0:	9381                	srli	a5,a5,0x20
    1ba2:	97b2                	add	a5,a5,a2
    1ba4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ba8:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1bac:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1bb0:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1bb2:	0eb56763          	bltu	a0,a1,1ca0 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bb6:	02e877bb          	remuw	a5,a6,a4
    1bba:	1782                	slli	a5,a5,0x20
    1bbc:	9381                	srli	a5,a5,0x20
    1bbe:	97b2                	add	a5,a5,a2
    1bc0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bc4:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1bc8:	02f10323          	sb	a5,38(sp)
    1bcc:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1bce:	0ce86963          	bltu	a6,a4,1ca0 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bd2:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1bd6:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1bda:	1582                	slli	a1,a1,0x20
    1bdc:	9181                	srli	a1,a1,0x20
    1bde:	95b2                	add	a1,a1,a2
    1be0:	0005c583          	lbu	a1,0(a1)
    1be4:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1be8:	0007859b          	sext.w	a1,a5
    1bec:	16e6e563          	bltu	a3,a4,1d56 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1bf0:	02e7f6bb          	remuw	a3,a5,a4
    1bf4:	1682                	slli	a3,a3,0x20
    1bf6:	9281                	srli	a3,a3,0x20
    1bf8:	96b2                	add	a3,a3,a2
    1bfa:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bfe:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c02:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c06:	16e5e163          	bltu	a1,a4,1d68 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c0a:	02e876bb          	remuw	a3,a6,a4
    1c0e:	1682                	slli	a3,a3,0x20
    1c10:	9281                	srli	a3,a3,0x20
    1c12:	96b2                	add	a3,a3,a2
    1c14:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c18:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c1c:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c20:	14e86d63          	bltu	a6,a4,1d7a <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c24:	02e5f6bb          	remuw	a3,a1,a4
    1c28:	1682                	slli	a3,a3,0x20
    1c2a:	9281                	srli	a3,a3,0x20
    1c2c:	96b2                	add	a3,a3,a2
    1c2e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c32:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c36:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1c3a:	10e5e563          	bltu	a1,a4,1d44 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1c3e:	02e876bb          	remuw	a3,a6,a4
    1c42:	1682                	slli	a3,a3,0x20
    1c44:	9281                	srli	a3,a3,0x20
    1c46:	96b2                	add	a3,a3,a2
    1c48:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c4c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c50:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c54:	14e86263          	bltu	a6,a4,1d98 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c58:	02e5f6bb          	remuw	a3,a1,a4
    1c5c:	1682                	slli	a3,a3,0x20
    1c5e:	9281                	srli	a3,a3,0x20
    1c60:	96b2                	add	a3,a3,a2
    1c62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c66:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c6a:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c6e:	14e5e463          	bltu	a1,a4,1db6 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1c72:	02e876bb          	remuw	a3,a6,a4
    1c76:	1682                	slli	a3,a3,0x20
    1c78:	9281                	srli	a3,a3,0x20
    1c7a:	96b2                	add	a3,a3,a2
    1c7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c80:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1c84:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1c88:	14e86063          	bltu	a6,a4,1dc8 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1c8c:	1782                	slli	a5,a5,0x20
    1c8e:	9381                	srli	a5,a5,0x20
    1c90:	97b2                	add	a5,a5,a2
    1c92:	0007c703          	lbu	a4,0(a5)
    1c96:	4799                	li	a5,6
    1c98:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c9c:	10054763          	bltz	a0,1daa <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1ca0:	00002497          	auipc	s1,0x2
    1ca4:	e4848493          	addi	s1,s1,-440 # 3ae8 <buffer_len>
    1ca8:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1cac:	0828                	addi	a0,sp,24
    1cae:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1cb0:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1cb2:	00f50433          	add	s0,a0,a5
    1cb6:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1cb8:	06e68463          	beq	a3,a4,1d20 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1cbc:	8522                	mv	a0,s0
    1cbe:	b15ff0ef          	jal	ra,17d2 <out_unlocked>
}
    1cc2:	60a6                	ld	ra,72(sp)
    1cc4:	6406                	ld	s0,64(sp)
    1cc6:	74e2                	ld	s1,56(sp)
    1cc8:	6161                	addi	sp,sp,80
    1cca:	8082                	ret
		x = -xx;
    1ccc:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1cd0:	02b877bb          	remuw	a5,a6,a1
    1cd4:	00002617          	auipc	a2,0x2
    1cd8:	f2460613          	addi	a2,a2,-220 # 3bf8 <digits>
	buf[16] = 0;
    1cdc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ce0:	0005871b          	sext.w	a4,a1
    1ce4:	1782                	slli	a5,a5,0x20
    1ce6:	9381                	srli	a5,a5,0x20
    1ce8:	97b2                	add	a5,a5,a2
    1cea:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cee:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1cf2:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1cf6:	08b86b63          	bltu	a6,a1,1d8c <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1cfa:	02e8f7bb          	remuw	a5,a7,a4
    1cfe:	1782                	slli	a5,a5,0x20
    1d00:	9381                	srli	a5,a5,0x20
    1d02:	97b2                	add	a5,a5,a2
    1d04:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d08:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d0c:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d10:	ece8f1e3          	bgeu	a7,a4,1bd2 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d14:	02d00793          	li	a5,45
    1d18:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d1c:	47b5                	li	a5,13
    1d1e:	b749                	j	1ca0 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d20:	10c4a503          	lw	a0,268(s1)
    1d24:	e42e                	sd	a1,8(sp)
    1d26:	2c1000ef          	jal	ra,27e6 <mutex_lock>
		len = out_unlocked(s, l);
    1d2a:	65a2                	ld	a1,8(sp)
    1d2c:	8522                	mv	a0,s0
    1d2e:	aa5ff0ef          	jal	ra,17d2 <out_unlocked>
		mutex_unlock(buffer_lock);
    1d32:	10c4a503          	lw	a0,268(s1)
    1d36:	2bd000ef          	jal	ra,27f2 <mutex_unlock>
}
    1d3a:	60a6                	ld	ra,72(sp)
    1d3c:	6406                	ld	s0,64(sp)
    1d3e:	74e2                	ld	s1,56(sp)
    1d40:	6161                	addi	sp,sp,80
    1d42:	8082                	ret
		buf[i--] = digits[x % base];
    1d44:	47a9                	li	a5,10
	if (sign)
    1d46:	f4055de3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d4a:	02d00793          	li	a5,45
    1d4e:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d52:	47a5                	li	a5,9
    1d54:	b7b1                	j	1ca0 <printint.constprop.0+0x122>
    1d56:	47b5                	li	a5,13
	if (sign)
    1d58:	f40554e3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d5c:	02d00793          	li	a5,45
    1d60:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d64:	47b1                	li	a5,12
    1d66:	bf2d                	j	1ca0 <printint.constprop.0+0x122>
    1d68:	47b1                	li	a5,12
	if (sign)
    1d6a:	f2055be3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d6e:	02d00793          	li	a5,45
    1d72:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d76:	47ad                	li	a5,11
    1d78:	b725                	j	1ca0 <printint.constprop.0+0x122>
    1d7a:	47ad                	li	a5,11
	if (sign)
    1d7c:	f20552e3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d80:	02d00793          	li	a5,45
    1d84:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1d88:	47a9                	li	a5,10
    1d8a:	bf19                	j	1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d8c:	02d00793          	li	a5,45
    1d90:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1d94:	47b9                	li	a5,14
    1d96:	b729                	j	1ca0 <printint.constprop.0+0x122>
    1d98:	47a5                	li	a5,9
	if (sign)
    1d9a:	f00553e3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d9e:	02d00793          	li	a5,45
    1da2:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1da6:	47a1                	li	a5,8
    1da8:	bde5                	j	1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1daa:	02d00793          	li	a5,45
    1dae:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1db2:	4795                	li	a5,5
    1db4:	b5f5                	j	1ca0 <printint.constprop.0+0x122>
    1db6:	47a1                	li	a5,8
	if (sign)
    1db8:	ee0554e3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dbc:	02d00793          	li	a5,45
    1dc0:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1dc4:	479d                	li	a5,7
    1dc6:	bde9                	j	1ca0 <printint.constprop.0+0x122>
    1dc8:	479d                	li	a5,7
	if (sign)
    1dca:	ec055be3          	bgez	a0,1ca0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dce:	02d00793          	li	a5,45
    1dd2:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1dd6:	4799                	li	a5,6
    1dd8:	b5e1                	j	1ca0 <printint.constprop.0+0x122>

0000000000001dda <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1dda:	02000793          	li	a5,32
    1dde:	00f50663          	beq	a0,a5,1dea <isspace+0x10>
    1de2:	355d                	addiw	a0,a0,-9
    1de4:	00553513          	sltiu	a0,a0,5
    1de8:	8082                	ret
    1dea:	4505                	li	a0,1
}
    1dec:	8082                	ret

0000000000001dee <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1dee:	fd05051b          	addiw	a0,a0,-48
}
    1df2:	00a53513          	sltiu	a0,a0,10
    1df6:	8082                	ret

0000000000001df8 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1df8:	02000613          	li	a2,32
    1dfc:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1dfe:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e02:	ff77869b          	addiw	a3,a5,-9
    1e06:	04c78c63          	beq	a5,a2,1e5e <atoi+0x66>
    1e0a:	0007871b          	sext.w	a4,a5
    1e0e:	04d5f863          	bgeu	a1,a3,1e5e <atoi+0x66>
		s++;
	switch (*s) {
    1e12:	02b00693          	li	a3,43
    1e16:	04d78963          	beq	a5,a3,1e68 <atoi+0x70>
    1e1a:	02d00693          	li	a3,45
    1e1e:	06d78263          	beq	a5,a3,1e82 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e22:	fd07061b          	addiw	a2,a4,-48
    1e26:	47a5                	li	a5,9
    1e28:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e2a:	4e01                	li	t3,0
	while (isdigit(*s))
    1e2c:	04c7e963          	bltu	a5,a2,1e7e <atoi+0x86>
	int n = 0, neg = 0;
    1e30:	4501                	li	a0,0
	while (isdigit(*s))
    1e32:	4825                	li	a6,9
    1e34:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1e38:	0025179b          	slliw	a5,a0,0x2
    1e3c:	9fa9                	addw	a5,a5,a0
    1e3e:	fd07031b          	addiw	t1,a4,-48
    1e42:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1e46:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1e4a:	0685                	addi	a3,a3,1
    1e4c:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e50:	0006071b          	sext.w	a4,a2
    1e54:	feb870e3          	bgeu	a6,a1,1e34 <atoi+0x3c>
	return neg ? n : -n;
    1e58:	000e0563          	beqz	t3,1e62 <atoi+0x6a>
}
    1e5c:	8082                	ret
		s++;
    1e5e:	0505                	addi	a0,a0,1
    1e60:	bf79                	j	1dfe <atoi+0x6>
	return neg ? n : -n;
    1e62:	4113053b          	subw	a0,t1,a7
    1e66:	8082                	ret
	while (isdigit(*s))
    1e68:	00154703          	lbu	a4,1(a0)
    1e6c:	47a5                	li	a5,9
		s++;
    1e6e:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e72:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e76:	4e01                	li	t3,0
	while (isdigit(*s))
    1e78:	2701                	sext.w	a4,a4
    1e7a:	fac7fbe3          	bgeu	a5,a2,1e30 <atoi+0x38>
    1e7e:	4501                	li	a0,0
}
    1e80:	8082                	ret
	while (isdigit(*s))
    1e82:	00154703          	lbu	a4,1(a0)
    1e86:	47a5                	li	a5,9
		s++;
    1e88:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e8c:	fd07061b          	addiw	a2,a4,-48
    1e90:	2701                	sext.w	a4,a4
    1e92:	fec7e6e3          	bltu	a5,a2,1e7e <atoi+0x86>
		neg = 1;
    1e96:	4e05                	li	t3,1
    1e98:	bf61                	j	1e30 <atoi+0x38>

0000000000001e9a <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e9a:	16060d63          	beqz	a2,2014 <memset+0x17a>
    1e9e:	40a007b3          	neg	a5,a0
    1ea2:	8b9d                	andi	a5,a5,7
    1ea4:	00778693          	addi	a3,a5,7
    1ea8:	482d                	li	a6,11
    1eaa:	0ff5f713          	zext.b	a4,a1
    1eae:	fff60593          	addi	a1,a2,-1
    1eb2:	1706e263          	bltu	a3,a6,2016 <memset+0x17c>
    1eb6:	16d5ea63          	bltu	a1,a3,202a <memset+0x190>
    1eba:	16078563          	beqz	a5,2024 <memset+0x18a>
    1ebe:	00e50023          	sb	a4,0(a0)
    1ec2:	4685                	li	a3,1
    1ec4:	00150593          	addi	a1,a0,1
    1ec8:	14d78c63          	beq	a5,a3,2020 <memset+0x186>
    1ecc:	00e500a3          	sb	a4,1(a0)
    1ed0:	4689                	li	a3,2
    1ed2:	00250593          	addi	a1,a0,2
    1ed6:	14d78d63          	beq	a5,a3,2030 <memset+0x196>
    1eda:	00e50123          	sb	a4,2(a0)
    1ede:	468d                	li	a3,3
    1ee0:	00350593          	addi	a1,a0,3
    1ee4:	12d78b63          	beq	a5,a3,201a <memset+0x180>
    1ee8:	00e501a3          	sb	a4,3(a0)
    1eec:	4691                	li	a3,4
    1eee:	00450593          	addi	a1,a0,4
    1ef2:	14d78163          	beq	a5,a3,2034 <memset+0x19a>
    1ef6:	00e50223          	sb	a4,4(a0)
    1efa:	4695                	li	a3,5
    1efc:	00550593          	addi	a1,a0,5
    1f00:	12d78c63          	beq	a5,a3,2038 <memset+0x19e>
    1f04:	00e502a3          	sb	a4,5(a0)
    1f08:	469d                	li	a3,7
    1f0a:	00650593          	addi	a1,a0,6
    1f0e:	12d79763          	bne	a5,a3,203c <memset+0x1a2>
    1f12:	00750593          	addi	a1,a0,7
    1f16:	00e50323          	sb	a4,6(a0)
    1f1a:	481d                	li	a6,7
    1f1c:	00871693          	slli	a3,a4,0x8
    1f20:	01071893          	slli	a7,a4,0x10
    1f24:	8ed9                	or	a3,a3,a4
    1f26:	01871313          	slli	t1,a4,0x18
    1f2a:	0116e6b3          	or	a3,a3,a7
    1f2e:	0066e6b3          	or	a3,a3,t1
    1f32:	02071893          	slli	a7,a4,0x20
    1f36:	02871e13          	slli	t3,a4,0x28
    1f3a:	0116e6b3          	or	a3,a3,a7
    1f3e:	40f60333          	sub	t1,a2,a5
    1f42:	03071893          	slli	a7,a4,0x30
    1f46:	01c6e6b3          	or	a3,a3,t3
    1f4a:	0116e6b3          	or	a3,a3,a7
    1f4e:	03871e13          	slli	t3,a4,0x38
    1f52:	97aa                	add	a5,a5,a0
    1f54:	ff837893          	andi	a7,t1,-8
    1f58:	01c6e6b3          	or	a3,a3,t3
    1f5c:	98be                	add	a7,a7,a5
    1f5e:	e394                	sd	a3,0(a5)
    1f60:	07a1                	addi	a5,a5,8
    1f62:	ff179ee3          	bne	a5,a7,1f5e <memset+0xc4>
    1f66:	ff837893          	andi	a7,t1,-8
    1f6a:	011587b3          	add	a5,a1,a7
    1f6e:	010886bb          	addw	a3,a7,a6
    1f72:	0b130663          	beq	t1,a7,201e <memset+0x184>
    1f76:	00e78023          	sb	a4,0(a5)
    1f7a:	0016859b          	addiw	a1,a3,1
    1f7e:	08c5fb63          	bgeu	a1,a2,2014 <memset+0x17a>
    1f82:	00e780a3          	sb	a4,1(a5)
    1f86:	0026859b          	addiw	a1,a3,2
    1f8a:	08c5f563          	bgeu	a1,a2,2014 <memset+0x17a>
    1f8e:	00e78123          	sb	a4,2(a5)
    1f92:	0036859b          	addiw	a1,a3,3
    1f96:	06c5ff63          	bgeu	a1,a2,2014 <memset+0x17a>
    1f9a:	00e781a3          	sb	a4,3(a5)
    1f9e:	0046859b          	addiw	a1,a3,4
    1fa2:	06c5f963          	bgeu	a1,a2,2014 <memset+0x17a>
    1fa6:	00e78223          	sb	a4,4(a5)
    1faa:	0056859b          	addiw	a1,a3,5
    1fae:	06c5f363          	bgeu	a1,a2,2014 <memset+0x17a>
    1fb2:	00e782a3          	sb	a4,5(a5)
    1fb6:	0066859b          	addiw	a1,a3,6
    1fba:	04c5fd63          	bgeu	a1,a2,2014 <memset+0x17a>
    1fbe:	00e78323          	sb	a4,6(a5)
    1fc2:	0076859b          	addiw	a1,a3,7
    1fc6:	04c5f763          	bgeu	a1,a2,2014 <memset+0x17a>
    1fca:	00e783a3          	sb	a4,7(a5)
    1fce:	0086859b          	addiw	a1,a3,8
    1fd2:	04c5f163          	bgeu	a1,a2,2014 <memset+0x17a>
    1fd6:	00e78423          	sb	a4,8(a5)
    1fda:	0096859b          	addiw	a1,a3,9
    1fde:	02c5fb63          	bgeu	a1,a2,2014 <memset+0x17a>
    1fe2:	00e784a3          	sb	a4,9(a5)
    1fe6:	00a6859b          	addiw	a1,a3,10
    1fea:	02c5f563          	bgeu	a1,a2,2014 <memset+0x17a>
    1fee:	00e78523          	sb	a4,10(a5)
    1ff2:	00b6859b          	addiw	a1,a3,11
    1ff6:	00c5ff63          	bgeu	a1,a2,2014 <memset+0x17a>
    1ffa:	00e785a3          	sb	a4,11(a5)
    1ffe:	00c6859b          	addiw	a1,a3,12
    2002:	00c5f963          	bgeu	a1,a2,2014 <memset+0x17a>
    2006:	00e78623          	sb	a4,12(a5)
    200a:	26b5                	addiw	a3,a3,13
    200c:	00c6f463          	bgeu	a3,a2,2014 <memset+0x17a>
    2010:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2014:	8082                	ret
    2016:	46ad                	li	a3,11
    2018:	bd79                	j	1eb6 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    201a:	480d                	li	a6,3
    201c:	b701                	j	1f1c <memset+0x82>
    201e:	8082                	ret
    2020:	4805                	li	a6,1
    2022:	bded                	j	1f1c <memset+0x82>
    2024:	85aa                	mv	a1,a0
    2026:	4801                	li	a6,0
    2028:	bdd5                	j	1f1c <memset+0x82>
    202a:	87aa                	mv	a5,a0
    202c:	4681                	li	a3,0
    202e:	b7a1                	j	1f76 <memset+0xdc>
    2030:	4809                	li	a6,2
    2032:	b5ed                	j	1f1c <memset+0x82>
    2034:	4811                	li	a6,4
    2036:	b5dd                	j	1f1c <memset+0x82>
    2038:	4815                	li	a6,5
    203a:	b5cd                	j	1f1c <memset+0x82>
    203c:	4819                	li	a6,6
    203e:	bdf9                	j	1f1c <memset+0x82>

0000000000002040 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2040:	00054783          	lbu	a5,0(a0)
    2044:	0005c703          	lbu	a4,0(a1)
    2048:	00e79863          	bne	a5,a4,2058 <strcmp+0x18>
    204c:	0505                	addi	a0,a0,1
    204e:	0585                	addi	a1,a1,1
    2050:	fbe5                	bnez	a5,2040 <strcmp>
    2052:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2054:	9d19                	subw	a0,a0,a4
    2056:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    2058:	0007851b          	sext.w	a0,a5
    205c:	bfe5                	j	2054 <strcmp+0x14>

000000000000205e <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    205e:	ca15                	beqz	a2,2092 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2060:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2064:	167d                	addi	a2,a2,-1
    2066:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    206a:	eb99                	bnez	a5,2080 <strncmp+0x22>
    206c:	a815                	j	20a0 <strncmp+0x42>
    206e:	00a68e63          	beq	a3,a0,208a <strncmp+0x2c>
    2072:	0505                	addi	a0,a0,1
    2074:	00f71b63          	bne	a4,a5,208a <strncmp+0x2c>
    2078:	00054783          	lbu	a5,0(a0)
    207c:	cf89                	beqz	a5,2096 <strncmp+0x38>
    207e:	85b2                	mv	a1,a2
    2080:	0005c703          	lbu	a4,0(a1)
    2084:	00158613          	addi	a2,a1,1
    2088:	f37d                	bnez	a4,206e <strncmp+0x10>
		;
	return *l - *r;
    208a:	0007851b          	sext.w	a0,a5
    208e:	9d19                	subw	a0,a0,a4
    2090:	8082                	ret
		return 0;
    2092:	4501                	li	a0,0
}
    2094:	8082                	ret
	return *l - *r;
    2096:	0015c703          	lbu	a4,1(a1)
    209a:	4501                	li	a0,0
    209c:	9d19                	subw	a0,a0,a4
    209e:	8082                	ret
    20a0:	0005c703          	lbu	a4,0(a1)
    20a4:	4501                	li	a0,0
    20a6:	b7e5                	j	208e <strncmp+0x30>

00000000000020a8 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    20a8:	00757793          	andi	a5,a0,7
    20ac:	cf89                	beqz	a5,20c6 <strlen+0x1e>
    20ae:	87aa                	mv	a5,a0
    20b0:	a029                	j	20ba <strlen+0x12>
    20b2:	0785                	addi	a5,a5,1
    20b4:	0077f713          	andi	a4,a5,7
    20b8:	cb01                	beqz	a4,20c8 <strlen+0x20>
		if (!*s)
    20ba:	0007c703          	lbu	a4,0(a5)
    20be:	fb75                	bnez	a4,20b2 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    20c0:	40a78533          	sub	a0,a5,a0
}
    20c4:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    20c6:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    20c8:	6394                	ld	a3,0(a5)
    20ca:	00001597          	auipc	a1,0x1
    20ce:	a065b583          	ld	a1,-1530(a1) # 2ad0 <enable_deadlock_detect+0x28a>
    20d2:	00001617          	auipc	a2,0x1
    20d6:	a0663603          	ld	a2,-1530(a2) # 2ad8 <enable_deadlock_detect+0x292>
    20da:	a019                	j	20e0 <strlen+0x38>
    20dc:	6794                	ld	a3,8(a5)
    20de:	07a1                	addi	a5,a5,8
    20e0:	00b68733          	add	a4,a3,a1
    20e4:	fff6c693          	not	a3,a3
    20e8:	8f75                	and	a4,a4,a3
    20ea:	8f71                	and	a4,a4,a2
    20ec:	db65                	beqz	a4,20dc <strlen+0x34>
	for (; *s; s++)
    20ee:	0007c703          	lbu	a4,0(a5)
    20f2:	d779                	beqz	a4,20c0 <strlen+0x18>
    20f4:	0017c703          	lbu	a4,1(a5)
    20f8:	0785                	addi	a5,a5,1
    20fa:	d379                	beqz	a4,20c0 <strlen+0x18>
    20fc:	0017c703          	lbu	a4,1(a5)
    2100:	0785                	addi	a5,a5,1
    2102:	fb6d                	bnez	a4,20f4 <strlen+0x4c>
    2104:	bf75                	j	20c0 <strlen+0x18>

0000000000002106 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2106:	00757713          	andi	a4,a0,7
{
    210a:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    210c:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2110:	cb19                	beqz	a4,2126 <memchr+0x20>
    2112:	ce25                	beqz	a2,218a <memchr+0x84>
    2114:	0007c703          	lbu	a4,0(a5)
    2118:	04b70e63          	beq	a4,a1,2174 <memchr+0x6e>
    211c:	0785                	addi	a5,a5,1
    211e:	0077f713          	andi	a4,a5,7
    2122:	167d                	addi	a2,a2,-1
    2124:	f77d                	bnez	a4,2112 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2126:	4501                	li	a0,0
	if (n && *s != c) {
    2128:	c235                	beqz	a2,218c <memchr+0x86>
    212a:	0007c703          	lbu	a4,0(a5)
    212e:	04b70363          	beq	a4,a1,2174 <memchr+0x6e>
		size_t k = ONES * c;
    2132:	00001517          	auipc	a0,0x1
    2136:	9ae53503          	ld	a0,-1618(a0) # 2ae0 <enable_deadlock_detect+0x29a>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    213a:	471d                	li	a4,7
		size_t k = ONES * c;
    213c:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2140:	02c77a63          	bgeu	a4,a2,2174 <memchr+0x6e>
    2144:	00001897          	auipc	a7,0x1
    2148:	98c8b883          	ld	a7,-1652(a7) # 2ad0 <enable_deadlock_detect+0x28a>
    214c:	00001817          	auipc	a6,0x1
    2150:	98c83803          	ld	a6,-1652(a6) # 2ad8 <enable_deadlock_detect+0x292>
    2154:	431d                	li	t1,7
    2156:	a029                	j	2160 <memchr+0x5a>
		     w++, n -= SS)
    2158:	1661                	addi	a2,a2,-8
    215a:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    215c:	02c37963          	bgeu	t1,a2,218e <memchr+0x88>
    2160:	6398                	ld	a4,0(a5)
    2162:	8f29                	xor	a4,a4,a0
    2164:	011706b3          	add	a3,a4,a7
    2168:	fff74713          	not	a4,a4
    216c:	8f75                	and	a4,a4,a3
    216e:	01077733          	and	a4,a4,a6
    2172:	d37d                	beqz	a4,2158 <memchr+0x52>
{
    2174:	853e                	mv	a0,a5
    2176:	97b2                	add	a5,a5,a2
    2178:	a021                	j	2180 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    217a:	0505                	addi	a0,a0,1
    217c:	00f50763          	beq	a0,a5,218a <memchr+0x84>
    2180:	00054703          	lbu	a4,0(a0)
    2184:	feb71be3          	bne	a4,a1,217a <memchr+0x74>
    2188:	8082                	ret
	return n ? (void *)s : 0;
    218a:	4501                	li	a0,0
}
    218c:	8082                	ret
	return n ? (void *)s : 0;
    218e:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2190:	f275                	bnez	a2,2174 <memchr+0x6e>
}
    2192:	8082                	ret

0000000000002194 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2194:	1101                	addi	sp,sp,-32
    2196:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2198:	862e                	mv	a2,a1
{
    219a:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    219c:	4581                	li	a1,0
{
    219e:	e426                	sd	s1,8(sp)
    21a0:	ec06                	sd	ra,24(sp)
    21a2:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    21a4:	f63ff0ef          	jal	ra,2106 <memchr>
	return p ? p - s : n;
    21a8:	c519                	beqz	a0,21b6 <strnlen+0x22>
}
    21aa:	60e2                	ld	ra,24(sp)
    21ac:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    21ae:	8d05                	sub	a0,a0,s1
}
    21b0:	64a2                	ld	s1,8(sp)
    21b2:	6105                	addi	sp,sp,32
    21b4:	8082                	ret
    21b6:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    21b8:	8522                	mv	a0,s0
}
    21ba:	6442                	ld	s0,16(sp)
    21bc:	64a2                	ld	s1,8(sp)
    21be:	6105                	addi	sp,sp,32
    21c0:	8082                	ret

00000000000021c2 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    21c2:	00a5c7b3          	xor	a5,a1,a0
    21c6:	8b9d                	andi	a5,a5,7
    21c8:	eb95                	bnez	a5,21fc <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    21ca:	0075f793          	andi	a5,a1,7
    21ce:	e7b1                	bnez	a5,221a <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    21d0:	6198                	ld	a4,0(a1)
    21d2:	00001617          	auipc	a2,0x1
    21d6:	8fe63603          	ld	a2,-1794(a2) # 2ad0 <enable_deadlock_detect+0x28a>
    21da:	00001817          	auipc	a6,0x1
    21de:	8fe83803          	ld	a6,-1794(a6) # 2ad8 <enable_deadlock_detect+0x292>
    21e2:	a029                	j	21ec <stpcpy+0x2a>
    21e4:	05a1                	addi	a1,a1,8
    21e6:	e118                	sd	a4,0(a0)
    21e8:	6198                	ld	a4,0(a1)
    21ea:	0521                	addi	a0,a0,8
    21ec:	00c707b3          	add	a5,a4,a2
    21f0:	fff74693          	not	a3,a4
    21f4:	8ff5                	and	a5,a5,a3
    21f6:	0107f7b3          	and	a5,a5,a6
    21fa:	d7ed                	beqz	a5,21e4 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    21fc:	0005c783          	lbu	a5,0(a1)
    2200:	00f50023          	sb	a5,0(a0)
    2204:	c785                	beqz	a5,222c <stpcpy+0x6a>
    2206:	0015c783          	lbu	a5,1(a1)
    220a:	0505                	addi	a0,a0,1
    220c:	0585                	addi	a1,a1,1
    220e:	00f50023          	sb	a5,0(a0)
    2212:	fbf5                	bnez	a5,2206 <stpcpy+0x44>
		;
	return d;
}
    2214:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2216:	0505                	addi	a0,a0,1
    2218:	df45                	beqz	a4,21d0 <stpcpy+0xe>
			if (!(*d = *s))
    221a:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    221e:	0585                	addi	a1,a1,1
    2220:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2224:	00f50023          	sb	a5,0(a0)
    2228:	f7fd                	bnez	a5,2216 <stpcpy+0x54>
}
    222a:	8082                	ret
    222c:	8082                	ret

000000000000222e <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    222e:	00a5c7b3          	xor	a5,a1,a0
    2232:	8b9d                	andi	a5,a5,7
    2234:	1a079863          	bnez	a5,23e4 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2238:	0075f793          	andi	a5,a1,7
    223c:	16078463          	beqz	a5,23a4 <stpncpy+0x176>
    2240:	ea01                	bnez	a2,2250 <stpncpy+0x22>
    2242:	a421                	j	244a <stpncpy+0x21c>
    2244:	167d                	addi	a2,a2,-1
    2246:	0505                	addi	a0,a0,1
    2248:	14070e63          	beqz	a4,23a4 <stpncpy+0x176>
    224c:	1a060863          	beqz	a2,23fc <stpncpy+0x1ce>
    2250:	0005c783          	lbu	a5,0(a1)
    2254:	0585                	addi	a1,a1,1
    2256:	0075f713          	andi	a4,a1,7
    225a:	00f50023          	sb	a5,0(a0)
    225e:	f3fd                	bnez	a5,2244 <stpncpy+0x16>
    2260:	4805                	li	a6,1
    2262:	1a061863          	bnez	a2,2412 <stpncpy+0x1e4>
    2266:	40a007b3          	neg	a5,a0
    226a:	8b9d                	andi	a5,a5,7
    226c:	4681                	li	a3,0
    226e:	18061a63          	bnez	a2,2402 <stpncpy+0x1d4>
    2272:	00778713          	addi	a4,a5,7
    2276:	45ad                	li	a1,11
    2278:	18b76363          	bltu	a4,a1,23fe <stpncpy+0x1d0>
    227c:	1ae6eb63          	bltu	a3,a4,2432 <stpncpy+0x204>
    2280:	1a078363          	beqz	a5,2426 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2284:	00050023          	sb	zero,0(a0)
    2288:	4685                	li	a3,1
    228a:	00150713          	addi	a4,a0,1
    228e:	18d78f63          	beq	a5,a3,242c <stpncpy+0x1fe>
    2292:	000500a3          	sb	zero,1(a0)
    2296:	4689                	li	a3,2
    2298:	00250713          	addi	a4,a0,2
    229c:	18d78e63          	beq	a5,a3,2438 <stpncpy+0x20a>
    22a0:	00050123          	sb	zero,2(a0)
    22a4:	468d                	li	a3,3
    22a6:	00350713          	addi	a4,a0,3
    22aa:	16d78c63          	beq	a5,a3,2422 <stpncpy+0x1f4>
    22ae:	000501a3          	sb	zero,3(a0)
    22b2:	4691                	li	a3,4
    22b4:	00450713          	addi	a4,a0,4
    22b8:	18d78263          	beq	a5,a3,243c <stpncpy+0x20e>
    22bc:	00050223          	sb	zero,4(a0)
    22c0:	4695                	li	a3,5
    22c2:	00550713          	addi	a4,a0,5
    22c6:	16d78d63          	beq	a5,a3,2440 <stpncpy+0x212>
    22ca:	000502a3          	sb	zero,5(a0)
    22ce:	469d                	li	a3,7
    22d0:	00650713          	addi	a4,a0,6
    22d4:	16d79863          	bne	a5,a3,2444 <stpncpy+0x216>
    22d8:	00750713          	addi	a4,a0,7
    22dc:	00050323          	sb	zero,6(a0)
    22e0:	40f80833          	sub	a6,a6,a5
    22e4:	ff887593          	andi	a1,a6,-8
    22e8:	97aa                	add	a5,a5,a0
    22ea:	95be                	add	a1,a1,a5
    22ec:	0007b023          	sd	zero,0(a5)
    22f0:	07a1                	addi	a5,a5,8
    22f2:	feb79de3          	bne	a5,a1,22ec <stpncpy+0xbe>
    22f6:	ff887593          	andi	a1,a6,-8
    22fa:	9ead                	addw	a3,a3,a1
    22fc:	00b707b3          	add	a5,a4,a1
    2300:	12b80863          	beq	a6,a1,2430 <stpncpy+0x202>
    2304:	00078023          	sb	zero,0(a5)
    2308:	0016871b          	addiw	a4,a3,1
    230c:	0ec77863          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2310:	000780a3          	sb	zero,1(a5)
    2314:	0026871b          	addiw	a4,a3,2
    2318:	0ec77263          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    231c:	00078123          	sb	zero,2(a5)
    2320:	0036871b          	addiw	a4,a3,3
    2324:	0cc77c63          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2328:	000781a3          	sb	zero,3(a5)
    232c:	0046871b          	addiw	a4,a3,4
    2330:	0cc77663          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2334:	00078223          	sb	zero,4(a5)
    2338:	0056871b          	addiw	a4,a3,5
    233c:	0cc77063          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2340:	000782a3          	sb	zero,5(a5)
    2344:	0066871b          	addiw	a4,a3,6
    2348:	0ac77a63          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    234c:	00078323          	sb	zero,6(a5)
    2350:	0076871b          	addiw	a4,a3,7
    2354:	0ac77463          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2358:	000783a3          	sb	zero,7(a5)
    235c:	0086871b          	addiw	a4,a3,8
    2360:	08c77e63          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2364:	00078423          	sb	zero,8(a5)
    2368:	0096871b          	addiw	a4,a3,9
    236c:	08c77863          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2370:	000784a3          	sb	zero,9(a5)
    2374:	00a6871b          	addiw	a4,a3,10
    2378:	08c77263          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    237c:	00078523          	sb	zero,10(a5)
    2380:	00b6871b          	addiw	a4,a3,11
    2384:	06c77c63          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2388:	000785a3          	sb	zero,11(a5)
    238c:	00c6871b          	addiw	a4,a3,12
    2390:	06c77663          	bgeu	a4,a2,23fc <stpncpy+0x1ce>
    2394:	00078623          	sb	zero,12(a5)
    2398:	26b5                	addiw	a3,a3,13
    239a:	06c6f163          	bgeu	a3,a2,23fc <stpncpy+0x1ce>
    239e:	000786a3          	sb	zero,13(a5)
    23a2:	8082                	ret
			;
		if (!n || !*s)
    23a4:	c645                	beqz	a2,244c <stpncpy+0x21e>
    23a6:	0005c783          	lbu	a5,0(a1)
    23aa:	ea078be3          	beqz	a5,2260 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    23ae:	479d                	li	a5,7
    23b0:	02c7ff63          	bgeu	a5,a2,23ee <stpncpy+0x1c0>
    23b4:	00000897          	auipc	a7,0x0
    23b8:	71c8b883          	ld	a7,1820(a7) # 2ad0 <enable_deadlock_detect+0x28a>
    23bc:	00000817          	auipc	a6,0x0
    23c0:	71c83803          	ld	a6,1820(a6) # 2ad8 <enable_deadlock_detect+0x292>
    23c4:	431d                	li	t1,7
    23c6:	6198                	ld	a4,0(a1)
    23c8:	011707b3          	add	a5,a4,a7
    23cc:	fff74693          	not	a3,a4
    23d0:	8ff5                	and	a5,a5,a3
    23d2:	0107f7b3          	and	a5,a5,a6
    23d6:	ef81                	bnez	a5,23ee <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    23d8:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    23da:	1661                	addi	a2,a2,-8
    23dc:	05a1                	addi	a1,a1,8
    23de:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    23e0:	fec363e3          	bltu	t1,a2,23c6 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    23e4:	e609                	bnez	a2,23ee <stpncpy+0x1c0>
    23e6:	a08d                	j	2448 <stpncpy+0x21a>
    23e8:	167d                	addi	a2,a2,-1
    23ea:	0505                	addi	a0,a0,1
    23ec:	ca01                	beqz	a2,23fc <stpncpy+0x1ce>
    23ee:	0005c783          	lbu	a5,0(a1)
    23f2:	0585                	addi	a1,a1,1
    23f4:	00f50023          	sb	a5,0(a0)
    23f8:	fbe5                	bnez	a5,23e8 <stpncpy+0x1ba>
		;
tail:
    23fa:	b59d                	j	2260 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    23fc:	8082                	ret
    23fe:	472d                	li	a4,11
    2400:	bdb5                	j	227c <stpncpy+0x4e>
    2402:	00778713          	addi	a4,a5,7
    2406:	45ad                	li	a1,11
    2408:	fff60693          	addi	a3,a2,-1
    240c:	e6b778e3          	bgeu	a4,a1,227c <stpncpy+0x4e>
    2410:	b7fd                	j	23fe <stpncpy+0x1d0>
    2412:	40a007b3          	neg	a5,a0
    2416:	8832                	mv	a6,a2
    2418:	8b9d                	andi	a5,a5,7
    241a:	4681                	li	a3,0
    241c:	e4060be3          	beqz	a2,2272 <stpncpy+0x44>
    2420:	b7cd                	j	2402 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2422:	468d                	li	a3,3
    2424:	bd75                	j	22e0 <stpncpy+0xb2>
    2426:	872a                	mv	a4,a0
    2428:	4681                	li	a3,0
    242a:	bd5d                	j	22e0 <stpncpy+0xb2>
    242c:	4685                	li	a3,1
    242e:	bd4d                	j	22e0 <stpncpy+0xb2>
    2430:	8082                	ret
    2432:	87aa                	mv	a5,a0
    2434:	4681                	li	a3,0
    2436:	b5f9                	j	2304 <stpncpy+0xd6>
    2438:	4689                	li	a3,2
    243a:	b55d                	j	22e0 <stpncpy+0xb2>
    243c:	4691                	li	a3,4
    243e:	b54d                	j	22e0 <stpncpy+0xb2>
    2440:	4695                	li	a3,5
    2442:	bd79                	j	22e0 <stpncpy+0xb2>
    2444:	4699                	li	a3,6
    2446:	bd69                	j	22e0 <stpncpy+0xb2>
    2448:	8082                	ret
    244a:	8082                	ret
    244c:	8082                	ret

000000000000244e <basename>:

char *basename(char *s)
{
    244e:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2450:	c54d                	beqz	a0,24fa <basename+0xac>
    2452:	00054783          	lbu	a5,0(a0)
		return ".";
    2456:	00000517          	auipc	a0,0x0
    245a:	67250513          	addi	a0,a0,1650 # 2ac8 <enable_deadlock_detect+0x282>
	if (!s || !*s)
    245e:	e391                	bnez	a5,2462 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2460:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2462:	0076f713          	andi	a4,a3,7
    2466:	87b6                	mv	a5,a3
    2468:	cf51                	beqz	a4,2504 <basename+0xb6>
    246a:	0785                	addi	a5,a5,1
    246c:	0077f713          	andi	a4,a5,7
    2470:	c729                	beqz	a4,24ba <basename+0x6c>
		if (!*s)
    2472:	0007c703          	lbu	a4,0(a5)
    2476:	fb75                	bnez	a4,246a <basename+0x1c>
	return s - a;
    2478:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    247a:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    247c:	cf8d                	beqz	a5,24b6 <basename+0x68>
    247e:	00f68733          	add	a4,a3,a5
    2482:	02f00593          	li	a1,47
    2486:	a031                	j	2492 <basename+0x44>
		s[i] = 0;
    2488:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    248c:	17fd                	addi	a5,a5,-1
    248e:	177d                	addi	a4,a4,-1
    2490:	c39d                	beqz	a5,24b6 <basename+0x68>
    2492:	00074603          	lbu	a2,0(a4)
    2496:	feb609e3          	beq	a2,a1,2488 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    249a:	02f00613          	li	a2,47
    249e:	a011                	j	24a2 <basename+0x54>
    24a0:	cb99                	beqz	a5,24b6 <basename+0x68>
    24a2:	853e                	mv	a0,a5
    24a4:	17fd                	addi	a5,a5,-1
    24a6:	00f68733          	add	a4,a3,a5
    24aa:	00074703          	lbu	a4,0(a4)
    24ae:	fec719e3          	bne	a4,a2,24a0 <basename+0x52>
	return s + i;
    24b2:	9536                	add	a0,a0,a3
    24b4:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24b6:	8536                	mv	a0,a3
    24b8:	8082                	ret
    24ba:	6390                	ld	a2,0(a5)
    24bc:	00000517          	auipc	a0,0x0
    24c0:	61453503          	ld	a0,1556(a0) # 2ad0 <enable_deadlock_detect+0x28a>
    24c4:	00000597          	auipc	a1,0x0
    24c8:	6145b583          	ld	a1,1556(a1) # 2ad8 <enable_deadlock_detect+0x292>
    24cc:	fff64713          	not	a4,a2
    24d0:	962a                	add	a2,a2,a0
    24d2:	8f71                	and	a4,a4,a2
    24d4:	8f6d                	and	a4,a4,a1
    24d6:	eb11                	bnez	a4,24ea <basename+0x9c>
    24d8:	6790                	ld	a2,8(a5)
    24da:	07a1                	addi	a5,a5,8
    24dc:	00a60733          	add	a4,a2,a0
    24e0:	fff64613          	not	a2,a2
    24e4:	8f71                	and	a4,a4,a2
    24e6:	8f6d                	and	a4,a4,a1
    24e8:	db65                	beqz	a4,24d8 <basename+0x8a>
	for (; *s; s++)
    24ea:	0007c703          	lbu	a4,0(a5)
    24ee:	d749                	beqz	a4,2478 <basename+0x2a>
    24f0:	0017c703          	lbu	a4,1(a5)
    24f4:	0785                	addi	a5,a5,1
    24f6:	ff6d                	bnez	a4,24f0 <basename+0xa2>
    24f8:	b741                	j	2478 <basename+0x2a>
		return ".";
    24fa:	00000517          	auipc	a0,0x0
    24fe:	5ce50513          	addi	a0,a0,1486 # 2ac8 <enable_deadlock_detect+0x282>
    2502:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2504:	6290                	ld	a2,0(a3)
    2506:	00000517          	auipc	a0,0x0
    250a:	5ca53503          	ld	a0,1482(a0) # 2ad0 <enable_deadlock_detect+0x28a>
    250e:	00000597          	auipc	a1,0x0
    2512:	5ca5b583          	ld	a1,1482(a1) # 2ad8 <enable_deadlock_detect+0x292>
    2516:	fff64713          	not	a4,a2
    251a:	962a                	add	a2,a2,a0
    251c:	8f71                	and	a4,a4,a2
    251e:	8f6d                	and	a4,a4,a1
    2520:	df45                	beqz	a4,24d8 <basename+0x8a>
    2522:	b7f9                	j	24f0 <basename+0xa2>

0000000000002524 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2524:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2528:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    252a:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    252e:	2501                	sext.w	a0,a0
    2530:	8082                	ret

0000000000002532 <close>:

int close(int fd)
{
	if (fd == 1) {
    2532:	4785                	li	a5,1
    2534:	00f50863          	beq	a0,a5,2544 <close+0x12>
	register long a7 __asm__("a7") = n;
    2538:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    253c:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2540:	2501                	sext.w	a0,a0
    2542:	8082                	ret
{
    2544:	1101                	addi	sp,sp,-32
    2546:	ec06                	sd	ra,24(sp)
    2548:	e42a                	sd	a0,8(sp)
		__write_buffer();
    254a:	cdffe0ef          	jal	ra,1228 <__write_buffer>
		__clear_buffer();
    254e:	d03fe0ef          	jal	ra,1250 <__clear_buffer>
    2552:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2554:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2558:	00000073          	ecall
}
    255c:	60e2                	ld	ra,24(sp)
    255e:	2501                	sext.w	a0,a0
    2560:	6105                	addi	sp,sp,32
    2562:	8082                	ret

0000000000002564 <read>:
	register long a7 __asm__("a7") = n;
    2564:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2568:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    256c:	8082                	ret

000000000000256e <write>:
	register long a7 __asm__("a7") = n;
    256e:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2572:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2576:	8082                	ret

0000000000002578 <getpid>:
	register long a7 __asm__("a7") = n;
    2578:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    257c:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2580:	2501                	sext.w	a0,a0
    2582:	8082                	ret

0000000000002584 <getppid>:
	register long a7 __asm__("a7") = n;
    2584:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2588:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    258c:	2501                	sext.w	a0,a0
    258e:	8082                	ret

0000000000002590 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2590:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2594:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2598:	2501                	sext.w	a0,a0
    259a:	8082                	ret

000000000000259c <fork>:
	register long a7 __asm__("a7") = n;
    259c:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    25a0:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    25a4:	2501                	sext.w	a0,a0
    25a6:	8082                	ret

00000000000025a8 <exit>:

void exit(int code)
{
    25a8:	1141                	addi	sp,sp,-16
    25aa:	e406                	sd	ra,8(sp)
    25ac:	e022                	sd	s0,0(sp)
    25ae:	842a                	mv	s0,a0
	__write_buffer();
    25b0:	c79fe0ef          	jal	ra,1228 <__write_buffer>
	__clear_buffer();
    25b4:	c9dfe0ef          	jal	ra,1250 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    25b8:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    25bc:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    25be:	00000073          	ecall
	syscall(SYS_exit, code);
}
    25c2:	60a2                	ld	ra,8(sp)
    25c4:	6402                	ld	s0,0(sp)
    25c6:	0141                	addi	sp,sp,16
    25c8:	8082                	ret

00000000000025ca <waitpid>:
	register long a7 __asm__("a7") = n;
    25ca:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ce:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    25d2:	2501                	sext.w	a0,a0
    25d4:	8082                	ret

00000000000025d6 <exec>:
	register long a7 __asm__("a7") = n;
    25d6:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25da:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret

00000000000025e2 <get_mtime>:

int64 get_mtime()
{
    25e2:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    25e4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25e8:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    25ea:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ec:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    25f0:	2501                	sext.w	a0,a0
    25f2:	ed01                	bnez	a0,260a <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    25f4:	6722                	ld	a4,8(sp)
    25f6:	3e800793          	li	a5,1000
    25fa:	6682                	ld	a3,0(sp)
    25fc:	02f75733          	divu	a4,a4,a5
    2600:	02d78533          	mul	a0,a5,a3
    2604:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2606:	0141                	addi	sp,sp,16
    2608:	8082                	ret
	return -1;
    260a:	557d                	li	a0,-1
    260c:	bfed                	j	2606 <get_mtime+0x24>

000000000000260e <sys_get_time>:
	register long a7 __asm__("a7") = n;
    260e:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2612:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2616:	2501                	sext.w	a0,a0
    2618:	8082                	ret

000000000000261a <sleep>:

int sleep(unsigned long long time)
{
    261a:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    261c:	880a                	mv	a6,sp
{
    261e:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2620:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2624:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2626:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2628:	00000073          	ecall
	if (err == 0) {
    262c:	2501                	sext.w	a0,a0
    262e:	ed31                	bnez	a0,268a <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2630:	6722                	ld	a4,8(sp)
    2632:	3e800793          	li	a5,1000
    2636:	6682                	ld	a3,0(sp)
    2638:	02f75733          	divu	a4,a4,a5
    263c:	02d787b3          	mul	a5,a5,a3
    2640:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2642:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2646:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2648:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    264a:	00000073          	ecall
	if (err == 0) {
    264e:	2501                	sext.w	a0,a0
    2650:	e915                	bnez	a0,2684 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2652:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2654:	3e800693          	li	a3,1000
    2658:	a819                	j	266e <sleep+0x54>
	__asm_syscall("r"(a7))
    265a:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    265e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2662:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2664:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2666:	00000073          	ecall
	if (err == 0) {
    266a:	2501                	sext.w	a0,a0
    266c:	ed01                	bnez	a0,2684 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    266e:	6722                	ld	a4,8(sp)
    2670:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2672:	07c00893          	li	a7,124
    2676:	02d75733          	divu	a4,a4,a3
    267a:	02f687b3          	mul	a5,a3,a5
    267e:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2680:	fcc7ede3          	bltu	a5,a2,265a <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2684:	4501                	li	a0,0
    2686:	0141                	addi	sp,sp,16
    2688:	8082                	ret
    268a:	57fd                	li	a5,-1
    268c:	bf5d                	j	2642 <sleep+0x28>

000000000000268e <sys_task_info>:
	register long a7 __asm__("a7") = n;
    268e:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2696:	2501                	sext.w	a0,a0
    2698:	8082                	ret

000000000000269a <set_priority>:
	register long a7 __asm__("a7") = n;
    269a:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    269e:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    26a6:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26aa:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <munmap>:
	register long a7 __asm__("a7") = n;
    26b2:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b6:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <wait>:

int wait(int *code)
{
    26be:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26c0:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    26c4:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c6:	00000073          	ecall
	return waitpid(-1, code);
}
    26ca:	2501                	sext.w	a0,a0
    26cc:	8082                	ret

00000000000026ce <spawn>:
	register long a7 __asm__("a7") = n;
    26ce:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    26d2:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    26d6:	2501                	sext.w	a0,a0
    26d8:	8082                	ret

00000000000026da <pipe>:
	register long a7 __asm__("a7") = n;
    26da:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    26de:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    26e2:	2501                	sext.w	a0,a0
    26e4:	8082                	ret

00000000000026e6 <mailread>:
	register long a7 __asm__("a7") = n;
    26e6:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ea:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    26ee:	2501                	sext.w	a0,a0
    26f0:	8082                	ret

00000000000026f2 <mailwrite>:
	register long a7 __asm__("a7") = n;
    26f2:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26f6:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret

00000000000026fe <fstat>:
	register long a7 __asm__("a7") = n;
    26fe:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2702:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2706:	2501                	sext.w	a0,a0
    2708:	8082                	ret

000000000000270a <sys_linkat>:
	register long a4 __asm__("a4") = e;
    270a:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    270c:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2710:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2712:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2716:	2501                	sext.w	a0,a0
    2718:	8082                	ret

000000000000271a <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    271a:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    271c:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2720:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2722:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2726:	2501                	sext.w	a0,a0
    2728:	8082                	ret

000000000000272a <link>:

int link(char *old_path, char *new_path)
{
    272a:	87aa                	mv	a5,a0
    272c:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    272e:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2732:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2736:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2738:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    273c:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    273e:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2742:	2501                	sext.w	a0,a0
    2744:	8082                	ret

0000000000002746 <unlink>:

int unlink(char *path)
{
    2746:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2748:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    274c:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2750:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2752:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    275a:	00001797          	auipc	a5,0x1
    275e:	4be7b783          	ld	a5,1214(a5) # 3c18 <_GLOBAL_OFFSET_TABLE_+0x8>
    2762:	439c                	lw	a5,0(a5)
    2764:	c799                	beqz	a5,2772 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2766:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    276a:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    276e:	2501                	sext.w	a0,a0
    2770:	8082                	ret
{
    2772:	1101                	addi	sp,sp,-32
    2774:	ec06                	sd	ra,24(sp)
    2776:	e42e                	sd	a1,8(sp)
    2778:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    277a:	fe7fe0ef          	jal	ra,1760 <enable_thread_io_buffer>
    277e:	65a2                	ld	a1,8(sp)
    2780:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2782:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2786:	00000073          	ecall
}
    278a:	60e2                	ld	ra,24(sp)
    278c:	2501                	sext.w	a0,a0
    278e:	6105                	addi	sp,sp,32
    2790:	8082                	ret

0000000000002792 <gettid>:
	register long a7 __asm__("a7") = n;
    2792:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2796:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    279a:	2501                	sext.w	a0,a0
    279c:	8082                	ret

000000000000279e <waittid>:

int waittid(int tid)
{
    279e:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    27a0:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    27a4:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    27a8:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    27aa:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27ac:	00e51e63          	bne	a0,a4,27c8 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    27b0:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    27b4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    27b8:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    27bc:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    27be:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    27c2:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27c4:	fee506e3          	beq	a0,a4,27b0 <waittid+0x12>
	}
	return ret;
}
    27c8:	8082                	ret

00000000000027ca <mutex_create>:
	register long a7 __asm__("a7") = n;
    27ca:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    27ce:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    27d0:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    27d4:	2501                	sext.w	a0,a0
    27d6:	8082                	ret

00000000000027d8 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    27d8:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    27dc:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    27de:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    27e2:	2501                	sext.w	a0,a0
    27e4:	8082                	ret

00000000000027e6 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    27e6:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    27ea:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    27ee:	2501                	sext.w	a0,a0
    27f0:	8082                	ret

00000000000027f2 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    27f2:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    27f6:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    27fa:	2501                	sext.w	a0,a0
    27fc:	8082                	ret

00000000000027fe <semaphore_create>:
	register long a7 __asm__("a7") = n;
    27fe:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2802:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2806:	2501                	sext.w	a0,a0
    2808:	8082                	ret

000000000000280a <semaphore_up>:
	register long a7 __asm__("a7") = n;
    280a:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    280e:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2812:	2501                	sext.w	a0,a0
    2814:	8082                	ret

0000000000002816 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2816:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    281a:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    281e:	2501                	sext.w	a0,a0
    2820:	8082                	ret

0000000000002822 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2822:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2826:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    282a:	2501                	sext.w	a0,a0
    282c:	8082                	ret

000000000000282e <condvar_signal>:
	register long a7 __asm__("a7") = n;
    282e:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2832:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2836:	2501                	sext.w	a0,a0
    2838:	8082                	ret

000000000000283a <condvar_wait>:
	register long a7 __asm__("a7") = n;
    283a:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    283e:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2842:	2501                	sext.w	a0,a0
    2844:	8082                	ret

0000000000002846 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2846:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    284a:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    284e:	2501                	sext.w	a0,a0
    2850:	8082                	ret
