
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch3_taskinfo:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a309                	j	1502 <__start_main>

0000000000001002 <main>:
/// 正确输出：（无报错信息）
/// hello task!
/// Test task info OK!

int main()
{
    1002:	7139                	addi	sp,sp,-64
    1004:	fc06                	sd	ra,56(sp)
    1006:	f426                	sd	s1,40(sp)
    1008:	f04a                	sd	s2,32(sp)
    100a:	ec4e                	sd	s3,24(sp)
    100c:	f822                	sd	s0,48(sp)
    100e:	e852                	sd	s4,16(sp)
    1010:	83010113          	addi	sp,sp,-2000
	int64 t1 = get_mtime();
    1014:	0e5010ef          	jal	ra,28f8 <get_mtime>
    1018:	84aa                	mv	s1,a0
	TaskInfo info;
	get_mtime();
    101a:	0df010ef          	jal	ra,28f8 <get_mtime>
	sleep(500);
    101e:	1f400513          	li	a0,500
    1022:	10f010ef          	jal	ra,2930 <sleep>
	int64 t2 = get_mtime();
    1026:	0d3010ef          	jal	ra,28f8 <get_mtime>
	// 注意本次 task info 调用也计入内
	assert(sys_task_info(&info) == 0);
    102a:	00810993          	addi	s3,sp,8
	int64 t2 = get_mtime();
    102e:	892a                	mv	s2,a0
	assert(sys_task_info(&info) == 0);
    1030:	854e                	mv	a0,s3
    1032:	173010ef          	jal	ra,29a4 <sys_task_info>
    1036:	48051b63          	bnez	a0,14cc <main+0x4ca>
	int64 t3 = get_mtime();
    103a:	0bf010ef          	jal	ra,28f8 <get_mtime>
	// sleep 会用到获取时间的系统调用，所以是 <= 而不是 ==
	assert(3 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    103e:	2b012703          	lw	a4,688(sp)
    1042:	4789                	li	a5,2
	int64 t3 = get_mtime();
    1044:	842a                	mv	s0,a0
	assert(3 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    1046:	44e7f863          	bgeu	a5,a4,1496 <main+0x494>
	assert(1 == info.syscall_times[SYSCALL_TASK_INFO]);
    104a:	67412703          	lw	a4,1652(sp)
    104e:	4785                	li	a5,1
    1050:	02f70c63          	beq	a4,a5,1088 <main+0x86>
    1054:	03b010ef          	jal	ra,288e <getpid>
    1058:	8a2a                	mv	s4,a0
    105a:	00002517          	auipc	a0,0x2
    105e:	b0e50513          	addi	a0,a0,-1266 # 2b68 <enable_deadlock_detect+0xc>
    1062:	702010ef          	jal	ra,2764 <basename>
    1066:	872a                	mv	a4,a0
    1068:	47ed                	li	a5,27
    106a:	00002517          	auipc	a0,0x2
    106e:	bde50513          	addi	a0,a0,-1058 # 2c48 <enable_deadlock_detect+0xec>
    1072:	86d2                	mv	a3,s4
    1074:	00002617          	auipc	a2,0x2
    1078:	b3c60613          	addi	a2,a2,-1220 # 2bb0 <enable_deadlock_detect+0x54>
    107c:	45fd                	li	a1,31
    107e:	5de000ef          	jal	ra,165c <printf>
    1082:	557d                	li	a0,-1
    1084:	03b010ef          	jal	ra,28be <exit>
	assert(0 == info.syscall_times[SYSCALL_WRITE]);
    1088:	10c12783          	lw	a5,268(sp)
    108c:	3c079a63          	bnez	a5,1460 <main+0x45e>
	assert(0 < info.syscall_times[SYSCALL_YIELD]);
    1090:	1fc12783          	lw	a5,508(sp)
    1094:	38078b63          	beqz	a5,142a <main+0x428>
	assert(0 == info.syscall_times[SYSCALL_EXIT]);
    1098:	18012783          	lw	a5,384(sp)
    109c:	34079c63          	bnez	a5,13f4 <main+0x3f2>
	assert(t2 - t1 <= info.time + 1);
    10a0:	7dc12783          	lw	a5,2012(sp)
    10a4:	40990933          	sub	s2,s2,s1
    10a8:	0017871b          	addiw	a4,a5,1
    10ac:	31274763          	blt	a4,s2,13ba <main+0x3b8>
	assert(info.time < t3 - t1 + 100);
    10b0:	8c05                	sub	s0,s0,s1
    10b2:	06340413          	addi	s0,s0,99
    10b6:	2cf44663          	blt	s0,a5,1382 <main+0x380>
	assert(Running == info.status);
    10ba:	4722                	lw	a4,8(sp)
    10bc:	4789                	li	a5,2
    10be:	02f70d63          	beq	a4,a5,10f8 <main+0xf6>
    10c2:	7cc010ef          	jal	ra,288e <getpid>
    10c6:	842a                	mv	s0,a0
    10c8:	00002517          	auipc	a0,0x2
    10cc:	aa050513          	addi	a0,a0,-1376 # 2b68 <enable_deadlock_detect+0xc>
    10d0:	694010ef          	jal	ra,2764 <basename>
    10d4:	872a                	mv	a4,a0
    10d6:	02100793          	li	a5,33
    10da:	00002517          	auipc	a0,0x2
    10de:	d1e50513          	addi	a0,a0,-738 # 2df8 <enable_deadlock_detect+0x29c>
    10e2:	86a2                	mv	a3,s0
    10e4:	00002617          	auipc	a2,0x2
    10e8:	acc60613          	addi	a2,a2,-1332 # 2bb0 <enable_deadlock_detect+0x54>
    10ec:	45fd                	li	a1,31
    10ee:	56e000ef          	jal	ra,165c <printf>
    10f2:	557d                	li	a0,-1
    10f4:	7ca010ef          	jal	ra,28be <exit>

	puts("hello task!");
    10f8:	00002517          	auipc	a0,0x2
    10fc:	d4050513          	addi	a0,a0,-704 # 2e38 <enable_deadlock_detect+0x2dc>
    1100:	473000ef          	jal	ra,1d72 <puts>
	int64 t4 = get_mtime();
    1104:	7f4010ef          	jal	ra,28f8 <get_mtime>
    1108:	892a                	mv	s2,a0
	// 看看puts的实现，想想为什么 write 调用只有一次
	assert(sys_task_info(&info) == 0);
    110a:	854e                	mv	a0,s3
    110c:	099010ef          	jal	ra,29a4 <sys_task_info>
    1110:	22051d63          	bnez	a0,134a <main+0x348>
	int64 t5 = get_mtime();
    1114:	7e4010ef          	jal	ra,28f8 <get_mtime>
	assert(5 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    1118:	2b012703          	lw	a4,688(sp)
    111c:	4791                	li	a5,4
	int64 t5 = get_mtime();
    111e:	842a                	mv	s0,a0
	assert(5 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    1120:	1ee7f963          	bgeu	a5,a4,1312 <main+0x310>
	assert(2 == info.syscall_times[SYSCALL_TASK_INFO]);
    1124:	67412703          	lw	a4,1652(sp)
    1128:	4789                	li	a5,2
    112a:	02f70d63          	beq	a4,a5,1164 <main+0x162>
    112e:	760010ef          	jal	ra,288e <getpid>
    1132:	89aa                	mv	s3,a0
    1134:	00002517          	auipc	a0,0x2
    1138:	a3450513          	addi	a0,a0,-1484 # 2b68 <enable_deadlock_detect+0xc>
    113c:	628010ef          	jal	ra,2764 <basename>
    1140:	872a                	mv	a4,a0
    1142:	02900793          	li	a5,41
    1146:	00002517          	auipc	a0,0x2
    114a:	d4a50513          	addi	a0,a0,-694 # 2e90 <enable_deadlock_detect+0x334>
    114e:	86ce                	mv	a3,s3
    1150:	00002617          	auipc	a2,0x2
    1154:	a6060613          	addi	a2,a2,-1440 # 2bb0 <enable_deadlock_detect+0x54>
    1158:	45fd                	li	a1,31
    115a:	502000ef          	jal	ra,165c <printf>
    115e:	557d                	li	a0,-1
    1160:	75e010ef          	jal	ra,28be <exit>
	assert(1 == info.syscall_times[SYSCALL_WRITE]);
    1164:	10c12703          	lw	a4,268(sp)
    1168:	4785                	li	a5,1
    116a:	02f70d63          	beq	a4,a5,11a4 <main+0x1a2>
    116e:	720010ef          	jal	ra,288e <getpid>
    1172:	89aa                	mv	s3,a0
    1174:	00002517          	auipc	a0,0x2
    1178:	9f450513          	addi	a0,a0,-1548 # 2b68 <enable_deadlock_detect+0xc>
    117c:	5e8010ef          	jal	ra,2764 <basename>
    1180:	872a                	mv	a4,a0
    1182:	02a00793          	li	a5,42
    1186:	00002517          	auipc	a0,0x2
    118a:	d5250513          	addi	a0,a0,-686 # 2ed8 <enable_deadlock_detect+0x37c>
    118e:	86ce                	mv	a3,s3
    1190:	00002617          	auipc	a2,0x2
    1194:	a2060613          	addi	a2,a2,-1504 # 2bb0 <enable_deadlock_detect+0x54>
    1198:	45fd                	li	a1,31
    119a:	4c2000ef          	jal	ra,165c <printf>
    119e:	557d                	li	a0,-1
    11a0:	71e010ef          	jal	ra,28be <exit>
	assert(0 < info.syscall_times[SYSCALL_YIELD]);
    11a4:	1fc12783          	lw	a5,508(sp)
    11a8:	12078963          	beqz	a5,12da <main+0x2d8>
	assert(0 == info.syscall_times[SYSCALL_EXIT]);
    11ac:	18012783          	lw	a5,384(sp)
    11b0:	0e079963          	bnez	a5,12a2 <main+0x2a0>
	assert(t4 - t1 <= info.time + 1);
    11b4:	7dc12783          	lw	a5,2012(sp)
    11b8:	40990933          	sub	s2,s2,s1
    11bc:	0017871b          	addiw	a4,a5,1
    11c0:	0b274363          	blt	a4,s2,1266 <main+0x264>
	assert(info.time < t5 - t1 + 100);
    11c4:	8c05                	sub	s0,s0,s1
    11c6:	06340413          	addi	s0,s0,99
    11ca:	06f44263          	blt	s0,a5,122e <main+0x22c>
	assert(Running == info.status);
    11ce:	4722                	lw	a4,8(sp)
    11d0:	4789                	li	a5,2
    11d2:	02f70d63          	beq	a4,a5,120c <main+0x20a>
    11d6:	6b8010ef          	jal	ra,288e <getpid>
    11da:	842a                	mv	s0,a0
    11dc:	00002517          	auipc	a0,0x2
    11e0:	98c50513          	addi	a0,a0,-1652 # 2b68 <enable_deadlock_detect+0xc>
    11e4:	580010ef          	jal	ra,2764 <basename>
    11e8:	872a                	mv	a4,a0
    11ea:	02f00793          	li	a5,47
    11ee:	00002517          	auipc	a0,0x2
    11f2:	c0a50513          	addi	a0,a0,-1014 # 2df8 <enable_deadlock_detect+0x29c>
    11f6:	86a2                	mv	a3,s0
    11f8:	00002617          	auipc	a2,0x2
    11fc:	9b860613          	addi	a2,a2,-1608 # 2bb0 <enable_deadlock_detect+0x54>
    1200:	45fd                	li	a1,31
    1202:	45a000ef          	jal	ra,165c <printf>
    1206:	557d                	li	a0,-1
    1208:	6b6010ef          	jal	ra,28be <exit>
	puts("Test task info OK!");
    120c:	00002517          	auipc	a0,0x2
    1210:	da450513          	addi	a0,a0,-604 # 2fb0 <enable_deadlock_detect+0x454>
    1214:	35f000ef          	jal	ra,1d72 <puts>
	return 0;
}
    1218:	7d010113          	addi	sp,sp,2000
    121c:	70e2                	ld	ra,56(sp)
    121e:	7442                	ld	s0,48(sp)
    1220:	74a2                	ld	s1,40(sp)
    1222:	7902                	ld	s2,32(sp)
    1224:	69e2                	ld	s3,24(sp)
    1226:	6a42                	ld	s4,16(sp)
    1228:	4501                	li	a0,0
    122a:	6121                	addi	sp,sp,64
    122c:	8082                	ret
	assert(info.time < t5 - t1 + 100);
    122e:	660010ef          	jal	ra,288e <getpid>
    1232:	842a                	mv	s0,a0
    1234:	00002517          	auipc	a0,0x2
    1238:	93450513          	addi	a0,a0,-1740 # 2b68 <enable_deadlock_detect+0xc>
    123c:	528010ef          	jal	ra,2764 <basename>
    1240:	872a                	mv	a4,a0
    1242:	02e00793          	li	a5,46
    1246:	00002517          	auipc	a0,0x2
    124a:	d2250513          	addi	a0,a0,-734 # 2f68 <enable_deadlock_detect+0x40c>
    124e:	86a2                	mv	a3,s0
    1250:	00002617          	auipc	a2,0x2
    1254:	96060613          	addi	a2,a2,-1696 # 2bb0 <enable_deadlock_detect+0x54>
    1258:	45fd                	li	a1,31
    125a:	402000ef          	jal	ra,165c <printf>
    125e:	557d                	li	a0,-1
    1260:	65e010ef          	jal	ra,28be <exit>
    1264:	b7ad                	j	11ce <main+0x1cc>
	assert(t4 - t1 <= info.time + 1);
    1266:	628010ef          	jal	ra,288e <getpid>
    126a:	892a                	mv	s2,a0
    126c:	00002517          	auipc	a0,0x2
    1270:	8fc50513          	addi	a0,a0,-1796 # 2b68 <enable_deadlock_detect+0xc>
    1274:	4f0010ef          	jal	ra,2764 <basename>
    1278:	872a                	mv	a4,a0
    127a:	02d00793          	li	a5,45
    127e:	86ca                	mv	a3,s2
    1280:	00002617          	auipc	a2,0x2
    1284:	93060613          	addi	a2,a2,-1744 # 2bb0 <enable_deadlock_detect+0x54>
    1288:	45fd                	li	a1,31
    128a:	00002517          	auipc	a0,0x2
    128e:	c9650513          	addi	a0,a0,-874 # 2f20 <enable_deadlock_detect+0x3c4>
    1292:	3ca000ef          	jal	ra,165c <printf>
    1296:	557d                	li	a0,-1
    1298:	626010ef          	jal	ra,28be <exit>
	assert(info.time < t5 - t1 + 100);
    129c:	7dc12783          	lw	a5,2012(sp)
    12a0:	b715                	j	11c4 <main+0x1c2>
	assert(0 == info.syscall_times[SYSCALL_EXIT]);
    12a2:	5ec010ef          	jal	ra,288e <getpid>
    12a6:	89aa                	mv	s3,a0
    12a8:	00002517          	auipc	a0,0x2
    12ac:	8c050513          	addi	a0,a0,-1856 # 2b68 <enable_deadlock_detect+0xc>
    12b0:	4b4010ef          	jal	ra,2764 <basename>
    12b4:	872a                	mv	a4,a0
    12b6:	02c00793          	li	a5,44
    12ba:	00002517          	auipc	a0,0x2
    12be:	a6650513          	addi	a0,a0,-1434 # 2d20 <enable_deadlock_detect+0x1c4>
    12c2:	86ce                	mv	a3,s3
    12c4:	00002617          	auipc	a2,0x2
    12c8:	8ec60613          	addi	a2,a2,-1812 # 2bb0 <enable_deadlock_detect+0x54>
    12cc:	45fd                	li	a1,31
    12ce:	38e000ef          	jal	ra,165c <printf>
    12d2:	557d                	li	a0,-1
    12d4:	5ea010ef          	jal	ra,28be <exit>
    12d8:	bdf1                	j	11b4 <main+0x1b2>
	assert(0 < info.syscall_times[SYSCALL_YIELD]);
    12da:	5b4010ef          	jal	ra,288e <getpid>
    12de:	89aa                	mv	s3,a0
    12e0:	00002517          	auipc	a0,0x2
    12e4:	88850513          	addi	a0,a0,-1912 # 2b68 <enable_deadlock_detect+0xc>
    12e8:	47c010ef          	jal	ra,2764 <basename>
    12ec:	872a                	mv	a4,a0
    12ee:	02b00793          	li	a5,43
    12f2:	00002517          	auipc	a0,0x2
    12f6:	9e650513          	addi	a0,a0,-1562 # 2cd8 <enable_deadlock_detect+0x17c>
    12fa:	86ce                	mv	a3,s3
    12fc:	00002617          	auipc	a2,0x2
    1300:	8b460613          	addi	a2,a2,-1868 # 2bb0 <enable_deadlock_detect+0x54>
    1304:	45fd                	li	a1,31
    1306:	356000ef          	jal	ra,165c <printf>
    130a:	557d                	li	a0,-1
    130c:	5b2010ef          	jal	ra,28be <exit>
    1310:	bd71                	j	11ac <main+0x1aa>
	assert(5 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    1312:	57c010ef          	jal	ra,288e <getpid>
    1316:	89aa                	mv	s3,a0
    1318:	00002517          	auipc	a0,0x2
    131c:	85050513          	addi	a0,a0,-1968 # 2b68 <enable_deadlock_detect+0xc>
    1320:	444010ef          	jal	ra,2764 <basename>
    1324:	872a                	mv	a4,a0
    1326:	02800793          	li	a5,40
    132a:	00002517          	auipc	a0,0x2
    132e:	b1e50513          	addi	a0,a0,-1250 # 2e48 <enable_deadlock_detect+0x2ec>
    1332:	86ce                	mv	a3,s3
    1334:	00002617          	auipc	a2,0x2
    1338:	87c60613          	addi	a2,a2,-1924 # 2bb0 <enable_deadlock_detect+0x54>
    133c:	45fd                	li	a1,31
    133e:	31e000ef          	jal	ra,165c <printf>
    1342:	557d                	li	a0,-1
    1344:	57a010ef          	jal	ra,28be <exit>
    1348:	bbf1                	j	1124 <main+0x122>
	assert(sys_task_info(&info) == 0);
    134a:	544010ef          	jal	ra,288e <getpid>
    134e:	842a                	mv	s0,a0
    1350:	00002517          	auipc	a0,0x2
    1354:	81850513          	addi	a0,a0,-2024 # 2b68 <enable_deadlock_detect+0xc>
    1358:	40c010ef          	jal	ra,2764 <basename>
    135c:	872a                	mv	a4,a0
    135e:	02600793          	li	a5,38
    1362:	00002517          	auipc	a0,0x2
    1366:	85650513          	addi	a0,a0,-1962 # 2bb8 <enable_deadlock_detect+0x5c>
    136a:	86a2                	mv	a3,s0
    136c:	00002617          	auipc	a2,0x2
    1370:	84460613          	addi	a2,a2,-1980 # 2bb0 <enable_deadlock_detect+0x54>
    1374:	45fd                	li	a1,31
    1376:	2e6000ef          	jal	ra,165c <printf>
    137a:	557d                	li	a0,-1
    137c:	542010ef          	jal	ra,28be <exit>
    1380:	bb51                	j	1114 <main+0x112>
	assert(info.time < t3 - t1 + 100);
    1382:	50c010ef          	jal	ra,288e <getpid>
    1386:	842a                	mv	s0,a0
    1388:	00001517          	auipc	a0,0x1
    138c:	7e050513          	addi	a0,a0,2016 # 2b68 <enable_deadlock_detect+0xc>
    1390:	3d4010ef          	jal	ra,2764 <basename>
    1394:	872a                	mv	a4,a0
    1396:	02000793          	li	a5,32
    139a:	00002517          	auipc	a0,0x2
    139e:	a1650513          	addi	a0,a0,-1514 # 2db0 <enable_deadlock_detect+0x254>
    13a2:	86a2                	mv	a3,s0
    13a4:	00002617          	auipc	a2,0x2
    13a8:	80c60613          	addi	a2,a2,-2036 # 2bb0 <enable_deadlock_detect+0x54>
    13ac:	45fd                	li	a1,31
    13ae:	2ae000ef          	jal	ra,165c <printf>
    13b2:	557d                	li	a0,-1
    13b4:	50a010ef          	jal	ra,28be <exit>
    13b8:	b309                	j	10ba <main+0xb8>
	assert(t2 - t1 <= info.time + 1);
    13ba:	4d4010ef          	jal	ra,288e <getpid>
    13be:	892a                	mv	s2,a0
    13c0:	00001517          	auipc	a0,0x1
    13c4:	7a850513          	addi	a0,a0,1960 # 2b68 <enable_deadlock_detect+0xc>
    13c8:	39c010ef          	jal	ra,2764 <basename>
    13cc:	872a                	mv	a4,a0
    13ce:	47fd                	li	a5,31
    13d0:	86ca                	mv	a3,s2
    13d2:	00001617          	auipc	a2,0x1
    13d6:	7de60613          	addi	a2,a2,2014 # 2bb0 <enable_deadlock_detect+0x54>
    13da:	45fd                	li	a1,31
    13dc:	00002517          	auipc	a0,0x2
    13e0:	98c50513          	addi	a0,a0,-1652 # 2d68 <enable_deadlock_detect+0x20c>
    13e4:	278000ef          	jal	ra,165c <printf>
    13e8:	557d                	li	a0,-1
    13ea:	4d4010ef          	jal	ra,28be <exit>
	assert(info.time < t3 - t1 + 100);
    13ee:	7dc12783          	lw	a5,2012(sp)
    13f2:	b97d                	j	10b0 <main+0xae>
	assert(0 == info.syscall_times[SYSCALL_EXIT]);
    13f4:	49a010ef          	jal	ra,288e <getpid>
    13f8:	8a2a                	mv	s4,a0
    13fa:	00001517          	auipc	a0,0x1
    13fe:	76e50513          	addi	a0,a0,1902 # 2b68 <enable_deadlock_detect+0xc>
    1402:	362010ef          	jal	ra,2764 <basename>
    1406:	872a                	mv	a4,a0
    1408:	47f9                	li	a5,30
    140a:	00002517          	auipc	a0,0x2
    140e:	91650513          	addi	a0,a0,-1770 # 2d20 <enable_deadlock_detect+0x1c4>
    1412:	86d2                	mv	a3,s4
    1414:	00001617          	auipc	a2,0x1
    1418:	79c60613          	addi	a2,a2,1948 # 2bb0 <enable_deadlock_detect+0x54>
    141c:	45fd                	li	a1,31
    141e:	23e000ef          	jal	ra,165c <printf>
    1422:	557d                	li	a0,-1
    1424:	49a010ef          	jal	ra,28be <exit>
    1428:	b9a5                	j	10a0 <main+0x9e>
	assert(0 < info.syscall_times[SYSCALL_YIELD]);
    142a:	464010ef          	jal	ra,288e <getpid>
    142e:	8a2a                	mv	s4,a0
    1430:	00001517          	auipc	a0,0x1
    1434:	73850513          	addi	a0,a0,1848 # 2b68 <enable_deadlock_detect+0xc>
    1438:	32c010ef          	jal	ra,2764 <basename>
    143c:	872a                	mv	a4,a0
    143e:	47f5                	li	a5,29
    1440:	00002517          	auipc	a0,0x2
    1444:	89850513          	addi	a0,a0,-1896 # 2cd8 <enable_deadlock_detect+0x17c>
    1448:	86d2                	mv	a3,s4
    144a:	00001617          	auipc	a2,0x1
    144e:	76660613          	addi	a2,a2,1894 # 2bb0 <enable_deadlock_detect+0x54>
    1452:	45fd                	li	a1,31
    1454:	208000ef          	jal	ra,165c <printf>
    1458:	557d                	li	a0,-1
    145a:	464010ef          	jal	ra,28be <exit>
    145e:	b92d                	j	1098 <main+0x96>
	assert(0 == info.syscall_times[SYSCALL_WRITE]);
    1460:	42e010ef          	jal	ra,288e <getpid>
    1464:	8a2a                	mv	s4,a0
    1466:	00001517          	auipc	a0,0x1
    146a:	70250513          	addi	a0,a0,1794 # 2b68 <enable_deadlock_detect+0xc>
    146e:	2f6010ef          	jal	ra,2764 <basename>
    1472:	872a                	mv	a4,a0
    1474:	47f1                	li	a5,28
    1476:	00002517          	auipc	a0,0x2
    147a:	81a50513          	addi	a0,a0,-2022 # 2c90 <enable_deadlock_detect+0x134>
    147e:	86d2                	mv	a3,s4
    1480:	00001617          	auipc	a2,0x1
    1484:	73060613          	addi	a2,a2,1840 # 2bb0 <enable_deadlock_detect+0x54>
    1488:	45fd                	li	a1,31
    148a:	1d2000ef          	jal	ra,165c <printf>
    148e:	557d                	li	a0,-1
    1490:	42e010ef          	jal	ra,28be <exit>
    1494:	bef5                	j	1090 <main+0x8e>
	assert(3 <= info.syscall_times[SYSCALL_GETTIMEOFDAY]);
    1496:	3f8010ef          	jal	ra,288e <getpid>
    149a:	8a2a                	mv	s4,a0
    149c:	00001517          	auipc	a0,0x1
    14a0:	6cc50513          	addi	a0,a0,1740 # 2b68 <enable_deadlock_detect+0xc>
    14a4:	2c0010ef          	jal	ra,2764 <basename>
    14a8:	872a                	mv	a4,a0
    14aa:	47e9                	li	a5,26
    14ac:	00001517          	auipc	a0,0x1
    14b0:	75450513          	addi	a0,a0,1876 # 2c00 <enable_deadlock_detect+0xa4>
    14b4:	86d2                	mv	a3,s4
    14b6:	00001617          	auipc	a2,0x1
    14ba:	6fa60613          	addi	a2,a2,1786 # 2bb0 <enable_deadlock_detect+0x54>
    14be:	45fd                	li	a1,31
    14c0:	19c000ef          	jal	ra,165c <printf>
    14c4:	557d                	li	a0,-1
    14c6:	3f8010ef          	jal	ra,28be <exit>
    14ca:	b641                	j	104a <main+0x48>
	assert(sys_task_info(&info) == 0);
    14cc:	3c2010ef          	jal	ra,288e <getpid>
    14d0:	842a                	mv	s0,a0
    14d2:	00001517          	auipc	a0,0x1
    14d6:	69650513          	addi	a0,a0,1686 # 2b68 <enable_deadlock_detect+0xc>
    14da:	28a010ef          	jal	ra,2764 <basename>
    14de:	872a                	mv	a4,a0
    14e0:	47dd                	li	a5,23
    14e2:	00001517          	auipc	a0,0x1
    14e6:	6d650513          	addi	a0,a0,1750 # 2bb8 <enable_deadlock_detect+0x5c>
    14ea:	86a2                	mv	a3,s0
    14ec:	00001617          	auipc	a2,0x1
    14f0:	6c460613          	addi	a2,a2,1732 # 2bb0 <enable_deadlock_detect+0x54>
    14f4:	45fd                	li	a1,31
    14f6:	166000ef          	jal	ra,165c <printf>
    14fa:	557d                	li	a0,-1
    14fc:	3c2010ef          	jal	ra,28be <exit>
    1500:	be2d                	j	103a <main+0x38>

0000000000001502 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1502:	1141                	addi	sp,sp,-16
    1504:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1506:	afdff0ef          	jal	ra,1002 <main>
    150a:	3b4010ef          	jal	ra,28be <exit>
	return 0;
    150e:	60a2                	ld	ra,8(sp)
    1510:	4501                	li	a0,0
    1512:	0141                	addi	sp,sp,16
    1514:	8082                	ret

0000000000001516 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1516:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1518:	4605                	li	a2,1
    151a:	00f10593          	addi	a1,sp,15
    151e:	4501                	li	a0,0
{
    1520:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1522:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1526:	354010ef          	jal	ra,287a <read>
    152a:	4785                	li	a5,1
    152c:	00f51763          	bne	a0,a5,153a <getchar+0x24>
		return byte;
    1530:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1534:	60e2                	ld	ra,24(sp)
    1536:	6105                	addi	sp,sp,32
    1538:	8082                	ret
		return EOF;
    153a:	557d                	li	a0,-1
    153c:	bfe5                	j	1534 <getchar+0x1e>

000000000000153e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    153e:	00002517          	auipc	a0,0x2
    1542:	b8252503          	lw	a0,-1150(a0) # 30c0 <buffer_len>
    1546:	e111                	bnez	a0,154a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1548:	8082                	ret
{
    154a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    154c:	862a                	mv	a2,a0
    154e:	00002597          	auipc	a1,0x2
    1552:	b7a58593          	addi	a1,a1,-1158 # 30c8 <buffer>
    1556:	4505                	li	a0,1
{
    1558:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    155a:	32a010ef          	jal	ra,2884 <write>
}
    155e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1560:	2501                	sext.w	a0,a0
}
    1562:	0141                	addi	sp,sp,16
    1564:	8082                	ret

0000000000001566 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1566:	00002797          	auipc	a5,0x2
    156a:	b407ad23          	sw	zero,-1190(a5) # 30c0 <buffer_len>
}
    156e:	8082                	ret

0000000000001570 <__fflush>:
	if (buffer_len == 0)
    1570:	00002517          	auipc	a0,0x2
    1574:	b5052503          	lw	a0,-1200(a0) # 30c0 <buffer_len>
    1578:	e511                	bnez	a0,1584 <__fflush+0x14>
	buffer_len = 0;
    157a:	00002797          	auipc	a5,0x2
    157e:	b407a323          	sw	zero,-1210(a5) # 30c0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1582:	8082                	ret
{
    1584:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1586:	862a                	mv	a2,a0
    1588:	00002597          	auipc	a1,0x2
    158c:	b4058593          	addi	a1,a1,-1216 # 30c8 <buffer>
    1590:	4505                	li	a0,1
{
    1592:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1594:	2f0010ef          	jal	ra,2884 <write>
	return r >= 0 ? 0 : r;
    1598:	0005079b          	sext.w	a5,a0
}
    159c:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    159e:	0017a793          	slti	a5,a5,1
    15a2:	40f007bb          	negw	a5,a5
    15a6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    15a8:	00002797          	auipc	a5,0x2
    15ac:	b007ac23          	sw	zero,-1256(a5) # 30c0 <buffer_len>
	return r >= 0 ? 0 : r;
    15b0:	2501                	sext.w	a0,a0
}
    15b2:	0141                	addi	sp,sp,16
    15b4:	8082                	ret

00000000000015b6 <fflush>:

int fflush(int fd)
{
    15b6:	1101                	addi	sp,sp,-32
    15b8:	e822                	sd	s0,16(sp)
    15ba:	ec06                	sd	ra,24(sp)
    15bc:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    15be:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    15c0:	4401                	li	s0,0
	if (fd == 1) {
    15c2:	00e50863          	beq	a0,a4,15d2 <fflush+0x1c>
}
    15c6:	60e2                	ld	ra,24(sp)
    15c8:	8522                	mv	a0,s0
    15ca:	6442                	ld	s0,16(sp)
    15cc:	64a2                	ld	s1,8(sp)
    15ce:	6105                	addi	sp,sp,32
    15d0:	8082                	ret
		if (buffer_lock_enabled == 1) {
    15d2:	00002497          	auipc	s1,0x2
    15d6:	aee48493          	addi	s1,s1,-1298 # 30c0 <buffer_len>
    15da:	1084a703          	lw	a4,264(s1)
    15de:	02a70e63          	beq	a4,a0,161a <fflush+0x64>
	if (buffer_len == 0)
    15e2:	4080                	lw	s0,0(s1)
    15e4:	c00d                	beqz	s0,1606 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    15e6:	8622                	mv	a2,s0
    15e8:	00002597          	auipc	a1,0x2
    15ec:	ae058593          	addi	a1,a1,-1312 # 30c8 <buffer>
    15f0:	294010ef          	jal	ra,2884 <write>
	return r >= 0 ? 0 : r;
    15f4:	0005079b          	sext.w	a5,a0
    15f8:	0017a793          	slti	a5,a5,1
    15fc:	40f007bb          	negw	a5,a5
    1600:	8d7d                	and	a0,a0,a5
    1602:	0005041b          	sext.w	s0,a0
}
    1606:	60e2                	ld	ra,24(sp)
    1608:	8522                	mv	a0,s0
    160a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    160c:	00002797          	auipc	a5,0x2
    1610:	aa07aa23          	sw	zero,-1356(a5) # 30c0 <buffer_len>
}
    1614:	64a2                	ld	s1,8(sp)
    1616:	6105                	addi	sp,sp,32
    1618:	8082                	ret
			mutex_lock(buffer_lock);
    161a:	10c4a503          	lw	a0,268(s1)
    161e:	4de010ef          	jal	ra,2afc <mutex_lock>
	if (buffer_len == 0)
    1622:	4080                	lw	s0,0(s1)
    1624:	e811                	bnez	s0,1638 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1626:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    162a:	00002797          	auipc	a5,0x2
    162e:	a807ab23          	sw	zero,-1386(a5) # 30c0 <buffer_len>
			mutex_unlock(buffer_lock);
    1632:	4d6010ef          	jal	ra,2b08 <mutex_unlock>
    1636:	bf41                	j	15c6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1638:	8622                	mv	a2,s0
    163a:	00002597          	auipc	a1,0x2
    163e:	a8e58593          	addi	a1,a1,-1394 # 30c8 <buffer>
    1642:	4505                	li	a0,1
    1644:	240010ef          	jal	ra,2884 <write>
	return r >= 0 ? 0 : r;
    1648:	0005079b          	sext.w	a5,a0
    164c:	0017a793          	slti	a5,a5,1
    1650:	40f007bb          	negw	a5,a5
    1654:	8d7d                	and	a0,a0,a5
    1656:	0005041b          	sext.w	s0,a0
	return r;
    165a:	b7f1                	j	1626 <fflush+0x70>

000000000000165c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    165c:	7131                	addi	sp,sp,-192
    165e:	e0da                	sd	s6,64(sp)
    1660:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1662:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1664:	013c                	addi	a5,sp,136
{
    1666:	f0ca                	sd	s2,96(sp)
    1668:	ecce                	sd	s3,88(sp)
    166a:	e8d2                	sd	s4,80(sp)
    166c:	e4d6                	sd	s5,72(sp)
    166e:	fc86                	sd	ra,120(sp)
    1670:	f8a2                	sd	s0,112(sp)
    1672:	f4a6                	sd	s1,104(sp)
    1674:	89aa                	mv	s3,a0
    1676:	e52e                	sd	a1,136(sp)
    1678:	e932                	sd	a2,144(sp)
    167a:	ed36                	sd	a3,152(sp)
    167c:	f13a                	sd	a4,160(sp)
    167e:	f942                	sd	a6,176(sp)
    1680:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1682:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1684:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1688:	00002a17          	auipc	s4,0x2
    168c:	a38a0a13          	addi	s4,s4,-1480 # 30c0 <buffer_len>
    1690:	4a85                	li	s5,1
	buf[i++] = '0';
    1692:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1696:	0009c783          	lbu	a5,0(s3)
    169a:	18078663          	beqz	a5,1826 <printf+0x1ca>
    169e:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    16a0:	19278d63          	beq	a5,s2,183a <printf+0x1de>
    16a4:	0015c783          	lbu	a5,1(a1)
    16a8:	0585                	addi	a1,a1,1
    16aa:	fbfd                	bnez	a5,16a0 <printf+0x44>
    16ac:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    16ae:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    16b2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    16b6:	1b578863          	beq	a5,s5,1866 <printf+0x20a>
		len = out_unlocked(s, l);
    16ba:	85a2                	mv	a1,s0
    16bc:	854e                	mv	a0,s3
    16be:	42a000ef          	jal	ra,1ae8 <out_unlocked>
		out(f, a, l);
		if (l)
    16c2:	1c041063          	bnez	s0,1882 <printf+0x226>
			continue;
		if (s[1] == 0)
    16c6:	0014c783          	lbu	a5,1(s1)
    16ca:	14078e63          	beqz	a5,1826 <printf+0x1ca>
			break;
		switch (s[1]) {
    16ce:	07300713          	li	a4,115
    16d2:	1ce78863          	beq	a5,a4,18a2 <printf+0x246>
    16d6:	1af76863          	bltu	a4,a5,1886 <printf+0x22a>
    16da:	06400713          	li	a4,100
    16de:	22e78063          	beq	a5,a4,18fe <printf+0x2a2>
    16e2:	07000713          	li	a4,112
    16e6:	1ee79563          	bne	a5,a4,18d0 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    16ea:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16ec:	00002797          	auipc	a5,0x2
    16f0:	ae478793          	addi	a5,a5,-1308 # 31d0 <digits>
	buf[i++] = '0';
    16f4:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    16f8:	6298                	ld	a4,0(a3)
    16fa:	06a1                	addi	a3,a3,8
    16fc:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    16fe:	00471393          	slli	t2,a4,0x4
    1702:	00871293          	slli	t0,a4,0x8
    1706:	00c71f93          	slli	t6,a4,0xc
    170a:	01071f13          	slli	t5,a4,0x10
    170e:	01471e93          	slli	t4,a4,0x14
    1712:	01871e13          	slli	t3,a4,0x18
    1716:	01c71893          	slli	a7,a4,0x1c
    171a:	02471813          	slli	a6,a4,0x24
    171e:	02871513          	slli	a0,a4,0x28
    1722:	02c71593          	slli	a1,a4,0x2c
    1726:	03071613          	slli	a2,a4,0x30
    172a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    172e:	03c75413          	srli	s0,a4,0x3c
    1732:	01c7531b          	srliw	t1,a4,0x1c
    1736:	03c3d393          	srli	t2,t2,0x3c
    173a:	03c2d293          	srli	t0,t0,0x3c
    173e:	03cfdf93          	srli	t6,t6,0x3c
    1742:	03cf5f13          	srli	t5,t5,0x3c
    1746:	03cede93          	srli	t4,t4,0x3c
    174a:	03ce5e13          	srli	t3,t3,0x3c
    174e:	03c8d893          	srli	a7,a7,0x3c
    1752:	03c85813          	srli	a6,a6,0x3c
    1756:	9171                	srli	a0,a0,0x3c
    1758:	91f1                	srli	a1,a1,0x3c
    175a:	9271                	srli	a2,a2,0x3c
    175c:	92f1                	srli	a3,a3,0x3c
    175e:	95be                	add	a1,a1,a5
    1760:	963e                	add	a2,a2,a5
    1762:	96be                	add	a3,a3,a5
    1764:	943e                	add	s0,s0,a5
    1766:	93be                	add	t2,t2,a5
    1768:	92be                	add	t0,t0,a5
    176a:	9fbe                	add	t6,t6,a5
    176c:	9f3e                	add	t5,t5,a5
    176e:	9ebe                	add	t4,t4,a5
    1770:	9e3e                	add	t3,t3,a5
    1772:	98be                	add	a7,a7,a5
    1774:	933e                	add	t1,t1,a5
    1776:	983e                	add	a6,a6,a5
    1778:	953e                	add	a0,a0,a5
    177a:	0005c983          	lbu	s3,0(a1)
    177e:	00044403          	lbu	s0,0(s0)
    1782:	00064583          	lbu	a1,0(a2)
    1786:	0003c383          	lbu	t2,0(t2)
    178a:	0006c603          	lbu	a2,0(a3)
    178e:	0002c283          	lbu	t0,0(t0)
    1792:	000fcf83          	lbu	t6,0(t6)
    1796:	000f4f03          	lbu	t5,0(t5)
    179a:	000ece83          	lbu	t4,0(t4)
    179e:	000e4e03          	lbu	t3,0(t3)
    17a2:	0008c883          	lbu	a7,0(a7)
    17a6:	00034303          	lbu	t1,0(t1)
    17aa:	00084803          	lbu	a6,0(a6)
    17ae:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    17b2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    17b6:	92f1                	srli	a3,a3,0x3c
    17b8:	8b3d                	andi	a4,a4,15
    17ba:	96be                	add	a3,a3,a5
    17bc:	97ba                	add	a5,a5,a4
    17be:	00810d23          	sb	s0,26(sp)
    17c2:	00710da3          	sb	t2,27(sp)
    17c6:	00510e23          	sb	t0,28(sp)
    17ca:	01f10ea3          	sb	t6,29(sp)
    17ce:	01e10f23          	sb	t5,30(sp)
    17d2:	01d10fa3          	sb	t4,31(sp)
    17d6:	03c10023          	sb	t3,32(sp)
    17da:	031100a3          	sb	a7,33(sp)
    17de:	02610123          	sb	t1,34(sp)
    17e2:	030101a3          	sb	a6,35(sp)
    17e6:	02a10223          	sb	a0,36(sp)
    17ea:	033102a3          	sb	s3,37(sp)
    17ee:	02b10323          	sb	a1,38(sp)
    17f2:	02c103a3          	sb	a2,39(sp)
    17f6:	0006c683          	lbu	a3,0(a3)
    17fa:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    17fe:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1802:	02d10423          	sb	a3,40(sp)
    1806:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    180a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    180e:	11578263          	beq	a5,s5,1912 <printf+0x2b6>
		len = out_unlocked(s, l);
    1812:	45c9                	li	a1,18
    1814:	0828                	addi	a0,sp,24
    1816:	2d2000ef          	jal	ra,1ae8 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    181a:	00248993          	addi	s3,s1,2
		if (!*s)
    181e:	0009c783          	lbu	a5,0(s3)
    1822:	e6079ee3          	bnez	a5,169e <printf+0x42>
	}
	va_end(ap);
    1826:	70e6                	ld	ra,120(sp)
    1828:	7446                	ld	s0,112(sp)
    182a:	74a6                	ld	s1,104(sp)
    182c:	7906                	ld	s2,96(sp)
    182e:	69e6                	ld	s3,88(sp)
    1830:	6a46                	ld	s4,80(sp)
    1832:	6aa6                	ld	s5,72(sp)
    1834:	6b06                	ld	s6,64(sp)
    1836:	6129                	addi	sp,sp,192
    1838:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    183a:	0005c783          	lbu	a5,0(a1)
    183e:	84ae                	mv	s1,a1
    1840:	01278963          	beq	a5,s2,1852 <printf+0x1f6>
    1844:	b5ad                	j	16ae <printf+0x52>
    1846:	0024c783          	lbu	a5,2(s1)
    184a:	0585                	addi	a1,a1,1
    184c:	0489                	addi	s1,s1,2
    184e:	e72790e3          	bne	a5,s2,16ae <printf+0x52>
    1852:	0014c783          	lbu	a5,1(s1)
    1856:	ff2788e3          	beq	a5,s2,1846 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    185a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    185e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1862:	e5579ce3          	bne	a5,s5,16ba <printf+0x5e>
		mutex_lock(buffer_lock);
    1866:	10ca2503          	lw	a0,268(s4)
    186a:	292010ef          	jal	ra,2afc <mutex_lock>
		len = out_unlocked(s, l);
    186e:	85a2                	mv	a1,s0
    1870:	854e                	mv	a0,s3
    1872:	276000ef          	jal	ra,1ae8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1876:	10ca2503          	lw	a0,268(s4)
    187a:	28e010ef          	jal	ra,2b08 <mutex_unlock>
		if (l)
    187e:	e40404e3          	beqz	s0,16c6 <printf+0x6a>
    1882:	89a6                	mv	s3,s1
    1884:	bd09                	j	1696 <printf+0x3a>
		switch (s[1]) {
    1886:	07800713          	li	a4,120
    188a:	04e79363          	bne	a5,a4,18d0 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    188e:	67c2                	ld	a5,16(sp)
    1890:	45c1                	li	a1,16
		s += 2;
    1892:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1896:	4388                	lw	a0,0(a5)
    1898:	07a1                	addi	a5,a5,8
    189a:	e83e                	sd	a5,16(sp)
    189c:	5f8000ef          	jal	ra,1e94 <printint.constprop.0>
		s += 2;
    18a0:	bfbd                	j	181e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    18a2:	67c2                	ld	a5,16(sp)
    18a4:	6380                	ld	s0,0(a5)
    18a6:	07a1                	addi	a5,a5,8
    18a8:	e83e                	sd	a5,16(sp)
    18aa:	1c040163          	beqz	s0,1a6c <printf+0x410>
			l = strnlen(a, 200);
    18ae:	0c800593          	li	a1,200
    18b2:	8522                	mv	a0,s0
    18b4:	3f7000ef          	jal	ra,24aa <strnlen>
	if (buffer_lock_enabled == 1) {
    18b8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    18bc:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    18c0:	19578663          	beq	a5,s5,1a4c <printf+0x3f0>
		len = out_unlocked(s, l);
    18c4:	8522                	mv	a0,s0
    18c6:	222000ef          	jal	ra,1ae8 <out_unlocked>
		s += 2;
    18ca:	00248993          	addi	s3,s1,2
    18ce:	bf81                	j	181e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    18d0:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18d4:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    18d8:	0f578663          	beq	a5,s5,19c4 <printf+0x368>
		len = out_unlocked(s, l);
    18dc:	0828                	addi	a0,sp,24
    18de:	316000ef          	jal	ra,1bf4 <out_unlocked.constprop.0>
			putchar(s[1]);
    18e2:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    18e6:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18ea:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    18ee:	05578163          	beq	a5,s5,1930 <printf+0x2d4>
		len = out_unlocked(s, l);
    18f2:	0828                	addi	a0,sp,24
    18f4:	300000ef          	jal	ra,1bf4 <out_unlocked.constprop.0>
		s += 2;
    18f8:	00248993          	addi	s3,s1,2
    18fc:	b70d                	j	181e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    18fe:	67c2                	ld	a5,16(sp)
    1900:	45a9                	li	a1,10
		s += 2;
    1902:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1906:	4388                	lw	a0,0(a5)
    1908:	07a1                	addi	a5,a5,8
    190a:	e83e                	sd	a5,16(sp)
    190c:	588000ef          	jal	ra,1e94 <printint.constprop.0>
		s += 2;
    1910:	b739                	j	181e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1912:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1916:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    191a:	1e2010ef          	jal	ra,2afc <mutex_lock>
		len = out_unlocked(s, l);
    191e:	45c9                	li	a1,18
    1920:	0828                	addi	a0,sp,24
    1922:	1c6000ef          	jal	ra,1ae8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1926:	10ca2503          	lw	a0,268(s4)
    192a:	1de010ef          	jal	ra,2b08 <mutex_unlock>
		s += 2;
    192e:	bdc5                	j	181e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1930:	10ca2503          	lw	a0,268(s4)
    1934:	1c8010ef          	jal	ra,2afc <mutex_lock>
		buffer[buffer_len++] = c;
    1938:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    193c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1940:	0017861b          	addiw	a2,a5,1
    1944:	97d2                	add	a5,a5,s4
    1946:	00ca2023          	sw	a2,0(s4)
    194a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    194e:	00c6cc63          	blt	a3,a2,1966 <printf+0x30a>
    1952:	47a9                	li	a5,10
    1954:	06f40663          	beq	s0,a5,19c0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1958:	10ca2503          	lw	a0,268(s4)
		s += 2;
    195c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1960:	1a8010ef          	jal	ra,2b08 <mutex_unlock>
		s += 2;
    1964:	bd6d                	j	181e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1966:	10000793          	li	a5,256
    196a:	00f61e63          	bne	a2,a5,1986 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    196e:	00001597          	auipc	a1,0x1
    1972:	75a58593          	addi	a1,a1,1882 # 30c8 <buffer>
    1976:	4505                	li	a0,1
    1978:	70d000ef          	jal	ra,2884 <write>
	buffer_len = 0;
    197c:	00001797          	auipc	a5,0x1
    1980:	7407a223          	sw	zero,1860(a5) # 30c0 <buffer_len>
			if (r < 0) {
    1984:	bfd1                	j	1958 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1986:	709000ef          	jal	ra,288e <getpid>
    198a:	842a                	mv	s0,a0
    198c:	00001517          	auipc	a0,0x1
    1990:	64450513          	addi	a0,a0,1604 # 2fd0 <enable_deadlock_detect+0x474>
    1994:	5d1000ef          	jal	ra,2764 <basename>
    1998:	872a                	mv	a4,a0
    199a:	00001617          	auipc	a2,0x1
    199e:	21660613          	addi	a2,a2,534 # 2bb0 <enable_deadlock_detect+0x54>
    19a2:	05400793          	li	a5,84
    19a6:	86a2                	mv	a3,s0
    19a8:	45fd                	li	a1,31
    19aa:	00001517          	auipc	a0,0x1
    19ae:	66650513          	addi	a0,a0,1638 # 3010 <enable_deadlock_detect+0x4b4>
    19b2:	cabff0ef          	jal	ra,165c <printf>
    19b6:	557d                	li	a0,-1
    19b8:	707000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    19bc:	000a2603          	lw	a2,0(s4)
    19c0:	de41                	beqz	a2,1958 <printf+0x2fc>
    19c2:	b775                	j	196e <printf+0x312>
		mutex_lock(buffer_lock);
    19c4:	10ca2503          	lw	a0,268(s4)
    19c8:	134010ef          	jal	ra,2afc <mutex_lock>
		buffer[buffer_len++] = c;
    19cc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19d4:	0017861b          	addiw	a2,a5,1
    19d8:	97d2                	add	a5,a5,s4
    19da:	00ca2023          	sw	a2,0(s4)
    19de:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19e2:	02c6d163          	bge	a3,a2,1a04 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    19e6:	10000793          	li	a5,256
    19ea:	02f61263          	bne	a2,a5,1a0e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    19ee:	00001597          	auipc	a1,0x1
    19f2:	6da58593          	addi	a1,a1,1754 # 30c8 <buffer>
    19f6:	4505                	li	a0,1
    19f8:	68d000ef          	jal	ra,2884 <write>
	buffer_len = 0;
    19fc:	00001797          	auipc	a5,0x1
    1a00:	6c07a223          	sw	zero,1732(a5) # 30c0 <buffer_len>
		mutex_unlock(buffer_lock);
    1a04:	10ca2503          	lw	a0,268(s4)
    1a08:	100010ef          	jal	ra,2b08 <mutex_unlock>
    1a0c:	bdd9                	j	18e2 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1a0e:	681000ef          	jal	ra,288e <getpid>
    1a12:	842a                	mv	s0,a0
    1a14:	00001517          	auipc	a0,0x1
    1a18:	5bc50513          	addi	a0,a0,1468 # 2fd0 <enable_deadlock_detect+0x474>
    1a1c:	549000ef          	jal	ra,2764 <basename>
    1a20:	872a                	mv	a4,a0
    1a22:	00001617          	auipc	a2,0x1
    1a26:	18e60613          	addi	a2,a2,398 # 2bb0 <enable_deadlock_detect+0x54>
    1a2a:	05400793          	li	a5,84
    1a2e:	86a2                	mv	a3,s0
    1a30:	45fd                	li	a1,31
    1a32:	00001517          	auipc	a0,0x1
    1a36:	5de50513          	addi	a0,a0,1502 # 3010 <enable_deadlock_detect+0x4b4>
    1a3a:	c23ff0ef          	jal	ra,165c <printf>
    1a3e:	557d                	li	a0,-1
    1a40:	67f000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    1a44:	000a2603          	lw	a2,0(s4)
    1a48:	de55                	beqz	a2,1a04 <printf+0x3a8>
    1a4a:	b755                	j	19ee <printf+0x392>
		mutex_lock(buffer_lock);
    1a4c:	10ca2503          	lw	a0,268(s4)
    1a50:	e42e                	sd	a1,8(sp)
		s += 2;
    1a52:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1a56:	0a6010ef          	jal	ra,2afc <mutex_lock>
		len = out_unlocked(s, l);
    1a5a:	65a2                	ld	a1,8(sp)
    1a5c:	8522                	mv	a0,s0
    1a5e:	08a000ef          	jal	ra,1ae8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1a62:	10ca2503          	lw	a0,268(s4)
    1a66:	0a2010ef          	jal	ra,2b08 <mutex_unlock>
		s += 2;
    1a6a:	bb55                	j	181e <printf+0x1c2>
				a = "(null)";
    1a6c:	00001417          	auipc	s0,0x1
    1a70:	55c40413          	addi	s0,s0,1372 # 2fc8 <enable_deadlock_detect+0x46c>
    1a74:	bd2d                	j	18ae <printf+0x252>

0000000000001a76 <enable_thread_io_buffer>:
{
    1a76:	1101                	addi	sp,sp,-32
    1a78:	e822                	sd	s0,16(sp)
    1a7a:	ec06                	sd	ra,24(sp)
    1a7c:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1a7e:	00001417          	auipc	s0,0x1
    1a82:	64240413          	addi	s0,s0,1602 # 30c0 <buffer_len>
    1a86:	05a010ef          	jal	ra,2ae0 <mutex_create>
    1a8a:	10a42623          	sw	a0,268(s0)
    1a8e:	00054a63          	bltz	a0,1aa2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1a92:	4785                	li	a5,1
}
    1a94:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1a96:	10f42423          	sw	a5,264(s0)
}
    1a9a:	6442                	ld	s0,16(sp)
    1a9c:	64a2                	ld	s1,8(sp)
    1a9e:	6105                	addi	sp,sp,32
    1aa0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1aa2:	5ed000ef          	jal	ra,288e <getpid>
    1aa6:	84aa                	mv	s1,a0
    1aa8:	00001517          	auipc	a0,0x1
    1aac:	52850513          	addi	a0,a0,1320 # 2fd0 <enable_deadlock_detect+0x474>
    1ab0:	4b5000ef          	jal	ra,2764 <basename>
    1ab4:	872a                	mv	a4,a0
    1ab6:	04800793          	li	a5,72
    1aba:	86a6                	mv	a3,s1
    1abc:	00001517          	auipc	a0,0x1
    1ac0:	59450513          	addi	a0,a0,1428 # 3050 <enable_deadlock_detect+0x4f4>
    1ac4:	00001617          	auipc	a2,0x1
    1ac8:	0ec60613          	addi	a2,a2,236 # 2bb0 <enable_deadlock_detect+0x54>
    1acc:	45fd                	li	a1,31
    1ace:	b8fff0ef          	jal	ra,165c <printf>
    1ad2:	557d                	li	a0,-1
    1ad4:	5eb000ef          	jal	ra,28be <exit>
	buffer_lock_enabled = 1;
    1ad8:	4785                	li	a5,1
}
    1ada:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1adc:	10f42423          	sw	a5,264(s0)
}
    1ae0:	6442                	ld	s0,16(sp)
    1ae2:	64a2                	ld	s1,8(sp)
    1ae4:	6105                	addi	sp,sp,32
    1ae6:	8082                	ret

0000000000001ae8 <out_unlocked>:
{
    1ae8:	7159                	addi	sp,sp,-112
    1aea:	f486                	sd	ra,104(sp)
    1aec:	f0a2                	sd	s0,96(sp)
    1aee:	eca6                	sd	s1,88(sp)
    1af0:	e8ca                	sd	s2,80(sp)
    1af2:	e4ce                	sd	s3,72(sp)
    1af4:	e0d2                	sd	s4,64(sp)
    1af6:	fc56                	sd	s5,56(sp)
    1af8:	f85a                	sd	s6,48(sp)
    1afa:	f45e                	sd	s7,40(sp)
    1afc:	f062                	sd	s8,32(sp)
    1afe:	ec66                	sd	s9,24(sp)
    1b00:	e86a                	sd	s10,16(sp)
    1b02:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1b04:	0e058663          	beqz	a1,1bf0 <out_unlocked+0x108>
    1b08:	842a                	mv	s0,a0
    1b0a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1b0e:	4981                	li	s3,0
    1b10:	00001d17          	auipc	s10,0x1
    1b14:	5b0d0d13          	addi	s10,s10,1456 # 30c0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b18:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1b1c:	00001b17          	auipc	s6,0x1
    1b20:	5acb0b13          	addi	s6,s6,1452 # 30c8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1b24:	10000a93          	li	s5,256
    1b28:	00001c97          	auipc	s9,0x1
    1b2c:	4a8c8c93          	addi	s9,s9,1192 # 2fd0 <enable_deadlock_detect+0x474>
    1b30:	00001c17          	auipc	s8,0x1
    1b34:	080c0c13          	addi	s8,s8,128 # 2bb0 <enable_deadlock_detect+0x54>
    1b38:	00001b97          	auipc	s7,0x1
    1b3c:	4d8b8b93          	addi	s7,s7,1240 # 3010 <enable_deadlock_detect+0x4b4>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b40:	4a29                	li	s4,10
    1b42:	a031                	j	1b4e <out_unlocked+0x66>
    1b44:	09468863          	beq	a3,s4,1bd4 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1b48:	0405                	addi	s0,s0,1
    1b4a:	04848163          	beq	s1,s0,1b8c <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1b4e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1b52:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1b56:	0017861b          	addiw	a2,a5,1
    1b5a:	97ea                	add	a5,a5,s10
    1b5c:	00cd2023          	sw	a2,0(s10)
    1b60:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b64:	fec950e3          	bge	s2,a2,1b44 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1b68:	05561263          	bne	a2,s5,1bac <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1b6c:	85da                	mv	a1,s6
    1b6e:	4505                	li	a0,1
    1b70:	515000ef          	jal	ra,2884 <write>
    1b74:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b76:	00001797          	auipc	a5,0x1
    1b7a:	5407a523          	sw	zero,1354(a5) # 30c0 <buffer_len>
			if (r < 0) {
    1b7e:	06054763          	bltz	a0,1bec <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1b82:	0405                	addi	s0,s0,1
			ret += r;
    1b84:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1b88:	fc8493e3          	bne	s1,s0,1b4e <out_unlocked+0x66>
}
    1b8c:	70a6                	ld	ra,104(sp)
    1b8e:	7406                	ld	s0,96(sp)
    1b90:	64e6                	ld	s1,88(sp)
    1b92:	6946                	ld	s2,80(sp)
    1b94:	6a06                	ld	s4,64(sp)
    1b96:	7ae2                	ld	s5,56(sp)
    1b98:	7b42                	ld	s6,48(sp)
    1b9a:	7ba2                	ld	s7,40(sp)
    1b9c:	7c02                	ld	s8,32(sp)
    1b9e:	6ce2                	ld	s9,24(sp)
    1ba0:	6d42                	ld	s10,16(sp)
    1ba2:	6da2                	ld	s11,8(sp)
    1ba4:	854e                	mv	a0,s3
    1ba6:	69a6                	ld	s3,72(sp)
    1ba8:	6165                	addi	sp,sp,112
    1baa:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bac:	4e3000ef          	jal	ra,288e <getpid>
    1bb0:	8daa                	mv	s11,a0
    1bb2:	8566                	mv	a0,s9
    1bb4:	3b1000ef          	jal	ra,2764 <basename>
    1bb8:	872a                	mv	a4,a0
    1bba:	8662                	mv	a2,s8
    1bbc:	05400793          	li	a5,84
    1bc0:	86ee                	mv	a3,s11
    1bc2:	45fd                	li	a1,31
    1bc4:	855e                	mv	a0,s7
    1bc6:	a97ff0ef          	jal	ra,165c <printf>
    1bca:	557d                	li	a0,-1
    1bcc:	4f3000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    1bd0:	000d2603          	lw	a2,0(s10)
    1bd4:	da35                	beqz	a2,1b48 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1bd6:	85da                	mv	a1,s6
    1bd8:	4505                	li	a0,1
    1bda:	4ab000ef          	jal	ra,2884 <write>
    1bde:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1be0:	00001797          	auipc	a5,0x1
    1be4:	4e07a023          	sw	zero,1248(a5) # 30c0 <buffer_len>
			if (r < 0) {
    1be8:	f8055de3          	bgez	a0,1b82 <out_unlocked+0x9a>
    1bec:	89aa                	mv	s3,a0
    1bee:	bf79                	j	1b8c <out_unlocked+0xa4>
	int ret = 0;
    1bf0:	4981                	li	s3,0
    1bf2:	bf69                	j	1b8c <out_unlocked+0xa4>

0000000000001bf4 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1bf4:	1101                	addi	sp,sp,-32
    1bf6:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1bf8:	00001497          	auipc	s1,0x1
    1bfc:	4c848493          	addi	s1,s1,1224 # 30c0 <buffer_len>
    1c00:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1c02:	ec06                	sd	ra,24(sp)
    1c04:	e822                	sd	s0,16(sp)
		char c = s[i];
    1c06:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1c0a:	0017861b          	addiw	a2,a5,1
    1c0e:	97a6                	add	a5,a5,s1
    1c10:	00e78423          	sb	a4,8(a5)
    1c14:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c16:	0ff00793          	li	a5,255
    1c1a:	00c7cc63          	blt	a5,a2,1c32 <out_unlocked.constprop.0+0x3e>
    1c1e:	47a9                	li	a5,10
    1c20:	06f70c63          	beq	a4,a5,1c98 <out_unlocked.constprop.0+0xa4>
    1c24:	4601                	li	a2,0
}
    1c26:	60e2                	ld	ra,24(sp)
    1c28:	6442                	ld	s0,16(sp)
    1c2a:	64a2                	ld	s1,8(sp)
    1c2c:	8532                	mv	a0,a2
    1c2e:	6105                	addi	sp,sp,32
    1c30:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c32:	10000793          	li	a5,256
    1c36:	02f61563          	bne	a2,a5,1c60 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1c3a:	00001597          	auipc	a1,0x1
    1c3e:	48e58593          	addi	a1,a1,1166 # 30c8 <buffer>
    1c42:	4505                	li	a0,1
    1c44:	441000ef          	jal	ra,2884 <write>
}
    1c48:	60e2                	ld	ra,24(sp)
    1c4a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1c4c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1c50:	00001797          	auipc	a5,0x1
    1c54:	4607a823          	sw	zero,1136(a5) # 30c0 <buffer_len>
}
    1c58:	64a2                	ld	s1,8(sp)
    1c5a:	8532                	mv	a0,a2
    1c5c:	6105                	addi	sp,sp,32
    1c5e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c60:	42f000ef          	jal	ra,288e <getpid>
    1c64:	842a                	mv	s0,a0
    1c66:	00001517          	auipc	a0,0x1
    1c6a:	36a50513          	addi	a0,a0,874 # 2fd0 <enable_deadlock_detect+0x474>
    1c6e:	2f7000ef          	jal	ra,2764 <basename>
    1c72:	872a                	mv	a4,a0
    1c74:	00001617          	auipc	a2,0x1
    1c78:	f3c60613          	addi	a2,a2,-196 # 2bb0 <enable_deadlock_detect+0x54>
    1c7c:	05400793          	li	a5,84
    1c80:	86a2                	mv	a3,s0
    1c82:	45fd                	li	a1,31
    1c84:	00001517          	auipc	a0,0x1
    1c88:	38c50513          	addi	a0,a0,908 # 3010 <enable_deadlock_detect+0x4b4>
    1c8c:	9d1ff0ef          	jal	ra,165c <printf>
    1c90:	557d                	li	a0,-1
    1c92:	42d000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    1c96:	4090                	lw	a2,0(s1)
    1c98:	d659                	beqz	a2,1c26 <out_unlocked.constprop.0+0x32>
    1c9a:	b745                	j	1c3a <out_unlocked.constprop.0+0x46>

0000000000001c9c <putchar>:
{
    1c9c:	7139                	addi	sp,sp,-64
    1c9e:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ca0:	00001497          	auipc	s1,0x1
    1ca4:	42048493          	addi	s1,s1,1056 # 30c0 <buffer_len>
    1ca8:	1084a703          	lw	a4,264(s1)
{
    1cac:	f822                	sd	s0,48(sp)
	char byte = c;
    1cae:	0ff57413          	zext.b	s0,a0
{
    1cb2:	fc06                	sd	ra,56(sp)
	char byte = c;
    1cb4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1cb8:	4785                	li	a5,1
    1cba:	00f70d63          	beq	a4,a5,1cd4 <putchar+0x38>
		len = out_unlocked(s, l);
    1cbe:	01f10513          	addi	a0,sp,31
    1cc2:	f33ff0ef          	jal	ra,1bf4 <out_unlocked.constprop.0>
}
    1cc6:	70e2                	ld	ra,56(sp)
    1cc8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1cca:	862a                	mv	a2,a0
}
    1ccc:	74a2                	ld	s1,40(sp)
    1cce:	8532                	mv	a0,a2
    1cd0:	6121                	addi	sp,sp,64
    1cd2:	8082                	ret
		mutex_lock(buffer_lock);
    1cd4:	10c4a503          	lw	a0,268(s1)
    1cd8:	625000ef          	jal	ra,2afc <mutex_lock>
		buffer[buffer_len++] = c;
    1cdc:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cde:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1ce2:	0017861b          	addiw	a2,a5,1
    1ce6:	97a6                	add	a5,a5,s1
    1ce8:	c090                	sw	a2,0(s1)
    1cea:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cee:	02c6c263          	blt	a3,a2,1d12 <putchar+0x76>
    1cf2:	47a9                	li	a5,10
    1cf4:	06f40d63          	beq	s0,a5,1d6e <putchar+0xd2>
    1cf8:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1cfa:	10c4a503          	lw	a0,268(s1)
    1cfe:	e432                	sd	a2,8(sp)
    1d00:	609000ef          	jal	ra,2b08 <mutex_unlock>
    1d04:	6622                	ld	a2,8(sp)
}
    1d06:	70e2                	ld	ra,56(sp)
    1d08:	7442                	ld	s0,48(sp)
    1d0a:	74a2                	ld	s1,40(sp)
    1d0c:	8532                	mv	a0,a2
    1d0e:	6121                	addi	sp,sp,64
    1d10:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1d12:	10000793          	li	a5,256
    1d16:	02f61063          	bne	a2,a5,1d36 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1d1a:	00001597          	auipc	a1,0x1
    1d1e:	3ae58593          	addi	a1,a1,942 # 30c8 <buffer>
    1d22:	4505                	li	a0,1
    1d24:	361000ef          	jal	ra,2884 <write>
    1d28:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1d2c:	00001797          	auipc	a5,0x1
    1d30:	3807aa23          	sw	zero,916(a5) # 30c0 <buffer_len>
			if (r < 0) {
    1d34:	b7d9                	j	1cfa <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1d36:	359000ef          	jal	ra,288e <getpid>
    1d3a:	842a                	mv	s0,a0
    1d3c:	00001517          	auipc	a0,0x1
    1d40:	29450513          	addi	a0,a0,660 # 2fd0 <enable_deadlock_detect+0x474>
    1d44:	221000ef          	jal	ra,2764 <basename>
    1d48:	872a                	mv	a4,a0
    1d4a:	00001617          	auipc	a2,0x1
    1d4e:	e6660613          	addi	a2,a2,-410 # 2bb0 <enable_deadlock_detect+0x54>
    1d52:	05400793          	li	a5,84
    1d56:	86a2                	mv	a3,s0
    1d58:	45fd                	li	a1,31
    1d5a:	00001517          	auipc	a0,0x1
    1d5e:	2b650513          	addi	a0,a0,694 # 3010 <enable_deadlock_detect+0x4b4>
    1d62:	8fbff0ef          	jal	ra,165c <printf>
    1d66:	557d                	li	a0,-1
    1d68:	357000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    1d6c:	4090                	lw	a2,0(s1)
    1d6e:	d651                	beqz	a2,1cfa <putchar+0x5e>
    1d70:	b76d                	j	1d1a <putchar+0x7e>

0000000000001d72 <puts>:
{
    1d72:	7139                	addi	sp,sp,-64
    1d74:	f822                	sd	s0,48(sp)
    1d76:	f426                	sd	s1,40(sp)
    1d78:	fc06                	sd	ra,56(sp)
    1d7a:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1d7c:	00001417          	auipc	s0,0x1
    1d80:	34440413          	addi	s0,s0,836 # 30c0 <buffer_len>
{
    1d84:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d86:	638000ef          	jal	ra,23be <strlen>
	if (buffer_lock_enabled == 1) {
    1d8a:	10842703          	lw	a4,264(s0)
    1d8e:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d90:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1d92:	04f70563          	beq	a4,a5,1ddc <puts+0x6a>
		len = out_unlocked(s, l);
    1d96:	8526                	mv	a0,s1
    1d98:	d51ff0ef          	jal	ra,1ae8 <out_unlocked>
    1d9c:	892a                	mv	s2,a0
    1d9e:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1da0:	00095963          	bgez	s2,1db2 <puts+0x40>
}
    1da4:	70e2                	ld	ra,56(sp)
    1da6:	7442                	ld	s0,48(sp)
    1da8:	7902                	ld	s2,32(sp)
    1daa:	8526                	mv	a0,s1
    1dac:	74a2                	ld	s1,40(sp)
    1dae:	6121                	addi	sp,sp,64
    1db0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1db2:	10842703          	lw	a4,264(s0)
	char byte = c;
    1db6:	44a9                	li	s1,10
    1db8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1dbc:	4785                	li	a5,1
    1dbe:	02f70e63          	beq	a4,a5,1dfa <puts+0x88>
		len = out_unlocked(s, l);
    1dc2:	01f10513          	addi	a0,sp,31
    1dc6:	e2fff0ef          	jal	ra,1bf4 <out_unlocked.constprop.0>
}
    1dca:	70e2                	ld	ra,56(sp)
    1dcc:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1dce:	41f5549b          	sraiw	s1,a0,0x1f
}
    1dd2:	7902                	ld	s2,32(sp)
    1dd4:	8526                	mv	a0,s1
    1dd6:	74a2                	ld	s1,40(sp)
    1dd8:	6121                	addi	sp,sp,64
    1dda:	8082                	ret
		mutex_lock(buffer_lock);
    1ddc:	e42a                	sd	a0,8(sp)
    1dde:	10c42503          	lw	a0,268(s0)
    1de2:	51b000ef          	jal	ra,2afc <mutex_lock>
		len = out_unlocked(s, l);
    1de6:	65a2                	ld	a1,8(sp)
    1de8:	8526                	mv	a0,s1
    1dea:	cffff0ef          	jal	ra,1ae8 <out_unlocked>
    1dee:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1df0:	10c42503          	lw	a0,268(s0)
    1df4:	515000ef          	jal	ra,2b08 <mutex_unlock>
    1df8:	b75d                	j	1d9e <puts+0x2c>
		mutex_lock(buffer_lock);
    1dfa:	10c42503          	lw	a0,268(s0)
    1dfe:	4ff000ef          	jal	ra,2afc <mutex_lock>
		buffer[buffer_len++] = c;
    1e02:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1e04:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1e08:	0017861b          	addiw	a2,a5,1
    1e0c:	97a2                	add	a5,a5,s0
    1e0e:	c010                	sw	a2,0(s0)
    1e10:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1e14:	06c6dc63          	bge	a3,a2,1e8c <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1e18:	10000793          	li	a5,256
    1e1c:	02f61c63          	bne	a2,a5,1e54 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1e20:	00001597          	auipc	a1,0x1
    1e24:	2a858593          	addi	a1,a1,680 # 30c8 <buffer>
    1e28:	4505                	li	a0,1
    1e2a:	25b000ef          	jal	ra,2884 <write>
			if (r < 0) {
    1e2e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1e30:	00001797          	auipc	a5,0x1
    1e34:	2807a823          	sw	zero,656(a5) # 30c0 <buffer_len>
			if (r < 0) {
    1e38:	04054c63          	bltz	a0,1e90 <puts+0x11e>
			if (r < buffer_len) {
    1e3c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1e3e:	10c42503          	lw	a0,268(s0)
    1e42:	4c7000ef          	jal	ra,2b08 <mutex_unlock>
}
    1e46:	70e2                	ld	ra,56(sp)
    1e48:	7442                	ld	s0,48(sp)
    1e4a:	7902                	ld	s2,32(sp)
    1e4c:	8526                	mv	a0,s1
    1e4e:	74a2                	ld	s1,40(sp)
    1e50:	6121                	addi	sp,sp,64
    1e52:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1e54:	23b000ef          	jal	ra,288e <getpid>
    1e58:	84aa                	mv	s1,a0
    1e5a:	00001517          	auipc	a0,0x1
    1e5e:	17650513          	addi	a0,a0,374 # 2fd0 <enable_deadlock_detect+0x474>
    1e62:	103000ef          	jal	ra,2764 <basename>
    1e66:	872a                	mv	a4,a0
    1e68:	00001617          	auipc	a2,0x1
    1e6c:	d4860613          	addi	a2,a2,-696 # 2bb0 <enable_deadlock_detect+0x54>
    1e70:	05400793          	li	a5,84
    1e74:	86a6                	mv	a3,s1
    1e76:	45fd                	li	a1,31
    1e78:	00001517          	auipc	a0,0x1
    1e7c:	19850513          	addi	a0,a0,408 # 3010 <enable_deadlock_detect+0x4b4>
    1e80:	fdcff0ef          	jal	ra,165c <printf>
    1e84:	557d                	li	a0,-1
    1e86:	239000ef          	jal	ra,28be <exit>
	if (buffer_len == 0)
    1e8a:	4010                	lw	a2,0(s0)
    1e8c:	da45                	beqz	a2,1e3c <puts+0xca>
    1e8e:	bf49                	j	1e20 <puts+0xae>
    1e90:	54fd                	li	s1,-1
    1e92:	b775                	j	1e3e <puts+0xcc>

0000000000001e94 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1e94:	715d                	addi	sp,sp,-80
    1e96:	e486                	sd	ra,72(sp)
    1e98:	e0a2                	sd	s0,64(sp)
    1e9a:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1e9c:	14054363          	bltz	a0,1fe2 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ea0:	02b577bb          	remuw	a5,a0,a1
    1ea4:	00001617          	auipc	a2,0x1
    1ea8:	32c60613          	addi	a2,a2,812 # 31d0 <digits>
	buf[16] = 0;
    1eac:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1eb0:	0005871b          	sext.w	a4,a1
    1eb4:	1782                	slli	a5,a5,0x20
    1eb6:	9381                	srli	a5,a5,0x20
    1eb8:	97b2                	add	a5,a5,a2
    1eba:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ebe:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ec2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ec6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ec8:	0eb56763          	bltu	a0,a1,1fb6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ecc:	02e877bb          	remuw	a5,a6,a4
    1ed0:	1782                	slli	a5,a5,0x20
    1ed2:	9381                	srli	a5,a5,0x20
    1ed4:	97b2                	add	a5,a5,a2
    1ed6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1eda:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1ede:	02f10323          	sb	a5,38(sp)
    1ee2:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ee4:	0ce86963          	bltu	a6,a4,1fb6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ee8:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1eec:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1ef0:	1582                	slli	a1,a1,0x20
    1ef2:	9181                	srli	a1,a1,0x20
    1ef4:	95b2                	add	a1,a1,a2
    1ef6:	0005c583          	lbu	a1,0(a1)
    1efa:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1efe:	0007859b          	sext.w	a1,a5
    1f02:	16e6e563          	bltu	a3,a4,206c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1f06:	02e7f6bb          	remuw	a3,a5,a4
    1f0a:	1682                	slli	a3,a3,0x20
    1f0c:	9281                	srli	a3,a3,0x20
    1f0e:	96b2                	add	a3,a3,a2
    1f10:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f14:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1f18:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1f1c:	16e5e163          	bltu	a1,a4,207e <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1f20:	02e876bb          	remuw	a3,a6,a4
    1f24:	1682                	slli	a3,a3,0x20
    1f26:	9281                	srli	a3,a3,0x20
    1f28:	96b2                	add	a3,a3,a2
    1f2a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f2e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f32:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1f36:	14e86d63          	bltu	a6,a4,2090 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1f3a:	02e5f6bb          	remuw	a3,a1,a4
    1f3e:	1682                	slli	a3,a3,0x20
    1f40:	9281                	srli	a3,a3,0x20
    1f42:	96b2                	add	a3,a3,a2
    1f44:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f48:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f4c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1f50:	10e5e563          	bltu	a1,a4,205a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1f54:	02e876bb          	remuw	a3,a6,a4
    1f58:	1682                	slli	a3,a3,0x20
    1f5a:	9281                	srli	a3,a3,0x20
    1f5c:	96b2                	add	a3,a3,a2
    1f5e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f62:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f66:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1f6a:	14e86263          	bltu	a6,a4,20ae <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1f6e:	02e5f6bb          	remuw	a3,a1,a4
    1f72:	1682                	slli	a3,a3,0x20
    1f74:	9281                	srli	a3,a3,0x20
    1f76:	96b2                	add	a3,a3,a2
    1f78:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f7c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f80:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1f84:	14e5e463          	bltu	a1,a4,20cc <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1f88:	02e876bb          	remuw	a3,a6,a4
    1f8c:	1682                	slli	a3,a3,0x20
    1f8e:	9281                	srli	a3,a3,0x20
    1f90:	96b2                	add	a3,a3,a2
    1f92:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f96:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1f9a:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1f9e:	14e86063          	bltu	a6,a4,20de <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1fa2:	1782                	slli	a5,a5,0x20
    1fa4:	9381                	srli	a5,a5,0x20
    1fa6:	97b2                	add	a5,a5,a2
    1fa8:	0007c703          	lbu	a4,0(a5)
    1fac:	4799                	li	a5,6
    1fae:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1fb2:	10054763          	bltz	a0,20c0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1fb6:	00001497          	auipc	s1,0x1
    1fba:	10a48493          	addi	s1,s1,266 # 30c0 <buffer_len>
    1fbe:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1fc2:	0828                	addi	a0,sp,24
    1fc4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1fc6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1fc8:	00f50433          	add	s0,a0,a5
    1fcc:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1fce:	06e68463          	beq	a3,a4,2036 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1fd2:	8522                	mv	a0,s0
    1fd4:	b15ff0ef          	jal	ra,1ae8 <out_unlocked>
}
    1fd8:	60a6                	ld	ra,72(sp)
    1fda:	6406                	ld	s0,64(sp)
    1fdc:	74e2                	ld	s1,56(sp)
    1fde:	6161                	addi	sp,sp,80
    1fe0:	8082                	ret
		x = -xx;
    1fe2:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1fe6:	02b877bb          	remuw	a5,a6,a1
    1fea:	00001617          	auipc	a2,0x1
    1fee:	1e660613          	addi	a2,a2,486 # 31d0 <digits>
	buf[16] = 0;
    1ff2:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ff6:	0005871b          	sext.w	a4,a1
    1ffa:	1782                	slli	a5,a5,0x20
    1ffc:	9381                	srli	a5,a5,0x20
    1ffe:	97b2                	add	a5,a5,a2
    2000:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    2004:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    2008:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    200c:	08b86b63          	bltu	a6,a1,20a2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    2010:	02e8f7bb          	remuw	a5,a7,a4
    2014:	1782                	slli	a5,a5,0x20
    2016:	9381                	srli	a5,a5,0x20
    2018:	97b2                	add	a5,a5,a2
    201a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    201e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    2022:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    2026:	ece8f1e3          	bgeu	a7,a4,1ee8 <printint.constprop.0+0x54>
		buf[i--] = '-';
    202a:	02d00793          	li	a5,45
    202e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    2032:	47b5                	li	a5,13
    2034:	b749                	j	1fb6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    2036:	10c4a503          	lw	a0,268(s1)
    203a:	e42e                	sd	a1,8(sp)
    203c:	2c1000ef          	jal	ra,2afc <mutex_lock>
		len = out_unlocked(s, l);
    2040:	65a2                	ld	a1,8(sp)
    2042:	8522                	mv	a0,s0
    2044:	aa5ff0ef          	jal	ra,1ae8 <out_unlocked>
		mutex_unlock(buffer_lock);
    2048:	10c4a503          	lw	a0,268(s1)
    204c:	2bd000ef          	jal	ra,2b08 <mutex_unlock>
}
    2050:	60a6                	ld	ra,72(sp)
    2052:	6406                	ld	s0,64(sp)
    2054:	74e2                	ld	s1,56(sp)
    2056:	6161                	addi	sp,sp,80
    2058:	8082                	ret
		buf[i--] = digits[x % base];
    205a:	47a9                	li	a5,10
	if (sign)
    205c:	f4055de3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2060:	02d00793          	li	a5,45
    2064:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    2068:	47a5                	li	a5,9
    206a:	b7b1                	j	1fb6 <printint.constprop.0+0x122>
    206c:	47b5                	li	a5,13
	if (sign)
    206e:	f40554e3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2072:	02d00793          	li	a5,45
    2076:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    207a:	47b1                	li	a5,12
    207c:	bf2d                	j	1fb6 <printint.constprop.0+0x122>
    207e:	47b1                	li	a5,12
	if (sign)
    2080:	f2055be3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2084:	02d00793          	li	a5,45
    2088:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    208c:	47ad                	li	a5,11
    208e:	b725                	j	1fb6 <printint.constprop.0+0x122>
    2090:	47ad                	li	a5,11
	if (sign)
    2092:	f20552e3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2096:	02d00793          	li	a5,45
    209a:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    209e:	47a9                	li	a5,10
    20a0:	bf19                	j	1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20a2:	02d00793          	li	a5,45
    20a6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    20aa:	47b9                	li	a5,14
    20ac:	b729                	j	1fb6 <printint.constprop.0+0x122>
    20ae:	47a5                	li	a5,9
	if (sign)
    20b0:	f00553e3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20b4:	02d00793          	li	a5,45
    20b8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    20bc:	47a1                	li	a5,8
    20be:	bde5                	j	1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20c0:	02d00793          	li	a5,45
    20c4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    20c8:	4795                	li	a5,5
    20ca:	b5f5                	j	1fb6 <printint.constprop.0+0x122>
    20cc:	47a1                	li	a5,8
	if (sign)
    20ce:	ee0554e3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20d2:	02d00793          	li	a5,45
    20d6:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    20da:	479d                	li	a5,7
    20dc:	bde9                	j	1fb6 <printint.constprop.0+0x122>
    20de:	479d                	li	a5,7
	if (sign)
    20e0:	ec055be3          	bgez	a0,1fb6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20e4:	02d00793          	li	a5,45
    20e8:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    20ec:	4799                	li	a5,6
    20ee:	b5e1                	j	1fb6 <printint.constprop.0+0x122>

00000000000020f0 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    20f0:	02000793          	li	a5,32
    20f4:	00f50663          	beq	a0,a5,2100 <isspace+0x10>
    20f8:	355d                	addiw	a0,a0,-9
    20fa:	00553513          	sltiu	a0,a0,5
    20fe:	8082                	ret
    2100:	4505                	li	a0,1
}
    2102:	8082                	ret

0000000000002104 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    2104:	fd05051b          	addiw	a0,a0,-48
}
    2108:	00a53513          	sltiu	a0,a0,10
    210c:	8082                	ret

000000000000210e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    210e:	02000613          	li	a2,32
    2112:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    2114:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    2118:	ff77869b          	addiw	a3,a5,-9
    211c:	04c78c63          	beq	a5,a2,2174 <atoi+0x66>
    2120:	0007871b          	sext.w	a4,a5
    2124:	04d5f863          	bgeu	a1,a3,2174 <atoi+0x66>
		s++;
	switch (*s) {
    2128:	02b00693          	li	a3,43
    212c:	04d78963          	beq	a5,a3,217e <atoi+0x70>
    2130:	02d00693          	li	a3,45
    2134:	06d78263          	beq	a5,a3,2198 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    2138:	fd07061b          	addiw	a2,a4,-48
    213c:	47a5                	li	a5,9
    213e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    2140:	4e01                	li	t3,0
	while (isdigit(*s))
    2142:	04c7e963          	bltu	a5,a2,2194 <atoi+0x86>
	int n = 0, neg = 0;
    2146:	4501                	li	a0,0
	while (isdigit(*s))
    2148:	4825                	li	a6,9
    214a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    214e:	0025179b          	slliw	a5,a0,0x2
    2152:	9fa9                	addw	a5,a5,a0
    2154:	fd07031b          	addiw	t1,a4,-48
    2158:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    215c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    2160:	0685                	addi	a3,a3,1
    2162:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    2166:	0006071b          	sext.w	a4,a2
    216a:	feb870e3          	bgeu	a6,a1,214a <atoi+0x3c>
	return neg ? n : -n;
    216e:	000e0563          	beqz	t3,2178 <atoi+0x6a>
}
    2172:	8082                	ret
		s++;
    2174:	0505                	addi	a0,a0,1
    2176:	bf79                	j	2114 <atoi+0x6>
	return neg ? n : -n;
    2178:	4113053b          	subw	a0,t1,a7
    217c:	8082                	ret
	while (isdigit(*s))
    217e:	00154703          	lbu	a4,1(a0)
    2182:	47a5                	li	a5,9
		s++;
    2184:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2188:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    218c:	4e01                	li	t3,0
	while (isdigit(*s))
    218e:	2701                	sext.w	a4,a4
    2190:	fac7fbe3          	bgeu	a5,a2,2146 <atoi+0x38>
    2194:	4501                	li	a0,0
}
    2196:	8082                	ret
	while (isdigit(*s))
    2198:	00154703          	lbu	a4,1(a0)
    219c:	47a5                	li	a5,9
		s++;
    219e:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    21a2:	fd07061b          	addiw	a2,a4,-48
    21a6:	2701                	sext.w	a4,a4
    21a8:	fec7e6e3          	bltu	a5,a2,2194 <atoi+0x86>
		neg = 1;
    21ac:	4e05                	li	t3,1
    21ae:	bf61                	j	2146 <atoi+0x38>

00000000000021b0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    21b0:	16060d63          	beqz	a2,232a <memset+0x17a>
    21b4:	40a007b3          	neg	a5,a0
    21b8:	8b9d                	andi	a5,a5,7
    21ba:	00778693          	addi	a3,a5,7
    21be:	482d                	li	a6,11
    21c0:	0ff5f713          	zext.b	a4,a1
    21c4:	fff60593          	addi	a1,a2,-1
    21c8:	1706e263          	bltu	a3,a6,232c <memset+0x17c>
    21cc:	16d5ea63          	bltu	a1,a3,2340 <memset+0x190>
    21d0:	16078563          	beqz	a5,233a <memset+0x18a>
    21d4:	00e50023          	sb	a4,0(a0)
    21d8:	4685                	li	a3,1
    21da:	00150593          	addi	a1,a0,1
    21de:	14d78c63          	beq	a5,a3,2336 <memset+0x186>
    21e2:	00e500a3          	sb	a4,1(a0)
    21e6:	4689                	li	a3,2
    21e8:	00250593          	addi	a1,a0,2
    21ec:	14d78d63          	beq	a5,a3,2346 <memset+0x196>
    21f0:	00e50123          	sb	a4,2(a0)
    21f4:	468d                	li	a3,3
    21f6:	00350593          	addi	a1,a0,3
    21fa:	12d78b63          	beq	a5,a3,2330 <memset+0x180>
    21fe:	00e501a3          	sb	a4,3(a0)
    2202:	4691                	li	a3,4
    2204:	00450593          	addi	a1,a0,4
    2208:	14d78163          	beq	a5,a3,234a <memset+0x19a>
    220c:	00e50223          	sb	a4,4(a0)
    2210:	4695                	li	a3,5
    2212:	00550593          	addi	a1,a0,5
    2216:	12d78c63          	beq	a5,a3,234e <memset+0x19e>
    221a:	00e502a3          	sb	a4,5(a0)
    221e:	469d                	li	a3,7
    2220:	00650593          	addi	a1,a0,6
    2224:	12d79763          	bne	a5,a3,2352 <memset+0x1a2>
    2228:	00750593          	addi	a1,a0,7
    222c:	00e50323          	sb	a4,6(a0)
    2230:	481d                	li	a6,7
    2232:	00871693          	slli	a3,a4,0x8
    2236:	01071893          	slli	a7,a4,0x10
    223a:	8ed9                	or	a3,a3,a4
    223c:	01871313          	slli	t1,a4,0x18
    2240:	0116e6b3          	or	a3,a3,a7
    2244:	0066e6b3          	or	a3,a3,t1
    2248:	02071893          	slli	a7,a4,0x20
    224c:	02871e13          	slli	t3,a4,0x28
    2250:	0116e6b3          	or	a3,a3,a7
    2254:	40f60333          	sub	t1,a2,a5
    2258:	03071893          	slli	a7,a4,0x30
    225c:	01c6e6b3          	or	a3,a3,t3
    2260:	0116e6b3          	or	a3,a3,a7
    2264:	03871e13          	slli	t3,a4,0x38
    2268:	97aa                	add	a5,a5,a0
    226a:	ff837893          	andi	a7,t1,-8
    226e:	01c6e6b3          	or	a3,a3,t3
    2272:	98be                	add	a7,a7,a5
    2274:	e394                	sd	a3,0(a5)
    2276:	07a1                	addi	a5,a5,8
    2278:	ff179ee3          	bne	a5,a7,2274 <memset+0xc4>
    227c:	ff837893          	andi	a7,t1,-8
    2280:	011587b3          	add	a5,a1,a7
    2284:	010886bb          	addw	a3,a7,a6
    2288:	0b130663          	beq	t1,a7,2334 <memset+0x184>
    228c:	00e78023          	sb	a4,0(a5)
    2290:	0016859b          	addiw	a1,a3,1
    2294:	08c5fb63          	bgeu	a1,a2,232a <memset+0x17a>
    2298:	00e780a3          	sb	a4,1(a5)
    229c:	0026859b          	addiw	a1,a3,2
    22a0:	08c5f563          	bgeu	a1,a2,232a <memset+0x17a>
    22a4:	00e78123          	sb	a4,2(a5)
    22a8:	0036859b          	addiw	a1,a3,3
    22ac:	06c5ff63          	bgeu	a1,a2,232a <memset+0x17a>
    22b0:	00e781a3          	sb	a4,3(a5)
    22b4:	0046859b          	addiw	a1,a3,4
    22b8:	06c5f963          	bgeu	a1,a2,232a <memset+0x17a>
    22bc:	00e78223          	sb	a4,4(a5)
    22c0:	0056859b          	addiw	a1,a3,5
    22c4:	06c5f363          	bgeu	a1,a2,232a <memset+0x17a>
    22c8:	00e782a3          	sb	a4,5(a5)
    22cc:	0066859b          	addiw	a1,a3,6
    22d0:	04c5fd63          	bgeu	a1,a2,232a <memset+0x17a>
    22d4:	00e78323          	sb	a4,6(a5)
    22d8:	0076859b          	addiw	a1,a3,7
    22dc:	04c5f763          	bgeu	a1,a2,232a <memset+0x17a>
    22e0:	00e783a3          	sb	a4,7(a5)
    22e4:	0086859b          	addiw	a1,a3,8
    22e8:	04c5f163          	bgeu	a1,a2,232a <memset+0x17a>
    22ec:	00e78423          	sb	a4,8(a5)
    22f0:	0096859b          	addiw	a1,a3,9
    22f4:	02c5fb63          	bgeu	a1,a2,232a <memset+0x17a>
    22f8:	00e784a3          	sb	a4,9(a5)
    22fc:	00a6859b          	addiw	a1,a3,10
    2300:	02c5f563          	bgeu	a1,a2,232a <memset+0x17a>
    2304:	00e78523          	sb	a4,10(a5)
    2308:	00b6859b          	addiw	a1,a3,11
    230c:	00c5ff63          	bgeu	a1,a2,232a <memset+0x17a>
    2310:	00e785a3          	sb	a4,11(a5)
    2314:	00c6859b          	addiw	a1,a3,12
    2318:	00c5f963          	bgeu	a1,a2,232a <memset+0x17a>
    231c:	00e78623          	sb	a4,12(a5)
    2320:	26b5                	addiw	a3,a3,13
    2322:	00c6f463          	bgeu	a3,a2,232a <memset+0x17a>
    2326:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    232a:	8082                	ret
    232c:	46ad                	li	a3,11
    232e:	bd79                	j	21cc <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2330:	480d                	li	a6,3
    2332:	b701                	j	2232 <memset+0x82>
    2334:	8082                	ret
    2336:	4805                	li	a6,1
    2338:	bded                	j	2232 <memset+0x82>
    233a:	85aa                	mv	a1,a0
    233c:	4801                	li	a6,0
    233e:	bdd5                	j	2232 <memset+0x82>
    2340:	87aa                	mv	a5,a0
    2342:	4681                	li	a3,0
    2344:	b7a1                	j	228c <memset+0xdc>
    2346:	4809                	li	a6,2
    2348:	b5ed                	j	2232 <memset+0x82>
    234a:	4811                	li	a6,4
    234c:	b5dd                	j	2232 <memset+0x82>
    234e:	4815                	li	a6,5
    2350:	b5cd                	j	2232 <memset+0x82>
    2352:	4819                	li	a6,6
    2354:	bdf9                	j	2232 <memset+0x82>

0000000000002356 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2356:	00054783          	lbu	a5,0(a0)
    235a:	0005c703          	lbu	a4,0(a1)
    235e:	00e79863          	bne	a5,a4,236e <strcmp+0x18>
    2362:	0505                	addi	a0,a0,1
    2364:	0585                	addi	a1,a1,1
    2366:	fbe5                	bnez	a5,2356 <strcmp>
    2368:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    236a:	9d19                	subw	a0,a0,a4
    236c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    236e:	0007851b          	sext.w	a0,a5
    2372:	bfe5                	j	236a <strcmp+0x14>

0000000000002374 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2374:	ca15                	beqz	a2,23a8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2376:	00054783          	lbu	a5,0(a0)
	if (!n--)
    237a:	167d                	addi	a2,a2,-1
    237c:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2380:	eb99                	bnez	a5,2396 <strncmp+0x22>
    2382:	a815                	j	23b6 <strncmp+0x42>
    2384:	00a68e63          	beq	a3,a0,23a0 <strncmp+0x2c>
    2388:	0505                	addi	a0,a0,1
    238a:	00f71b63          	bne	a4,a5,23a0 <strncmp+0x2c>
    238e:	00054783          	lbu	a5,0(a0)
    2392:	cf89                	beqz	a5,23ac <strncmp+0x38>
    2394:	85b2                	mv	a1,a2
    2396:	0005c703          	lbu	a4,0(a1)
    239a:	00158613          	addi	a2,a1,1
    239e:	f37d                	bnez	a4,2384 <strncmp+0x10>
		;
	return *l - *r;
    23a0:	0007851b          	sext.w	a0,a5
    23a4:	9d19                	subw	a0,a0,a4
    23a6:	8082                	ret
		return 0;
    23a8:	4501                	li	a0,0
}
    23aa:	8082                	ret
	return *l - *r;
    23ac:	0015c703          	lbu	a4,1(a1)
    23b0:	4501                	li	a0,0
    23b2:	9d19                	subw	a0,a0,a4
    23b4:	8082                	ret
    23b6:	0005c703          	lbu	a4,0(a1)
    23ba:	4501                	li	a0,0
    23bc:	b7e5                	j	23a4 <strncmp+0x30>

00000000000023be <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    23be:	00757793          	andi	a5,a0,7
    23c2:	cf89                	beqz	a5,23dc <strlen+0x1e>
    23c4:	87aa                	mv	a5,a0
    23c6:	a029                	j	23d0 <strlen+0x12>
    23c8:	0785                	addi	a5,a5,1
    23ca:	0077f713          	andi	a4,a5,7
    23ce:	cb01                	beqz	a4,23de <strlen+0x20>
		if (!*s)
    23d0:	0007c703          	lbu	a4,0(a5)
    23d4:	fb75                	bnez	a4,23c8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    23d6:	40a78533          	sub	a0,a5,a0
}
    23da:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23dc:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    23de:	6394                	ld	a3,0(a5)
    23e0:	00001597          	auipc	a1,0x1
    23e4:	cc85b583          	ld	a1,-824(a1) # 30a8 <enable_deadlock_detect+0x54c>
    23e8:	00001617          	auipc	a2,0x1
    23ec:	cc863603          	ld	a2,-824(a2) # 30b0 <enable_deadlock_detect+0x554>
    23f0:	a019                	j	23f6 <strlen+0x38>
    23f2:	6794                	ld	a3,8(a5)
    23f4:	07a1                	addi	a5,a5,8
    23f6:	00b68733          	add	a4,a3,a1
    23fa:	fff6c693          	not	a3,a3
    23fe:	8f75                	and	a4,a4,a3
    2400:	8f71                	and	a4,a4,a2
    2402:	db65                	beqz	a4,23f2 <strlen+0x34>
	for (; *s; s++)
    2404:	0007c703          	lbu	a4,0(a5)
    2408:	d779                	beqz	a4,23d6 <strlen+0x18>
    240a:	0017c703          	lbu	a4,1(a5)
    240e:	0785                	addi	a5,a5,1
    2410:	d379                	beqz	a4,23d6 <strlen+0x18>
    2412:	0017c703          	lbu	a4,1(a5)
    2416:	0785                	addi	a5,a5,1
    2418:	fb6d                	bnez	a4,240a <strlen+0x4c>
    241a:	bf75                	j	23d6 <strlen+0x18>

000000000000241c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    241c:	00757713          	andi	a4,a0,7
{
    2420:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2422:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2426:	cb19                	beqz	a4,243c <memchr+0x20>
    2428:	ce25                	beqz	a2,24a0 <memchr+0x84>
    242a:	0007c703          	lbu	a4,0(a5)
    242e:	04b70e63          	beq	a4,a1,248a <memchr+0x6e>
    2432:	0785                	addi	a5,a5,1
    2434:	0077f713          	andi	a4,a5,7
    2438:	167d                	addi	a2,a2,-1
    243a:	f77d                	bnez	a4,2428 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    243c:	4501                	li	a0,0
	if (n && *s != c) {
    243e:	c235                	beqz	a2,24a2 <memchr+0x86>
    2440:	0007c703          	lbu	a4,0(a5)
    2444:	04b70363          	beq	a4,a1,248a <memchr+0x6e>
		size_t k = ONES * c;
    2448:	00001517          	auipc	a0,0x1
    244c:	c7053503          	ld	a0,-912(a0) # 30b8 <enable_deadlock_detect+0x55c>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2450:	471d                	li	a4,7
		size_t k = ONES * c;
    2452:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2456:	02c77a63          	bgeu	a4,a2,248a <memchr+0x6e>
    245a:	00001897          	auipc	a7,0x1
    245e:	c4e8b883          	ld	a7,-946(a7) # 30a8 <enable_deadlock_detect+0x54c>
    2462:	00001817          	auipc	a6,0x1
    2466:	c4e83803          	ld	a6,-946(a6) # 30b0 <enable_deadlock_detect+0x554>
    246a:	431d                	li	t1,7
    246c:	a029                	j	2476 <memchr+0x5a>
		     w++, n -= SS)
    246e:	1661                	addi	a2,a2,-8
    2470:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2472:	02c37963          	bgeu	t1,a2,24a4 <memchr+0x88>
    2476:	6398                	ld	a4,0(a5)
    2478:	8f29                	xor	a4,a4,a0
    247a:	011706b3          	add	a3,a4,a7
    247e:	fff74713          	not	a4,a4
    2482:	8f75                	and	a4,a4,a3
    2484:	01077733          	and	a4,a4,a6
    2488:	d37d                	beqz	a4,246e <memchr+0x52>
{
    248a:	853e                	mv	a0,a5
    248c:	97b2                	add	a5,a5,a2
    248e:	a021                	j	2496 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2490:	0505                	addi	a0,a0,1
    2492:	00f50763          	beq	a0,a5,24a0 <memchr+0x84>
    2496:	00054703          	lbu	a4,0(a0)
    249a:	feb71be3          	bne	a4,a1,2490 <memchr+0x74>
    249e:	8082                	ret
	return n ? (void *)s : 0;
    24a0:	4501                	li	a0,0
}
    24a2:	8082                	ret
	return n ? (void *)s : 0;
    24a4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    24a6:	f275                	bnez	a2,248a <memchr+0x6e>
}
    24a8:	8082                	ret

00000000000024aa <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    24aa:	1101                	addi	sp,sp,-32
    24ac:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    24ae:	862e                	mv	a2,a1
{
    24b0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    24b2:	4581                	li	a1,0
{
    24b4:	e426                	sd	s1,8(sp)
    24b6:	ec06                	sd	ra,24(sp)
    24b8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    24ba:	f63ff0ef          	jal	ra,241c <memchr>
	return p ? p - s : n;
    24be:	c519                	beqz	a0,24cc <strnlen+0x22>
}
    24c0:	60e2                	ld	ra,24(sp)
    24c2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    24c4:	8d05                	sub	a0,a0,s1
}
    24c6:	64a2                	ld	s1,8(sp)
    24c8:	6105                	addi	sp,sp,32
    24ca:	8082                	ret
    24cc:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    24ce:	8522                	mv	a0,s0
}
    24d0:	6442                	ld	s0,16(sp)
    24d2:	64a2                	ld	s1,8(sp)
    24d4:	6105                	addi	sp,sp,32
    24d6:	8082                	ret

00000000000024d8 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    24d8:	00a5c7b3          	xor	a5,a1,a0
    24dc:	8b9d                	andi	a5,a5,7
    24de:	eb95                	bnez	a5,2512 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    24e0:	0075f793          	andi	a5,a1,7
    24e4:	e7b1                	bnez	a5,2530 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    24e6:	6198                	ld	a4,0(a1)
    24e8:	00001617          	auipc	a2,0x1
    24ec:	bc063603          	ld	a2,-1088(a2) # 30a8 <enable_deadlock_detect+0x54c>
    24f0:	00001817          	auipc	a6,0x1
    24f4:	bc083803          	ld	a6,-1088(a6) # 30b0 <enable_deadlock_detect+0x554>
    24f8:	a029                	j	2502 <stpcpy+0x2a>
    24fa:	05a1                	addi	a1,a1,8
    24fc:	e118                	sd	a4,0(a0)
    24fe:	6198                	ld	a4,0(a1)
    2500:	0521                	addi	a0,a0,8
    2502:	00c707b3          	add	a5,a4,a2
    2506:	fff74693          	not	a3,a4
    250a:	8ff5                	and	a5,a5,a3
    250c:	0107f7b3          	and	a5,a5,a6
    2510:	d7ed                	beqz	a5,24fa <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2512:	0005c783          	lbu	a5,0(a1)
    2516:	00f50023          	sb	a5,0(a0)
    251a:	c785                	beqz	a5,2542 <stpcpy+0x6a>
    251c:	0015c783          	lbu	a5,1(a1)
    2520:	0505                	addi	a0,a0,1
    2522:	0585                	addi	a1,a1,1
    2524:	00f50023          	sb	a5,0(a0)
    2528:	fbf5                	bnez	a5,251c <stpcpy+0x44>
		;
	return d;
}
    252a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    252c:	0505                	addi	a0,a0,1
    252e:	df45                	beqz	a4,24e6 <stpcpy+0xe>
			if (!(*d = *s))
    2530:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2534:	0585                	addi	a1,a1,1
    2536:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    253a:	00f50023          	sb	a5,0(a0)
    253e:	f7fd                	bnez	a5,252c <stpcpy+0x54>
}
    2540:	8082                	ret
    2542:	8082                	ret

0000000000002544 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2544:	00a5c7b3          	xor	a5,a1,a0
    2548:	8b9d                	andi	a5,a5,7
    254a:	1a079863          	bnez	a5,26fa <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    254e:	0075f793          	andi	a5,a1,7
    2552:	16078463          	beqz	a5,26ba <stpncpy+0x176>
    2556:	ea01                	bnez	a2,2566 <stpncpy+0x22>
    2558:	a421                	j	2760 <stpncpy+0x21c>
    255a:	167d                	addi	a2,a2,-1
    255c:	0505                	addi	a0,a0,1
    255e:	14070e63          	beqz	a4,26ba <stpncpy+0x176>
    2562:	1a060863          	beqz	a2,2712 <stpncpy+0x1ce>
    2566:	0005c783          	lbu	a5,0(a1)
    256a:	0585                	addi	a1,a1,1
    256c:	0075f713          	andi	a4,a1,7
    2570:	00f50023          	sb	a5,0(a0)
    2574:	f3fd                	bnez	a5,255a <stpncpy+0x16>
    2576:	4805                	li	a6,1
    2578:	1a061863          	bnez	a2,2728 <stpncpy+0x1e4>
    257c:	40a007b3          	neg	a5,a0
    2580:	8b9d                	andi	a5,a5,7
    2582:	4681                	li	a3,0
    2584:	18061a63          	bnez	a2,2718 <stpncpy+0x1d4>
    2588:	00778713          	addi	a4,a5,7
    258c:	45ad                	li	a1,11
    258e:	18b76363          	bltu	a4,a1,2714 <stpncpy+0x1d0>
    2592:	1ae6eb63          	bltu	a3,a4,2748 <stpncpy+0x204>
    2596:	1a078363          	beqz	a5,273c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    259a:	00050023          	sb	zero,0(a0)
    259e:	4685                	li	a3,1
    25a0:	00150713          	addi	a4,a0,1
    25a4:	18d78f63          	beq	a5,a3,2742 <stpncpy+0x1fe>
    25a8:	000500a3          	sb	zero,1(a0)
    25ac:	4689                	li	a3,2
    25ae:	00250713          	addi	a4,a0,2
    25b2:	18d78e63          	beq	a5,a3,274e <stpncpy+0x20a>
    25b6:	00050123          	sb	zero,2(a0)
    25ba:	468d                	li	a3,3
    25bc:	00350713          	addi	a4,a0,3
    25c0:	16d78c63          	beq	a5,a3,2738 <stpncpy+0x1f4>
    25c4:	000501a3          	sb	zero,3(a0)
    25c8:	4691                	li	a3,4
    25ca:	00450713          	addi	a4,a0,4
    25ce:	18d78263          	beq	a5,a3,2752 <stpncpy+0x20e>
    25d2:	00050223          	sb	zero,4(a0)
    25d6:	4695                	li	a3,5
    25d8:	00550713          	addi	a4,a0,5
    25dc:	16d78d63          	beq	a5,a3,2756 <stpncpy+0x212>
    25e0:	000502a3          	sb	zero,5(a0)
    25e4:	469d                	li	a3,7
    25e6:	00650713          	addi	a4,a0,6
    25ea:	16d79863          	bne	a5,a3,275a <stpncpy+0x216>
    25ee:	00750713          	addi	a4,a0,7
    25f2:	00050323          	sb	zero,6(a0)
    25f6:	40f80833          	sub	a6,a6,a5
    25fa:	ff887593          	andi	a1,a6,-8
    25fe:	97aa                	add	a5,a5,a0
    2600:	95be                	add	a1,a1,a5
    2602:	0007b023          	sd	zero,0(a5)
    2606:	07a1                	addi	a5,a5,8
    2608:	feb79de3          	bne	a5,a1,2602 <stpncpy+0xbe>
    260c:	ff887593          	andi	a1,a6,-8
    2610:	9ead                	addw	a3,a3,a1
    2612:	00b707b3          	add	a5,a4,a1
    2616:	12b80863          	beq	a6,a1,2746 <stpncpy+0x202>
    261a:	00078023          	sb	zero,0(a5)
    261e:	0016871b          	addiw	a4,a3,1
    2622:	0ec77863          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2626:	000780a3          	sb	zero,1(a5)
    262a:	0026871b          	addiw	a4,a3,2
    262e:	0ec77263          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2632:	00078123          	sb	zero,2(a5)
    2636:	0036871b          	addiw	a4,a3,3
    263a:	0cc77c63          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    263e:	000781a3          	sb	zero,3(a5)
    2642:	0046871b          	addiw	a4,a3,4
    2646:	0cc77663          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    264a:	00078223          	sb	zero,4(a5)
    264e:	0056871b          	addiw	a4,a3,5
    2652:	0cc77063          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2656:	000782a3          	sb	zero,5(a5)
    265a:	0066871b          	addiw	a4,a3,6
    265e:	0ac77a63          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2662:	00078323          	sb	zero,6(a5)
    2666:	0076871b          	addiw	a4,a3,7
    266a:	0ac77463          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    266e:	000783a3          	sb	zero,7(a5)
    2672:	0086871b          	addiw	a4,a3,8
    2676:	08c77e63          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    267a:	00078423          	sb	zero,8(a5)
    267e:	0096871b          	addiw	a4,a3,9
    2682:	08c77863          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2686:	000784a3          	sb	zero,9(a5)
    268a:	00a6871b          	addiw	a4,a3,10
    268e:	08c77263          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    2692:	00078523          	sb	zero,10(a5)
    2696:	00b6871b          	addiw	a4,a3,11
    269a:	06c77c63          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    269e:	000785a3          	sb	zero,11(a5)
    26a2:	00c6871b          	addiw	a4,a3,12
    26a6:	06c77663          	bgeu	a4,a2,2712 <stpncpy+0x1ce>
    26aa:	00078623          	sb	zero,12(a5)
    26ae:	26b5                	addiw	a3,a3,13
    26b0:	06c6f163          	bgeu	a3,a2,2712 <stpncpy+0x1ce>
    26b4:	000786a3          	sb	zero,13(a5)
    26b8:	8082                	ret
			;
		if (!n || !*s)
    26ba:	c645                	beqz	a2,2762 <stpncpy+0x21e>
    26bc:	0005c783          	lbu	a5,0(a1)
    26c0:	ea078be3          	beqz	a5,2576 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    26c4:	479d                	li	a5,7
    26c6:	02c7ff63          	bgeu	a5,a2,2704 <stpncpy+0x1c0>
    26ca:	00001897          	auipc	a7,0x1
    26ce:	9de8b883          	ld	a7,-1570(a7) # 30a8 <enable_deadlock_detect+0x54c>
    26d2:	00001817          	auipc	a6,0x1
    26d6:	9de83803          	ld	a6,-1570(a6) # 30b0 <enable_deadlock_detect+0x554>
    26da:	431d                	li	t1,7
    26dc:	6198                	ld	a4,0(a1)
    26de:	011707b3          	add	a5,a4,a7
    26e2:	fff74693          	not	a3,a4
    26e6:	8ff5                	and	a5,a5,a3
    26e8:	0107f7b3          	and	a5,a5,a6
    26ec:	ef81                	bnez	a5,2704 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    26ee:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    26f0:	1661                	addi	a2,a2,-8
    26f2:	05a1                	addi	a1,a1,8
    26f4:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    26f6:	fec363e3          	bltu	t1,a2,26dc <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    26fa:	e609                	bnez	a2,2704 <stpncpy+0x1c0>
    26fc:	a08d                	j	275e <stpncpy+0x21a>
    26fe:	167d                	addi	a2,a2,-1
    2700:	0505                	addi	a0,a0,1
    2702:	ca01                	beqz	a2,2712 <stpncpy+0x1ce>
    2704:	0005c783          	lbu	a5,0(a1)
    2708:	0585                	addi	a1,a1,1
    270a:	00f50023          	sb	a5,0(a0)
    270e:	fbe5                	bnez	a5,26fe <stpncpy+0x1ba>
		;
tail:
    2710:	b59d                	j	2576 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2712:	8082                	ret
    2714:	472d                	li	a4,11
    2716:	bdb5                	j	2592 <stpncpy+0x4e>
    2718:	00778713          	addi	a4,a5,7
    271c:	45ad                	li	a1,11
    271e:	fff60693          	addi	a3,a2,-1
    2722:	e6b778e3          	bgeu	a4,a1,2592 <stpncpy+0x4e>
    2726:	b7fd                	j	2714 <stpncpy+0x1d0>
    2728:	40a007b3          	neg	a5,a0
    272c:	8832                	mv	a6,a2
    272e:	8b9d                	andi	a5,a5,7
    2730:	4681                	li	a3,0
    2732:	e4060be3          	beqz	a2,2588 <stpncpy+0x44>
    2736:	b7cd                	j	2718 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2738:	468d                	li	a3,3
    273a:	bd75                	j	25f6 <stpncpy+0xb2>
    273c:	872a                	mv	a4,a0
    273e:	4681                	li	a3,0
    2740:	bd5d                	j	25f6 <stpncpy+0xb2>
    2742:	4685                	li	a3,1
    2744:	bd4d                	j	25f6 <stpncpy+0xb2>
    2746:	8082                	ret
    2748:	87aa                	mv	a5,a0
    274a:	4681                	li	a3,0
    274c:	b5f9                	j	261a <stpncpy+0xd6>
    274e:	4689                	li	a3,2
    2750:	b55d                	j	25f6 <stpncpy+0xb2>
    2752:	4691                	li	a3,4
    2754:	b54d                	j	25f6 <stpncpy+0xb2>
    2756:	4695                	li	a3,5
    2758:	bd79                	j	25f6 <stpncpy+0xb2>
    275a:	4699                	li	a3,6
    275c:	bd69                	j	25f6 <stpncpy+0xb2>
    275e:	8082                	ret
    2760:	8082                	ret
    2762:	8082                	ret

0000000000002764 <basename>:

char *basename(char *s)
{
    2764:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2766:	c54d                	beqz	a0,2810 <basename+0xac>
    2768:	00054783          	lbu	a5,0(a0)
		return ".";
    276c:	00001517          	auipc	a0,0x1
    2770:	93450513          	addi	a0,a0,-1740 # 30a0 <enable_deadlock_detect+0x544>
	if (!s || !*s)
    2774:	e391                	bnez	a5,2778 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2776:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2778:	0076f713          	andi	a4,a3,7
    277c:	87b6                	mv	a5,a3
    277e:	cf51                	beqz	a4,281a <basename+0xb6>
    2780:	0785                	addi	a5,a5,1
    2782:	0077f713          	andi	a4,a5,7
    2786:	c729                	beqz	a4,27d0 <basename+0x6c>
		if (!*s)
    2788:	0007c703          	lbu	a4,0(a5)
    278c:	fb75                	bnez	a4,2780 <basename+0x1c>
	return s - a;
    278e:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2790:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2792:	cf8d                	beqz	a5,27cc <basename+0x68>
    2794:	00f68733          	add	a4,a3,a5
    2798:	02f00593          	li	a1,47
    279c:	a031                	j	27a8 <basename+0x44>
		s[i] = 0;
    279e:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    27a2:	17fd                	addi	a5,a5,-1
    27a4:	177d                	addi	a4,a4,-1
    27a6:	c39d                	beqz	a5,27cc <basename+0x68>
    27a8:	00074603          	lbu	a2,0(a4)
    27ac:	feb609e3          	beq	a2,a1,279e <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    27b0:	02f00613          	li	a2,47
    27b4:	a011                	j	27b8 <basename+0x54>
    27b6:	cb99                	beqz	a5,27cc <basename+0x68>
    27b8:	853e                	mv	a0,a5
    27ba:	17fd                	addi	a5,a5,-1
    27bc:	00f68733          	add	a4,a3,a5
    27c0:	00074703          	lbu	a4,0(a4)
    27c4:	fec719e3          	bne	a4,a2,27b6 <basename+0x52>
	return s + i;
    27c8:	9536                	add	a0,a0,a3
    27ca:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    27cc:	8536                	mv	a0,a3
    27ce:	8082                	ret
    27d0:	6390                	ld	a2,0(a5)
    27d2:	00001517          	auipc	a0,0x1
    27d6:	8d653503          	ld	a0,-1834(a0) # 30a8 <enable_deadlock_detect+0x54c>
    27da:	00001597          	auipc	a1,0x1
    27de:	8d65b583          	ld	a1,-1834(a1) # 30b0 <enable_deadlock_detect+0x554>
    27e2:	fff64713          	not	a4,a2
    27e6:	962a                	add	a2,a2,a0
    27e8:	8f71                	and	a4,a4,a2
    27ea:	8f6d                	and	a4,a4,a1
    27ec:	eb11                	bnez	a4,2800 <basename+0x9c>
    27ee:	6790                	ld	a2,8(a5)
    27f0:	07a1                	addi	a5,a5,8
    27f2:	00a60733          	add	a4,a2,a0
    27f6:	fff64613          	not	a2,a2
    27fa:	8f71                	and	a4,a4,a2
    27fc:	8f6d                	and	a4,a4,a1
    27fe:	db65                	beqz	a4,27ee <basename+0x8a>
	for (; *s; s++)
    2800:	0007c703          	lbu	a4,0(a5)
    2804:	d749                	beqz	a4,278e <basename+0x2a>
    2806:	0017c703          	lbu	a4,1(a5)
    280a:	0785                	addi	a5,a5,1
    280c:	ff6d                	bnez	a4,2806 <basename+0xa2>
    280e:	b741                	j	278e <basename+0x2a>
		return ".";
    2810:	00001517          	auipc	a0,0x1
    2814:	89050513          	addi	a0,a0,-1904 # 30a0 <enable_deadlock_detect+0x544>
    2818:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    281a:	6290                	ld	a2,0(a3)
    281c:	00001517          	auipc	a0,0x1
    2820:	88c53503          	ld	a0,-1908(a0) # 30a8 <enable_deadlock_detect+0x54c>
    2824:	00001597          	auipc	a1,0x1
    2828:	88c5b583          	ld	a1,-1908(a1) # 30b0 <enable_deadlock_detect+0x554>
    282c:	fff64713          	not	a4,a2
    2830:	962a                	add	a2,a2,a0
    2832:	8f71                	and	a4,a4,a2
    2834:	8f6d                	and	a4,a4,a1
    2836:	df45                	beqz	a4,27ee <basename+0x8a>
    2838:	b7f9                	j	2806 <basename+0xa2>

000000000000283a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    283a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    283e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2840:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2844:	2501                	sext.w	a0,a0
    2846:	8082                	ret

0000000000002848 <close>:

int close(int fd)
{
	if (fd == 1) {
    2848:	4785                	li	a5,1
    284a:	00f50863          	beq	a0,a5,285a <close+0x12>
	register long a7 __asm__("a7") = n;
    284e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2852:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2856:	2501                	sext.w	a0,a0
    2858:	8082                	ret
{
    285a:	1101                	addi	sp,sp,-32
    285c:	ec06                	sd	ra,24(sp)
    285e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2860:	cdffe0ef          	jal	ra,153e <__write_buffer>
		__clear_buffer();
    2864:	d03fe0ef          	jal	ra,1566 <__clear_buffer>
    2868:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    286a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    286e:	00000073          	ecall
}
    2872:	60e2                	ld	ra,24(sp)
    2874:	2501                	sext.w	a0,a0
    2876:	6105                	addi	sp,sp,32
    2878:	8082                	ret

000000000000287a <read>:
	register long a7 __asm__("a7") = n;
    287a:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    287e:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2882:	8082                	ret

0000000000002884 <write>:
	register long a7 __asm__("a7") = n;
    2884:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2888:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    288c:	8082                	ret

000000000000288e <getpid>:
	register long a7 __asm__("a7") = n;
    288e:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2892:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2896:	2501                	sext.w	a0,a0
    2898:	8082                	ret

000000000000289a <getppid>:
	register long a7 __asm__("a7") = n;
    289a:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    289e:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    28a2:	2501                	sext.w	a0,a0
    28a4:	8082                	ret

00000000000028a6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    28a6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    28aa:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    28ae:	2501                	sext.w	a0,a0
    28b0:	8082                	ret

00000000000028b2 <fork>:
	register long a7 __asm__("a7") = n;
    28b2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    28b6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    28ba:	2501                	sext.w	a0,a0
    28bc:	8082                	ret

00000000000028be <exit>:

void exit(int code)
{
    28be:	1141                	addi	sp,sp,-16
    28c0:	e406                	sd	ra,8(sp)
    28c2:	e022                	sd	s0,0(sp)
    28c4:	842a                	mv	s0,a0
	__write_buffer();
    28c6:	c79fe0ef          	jal	ra,153e <__write_buffer>
	__clear_buffer();
    28ca:	c9dfe0ef          	jal	ra,1566 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    28ce:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    28d2:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    28d4:	00000073          	ecall
	syscall(SYS_exit, code);
}
    28d8:	60a2                	ld	ra,8(sp)
    28da:	6402                	ld	s0,0(sp)
    28dc:	0141                	addi	sp,sp,16
    28de:	8082                	ret

00000000000028e0 <waitpid>:
	register long a7 __asm__("a7") = n;
    28e0:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28e4:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    28e8:	2501                	sext.w	a0,a0
    28ea:	8082                	ret

00000000000028ec <exec>:
	register long a7 __asm__("a7") = n;
    28ec:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28f0:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    28f4:	2501                	sext.w	a0,a0
    28f6:	8082                	ret

00000000000028f8 <get_mtime>:

int64 get_mtime()
{
    28f8:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    28fa:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    28fe:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2900:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2902:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2906:	2501                	sext.w	a0,a0
    2908:	ed01                	bnez	a0,2920 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    290a:	6722                	ld	a4,8(sp)
    290c:	3e800793          	li	a5,1000
    2910:	6682                	ld	a3,0(sp)
    2912:	02f75733          	divu	a4,a4,a5
    2916:	02d78533          	mul	a0,a5,a3
    291a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    291c:	0141                	addi	sp,sp,16
    291e:	8082                	ret
	return -1;
    2920:	557d                	li	a0,-1
    2922:	bfed                	j	291c <get_mtime+0x24>

0000000000002924 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2924:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2928:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    292c:	2501                	sext.w	a0,a0
    292e:	8082                	ret

0000000000002930 <sleep>:

int sleep(unsigned long long time)
{
    2930:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2932:	880a                	mv	a6,sp
{
    2934:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2936:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    293a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    293c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    293e:	00000073          	ecall
	if (err == 0) {
    2942:	2501                	sext.w	a0,a0
    2944:	ed31                	bnez	a0,29a0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2946:	6722                	ld	a4,8(sp)
    2948:	3e800793          	li	a5,1000
    294c:	6682                	ld	a3,0(sp)
    294e:	02f75733          	divu	a4,a4,a5
    2952:	02d787b3          	mul	a5,a5,a3
    2956:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2958:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    295c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    295e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2960:	00000073          	ecall
	if (err == 0) {
    2964:	2501                	sext.w	a0,a0
    2966:	e915                	bnez	a0,299a <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2968:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    296a:	3e800693          	li	a3,1000
    296e:	a819                	j	2984 <sleep+0x54>
	__asm_syscall("r"(a7))
    2970:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2974:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2978:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    297a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    297c:	00000073          	ecall
	if (err == 0) {
    2980:	2501                	sext.w	a0,a0
    2982:	ed01                	bnez	a0,299a <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2984:	6722                	ld	a4,8(sp)
    2986:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2988:	07c00893          	li	a7,124
    298c:	02d75733          	divu	a4,a4,a3
    2990:	02f687b3          	mul	a5,a3,a5
    2994:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2996:	fcc7ede3          	bltu	a5,a2,2970 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    299a:	4501                	li	a0,0
    299c:	0141                	addi	sp,sp,16
    299e:	8082                	ret
    29a0:	57fd                	li	a5,-1
    29a2:	bf5d                	j	2958 <sleep+0x28>

00000000000029a4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    29a4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    29a8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    29ac:	2501                	sext.w	a0,a0
    29ae:	8082                	ret

00000000000029b0 <set_priority>:
	register long a7 __asm__("a7") = n;
    29b0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    29b4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    29b8:	2501                	sext.w	a0,a0
    29ba:	8082                	ret

00000000000029bc <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    29bc:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    29c0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    29c4:	2501                	sext.w	a0,a0
    29c6:	8082                	ret

00000000000029c8 <munmap>:
	register long a7 __asm__("a7") = n;
    29c8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29cc:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    29d0:	2501                	sext.w	a0,a0
    29d2:	8082                	ret

00000000000029d4 <wait>:

int wait(int *code)
{
    29d4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    29d6:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    29da:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29dc:	00000073          	ecall
	return waitpid(-1, code);
}
    29e0:	2501                	sext.w	a0,a0
    29e2:	8082                	ret

00000000000029e4 <spawn>:
	register long a7 __asm__("a7") = n;
    29e4:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    29e8:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    29ec:	2501                	sext.w	a0,a0
    29ee:	8082                	ret

00000000000029f0 <pipe>:
	register long a7 __asm__("a7") = n;
    29f0:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    29f4:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    29f8:	2501                	sext.w	a0,a0
    29fa:	8082                	ret

00000000000029fc <mailread>:
	register long a7 __asm__("a7") = n;
    29fc:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a00:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2a04:	2501                	sext.w	a0,a0
    2a06:	8082                	ret

0000000000002a08 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2a08:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a0c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2a10:	2501                	sext.w	a0,a0
    2a12:	8082                	ret

0000000000002a14 <fstat>:
	register long a7 __asm__("a7") = n;
    2a14:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a18:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2a1c:	2501                	sext.w	a0,a0
    2a1e:	8082                	ret

0000000000002a20 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2a20:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2a22:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2a26:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a28:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2a2c:	2501                	sext.w	a0,a0
    2a2e:	8082                	ret

0000000000002a30 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2a30:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2a32:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2a36:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a38:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2a3c:	2501                	sext.w	a0,a0
    2a3e:	8082                	ret

0000000000002a40 <link>:

int link(char *old_path, char *new_path)
{
    2a40:	87aa                	mv	a5,a0
    2a42:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2a44:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2a48:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2a4c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2a4e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2a52:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a54:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2a58:	2501                	sext.w	a0,a0
    2a5a:	8082                	ret

0000000000002a5c <unlink>:

int unlink(char *path)
{
    2a5c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2a5e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2a62:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2a66:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a68:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2a6c:	2501                	sext.w	a0,a0
    2a6e:	8082                	ret

0000000000002a70 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2a70:	00000797          	auipc	a5,0x0
    2a74:	7807b783          	ld	a5,1920(a5) # 31f0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2a78:	439c                	lw	a5,0(a5)
    2a7a:	c799                	beqz	a5,2a88 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2a7c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a80:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2a84:	2501                	sext.w	a0,a0
    2a86:	8082                	ret
{
    2a88:	1101                	addi	sp,sp,-32
    2a8a:	ec06                	sd	ra,24(sp)
    2a8c:	e42e                	sd	a1,8(sp)
    2a8e:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2a90:	fe7fe0ef          	jal	ra,1a76 <enable_thread_io_buffer>
    2a94:	65a2                	ld	a1,8(sp)
    2a96:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2a98:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a9c:	00000073          	ecall
}
    2aa0:	60e2                	ld	ra,24(sp)
    2aa2:	2501                	sext.w	a0,a0
    2aa4:	6105                	addi	sp,sp,32
    2aa6:	8082                	ret

0000000000002aa8 <gettid>:
	register long a7 __asm__("a7") = n;
    2aa8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2aac:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2ab0:	2501                	sext.w	a0,a0
    2ab2:	8082                	ret

0000000000002ab4 <waittid>:

int waittid(int tid)
{
    2ab4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2ab6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2aba:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2abe:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2ac0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2ac2:	00e51e63          	bne	a0,a4,2ade <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2ac6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2aca:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2ace:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2ad2:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2ad4:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2ad8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2ada:	fee506e3          	beq	a0,a4,2ac6 <waittid+0x12>
	}
	return ret;
}
    2ade:	8082                	ret

0000000000002ae0 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2ae0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2ae4:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2ae6:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2aea:	2501                	sext.w	a0,a0
    2aec:	8082                	ret

0000000000002aee <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2aee:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2af2:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2af4:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2af8:	2501                	sext.w	a0,a0
    2afa:	8082                	ret

0000000000002afc <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2afc:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2b00:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2b04:	2501                	sext.w	a0,a0
    2b06:	8082                	ret

0000000000002b08 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2b08:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2b0c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2b10:	2501                	sext.w	a0,a0
    2b12:	8082                	ret

0000000000002b14 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2b14:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2b18:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2b1c:	2501                	sext.w	a0,a0
    2b1e:	8082                	ret

0000000000002b20 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2b20:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2b24:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2b28:	2501                	sext.w	a0,a0
    2b2a:	8082                	ret

0000000000002b2c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2b2c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2b30:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2b34:	2501                	sext.w	a0,a0
    2b36:	8082                	ret

0000000000002b38 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2b38:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2b3c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2b40:	2501                	sext.w	a0,a0
    2b42:	8082                	ret

0000000000002b44 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2b44:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2b48:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2b4c:	2501                	sext.w	a0,a0
    2b4e:	8082                	ret

0000000000002b50 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2b50:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2b54:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2b58:	2501                	sext.w	a0,a0
    2b5a:	8082                	ret

0000000000002b5c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2b5c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2b60:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2b64:	2501                	sext.w	a0,a0
    2b66:	8082                	ret
