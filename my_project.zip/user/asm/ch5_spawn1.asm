
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_spawn1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a601                	j	1300 <__start_main>

0000000000001002 <main>:
/// new child i
/// Test wait OK!
/// Test waitpid OK!

int main()
{
    1002:	715d                	addi	sp,sp,-80
	int cpid = spawn("ch5_exit0\0");
    1004:	00002517          	auipc	a0,0x2
    1008:	c7450513          	addi	a0,a0,-908 # 2c78 <buffer_lock+0x4>
{
    100c:	e0a2                	sd	s0,64(sp)
    100e:	e486                	sd	ra,72(sp)
    1010:	fc26                	sd	s1,56(sp)
    1012:	f84a                	sd	s2,48(sp)
    1014:	f44e                	sd	s3,40(sp)
    1016:	f052                	sd	s4,32(sp)
    1018:	ec56                	sd	s5,24(sp)
	int cpid = spawn("ch5_exit0\0");
    101a:	7c8010ef          	jal	ra,27e2 <spawn>
    101e:	842a                	mv	s0,a0
	assert(cpid >= 0); // "child pid invalid"
    1020:	2a054563          	bltz	a0,12ca <main+0x2c8>
	printf("new child %d\n", cpid);
    1024:	85a2                	mv	a1,s0
    1026:	00002517          	auipc	a0,0x2
    102a:	9ca50513          	addi	a0,a0,-1590 # 29f0 <enable_deadlock_detect+0x96>
    102e:	42c000ef          	jal	ra,145a <printf>
	int exit_code = 0;
	int exit_pid = wait(&exit_code);
    1032:	00c10993          	addi	s3,sp,12
    1036:	854e                	mv	a0,s3
	int exit_code = 0;
    1038:	c602                	sw	zero,12(sp)
	int exit_pid = wait(&exit_code);
    103a:	798010ef          	jal	ra,27d2 <wait>
    103e:	84aa                	mv	s1,a0
	assert_eq(exit_pid, cpid); // "error exit pid"
    1040:	02a40e63          	beq	s0,a0,107c <main+0x7a>
    1044:	648010ef          	jal	ra,268c <getpid>
    1048:	892a                	mv	s2,a0
    104a:	00002517          	auipc	a0,0x2
    104e:	91e50513          	addi	a0,a0,-1762 # 2968 <enable_deadlock_detect+0xe>
    1052:	510010ef          	jal	ra,2562 <basename>
    1056:	872a                	mv	a4,a0
    1058:	88a2                	mv	a7,s0
    105a:	00002517          	auipc	a0,0x2
    105e:	9a650513          	addi	a0,a0,-1626 # 2a00 <enable_deadlock_detect+0xa6>
    1062:	8826                	mv	a6,s1
    1064:	47cd                	li	a5,19
    1066:	86ca                	mv	a3,s2
    1068:	00002617          	auipc	a2,0x2
    106c:	94860613          	addi	a2,a2,-1720 # 29b0 <enable_deadlock_detect+0x56>
    1070:	45fd                	li	a1,31
    1072:	3e8000ef          	jal	ra,145a <printf>
    1076:	557d                	li	a0,-1
    1078:	644010ef          	jal	ra,26bc <exit>
	assert_eq(exit_code, 66778); // "error exit code"
    107c:	47b2                	lw	a5,12(sp)
    107e:	6441                	lui	s0,0x10
    1080:	4da40413          	addi	s0,s0,1242 # 104da <.got.plt+0xd80a>
    1084:	02878e63          	beq	a5,s0,10c0 <main+0xbe>
    1088:	604010ef          	jal	ra,268c <getpid>
    108c:	84aa                	mv	s1,a0
    108e:	00002517          	auipc	a0,0x2
    1092:	8da50513          	addi	a0,a0,-1830 # 2968 <enable_deadlock_detect+0xe>
    1096:	4cc010ef          	jal	ra,2562 <basename>
    109a:	4832                	lw	a6,12(sp)
    109c:	872a                	mv	a4,a0
    109e:	88a2                	mv	a7,s0
    10a0:	00002517          	auipc	a0,0x2
    10a4:	96050513          	addi	a0,a0,-1696 # 2a00 <enable_deadlock_detect+0xa6>
    10a8:	47d1                	li	a5,20
    10aa:	86a6                	mv	a3,s1
    10ac:	00002617          	auipc	a2,0x2
    10b0:	90460613          	addi	a2,a2,-1788 # 29b0 <enable_deadlock_detect+0x56>
    10b4:	45fd                	li	a1,31
    10b6:	3a4000ef          	jal	ra,145a <printf>
    10ba:	557d                	li	a0,-1
    10bc:	600010ef          	jal	ra,26bc <exit>
	puts("Test wait OK!\n");
    10c0:	00002517          	auipc	a0,0x2
    10c4:	97850513          	addi	a0,a0,-1672 # 2a38 <enable_deadlock_detect+0xde>
    10c8:	2a9000ef          	jal	ra,1b70 <puts>
	int cpid0 = spawn("ch5_exit0\0");
    10cc:	00002517          	auipc	a0,0x2
    10d0:	bac50513          	addi	a0,a0,-1108 # 2c78 <buffer_lock+0x4>
    10d4:	70e010ef          	jal	ra,27e2 <spawn>
    10d8:	84aa                	mv	s1,a0
	int cpid1 = spawn("ch5_exit1\0");
    10da:	00002517          	auipc	a0,0x2
    10de:	bae50513          	addi	a0,a0,-1106 # 2c88 <buffer_lock+0x14>
    10e2:	700010ef          	jal	ra,27e2 <spawn>
    10e6:	892a                	mv	s2,a0
	int cpid2 = spawn("ch5_ppid\0");
    10e8:	00002517          	auipc	a0,0x2
    10ec:	bb050513          	addi	a0,a0,-1104 # 2c98 <buffer_lock+0x24>
    10f0:	6f2010ef          	jal	ra,27e2 <spawn>
    10f4:	842a                	mv	s0,a0
	exit_pid = waitpid(cpid1, &exit_code);
    10f6:	85ce                	mv	a1,s3
    10f8:	854a                	mv	a0,s2
    10fa:	5e4010ef          	jal	ra,26de <waitpid>
    10fe:	8a2a                	mv	s4,a0
	assert_eq(exit_pid, cpid1); // "error exit pid"
    1100:	02a90e63          	beq	s2,a0,113c <main+0x13a>
    1104:	588010ef          	jal	ra,268c <getpid>
    1108:	8aaa                	mv	s5,a0
    110a:	00002517          	auipc	a0,0x2
    110e:	85e50513          	addi	a0,a0,-1954 # 2968 <enable_deadlock_detect+0xe>
    1112:	450010ef          	jal	ra,2562 <basename>
    1116:	872a                	mv	a4,a0
    1118:	88ca                	mv	a7,s2
    111a:	00002517          	auipc	a0,0x2
    111e:	8e650513          	addi	a0,a0,-1818 # 2a00 <enable_deadlock_detect+0xa6>
    1122:	8852                	mv	a6,s4
    1124:	47e9                	li	a5,26
    1126:	86d6                	mv	a3,s5
    1128:	00002617          	auipc	a2,0x2
    112c:	88860613          	addi	a2,a2,-1912 # 29b0 <enable_deadlock_detect+0x56>
    1130:	45fd                	li	a1,31
    1132:	328000ef          	jal	ra,145a <printf>
    1136:	557d                	li	a0,-1
    1138:	584010ef          	jal	ra,26bc <exit>
	assert_eq(exit_code, -233); // "error exit code"
    113c:	4732                	lw	a4,12(sp)
    113e:	f1700793          	li	a5,-233
    1142:	02f70f63          	beq	a4,a5,1180 <main+0x17e>
    1146:	546010ef          	jal	ra,268c <getpid>
    114a:	892a                	mv	s2,a0
    114c:	00002517          	auipc	a0,0x2
    1150:	81c50513          	addi	a0,a0,-2020 # 2968 <enable_deadlock_detect+0xe>
    1154:	40e010ef          	jal	ra,2562 <basename>
    1158:	4832                	lw	a6,12(sp)
    115a:	872a                	mv	a4,a0
    115c:	f1700893          	li	a7,-233
    1160:	00002517          	auipc	a0,0x2
    1164:	8a050513          	addi	a0,a0,-1888 # 2a00 <enable_deadlock_detect+0xa6>
    1168:	47ed                	li	a5,27
    116a:	86ca                	mv	a3,s2
    116c:	00002617          	auipc	a2,0x2
    1170:	84460613          	addi	a2,a2,-1980 # 29b0 <enable_deadlock_detect+0x56>
    1174:	45fd                	li	a1,31
    1176:	2e4000ef          	jal	ra,145a <printf>
    117a:	557d                	li	a0,-1
    117c:	540010ef          	jal	ra,26bc <exit>
	exit_pid = waitpid(cpid0, &exit_code);
    1180:	85ce                	mv	a1,s3
    1182:	8526                	mv	a0,s1
    1184:	55a010ef          	jal	ra,26de <waitpid>
    1188:	892a                	mv	s2,a0
	assert_eq(exit_pid, cpid0); // "error exit pid"
    118a:	02a48e63          	beq	s1,a0,11c6 <main+0x1c4>
    118e:	4fe010ef          	jal	ra,268c <getpid>
    1192:	8a2a                	mv	s4,a0
    1194:	00001517          	auipc	a0,0x1
    1198:	7d450513          	addi	a0,a0,2004 # 2968 <enable_deadlock_detect+0xe>
    119c:	3c6010ef          	jal	ra,2562 <basename>
    11a0:	872a                	mv	a4,a0
    11a2:	88a6                	mv	a7,s1
    11a4:	00002517          	auipc	a0,0x2
    11a8:	85c50513          	addi	a0,a0,-1956 # 2a00 <enable_deadlock_detect+0xa6>
    11ac:	884a                	mv	a6,s2
    11ae:	47f5                	li	a5,29
    11b0:	86d2                	mv	a3,s4
    11b2:	00001617          	auipc	a2,0x1
    11b6:	7fe60613          	addi	a2,a2,2046 # 29b0 <enable_deadlock_detect+0x56>
    11ba:	45fd                	li	a1,31
    11bc:	29e000ef          	jal	ra,145a <printf>
    11c0:	557d                	li	a0,-1
    11c2:	4fa010ef          	jal	ra,26bc <exit>
	assert_eq(exit_code, 66778); // "error exit code"
    11c6:	47b2                	lw	a5,12(sp)
    11c8:	64c1                	lui	s1,0x10
    11ca:	4da48493          	addi	s1,s1,1242 # 104da <.got.plt+0xd80a>
    11ce:	02978e63          	beq	a5,s1,120a <main+0x208>
    11d2:	4ba010ef          	jal	ra,268c <getpid>
    11d6:	892a                	mv	s2,a0
    11d8:	00001517          	auipc	a0,0x1
    11dc:	79050513          	addi	a0,a0,1936 # 2968 <enable_deadlock_detect+0xe>
    11e0:	382010ef          	jal	ra,2562 <basename>
    11e4:	4832                	lw	a6,12(sp)
    11e6:	872a                	mv	a4,a0
    11e8:	88a6                	mv	a7,s1
    11ea:	00002517          	auipc	a0,0x2
    11ee:	81650513          	addi	a0,a0,-2026 # 2a00 <enable_deadlock_detect+0xa6>
    11f2:	47f9                	li	a5,30
    11f4:	86ca                	mv	a3,s2
    11f6:	00001617          	auipc	a2,0x1
    11fa:	7ba60613          	addi	a2,a2,1978 # 29b0 <enable_deadlock_detect+0x56>
    11fe:	45fd                	li	a1,31
    1200:	25a000ef          	jal	ra,145a <printf>
    1204:	557d                	li	a0,-1
    1206:	4b6010ef          	jal	ra,26bc <exit>
	exit_pid = waitpid(cpid2, &exit_code);
    120a:	85ce                	mv	a1,s3
    120c:	8522                	mv	a0,s0
    120e:	4d0010ef          	jal	ra,26de <waitpid>
    1212:	84aa                	mv	s1,a0
	assert_eq(exit_pid, cpid2); // "error exit pid"
    1214:	02a40f63          	beq	s0,a0,1252 <main+0x250>
    1218:	474010ef          	jal	ra,268c <getpid>
    121c:	892a                	mv	s2,a0
    121e:	00001517          	auipc	a0,0x1
    1222:	74a50513          	addi	a0,a0,1866 # 2968 <enable_deadlock_detect+0xe>
    1226:	33c010ef          	jal	ra,2562 <basename>
    122a:	872a                	mv	a4,a0
    122c:	88a2                	mv	a7,s0
    122e:	00001517          	auipc	a0,0x1
    1232:	7d250513          	addi	a0,a0,2002 # 2a00 <enable_deadlock_detect+0xa6>
    1236:	8826                	mv	a6,s1
    1238:	02000793          	li	a5,32
    123c:	86ca                	mv	a3,s2
    123e:	00001617          	auipc	a2,0x1
    1242:	77260613          	addi	a2,a2,1906 # 29b0 <enable_deadlock_detect+0x56>
    1246:	45fd                	li	a1,31
    1248:	212000ef          	jal	ra,145a <printf>
    124c:	557d                	li	a0,-1
    124e:	46e010ef          	jal	ra,26bc <exit>
	assert_eq(exit_code, getpid()); // "error exit code"
    1252:	43a010ef          	jal	ra,268c <getpid>
    1256:	47b2                	lw	a5,12(sp)
    1258:	04a78363          	beq	a5,a0,129e <main+0x29c>
    125c:	430010ef          	jal	ra,268c <getpid>
    1260:	842a                	mv	s0,a0
    1262:	00001517          	auipc	a0,0x1
    1266:	70650513          	addi	a0,a0,1798 # 2968 <enable_deadlock_detect+0xe>
    126a:	2f8010ef          	jal	ra,2562 <basename>
    126e:	4932                	lw	s2,12(sp)
    1270:	84aa                	mv	s1,a0
    1272:	41a010ef          	jal	ra,268c <getpid>
    1276:	88aa                	mv	a7,a0
    1278:	884a                	mv	a6,s2
    127a:	00001517          	auipc	a0,0x1
    127e:	78650513          	addi	a0,a0,1926 # 2a00 <enable_deadlock_detect+0xa6>
    1282:	02100793          	li	a5,33
    1286:	8726                	mv	a4,s1
    1288:	86a2                	mv	a3,s0
    128a:	00001617          	auipc	a2,0x1
    128e:	72660613          	addi	a2,a2,1830 # 29b0 <enable_deadlock_detect+0x56>
    1292:	45fd                	li	a1,31
    1294:	1c6000ef          	jal	ra,145a <printf>
    1298:	557d                	li	a0,-1
    129a:	422010ef          	jal	ra,26bc <exit>
	puts("Test ppid OK!");
    129e:	00001517          	auipc	a0,0x1
    12a2:	7aa50513          	addi	a0,a0,1962 # 2a48 <enable_deadlock_detect+0xee>
    12a6:	0cb000ef          	jal	ra,1b70 <puts>
	puts("Test waitpid OK!");
    12aa:	00001517          	auipc	a0,0x1
    12ae:	7ae50513          	addi	a0,a0,1966 # 2a58 <enable_deadlock_detect+0xfe>
    12b2:	0bf000ef          	jal	ra,1b70 <puts>
	return 0;
    12b6:	60a6                	ld	ra,72(sp)
    12b8:	6406                	ld	s0,64(sp)
    12ba:	74e2                	ld	s1,56(sp)
    12bc:	7942                	ld	s2,48(sp)
    12be:	79a2                	ld	s3,40(sp)
    12c0:	7a02                	ld	s4,32(sp)
    12c2:	6ae2                	ld	s5,24(sp)
    12c4:	4501                	li	a0,0
    12c6:	6161                	addi	sp,sp,80
    12c8:	8082                	ret
	assert(cpid >= 0); // "child pid invalid"
    12ca:	3c2010ef          	jal	ra,268c <getpid>
    12ce:	84aa                	mv	s1,a0
    12d0:	00001517          	auipc	a0,0x1
    12d4:	69850513          	addi	a0,a0,1688 # 2968 <enable_deadlock_detect+0xe>
    12d8:	28a010ef          	jal	ra,2562 <basename>
    12dc:	872a                	mv	a4,a0
    12de:	47bd                	li	a5,15
    12e0:	00001517          	auipc	a0,0x1
    12e4:	6d850513          	addi	a0,a0,1752 # 29b8 <enable_deadlock_detect+0x5e>
    12e8:	86a6                	mv	a3,s1
    12ea:	00001617          	auipc	a2,0x1
    12ee:	6c660613          	addi	a2,a2,1734 # 29b0 <enable_deadlock_detect+0x56>
    12f2:	45fd                	li	a1,31
    12f4:	166000ef          	jal	ra,145a <printf>
    12f8:	557d                	li	a0,-1
    12fa:	3c2010ef          	jal	ra,26bc <exit>
    12fe:	b31d                	j	1024 <main+0x22>

0000000000001300 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1300:	1141                	addi	sp,sp,-16
    1302:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1304:	cffff0ef          	jal	ra,1002 <main>
    1308:	3b4010ef          	jal	ra,26bc <exit>
	return 0;
    130c:	60a2                	ld	ra,8(sp)
    130e:	4501                	li	a0,0
    1310:	0141                	addi	sp,sp,16
    1312:	8082                	ret

0000000000001314 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1314:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1316:	4605                	li	a2,1
    1318:	00f10593          	addi	a1,sp,15
    131c:	4501                	li	a0,0
{
    131e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1320:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1324:	354010ef          	jal	ra,2678 <read>
    1328:	4785                	li	a5,1
    132a:	00f51763          	bne	a0,a5,1338 <getchar+0x24>
		return byte;
    132e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1332:	60e2                	ld	ra,24(sp)
    1334:	6105                	addi	sp,sp,32
    1336:	8082                	ret
		return EOF;
    1338:	557d                	li	a0,-1
    133a:	bfe5                	j	1332 <getchar+0x1e>

000000000000133c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    133c:	00002517          	auipc	a0,0x2
    1340:	82c52503          	lw	a0,-2004(a0) # 2b68 <buffer_len>
    1344:	e111                	bnez	a0,1348 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1346:	8082                	ret
{
    1348:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    134a:	862a                	mv	a2,a0
    134c:	00002597          	auipc	a1,0x2
    1350:	82458593          	addi	a1,a1,-2012 # 2b70 <buffer>
    1354:	4505                	li	a0,1
{
    1356:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1358:	32a010ef          	jal	ra,2682 <write>
}
    135c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    135e:	2501                	sext.w	a0,a0
}
    1360:	0141                	addi	sp,sp,16
    1362:	8082                	ret

0000000000001364 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1364:	00002797          	auipc	a5,0x2
    1368:	8007a223          	sw	zero,-2044(a5) # 2b68 <buffer_len>
}
    136c:	8082                	ret

000000000000136e <__fflush>:
	if (buffer_len == 0)
    136e:	00001517          	auipc	a0,0x1
    1372:	7fa52503          	lw	a0,2042(a0) # 2b68 <buffer_len>
    1376:	e511                	bnez	a0,1382 <__fflush+0x14>
	buffer_len = 0;
    1378:	00001797          	auipc	a5,0x1
    137c:	7e07a823          	sw	zero,2032(a5) # 2b68 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1380:	8082                	ret
{
    1382:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1384:	862a                	mv	a2,a0
    1386:	00001597          	auipc	a1,0x1
    138a:	7ea58593          	addi	a1,a1,2026 # 2b70 <buffer>
    138e:	4505                	li	a0,1
{
    1390:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1392:	2f0010ef          	jal	ra,2682 <write>
	return r >= 0 ? 0 : r;
    1396:	0005079b          	sext.w	a5,a0
}
    139a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    139c:	0017a793          	slti	a5,a5,1
    13a0:	40f007bb          	negw	a5,a5
    13a4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13a6:	00001797          	auipc	a5,0x1
    13aa:	7c07a123          	sw	zero,1986(a5) # 2b68 <buffer_len>
	return r >= 0 ? 0 : r;
    13ae:	2501                	sext.w	a0,a0
}
    13b0:	0141                	addi	sp,sp,16
    13b2:	8082                	ret

00000000000013b4 <fflush>:

int fflush(int fd)
{
    13b4:	1101                	addi	sp,sp,-32
    13b6:	e822                	sd	s0,16(sp)
    13b8:	ec06                	sd	ra,24(sp)
    13ba:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13bc:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13be:	4401                	li	s0,0
	if (fd == 1) {
    13c0:	00e50863          	beq	a0,a4,13d0 <fflush+0x1c>
}
    13c4:	60e2                	ld	ra,24(sp)
    13c6:	8522                	mv	a0,s0
    13c8:	6442                	ld	s0,16(sp)
    13ca:	64a2                	ld	s1,8(sp)
    13cc:	6105                	addi	sp,sp,32
    13ce:	8082                	ret
		if (buffer_lock_enabled == 1) {
    13d0:	00001497          	auipc	s1,0x1
    13d4:	79848493          	addi	s1,s1,1944 # 2b68 <buffer_len>
    13d8:	1084a703          	lw	a4,264(s1)
    13dc:	02a70e63          	beq	a4,a0,1418 <fflush+0x64>
	if (buffer_len == 0)
    13e0:	4080                	lw	s0,0(s1)
    13e2:	c00d                	beqz	s0,1404 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    13e4:	8622                	mv	a2,s0
    13e6:	00001597          	auipc	a1,0x1
    13ea:	78a58593          	addi	a1,a1,1930 # 2b70 <buffer>
    13ee:	294010ef          	jal	ra,2682 <write>
	return r >= 0 ? 0 : r;
    13f2:	0005079b          	sext.w	a5,a0
    13f6:	0017a793          	slti	a5,a5,1
    13fa:	40f007bb          	negw	a5,a5
    13fe:	8d7d                	and	a0,a0,a5
    1400:	0005041b          	sext.w	s0,a0
}
    1404:	60e2                	ld	ra,24(sp)
    1406:	8522                	mv	a0,s0
    1408:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    140a:	00001797          	auipc	a5,0x1
    140e:	7407af23          	sw	zero,1886(a5) # 2b68 <buffer_len>
}
    1412:	64a2                	ld	s1,8(sp)
    1414:	6105                	addi	sp,sp,32
    1416:	8082                	ret
			mutex_lock(buffer_lock);
    1418:	10c4a503          	lw	a0,268(s1)
    141c:	4de010ef          	jal	ra,28fa <mutex_lock>
	if (buffer_len == 0)
    1420:	4080                	lw	s0,0(s1)
    1422:	e811                	bnez	s0,1436 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1424:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1428:	00001797          	auipc	a5,0x1
    142c:	7407a023          	sw	zero,1856(a5) # 2b68 <buffer_len>
			mutex_unlock(buffer_lock);
    1430:	4d6010ef          	jal	ra,2906 <mutex_unlock>
    1434:	bf41                	j	13c4 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1436:	8622                	mv	a2,s0
    1438:	00001597          	auipc	a1,0x1
    143c:	73858593          	addi	a1,a1,1848 # 2b70 <buffer>
    1440:	4505                	li	a0,1
    1442:	240010ef          	jal	ra,2682 <write>
	return r >= 0 ? 0 : r;
    1446:	0005079b          	sext.w	a5,a0
    144a:	0017a793          	slti	a5,a5,1
    144e:	40f007bb          	negw	a5,a5
    1452:	8d7d                	and	a0,a0,a5
    1454:	0005041b          	sext.w	s0,a0
	return r;
    1458:	b7f1                	j	1424 <fflush+0x70>

000000000000145a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    145a:	7131                	addi	sp,sp,-192
    145c:	e0da                	sd	s6,64(sp)
    145e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1460:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1462:	013c                	addi	a5,sp,136
{
    1464:	f0ca                	sd	s2,96(sp)
    1466:	ecce                	sd	s3,88(sp)
    1468:	e8d2                	sd	s4,80(sp)
    146a:	e4d6                	sd	s5,72(sp)
    146c:	fc86                	sd	ra,120(sp)
    146e:	f8a2                	sd	s0,112(sp)
    1470:	f4a6                	sd	s1,104(sp)
    1472:	89aa                	mv	s3,a0
    1474:	e52e                	sd	a1,136(sp)
    1476:	e932                	sd	a2,144(sp)
    1478:	ed36                	sd	a3,152(sp)
    147a:	f13a                	sd	a4,160(sp)
    147c:	f942                	sd	a6,176(sp)
    147e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1480:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1482:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1486:	00001a17          	auipc	s4,0x1
    148a:	6e2a0a13          	addi	s4,s4,1762 # 2b68 <buffer_len>
    148e:	4a85                	li	s5,1
	buf[i++] = '0';
    1490:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1494:	0009c783          	lbu	a5,0(s3)
    1498:	18078663          	beqz	a5,1624 <printf+0x1ca>
    149c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    149e:	19278d63          	beq	a5,s2,1638 <printf+0x1de>
    14a2:	0015c783          	lbu	a5,1(a1)
    14a6:	0585                	addi	a1,a1,1
    14a8:	fbfd                	bnez	a5,149e <printf+0x44>
    14aa:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14ac:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14b0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14b4:	1b578863          	beq	a5,s5,1664 <printf+0x20a>
		len = out_unlocked(s, l);
    14b8:	85a2                	mv	a1,s0
    14ba:	854e                	mv	a0,s3
    14bc:	42a000ef          	jal	ra,18e6 <out_unlocked>
		out(f, a, l);
		if (l)
    14c0:	1c041063          	bnez	s0,1680 <printf+0x226>
			continue;
		if (s[1] == 0)
    14c4:	0014c783          	lbu	a5,1(s1)
    14c8:	14078e63          	beqz	a5,1624 <printf+0x1ca>
			break;
		switch (s[1]) {
    14cc:	07300713          	li	a4,115
    14d0:	1ce78863          	beq	a5,a4,16a0 <printf+0x246>
    14d4:	1af76863          	bltu	a4,a5,1684 <printf+0x22a>
    14d8:	06400713          	li	a4,100
    14dc:	22e78063          	beq	a5,a4,16fc <printf+0x2a2>
    14e0:	07000713          	li	a4,112
    14e4:	1ee79563          	bne	a5,a4,16ce <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    14e8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14ea:	00001797          	auipc	a5,0x1
    14ee:	7be78793          	addi	a5,a5,1982 # 2ca8 <digits>
	buf[i++] = '0';
    14f2:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    14f6:	6298                	ld	a4,0(a3)
    14f8:	06a1                	addi	a3,a3,8
    14fa:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    14fc:	00471393          	slli	t2,a4,0x4
    1500:	00871293          	slli	t0,a4,0x8
    1504:	00c71f93          	slli	t6,a4,0xc
    1508:	01071f13          	slli	t5,a4,0x10
    150c:	01471e93          	slli	t4,a4,0x14
    1510:	01871e13          	slli	t3,a4,0x18
    1514:	01c71893          	slli	a7,a4,0x1c
    1518:	02471813          	slli	a6,a4,0x24
    151c:	02871513          	slli	a0,a4,0x28
    1520:	02c71593          	slli	a1,a4,0x2c
    1524:	03071613          	slli	a2,a4,0x30
    1528:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    152c:	03c75413          	srli	s0,a4,0x3c
    1530:	01c7531b          	srliw	t1,a4,0x1c
    1534:	03c3d393          	srli	t2,t2,0x3c
    1538:	03c2d293          	srli	t0,t0,0x3c
    153c:	03cfdf93          	srli	t6,t6,0x3c
    1540:	03cf5f13          	srli	t5,t5,0x3c
    1544:	03cede93          	srli	t4,t4,0x3c
    1548:	03ce5e13          	srli	t3,t3,0x3c
    154c:	03c8d893          	srli	a7,a7,0x3c
    1550:	03c85813          	srli	a6,a6,0x3c
    1554:	9171                	srli	a0,a0,0x3c
    1556:	91f1                	srli	a1,a1,0x3c
    1558:	9271                	srli	a2,a2,0x3c
    155a:	92f1                	srli	a3,a3,0x3c
    155c:	95be                	add	a1,a1,a5
    155e:	963e                	add	a2,a2,a5
    1560:	96be                	add	a3,a3,a5
    1562:	943e                	add	s0,s0,a5
    1564:	93be                	add	t2,t2,a5
    1566:	92be                	add	t0,t0,a5
    1568:	9fbe                	add	t6,t6,a5
    156a:	9f3e                	add	t5,t5,a5
    156c:	9ebe                	add	t4,t4,a5
    156e:	9e3e                	add	t3,t3,a5
    1570:	98be                	add	a7,a7,a5
    1572:	933e                	add	t1,t1,a5
    1574:	983e                	add	a6,a6,a5
    1576:	953e                	add	a0,a0,a5
    1578:	0005c983          	lbu	s3,0(a1)
    157c:	00044403          	lbu	s0,0(s0)
    1580:	00064583          	lbu	a1,0(a2)
    1584:	0003c383          	lbu	t2,0(t2)
    1588:	0006c603          	lbu	a2,0(a3)
    158c:	0002c283          	lbu	t0,0(t0)
    1590:	000fcf83          	lbu	t6,0(t6)
    1594:	000f4f03          	lbu	t5,0(t5)
    1598:	000ece83          	lbu	t4,0(t4)
    159c:	000e4e03          	lbu	t3,0(t3)
    15a0:	0008c883          	lbu	a7,0(a7)
    15a4:	00034303          	lbu	t1,0(t1)
    15a8:	00084803          	lbu	a6,0(a6)
    15ac:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15b0:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15b4:	92f1                	srli	a3,a3,0x3c
    15b6:	8b3d                	andi	a4,a4,15
    15b8:	96be                	add	a3,a3,a5
    15ba:	97ba                	add	a5,a5,a4
    15bc:	00810d23          	sb	s0,26(sp)
    15c0:	00710da3          	sb	t2,27(sp)
    15c4:	00510e23          	sb	t0,28(sp)
    15c8:	01f10ea3          	sb	t6,29(sp)
    15cc:	01e10f23          	sb	t5,30(sp)
    15d0:	01d10fa3          	sb	t4,31(sp)
    15d4:	03c10023          	sb	t3,32(sp)
    15d8:	031100a3          	sb	a7,33(sp)
    15dc:	02610123          	sb	t1,34(sp)
    15e0:	030101a3          	sb	a6,35(sp)
    15e4:	02a10223          	sb	a0,36(sp)
    15e8:	033102a3          	sb	s3,37(sp)
    15ec:	02b10323          	sb	a1,38(sp)
    15f0:	02c103a3          	sb	a2,39(sp)
    15f4:	0006c683          	lbu	a3,0(a3)
    15f8:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    15fc:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1600:	02d10423          	sb	a3,40(sp)
    1604:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1608:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    160c:	11578263          	beq	a5,s5,1710 <printf+0x2b6>
		len = out_unlocked(s, l);
    1610:	45c9                	li	a1,18
    1612:	0828                	addi	a0,sp,24
    1614:	2d2000ef          	jal	ra,18e6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1618:	00248993          	addi	s3,s1,2
		if (!*s)
    161c:	0009c783          	lbu	a5,0(s3)
    1620:	e6079ee3          	bnez	a5,149c <printf+0x42>
	}
	va_end(ap);
    1624:	70e6                	ld	ra,120(sp)
    1626:	7446                	ld	s0,112(sp)
    1628:	74a6                	ld	s1,104(sp)
    162a:	7906                	ld	s2,96(sp)
    162c:	69e6                	ld	s3,88(sp)
    162e:	6a46                	ld	s4,80(sp)
    1630:	6aa6                	ld	s5,72(sp)
    1632:	6b06                	ld	s6,64(sp)
    1634:	6129                	addi	sp,sp,192
    1636:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1638:	0005c783          	lbu	a5,0(a1)
    163c:	84ae                	mv	s1,a1
    163e:	01278963          	beq	a5,s2,1650 <printf+0x1f6>
    1642:	b5ad                	j	14ac <printf+0x52>
    1644:	0024c783          	lbu	a5,2(s1)
    1648:	0585                	addi	a1,a1,1
    164a:	0489                	addi	s1,s1,2
    164c:	e72790e3          	bne	a5,s2,14ac <printf+0x52>
    1650:	0014c783          	lbu	a5,1(s1)
    1654:	ff2788e3          	beq	a5,s2,1644 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1658:	108a2783          	lw	a5,264(s4)
		l = z - a;
    165c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1660:	e5579ce3          	bne	a5,s5,14b8 <printf+0x5e>
		mutex_lock(buffer_lock);
    1664:	10ca2503          	lw	a0,268(s4)
    1668:	292010ef          	jal	ra,28fa <mutex_lock>
		len = out_unlocked(s, l);
    166c:	85a2                	mv	a1,s0
    166e:	854e                	mv	a0,s3
    1670:	276000ef          	jal	ra,18e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1674:	10ca2503          	lw	a0,268(s4)
    1678:	28e010ef          	jal	ra,2906 <mutex_unlock>
		if (l)
    167c:	e40404e3          	beqz	s0,14c4 <printf+0x6a>
    1680:	89a6                	mv	s3,s1
    1682:	bd09                	j	1494 <printf+0x3a>
		switch (s[1]) {
    1684:	07800713          	li	a4,120
    1688:	04e79363          	bne	a5,a4,16ce <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    168c:	67c2                	ld	a5,16(sp)
    168e:	45c1                	li	a1,16
		s += 2;
    1690:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1694:	4388                	lw	a0,0(a5)
    1696:	07a1                	addi	a5,a5,8
    1698:	e83e                	sd	a5,16(sp)
    169a:	5f8000ef          	jal	ra,1c92 <printint.constprop.0>
		s += 2;
    169e:	bfbd                	j	161c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16a0:	67c2                	ld	a5,16(sp)
    16a2:	6380                	ld	s0,0(a5)
    16a4:	07a1                	addi	a5,a5,8
    16a6:	e83e                	sd	a5,16(sp)
    16a8:	1c040163          	beqz	s0,186a <printf+0x410>
			l = strnlen(a, 200);
    16ac:	0c800593          	li	a1,200
    16b0:	8522                	mv	a0,s0
    16b2:	3f7000ef          	jal	ra,22a8 <strnlen>
	if (buffer_lock_enabled == 1) {
    16b6:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16ba:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16be:	19578663          	beq	a5,s5,184a <printf+0x3f0>
		len = out_unlocked(s, l);
    16c2:	8522                	mv	a0,s0
    16c4:	222000ef          	jal	ra,18e6 <out_unlocked>
		s += 2;
    16c8:	00248993          	addi	s3,s1,2
    16cc:	bf81                	j	161c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    16ce:	108a2783          	lw	a5,264(s4)
	char byte = c;
    16d2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    16d6:	0f578663          	beq	a5,s5,17c2 <printf+0x368>
		len = out_unlocked(s, l);
    16da:	0828                	addi	a0,sp,24
    16dc:	316000ef          	jal	ra,19f2 <out_unlocked.constprop.0>
			putchar(s[1]);
    16e0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    16e4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    16e8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    16ec:	05578163          	beq	a5,s5,172e <printf+0x2d4>
		len = out_unlocked(s, l);
    16f0:	0828                	addi	a0,sp,24
    16f2:	300000ef          	jal	ra,19f2 <out_unlocked.constprop.0>
		s += 2;
    16f6:	00248993          	addi	s3,s1,2
    16fa:	b70d                	j	161c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    16fc:	67c2                	ld	a5,16(sp)
    16fe:	45a9                	li	a1,10
		s += 2;
    1700:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1704:	4388                	lw	a0,0(a5)
    1706:	07a1                	addi	a5,a5,8
    1708:	e83e                	sd	a5,16(sp)
    170a:	588000ef          	jal	ra,1c92 <printint.constprop.0>
		s += 2;
    170e:	b739                	j	161c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1710:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1714:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1718:	1e2010ef          	jal	ra,28fa <mutex_lock>
		len = out_unlocked(s, l);
    171c:	45c9                	li	a1,18
    171e:	0828                	addi	a0,sp,24
    1720:	1c6000ef          	jal	ra,18e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1724:	10ca2503          	lw	a0,268(s4)
    1728:	1de010ef          	jal	ra,2906 <mutex_unlock>
		s += 2;
    172c:	bdc5                	j	161c <printf+0x1c2>
		mutex_lock(buffer_lock);
    172e:	10ca2503          	lw	a0,268(s4)
    1732:	1c8010ef          	jal	ra,28fa <mutex_lock>
		buffer[buffer_len++] = c;
    1736:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    173a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    173e:	0017861b          	addiw	a2,a5,1
    1742:	97d2                	add	a5,a5,s4
    1744:	00ca2023          	sw	a2,0(s4)
    1748:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    174c:	00c6cc63          	blt	a3,a2,1764 <printf+0x30a>
    1750:	47a9                	li	a5,10
    1752:	06f40663          	beq	s0,a5,17be <printf+0x364>
		mutex_unlock(buffer_lock);
    1756:	10ca2503          	lw	a0,268(s4)
		s += 2;
    175a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    175e:	1a8010ef          	jal	ra,2906 <mutex_unlock>
		s += 2;
    1762:	bd6d                	j	161c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1764:	10000793          	li	a5,256
    1768:	00f61e63          	bne	a2,a5,1784 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    176c:	00001597          	auipc	a1,0x1
    1770:	40458593          	addi	a1,a1,1028 # 2b70 <buffer>
    1774:	4505                	li	a0,1
    1776:	70d000ef          	jal	ra,2682 <write>
	buffer_len = 0;
    177a:	00001797          	auipc	a5,0x1
    177e:	3e07a723          	sw	zero,1006(a5) # 2b68 <buffer_len>
			if (r < 0) {
    1782:	bfd1                	j	1756 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1784:	709000ef          	jal	ra,268c <getpid>
    1788:	842a                	mv	s0,a0
    178a:	00001517          	auipc	a0,0x1
    178e:	2ee50513          	addi	a0,a0,750 # 2a78 <enable_deadlock_detect+0x11e>
    1792:	5d1000ef          	jal	ra,2562 <basename>
    1796:	872a                	mv	a4,a0
    1798:	00001617          	auipc	a2,0x1
    179c:	21860613          	addi	a2,a2,536 # 29b0 <enable_deadlock_detect+0x56>
    17a0:	05400793          	li	a5,84
    17a4:	86a2                	mv	a3,s0
    17a6:	45fd                	li	a1,31
    17a8:	00001517          	auipc	a0,0x1
    17ac:	31050513          	addi	a0,a0,784 # 2ab8 <enable_deadlock_detect+0x15e>
    17b0:	cabff0ef          	jal	ra,145a <printf>
    17b4:	557d                	li	a0,-1
    17b6:	707000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    17ba:	000a2603          	lw	a2,0(s4)
    17be:	de41                	beqz	a2,1756 <printf+0x2fc>
    17c0:	b775                	j	176c <printf+0x312>
		mutex_lock(buffer_lock);
    17c2:	10ca2503          	lw	a0,268(s4)
    17c6:	134010ef          	jal	ra,28fa <mutex_lock>
		buffer[buffer_len++] = c;
    17ca:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17ce:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    17d2:	0017861b          	addiw	a2,a5,1
    17d6:	97d2                	add	a5,a5,s4
    17d8:	00ca2023          	sw	a2,0(s4)
    17dc:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17e0:	02c6d163          	bge	a3,a2,1802 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    17e4:	10000793          	li	a5,256
    17e8:	02f61263          	bne	a2,a5,180c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    17ec:	00001597          	auipc	a1,0x1
    17f0:	38458593          	addi	a1,a1,900 # 2b70 <buffer>
    17f4:	4505                	li	a0,1
    17f6:	68d000ef          	jal	ra,2682 <write>
	buffer_len = 0;
    17fa:	00001797          	auipc	a5,0x1
    17fe:	3607a723          	sw	zero,878(a5) # 2b68 <buffer_len>
		mutex_unlock(buffer_lock);
    1802:	10ca2503          	lw	a0,268(s4)
    1806:	100010ef          	jal	ra,2906 <mutex_unlock>
    180a:	bdd9                	j	16e0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    180c:	681000ef          	jal	ra,268c <getpid>
    1810:	842a                	mv	s0,a0
    1812:	00001517          	auipc	a0,0x1
    1816:	26650513          	addi	a0,a0,614 # 2a78 <enable_deadlock_detect+0x11e>
    181a:	549000ef          	jal	ra,2562 <basename>
    181e:	872a                	mv	a4,a0
    1820:	00001617          	auipc	a2,0x1
    1824:	19060613          	addi	a2,a2,400 # 29b0 <enable_deadlock_detect+0x56>
    1828:	05400793          	li	a5,84
    182c:	86a2                	mv	a3,s0
    182e:	45fd                	li	a1,31
    1830:	00001517          	auipc	a0,0x1
    1834:	28850513          	addi	a0,a0,648 # 2ab8 <enable_deadlock_detect+0x15e>
    1838:	c23ff0ef          	jal	ra,145a <printf>
    183c:	557d                	li	a0,-1
    183e:	67f000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    1842:	000a2603          	lw	a2,0(s4)
    1846:	de55                	beqz	a2,1802 <printf+0x3a8>
    1848:	b755                	j	17ec <printf+0x392>
		mutex_lock(buffer_lock);
    184a:	10ca2503          	lw	a0,268(s4)
    184e:	e42e                	sd	a1,8(sp)
		s += 2;
    1850:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1854:	0a6010ef          	jal	ra,28fa <mutex_lock>
		len = out_unlocked(s, l);
    1858:	65a2                	ld	a1,8(sp)
    185a:	8522                	mv	a0,s0
    185c:	08a000ef          	jal	ra,18e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1860:	10ca2503          	lw	a0,268(s4)
    1864:	0a2010ef          	jal	ra,2906 <mutex_unlock>
		s += 2;
    1868:	bb55                	j	161c <printf+0x1c2>
				a = "(null)";
    186a:	00001417          	auipc	s0,0x1
    186e:	20640413          	addi	s0,s0,518 # 2a70 <enable_deadlock_detect+0x116>
    1872:	bd2d                	j	16ac <printf+0x252>

0000000000001874 <enable_thread_io_buffer>:
{
    1874:	1101                	addi	sp,sp,-32
    1876:	e822                	sd	s0,16(sp)
    1878:	ec06                	sd	ra,24(sp)
    187a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    187c:	00001417          	auipc	s0,0x1
    1880:	2ec40413          	addi	s0,s0,748 # 2b68 <buffer_len>
    1884:	05a010ef          	jal	ra,28de <mutex_create>
    1888:	10a42623          	sw	a0,268(s0)
    188c:	00054a63          	bltz	a0,18a0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1890:	4785                	li	a5,1
}
    1892:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1894:	10f42423          	sw	a5,264(s0)
}
    1898:	6442                	ld	s0,16(sp)
    189a:	64a2                	ld	s1,8(sp)
    189c:	6105                	addi	sp,sp,32
    189e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18a0:	5ed000ef          	jal	ra,268c <getpid>
    18a4:	84aa                	mv	s1,a0
    18a6:	00001517          	auipc	a0,0x1
    18aa:	1d250513          	addi	a0,a0,466 # 2a78 <enable_deadlock_detect+0x11e>
    18ae:	4b5000ef          	jal	ra,2562 <basename>
    18b2:	872a                	mv	a4,a0
    18b4:	04800793          	li	a5,72
    18b8:	86a6                	mv	a3,s1
    18ba:	00001517          	auipc	a0,0x1
    18be:	23e50513          	addi	a0,a0,574 # 2af8 <enable_deadlock_detect+0x19e>
    18c2:	00001617          	auipc	a2,0x1
    18c6:	0ee60613          	addi	a2,a2,238 # 29b0 <enable_deadlock_detect+0x56>
    18ca:	45fd                	li	a1,31
    18cc:	b8fff0ef          	jal	ra,145a <printf>
    18d0:	557d                	li	a0,-1
    18d2:	5eb000ef          	jal	ra,26bc <exit>
	buffer_lock_enabled = 1;
    18d6:	4785                	li	a5,1
}
    18d8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18da:	10f42423          	sw	a5,264(s0)
}
    18de:	6442                	ld	s0,16(sp)
    18e0:	64a2                	ld	s1,8(sp)
    18e2:	6105                	addi	sp,sp,32
    18e4:	8082                	ret

00000000000018e6 <out_unlocked>:
{
    18e6:	7159                	addi	sp,sp,-112
    18e8:	f486                	sd	ra,104(sp)
    18ea:	f0a2                	sd	s0,96(sp)
    18ec:	eca6                	sd	s1,88(sp)
    18ee:	e8ca                	sd	s2,80(sp)
    18f0:	e4ce                	sd	s3,72(sp)
    18f2:	e0d2                	sd	s4,64(sp)
    18f4:	fc56                	sd	s5,56(sp)
    18f6:	f85a                	sd	s6,48(sp)
    18f8:	f45e                	sd	s7,40(sp)
    18fa:	f062                	sd	s8,32(sp)
    18fc:	ec66                	sd	s9,24(sp)
    18fe:	e86a                	sd	s10,16(sp)
    1900:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1902:	0e058663          	beqz	a1,19ee <out_unlocked+0x108>
    1906:	842a                	mv	s0,a0
    1908:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    190c:	4981                	li	s3,0
    190e:	00001d17          	auipc	s10,0x1
    1912:	25ad0d13          	addi	s10,s10,602 # 2b68 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1916:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    191a:	00001b17          	auipc	s6,0x1
    191e:	256b0b13          	addi	s6,s6,598 # 2b70 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1922:	10000a93          	li	s5,256
    1926:	00001c97          	auipc	s9,0x1
    192a:	152c8c93          	addi	s9,s9,338 # 2a78 <enable_deadlock_detect+0x11e>
    192e:	00001c17          	auipc	s8,0x1
    1932:	082c0c13          	addi	s8,s8,130 # 29b0 <enable_deadlock_detect+0x56>
    1936:	00001b97          	auipc	s7,0x1
    193a:	182b8b93          	addi	s7,s7,386 # 2ab8 <enable_deadlock_detect+0x15e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    193e:	4a29                	li	s4,10
    1940:	a031                	j	194c <out_unlocked+0x66>
    1942:	09468863          	beq	a3,s4,19d2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1946:	0405                	addi	s0,s0,1
    1948:	04848163          	beq	s1,s0,198a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    194c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1950:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1954:	0017861b          	addiw	a2,a5,1
    1958:	97ea                	add	a5,a5,s10
    195a:	00cd2023          	sw	a2,0(s10)
    195e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1962:	fec950e3          	bge	s2,a2,1942 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1966:	05561263          	bne	a2,s5,19aa <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    196a:	85da                	mv	a1,s6
    196c:	4505                	li	a0,1
    196e:	515000ef          	jal	ra,2682 <write>
    1972:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1974:	00001797          	auipc	a5,0x1
    1978:	1e07aa23          	sw	zero,500(a5) # 2b68 <buffer_len>
			if (r < 0) {
    197c:	06054763          	bltz	a0,19ea <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1980:	0405                	addi	s0,s0,1
			ret += r;
    1982:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1986:	fc8493e3          	bne	s1,s0,194c <out_unlocked+0x66>
}
    198a:	70a6                	ld	ra,104(sp)
    198c:	7406                	ld	s0,96(sp)
    198e:	64e6                	ld	s1,88(sp)
    1990:	6946                	ld	s2,80(sp)
    1992:	6a06                	ld	s4,64(sp)
    1994:	7ae2                	ld	s5,56(sp)
    1996:	7b42                	ld	s6,48(sp)
    1998:	7ba2                	ld	s7,40(sp)
    199a:	7c02                	ld	s8,32(sp)
    199c:	6ce2                	ld	s9,24(sp)
    199e:	6d42                	ld	s10,16(sp)
    19a0:	6da2                	ld	s11,8(sp)
    19a2:	854e                	mv	a0,s3
    19a4:	69a6                	ld	s3,72(sp)
    19a6:	6165                	addi	sp,sp,112
    19a8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19aa:	4e3000ef          	jal	ra,268c <getpid>
    19ae:	8daa                	mv	s11,a0
    19b0:	8566                	mv	a0,s9
    19b2:	3b1000ef          	jal	ra,2562 <basename>
    19b6:	872a                	mv	a4,a0
    19b8:	8662                	mv	a2,s8
    19ba:	05400793          	li	a5,84
    19be:	86ee                	mv	a3,s11
    19c0:	45fd                	li	a1,31
    19c2:	855e                	mv	a0,s7
    19c4:	a97ff0ef          	jal	ra,145a <printf>
    19c8:	557d                	li	a0,-1
    19ca:	4f3000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    19ce:	000d2603          	lw	a2,0(s10)
    19d2:	da35                	beqz	a2,1946 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    19d4:	85da                	mv	a1,s6
    19d6:	4505                	li	a0,1
    19d8:	4ab000ef          	jal	ra,2682 <write>
    19dc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19de:	00001797          	auipc	a5,0x1
    19e2:	1807a523          	sw	zero,394(a5) # 2b68 <buffer_len>
			if (r < 0) {
    19e6:	f8055de3          	bgez	a0,1980 <out_unlocked+0x9a>
    19ea:	89aa                	mv	s3,a0
    19ec:	bf79                	j	198a <out_unlocked+0xa4>
	int ret = 0;
    19ee:	4981                	li	s3,0
    19f0:	bf69                	j	198a <out_unlocked+0xa4>

00000000000019f2 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    19f2:	1101                	addi	sp,sp,-32
    19f4:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    19f6:	00001497          	auipc	s1,0x1
    19fa:	17248493          	addi	s1,s1,370 # 2b68 <buffer_len>
    19fe:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a00:	ec06                	sd	ra,24(sp)
    1a02:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a04:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a08:	0017861b          	addiw	a2,a5,1
    1a0c:	97a6                	add	a5,a5,s1
    1a0e:	00e78423          	sb	a4,8(a5)
    1a12:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a14:	0ff00793          	li	a5,255
    1a18:	00c7cc63          	blt	a5,a2,1a30 <out_unlocked.constprop.0+0x3e>
    1a1c:	47a9                	li	a5,10
    1a1e:	06f70c63          	beq	a4,a5,1a96 <out_unlocked.constprop.0+0xa4>
    1a22:	4601                	li	a2,0
}
    1a24:	60e2                	ld	ra,24(sp)
    1a26:	6442                	ld	s0,16(sp)
    1a28:	64a2                	ld	s1,8(sp)
    1a2a:	8532                	mv	a0,a2
    1a2c:	6105                	addi	sp,sp,32
    1a2e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a30:	10000793          	li	a5,256
    1a34:	02f61563          	bne	a2,a5,1a5e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a38:	00001597          	auipc	a1,0x1
    1a3c:	13858593          	addi	a1,a1,312 # 2b70 <buffer>
    1a40:	4505                	li	a0,1
    1a42:	441000ef          	jal	ra,2682 <write>
}
    1a46:	60e2                	ld	ra,24(sp)
    1a48:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a4a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a4e:	00001797          	auipc	a5,0x1
    1a52:	1007ad23          	sw	zero,282(a5) # 2b68 <buffer_len>
}
    1a56:	64a2                	ld	s1,8(sp)
    1a58:	8532                	mv	a0,a2
    1a5a:	6105                	addi	sp,sp,32
    1a5c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a5e:	42f000ef          	jal	ra,268c <getpid>
    1a62:	842a                	mv	s0,a0
    1a64:	00001517          	auipc	a0,0x1
    1a68:	01450513          	addi	a0,a0,20 # 2a78 <enable_deadlock_detect+0x11e>
    1a6c:	2f7000ef          	jal	ra,2562 <basename>
    1a70:	872a                	mv	a4,a0
    1a72:	00001617          	auipc	a2,0x1
    1a76:	f3e60613          	addi	a2,a2,-194 # 29b0 <enable_deadlock_detect+0x56>
    1a7a:	05400793          	li	a5,84
    1a7e:	86a2                	mv	a3,s0
    1a80:	45fd                	li	a1,31
    1a82:	00001517          	auipc	a0,0x1
    1a86:	03650513          	addi	a0,a0,54 # 2ab8 <enable_deadlock_detect+0x15e>
    1a8a:	9d1ff0ef          	jal	ra,145a <printf>
    1a8e:	557d                	li	a0,-1
    1a90:	42d000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    1a94:	4090                	lw	a2,0(s1)
    1a96:	d659                	beqz	a2,1a24 <out_unlocked.constprop.0+0x32>
    1a98:	b745                	j	1a38 <out_unlocked.constprop.0+0x46>

0000000000001a9a <putchar>:
{
    1a9a:	7139                	addi	sp,sp,-64
    1a9c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1a9e:	00001497          	auipc	s1,0x1
    1aa2:	0ca48493          	addi	s1,s1,202 # 2b68 <buffer_len>
    1aa6:	1084a703          	lw	a4,264(s1)
{
    1aaa:	f822                	sd	s0,48(sp)
	char byte = c;
    1aac:	0ff57413          	zext.b	s0,a0
{
    1ab0:	fc06                	sd	ra,56(sp)
	char byte = c;
    1ab2:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1ab6:	4785                	li	a5,1
    1ab8:	00f70d63          	beq	a4,a5,1ad2 <putchar+0x38>
		len = out_unlocked(s, l);
    1abc:	01f10513          	addi	a0,sp,31
    1ac0:	f33ff0ef          	jal	ra,19f2 <out_unlocked.constprop.0>
}
    1ac4:	70e2                	ld	ra,56(sp)
    1ac6:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1ac8:	862a                	mv	a2,a0
}
    1aca:	74a2                	ld	s1,40(sp)
    1acc:	8532                	mv	a0,a2
    1ace:	6121                	addi	sp,sp,64
    1ad0:	8082                	ret
		mutex_lock(buffer_lock);
    1ad2:	10c4a503          	lw	a0,268(s1)
    1ad6:	625000ef          	jal	ra,28fa <mutex_lock>
		buffer[buffer_len++] = c;
    1ada:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1adc:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1ae0:	0017861b          	addiw	a2,a5,1
    1ae4:	97a6                	add	a5,a5,s1
    1ae6:	c090                	sw	a2,0(s1)
    1ae8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1aec:	02c6c263          	blt	a3,a2,1b10 <putchar+0x76>
    1af0:	47a9                	li	a5,10
    1af2:	06f40d63          	beq	s0,a5,1b6c <putchar+0xd2>
    1af6:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1af8:	10c4a503          	lw	a0,268(s1)
    1afc:	e432                	sd	a2,8(sp)
    1afe:	609000ef          	jal	ra,2906 <mutex_unlock>
    1b02:	6622                	ld	a2,8(sp)
}
    1b04:	70e2                	ld	ra,56(sp)
    1b06:	7442                	ld	s0,48(sp)
    1b08:	74a2                	ld	s1,40(sp)
    1b0a:	8532                	mv	a0,a2
    1b0c:	6121                	addi	sp,sp,64
    1b0e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b10:	10000793          	li	a5,256
    1b14:	02f61063          	bne	a2,a5,1b34 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b18:	00001597          	auipc	a1,0x1
    1b1c:	05858593          	addi	a1,a1,88 # 2b70 <buffer>
    1b20:	4505                	li	a0,1
    1b22:	361000ef          	jal	ra,2682 <write>
    1b26:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b2a:	00001797          	auipc	a5,0x1
    1b2e:	0207af23          	sw	zero,62(a5) # 2b68 <buffer_len>
			if (r < 0) {
    1b32:	b7d9                	j	1af8 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b34:	359000ef          	jal	ra,268c <getpid>
    1b38:	842a                	mv	s0,a0
    1b3a:	00001517          	auipc	a0,0x1
    1b3e:	f3e50513          	addi	a0,a0,-194 # 2a78 <enable_deadlock_detect+0x11e>
    1b42:	221000ef          	jal	ra,2562 <basename>
    1b46:	872a                	mv	a4,a0
    1b48:	00001617          	auipc	a2,0x1
    1b4c:	e6860613          	addi	a2,a2,-408 # 29b0 <enable_deadlock_detect+0x56>
    1b50:	05400793          	li	a5,84
    1b54:	86a2                	mv	a3,s0
    1b56:	45fd                	li	a1,31
    1b58:	00001517          	auipc	a0,0x1
    1b5c:	f6050513          	addi	a0,a0,-160 # 2ab8 <enable_deadlock_detect+0x15e>
    1b60:	8fbff0ef          	jal	ra,145a <printf>
    1b64:	557d                	li	a0,-1
    1b66:	357000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    1b6a:	4090                	lw	a2,0(s1)
    1b6c:	d651                	beqz	a2,1af8 <putchar+0x5e>
    1b6e:	b76d                	j	1b18 <putchar+0x7e>

0000000000001b70 <puts>:
{
    1b70:	7139                	addi	sp,sp,-64
    1b72:	f822                	sd	s0,48(sp)
    1b74:	f426                	sd	s1,40(sp)
    1b76:	fc06                	sd	ra,56(sp)
    1b78:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1b7a:	00001417          	auipc	s0,0x1
    1b7e:	fee40413          	addi	s0,s0,-18 # 2b68 <buffer_len>
{
    1b82:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b84:	638000ef          	jal	ra,21bc <strlen>
	if (buffer_lock_enabled == 1) {
    1b88:	10842703          	lw	a4,264(s0)
    1b8c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b8e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1b90:	04f70563          	beq	a4,a5,1bda <puts+0x6a>
		len = out_unlocked(s, l);
    1b94:	8526                	mv	a0,s1
    1b96:	d51ff0ef          	jal	ra,18e6 <out_unlocked>
    1b9a:	892a                	mv	s2,a0
    1b9c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b9e:	00095963          	bgez	s2,1bb0 <puts+0x40>
}
    1ba2:	70e2                	ld	ra,56(sp)
    1ba4:	7442                	ld	s0,48(sp)
    1ba6:	7902                	ld	s2,32(sp)
    1ba8:	8526                	mv	a0,s1
    1baa:	74a2                	ld	s1,40(sp)
    1bac:	6121                	addi	sp,sp,64
    1bae:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1bb0:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bb4:	44a9                	li	s1,10
    1bb6:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bba:	4785                	li	a5,1
    1bbc:	02f70e63          	beq	a4,a5,1bf8 <puts+0x88>
		len = out_unlocked(s, l);
    1bc0:	01f10513          	addi	a0,sp,31
    1bc4:	e2fff0ef          	jal	ra,19f2 <out_unlocked.constprop.0>
}
    1bc8:	70e2                	ld	ra,56(sp)
    1bca:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bcc:	41f5549b          	sraiw	s1,a0,0x1f
}
    1bd0:	7902                	ld	s2,32(sp)
    1bd2:	8526                	mv	a0,s1
    1bd4:	74a2                	ld	s1,40(sp)
    1bd6:	6121                	addi	sp,sp,64
    1bd8:	8082                	ret
		mutex_lock(buffer_lock);
    1bda:	e42a                	sd	a0,8(sp)
    1bdc:	10c42503          	lw	a0,268(s0)
    1be0:	51b000ef          	jal	ra,28fa <mutex_lock>
		len = out_unlocked(s, l);
    1be4:	65a2                	ld	a1,8(sp)
    1be6:	8526                	mv	a0,s1
    1be8:	cffff0ef          	jal	ra,18e6 <out_unlocked>
    1bec:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1bee:	10c42503          	lw	a0,268(s0)
    1bf2:	515000ef          	jal	ra,2906 <mutex_unlock>
    1bf6:	b75d                	j	1b9c <puts+0x2c>
		mutex_lock(buffer_lock);
    1bf8:	10c42503          	lw	a0,268(s0)
    1bfc:	4ff000ef          	jal	ra,28fa <mutex_lock>
		buffer[buffer_len++] = c;
    1c00:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c02:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c06:	0017861b          	addiw	a2,a5,1
    1c0a:	97a2                	add	a5,a5,s0
    1c0c:	c010                	sw	a2,0(s0)
    1c0e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c12:	06c6dc63          	bge	a3,a2,1c8a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c16:	10000793          	li	a5,256
    1c1a:	02f61c63          	bne	a2,a5,1c52 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c1e:	00001597          	auipc	a1,0x1
    1c22:	f5258593          	addi	a1,a1,-174 # 2b70 <buffer>
    1c26:	4505                	li	a0,1
    1c28:	25b000ef          	jal	ra,2682 <write>
			if (r < 0) {
    1c2c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c2e:	00001797          	auipc	a5,0x1
    1c32:	f207ad23          	sw	zero,-198(a5) # 2b68 <buffer_len>
			if (r < 0) {
    1c36:	04054c63          	bltz	a0,1c8e <puts+0x11e>
			if (r < buffer_len) {
    1c3a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c3c:	10c42503          	lw	a0,268(s0)
    1c40:	4c7000ef          	jal	ra,2906 <mutex_unlock>
}
    1c44:	70e2                	ld	ra,56(sp)
    1c46:	7442                	ld	s0,48(sp)
    1c48:	7902                	ld	s2,32(sp)
    1c4a:	8526                	mv	a0,s1
    1c4c:	74a2                	ld	s1,40(sp)
    1c4e:	6121                	addi	sp,sp,64
    1c50:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c52:	23b000ef          	jal	ra,268c <getpid>
    1c56:	84aa                	mv	s1,a0
    1c58:	00001517          	auipc	a0,0x1
    1c5c:	e2050513          	addi	a0,a0,-480 # 2a78 <enable_deadlock_detect+0x11e>
    1c60:	103000ef          	jal	ra,2562 <basename>
    1c64:	872a                	mv	a4,a0
    1c66:	00001617          	auipc	a2,0x1
    1c6a:	d4a60613          	addi	a2,a2,-694 # 29b0 <enable_deadlock_detect+0x56>
    1c6e:	05400793          	li	a5,84
    1c72:	86a6                	mv	a3,s1
    1c74:	45fd                	li	a1,31
    1c76:	00001517          	auipc	a0,0x1
    1c7a:	e4250513          	addi	a0,a0,-446 # 2ab8 <enable_deadlock_detect+0x15e>
    1c7e:	fdcff0ef          	jal	ra,145a <printf>
    1c82:	557d                	li	a0,-1
    1c84:	239000ef          	jal	ra,26bc <exit>
	if (buffer_len == 0)
    1c88:	4010                	lw	a2,0(s0)
    1c8a:	da45                	beqz	a2,1c3a <puts+0xca>
    1c8c:	bf49                	j	1c1e <puts+0xae>
    1c8e:	54fd                	li	s1,-1
    1c90:	b775                	j	1c3c <puts+0xcc>

0000000000001c92 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1c92:	715d                	addi	sp,sp,-80
    1c94:	e486                	sd	ra,72(sp)
    1c96:	e0a2                	sd	s0,64(sp)
    1c98:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1c9a:	14054363          	bltz	a0,1de0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1c9e:	02b577bb          	remuw	a5,a0,a1
    1ca2:	00001617          	auipc	a2,0x1
    1ca6:	00660613          	addi	a2,a2,6 # 2ca8 <digits>
	buf[16] = 0;
    1caa:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1cae:	0005871b          	sext.w	a4,a1
    1cb2:	1782                	slli	a5,a5,0x20
    1cb4:	9381                	srli	a5,a5,0x20
    1cb6:	97b2                	add	a5,a5,a2
    1cb8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cbc:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1cc0:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1cc4:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1cc6:	0eb56763          	bltu	a0,a1,1db4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1cca:	02e877bb          	remuw	a5,a6,a4
    1cce:	1782                	slli	a5,a5,0x20
    1cd0:	9381                	srli	a5,a5,0x20
    1cd2:	97b2                	add	a5,a5,a2
    1cd4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cd8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1cdc:	02f10323          	sb	a5,38(sp)
    1ce0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ce2:	0ce86963          	bltu	a6,a4,1db4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ce6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1cea:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1cee:	1582                	slli	a1,a1,0x20
    1cf0:	9181                	srli	a1,a1,0x20
    1cf2:	95b2                	add	a1,a1,a2
    1cf4:	0005c583          	lbu	a1,0(a1)
    1cf8:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1cfc:	0007859b          	sext.w	a1,a5
    1d00:	16e6e563          	bltu	a3,a4,1e6a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d04:	02e7f6bb          	remuw	a3,a5,a4
    1d08:	1682                	slli	a3,a3,0x20
    1d0a:	9281                	srli	a3,a3,0x20
    1d0c:	96b2                	add	a3,a3,a2
    1d0e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d12:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d16:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d1a:	16e5e163          	bltu	a1,a4,1e7c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d1e:	02e876bb          	remuw	a3,a6,a4
    1d22:	1682                	slli	a3,a3,0x20
    1d24:	9281                	srli	a3,a3,0x20
    1d26:	96b2                	add	a3,a3,a2
    1d28:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d2c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d30:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d34:	14e86d63          	bltu	a6,a4,1e8e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d38:	02e5f6bb          	remuw	a3,a1,a4
    1d3c:	1682                	slli	a3,a3,0x20
    1d3e:	9281                	srli	a3,a3,0x20
    1d40:	96b2                	add	a3,a3,a2
    1d42:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d46:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d4a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d4e:	10e5e563          	bltu	a1,a4,1e58 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d52:	02e876bb          	remuw	a3,a6,a4
    1d56:	1682                	slli	a3,a3,0x20
    1d58:	9281                	srli	a3,a3,0x20
    1d5a:	96b2                	add	a3,a3,a2
    1d5c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d60:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d64:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1d68:	14e86263          	bltu	a6,a4,1eac <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1d6c:	02e5f6bb          	remuw	a3,a1,a4
    1d70:	1682                	slli	a3,a3,0x20
    1d72:	9281                	srli	a3,a3,0x20
    1d74:	96b2                	add	a3,a3,a2
    1d76:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d7a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d7e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1d82:	14e5e463          	bltu	a1,a4,1eca <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1d86:	02e876bb          	remuw	a3,a6,a4
    1d8a:	1682                	slli	a3,a3,0x20
    1d8c:	9281                	srli	a3,a3,0x20
    1d8e:	96b2                	add	a3,a3,a2
    1d90:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d94:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1d98:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1d9c:	14e86063          	bltu	a6,a4,1edc <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1da0:	1782                	slli	a5,a5,0x20
    1da2:	9381                	srli	a5,a5,0x20
    1da4:	97b2                	add	a5,a5,a2
    1da6:	0007c703          	lbu	a4,0(a5)
    1daa:	4799                	li	a5,6
    1dac:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1db0:	10054763          	bltz	a0,1ebe <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1db4:	00001497          	auipc	s1,0x1
    1db8:	db448493          	addi	s1,s1,-588 # 2b68 <buffer_len>
    1dbc:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1dc0:	0828                	addi	a0,sp,24
    1dc2:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1dc4:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1dc6:	00f50433          	add	s0,a0,a5
    1dca:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1dcc:	06e68463          	beq	a3,a4,1e34 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1dd0:	8522                	mv	a0,s0
    1dd2:	b15ff0ef          	jal	ra,18e6 <out_unlocked>
}
    1dd6:	60a6                	ld	ra,72(sp)
    1dd8:	6406                	ld	s0,64(sp)
    1dda:	74e2                	ld	s1,56(sp)
    1ddc:	6161                	addi	sp,sp,80
    1dde:	8082                	ret
		x = -xx;
    1de0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1de4:	02b877bb          	remuw	a5,a6,a1
    1de8:	00001617          	auipc	a2,0x1
    1dec:	ec060613          	addi	a2,a2,-320 # 2ca8 <digits>
	buf[16] = 0;
    1df0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1df4:	0005871b          	sext.w	a4,a1
    1df8:	1782                	slli	a5,a5,0x20
    1dfa:	9381                	srli	a5,a5,0x20
    1dfc:	97b2                	add	a5,a5,a2
    1dfe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e02:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e06:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e0a:	08b86b63          	bltu	a6,a1,1ea0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e0e:	02e8f7bb          	remuw	a5,a7,a4
    1e12:	1782                	slli	a5,a5,0x20
    1e14:	9381                	srli	a5,a5,0x20
    1e16:	97b2                	add	a5,a5,a2
    1e18:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e1c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e20:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e24:	ece8f1e3          	bgeu	a7,a4,1ce6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e28:	02d00793          	li	a5,45
    1e2c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e30:	47b5                	li	a5,13
    1e32:	b749                	j	1db4 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e34:	10c4a503          	lw	a0,268(s1)
    1e38:	e42e                	sd	a1,8(sp)
    1e3a:	2c1000ef          	jal	ra,28fa <mutex_lock>
		len = out_unlocked(s, l);
    1e3e:	65a2                	ld	a1,8(sp)
    1e40:	8522                	mv	a0,s0
    1e42:	aa5ff0ef          	jal	ra,18e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1e46:	10c4a503          	lw	a0,268(s1)
    1e4a:	2bd000ef          	jal	ra,2906 <mutex_unlock>
}
    1e4e:	60a6                	ld	ra,72(sp)
    1e50:	6406                	ld	s0,64(sp)
    1e52:	74e2                	ld	s1,56(sp)
    1e54:	6161                	addi	sp,sp,80
    1e56:	8082                	ret
		buf[i--] = digits[x % base];
    1e58:	47a9                	li	a5,10
	if (sign)
    1e5a:	f4055de3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e5e:	02d00793          	li	a5,45
    1e62:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e66:	47a5                	li	a5,9
    1e68:	b7b1                	j	1db4 <printint.constprop.0+0x122>
    1e6a:	47b5                	li	a5,13
	if (sign)
    1e6c:	f40554e3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e70:	02d00793          	li	a5,45
    1e74:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1e78:	47b1                	li	a5,12
    1e7a:	bf2d                	j	1db4 <printint.constprop.0+0x122>
    1e7c:	47b1                	li	a5,12
	if (sign)
    1e7e:	f2055be3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e82:	02d00793          	li	a5,45
    1e86:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1e8a:	47ad                	li	a5,11
    1e8c:	b725                	j	1db4 <printint.constprop.0+0x122>
    1e8e:	47ad                	li	a5,11
	if (sign)
    1e90:	f20552e3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e94:	02d00793          	li	a5,45
    1e98:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1e9c:	47a9                	li	a5,10
    1e9e:	bf19                	j	1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea0:	02d00793          	li	a5,45
    1ea4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ea8:	47b9                	li	a5,14
    1eaa:	b729                	j	1db4 <printint.constprop.0+0x122>
    1eac:	47a5                	li	a5,9
	if (sign)
    1eae:	f00553e3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb2:	02d00793          	li	a5,45
    1eb6:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1eba:	47a1                	li	a5,8
    1ebc:	bde5                	j	1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ebe:	02d00793          	li	a5,45
    1ec2:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ec6:	4795                	li	a5,5
    1ec8:	b5f5                	j	1db4 <printint.constprop.0+0x122>
    1eca:	47a1                	li	a5,8
	if (sign)
    1ecc:	ee0554e3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed0:	02d00793          	li	a5,45
    1ed4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1ed8:	479d                	li	a5,7
    1eda:	bde9                	j	1db4 <printint.constprop.0+0x122>
    1edc:	479d                	li	a5,7
	if (sign)
    1ede:	ec055be3          	bgez	a0,1db4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee2:	02d00793          	li	a5,45
    1ee6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1eea:	4799                	li	a5,6
    1eec:	b5e1                	j	1db4 <printint.constprop.0+0x122>

0000000000001eee <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1eee:	02000793          	li	a5,32
    1ef2:	00f50663          	beq	a0,a5,1efe <isspace+0x10>
    1ef6:	355d                	addiw	a0,a0,-9
    1ef8:	00553513          	sltiu	a0,a0,5
    1efc:	8082                	ret
    1efe:	4505                	li	a0,1
}
    1f00:	8082                	ret

0000000000001f02 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f02:	fd05051b          	addiw	a0,a0,-48
}
    1f06:	00a53513          	sltiu	a0,a0,10
    1f0a:	8082                	ret

0000000000001f0c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f0c:	02000613          	li	a2,32
    1f10:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f12:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f16:	ff77869b          	addiw	a3,a5,-9
    1f1a:	04c78c63          	beq	a5,a2,1f72 <atoi+0x66>
    1f1e:	0007871b          	sext.w	a4,a5
    1f22:	04d5f863          	bgeu	a1,a3,1f72 <atoi+0x66>
		s++;
	switch (*s) {
    1f26:	02b00693          	li	a3,43
    1f2a:	04d78963          	beq	a5,a3,1f7c <atoi+0x70>
    1f2e:	02d00693          	li	a3,45
    1f32:	06d78263          	beq	a5,a3,1f96 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f36:	fd07061b          	addiw	a2,a4,-48
    1f3a:	47a5                	li	a5,9
    1f3c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f3e:	4e01                	li	t3,0
	while (isdigit(*s))
    1f40:	04c7e963          	bltu	a5,a2,1f92 <atoi+0x86>
	int n = 0, neg = 0;
    1f44:	4501                	li	a0,0
	while (isdigit(*s))
    1f46:	4825                	li	a6,9
    1f48:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f4c:	0025179b          	slliw	a5,a0,0x2
    1f50:	9fa9                	addw	a5,a5,a0
    1f52:	fd07031b          	addiw	t1,a4,-48
    1f56:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f5a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f5e:	0685                	addi	a3,a3,1
    1f60:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f64:	0006071b          	sext.w	a4,a2
    1f68:	feb870e3          	bgeu	a6,a1,1f48 <atoi+0x3c>
	return neg ? n : -n;
    1f6c:	000e0563          	beqz	t3,1f76 <atoi+0x6a>
}
    1f70:	8082                	ret
		s++;
    1f72:	0505                	addi	a0,a0,1
    1f74:	bf79                	j	1f12 <atoi+0x6>
	return neg ? n : -n;
    1f76:	4113053b          	subw	a0,t1,a7
    1f7a:	8082                	ret
	while (isdigit(*s))
    1f7c:	00154703          	lbu	a4,1(a0)
    1f80:	47a5                	li	a5,9
		s++;
    1f82:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1f86:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1f8a:	4e01                	li	t3,0
	while (isdigit(*s))
    1f8c:	2701                	sext.w	a4,a4
    1f8e:	fac7fbe3          	bgeu	a5,a2,1f44 <atoi+0x38>
    1f92:	4501                	li	a0,0
}
    1f94:	8082                	ret
	while (isdigit(*s))
    1f96:	00154703          	lbu	a4,1(a0)
    1f9a:	47a5                	li	a5,9
		s++;
    1f9c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fa0:	fd07061b          	addiw	a2,a4,-48
    1fa4:	2701                	sext.w	a4,a4
    1fa6:	fec7e6e3          	bltu	a5,a2,1f92 <atoi+0x86>
		neg = 1;
    1faa:	4e05                	li	t3,1
    1fac:	bf61                	j	1f44 <atoi+0x38>

0000000000001fae <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fae:	16060d63          	beqz	a2,2128 <memset+0x17a>
    1fb2:	40a007b3          	neg	a5,a0
    1fb6:	8b9d                	andi	a5,a5,7
    1fb8:	00778693          	addi	a3,a5,7
    1fbc:	482d                	li	a6,11
    1fbe:	0ff5f713          	zext.b	a4,a1
    1fc2:	fff60593          	addi	a1,a2,-1
    1fc6:	1706e263          	bltu	a3,a6,212a <memset+0x17c>
    1fca:	16d5ea63          	bltu	a1,a3,213e <memset+0x190>
    1fce:	16078563          	beqz	a5,2138 <memset+0x18a>
    1fd2:	00e50023          	sb	a4,0(a0)
    1fd6:	4685                	li	a3,1
    1fd8:	00150593          	addi	a1,a0,1
    1fdc:	14d78c63          	beq	a5,a3,2134 <memset+0x186>
    1fe0:	00e500a3          	sb	a4,1(a0)
    1fe4:	4689                	li	a3,2
    1fe6:	00250593          	addi	a1,a0,2
    1fea:	14d78d63          	beq	a5,a3,2144 <memset+0x196>
    1fee:	00e50123          	sb	a4,2(a0)
    1ff2:	468d                	li	a3,3
    1ff4:	00350593          	addi	a1,a0,3
    1ff8:	12d78b63          	beq	a5,a3,212e <memset+0x180>
    1ffc:	00e501a3          	sb	a4,3(a0)
    2000:	4691                	li	a3,4
    2002:	00450593          	addi	a1,a0,4
    2006:	14d78163          	beq	a5,a3,2148 <memset+0x19a>
    200a:	00e50223          	sb	a4,4(a0)
    200e:	4695                	li	a3,5
    2010:	00550593          	addi	a1,a0,5
    2014:	12d78c63          	beq	a5,a3,214c <memset+0x19e>
    2018:	00e502a3          	sb	a4,5(a0)
    201c:	469d                	li	a3,7
    201e:	00650593          	addi	a1,a0,6
    2022:	12d79763          	bne	a5,a3,2150 <memset+0x1a2>
    2026:	00750593          	addi	a1,a0,7
    202a:	00e50323          	sb	a4,6(a0)
    202e:	481d                	li	a6,7
    2030:	00871693          	slli	a3,a4,0x8
    2034:	01071893          	slli	a7,a4,0x10
    2038:	8ed9                	or	a3,a3,a4
    203a:	01871313          	slli	t1,a4,0x18
    203e:	0116e6b3          	or	a3,a3,a7
    2042:	0066e6b3          	or	a3,a3,t1
    2046:	02071893          	slli	a7,a4,0x20
    204a:	02871e13          	slli	t3,a4,0x28
    204e:	0116e6b3          	or	a3,a3,a7
    2052:	40f60333          	sub	t1,a2,a5
    2056:	03071893          	slli	a7,a4,0x30
    205a:	01c6e6b3          	or	a3,a3,t3
    205e:	0116e6b3          	or	a3,a3,a7
    2062:	03871e13          	slli	t3,a4,0x38
    2066:	97aa                	add	a5,a5,a0
    2068:	ff837893          	andi	a7,t1,-8
    206c:	01c6e6b3          	or	a3,a3,t3
    2070:	98be                	add	a7,a7,a5
    2072:	e394                	sd	a3,0(a5)
    2074:	07a1                	addi	a5,a5,8
    2076:	ff179ee3          	bne	a5,a7,2072 <memset+0xc4>
    207a:	ff837893          	andi	a7,t1,-8
    207e:	011587b3          	add	a5,a1,a7
    2082:	010886bb          	addw	a3,a7,a6
    2086:	0b130663          	beq	t1,a7,2132 <memset+0x184>
    208a:	00e78023          	sb	a4,0(a5)
    208e:	0016859b          	addiw	a1,a3,1
    2092:	08c5fb63          	bgeu	a1,a2,2128 <memset+0x17a>
    2096:	00e780a3          	sb	a4,1(a5)
    209a:	0026859b          	addiw	a1,a3,2
    209e:	08c5f563          	bgeu	a1,a2,2128 <memset+0x17a>
    20a2:	00e78123          	sb	a4,2(a5)
    20a6:	0036859b          	addiw	a1,a3,3
    20aa:	06c5ff63          	bgeu	a1,a2,2128 <memset+0x17a>
    20ae:	00e781a3          	sb	a4,3(a5)
    20b2:	0046859b          	addiw	a1,a3,4
    20b6:	06c5f963          	bgeu	a1,a2,2128 <memset+0x17a>
    20ba:	00e78223          	sb	a4,4(a5)
    20be:	0056859b          	addiw	a1,a3,5
    20c2:	06c5f363          	bgeu	a1,a2,2128 <memset+0x17a>
    20c6:	00e782a3          	sb	a4,5(a5)
    20ca:	0066859b          	addiw	a1,a3,6
    20ce:	04c5fd63          	bgeu	a1,a2,2128 <memset+0x17a>
    20d2:	00e78323          	sb	a4,6(a5)
    20d6:	0076859b          	addiw	a1,a3,7
    20da:	04c5f763          	bgeu	a1,a2,2128 <memset+0x17a>
    20de:	00e783a3          	sb	a4,7(a5)
    20e2:	0086859b          	addiw	a1,a3,8
    20e6:	04c5f163          	bgeu	a1,a2,2128 <memset+0x17a>
    20ea:	00e78423          	sb	a4,8(a5)
    20ee:	0096859b          	addiw	a1,a3,9
    20f2:	02c5fb63          	bgeu	a1,a2,2128 <memset+0x17a>
    20f6:	00e784a3          	sb	a4,9(a5)
    20fa:	00a6859b          	addiw	a1,a3,10
    20fe:	02c5f563          	bgeu	a1,a2,2128 <memset+0x17a>
    2102:	00e78523          	sb	a4,10(a5)
    2106:	00b6859b          	addiw	a1,a3,11
    210a:	00c5ff63          	bgeu	a1,a2,2128 <memset+0x17a>
    210e:	00e785a3          	sb	a4,11(a5)
    2112:	00c6859b          	addiw	a1,a3,12
    2116:	00c5f963          	bgeu	a1,a2,2128 <memset+0x17a>
    211a:	00e78623          	sb	a4,12(a5)
    211e:	26b5                	addiw	a3,a3,13
    2120:	00c6f463          	bgeu	a3,a2,2128 <memset+0x17a>
    2124:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2128:	8082                	ret
    212a:	46ad                	li	a3,11
    212c:	bd79                	j	1fca <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    212e:	480d                	li	a6,3
    2130:	b701                	j	2030 <memset+0x82>
    2132:	8082                	ret
    2134:	4805                	li	a6,1
    2136:	bded                	j	2030 <memset+0x82>
    2138:	85aa                	mv	a1,a0
    213a:	4801                	li	a6,0
    213c:	bdd5                	j	2030 <memset+0x82>
    213e:	87aa                	mv	a5,a0
    2140:	4681                	li	a3,0
    2142:	b7a1                	j	208a <memset+0xdc>
    2144:	4809                	li	a6,2
    2146:	b5ed                	j	2030 <memset+0x82>
    2148:	4811                	li	a6,4
    214a:	b5dd                	j	2030 <memset+0x82>
    214c:	4815                	li	a6,5
    214e:	b5cd                	j	2030 <memset+0x82>
    2150:	4819                	li	a6,6
    2152:	bdf9                	j	2030 <memset+0x82>

0000000000002154 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2154:	00054783          	lbu	a5,0(a0)
    2158:	0005c703          	lbu	a4,0(a1)
    215c:	00e79863          	bne	a5,a4,216c <strcmp+0x18>
    2160:	0505                	addi	a0,a0,1
    2162:	0585                	addi	a1,a1,1
    2164:	fbe5                	bnez	a5,2154 <strcmp>
    2166:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2168:	9d19                	subw	a0,a0,a4
    216a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    216c:	0007851b          	sext.w	a0,a5
    2170:	bfe5                	j	2168 <strcmp+0x14>

0000000000002172 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2172:	ca15                	beqz	a2,21a6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2174:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2178:	167d                	addi	a2,a2,-1
    217a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    217e:	eb99                	bnez	a5,2194 <strncmp+0x22>
    2180:	a815                	j	21b4 <strncmp+0x42>
    2182:	00a68e63          	beq	a3,a0,219e <strncmp+0x2c>
    2186:	0505                	addi	a0,a0,1
    2188:	00f71b63          	bne	a4,a5,219e <strncmp+0x2c>
    218c:	00054783          	lbu	a5,0(a0)
    2190:	cf89                	beqz	a5,21aa <strncmp+0x38>
    2192:	85b2                	mv	a1,a2
    2194:	0005c703          	lbu	a4,0(a1)
    2198:	00158613          	addi	a2,a1,1
    219c:	f37d                	bnez	a4,2182 <strncmp+0x10>
		;
	return *l - *r;
    219e:	0007851b          	sext.w	a0,a5
    21a2:	9d19                	subw	a0,a0,a4
    21a4:	8082                	ret
		return 0;
    21a6:	4501                	li	a0,0
}
    21a8:	8082                	ret
	return *l - *r;
    21aa:	0015c703          	lbu	a4,1(a1)
    21ae:	4501                	li	a0,0
    21b0:	9d19                	subw	a0,a0,a4
    21b2:	8082                	ret
    21b4:	0005c703          	lbu	a4,0(a1)
    21b8:	4501                	li	a0,0
    21ba:	b7e5                	j	21a2 <strncmp+0x30>

00000000000021bc <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21bc:	00757793          	andi	a5,a0,7
    21c0:	cf89                	beqz	a5,21da <strlen+0x1e>
    21c2:	87aa                	mv	a5,a0
    21c4:	a029                	j	21ce <strlen+0x12>
    21c6:	0785                	addi	a5,a5,1
    21c8:	0077f713          	andi	a4,a5,7
    21cc:	cb01                	beqz	a4,21dc <strlen+0x20>
		if (!*s)
    21ce:	0007c703          	lbu	a4,0(a5)
    21d2:	fb75                	bnez	a4,21c6 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    21d4:	40a78533          	sub	a0,a5,a0
}
    21d8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    21da:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    21dc:	6394                	ld	a3,0(a5)
    21de:	00001597          	auipc	a1,0x1
    21e2:	9725b583          	ld	a1,-1678(a1) # 2b50 <enable_deadlock_detect+0x1f6>
    21e6:	00001617          	auipc	a2,0x1
    21ea:	97263603          	ld	a2,-1678(a2) # 2b58 <enable_deadlock_detect+0x1fe>
    21ee:	a019                	j	21f4 <strlen+0x38>
    21f0:	6794                	ld	a3,8(a5)
    21f2:	07a1                	addi	a5,a5,8
    21f4:	00b68733          	add	a4,a3,a1
    21f8:	fff6c693          	not	a3,a3
    21fc:	8f75                	and	a4,a4,a3
    21fe:	8f71                	and	a4,a4,a2
    2200:	db65                	beqz	a4,21f0 <strlen+0x34>
	for (; *s; s++)
    2202:	0007c703          	lbu	a4,0(a5)
    2206:	d779                	beqz	a4,21d4 <strlen+0x18>
    2208:	0017c703          	lbu	a4,1(a5)
    220c:	0785                	addi	a5,a5,1
    220e:	d379                	beqz	a4,21d4 <strlen+0x18>
    2210:	0017c703          	lbu	a4,1(a5)
    2214:	0785                	addi	a5,a5,1
    2216:	fb6d                	bnez	a4,2208 <strlen+0x4c>
    2218:	bf75                	j	21d4 <strlen+0x18>

000000000000221a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    221a:	00757713          	andi	a4,a0,7
{
    221e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2220:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2224:	cb19                	beqz	a4,223a <memchr+0x20>
    2226:	ce25                	beqz	a2,229e <memchr+0x84>
    2228:	0007c703          	lbu	a4,0(a5)
    222c:	04b70e63          	beq	a4,a1,2288 <memchr+0x6e>
    2230:	0785                	addi	a5,a5,1
    2232:	0077f713          	andi	a4,a5,7
    2236:	167d                	addi	a2,a2,-1
    2238:	f77d                	bnez	a4,2226 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    223a:	4501                	li	a0,0
	if (n && *s != c) {
    223c:	c235                	beqz	a2,22a0 <memchr+0x86>
    223e:	0007c703          	lbu	a4,0(a5)
    2242:	04b70363          	beq	a4,a1,2288 <memchr+0x6e>
		size_t k = ONES * c;
    2246:	00001517          	auipc	a0,0x1
    224a:	91a53503          	ld	a0,-1766(a0) # 2b60 <enable_deadlock_detect+0x206>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    224e:	471d                	li	a4,7
		size_t k = ONES * c;
    2250:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2254:	02c77a63          	bgeu	a4,a2,2288 <memchr+0x6e>
    2258:	00001897          	auipc	a7,0x1
    225c:	8f88b883          	ld	a7,-1800(a7) # 2b50 <enable_deadlock_detect+0x1f6>
    2260:	00001817          	auipc	a6,0x1
    2264:	8f883803          	ld	a6,-1800(a6) # 2b58 <enable_deadlock_detect+0x1fe>
    2268:	431d                	li	t1,7
    226a:	a029                	j	2274 <memchr+0x5a>
		     w++, n -= SS)
    226c:	1661                	addi	a2,a2,-8
    226e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2270:	02c37963          	bgeu	t1,a2,22a2 <memchr+0x88>
    2274:	6398                	ld	a4,0(a5)
    2276:	8f29                	xor	a4,a4,a0
    2278:	011706b3          	add	a3,a4,a7
    227c:	fff74713          	not	a4,a4
    2280:	8f75                	and	a4,a4,a3
    2282:	01077733          	and	a4,a4,a6
    2286:	d37d                	beqz	a4,226c <memchr+0x52>
{
    2288:	853e                	mv	a0,a5
    228a:	97b2                	add	a5,a5,a2
    228c:	a021                	j	2294 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    228e:	0505                	addi	a0,a0,1
    2290:	00f50763          	beq	a0,a5,229e <memchr+0x84>
    2294:	00054703          	lbu	a4,0(a0)
    2298:	feb71be3          	bne	a4,a1,228e <memchr+0x74>
    229c:	8082                	ret
	return n ? (void *)s : 0;
    229e:	4501                	li	a0,0
}
    22a0:	8082                	ret
	return n ? (void *)s : 0;
    22a2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22a4:	f275                	bnez	a2,2288 <memchr+0x6e>
}
    22a6:	8082                	ret

00000000000022a8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22a8:	1101                	addi	sp,sp,-32
    22aa:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22ac:	862e                	mv	a2,a1
{
    22ae:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22b0:	4581                	li	a1,0
{
    22b2:	e426                	sd	s1,8(sp)
    22b4:	ec06                	sd	ra,24(sp)
    22b6:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22b8:	f63ff0ef          	jal	ra,221a <memchr>
	return p ? p - s : n;
    22bc:	c519                	beqz	a0,22ca <strnlen+0x22>
}
    22be:	60e2                	ld	ra,24(sp)
    22c0:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22c2:	8d05                	sub	a0,a0,s1
}
    22c4:	64a2                	ld	s1,8(sp)
    22c6:	6105                	addi	sp,sp,32
    22c8:	8082                	ret
    22ca:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    22cc:	8522                	mv	a0,s0
}
    22ce:	6442                	ld	s0,16(sp)
    22d0:	64a2                	ld	s1,8(sp)
    22d2:	6105                	addi	sp,sp,32
    22d4:	8082                	ret

00000000000022d6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    22d6:	00a5c7b3          	xor	a5,a1,a0
    22da:	8b9d                	andi	a5,a5,7
    22dc:	eb95                	bnez	a5,2310 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    22de:	0075f793          	andi	a5,a1,7
    22e2:	e7b1                	bnez	a5,232e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    22e4:	6198                	ld	a4,0(a1)
    22e6:	00001617          	auipc	a2,0x1
    22ea:	86a63603          	ld	a2,-1942(a2) # 2b50 <enable_deadlock_detect+0x1f6>
    22ee:	00001817          	auipc	a6,0x1
    22f2:	86a83803          	ld	a6,-1942(a6) # 2b58 <enable_deadlock_detect+0x1fe>
    22f6:	a029                	j	2300 <stpcpy+0x2a>
    22f8:	05a1                	addi	a1,a1,8
    22fa:	e118                	sd	a4,0(a0)
    22fc:	6198                	ld	a4,0(a1)
    22fe:	0521                	addi	a0,a0,8
    2300:	00c707b3          	add	a5,a4,a2
    2304:	fff74693          	not	a3,a4
    2308:	8ff5                	and	a5,a5,a3
    230a:	0107f7b3          	and	a5,a5,a6
    230e:	d7ed                	beqz	a5,22f8 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2310:	0005c783          	lbu	a5,0(a1)
    2314:	00f50023          	sb	a5,0(a0)
    2318:	c785                	beqz	a5,2340 <stpcpy+0x6a>
    231a:	0015c783          	lbu	a5,1(a1)
    231e:	0505                	addi	a0,a0,1
    2320:	0585                	addi	a1,a1,1
    2322:	00f50023          	sb	a5,0(a0)
    2326:	fbf5                	bnez	a5,231a <stpcpy+0x44>
		;
	return d;
}
    2328:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    232a:	0505                	addi	a0,a0,1
    232c:	df45                	beqz	a4,22e4 <stpcpy+0xe>
			if (!(*d = *s))
    232e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2332:	0585                	addi	a1,a1,1
    2334:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2338:	00f50023          	sb	a5,0(a0)
    233c:	f7fd                	bnez	a5,232a <stpcpy+0x54>
}
    233e:	8082                	ret
    2340:	8082                	ret

0000000000002342 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2342:	00a5c7b3          	xor	a5,a1,a0
    2346:	8b9d                	andi	a5,a5,7
    2348:	1a079863          	bnez	a5,24f8 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    234c:	0075f793          	andi	a5,a1,7
    2350:	16078463          	beqz	a5,24b8 <stpncpy+0x176>
    2354:	ea01                	bnez	a2,2364 <stpncpy+0x22>
    2356:	a421                	j	255e <stpncpy+0x21c>
    2358:	167d                	addi	a2,a2,-1
    235a:	0505                	addi	a0,a0,1
    235c:	14070e63          	beqz	a4,24b8 <stpncpy+0x176>
    2360:	1a060863          	beqz	a2,2510 <stpncpy+0x1ce>
    2364:	0005c783          	lbu	a5,0(a1)
    2368:	0585                	addi	a1,a1,1
    236a:	0075f713          	andi	a4,a1,7
    236e:	00f50023          	sb	a5,0(a0)
    2372:	f3fd                	bnez	a5,2358 <stpncpy+0x16>
    2374:	4805                	li	a6,1
    2376:	1a061863          	bnez	a2,2526 <stpncpy+0x1e4>
    237a:	40a007b3          	neg	a5,a0
    237e:	8b9d                	andi	a5,a5,7
    2380:	4681                	li	a3,0
    2382:	18061a63          	bnez	a2,2516 <stpncpy+0x1d4>
    2386:	00778713          	addi	a4,a5,7
    238a:	45ad                	li	a1,11
    238c:	18b76363          	bltu	a4,a1,2512 <stpncpy+0x1d0>
    2390:	1ae6eb63          	bltu	a3,a4,2546 <stpncpy+0x204>
    2394:	1a078363          	beqz	a5,253a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2398:	00050023          	sb	zero,0(a0)
    239c:	4685                	li	a3,1
    239e:	00150713          	addi	a4,a0,1
    23a2:	18d78f63          	beq	a5,a3,2540 <stpncpy+0x1fe>
    23a6:	000500a3          	sb	zero,1(a0)
    23aa:	4689                	li	a3,2
    23ac:	00250713          	addi	a4,a0,2
    23b0:	18d78e63          	beq	a5,a3,254c <stpncpy+0x20a>
    23b4:	00050123          	sb	zero,2(a0)
    23b8:	468d                	li	a3,3
    23ba:	00350713          	addi	a4,a0,3
    23be:	16d78c63          	beq	a5,a3,2536 <stpncpy+0x1f4>
    23c2:	000501a3          	sb	zero,3(a0)
    23c6:	4691                	li	a3,4
    23c8:	00450713          	addi	a4,a0,4
    23cc:	18d78263          	beq	a5,a3,2550 <stpncpy+0x20e>
    23d0:	00050223          	sb	zero,4(a0)
    23d4:	4695                	li	a3,5
    23d6:	00550713          	addi	a4,a0,5
    23da:	16d78d63          	beq	a5,a3,2554 <stpncpy+0x212>
    23de:	000502a3          	sb	zero,5(a0)
    23e2:	469d                	li	a3,7
    23e4:	00650713          	addi	a4,a0,6
    23e8:	16d79863          	bne	a5,a3,2558 <stpncpy+0x216>
    23ec:	00750713          	addi	a4,a0,7
    23f0:	00050323          	sb	zero,6(a0)
    23f4:	40f80833          	sub	a6,a6,a5
    23f8:	ff887593          	andi	a1,a6,-8
    23fc:	97aa                	add	a5,a5,a0
    23fe:	95be                	add	a1,a1,a5
    2400:	0007b023          	sd	zero,0(a5)
    2404:	07a1                	addi	a5,a5,8
    2406:	feb79de3          	bne	a5,a1,2400 <stpncpy+0xbe>
    240a:	ff887593          	andi	a1,a6,-8
    240e:	9ead                	addw	a3,a3,a1
    2410:	00b707b3          	add	a5,a4,a1
    2414:	12b80863          	beq	a6,a1,2544 <stpncpy+0x202>
    2418:	00078023          	sb	zero,0(a5)
    241c:	0016871b          	addiw	a4,a3,1
    2420:	0ec77863          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2424:	000780a3          	sb	zero,1(a5)
    2428:	0026871b          	addiw	a4,a3,2
    242c:	0ec77263          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2430:	00078123          	sb	zero,2(a5)
    2434:	0036871b          	addiw	a4,a3,3
    2438:	0cc77c63          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    243c:	000781a3          	sb	zero,3(a5)
    2440:	0046871b          	addiw	a4,a3,4
    2444:	0cc77663          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2448:	00078223          	sb	zero,4(a5)
    244c:	0056871b          	addiw	a4,a3,5
    2450:	0cc77063          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2454:	000782a3          	sb	zero,5(a5)
    2458:	0066871b          	addiw	a4,a3,6
    245c:	0ac77a63          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2460:	00078323          	sb	zero,6(a5)
    2464:	0076871b          	addiw	a4,a3,7
    2468:	0ac77463          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    246c:	000783a3          	sb	zero,7(a5)
    2470:	0086871b          	addiw	a4,a3,8
    2474:	08c77e63          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2478:	00078423          	sb	zero,8(a5)
    247c:	0096871b          	addiw	a4,a3,9
    2480:	08c77863          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2484:	000784a3          	sb	zero,9(a5)
    2488:	00a6871b          	addiw	a4,a3,10
    248c:	08c77263          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    2490:	00078523          	sb	zero,10(a5)
    2494:	00b6871b          	addiw	a4,a3,11
    2498:	06c77c63          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    249c:	000785a3          	sb	zero,11(a5)
    24a0:	00c6871b          	addiw	a4,a3,12
    24a4:	06c77663          	bgeu	a4,a2,2510 <stpncpy+0x1ce>
    24a8:	00078623          	sb	zero,12(a5)
    24ac:	26b5                	addiw	a3,a3,13
    24ae:	06c6f163          	bgeu	a3,a2,2510 <stpncpy+0x1ce>
    24b2:	000786a3          	sb	zero,13(a5)
    24b6:	8082                	ret
			;
		if (!n || !*s)
    24b8:	c645                	beqz	a2,2560 <stpncpy+0x21e>
    24ba:	0005c783          	lbu	a5,0(a1)
    24be:	ea078be3          	beqz	a5,2374 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24c2:	479d                	li	a5,7
    24c4:	02c7ff63          	bgeu	a5,a2,2502 <stpncpy+0x1c0>
    24c8:	00000897          	auipc	a7,0x0
    24cc:	6888b883          	ld	a7,1672(a7) # 2b50 <enable_deadlock_detect+0x1f6>
    24d0:	00000817          	auipc	a6,0x0
    24d4:	68883803          	ld	a6,1672(a6) # 2b58 <enable_deadlock_detect+0x1fe>
    24d8:	431d                	li	t1,7
    24da:	6198                	ld	a4,0(a1)
    24dc:	011707b3          	add	a5,a4,a7
    24e0:	fff74693          	not	a3,a4
    24e4:	8ff5                	and	a5,a5,a3
    24e6:	0107f7b3          	and	a5,a5,a6
    24ea:	ef81                	bnez	a5,2502 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    24ec:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    24ee:	1661                	addi	a2,a2,-8
    24f0:	05a1                	addi	a1,a1,8
    24f2:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24f4:	fec363e3          	bltu	t1,a2,24da <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    24f8:	e609                	bnez	a2,2502 <stpncpy+0x1c0>
    24fa:	a08d                	j	255c <stpncpy+0x21a>
    24fc:	167d                	addi	a2,a2,-1
    24fe:	0505                	addi	a0,a0,1
    2500:	ca01                	beqz	a2,2510 <stpncpy+0x1ce>
    2502:	0005c783          	lbu	a5,0(a1)
    2506:	0585                	addi	a1,a1,1
    2508:	00f50023          	sb	a5,0(a0)
    250c:	fbe5                	bnez	a5,24fc <stpncpy+0x1ba>
		;
tail:
    250e:	b59d                	j	2374 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2510:	8082                	ret
    2512:	472d                	li	a4,11
    2514:	bdb5                	j	2390 <stpncpy+0x4e>
    2516:	00778713          	addi	a4,a5,7
    251a:	45ad                	li	a1,11
    251c:	fff60693          	addi	a3,a2,-1
    2520:	e6b778e3          	bgeu	a4,a1,2390 <stpncpy+0x4e>
    2524:	b7fd                	j	2512 <stpncpy+0x1d0>
    2526:	40a007b3          	neg	a5,a0
    252a:	8832                	mv	a6,a2
    252c:	8b9d                	andi	a5,a5,7
    252e:	4681                	li	a3,0
    2530:	e4060be3          	beqz	a2,2386 <stpncpy+0x44>
    2534:	b7cd                	j	2516 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2536:	468d                	li	a3,3
    2538:	bd75                	j	23f4 <stpncpy+0xb2>
    253a:	872a                	mv	a4,a0
    253c:	4681                	li	a3,0
    253e:	bd5d                	j	23f4 <stpncpy+0xb2>
    2540:	4685                	li	a3,1
    2542:	bd4d                	j	23f4 <stpncpy+0xb2>
    2544:	8082                	ret
    2546:	87aa                	mv	a5,a0
    2548:	4681                	li	a3,0
    254a:	b5f9                	j	2418 <stpncpy+0xd6>
    254c:	4689                	li	a3,2
    254e:	b55d                	j	23f4 <stpncpy+0xb2>
    2550:	4691                	li	a3,4
    2552:	b54d                	j	23f4 <stpncpy+0xb2>
    2554:	4695                	li	a3,5
    2556:	bd79                	j	23f4 <stpncpy+0xb2>
    2558:	4699                	li	a3,6
    255a:	bd69                	j	23f4 <stpncpy+0xb2>
    255c:	8082                	ret
    255e:	8082                	ret
    2560:	8082                	ret

0000000000002562 <basename>:

char *basename(char *s)
{
    2562:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2564:	c54d                	beqz	a0,260e <basename+0xac>
    2566:	00054783          	lbu	a5,0(a0)
		return ".";
    256a:	00000517          	auipc	a0,0x0
    256e:	5de50513          	addi	a0,a0,1502 # 2b48 <enable_deadlock_detect+0x1ee>
	if (!s || !*s)
    2572:	e391                	bnez	a5,2576 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2574:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2576:	0076f713          	andi	a4,a3,7
    257a:	87b6                	mv	a5,a3
    257c:	cf51                	beqz	a4,2618 <basename+0xb6>
    257e:	0785                	addi	a5,a5,1
    2580:	0077f713          	andi	a4,a5,7
    2584:	c729                	beqz	a4,25ce <basename+0x6c>
		if (!*s)
    2586:	0007c703          	lbu	a4,0(a5)
    258a:	fb75                	bnez	a4,257e <basename+0x1c>
	return s - a;
    258c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    258e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2590:	cf8d                	beqz	a5,25ca <basename+0x68>
    2592:	00f68733          	add	a4,a3,a5
    2596:	02f00593          	li	a1,47
    259a:	a031                	j	25a6 <basename+0x44>
		s[i] = 0;
    259c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25a0:	17fd                	addi	a5,a5,-1
    25a2:	177d                	addi	a4,a4,-1
    25a4:	c39d                	beqz	a5,25ca <basename+0x68>
    25a6:	00074603          	lbu	a2,0(a4)
    25aa:	feb609e3          	beq	a2,a1,259c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25ae:	02f00613          	li	a2,47
    25b2:	a011                	j	25b6 <basename+0x54>
    25b4:	cb99                	beqz	a5,25ca <basename+0x68>
    25b6:	853e                	mv	a0,a5
    25b8:	17fd                	addi	a5,a5,-1
    25ba:	00f68733          	add	a4,a3,a5
    25be:	00074703          	lbu	a4,0(a4)
    25c2:	fec719e3          	bne	a4,a2,25b4 <basename+0x52>
	return s + i;
    25c6:	9536                	add	a0,a0,a3
    25c8:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    25ca:	8536                	mv	a0,a3
    25cc:	8082                	ret
    25ce:	6390                	ld	a2,0(a5)
    25d0:	00000517          	auipc	a0,0x0
    25d4:	58053503          	ld	a0,1408(a0) # 2b50 <enable_deadlock_detect+0x1f6>
    25d8:	00000597          	auipc	a1,0x0
    25dc:	5805b583          	ld	a1,1408(a1) # 2b58 <enable_deadlock_detect+0x1fe>
    25e0:	fff64713          	not	a4,a2
    25e4:	962a                	add	a2,a2,a0
    25e6:	8f71                	and	a4,a4,a2
    25e8:	8f6d                	and	a4,a4,a1
    25ea:	eb11                	bnez	a4,25fe <basename+0x9c>
    25ec:	6790                	ld	a2,8(a5)
    25ee:	07a1                	addi	a5,a5,8
    25f0:	00a60733          	add	a4,a2,a0
    25f4:	fff64613          	not	a2,a2
    25f8:	8f71                	and	a4,a4,a2
    25fa:	8f6d                	and	a4,a4,a1
    25fc:	db65                	beqz	a4,25ec <basename+0x8a>
	for (; *s; s++)
    25fe:	0007c703          	lbu	a4,0(a5)
    2602:	d749                	beqz	a4,258c <basename+0x2a>
    2604:	0017c703          	lbu	a4,1(a5)
    2608:	0785                	addi	a5,a5,1
    260a:	ff6d                	bnez	a4,2604 <basename+0xa2>
    260c:	b741                	j	258c <basename+0x2a>
		return ".";
    260e:	00000517          	auipc	a0,0x0
    2612:	53a50513          	addi	a0,a0,1338 # 2b48 <enable_deadlock_detect+0x1ee>
    2616:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2618:	6290                	ld	a2,0(a3)
    261a:	00000517          	auipc	a0,0x0
    261e:	53653503          	ld	a0,1334(a0) # 2b50 <enable_deadlock_detect+0x1f6>
    2622:	00000597          	auipc	a1,0x0
    2626:	5365b583          	ld	a1,1334(a1) # 2b58 <enable_deadlock_detect+0x1fe>
    262a:	fff64713          	not	a4,a2
    262e:	962a                	add	a2,a2,a0
    2630:	8f71                	and	a4,a4,a2
    2632:	8f6d                	and	a4,a4,a1
    2634:	df45                	beqz	a4,25ec <basename+0x8a>
    2636:	b7f9                	j	2604 <basename+0xa2>

0000000000002638 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2638:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    263c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    263e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2642:	2501                	sext.w	a0,a0
    2644:	8082                	ret

0000000000002646 <close>:

int close(int fd)
{
	if (fd == 1) {
    2646:	4785                	li	a5,1
    2648:	00f50863          	beq	a0,a5,2658 <close+0x12>
	register long a7 __asm__("a7") = n;
    264c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2650:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2654:	2501                	sext.w	a0,a0
    2656:	8082                	ret
{
    2658:	1101                	addi	sp,sp,-32
    265a:	ec06                	sd	ra,24(sp)
    265c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    265e:	cdffe0ef          	jal	ra,133c <__write_buffer>
		__clear_buffer();
    2662:	d03fe0ef          	jal	ra,1364 <__clear_buffer>
    2666:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2668:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    266c:	00000073          	ecall
}
    2670:	60e2                	ld	ra,24(sp)
    2672:	2501                	sext.w	a0,a0
    2674:	6105                	addi	sp,sp,32
    2676:	8082                	ret

0000000000002678 <read>:
	register long a7 __asm__("a7") = n;
    2678:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    267c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2680:	8082                	ret

0000000000002682 <write>:
	register long a7 __asm__("a7") = n;
    2682:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2686:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    268a:	8082                	ret

000000000000268c <getpid>:
	register long a7 __asm__("a7") = n;
    268c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2690:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret

0000000000002698 <getppid>:
	register long a7 __asm__("a7") = n;
    2698:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    269c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    26a0:	2501                	sext.w	a0,a0
    26a2:	8082                	ret

00000000000026a4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    26a4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26a8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <fork>:
	register long a7 __asm__("a7") = n;
    26b0:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    26b4:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    26b8:	2501                	sext.w	a0,a0
    26ba:	8082                	ret

00000000000026bc <exit>:

void exit(int code)
{
    26bc:	1141                	addi	sp,sp,-16
    26be:	e406                	sd	ra,8(sp)
    26c0:	e022                	sd	s0,0(sp)
    26c2:	842a                	mv	s0,a0
	__write_buffer();
    26c4:	c79fe0ef          	jal	ra,133c <__write_buffer>
	__clear_buffer();
    26c8:	c9dfe0ef          	jal	ra,1364 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    26cc:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    26d0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    26d2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    26d6:	60a2                	ld	ra,8(sp)
    26d8:	6402                	ld	s0,0(sp)
    26da:	0141                	addi	sp,sp,16
    26dc:	8082                	ret

00000000000026de <waitpid>:
	register long a7 __asm__("a7") = n;
    26de:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26e2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    26e6:	2501                	sext.w	a0,a0
    26e8:	8082                	ret

00000000000026ea <exec>:
	register long a7 __asm__("a7") = n;
    26ea:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ee:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    26f2:	2501                	sext.w	a0,a0
    26f4:	8082                	ret

00000000000026f6 <get_mtime>:

int64 get_mtime()
{
    26f6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    26f8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26fc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    26fe:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2700:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2704:	2501                	sext.w	a0,a0
    2706:	ed01                	bnez	a0,271e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2708:	6722                	ld	a4,8(sp)
    270a:	3e800793          	li	a5,1000
    270e:	6682                	ld	a3,0(sp)
    2710:	02f75733          	divu	a4,a4,a5
    2714:	02d78533          	mul	a0,a5,a3
    2718:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    271a:	0141                	addi	sp,sp,16
    271c:	8082                	ret
	return -1;
    271e:	557d                	li	a0,-1
    2720:	bfed                	j	271a <get_mtime+0x24>

0000000000002722 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2722:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2726:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    272a:	2501                	sext.w	a0,a0
    272c:	8082                	ret

000000000000272e <sleep>:

int sleep(unsigned long long time)
{
    272e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2730:	880a                	mv	a6,sp
{
    2732:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2734:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2738:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    273a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    273c:	00000073          	ecall
	if (err == 0) {
    2740:	2501                	sext.w	a0,a0
    2742:	ed31                	bnez	a0,279e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2744:	6722                	ld	a4,8(sp)
    2746:	3e800793          	li	a5,1000
    274a:	6682                	ld	a3,0(sp)
    274c:	02f75733          	divu	a4,a4,a5
    2750:	02d787b3          	mul	a5,a5,a3
    2754:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2756:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    275a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    275c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    275e:	00000073          	ecall
	if (err == 0) {
    2762:	2501                	sext.w	a0,a0
    2764:	e915                	bnez	a0,2798 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2766:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2768:	3e800693          	li	a3,1000
    276c:	a819                	j	2782 <sleep+0x54>
	__asm_syscall("r"(a7))
    276e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2772:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2776:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2778:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    277a:	00000073          	ecall
	if (err == 0) {
    277e:	2501                	sext.w	a0,a0
    2780:	ed01                	bnez	a0,2798 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2782:	6722                	ld	a4,8(sp)
    2784:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2786:	07c00893          	li	a7,124
    278a:	02d75733          	divu	a4,a4,a3
    278e:	02f687b3          	mul	a5,a3,a5
    2792:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2794:	fcc7ede3          	bltu	a5,a2,276e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2798:	4501                	li	a0,0
    279a:	0141                	addi	sp,sp,16
    279c:	8082                	ret
    279e:	57fd                	li	a5,-1
    27a0:	bf5d                	j	2756 <sleep+0x28>

00000000000027a2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    27a2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    27a6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    27aa:	2501                	sext.w	a0,a0
    27ac:	8082                	ret

00000000000027ae <set_priority>:
	register long a7 __asm__("a7") = n;
    27ae:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    27b2:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    27b6:	2501                	sext.w	a0,a0
    27b8:	8082                	ret

00000000000027ba <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    27ba:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27be:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    27c2:	2501                	sext.w	a0,a0
    27c4:	8082                	ret

00000000000027c6 <munmap>:
	register long a7 __asm__("a7") = n;
    27c6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ca:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    27ce:	2501                	sext.w	a0,a0
    27d0:	8082                	ret

00000000000027d2 <wait>:

int wait(int *code)
{
    27d2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27d4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    27d8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27da:	00000073          	ecall
	return waitpid(-1, code);
}
    27de:	2501                	sext.w	a0,a0
    27e0:	8082                	ret

00000000000027e2 <spawn>:
	register long a7 __asm__("a7") = n;
    27e2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    27e6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    27ea:	2501                	sext.w	a0,a0
    27ec:	8082                	ret

00000000000027ee <pipe>:
	register long a7 __asm__("a7") = n;
    27ee:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    27f2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    27f6:	2501                	sext.w	a0,a0
    27f8:	8082                	ret

00000000000027fa <mailread>:
	register long a7 __asm__("a7") = n;
    27fa:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27fe:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2802:	2501                	sext.w	a0,a0
    2804:	8082                	ret

0000000000002806 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2806:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    280a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    280e:	2501                	sext.w	a0,a0
    2810:	8082                	ret

0000000000002812 <fstat>:
	register long a7 __asm__("a7") = n;
    2812:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2816:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    281a:	2501                	sext.w	a0,a0
    281c:	8082                	ret

000000000000281e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    281e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2820:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2824:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2826:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    282a:	2501                	sext.w	a0,a0
    282c:	8082                	ret

000000000000282e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    282e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2830:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2834:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2836:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    283a:	2501                	sext.w	a0,a0
    283c:	8082                	ret

000000000000283e <link>:

int link(char *old_path, char *new_path)
{
    283e:	87aa                	mv	a5,a0
    2840:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2842:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2846:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    284a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    284c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2850:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2852:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2856:	2501                	sext.w	a0,a0
    2858:	8082                	ret

000000000000285a <unlink>:

int unlink(char *path)
{
    285a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    285c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2860:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2864:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2866:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    286a:	2501                	sext.w	a0,a0
    286c:	8082                	ret

000000000000286e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    286e:	00000797          	auipc	a5,0x0
    2872:	45a7b783          	ld	a5,1114(a5) # 2cc8 <_GLOBAL_OFFSET_TABLE_+0x8>
    2876:	439c                	lw	a5,0(a5)
    2878:	c799                	beqz	a5,2886 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    287a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    287e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2882:	2501                	sext.w	a0,a0
    2884:	8082                	ret
{
    2886:	1101                	addi	sp,sp,-32
    2888:	ec06                	sd	ra,24(sp)
    288a:	e42e                	sd	a1,8(sp)
    288c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    288e:	fe7fe0ef          	jal	ra,1874 <enable_thread_io_buffer>
    2892:	65a2                	ld	a1,8(sp)
    2894:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2896:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    289a:	00000073          	ecall
}
    289e:	60e2                	ld	ra,24(sp)
    28a0:	2501                	sext.w	a0,a0
    28a2:	6105                	addi	sp,sp,32
    28a4:	8082                	ret

00000000000028a6 <gettid>:
	register long a7 __asm__("a7") = n;
    28a6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    28aa:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    28ae:	2501                	sext.w	a0,a0
    28b0:	8082                	ret

00000000000028b2 <waittid>:

int waittid(int tid)
{
    28b2:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    28b4:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    28b8:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    28bc:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    28be:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28c0:	00e51e63          	bne	a0,a4,28dc <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    28c4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    28c8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    28cc:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    28d0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    28d2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    28d6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28d8:	fee506e3          	beq	a0,a4,28c4 <waittid+0x12>
	}
	return ret;
}
    28dc:	8082                	ret

00000000000028de <mutex_create>:
	register long a7 __asm__("a7") = n;
    28de:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    28e2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    28e4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    28e8:	2501                	sext.w	a0,a0
    28ea:	8082                	ret

00000000000028ec <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    28ec:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    28f0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    28f2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    28f6:	2501                	sext.w	a0,a0
    28f8:	8082                	ret

00000000000028fa <mutex_lock>:
	register long a7 __asm__("a7") = n;
    28fa:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    28fe:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2902:	2501                	sext.w	a0,a0
    2904:	8082                	ret

0000000000002906 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2906:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    290a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    290e:	2501                	sext.w	a0,a0
    2910:	8082                	ret

0000000000002912 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2912:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2916:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    291a:	2501                	sext.w	a0,a0
    291c:	8082                	ret

000000000000291e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    291e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2922:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2926:	2501                	sext.w	a0,a0
    2928:	8082                	ret

000000000000292a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    292a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    292e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2932:	2501                	sext.w	a0,a0
    2934:	8082                	ret

0000000000002936 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2936:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    293a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    293e:	2501                	sext.w	a0,a0
    2940:	8082                	ret

0000000000002942 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2942:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2946:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    294a:	2501                	sext.w	a0,a0
    294c:	8082                	ret

000000000000294e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    294e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2952:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2956:	2501                	sext.w	a0,a0
    2958:	8082                	ret

000000000000295a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    295a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    295e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2962:	2501                	sext.w	a0,a0
    2964:	8082                	ret
