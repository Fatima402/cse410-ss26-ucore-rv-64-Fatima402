
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6_usertest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	ac09                	j	1212 <__start_main>

0000000000001002 <run_tests>:
#ifndef USER_TEST
#define USER_TEST

int run_tests(const char *tests[], int n)
{
    1002:	7175                	addi	sp,sp,-144
    1004:	e506                	sd	ra,136(sp)
    1006:	e122                	sd	s0,128(sp)
    1008:	fca6                	sd	s1,120(sp)
    100a:	f8ca                	sd	s2,112(sp)
    100c:	f4ce                	sd	s3,104(sp)
    100e:	f0d2                	sd	s4,96(sp)
    1010:	ecd6                	sd	s5,88(sp)
    1012:	e8da                	sd	s6,80(sp)
    1014:	e4de                	sd	s7,72(sp)
    1016:	e0e2                	sd	s8,64(sp)
    1018:	fc66                	sd	s9,56(sp)
    101a:	f86a                	sd	s10,48(sp)
    101c:	f46e                	sd	s11,40(sp)
	int success = 0;
	for (int i = 0; i < n; ++i) {
    101e:	0eb05c63          	blez	a1,1116 <run_tests+0x114>
    1022:	fff58a1b          	addiw	s4,a1,-1
    1026:	020a1793          	slli	a5,s4,0x20
    102a:	01d7da13          	srli	s4,a5,0x1d
    102e:	00850793          	addi	a5,a0,8
    1032:	84aa                	mv	s1,a0
    1034:	9a3e                	add	s4,s4,a5
	int success = 0;
    1036:	4981                	li	s3,0
    1038:	01c10b93          	addi	s7,sp,28
		const char *test = tests[i];
		printf("Usertests: Running %s\n", test);
    103c:	00002b17          	auipc	s6,0x2
    1040:	83cb0b13          	addi	s6,s6,-1988 # 2878 <enable_deadlock_detect+0xc>
		}
		int xstate = 0;
		int wait_pid = waitpid(pid, &xstate);
		assert_eq(pid, wait_pid);
		success += (xstate == 0);
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1044:	00002a97          	auipc	s5,0x2
    1048:	8d4a8a93          	addi	s5,s5,-1836 # 2918 <enable_deadlock_detect+0xac>
		assert_eq(pid, wait_pid);
    104c:	00002d17          	auipc	s10,0x2
    1050:	844d0d13          	addi	s10,s10,-1980 # 2890 <enable_deadlock_detect+0x24>
    1054:	00002c97          	auipc	s9,0x2
    1058:	884c8c93          	addi	s9,s9,-1916 # 28d8 <enable_deadlock_detect+0x6c>
    105c:	00002c17          	auipc	s8,0x2
    1060:	884c0c13          	addi	s8,s8,-1916 # 28e0 <enable_deadlock_detect+0x74>
		const char *test = tests[i];
    1064:	0004b903          	ld	s2,0(s1)
		printf("Usertests: Running %s\n", test);
    1068:	855a                	mv	a0,s6
    106a:	85ca                	mv	a1,s2
    106c:	300000ef          	jal	ra,136c <printf>
		int pid = fork();
    1070:	552010ef          	jal	ra,25c2 <fork>
    1074:	842a                	mv	s0,a0
		if (pid == 0) {
    1076:	c941                	beqz	a0,1106 <run_tests+0x104>
		int wait_pid = waitpid(pid, &xstate);
    1078:	85de                	mv	a1,s7
    107a:	8522                	mv	a0,s0
		int xstate = 0;
    107c:	ce02                	sw	zero,28(sp)
		int wait_pid = waitpid(pid, &xstate);
    107e:	572010ef          	jal	ra,25f0 <waitpid>
    1082:	8daa                	mv	s11,a0
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1084:	8622                	mv	a2,s0
    1086:	85ca                	mv	a1,s2
    1088:	8556                	mv	a0,s5
		assert_eq(pid, wait_pid);
    108a:	07b40363          	beq	s0,s11,10f0 <run_tests+0xee>
    108e:	510010ef          	jal	ra,259e <getpid>
    1092:	86aa                	mv	a3,a0
    1094:	856a                	mv	a0,s10
    1096:	e436                	sd	a3,8(sp)
    1098:	3dc010ef          	jal	ra,2474 <basename>
    109c:	66a2                	ld	a3,8(sp)
    109e:	872a                	mv	a4,a0
    10a0:	47c5                	li	a5,17
    10a2:	8666                	mv	a2,s9
    10a4:	45fd                	li	a1,31
    10a6:	88ee                	mv	a7,s11
    10a8:	8822                	mv	a6,s0
    10aa:	8562                	mv	a0,s8
    10ac:	2c0000ef          	jal	ra,136c <printf>
    10b0:	557d                	li	a0,-1
    10b2:	51c010ef          	jal	ra,25ce <exit>
		success += (xstate == 0);
    10b6:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10b8:	04a1                	addi	s1,s1,8
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10ba:	8622                	mv	a2,s0
		success += (xstate == 0);
    10bc:	0016b793          	seqz	a5,a3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c0:	85ca                	mv	a1,s2
    10c2:	8556                	mv	a0,s5
		success += (xstate == 0);
    10c4:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c8:	2a4000ef          	jal	ra,136c <printf>
	for (int i = 0; i < n; ++i) {
    10cc:	f89a1ce3          	bne	s4,s1,1064 <run_tests+0x62>
		       test, pid, xstate);
	}
	return success;
}
    10d0:	60aa                	ld	ra,136(sp)
    10d2:	640a                	ld	s0,128(sp)
    10d4:	74e6                	ld	s1,120(sp)
    10d6:	7946                	ld	s2,112(sp)
    10d8:	7a06                	ld	s4,96(sp)
    10da:	6ae6                	ld	s5,88(sp)
    10dc:	6b46                	ld	s6,80(sp)
    10de:	6ba6                	ld	s7,72(sp)
    10e0:	6c06                	ld	s8,64(sp)
    10e2:	7ce2                	ld	s9,56(sp)
    10e4:	7d42                	ld	s10,48(sp)
    10e6:	7da2                	ld	s11,40(sp)
    10e8:	854e                	mv	a0,s3
    10ea:	79a6                	ld	s3,104(sp)
    10ec:	6149                	addi	sp,sp,144
    10ee:	8082                	ret
		success += (xstate == 0);
    10f0:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10f2:	04a1                	addi	s1,s1,8
		success += (xstate == 0);
    10f4:	0016b793          	seqz	a5,a3
    10f8:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10fc:	270000ef          	jal	ra,136c <printf>
	for (int i = 0; i < n; ++i) {
    1100:	f74492e3          	bne	s1,s4,1064 <run_tests+0x62>
    1104:	b7f1                	j	10d0 <run_tests+0xce>
			exec(test, NULL);
    1106:	4581                	li	a1,0
    1108:	854a                	mv	a0,s2
    110a:	4f2010ef          	jal	ra,25fc <exec>
			exit(-1);
    110e:	557d                	li	a0,-1
    1110:	4be010ef          	jal	ra,25ce <exit>
    1114:	b795                	j	1078 <run_tests+0x76>
	int success = 0;
    1116:	4981                	li	s3,0
    1118:	bf65                	j	10d0 <run_tests+0xce>

000000000000111a <test>:

int test(const char *succs[], int nsucc, const char *fails[], int nfail,
	 const char *message)
{
    111a:	7139                	addi	sp,sp,-64
    111c:	f822                	sd	s0,48(sp)
    111e:	f426                	sd	s1,40(sp)
    1120:	ec4e                	sd	s3,24(sp)
    1122:	fc06                	sd	ra,56(sp)
    1124:	f04a                	sd	s2,32(sp)
    1126:	e852                	sd	s4,16(sp)
    1128:	e456                	sd	s5,8(sp)
    112a:	84b2                	mv	s1,a2
    112c:	89b6                	mv	s3,a3
    112e:	843a                	mv	s0,a4
	if (succs && nsucc > 0) {
    1130:	c501                	beqz	a0,1138 <test+0x1e>
    1132:	892e                	mv	s2,a1
    1134:	06b04763          	bgtz	a1,11a2 <test+0x88>
		int succ_count = run_tests(succs, nsucc);
		assert_eq(succ_count, nsucc);
	}
	if (fails && nfail > 0) {
    1138:	c099                	beqz	s1,113e <test+0x24>
    113a:	03304063          	bgtz	s3,115a <test+0x40>
		int fail_count = run_tests(fails, nfail);
		assert_eq(fail_count, 0);
	}
	if (message)
    113e:	c401                	beqz	s0,1146 <test+0x2c>
		puts(message);
    1140:	8522                	mv	a0,s0
    1142:	141000ef          	jal	ra,1a82 <puts>
	return 0;
}
    1146:	70e2                	ld	ra,56(sp)
    1148:	7442                	ld	s0,48(sp)
    114a:	74a2                	ld	s1,40(sp)
    114c:	7902                	ld	s2,32(sp)
    114e:	69e2                	ld	s3,24(sp)
    1150:	6a42                	ld	s4,16(sp)
    1152:	6aa2                	ld	s5,8(sp)
    1154:	4501                	li	a0,0
    1156:	6121                	addi	sp,sp,64
    1158:	8082                	ret
		int fail_count = run_tests(fails, nfail);
    115a:	8526                	mv	a0,s1
    115c:	85ce                	mv	a1,s3
    115e:	ea5ff0ef          	jal	ra,1002 <run_tests>
    1162:	84aa                	mv	s1,a0
		assert_eq(fail_count, 0);
    1164:	dd69                	beqz	a0,113e <test+0x24>
    1166:	438010ef          	jal	ra,259e <getpid>
    116a:	892a                	mv	s2,a0
    116c:	00001517          	auipc	a0,0x1
    1170:	72450513          	addi	a0,a0,1828 # 2890 <enable_deadlock_detect+0x24>
    1174:	300010ef          	jal	ra,2474 <basename>
    1178:	872a                	mv	a4,a0
    117a:	4881                	li	a7,0
    117c:	00001517          	auipc	a0,0x1
    1180:	76450513          	addi	a0,a0,1892 # 28e0 <enable_deadlock_detect+0x74>
    1184:	8826                	mv	a6,s1
    1186:	02200793          	li	a5,34
    118a:	86ca                	mv	a3,s2
    118c:	00001617          	auipc	a2,0x1
    1190:	74c60613          	addi	a2,a2,1868 # 28d8 <enable_deadlock_detect+0x6c>
    1194:	45fd                	li	a1,31
    1196:	1d6000ef          	jal	ra,136c <printf>
    119a:	557d                	li	a0,-1
    119c:	432010ef          	jal	ra,25ce <exit>
    11a0:	bf79                	j	113e <test+0x24>
		int succ_count = run_tests(succs, nsucc);
    11a2:	e61ff0ef          	jal	ra,1002 <run_tests>
    11a6:	8a2a                	mv	s4,a0
		assert_eq(succ_count, nsucc);
    11a8:	f8a908e3          	beq	s2,a0,1138 <test+0x1e>
    11ac:	3f2010ef          	jal	ra,259e <getpid>
    11b0:	8aaa                	mv	s5,a0
    11b2:	00001517          	auipc	a0,0x1
    11b6:	6de50513          	addi	a0,a0,1758 # 2890 <enable_deadlock_detect+0x24>
    11ba:	2ba010ef          	jal	ra,2474 <basename>
    11be:	872a                	mv	a4,a0
    11c0:	88ca                	mv	a7,s2
    11c2:	8852                	mv	a6,s4
    11c4:	00001517          	auipc	a0,0x1
    11c8:	71c50513          	addi	a0,a0,1820 # 28e0 <enable_deadlock_detect+0x74>
    11cc:	47f9                	li	a5,30
    11ce:	86d6                	mv	a3,s5
    11d0:	00001617          	auipc	a2,0x1
    11d4:	70860613          	addi	a2,a2,1800 # 28d8 <enable_deadlock_detect+0x6c>
    11d8:	45fd                	li	a1,31
    11da:	192000ef          	jal	ra,136c <printf>
    11de:	557d                	li	a0,-1
    11e0:	3ee010ef          	jal	ra,25ce <exit>
    11e4:	bf91                	j	1138 <test+0x1e>

00000000000011e6 <main>:
	"ch4_mmap1\0",
	"ch4_mmap2\0",
};

int main()
{
    11e6:	1141                	addi	sp,sp,-16
	int nsucc = sizeof(TESTS) / sizeof(char *);
	int nfail = sizeof(FAILS) / sizeof(char *);
	test(TESTS, nsucc, FAILS, nfail, "ch6 Usertests passed!");
    11e8:	00001717          	auipc	a4,0x1
    11ec:	76870713          	addi	a4,a4,1896 # 2950 <enable_deadlock_detect+0xe4>
    11f0:	4689                	li	a3,2
    11f2:	00002617          	auipc	a2,0x2
    11f6:	b2e60613          	addi	a2,a2,-1234 # 2d20 <FAILS>
    11fa:	45dd                	li	a1,23
    11fc:	00002517          	auipc	a0,0x2
    1200:	b3450513          	addi	a0,a0,-1228 # 2d30 <TESTS>
{
    1204:	e406                	sd	ra,8(sp)
	test(TESTS, nsucc, FAILS, nfail, "ch6 Usertests passed!");
    1206:	f15ff0ef          	jal	ra,111a <test>
	return 0;
}
    120a:	60a2                	ld	ra,8(sp)
    120c:	4501                	li	a0,0
    120e:	0141                	addi	sp,sp,16
    1210:	8082                	ret

0000000000001212 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1212:	1141                	addi	sp,sp,-16
    1214:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1216:	fd1ff0ef          	jal	ra,11e6 <main>
    121a:	3b4010ef          	jal	ra,25ce <exit>
	return 0;
    121e:	60a2                	ld	ra,8(sp)
    1220:	4501                	li	a0,0
    1222:	0141                	addi	sp,sp,16
    1224:	8082                	ret

0000000000001226 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1226:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1228:	4605                	li	a2,1
    122a:	00f10593          	addi	a1,sp,15
    122e:	4501                	li	a0,0
{
    1230:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1232:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1236:	354010ef          	jal	ra,258a <read>
    123a:	4785                	li	a5,1
    123c:	00f51763          	bne	a0,a5,124a <getchar+0x24>
		return byte;
    1240:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1244:	60e2                	ld	ra,24(sp)
    1246:	6105                	addi	sp,sp,32
    1248:	8082                	ret
		return EOF;
    124a:	557d                	li	a0,-1
    124c:	bfe5                	j	1244 <getchar+0x1e>

000000000000124e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    124e:	00002517          	auipc	a0,0x2
    1252:	81252503          	lw	a0,-2030(a0) # 2a60 <buffer_len>
    1256:	e111                	bnez	a0,125a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1258:	8082                	ret
{
    125a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    125c:	862a                	mv	a2,a0
    125e:	00002597          	auipc	a1,0x2
    1262:	80a58593          	addi	a1,a1,-2038 # 2a68 <buffer>
    1266:	4505                	li	a0,1
{
    1268:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    126a:	32a010ef          	jal	ra,2594 <write>
}
    126e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1270:	2501                	sext.w	a0,a0
}
    1272:	0141                	addi	sp,sp,16
    1274:	8082                	ret

0000000000001276 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1276:	00001797          	auipc	a5,0x1
    127a:	7e07a523          	sw	zero,2026(a5) # 2a60 <buffer_len>
}
    127e:	8082                	ret

0000000000001280 <__fflush>:
	if (buffer_len == 0)
    1280:	00001517          	auipc	a0,0x1
    1284:	7e052503          	lw	a0,2016(a0) # 2a60 <buffer_len>
    1288:	e511                	bnez	a0,1294 <__fflush+0x14>
	buffer_len = 0;
    128a:	00001797          	auipc	a5,0x1
    128e:	7c07ab23          	sw	zero,2006(a5) # 2a60 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1292:	8082                	ret
{
    1294:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1296:	862a                	mv	a2,a0
    1298:	00001597          	auipc	a1,0x1
    129c:	7d058593          	addi	a1,a1,2000 # 2a68 <buffer>
    12a0:	4505                	li	a0,1
{
    12a2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12a4:	2f0010ef          	jal	ra,2594 <write>
	return r >= 0 ? 0 : r;
    12a8:	0005079b          	sext.w	a5,a0
}
    12ac:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12ae:	0017a793          	slti	a5,a5,1
    12b2:	40f007bb          	negw	a5,a5
    12b6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    12b8:	00001797          	auipc	a5,0x1
    12bc:	7a07a423          	sw	zero,1960(a5) # 2a60 <buffer_len>
	return r >= 0 ? 0 : r;
    12c0:	2501                	sext.w	a0,a0
}
    12c2:	0141                	addi	sp,sp,16
    12c4:	8082                	ret

00000000000012c6 <fflush>:

int fflush(int fd)
{
    12c6:	1101                	addi	sp,sp,-32
    12c8:	e822                	sd	s0,16(sp)
    12ca:	ec06                	sd	ra,24(sp)
    12cc:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    12ce:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    12d0:	4401                	li	s0,0
	if (fd == 1) {
    12d2:	00e50863          	beq	a0,a4,12e2 <fflush+0x1c>
}
    12d6:	60e2                	ld	ra,24(sp)
    12d8:	8522                	mv	a0,s0
    12da:	6442                	ld	s0,16(sp)
    12dc:	64a2                	ld	s1,8(sp)
    12de:	6105                	addi	sp,sp,32
    12e0:	8082                	ret
		if (buffer_lock_enabled == 1) {
    12e2:	00001497          	auipc	s1,0x1
    12e6:	77e48493          	addi	s1,s1,1918 # 2a60 <buffer_len>
    12ea:	1084a703          	lw	a4,264(s1)
    12ee:	02a70e63          	beq	a4,a0,132a <fflush+0x64>
	if (buffer_len == 0)
    12f2:	4080                	lw	s0,0(s1)
    12f4:	c00d                	beqz	s0,1316 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    12f6:	8622                	mv	a2,s0
    12f8:	00001597          	auipc	a1,0x1
    12fc:	77058593          	addi	a1,a1,1904 # 2a68 <buffer>
    1300:	294010ef          	jal	ra,2594 <write>
	return r >= 0 ? 0 : r;
    1304:	0005079b          	sext.w	a5,a0
    1308:	0017a793          	slti	a5,a5,1
    130c:	40f007bb          	negw	a5,a5
    1310:	8d7d                	and	a0,a0,a5
    1312:	0005041b          	sext.w	s0,a0
}
    1316:	60e2                	ld	ra,24(sp)
    1318:	8522                	mv	a0,s0
    131a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    131c:	00001797          	auipc	a5,0x1
    1320:	7407a223          	sw	zero,1860(a5) # 2a60 <buffer_len>
}
    1324:	64a2                	ld	s1,8(sp)
    1326:	6105                	addi	sp,sp,32
    1328:	8082                	ret
			mutex_lock(buffer_lock);
    132a:	10c4a503          	lw	a0,268(s1)
    132e:	4de010ef          	jal	ra,280c <mutex_lock>
	if (buffer_len == 0)
    1332:	4080                	lw	s0,0(s1)
    1334:	e811                	bnez	s0,1348 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1336:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    133a:	00001797          	auipc	a5,0x1
    133e:	7207a323          	sw	zero,1830(a5) # 2a60 <buffer_len>
			mutex_unlock(buffer_lock);
    1342:	4d6010ef          	jal	ra,2818 <mutex_unlock>
    1346:	bf41                	j	12d6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1348:	8622                	mv	a2,s0
    134a:	00001597          	auipc	a1,0x1
    134e:	71e58593          	addi	a1,a1,1822 # 2a68 <buffer>
    1352:	4505                	li	a0,1
    1354:	240010ef          	jal	ra,2594 <write>
	return r >= 0 ? 0 : r;
    1358:	0005079b          	sext.w	a5,a0
    135c:	0017a793          	slti	a5,a5,1
    1360:	40f007bb          	negw	a5,a5
    1364:	8d7d                	and	a0,a0,a5
    1366:	0005041b          	sext.w	s0,a0
	return r;
    136a:	b7f1                	j	1336 <fflush+0x70>

000000000000136c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    136c:	7131                	addi	sp,sp,-192
    136e:	e0da                	sd	s6,64(sp)
    1370:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1372:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1374:	013c                	addi	a5,sp,136
{
    1376:	f0ca                	sd	s2,96(sp)
    1378:	ecce                	sd	s3,88(sp)
    137a:	e8d2                	sd	s4,80(sp)
    137c:	e4d6                	sd	s5,72(sp)
    137e:	fc86                	sd	ra,120(sp)
    1380:	f8a2                	sd	s0,112(sp)
    1382:	f4a6                	sd	s1,104(sp)
    1384:	89aa                	mv	s3,a0
    1386:	e52e                	sd	a1,136(sp)
    1388:	e932                	sd	a2,144(sp)
    138a:	ed36                	sd	a3,152(sp)
    138c:	f13a                	sd	a4,160(sp)
    138e:	f942                	sd	a6,176(sp)
    1390:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1392:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1394:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1398:	00001a17          	auipc	s4,0x1
    139c:	6c8a0a13          	addi	s4,s4,1736 # 2a60 <buffer_len>
    13a0:	4a85                	li	s5,1
	buf[i++] = '0';
    13a2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13a6:	0009c783          	lbu	a5,0(s3)
    13aa:	18078663          	beqz	a5,1536 <printf+0x1ca>
    13ae:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13b0:	19278d63          	beq	a5,s2,154a <printf+0x1de>
    13b4:	0015c783          	lbu	a5,1(a1)
    13b8:	0585                	addi	a1,a1,1
    13ba:	fbfd                	bnez	a5,13b0 <printf+0x44>
    13bc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    13be:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    13c2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13c6:	1b578863          	beq	a5,s5,1576 <printf+0x20a>
		len = out_unlocked(s, l);
    13ca:	85a2                	mv	a1,s0
    13cc:	854e                	mv	a0,s3
    13ce:	42a000ef          	jal	ra,17f8 <out_unlocked>
		out(f, a, l);
		if (l)
    13d2:	1c041063          	bnez	s0,1592 <printf+0x226>
			continue;
		if (s[1] == 0)
    13d6:	0014c783          	lbu	a5,1(s1)
    13da:	14078e63          	beqz	a5,1536 <printf+0x1ca>
			break;
		switch (s[1]) {
    13de:	07300713          	li	a4,115
    13e2:	1ce78863          	beq	a5,a4,15b2 <printf+0x246>
    13e6:	1af76863          	bltu	a4,a5,1596 <printf+0x22a>
    13ea:	06400713          	li	a4,100
    13ee:	22e78063          	beq	a5,a4,160e <printf+0x2a2>
    13f2:	07000713          	li	a4,112
    13f6:	1ee79563          	bne	a5,a4,15e0 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    13fa:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13fc:	00002797          	auipc	a5,0x2
    1400:	90c78793          	addi	a5,a5,-1780 # 2d08 <digits>
	buf[i++] = '0';
    1404:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1408:	6298                	ld	a4,0(a3)
    140a:	06a1                	addi	a3,a3,8
    140c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    140e:	00471393          	slli	t2,a4,0x4
    1412:	00871293          	slli	t0,a4,0x8
    1416:	00c71f93          	slli	t6,a4,0xc
    141a:	01071f13          	slli	t5,a4,0x10
    141e:	01471e93          	slli	t4,a4,0x14
    1422:	01871e13          	slli	t3,a4,0x18
    1426:	01c71893          	slli	a7,a4,0x1c
    142a:	02471813          	slli	a6,a4,0x24
    142e:	02871513          	slli	a0,a4,0x28
    1432:	02c71593          	slli	a1,a4,0x2c
    1436:	03071613          	slli	a2,a4,0x30
    143a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    143e:	03c75413          	srli	s0,a4,0x3c
    1442:	01c7531b          	srliw	t1,a4,0x1c
    1446:	03c3d393          	srli	t2,t2,0x3c
    144a:	03c2d293          	srli	t0,t0,0x3c
    144e:	03cfdf93          	srli	t6,t6,0x3c
    1452:	03cf5f13          	srli	t5,t5,0x3c
    1456:	03cede93          	srli	t4,t4,0x3c
    145a:	03ce5e13          	srli	t3,t3,0x3c
    145e:	03c8d893          	srli	a7,a7,0x3c
    1462:	03c85813          	srli	a6,a6,0x3c
    1466:	9171                	srli	a0,a0,0x3c
    1468:	91f1                	srli	a1,a1,0x3c
    146a:	9271                	srli	a2,a2,0x3c
    146c:	92f1                	srli	a3,a3,0x3c
    146e:	95be                	add	a1,a1,a5
    1470:	963e                	add	a2,a2,a5
    1472:	96be                	add	a3,a3,a5
    1474:	943e                	add	s0,s0,a5
    1476:	93be                	add	t2,t2,a5
    1478:	92be                	add	t0,t0,a5
    147a:	9fbe                	add	t6,t6,a5
    147c:	9f3e                	add	t5,t5,a5
    147e:	9ebe                	add	t4,t4,a5
    1480:	9e3e                	add	t3,t3,a5
    1482:	98be                	add	a7,a7,a5
    1484:	933e                	add	t1,t1,a5
    1486:	983e                	add	a6,a6,a5
    1488:	953e                	add	a0,a0,a5
    148a:	0005c983          	lbu	s3,0(a1)
    148e:	00044403          	lbu	s0,0(s0)
    1492:	00064583          	lbu	a1,0(a2)
    1496:	0003c383          	lbu	t2,0(t2)
    149a:	0006c603          	lbu	a2,0(a3)
    149e:	0002c283          	lbu	t0,0(t0)
    14a2:	000fcf83          	lbu	t6,0(t6)
    14a6:	000f4f03          	lbu	t5,0(t5)
    14aa:	000ece83          	lbu	t4,0(t4)
    14ae:	000e4e03          	lbu	t3,0(t3)
    14b2:	0008c883          	lbu	a7,0(a7)
    14b6:	00034303          	lbu	t1,0(t1)
    14ba:	00084803          	lbu	a6,0(a6)
    14be:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    14c2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14c6:	92f1                	srli	a3,a3,0x3c
    14c8:	8b3d                	andi	a4,a4,15
    14ca:	96be                	add	a3,a3,a5
    14cc:	97ba                	add	a5,a5,a4
    14ce:	00810d23          	sb	s0,26(sp)
    14d2:	00710da3          	sb	t2,27(sp)
    14d6:	00510e23          	sb	t0,28(sp)
    14da:	01f10ea3          	sb	t6,29(sp)
    14de:	01e10f23          	sb	t5,30(sp)
    14e2:	01d10fa3          	sb	t4,31(sp)
    14e6:	03c10023          	sb	t3,32(sp)
    14ea:	031100a3          	sb	a7,33(sp)
    14ee:	02610123          	sb	t1,34(sp)
    14f2:	030101a3          	sb	a6,35(sp)
    14f6:	02a10223          	sb	a0,36(sp)
    14fa:	033102a3          	sb	s3,37(sp)
    14fe:	02b10323          	sb	a1,38(sp)
    1502:	02c103a3          	sb	a2,39(sp)
    1506:	0006c683          	lbu	a3,0(a3)
    150a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    150e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1512:	02d10423          	sb	a3,40(sp)
    1516:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    151a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    151e:	11578263          	beq	a5,s5,1622 <printf+0x2b6>
		len = out_unlocked(s, l);
    1522:	45c9                	li	a1,18
    1524:	0828                	addi	a0,sp,24
    1526:	2d2000ef          	jal	ra,17f8 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    152a:	00248993          	addi	s3,s1,2
		if (!*s)
    152e:	0009c783          	lbu	a5,0(s3)
    1532:	e6079ee3          	bnez	a5,13ae <printf+0x42>
	}
	va_end(ap);
    1536:	70e6                	ld	ra,120(sp)
    1538:	7446                	ld	s0,112(sp)
    153a:	74a6                	ld	s1,104(sp)
    153c:	7906                	ld	s2,96(sp)
    153e:	69e6                	ld	s3,88(sp)
    1540:	6a46                	ld	s4,80(sp)
    1542:	6aa6                	ld	s5,72(sp)
    1544:	6b06                	ld	s6,64(sp)
    1546:	6129                	addi	sp,sp,192
    1548:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    154a:	0005c783          	lbu	a5,0(a1)
    154e:	84ae                	mv	s1,a1
    1550:	01278963          	beq	a5,s2,1562 <printf+0x1f6>
    1554:	b5ad                	j	13be <printf+0x52>
    1556:	0024c783          	lbu	a5,2(s1)
    155a:	0585                	addi	a1,a1,1
    155c:	0489                	addi	s1,s1,2
    155e:	e72790e3          	bne	a5,s2,13be <printf+0x52>
    1562:	0014c783          	lbu	a5,1(s1)
    1566:	ff2788e3          	beq	a5,s2,1556 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    156a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    156e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1572:	e5579ce3          	bne	a5,s5,13ca <printf+0x5e>
		mutex_lock(buffer_lock);
    1576:	10ca2503          	lw	a0,268(s4)
    157a:	292010ef          	jal	ra,280c <mutex_lock>
		len = out_unlocked(s, l);
    157e:	85a2                	mv	a1,s0
    1580:	854e                	mv	a0,s3
    1582:	276000ef          	jal	ra,17f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1586:	10ca2503          	lw	a0,268(s4)
    158a:	28e010ef          	jal	ra,2818 <mutex_unlock>
		if (l)
    158e:	e40404e3          	beqz	s0,13d6 <printf+0x6a>
    1592:	89a6                	mv	s3,s1
    1594:	bd09                	j	13a6 <printf+0x3a>
		switch (s[1]) {
    1596:	07800713          	li	a4,120
    159a:	04e79363          	bne	a5,a4,15e0 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    159e:	67c2                	ld	a5,16(sp)
    15a0:	45c1                	li	a1,16
		s += 2;
    15a2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15a6:	4388                	lw	a0,0(a5)
    15a8:	07a1                	addi	a5,a5,8
    15aa:	e83e                	sd	a5,16(sp)
    15ac:	5f8000ef          	jal	ra,1ba4 <printint.constprop.0>
		s += 2;
    15b0:	bfbd                	j	152e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    15b2:	67c2                	ld	a5,16(sp)
    15b4:	6380                	ld	s0,0(a5)
    15b6:	07a1                	addi	a5,a5,8
    15b8:	e83e                	sd	a5,16(sp)
    15ba:	1c040163          	beqz	s0,177c <printf+0x410>
			l = strnlen(a, 200);
    15be:	0c800593          	li	a1,200
    15c2:	8522                	mv	a0,s0
    15c4:	3f7000ef          	jal	ra,21ba <strnlen>
	if (buffer_lock_enabled == 1) {
    15c8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    15cc:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    15d0:	19578663          	beq	a5,s5,175c <printf+0x3f0>
		len = out_unlocked(s, l);
    15d4:	8522                	mv	a0,s0
    15d6:	222000ef          	jal	ra,17f8 <out_unlocked>
		s += 2;
    15da:	00248993          	addi	s3,s1,2
    15de:	bf81                	j	152e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    15e0:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15e4:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    15e8:	0f578663          	beq	a5,s5,16d4 <printf+0x368>
		len = out_unlocked(s, l);
    15ec:	0828                	addi	a0,sp,24
    15ee:	316000ef          	jal	ra,1904 <out_unlocked.constprop.0>
			putchar(s[1]);
    15f2:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    15f6:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15fa:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    15fe:	05578163          	beq	a5,s5,1640 <printf+0x2d4>
		len = out_unlocked(s, l);
    1602:	0828                	addi	a0,sp,24
    1604:	300000ef          	jal	ra,1904 <out_unlocked.constprop.0>
		s += 2;
    1608:	00248993          	addi	s3,s1,2
    160c:	b70d                	j	152e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    160e:	67c2                	ld	a5,16(sp)
    1610:	45a9                	li	a1,10
		s += 2;
    1612:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1616:	4388                	lw	a0,0(a5)
    1618:	07a1                	addi	a5,a5,8
    161a:	e83e                	sd	a5,16(sp)
    161c:	588000ef          	jal	ra,1ba4 <printint.constprop.0>
		s += 2;
    1620:	b739                	j	152e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1622:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1626:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    162a:	1e2010ef          	jal	ra,280c <mutex_lock>
		len = out_unlocked(s, l);
    162e:	45c9                	li	a1,18
    1630:	0828                	addi	a0,sp,24
    1632:	1c6000ef          	jal	ra,17f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1636:	10ca2503          	lw	a0,268(s4)
    163a:	1de010ef          	jal	ra,2818 <mutex_unlock>
		s += 2;
    163e:	bdc5                	j	152e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1640:	10ca2503          	lw	a0,268(s4)
    1644:	1c8010ef          	jal	ra,280c <mutex_lock>
		buffer[buffer_len++] = c;
    1648:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    164c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1650:	0017861b          	addiw	a2,a5,1
    1654:	97d2                	add	a5,a5,s4
    1656:	00ca2023          	sw	a2,0(s4)
    165a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    165e:	00c6cc63          	blt	a3,a2,1676 <printf+0x30a>
    1662:	47a9                	li	a5,10
    1664:	06f40663          	beq	s0,a5,16d0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1668:	10ca2503          	lw	a0,268(s4)
		s += 2;
    166c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1670:	1a8010ef          	jal	ra,2818 <mutex_unlock>
		s += 2;
    1674:	bd6d                	j	152e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1676:	10000793          	li	a5,256
    167a:	00f61e63          	bne	a2,a5,1696 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    167e:	00001597          	auipc	a1,0x1
    1682:	3ea58593          	addi	a1,a1,1002 # 2a68 <buffer>
    1686:	4505                	li	a0,1
    1688:	70d000ef          	jal	ra,2594 <write>
	buffer_len = 0;
    168c:	00001797          	auipc	a5,0x1
    1690:	3c07aa23          	sw	zero,980(a5) # 2a60 <buffer_len>
			if (r < 0) {
    1694:	bfd1                	j	1668 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1696:	709000ef          	jal	ra,259e <getpid>
    169a:	842a                	mv	s0,a0
    169c:	00001517          	auipc	a0,0x1
    16a0:	2d450513          	addi	a0,a0,724 # 2970 <enable_deadlock_detect+0x104>
    16a4:	5d1000ef          	jal	ra,2474 <basename>
    16a8:	872a                	mv	a4,a0
    16aa:	00001617          	auipc	a2,0x1
    16ae:	22e60613          	addi	a2,a2,558 # 28d8 <enable_deadlock_detect+0x6c>
    16b2:	05400793          	li	a5,84
    16b6:	86a2                	mv	a3,s0
    16b8:	45fd                	li	a1,31
    16ba:	00001517          	auipc	a0,0x1
    16be:	2f650513          	addi	a0,a0,758 # 29b0 <enable_deadlock_detect+0x144>
    16c2:	cabff0ef          	jal	ra,136c <printf>
    16c6:	557d                	li	a0,-1
    16c8:	707000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    16cc:	000a2603          	lw	a2,0(s4)
    16d0:	de41                	beqz	a2,1668 <printf+0x2fc>
    16d2:	b775                	j	167e <printf+0x312>
		mutex_lock(buffer_lock);
    16d4:	10ca2503          	lw	a0,268(s4)
    16d8:	134010ef          	jal	ra,280c <mutex_lock>
		buffer[buffer_len++] = c;
    16dc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16e0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16e4:	0017861b          	addiw	a2,a5,1
    16e8:	97d2                	add	a5,a5,s4
    16ea:	00ca2023          	sw	a2,0(s4)
    16ee:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16f2:	02c6d163          	bge	a3,a2,1714 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    16f6:	10000793          	li	a5,256
    16fa:	02f61263          	bne	a2,a5,171e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    16fe:	00001597          	auipc	a1,0x1
    1702:	36a58593          	addi	a1,a1,874 # 2a68 <buffer>
    1706:	4505                	li	a0,1
    1708:	68d000ef          	jal	ra,2594 <write>
	buffer_len = 0;
    170c:	00001797          	auipc	a5,0x1
    1710:	3407aa23          	sw	zero,852(a5) # 2a60 <buffer_len>
		mutex_unlock(buffer_lock);
    1714:	10ca2503          	lw	a0,268(s4)
    1718:	100010ef          	jal	ra,2818 <mutex_unlock>
    171c:	bdd9                	j	15f2 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    171e:	681000ef          	jal	ra,259e <getpid>
    1722:	842a                	mv	s0,a0
    1724:	00001517          	auipc	a0,0x1
    1728:	24c50513          	addi	a0,a0,588 # 2970 <enable_deadlock_detect+0x104>
    172c:	549000ef          	jal	ra,2474 <basename>
    1730:	872a                	mv	a4,a0
    1732:	00001617          	auipc	a2,0x1
    1736:	1a660613          	addi	a2,a2,422 # 28d8 <enable_deadlock_detect+0x6c>
    173a:	05400793          	li	a5,84
    173e:	86a2                	mv	a3,s0
    1740:	45fd                	li	a1,31
    1742:	00001517          	auipc	a0,0x1
    1746:	26e50513          	addi	a0,a0,622 # 29b0 <enable_deadlock_detect+0x144>
    174a:	c23ff0ef          	jal	ra,136c <printf>
    174e:	557d                	li	a0,-1
    1750:	67f000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    1754:	000a2603          	lw	a2,0(s4)
    1758:	de55                	beqz	a2,1714 <printf+0x3a8>
    175a:	b755                	j	16fe <printf+0x392>
		mutex_lock(buffer_lock);
    175c:	10ca2503          	lw	a0,268(s4)
    1760:	e42e                	sd	a1,8(sp)
		s += 2;
    1762:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1766:	0a6010ef          	jal	ra,280c <mutex_lock>
		len = out_unlocked(s, l);
    176a:	65a2                	ld	a1,8(sp)
    176c:	8522                	mv	a0,s0
    176e:	08a000ef          	jal	ra,17f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1772:	10ca2503          	lw	a0,268(s4)
    1776:	0a2010ef          	jal	ra,2818 <mutex_unlock>
		s += 2;
    177a:	bb55                	j	152e <printf+0x1c2>
				a = "(null)";
    177c:	00001417          	auipc	s0,0x1
    1780:	1ec40413          	addi	s0,s0,492 # 2968 <enable_deadlock_detect+0xfc>
    1784:	bd2d                	j	15be <printf+0x252>

0000000000001786 <enable_thread_io_buffer>:
{
    1786:	1101                	addi	sp,sp,-32
    1788:	e822                	sd	s0,16(sp)
    178a:	ec06                	sd	ra,24(sp)
    178c:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    178e:	00001417          	auipc	s0,0x1
    1792:	2d240413          	addi	s0,s0,722 # 2a60 <buffer_len>
    1796:	05a010ef          	jal	ra,27f0 <mutex_create>
    179a:	10a42623          	sw	a0,268(s0)
    179e:	00054a63          	bltz	a0,17b2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17a2:	4785                	li	a5,1
}
    17a4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17a6:	10f42423          	sw	a5,264(s0)
}
    17aa:	6442                	ld	s0,16(sp)
    17ac:	64a2                	ld	s1,8(sp)
    17ae:	6105                	addi	sp,sp,32
    17b0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    17b2:	5ed000ef          	jal	ra,259e <getpid>
    17b6:	84aa                	mv	s1,a0
    17b8:	00001517          	auipc	a0,0x1
    17bc:	1b850513          	addi	a0,a0,440 # 2970 <enable_deadlock_detect+0x104>
    17c0:	4b5000ef          	jal	ra,2474 <basename>
    17c4:	872a                	mv	a4,a0
    17c6:	04800793          	li	a5,72
    17ca:	86a6                	mv	a3,s1
    17cc:	00001517          	auipc	a0,0x1
    17d0:	22450513          	addi	a0,a0,548 # 29f0 <enable_deadlock_detect+0x184>
    17d4:	00001617          	auipc	a2,0x1
    17d8:	10460613          	addi	a2,a2,260 # 28d8 <enable_deadlock_detect+0x6c>
    17dc:	45fd                	li	a1,31
    17de:	b8fff0ef          	jal	ra,136c <printf>
    17e2:	557d                	li	a0,-1
    17e4:	5eb000ef          	jal	ra,25ce <exit>
	buffer_lock_enabled = 1;
    17e8:	4785                	li	a5,1
}
    17ea:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17ec:	10f42423          	sw	a5,264(s0)
}
    17f0:	6442                	ld	s0,16(sp)
    17f2:	64a2                	ld	s1,8(sp)
    17f4:	6105                	addi	sp,sp,32
    17f6:	8082                	ret

00000000000017f8 <out_unlocked>:
{
    17f8:	7159                	addi	sp,sp,-112
    17fa:	f486                	sd	ra,104(sp)
    17fc:	f0a2                	sd	s0,96(sp)
    17fe:	eca6                	sd	s1,88(sp)
    1800:	e8ca                	sd	s2,80(sp)
    1802:	e4ce                	sd	s3,72(sp)
    1804:	e0d2                	sd	s4,64(sp)
    1806:	fc56                	sd	s5,56(sp)
    1808:	f85a                	sd	s6,48(sp)
    180a:	f45e                	sd	s7,40(sp)
    180c:	f062                	sd	s8,32(sp)
    180e:	ec66                	sd	s9,24(sp)
    1810:	e86a                	sd	s10,16(sp)
    1812:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1814:	0e058663          	beqz	a1,1900 <out_unlocked+0x108>
    1818:	842a                	mv	s0,a0
    181a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    181e:	4981                	li	s3,0
    1820:	00001d17          	auipc	s10,0x1
    1824:	240d0d13          	addi	s10,s10,576 # 2a60 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1828:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    182c:	00001b17          	auipc	s6,0x1
    1830:	23cb0b13          	addi	s6,s6,572 # 2a68 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1834:	10000a93          	li	s5,256
    1838:	00001c97          	auipc	s9,0x1
    183c:	138c8c93          	addi	s9,s9,312 # 2970 <enable_deadlock_detect+0x104>
    1840:	00001c17          	auipc	s8,0x1
    1844:	098c0c13          	addi	s8,s8,152 # 28d8 <enable_deadlock_detect+0x6c>
    1848:	00001b97          	auipc	s7,0x1
    184c:	168b8b93          	addi	s7,s7,360 # 29b0 <enable_deadlock_detect+0x144>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1850:	4a29                	li	s4,10
    1852:	a031                	j	185e <out_unlocked+0x66>
    1854:	09468863          	beq	a3,s4,18e4 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1858:	0405                	addi	s0,s0,1
    185a:	04848163          	beq	s1,s0,189c <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    185e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1862:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1866:	0017861b          	addiw	a2,a5,1
    186a:	97ea                	add	a5,a5,s10
    186c:	00cd2023          	sw	a2,0(s10)
    1870:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1874:	fec950e3          	bge	s2,a2,1854 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1878:	05561263          	bne	a2,s5,18bc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    187c:	85da                	mv	a1,s6
    187e:	4505                	li	a0,1
    1880:	515000ef          	jal	ra,2594 <write>
    1884:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1886:	00001797          	auipc	a5,0x1
    188a:	1c07ad23          	sw	zero,474(a5) # 2a60 <buffer_len>
			if (r < 0) {
    188e:	06054763          	bltz	a0,18fc <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1892:	0405                	addi	s0,s0,1
			ret += r;
    1894:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1898:	fc8493e3          	bne	s1,s0,185e <out_unlocked+0x66>
}
    189c:	70a6                	ld	ra,104(sp)
    189e:	7406                	ld	s0,96(sp)
    18a0:	64e6                	ld	s1,88(sp)
    18a2:	6946                	ld	s2,80(sp)
    18a4:	6a06                	ld	s4,64(sp)
    18a6:	7ae2                	ld	s5,56(sp)
    18a8:	7b42                	ld	s6,48(sp)
    18aa:	7ba2                	ld	s7,40(sp)
    18ac:	7c02                	ld	s8,32(sp)
    18ae:	6ce2                	ld	s9,24(sp)
    18b0:	6d42                	ld	s10,16(sp)
    18b2:	6da2                	ld	s11,8(sp)
    18b4:	854e                	mv	a0,s3
    18b6:	69a6                	ld	s3,72(sp)
    18b8:	6165                	addi	sp,sp,112
    18ba:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18bc:	4e3000ef          	jal	ra,259e <getpid>
    18c0:	8daa                	mv	s11,a0
    18c2:	8566                	mv	a0,s9
    18c4:	3b1000ef          	jal	ra,2474 <basename>
    18c8:	872a                	mv	a4,a0
    18ca:	8662                	mv	a2,s8
    18cc:	05400793          	li	a5,84
    18d0:	86ee                	mv	a3,s11
    18d2:	45fd                	li	a1,31
    18d4:	855e                	mv	a0,s7
    18d6:	a97ff0ef          	jal	ra,136c <printf>
    18da:	557d                	li	a0,-1
    18dc:	4f3000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    18e0:	000d2603          	lw	a2,0(s10)
    18e4:	da35                	beqz	a2,1858 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    18e6:	85da                	mv	a1,s6
    18e8:	4505                	li	a0,1
    18ea:	4ab000ef          	jal	ra,2594 <write>
    18ee:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18f0:	00001797          	auipc	a5,0x1
    18f4:	1607a823          	sw	zero,368(a5) # 2a60 <buffer_len>
			if (r < 0) {
    18f8:	f8055de3          	bgez	a0,1892 <out_unlocked+0x9a>
    18fc:	89aa                	mv	s3,a0
    18fe:	bf79                	j	189c <out_unlocked+0xa4>
	int ret = 0;
    1900:	4981                	li	s3,0
    1902:	bf69                	j	189c <out_unlocked+0xa4>

0000000000001904 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1904:	1101                	addi	sp,sp,-32
    1906:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1908:	00001497          	auipc	s1,0x1
    190c:	15848493          	addi	s1,s1,344 # 2a60 <buffer_len>
    1910:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1912:	ec06                	sd	ra,24(sp)
    1914:	e822                	sd	s0,16(sp)
		char c = s[i];
    1916:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    191a:	0017861b          	addiw	a2,a5,1
    191e:	97a6                	add	a5,a5,s1
    1920:	00e78423          	sb	a4,8(a5)
    1924:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1926:	0ff00793          	li	a5,255
    192a:	00c7cc63          	blt	a5,a2,1942 <out_unlocked.constprop.0+0x3e>
    192e:	47a9                	li	a5,10
    1930:	06f70c63          	beq	a4,a5,19a8 <out_unlocked.constprop.0+0xa4>
    1934:	4601                	li	a2,0
}
    1936:	60e2                	ld	ra,24(sp)
    1938:	6442                	ld	s0,16(sp)
    193a:	64a2                	ld	s1,8(sp)
    193c:	8532                	mv	a0,a2
    193e:	6105                	addi	sp,sp,32
    1940:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1942:	10000793          	li	a5,256
    1946:	02f61563          	bne	a2,a5,1970 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    194a:	00001597          	auipc	a1,0x1
    194e:	11e58593          	addi	a1,a1,286 # 2a68 <buffer>
    1952:	4505                	li	a0,1
    1954:	441000ef          	jal	ra,2594 <write>
}
    1958:	60e2                	ld	ra,24(sp)
    195a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    195c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1960:	00001797          	auipc	a5,0x1
    1964:	1007a023          	sw	zero,256(a5) # 2a60 <buffer_len>
}
    1968:	64a2                	ld	s1,8(sp)
    196a:	8532                	mv	a0,a2
    196c:	6105                	addi	sp,sp,32
    196e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1970:	42f000ef          	jal	ra,259e <getpid>
    1974:	842a                	mv	s0,a0
    1976:	00001517          	auipc	a0,0x1
    197a:	ffa50513          	addi	a0,a0,-6 # 2970 <enable_deadlock_detect+0x104>
    197e:	2f7000ef          	jal	ra,2474 <basename>
    1982:	872a                	mv	a4,a0
    1984:	00001617          	auipc	a2,0x1
    1988:	f5460613          	addi	a2,a2,-172 # 28d8 <enable_deadlock_detect+0x6c>
    198c:	05400793          	li	a5,84
    1990:	86a2                	mv	a3,s0
    1992:	45fd                	li	a1,31
    1994:	00001517          	auipc	a0,0x1
    1998:	01c50513          	addi	a0,a0,28 # 29b0 <enable_deadlock_detect+0x144>
    199c:	9d1ff0ef          	jal	ra,136c <printf>
    19a0:	557d                	li	a0,-1
    19a2:	42d000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    19a6:	4090                	lw	a2,0(s1)
    19a8:	d659                	beqz	a2,1936 <out_unlocked.constprop.0+0x32>
    19aa:	b745                	j	194a <out_unlocked.constprop.0+0x46>

00000000000019ac <putchar>:
{
    19ac:	7139                	addi	sp,sp,-64
    19ae:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19b0:	00001497          	auipc	s1,0x1
    19b4:	0b048493          	addi	s1,s1,176 # 2a60 <buffer_len>
    19b8:	1084a703          	lw	a4,264(s1)
{
    19bc:	f822                	sd	s0,48(sp)
	char byte = c;
    19be:	0ff57413          	zext.b	s0,a0
{
    19c2:	fc06                	sd	ra,56(sp)
	char byte = c;
    19c4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    19c8:	4785                	li	a5,1
    19ca:	00f70d63          	beq	a4,a5,19e4 <putchar+0x38>
		len = out_unlocked(s, l);
    19ce:	01f10513          	addi	a0,sp,31
    19d2:	f33ff0ef          	jal	ra,1904 <out_unlocked.constprop.0>
}
    19d6:	70e2                	ld	ra,56(sp)
    19d8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    19da:	862a                	mv	a2,a0
}
    19dc:	74a2                	ld	s1,40(sp)
    19de:	8532                	mv	a0,a2
    19e0:	6121                	addi	sp,sp,64
    19e2:	8082                	ret
		mutex_lock(buffer_lock);
    19e4:	10c4a503          	lw	a0,268(s1)
    19e8:	625000ef          	jal	ra,280c <mutex_lock>
		buffer[buffer_len++] = c;
    19ec:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19ee:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19f2:	0017861b          	addiw	a2,a5,1
    19f6:	97a6                	add	a5,a5,s1
    19f8:	c090                	sw	a2,0(s1)
    19fa:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19fe:	02c6c263          	blt	a3,a2,1a22 <putchar+0x76>
    1a02:	47a9                	li	a5,10
    1a04:	06f40d63          	beq	s0,a5,1a7e <putchar+0xd2>
    1a08:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a0a:	10c4a503          	lw	a0,268(s1)
    1a0e:	e432                	sd	a2,8(sp)
    1a10:	609000ef          	jal	ra,2818 <mutex_unlock>
    1a14:	6622                	ld	a2,8(sp)
}
    1a16:	70e2                	ld	ra,56(sp)
    1a18:	7442                	ld	s0,48(sp)
    1a1a:	74a2                	ld	s1,40(sp)
    1a1c:	8532                	mv	a0,a2
    1a1e:	6121                	addi	sp,sp,64
    1a20:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a22:	10000793          	li	a5,256
    1a26:	02f61063          	bne	a2,a5,1a46 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a2a:	00001597          	auipc	a1,0x1
    1a2e:	03e58593          	addi	a1,a1,62 # 2a68 <buffer>
    1a32:	4505                	li	a0,1
    1a34:	361000ef          	jal	ra,2594 <write>
    1a38:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a3c:	00001797          	auipc	a5,0x1
    1a40:	0207a223          	sw	zero,36(a5) # 2a60 <buffer_len>
			if (r < 0) {
    1a44:	b7d9                	j	1a0a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a46:	359000ef          	jal	ra,259e <getpid>
    1a4a:	842a                	mv	s0,a0
    1a4c:	00001517          	auipc	a0,0x1
    1a50:	f2450513          	addi	a0,a0,-220 # 2970 <enable_deadlock_detect+0x104>
    1a54:	221000ef          	jal	ra,2474 <basename>
    1a58:	872a                	mv	a4,a0
    1a5a:	00001617          	auipc	a2,0x1
    1a5e:	e7e60613          	addi	a2,a2,-386 # 28d8 <enable_deadlock_detect+0x6c>
    1a62:	05400793          	li	a5,84
    1a66:	86a2                	mv	a3,s0
    1a68:	45fd                	li	a1,31
    1a6a:	00001517          	auipc	a0,0x1
    1a6e:	f4650513          	addi	a0,a0,-186 # 29b0 <enable_deadlock_detect+0x144>
    1a72:	8fbff0ef          	jal	ra,136c <printf>
    1a76:	557d                	li	a0,-1
    1a78:	357000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    1a7c:	4090                	lw	a2,0(s1)
    1a7e:	d651                	beqz	a2,1a0a <putchar+0x5e>
    1a80:	b76d                	j	1a2a <putchar+0x7e>

0000000000001a82 <puts>:
{
    1a82:	7139                	addi	sp,sp,-64
    1a84:	f822                	sd	s0,48(sp)
    1a86:	f426                	sd	s1,40(sp)
    1a88:	fc06                	sd	ra,56(sp)
    1a8a:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a8c:	00001417          	auipc	s0,0x1
    1a90:	fd440413          	addi	s0,s0,-44 # 2a60 <buffer_len>
{
    1a94:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a96:	638000ef          	jal	ra,20ce <strlen>
	if (buffer_lock_enabled == 1) {
    1a9a:	10842703          	lw	a4,264(s0)
    1a9e:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aa0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1aa2:	04f70563          	beq	a4,a5,1aec <puts+0x6a>
		len = out_unlocked(s, l);
    1aa6:	8526                	mv	a0,s1
    1aa8:	d51ff0ef          	jal	ra,17f8 <out_unlocked>
    1aac:	892a                	mv	s2,a0
    1aae:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ab0:	00095963          	bgez	s2,1ac2 <puts+0x40>
}
    1ab4:	70e2                	ld	ra,56(sp)
    1ab6:	7442                	ld	s0,48(sp)
    1ab8:	7902                	ld	s2,32(sp)
    1aba:	8526                	mv	a0,s1
    1abc:	74a2                	ld	s1,40(sp)
    1abe:	6121                	addi	sp,sp,64
    1ac0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1ac2:	10842703          	lw	a4,264(s0)
	char byte = c;
    1ac6:	44a9                	li	s1,10
    1ac8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1acc:	4785                	li	a5,1
    1ace:	02f70e63          	beq	a4,a5,1b0a <puts+0x88>
		len = out_unlocked(s, l);
    1ad2:	01f10513          	addi	a0,sp,31
    1ad6:	e2fff0ef          	jal	ra,1904 <out_unlocked.constprop.0>
}
    1ada:	70e2                	ld	ra,56(sp)
    1adc:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ade:	41f5549b          	sraiw	s1,a0,0x1f
}
    1ae2:	7902                	ld	s2,32(sp)
    1ae4:	8526                	mv	a0,s1
    1ae6:	74a2                	ld	s1,40(sp)
    1ae8:	6121                	addi	sp,sp,64
    1aea:	8082                	ret
		mutex_lock(buffer_lock);
    1aec:	e42a                	sd	a0,8(sp)
    1aee:	10c42503          	lw	a0,268(s0)
    1af2:	51b000ef          	jal	ra,280c <mutex_lock>
		len = out_unlocked(s, l);
    1af6:	65a2                	ld	a1,8(sp)
    1af8:	8526                	mv	a0,s1
    1afa:	cffff0ef          	jal	ra,17f8 <out_unlocked>
    1afe:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b00:	10c42503          	lw	a0,268(s0)
    1b04:	515000ef          	jal	ra,2818 <mutex_unlock>
    1b08:	b75d                	j	1aae <puts+0x2c>
		mutex_lock(buffer_lock);
    1b0a:	10c42503          	lw	a0,268(s0)
    1b0e:	4ff000ef          	jal	ra,280c <mutex_lock>
		buffer[buffer_len++] = c;
    1b12:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b14:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b18:	0017861b          	addiw	a2,a5,1
    1b1c:	97a2                	add	a5,a5,s0
    1b1e:	c010                	sw	a2,0(s0)
    1b20:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b24:	06c6dc63          	bge	a3,a2,1b9c <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b28:	10000793          	li	a5,256
    1b2c:	02f61c63          	bne	a2,a5,1b64 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b30:	00001597          	auipc	a1,0x1
    1b34:	f3858593          	addi	a1,a1,-200 # 2a68 <buffer>
    1b38:	4505                	li	a0,1
    1b3a:	25b000ef          	jal	ra,2594 <write>
			if (r < 0) {
    1b3e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b40:	00001797          	auipc	a5,0x1
    1b44:	f207a023          	sw	zero,-224(a5) # 2a60 <buffer_len>
			if (r < 0) {
    1b48:	04054c63          	bltz	a0,1ba0 <puts+0x11e>
			if (r < buffer_len) {
    1b4c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b4e:	10c42503          	lw	a0,268(s0)
    1b52:	4c7000ef          	jal	ra,2818 <mutex_unlock>
}
    1b56:	70e2                	ld	ra,56(sp)
    1b58:	7442                	ld	s0,48(sp)
    1b5a:	7902                	ld	s2,32(sp)
    1b5c:	8526                	mv	a0,s1
    1b5e:	74a2                	ld	s1,40(sp)
    1b60:	6121                	addi	sp,sp,64
    1b62:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b64:	23b000ef          	jal	ra,259e <getpid>
    1b68:	84aa                	mv	s1,a0
    1b6a:	00001517          	auipc	a0,0x1
    1b6e:	e0650513          	addi	a0,a0,-506 # 2970 <enable_deadlock_detect+0x104>
    1b72:	103000ef          	jal	ra,2474 <basename>
    1b76:	872a                	mv	a4,a0
    1b78:	00001617          	auipc	a2,0x1
    1b7c:	d6060613          	addi	a2,a2,-672 # 28d8 <enable_deadlock_detect+0x6c>
    1b80:	05400793          	li	a5,84
    1b84:	86a6                	mv	a3,s1
    1b86:	45fd                	li	a1,31
    1b88:	00001517          	auipc	a0,0x1
    1b8c:	e2850513          	addi	a0,a0,-472 # 29b0 <enable_deadlock_detect+0x144>
    1b90:	fdcff0ef          	jal	ra,136c <printf>
    1b94:	557d                	li	a0,-1
    1b96:	239000ef          	jal	ra,25ce <exit>
	if (buffer_len == 0)
    1b9a:	4010                	lw	a2,0(s0)
    1b9c:	da45                	beqz	a2,1b4c <puts+0xca>
    1b9e:	bf49                	j	1b30 <puts+0xae>
    1ba0:	54fd                	li	s1,-1
    1ba2:	b775                	j	1b4e <puts+0xcc>

0000000000001ba4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ba4:	715d                	addi	sp,sp,-80
    1ba6:	e486                	sd	ra,72(sp)
    1ba8:	e0a2                	sd	s0,64(sp)
    1baa:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1bac:	14054363          	bltz	a0,1cf2 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bb0:	02b577bb          	remuw	a5,a0,a1
    1bb4:	00001617          	auipc	a2,0x1
    1bb8:	15460613          	addi	a2,a2,340 # 2d08 <digits>
	buf[16] = 0;
    1bbc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bc0:	0005871b          	sext.w	a4,a1
    1bc4:	1782                	slli	a5,a5,0x20
    1bc6:	9381                	srli	a5,a5,0x20
    1bc8:	97b2                	add	a5,a5,a2
    1bca:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bce:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1bd2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1bd6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1bd8:	0eb56763          	bltu	a0,a1,1cc6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bdc:	02e877bb          	remuw	a5,a6,a4
    1be0:	1782                	slli	a5,a5,0x20
    1be2:	9381                	srli	a5,a5,0x20
    1be4:	97b2                	add	a5,a5,a2
    1be6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bea:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1bee:	02f10323          	sb	a5,38(sp)
    1bf2:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1bf4:	0ce86963          	bltu	a6,a4,1cc6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bf8:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1bfc:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c00:	1582                	slli	a1,a1,0x20
    1c02:	9181                	srli	a1,a1,0x20
    1c04:	95b2                	add	a1,a1,a2
    1c06:	0005c583          	lbu	a1,0(a1)
    1c0a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c0e:	0007859b          	sext.w	a1,a5
    1c12:	16e6e563          	bltu	a3,a4,1d7c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c16:	02e7f6bb          	remuw	a3,a5,a4
    1c1a:	1682                	slli	a3,a3,0x20
    1c1c:	9281                	srli	a3,a3,0x20
    1c1e:	96b2                	add	a3,a3,a2
    1c20:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c24:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c28:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c2c:	16e5e163          	bltu	a1,a4,1d8e <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c30:	02e876bb          	remuw	a3,a6,a4
    1c34:	1682                	slli	a3,a3,0x20
    1c36:	9281                	srli	a3,a3,0x20
    1c38:	96b2                	add	a3,a3,a2
    1c3a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c3e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c42:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c46:	14e86d63          	bltu	a6,a4,1da0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c4a:	02e5f6bb          	remuw	a3,a1,a4
    1c4e:	1682                	slli	a3,a3,0x20
    1c50:	9281                	srli	a3,a3,0x20
    1c52:	96b2                	add	a3,a3,a2
    1c54:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c58:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c5c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1c60:	10e5e563          	bltu	a1,a4,1d6a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1c64:	02e876bb          	remuw	a3,a6,a4
    1c68:	1682                	slli	a3,a3,0x20
    1c6a:	9281                	srli	a3,a3,0x20
    1c6c:	96b2                	add	a3,a3,a2
    1c6e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c72:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c76:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c7a:	14e86263          	bltu	a6,a4,1dbe <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c7e:	02e5f6bb          	remuw	a3,a1,a4
    1c82:	1682                	slli	a3,a3,0x20
    1c84:	9281                	srli	a3,a3,0x20
    1c86:	96b2                	add	a3,a3,a2
    1c88:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c8c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c90:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c94:	14e5e463          	bltu	a1,a4,1ddc <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1c98:	02e876bb          	remuw	a3,a6,a4
    1c9c:	1682                	slli	a3,a3,0x20
    1c9e:	9281                	srli	a3,a3,0x20
    1ca0:	96b2                	add	a3,a3,a2
    1ca2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ca6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1caa:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cae:	14e86063          	bltu	a6,a4,1dee <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1cb2:	1782                	slli	a5,a5,0x20
    1cb4:	9381                	srli	a5,a5,0x20
    1cb6:	97b2                	add	a5,a5,a2
    1cb8:	0007c703          	lbu	a4,0(a5)
    1cbc:	4799                	li	a5,6
    1cbe:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1cc2:	10054763          	bltz	a0,1dd0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1cc6:	00001497          	auipc	s1,0x1
    1cca:	d9a48493          	addi	s1,s1,-614 # 2a60 <buffer_len>
    1cce:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1cd2:	0828                	addi	a0,sp,24
    1cd4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1cd6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1cd8:	00f50433          	add	s0,a0,a5
    1cdc:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1cde:	06e68463          	beq	a3,a4,1d46 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1ce2:	8522                	mv	a0,s0
    1ce4:	b15ff0ef          	jal	ra,17f8 <out_unlocked>
}
    1ce8:	60a6                	ld	ra,72(sp)
    1cea:	6406                	ld	s0,64(sp)
    1cec:	74e2                	ld	s1,56(sp)
    1cee:	6161                	addi	sp,sp,80
    1cf0:	8082                	ret
		x = -xx;
    1cf2:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1cf6:	02b877bb          	remuw	a5,a6,a1
    1cfa:	00001617          	auipc	a2,0x1
    1cfe:	00e60613          	addi	a2,a2,14 # 2d08 <digits>
	buf[16] = 0;
    1d02:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d06:	0005871b          	sext.w	a4,a1
    1d0a:	1782                	slli	a5,a5,0x20
    1d0c:	9381                	srli	a5,a5,0x20
    1d0e:	97b2                	add	a5,a5,a2
    1d10:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d14:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d18:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d1c:	08b86b63          	bltu	a6,a1,1db2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d20:	02e8f7bb          	remuw	a5,a7,a4
    1d24:	1782                	slli	a5,a5,0x20
    1d26:	9381                	srli	a5,a5,0x20
    1d28:	97b2                	add	a5,a5,a2
    1d2a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d2e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d32:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d36:	ece8f1e3          	bgeu	a7,a4,1bf8 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d3a:	02d00793          	li	a5,45
    1d3e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d42:	47b5                	li	a5,13
    1d44:	b749                	j	1cc6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d46:	10c4a503          	lw	a0,268(s1)
    1d4a:	e42e                	sd	a1,8(sp)
    1d4c:	2c1000ef          	jal	ra,280c <mutex_lock>
		len = out_unlocked(s, l);
    1d50:	65a2                	ld	a1,8(sp)
    1d52:	8522                	mv	a0,s0
    1d54:	aa5ff0ef          	jal	ra,17f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1d58:	10c4a503          	lw	a0,268(s1)
    1d5c:	2bd000ef          	jal	ra,2818 <mutex_unlock>
}
    1d60:	60a6                	ld	ra,72(sp)
    1d62:	6406                	ld	s0,64(sp)
    1d64:	74e2                	ld	s1,56(sp)
    1d66:	6161                	addi	sp,sp,80
    1d68:	8082                	ret
		buf[i--] = digits[x % base];
    1d6a:	47a9                	li	a5,10
	if (sign)
    1d6c:	f4055de3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d70:	02d00793          	li	a5,45
    1d74:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d78:	47a5                	li	a5,9
    1d7a:	b7b1                	j	1cc6 <printint.constprop.0+0x122>
    1d7c:	47b5                	li	a5,13
	if (sign)
    1d7e:	f40554e3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d82:	02d00793          	li	a5,45
    1d86:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d8a:	47b1                	li	a5,12
    1d8c:	bf2d                	j	1cc6 <printint.constprop.0+0x122>
    1d8e:	47b1                	li	a5,12
	if (sign)
    1d90:	f2055be3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d94:	02d00793          	li	a5,45
    1d98:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d9c:	47ad                	li	a5,11
    1d9e:	b725                	j	1cc6 <printint.constprop.0+0x122>
    1da0:	47ad                	li	a5,11
	if (sign)
    1da2:	f20552e3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1da6:	02d00793          	li	a5,45
    1daa:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1dae:	47a9                	li	a5,10
    1db0:	bf19                	j	1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1db2:	02d00793          	li	a5,45
    1db6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1dba:	47b9                	li	a5,14
    1dbc:	b729                	j	1cc6 <printint.constprop.0+0x122>
    1dbe:	47a5                	li	a5,9
	if (sign)
    1dc0:	f00553e3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dc4:	02d00793          	li	a5,45
    1dc8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1dcc:	47a1                	li	a5,8
    1dce:	bde5                	j	1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dd0:	02d00793          	li	a5,45
    1dd4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1dd8:	4795                	li	a5,5
    1dda:	b5f5                	j	1cc6 <printint.constprop.0+0x122>
    1ddc:	47a1                	li	a5,8
	if (sign)
    1dde:	ee0554e3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de2:	02d00793          	li	a5,45
    1de6:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1dea:	479d                	li	a5,7
    1dec:	bde9                	j	1cc6 <printint.constprop.0+0x122>
    1dee:	479d                	li	a5,7
	if (sign)
    1df0:	ec055be3          	bgez	a0,1cc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1df4:	02d00793          	li	a5,45
    1df8:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1dfc:	4799                	li	a5,6
    1dfe:	b5e1                	j	1cc6 <printint.constprop.0+0x122>

0000000000001e00 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e00:	02000793          	li	a5,32
    1e04:	00f50663          	beq	a0,a5,1e10 <isspace+0x10>
    1e08:	355d                	addiw	a0,a0,-9
    1e0a:	00553513          	sltiu	a0,a0,5
    1e0e:	8082                	ret
    1e10:	4505                	li	a0,1
}
    1e12:	8082                	ret

0000000000001e14 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e14:	fd05051b          	addiw	a0,a0,-48
}
    1e18:	00a53513          	sltiu	a0,a0,10
    1e1c:	8082                	ret

0000000000001e1e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e1e:	02000613          	li	a2,32
    1e22:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e24:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e28:	ff77869b          	addiw	a3,a5,-9
    1e2c:	04c78c63          	beq	a5,a2,1e84 <atoi+0x66>
    1e30:	0007871b          	sext.w	a4,a5
    1e34:	04d5f863          	bgeu	a1,a3,1e84 <atoi+0x66>
		s++;
	switch (*s) {
    1e38:	02b00693          	li	a3,43
    1e3c:	04d78963          	beq	a5,a3,1e8e <atoi+0x70>
    1e40:	02d00693          	li	a3,45
    1e44:	06d78263          	beq	a5,a3,1ea8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e48:	fd07061b          	addiw	a2,a4,-48
    1e4c:	47a5                	li	a5,9
    1e4e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e50:	4e01                	li	t3,0
	while (isdigit(*s))
    1e52:	04c7e963          	bltu	a5,a2,1ea4 <atoi+0x86>
	int n = 0, neg = 0;
    1e56:	4501                	li	a0,0
	while (isdigit(*s))
    1e58:	4825                	li	a6,9
    1e5a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1e5e:	0025179b          	slliw	a5,a0,0x2
    1e62:	9fa9                	addw	a5,a5,a0
    1e64:	fd07031b          	addiw	t1,a4,-48
    1e68:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1e6c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1e70:	0685                	addi	a3,a3,1
    1e72:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e76:	0006071b          	sext.w	a4,a2
    1e7a:	feb870e3          	bgeu	a6,a1,1e5a <atoi+0x3c>
	return neg ? n : -n;
    1e7e:	000e0563          	beqz	t3,1e88 <atoi+0x6a>
}
    1e82:	8082                	ret
		s++;
    1e84:	0505                	addi	a0,a0,1
    1e86:	bf79                	j	1e24 <atoi+0x6>
	return neg ? n : -n;
    1e88:	4113053b          	subw	a0,t1,a7
    1e8c:	8082                	ret
	while (isdigit(*s))
    1e8e:	00154703          	lbu	a4,1(a0)
    1e92:	47a5                	li	a5,9
		s++;
    1e94:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e98:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e9c:	4e01                	li	t3,0
	while (isdigit(*s))
    1e9e:	2701                	sext.w	a4,a4
    1ea0:	fac7fbe3          	bgeu	a5,a2,1e56 <atoi+0x38>
    1ea4:	4501                	li	a0,0
}
    1ea6:	8082                	ret
	while (isdigit(*s))
    1ea8:	00154703          	lbu	a4,1(a0)
    1eac:	47a5                	li	a5,9
		s++;
    1eae:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1eb2:	fd07061b          	addiw	a2,a4,-48
    1eb6:	2701                	sext.w	a4,a4
    1eb8:	fec7e6e3          	bltu	a5,a2,1ea4 <atoi+0x86>
		neg = 1;
    1ebc:	4e05                	li	t3,1
    1ebe:	bf61                	j	1e56 <atoi+0x38>

0000000000001ec0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ec0:	16060d63          	beqz	a2,203a <memset+0x17a>
    1ec4:	40a007b3          	neg	a5,a0
    1ec8:	8b9d                	andi	a5,a5,7
    1eca:	00778693          	addi	a3,a5,7
    1ece:	482d                	li	a6,11
    1ed0:	0ff5f713          	zext.b	a4,a1
    1ed4:	fff60593          	addi	a1,a2,-1
    1ed8:	1706e263          	bltu	a3,a6,203c <memset+0x17c>
    1edc:	16d5ea63          	bltu	a1,a3,2050 <memset+0x190>
    1ee0:	16078563          	beqz	a5,204a <memset+0x18a>
    1ee4:	00e50023          	sb	a4,0(a0)
    1ee8:	4685                	li	a3,1
    1eea:	00150593          	addi	a1,a0,1
    1eee:	14d78c63          	beq	a5,a3,2046 <memset+0x186>
    1ef2:	00e500a3          	sb	a4,1(a0)
    1ef6:	4689                	li	a3,2
    1ef8:	00250593          	addi	a1,a0,2
    1efc:	14d78d63          	beq	a5,a3,2056 <memset+0x196>
    1f00:	00e50123          	sb	a4,2(a0)
    1f04:	468d                	li	a3,3
    1f06:	00350593          	addi	a1,a0,3
    1f0a:	12d78b63          	beq	a5,a3,2040 <memset+0x180>
    1f0e:	00e501a3          	sb	a4,3(a0)
    1f12:	4691                	li	a3,4
    1f14:	00450593          	addi	a1,a0,4
    1f18:	14d78163          	beq	a5,a3,205a <memset+0x19a>
    1f1c:	00e50223          	sb	a4,4(a0)
    1f20:	4695                	li	a3,5
    1f22:	00550593          	addi	a1,a0,5
    1f26:	12d78c63          	beq	a5,a3,205e <memset+0x19e>
    1f2a:	00e502a3          	sb	a4,5(a0)
    1f2e:	469d                	li	a3,7
    1f30:	00650593          	addi	a1,a0,6
    1f34:	12d79763          	bne	a5,a3,2062 <memset+0x1a2>
    1f38:	00750593          	addi	a1,a0,7
    1f3c:	00e50323          	sb	a4,6(a0)
    1f40:	481d                	li	a6,7
    1f42:	00871693          	slli	a3,a4,0x8
    1f46:	01071893          	slli	a7,a4,0x10
    1f4a:	8ed9                	or	a3,a3,a4
    1f4c:	01871313          	slli	t1,a4,0x18
    1f50:	0116e6b3          	or	a3,a3,a7
    1f54:	0066e6b3          	or	a3,a3,t1
    1f58:	02071893          	slli	a7,a4,0x20
    1f5c:	02871e13          	slli	t3,a4,0x28
    1f60:	0116e6b3          	or	a3,a3,a7
    1f64:	40f60333          	sub	t1,a2,a5
    1f68:	03071893          	slli	a7,a4,0x30
    1f6c:	01c6e6b3          	or	a3,a3,t3
    1f70:	0116e6b3          	or	a3,a3,a7
    1f74:	03871e13          	slli	t3,a4,0x38
    1f78:	97aa                	add	a5,a5,a0
    1f7a:	ff837893          	andi	a7,t1,-8
    1f7e:	01c6e6b3          	or	a3,a3,t3
    1f82:	98be                	add	a7,a7,a5
    1f84:	e394                	sd	a3,0(a5)
    1f86:	07a1                	addi	a5,a5,8
    1f88:	ff179ee3          	bne	a5,a7,1f84 <memset+0xc4>
    1f8c:	ff837893          	andi	a7,t1,-8
    1f90:	011587b3          	add	a5,a1,a7
    1f94:	010886bb          	addw	a3,a7,a6
    1f98:	0b130663          	beq	t1,a7,2044 <memset+0x184>
    1f9c:	00e78023          	sb	a4,0(a5)
    1fa0:	0016859b          	addiw	a1,a3,1
    1fa4:	08c5fb63          	bgeu	a1,a2,203a <memset+0x17a>
    1fa8:	00e780a3          	sb	a4,1(a5)
    1fac:	0026859b          	addiw	a1,a3,2
    1fb0:	08c5f563          	bgeu	a1,a2,203a <memset+0x17a>
    1fb4:	00e78123          	sb	a4,2(a5)
    1fb8:	0036859b          	addiw	a1,a3,3
    1fbc:	06c5ff63          	bgeu	a1,a2,203a <memset+0x17a>
    1fc0:	00e781a3          	sb	a4,3(a5)
    1fc4:	0046859b          	addiw	a1,a3,4
    1fc8:	06c5f963          	bgeu	a1,a2,203a <memset+0x17a>
    1fcc:	00e78223          	sb	a4,4(a5)
    1fd0:	0056859b          	addiw	a1,a3,5
    1fd4:	06c5f363          	bgeu	a1,a2,203a <memset+0x17a>
    1fd8:	00e782a3          	sb	a4,5(a5)
    1fdc:	0066859b          	addiw	a1,a3,6
    1fe0:	04c5fd63          	bgeu	a1,a2,203a <memset+0x17a>
    1fe4:	00e78323          	sb	a4,6(a5)
    1fe8:	0076859b          	addiw	a1,a3,7
    1fec:	04c5f763          	bgeu	a1,a2,203a <memset+0x17a>
    1ff0:	00e783a3          	sb	a4,7(a5)
    1ff4:	0086859b          	addiw	a1,a3,8
    1ff8:	04c5f163          	bgeu	a1,a2,203a <memset+0x17a>
    1ffc:	00e78423          	sb	a4,8(a5)
    2000:	0096859b          	addiw	a1,a3,9
    2004:	02c5fb63          	bgeu	a1,a2,203a <memset+0x17a>
    2008:	00e784a3          	sb	a4,9(a5)
    200c:	00a6859b          	addiw	a1,a3,10
    2010:	02c5f563          	bgeu	a1,a2,203a <memset+0x17a>
    2014:	00e78523          	sb	a4,10(a5)
    2018:	00b6859b          	addiw	a1,a3,11
    201c:	00c5ff63          	bgeu	a1,a2,203a <memset+0x17a>
    2020:	00e785a3          	sb	a4,11(a5)
    2024:	00c6859b          	addiw	a1,a3,12
    2028:	00c5f963          	bgeu	a1,a2,203a <memset+0x17a>
    202c:	00e78623          	sb	a4,12(a5)
    2030:	26b5                	addiw	a3,a3,13
    2032:	00c6f463          	bgeu	a3,a2,203a <memset+0x17a>
    2036:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    203a:	8082                	ret
    203c:	46ad                	li	a3,11
    203e:	bd79                	j	1edc <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2040:	480d                	li	a6,3
    2042:	b701                	j	1f42 <memset+0x82>
    2044:	8082                	ret
    2046:	4805                	li	a6,1
    2048:	bded                	j	1f42 <memset+0x82>
    204a:	85aa                	mv	a1,a0
    204c:	4801                	li	a6,0
    204e:	bdd5                	j	1f42 <memset+0x82>
    2050:	87aa                	mv	a5,a0
    2052:	4681                	li	a3,0
    2054:	b7a1                	j	1f9c <memset+0xdc>
    2056:	4809                	li	a6,2
    2058:	b5ed                	j	1f42 <memset+0x82>
    205a:	4811                	li	a6,4
    205c:	b5dd                	j	1f42 <memset+0x82>
    205e:	4815                	li	a6,5
    2060:	b5cd                	j	1f42 <memset+0x82>
    2062:	4819                	li	a6,6
    2064:	bdf9                	j	1f42 <memset+0x82>

0000000000002066 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2066:	00054783          	lbu	a5,0(a0)
    206a:	0005c703          	lbu	a4,0(a1)
    206e:	00e79863          	bne	a5,a4,207e <strcmp+0x18>
    2072:	0505                	addi	a0,a0,1
    2074:	0585                	addi	a1,a1,1
    2076:	fbe5                	bnez	a5,2066 <strcmp>
    2078:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    207a:	9d19                	subw	a0,a0,a4
    207c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    207e:	0007851b          	sext.w	a0,a5
    2082:	bfe5                	j	207a <strcmp+0x14>

0000000000002084 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2084:	ca15                	beqz	a2,20b8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2086:	00054783          	lbu	a5,0(a0)
	if (!n--)
    208a:	167d                	addi	a2,a2,-1
    208c:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2090:	eb99                	bnez	a5,20a6 <strncmp+0x22>
    2092:	a815                	j	20c6 <strncmp+0x42>
    2094:	00a68e63          	beq	a3,a0,20b0 <strncmp+0x2c>
    2098:	0505                	addi	a0,a0,1
    209a:	00f71b63          	bne	a4,a5,20b0 <strncmp+0x2c>
    209e:	00054783          	lbu	a5,0(a0)
    20a2:	cf89                	beqz	a5,20bc <strncmp+0x38>
    20a4:	85b2                	mv	a1,a2
    20a6:	0005c703          	lbu	a4,0(a1)
    20aa:	00158613          	addi	a2,a1,1
    20ae:	f37d                	bnez	a4,2094 <strncmp+0x10>
		;
	return *l - *r;
    20b0:	0007851b          	sext.w	a0,a5
    20b4:	9d19                	subw	a0,a0,a4
    20b6:	8082                	ret
		return 0;
    20b8:	4501                	li	a0,0
}
    20ba:	8082                	ret
	return *l - *r;
    20bc:	0015c703          	lbu	a4,1(a1)
    20c0:	4501                	li	a0,0
    20c2:	9d19                	subw	a0,a0,a4
    20c4:	8082                	ret
    20c6:	0005c703          	lbu	a4,0(a1)
    20ca:	4501                	li	a0,0
    20cc:	b7e5                	j	20b4 <strncmp+0x30>

00000000000020ce <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    20ce:	00757793          	andi	a5,a0,7
    20d2:	cf89                	beqz	a5,20ec <strlen+0x1e>
    20d4:	87aa                	mv	a5,a0
    20d6:	a029                	j	20e0 <strlen+0x12>
    20d8:	0785                	addi	a5,a5,1
    20da:	0077f713          	andi	a4,a5,7
    20de:	cb01                	beqz	a4,20ee <strlen+0x20>
		if (!*s)
    20e0:	0007c703          	lbu	a4,0(a5)
    20e4:	fb75                	bnez	a4,20d8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    20e6:	40a78533          	sub	a0,a5,a0
}
    20ea:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    20ec:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    20ee:	6394                	ld	a3,0(a5)
    20f0:	00001597          	auipc	a1,0x1
    20f4:	9585b583          	ld	a1,-1704(a1) # 2a48 <enable_deadlock_detect+0x1dc>
    20f8:	00001617          	auipc	a2,0x1
    20fc:	95863603          	ld	a2,-1704(a2) # 2a50 <enable_deadlock_detect+0x1e4>
    2100:	a019                	j	2106 <strlen+0x38>
    2102:	6794                	ld	a3,8(a5)
    2104:	07a1                	addi	a5,a5,8
    2106:	00b68733          	add	a4,a3,a1
    210a:	fff6c693          	not	a3,a3
    210e:	8f75                	and	a4,a4,a3
    2110:	8f71                	and	a4,a4,a2
    2112:	db65                	beqz	a4,2102 <strlen+0x34>
	for (; *s; s++)
    2114:	0007c703          	lbu	a4,0(a5)
    2118:	d779                	beqz	a4,20e6 <strlen+0x18>
    211a:	0017c703          	lbu	a4,1(a5)
    211e:	0785                	addi	a5,a5,1
    2120:	d379                	beqz	a4,20e6 <strlen+0x18>
    2122:	0017c703          	lbu	a4,1(a5)
    2126:	0785                	addi	a5,a5,1
    2128:	fb6d                	bnez	a4,211a <strlen+0x4c>
    212a:	bf75                	j	20e6 <strlen+0x18>

000000000000212c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    212c:	00757713          	andi	a4,a0,7
{
    2130:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2132:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2136:	cb19                	beqz	a4,214c <memchr+0x20>
    2138:	ce25                	beqz	a2,21b0 <memchr+0x84>
    213a:	0007c703          	lbu	a4,0(a5)
    213e:	04b70e63          	beq	a4,a1,219a <memchr+0x6e>
    2142:	0785                	addi	a5,a5,1
    2144:	0077f713          	andi	a4,a5,7
    2148:	167d                	addi	a2,a2,-1
    214a:	f77d                	bnez	a4,2138 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    214c:	4501                	li	a0,0
	if (n && *s != c) {
    214e:	c235                	beqz	a2,21b2 <memchr+0x86>
    2150:	0007c703          	lbu	a4,0(a5)
    2154:	04b70363          	beq	a4,a1,219a <memchr+0x6e>
		size_t k = ONES * c;
    2158:	00001517          	auipc	a0,0x1
    215c:	90053503          	ld	a0,-1792(a0) # 2a58 <enable_deadlock_detect+0x1ec>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2160:	471d                	li	a4,7
		size_t k = ONES * c;
    2162:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2166:	02c77a63          	bgeu	a4,a2,219a <memchr+0x6e>
    216a:	00001897          	auipc	a7,0x1
    216e:	8de8b883          	ld	a7,-1826(a7) # 2a48 <enable_deadlock_detect+0x1dc>
    2172:	00001817          	auipc	a6,0x1
    2176:	8de83803          	ld	a6,-1826(a6) # 2a50 <enable_deadlock_detect+0x1e4>
    217a:	431d                	li	t1,7
    217c:	a029                	j	2186 <memchr+0x5a>
		     w++, n -= SS)
    217e:	1661                	addi	a2,a2,-8
    2180:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2182:	02c37963          	bgeu	t1,a2,21b4 <memchr+0x88>
    2186:	6398                	ld	a4,0(a5)
    2188:	8f29                	xor	a4,a4,a0
    218a:	011706b3          	add	a3,a4,a7
    218e:	fff74713          	not	a4,a4
    2192:	8f75                	and	a4,a4,a3
    2194:	01077733          	and	a4,a4,a6
    2198:	d37d                	beqz	a4,217e <memchr+0x52>
{
    219a:	853e                	mv	a0,a5
    219c:	97b2                	add	a5,a5,a2
    219e:	a021                	j	21a6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21a0:	0505                	addi	a0,a0,1
    21a2:	00f50763          	beq	a0,a5,21b0 <memchr+0x84>
    21a6:	00054703          	lbu	a4,0(a0)
    21aa:	feb71be3          	bne	a4,a1,21a0 <memchr+0x74>
    21ae:	8082                	ret
	return n ? (void *)s : 0;
    21b0:	4501                	li	a0,0
}
    21b2:	8082                	ret
	return n ? (void *)s : 0;
    21b4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    21b6:	f275                	bnez	a2,219a <memchr+0x6e>
}
    21b8:	8082                	ret

00000000000021ba <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    21ba:	1101                	addi	sp,sp,-32
    21bc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    21be:	862e                	mv	a2,a1
{
    21c0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    21c2:	4581                	li	a1,0
{
    21c4:	e426                	sd	s1,8(sp)
    21c6:	ec06                	sd	ra,24(sp)
    21c8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    21ca:	f63ff0ef          	jal	ra,212c <memchr>
	return p ? p - s : n;
    21ce:	c519                	beqz	a0,21dc <strnlen+0x22>
}
    21d0:	60e2                	ld	ra,24(sp)
    21d2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    21d4:	8d05                	sub	a0,a0,s1
}
    21d6:	64a2                	ld	s1,8(sp)
    21d8:	6105                	addi	sp,sp,32
    21da:	8082                	ret
    21dc:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    21de:	8522                	mv	a0,s0
}
    21e0:	6442                	ld	s0,16(sp)
    21e2:	64a2                	ld	s1,8(sp)
    21e4:	6105                	addi	sp,sp,32
    21e6:	8082                	ret

00000000000021e8 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    21e8:	00a5c7b3          	xor	a5,a1,a0
    21ec:	8b9d                	andi	a5,a5,7
    21ee:	eb95                	bnez	a5,2222 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    21f0:	0075f793          	andi	a5,a1,7
    21f4:	e7b1                	bnez	a5,2240 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    21f6:	6198                	ld	a4,0(a1)
    21f8:	00001617          	auipc	a2,0x1
    21fc:	85063603          	ld	a2,-1968(a2) # 2a48 <enable_deadlock_detect+0x1dc>
    2200:	00001817          	auipc	a6,0x1
    2204:	85083803          	ld	a6,-1968(a6) # 2a50 <enable_deadlock_detect+0x1e4>
    2208:	a029                	j	2212 <stpcpy+0x2a>
    220a:	05a1                	addi	a1,a1,8
    220c:	e118                	sd	a4,0(a0)
    220e:	6198                	ld	a4,0(a1)
    2210:	0521                	addi	a0,a0,8
    2212:	00c707b3          	add	a5,a4,a2
    2216:	fff74693          	not	a3,a4
    221a:	8ff5                	and	a5,a5,a3
    221c:	0107f7b3          	and	a5,a5,a6
    2220:	d7ed                	beqz	a5,220a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2222:	0005c783          	lbu	a5,0(a1)
    2226:	00f50023          	sb	a5,0(a0)
    222a:	c785                	beqz	a5,2252 <stpcpy+0x6a>
    222c:	0015c783          	lbu	a5,1(a1)
    2230:	0505                	addi	a0,a0,1
    2232:	0585                	addi	a1,a1,1
    2234:	00f50023          	sb	a5,0(a0)
    2238:	fbf5                	bnez	a5,222c <stpcpy+0x44>
		;
	return d;
}
    223a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    223c:	0505                	addi	a0,a0,1
    223e:	df45                	beqz	a4,21f6 <stpcpy+0xe>
			if (!(*d = *s))
    2240:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2244:	0585                	addi	a1,a1,1
    2246:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    224a:	00f50023          	sb	a5,0(a0)
    224e:	f7fd                	bnez	a5,223c <stpcpy+0x54>
}
    2250:	8082                	ret
    2252:	8082                	ret

0000000000002254 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2254:	00a5c7b3          	xor	a5,a1,a0
    2258:	8b9d                	andi	a5,a5,7
    225a:	1a079863          	bnez	a5,240a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    225e:	0075f793          	andi	a5,a1,7
    2262:	16078463          	beqz	a5,23ca <stpncpy+0x176>
    2266:	ea01                	bnez	a2,2276 <stpncpy+0x22>
    2268:	a421                	j	2470 <stpncpy+0x21c>
    226a:	167d                	addi	a2,a2,-1
    226c:	0505                	addi	a0,a0,1
    226e:	14070e63          	beqz	a4,23ca <stpncpy+0x176>
    2272:	1a060863          	beqz	a2,2422 <stpncpy+0x1ce>
    2276:	0005c783          	lbu	a5,0(a1)
    227a:	0585                	addi	a1,a1,1
    227c:	0075f713          	andi	a4,a1,7
    2280:	00f50023          	sb	a5,0(a0)
    2284:	f3fd                	bnez	a5,226a <stpncpy+0x16>
    2286:	4805                	li	a6,1
    2288:	1a061863          	bnez	a2,2438 <stpncpy+0x1e4>
    228c:	40a007b3          	neg	a5,a0
    2290:	8b9d                	andi	a5,a5,7
    2292:	4681                	li	a3,0
    2294:	18061a63          	bnez	a2,2428 <stpncpy+0x1d4>
    2298:	00778713          	addi	a4,a5,7
    229c:	45ad                	li	a1,11
    229e:	18b76363          	bltu	a4,a1,2424 <stpncpy+0x1d0>
    22a2:	1ae6eb63          	bltu	a3,a4,2458 <stpncpy+0x204>
    22a6:	1a078363          	beqz	a5,244c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22aa:	00050023          	sb	zero,0(a0)
    22ae:	4685                	li	a3,1
    22b0:	00150713          	addi	a4,a0,1
    22b4:	18d78f63          	beq	a5,a3,2452 <stpncpy+0x1fe>
    22b8:	000500a3          	sb	zero,1(a0)
    22bc:	4689                	li	a3,2
    22be:	00250713          	addi	a4,a0,2
    22c2:	18d78e63          	beq	a5,a3,245e <stpncpy+0x20a>
    22c6:	00050123          	sb	zero,2(a0)
    22ca:	468d                	li	a3,3
    22cc:	00350713          	addi	a4,a0,3
    22d0:	16d78c63          	beq	a5,a3,2448 <stpncpy+0x1f4>
    22d4:	000501a3          	sb	zero,3(a0)
    22d8:	4691                	li	a3,4
    22da:	00450713          	addi	a4,a0,4
    22de:	18d78263          	beq	a5,a3,2462 <stpncpy+0x20e>
    22e2:	00050223          	sb	zero,4(a0)
    22e6:	4695                	li	a3,5
    22e8:	00550713          	addi	a4,a0,5
    22ec:	16d78d63          	beq	a5,a3,2466 <stpncpy+0x212>
    22f0:	000502a3          	sb	zero,5(a0)
    22f4:	469d                	li	a3,7
    22f6:	00650713          	addi	a4,a0,6
    22fa:	16d79863          	bne	a5,a3,246a <stpncpy+0x216>
    22fe:	00750713          	addi	a4,a0,7
    2302:	00050323          	sb	zero,6(a0)
    2306:	40f80833          	sub	a6,a6,a5
    230a:	ff887593          	andi	a1,a6,-8
    230e:	97aa                	add	a5,a5,a0
    2310:	95be                	add	a1,a1,a5
    2312:	0007b023          	sd	zero,0(a5)
    2316:	07a1                	addi	a5,a5,8
    2318:	feb79de3          	bne	a5,a1,2312 <stpncpy+0xbe>
    231c:	ff887593          	andi	a1,a6,-8
    2320:	9ead                	addw	a3,a3,a1
    2322:	00b707b3          	add	a5,a4,a1
    2326:	12b80863          	beq	a6,a1,2456 <stpncpy+0x202>
    232a:	00078023          	sb	zero,0(a5)
    232e:	0016871b          	addiw	a4,a3,1
    2332:	0ec77863          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    2336:	000780a3          	sb	zero,1(a5)
    233a:	0026871b          	addiw	a4,a3,2
    233e:	0ec77263          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    2342:	00078123          	sb	zero,2(a5)
    2346:	0036871b          	addiw	a4,a3,3
    234a:	0cc77c63          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    234e:	000781a3          	sb	zero,3(a5)
    2352:	0046871b          	addiw	a4,a3,4
    2356:	0cc77663          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    235a:	00078223          	sb	zero,4(a5)
    235e:	0056871b          	addiw	a4,a3,5
    2362:	0cc77063          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    2366:	000782a3          	sb	zero,5(a5)
    236a:	0066871b          	addiw	a4,a3,6
    236e:	0ac77a63          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    2372:	00078323          	sb	zero,6(a5)
    2376:	0076871b          	addiw	a4,a3,7
    237a:	0ac77463          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    237e:	000783a3          	sb	zero,7(a5)
    2382:	0086871b          	addiw	a4,a3,8
    2386:	08c77e63          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    238a:	00078423          	sb	zero,8(a5)
    238e:	0096871b          	addiw	a4,a3,9
    2392:	08c77863          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    2396:	000784a3          	sb	zero,9(a5)
    239a:	00a6871b          	addiw	a4,a3,10
    239e:	08c77263          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    23a2:	00078523          	sb	zero,10(a5)
    23a6:	00b6871b          	addiw	a4,a3,11
    23aa:	06c77c63          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    23ae:	000785a3          	sb	zero,11(a5)
    23b2:	00c6871b          	addiw	a4,a3,12
    23b6:	06c77663          	bgeu	a4,a2,2422 <stpncpy+0x1ce>
    23ba:	00078623          	sb	zero,12(a5)
    23be:	26b5                	addiw	a3,a3,13
    23c0:	06c6f163          	bgeu	a3,a2,2422 <stpncpy+0x1ce>
    23c4:	000786a3          	sb	zero,13(a5)
    23c8:	8082                	ret
			;
		if (!n || !*s)
    23ca:	c645                	beqz	a2,2472 <stpncpy+0x21e>
    23cc:	0005c783          	lbu	a5,0(a1)
    23d0:	ea078be3          	beqz	a5,2286 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    23d4:	479d                	li	a5,7
    23d6:	02c7ff63          	bgeu	a5,a2,2414 <stpncpy+0x1c0>
    23da:	00000897          	auipc	a7,0x0
    23de:	66e8b883          	ld	a7,1646(a7) # 2a48 <enable_deadlock_detect+0x1dc>
    23e2:	00000817          	auipc	a6,0x0
    23e6:	66e83803          	ld	a6,1646(a6) # 2a50 <enable_deadlock_detect+0x1e4>
    23ea:	431d                	li	t1,7
    23ec:	6198                	ld	a4,0(a1)
    23ee:	011707b3          	add	a5,a4,a7
    23f2:	fff74693          	not	a3,a4
    23f6:	8ff5                	and	a5,a5,a3
    23f8:	0107f7b3          	and	a5,a5,a6
    23fc:	ef81                	bnez	a5,2414 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    23fe:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2400:	1661                	addi	a2,a2,-8
    2402:	05a1                	addi	a1,a1,8
    2404:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2406:	fec363e3          	bltu	t1,a2,23ec <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    240a:	e609                	bnez	a2,2414 <stpncpy+0x1c0>
    240c:	a08d                	j	246e <stpncpy+0x21a>
    240e:	167d                	addi	a2,a2,-1
    2410:	0505                	addi	a0,a0,1
    2412:	ca01                	beqz	a2,2422 <stpncpy+0x1ce>
    2414:	0005c783          	lbu	a5,0(a1)
    2418:	0585                	addi	a1,a1,1
    241a:	00f50023          	sb	a5,0(a0)
    241e:	fbe5                	bnez	a5,240e <stpncpy+0x1ba>
		;
tail:
    2420:	b59d                	j	2286 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2422:	8082                	ret
    2424:	472d                	li	a4,11
    2426:	bdb5                	j	22a2 <stpncpy+0x4e>
    2428:	00778713          	addi	a4,a5,7
    242c:	45ad                	li	a1,11
    242e:	fff60693          	addi	a3,a2,-1
    2432:	e6b778e3          	bgeu	a4,a1,22a2 <stpncpy+0x4e>
    2436:	b7fd                	j	2424 <stpncpy+0x1d0>
    2438:	40a007b3          	neg	a5,a0
    243c:	8832                	mv	a6,a2
    243e:	8b9d                	andi	a5,a5,7
    2440:	4681                	li	a3,0
    2442:	e4060be3          	beqz	a2,2298 <stpncpy+0x44>
    2446:	b7cd                	j	2428 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2448:	468d                	li	a3,3
    244a:	bd75                	j	2306 <stpncpy+0xb2>
    244c:	872a                	mv	a4,a0
    244e:	4681                	li	a3,0
    2450:	bd5d                	j	2306 <stpncpy+0xb2>
    2452:	4685                	li	a3,1
    2454:	bd4d                	j	2306 <stpncpy+0xb2>
    2456:	8082                	ret
    2458:	87aa                	mv	a5,a0
    245a:	4681                	li	a3,0
    245c:	b5f9                	j	232a <stpncpy+0xd6>
    245e:	4689                	li	a3,2
    2460:	b55d                	j	2306 <stpncpy+0xb2>
    2462:	4691                	li	a3,4
    2464:	b54d                	j	2306 <stpncpy+0xb2>
    2466:	4695                	li	a3,5
    2468:	bd79                	j	2306 <stpncpy+0xb2>
    246a:	4699                	li	a3,6
    246c:	bd69                	j	2306 <stpncpy+0xb2>
    246e:	8082                	ret
    2470:	8082                	ret
    2472:	8082                	ret

0000000000002474 <basename>:

char *basename(char *s)
{
    2474:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2476:	c54d                	beqz	a0,2520 <basename+0xac>
    2478:	00054783          	lbu	a5,0(a0)
		return ".";
    247c:	00000517          	auipc	a0,0x0
    2480:	5c450513          	addi	a0,a0,1476 # 2a40 <enable_deadlock_detect+0x1d4>
	if (!s || !*s)
    2484:	e391                	bnez	a5,2488 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2486:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2488:	0076f713          	andi	a4,a3,7
    248c:	87b6                	mv	a5,a3
    248e:	cf51                	beqz	a4,252a <basename+0xb6>
    2490:	0785                	addi	a5,a5,1
    2492:	0077f713          	andi	a4,a5,7
    2496:	c729                	beqz	a4,24e0 <basename+0x6c>
		if (!*s)
    2498:	0007c703          	lbu	a4,0(a5)
    249c:	fb75                	bnez	a4,2490 <basename+0x1c>
	return s - a;
    249e:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24a0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24a2:	cf8d                	beqz	a5,24dc <basename+0x68>
    24a4:	00f68733          	add	a4,a3,a5
    24a8:	02f00593          	li	a1,47
    24ac:	a031                	j	24b8 <basename+0x44>
		s[i] = 0;
    24ae:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    24b2:	17fd                	addi	a5,a5,-1
    24b4:	177d                	addi	a4,a4,-1
    24b6:	c39d                	beqz	a5,24dc <basename+0x68>
    24b8:	00074603          	lbu	a2,0(a4)
    24bc:	feb609e3          	beq	a2,a1,24ae <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    24c0:	02f00613          	li	a2,47
    24c4:	a011                	j	24c8 <basename+0x54>
    24c6:	cb99                	beqz	a5,24dc <basename+0x68>
    24c8:	853e                	mv	a0,a5
    24ca:	17fd                	addi	a5,a5,-1
    24cc:	00f68733          	add	a4,a3,a5
    24d0:	00074703          	lbu	a4,0(a4)
    24d4:	fec719e3          	bne	a4,a2,24c6 <basename+0x52>
	return s + i;
    24d8:	9536                	add	a0,a0,a3
    24da:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24dc:	8536                	mv	a0,a3
    24de:	8082                	ret
    24e0:	6390                	ld	a2,0(a5)
    24e2:	00000517          	auipc	a0,0x0
    24e6:	56653503          	ld	a0,1382(a0) # 2a48 <enable_deadlock_detect+0x1dc>
    24ea:	00000597          	auipc	a1,0x0
    24ee:	5665b583          	ld	a1,1382(a1) # 2a50 <enable_deadlock_detect+0x1e4>
    24f2:	fff64713          	not	a4,a2
    24f6:	962a                	add	a2,a2,a0
    24f8:	8f71                	and	a4,a4,a2
    24fa:	8f6d                	and	a4,a4,a1
    24fc:	eb11                	bnez	a4,2510 <basename+0x9c>
    24fe:	6790                	ld	a2,8(a5)
    2500:	07a1                	addi	a5,a5,8
    2502:	00a60733          	add	a4,a2,a0
    2506:	fff64613          	not	a2,a2
    250a:	8f71                	and	a4,a4,a2
    250c:	8f6d                	and	a4,a4,a1
    250e:	db65                	beqz	a4,24fe <basename+0x8a>
	for (; *s; s++)
    2510:	0007c703          	lbu	a4,0(a5)
    2514:	d749                	beqz	a4,249e <basename+0x2a>
    2516:	0017c703          	lbu	a4,1(a5)
    251a:	0785                	addi	a5,a5,1
    251c:	ff6d                	bnez	a4,2516 <basename+0xa2>
    251e:	b741                	j	249e <basename+0x2a>
		return ".";
    2520:	00000517          	auipc	a0,0x0
    2524:	52050513          	addi	a0,a0,1312 # 2a40 <enable_deadlock_detect+0x1d4>
    2528:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    252a:	6290                	ld	a2,0(a3)
    252c:	00000517          	auipc	a0,0x0
    2530:	51c53503          	ld	a0,1308(a0) # 2a48 <enable_deadlock_detect+0x1dc>
    2534:	00000597          	auipc	a1,0x0
    2538:	51c5b583          	ld	a1,1308(a1) # 2a50 <enable_deadlock_detect+0x1e4>
    253c:	fff64713          	not	a4,a2
    2540:	962a                	add	a2,a2,a0
    2542:	8f71                	and	a4,a4,a2
    2544:	8f6d                	and	a4,a4,a1
    2546:	df45                	beqz	a4,24fe <basename+0x8a>
    2548:	b7f9                	j	2516 <basename+0xa2>

000000000000254a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    254a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    254e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2550:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2554:	2501                	sext.w	a0,a0
    2556:	8082                	ret

0000000000002558 <close>:

int close(int fd)
{
	if (fd == 1) {
    2558:	4785                	li	a5,1
    255a:	00f50863          	beq	a0,a5,256a <close+0x12>
	register long a7 __asm__("a7") = n;
    255e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2562:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2566:	2501                	sext.w	a0,a0
    2568:	8082                	ret
{
    256a:	1101                	addi	sp,sp,-32
    256c:	ec06                	sd	ra,24(sp)
    256e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2570:	cdffe0ef          	jal	ra,124e <__write_buffer>
		__clear_buffer();
    2574:	d03fe0ef          	jal	ra,1276 <__clear_buffer>
    2578:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    257a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    257e:	00000073          	ecall
}
    2582:	60e2                	ld	ra,24(sp)
    2584:	2501                	sext.w	a0,a0
    2586:	6105                	addi	sp,sp,32
    2588:	8082                	ret

000000000000258a <read>:
	register long a7 __asm__("a7") = n;
    258a:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    258e:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2592:	8082                	ret

0000000000002594 <write>:
	register long a7 __asm__("a7") = n;
    2594:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2598:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    259c:	8082                	ret

000000000000259e <getpid>:
	register long a7 __asm__("a7") = n;
    259e:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25a2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25a6:	2501                	sext.w	a0,a0
    25a8:	8082                	ret

00000000000025aa <getppid>:
	register long a7 __asm__("a7") = n;
    25aa:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25ae:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    25b2:	2501                	sext.w	a0,a0
    25b4:	8082                	ret

00000000000025b6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    25b6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25ba:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    25be:	2501                	sext.w	a0,a0
    25c0:	8082                	ret

00000000000025c2 <fork>:
	register long a7 __asm__("a7") = n;
    25c2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    25c6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    25ca:	2501                	sext.w	a0,a0
    25cc:	8082                	ret

00000000000025ce <exit>:

void exit(int code)
{
    25ce:	1141                	addi	sp,sp,-16
    25d0:	e406                	sd	ra,8(sp)
    25d2:	e022                	sd	s0,0(sp)
    25d4:	842a                	mv	s0,a0
	__write_buffer();
    25d6:	c79fe0ef          	jal	ra,124e <__write_buffer>
	__clear_buffer();
    25da:	c9dfe0ef          	jal	ra,1276 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    25de:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    25e2:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    25e4:	00000073          	ecall
	syscall(SYS_exit, code);
}
    25e8:	60a2                	ld	ra,8(sp)
    25ea:	6402                	ld	s0,0(sp)
    25ec:	0141                	addi	sp,sp,16
    25ee:	8082                	ret

00000000000025f0 <waitpid>:
	register long a7 __asm__("a7") = n;
    25f0:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25f4:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    25f8:	2501                	sext.w	a0,a0
    25fa:	8082                	ret

00000000000025fc <exec>:
	register long a7 __asm__("a7") = n;
    25fc:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2600:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2604:	2501                	sext.w	a0,a0
    2606:	8082                	ret

0000000000002608 <get_mtime>:

int64 get_mtime()
{
    2608:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    260a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    260e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2610:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2612:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2616:	2501                	sext.w	a0,a0
    2618:	ed01                	bnez	a0,2630 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    261a:	6722                	ld	a4,8(sp)
    261c:	3e800793          	li	a5,1000
    2620:	6682                	ld	a3,0(sp)
    2622:	02f75733          	divu	a4,a4,a5
    2626:	02d78533          	mul	a0,a5,a3
    262a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    262c:	0141                	addi	sp,sp,16
    262e:	8082                	ret
	return -1;
    2630:	557d                	li	a0,-1
    2632:	bfed                	j	262c <get_mtime+0x24>

0000000000002634 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2634:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2638:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    263c:	2501                	sext.w	a0,a0
    263e:	8082                	ret

0000000000002640 <sleep>:

int sleep(unsigned long long time)
{
    2640:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2642:	880a                	mv	a6,sp
{
    2644:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2646:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    264a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    264c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    264e:	00000073          	ecall
	if (err == 0) {
    2652:	2501                	sext.w	a0,a0
    2654:	ed31                	bnez	a0,26b0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2656:	6722                	ld	a4,8(sp)
    2658:	3e800793          	li	a5,1000
    265c:	6682                	ld	a3,0(sp)
    265e:	02f75733          	divu	a4,a4,a5
    2662:	02d787b3          	mul	a5,a5,a3
    2666:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2668:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    266c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    266e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2670:	00000073          	ecall
	if (err == 0) {
    2674:	2501                	sext.w	a0,a0
    2676:	e915                	bnez	a0,26aa <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2678:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    267a:	3e800693          	li	a3,1000
    267e:	a819                	j	2694 <sleep+0x54>
	__asm_syscall("r"(a7))
    2680:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2684:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2688:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    268a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268c:	00000073          	ecall
	if (err == 0) {
    2690:	2501                	sext.w	a0,a0
    2692:	ed01                	bnez	a0,26aa <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2694:	6722                	ld	a4,8(sp)
    2696:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2698:	07c00893          	li	a7,124
    269c:	02d75733          	divu	a4,a4,a3
    26a0:	02f687b3          	mul	a5,a3,a5
    26a4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26a6:	fcc7ede3          	bltu	a5,a2,2680 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26aa:	4501                	li	a0,0
    26ac:	0141                	addi	sp,sp,16
    26ae:	8082                	ret
    26b0:	57fd                	li	a5,-1
    26b2:	bf5d                	j	2668 <sleep+0x28>

00000000000026b4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    26b4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    26b8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    26bc:	2501                	sext.w	a0,a0
    26be:	8082                	ret

00000000000026c0 <set_priority>:
	register long a7 __asm__("a7") = n;
    26c0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    26c4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    26c8:	2501                	sext.w	a0,a0
    26ca:	8082                	ret

00000000000026cc <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    26cc:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26d0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    26d4:	2501                	sext.w	a0,a0
    26d6:	8082                	ret

00000000000026d8 <munmap>:
	register long a7 __asm__("a7") = n;
    26d8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26dc:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    26e0:	2501                	sext.w	a0,a0
    26e2:	8082                	ret

00000000000026e4 <wait>:

int wait(int *code)
{
    26e4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26e6:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    26ea:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ec:	00000073          	ecall
	return waitpid(-1, code);
}
    26f0:	2501                	sext.w	a0,a0
    26f2:	8082                	ret

00000000000026f4 <spawn>:
	register long a7 __asm__("a7") = n;
    26f4:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    26f8:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    26fc:	2501                	sext.w	a0,a0
    26fe:	8082                	ret

0000000000002700 <pipe>:
	register long a7 __asm__("a7") = n;
    2700:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <mailread>:
	register long a7 __asm__("a7") = n;
    270c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2710:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2718:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    271c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2720:	2501                	sext.w	a0,a0
    2722:	8082                	ret

0000000000002724 <fstat>:
	register long a7 __asm__("a7") = n;
    2724:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2728:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    272c:	2501                	sext.w	a0,a0
    272e:	8082                	ret

0000000000002730 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2730:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2732:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2736:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2738:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    273c:	2501                	sext.w	a0,a0
    273e:	8082                	ret

0000000000002740 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2740:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2742:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2746:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2748:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    274c:	2501                	sext.w	a0,a0
    274e:	8082                	ret

0000000000002750 <link>:

int link(char *old_path, char *new_path)
{
    2750:	87aa                	mv	a5,a0
    2752:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2754:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2758:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    275c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    275e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2762:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2764:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret

000000000000276c <unlink>:

int unlink(char *path)
{
    276c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    276e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2772:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2776:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2778:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    277c:	2501                	sext.w	a0,a0
    277e:	8082                	ret

0000000000002780 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2780:	00000797          	auipc	a5,0x0
    2784:	6707b783          	ld	a5,1648(a5) # 2df0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2788:	439c                	lw	a5,0(a5)
    278a:	c799                	beqz	a5,2798 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    278c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2790:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2794:	2501                	sext.w	a0,a0
    2796:	8082                	ret
{
    2798:	1101                	addi	sp,sp,-32
    279a:	ec06                	sd	ra,24(sp)
    279c:	e42e                	sd	a1,8(sp)
    279e:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27a0:	fe7fe0ef          	jal	ra,1786 <enable_thread_io_buffer>
    27a4:	65a2                	ld	a1,8(sp)
    27a6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27a8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ac:	00000073          	ecall
}
    27b0:	60e2                	ld	ra,24(sp)
    27b2:	2501                	sext.w	a0,a0
    27b4:	6105                	addi	sp,sp,32
    27b6:	8082                	ret

00000000000027b8 <gettid>:
	register long a7 __asm__("a7") = n;
    27b8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    27bc:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    27c0:	2501                	sext.w	a0,a0
    27c2:	8082                	ret

00000000000027c4 <waittid>:

int waittid(int tid)
{
    27c4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    27c6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    27ca:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    27ce:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    27d0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27d2:	00e51e63          	bne	a0,a4,27ee <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    27d6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    27da:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    27de:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    27e2:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    27e4:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    27e8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27ea:	fee506e3          	beq	a0,a4,27d6 <waittid+0x12>
	}
	return ret;
}
    27ee:	8082                	ret

00000000000027f0 <mutex_create>:
	register long a7 __asm__("a7") = n;
    27f0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    27f4:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    27f6:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    27fa:	2501                	sext.w	a0,a0
    27fc:	8082                	ret

00000000000027fe <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    27fe:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2802:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2804:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2808:	2501                	sext.w	a0,a0
    280a:	8082                	ret

000000000000280c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    280c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2810:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2814:	2501                	sext.w	a0,a0
    2816:	8082                	ret

0000000000002818 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2818:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    281c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2820:	2501                	sext.w	a0,a0
    2822:	8082                	ret

0000000000002824 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2824:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2828:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    282c:	2501                	sext.w	a0,a0
    282e:	8082                	ret

0000000000002830 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2830:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2834:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2838:	2501                	sext.w	a0,a0
    283a:	8082                	ret

000000000000283c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    283c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2840:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2844:	2501                	sext.w	a0,a0
    2846:	8082                	ret

0000000000002848 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2848:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    284c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2850:	2501                	sext.w	a0,a0
    2852:	8082                	ret

0000000000002854 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2854:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2858:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    285c:	2501                	sext.w	a0,a0
    285e:	8082                	ret

0000000000002860 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2860:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2864:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2868:	2501                	sext.w	a0,a0
    286a:	8082                	ret

000000000000286c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    286c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2870:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2874:	2501                	sext.w	a0,a0
    2876:	8082                	ret
