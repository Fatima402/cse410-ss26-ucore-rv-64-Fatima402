
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch4_mmap2:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0c1                	j	10c0 <__start_main>

0000000000001002 <main>:
/*
理想结果：程序触发访存异常，被杀死。不输出 error 就算过。
*/

int main()
{
    1002:	1101                	addi	sp,sp,-32
	uint64 start = 0x10000000;
	uint64 len = 4096;
	int prot = 2;
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1004:	577d                	li	a4,-1
    1006:	4681                	li	a3,0
    1008:	4609                	li	a2,2
    100a:	6585                	lui	a1,0x1
    100c:	10000537          	lui	a0,0x10000
{
    1010:	ec06                	sd	ra,24(sp)
    1012:	e822                	sd	s0,16(sp)
    1014:	e426                	sd	s1,8(sp)
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1016:	564010ef          	jal	ra,257a <mmap>
    101a:	e115                	bnez	a0,103e <main+0x3c>
	uint8 *addr = (uint8 *)start;
	// *addr = (uint8)start; // can't write, R, 0 && W, 1 is illegal in riscv
	assert(*addr != 0);
    101c:	100007b7          	lui	a5,0x10000
    1020:	0007c783          	lbu	a5,0(a5) # 10000000 <.got.plt+0xfffd5c0>
    1024:	c3bd                	beqz	a5,108a <main+0x88>
	puts("Should cause error, Test 04_2 fail!");
    1026:	00001517          	auipc	a0,0x1
    102a:	7c250513          	addi	a0,a0,1986 # 27e8 <enable_deadlock_detect+0xce>
    102e:	103000ef          	jal	ra,1930 <puts>
	return 0;
}
    1032:	60e2                	ld	ra,24(sp)
    1034:	6442                	ld	s0,16(sp)
    1036:	64a2                	ld	s1,8(sp)
    1038:	4501                	li	a0,0
    103a:	6105                	addi	sp,sp,32
    103c:	8082                	ret
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    103e:	40e010ef          	jal	ra,244c <getpid>
    1042:	842a                	mv	s0,a0
    1044:	00001517          	auipc	a0,0x1
    1048:	6e450513          	addi	a0,a0,1764 # 2728 <enable_deadlock_detect+0xe>
    104c:	2d6010ef          	jal	ra,2322 <basename>
    1050:	84aa                	mv	s1,a0
    1052:	577d                	li	a4,-1
    1054:	4681                	li	a3,0
    1056:	4609                	li	a2,2
    1058:	6585                	lui	a1,0x1
    105a:	10000537          	lui	a0,0x10000
    105e:	51c010ef          	jal	ra,257a <mmap>
    1062:	88aa                	mv	a7,a0
    1064:	4801                	li	a6,0
    1066:	00001517          	auipc	a0,0x1
    106a:	71250513          	addi	a0,a0,1810 # 2778 <enable_deadlock_detect+0x5e>
    106e:	47bd                	li	a5,15
    1070:	8726                	mv	a4,s1
    1072:	86a2                	mv	a3,s0
    1074:	00001617          	auipc	a2,0x1
    1078:	6fc60613          	addi	a2,a2,1788 # 2770 <enable_deadlock_detect+0x56>
    107c:	45fd                	li	a1,31
    107e:	19c000ef          	jal	ra,121a <printf>
    1082:	557d                	li	a0,-1
    1084:	3f8010ef          	jal	ra,247c <exit>
    1088:	bf51                	j	101c <main+0x1a>
	assert(*addr != 0);
    108a:	3c2010ef          	jal	ra,244c <getpid>
    108e:	842a                	mv	s0,a0
    1090:	00001517          	auipc	a0,0x1
    1094:	69850513          	addi	a0,a0,1688 # 2728 <enable_deadlock_detect+0xe>
    1098:	28a010ef          	jal	ra,2322 <basename>
    109c:	872a                	mv	a4,a0
    109e:	47c9                	li	a5,18
    10a0:	00001517          	auipc	a0,0x1
    10a4:	71050513          	addi	a0,a0,1808 # 27b0 <enable_deadlock_detect+0x96>
    10a8:	86a2                	mv	a3,s0
    10aa:	00001617          	auipc	a2,0x1
    10ae:	6c660613          	addi	a2,a2,1734 # 2770 <enable_deadlock_detect+0x56>
    10b2:	45fd                	li	a1,31
    10b4:	166000ef          	jal	ra,121a <printf>
    10b8:	557d                	li	a0,-1
    10ba:	3c2010ef          	jal	ra,247c <exit>
    10be:	b7a5                	j	1026 <main+0x24>

00000000000010c0 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    10c0:	1141                	addi	sp,sp,-16
    10c2:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    10c4:	f3fff0ef          	jal	ra,1002 <main>
    10c8:	3b4010ef          	jal	ra,247c <exit>
	return 0;
    10cc:	60a2                	ld	ra,8(sp)
    10ce:	4501                	li	a0,0
    10d0:	0141                	addi	sp,sp,16
    10d2:	8082                	ret

00000000000010d4 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    10d4:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    10d6:	4605                	li	a2,1
    10d8:	00f10593          	addi	a1,sp,15
    10dc:	4501                	li	a0,0
{
    10de:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10e0:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10e4:	354010ef          	jal	ra,2438 <read>
    10e8:	4785                	li	a5,1
    10ea:	00f51763          	bne	a0,a5,10f8 <getchar+0x24>
		return byte;
    10ee:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10f2:	60e2                	ld	ra,24(sp)
    10f4:	6105                	addi	sp,sp,32
    10f6:	8082                	ret
		return EOF;
    10f8:	557d                	li	a0,-1
    10fa:	bfe5                	j	10f2 <getchar+0x1e>

00000000000010fc <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10fc:	00002517          	auipc	a0,0x2
    1100:	80c52503          	lw	a0,-2036(a0) # 2908 <buffer_len>
    1104:	e111                	bnez	a0,1108 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1106:	8082                	ret
{
    1108:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    110a:	862a                	mv	a2,a0
    110c:	00002597          	auipc	a1,0x2
    1110:	80458593          	addi	a1,a1,-2044 # 2910 <buffer>
    1114:	4505                	li	a0,1
{
    1116:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1118:	32a010ef          	jal	ra,2442 <write>
}
    111c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    111e:	2501                	sext.w	a0,a0
}
    1120:	0141                	addi	sp,sp,16
    1122:	8082                	ret

0000000000001124 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1124:	00001797          	auipc	a5,0x1
    1128:	7e07a223          	sw	zero,2020(a5) # 2908 <buffer_len>
}
    112c:	8082                	ret

000000000000112e <__fflush>:
	if (buffer_len == 0)
    112e:	00001517          	auipc	a0,0x1
    1132:	7da52503          	lw	a0,2010(a0) # 2908 <buffer_len>
    1136:	e511                	bnez	a0,1142 <__fflush+0x14>
	buffer_len = 0;
    1138:	00001797          	auipc	a5,0x1
    113c:	7c07a823          	sw	zero,2000(a5) # 2908 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1140:	8082                	ret
{
    1142:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1144:	862a                	mv	a2,a0
    1146:	00001597          	auipc	a1,0x1
    114a:	7ca58593          	addi	a1,a1,1994 # 2910 <buffer>
    114e:	4505                	li	a0,1
{
    1150:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1152:	2f0010ef          	jal	ra,2442 <write>
	return r >= 0 ? 0 : r;
    1156:	0005079b          	sext.w	a5,a0
}
    115a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    115c:	0017a793          	slti	a5,a5,1
    1160:	40f007bb          	negw	a5,a5
    1164:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1166:	00001797          	auipc	a5,0x1
    116a:	7a07a123          	sw	zero,1954(a5) # 2908 <buffer_len>
	return r >= 0 ? 0 : r;
    116e:	2501                	sext.w	a0,a0
}
    1170:	0141                	addi	sp,sp,16
    1172:	8082                	ret

0000000000001174 <fflush>:

int fflush(int fd)
{
    1174:	1101                	addi	sp,sp,-32
    1176:	e822                	sd	s0,16(sp)
    1178:	ec06                	sd	ra,24(sp)
    117a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    117c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    117e:	4401                	li	s0,0
	if (fd == 1) {
    1180:	00e50863          	beq	a0,a4,1190 <fflush+0x1c>
}
    1184:	60e2                	ld	ra,24(sp)
    1186:	8522                	mv	a0,s0
    1188:	6442                	ld	s0,16(sp)
    118a:	64a2                	ld	s1,8(sp)
    118c:	6105                	addi	sp,sp,32
    118e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1190:	00001497          	auipc	s1,0x1
    1194:	77848493          	addi	s1,s1,1912 # 2908 <buffer_len>
    1198:	1084a703          	lw	a4,264(s1)
    119c:	02a70e63          	beq	a4,a0,11d8 <fflush+0x64>
	if (buffer_len == 0)
    11a0:	4080                	lw	s0,0(s1)
    11a2:	c00d                	beqz	s0,11c4 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11a4:	8622                	mv	a2,s0
    11a6:	00001597          	auipc	a1,0x1
    11aa:	76a58593          	addi	a1,a1,1898 # 2910 <buffer>
    11ae:	294010ef          	jal	ra,2442 <write>
	return r >= 0 ? 0 : r;
    11b2:	0005079b          	sext.w	a5,a0
    11b6:	0017a793          	slti	a5,a5,1
    11ba:	40f007bb          	negw	a5,a5
    11be:	8d7d                	and	a0,a0,a5
    11c0:	0005041b          	sext.w	s0,a0
}
    11c4:	60e2                	ld	ra,24(sp)
    11c6:	8522                	mv	a0,s0
    11c8:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    11ca:	00001797          	auipc	a5,0x1
    11ce:	7207af23          	sw	zero,1854(a5) # 2908 <buffer_len>
}
    11d2:	64a2                	ld	s1,8(sp)
    11d4:	6105                	addi	sp,sp,32
    11d6:	8082                	ret
			mutex_lock(buffer_lock);
    11d8:	10c4a503          	lw	a0,268(s1)
    11dc:	4de010ef          	jal	ra,26ba <mutex_lock>
	if (buffer_len == 0)
    11e0:	4080                	lw	s0,0(s1)
    11e2:	e811                	bnez	s0,11f6 <fflush+0x82>
			mutex_unlock(buffer_lock);
    11e4:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11e8:	00001797          	auipc	a5,0x1
    11ec:	7207a023          	sw	zero,1824(a5) # 2908 <buffer_len>
			mutex_unlock(buffer_lock);
    11f0:	4d6010ef          	jal	ra,26c6 <mutex_unlock>
    11f4:	bf41                	j	1184 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11f6:	8622                	mv	a2,s0
    11f8:	00001597          	auipc	a1,0x1
    11fc:	71858593          	addi	a1,a1,1816 # 2910 <buffer>
    1200:	4505                	li	a0,1
    1202:	240010ef          	jal	ra,2442 <write>
	return r >= 0 ? 0 : r;
    1206:	0005079b          	sext.w	a5,a0
    120a:	0017a793          	slti	a5,a5,1
    120e:	40f007bb          	negw	a5,a5
    1212:	8d7d                	and	a0,a0,a5
    1214:	0005041b          	sext.w	s0,a0
	return r;
    1218:	b7f1                	j	11e4 <fflush+0x70>

000000000000121a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    121a:	7131                	addi	sp,sp,-192
    121c:	e0da                	sd	s6,64(sp)
    121e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1220:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1222:	013c                	addi	a5,sp,136
{
    1224:	f0ca                	sd	s2,96(sp)
    1226:	ecce                	sd	s3,88(sp)
    1228:	e8d2                	sd	s4,80(sp)
    122a:	e4d6                	sd	s5,72(sp)
    122c:	fc86                	sd	ra,120(sp)
    122e:	f8a2                	sd	s0,112(sp)
    1230:	f4a6                	sd	s1,104(sp)
    1232:	89aa                	mv	s3,a0
    1234:	e52e                	sd	a1,136(sp)
    1236:	e932                	sd	a2,144(sp)
    1238:	ed36                	sd	a3,152(sp)
    123a:	f13a                	sd	a4,160(sp)
    123c:	f942                	sd	a6,176(sp)
    123e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1240:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1242:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1246:	00001a17          	auipc	s4,0x1
    124a:	6c2a0a13          	addi	s4,s4,1730 # 2908 <buffer_len>
    124e:	4a85                	li	s5,1
	buf[i++] = '0';
    1250:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1254:	0009c783          	lbu	a5,0(s3)
    1258:	18078663          	beqz	a5,13e4 <printf+0x1ca>
    125c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    125e:	19278d63          	beq	a5,s2,13f8 <printf+0x1de>
    1262:	0015c783          	lbu	a5,1(a1)
    1266:	0585                	addi	a1,a1,1
    1268:	fbfd                	bnez	a5,125e <printf+0x44>
    126a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    126c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1270:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1274:	1b578863          	beq	a5,s5,1424 <printf+0x20a>
		len = out_unlocked(s, l);
    1278:	85a2                	mv	a1,s0
    127a:	854e                	mv	a0,s3
    127c:	42a000ef          	jal	ra,16a6 <out_unlocked>
		out(f, a, l);
		if (l)
    1280:	1c041063          	bnez	s0,1440 <printf+0x226>
			continue;
		if (s[1] == 0)
    1284:	0014c783          	lbu	a5,1(s1)
    1288:	14078e63          	beqz	a5,13e4 <printf+0x1ca>
			break;
		switch (s[1]) {
    128c:	07300713          	li	a4,115
    1290:	1ce78863          	beq	a5,a4,1460 <printf+0x246>
    1294:	1af76863          	bltu	a4,a5,1444 <printf+0x22a>
    1298:	06400713          	li	a4,100
    129c:	22e78063          	beq	a5,a4,14bc <printf+0x2a2>
    12a0:	07000713          	li	a4,112
    12a4:	1ee79563          	bne	a5,a4,148e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12a8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12aa:	00001797          	auipc	a5,0x1
    12ae:	76e78793          	addi	a5,a5,1902 # 2a18 <digits>
	buf[i++] = '0';
    12b2:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12b6:	6298                	ld	a4,0(a3)
    12b8:	06a1                	addi	a3,a3,8
    12ba:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12bc:	00471393          	slli	t2,a4,0x4
    12c0:	00871293          	slli	t0,a4,0x8
    12c4:	00c71f93          	slli	t6,a4,0xc
    12c8:	01071f13          	slli	t5,a4,0x10
    12cc:	01471e93          	slli	t4,a4,0x14
    12d0:	01871e13          	slli	t3,a4,0x18
    12d4:	01c71893          	slli	a7,a4,0x1c
    12d8:	02471813          	slli	a6,a4,0x24
    12dc:	02871513          	slli	a0,a4,0x28
    12e0:	02c71593          	slli	a1,a4,0x2c
    12e4:	03071613          	slli	a2,a4,0x30
    12e8:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12ec:	03c75413          	srli	s0,a4,0x3c
    12f0:	01c7531b          	srliw	t1,a4,0x1c
    12f4:	03c3d393          	srli	t2,t2,0x3c
    12f8:	03c2d293          	srli	t0,t0,0x3c
    12fc:	03cfdf93          	srli	t6,t6,0x3c
    1300:	03cf5f13          	srli	t5,t5,0x3c
    1304:	03cede93          	srli	t4,t4,0x3c
    1308:	03ce5e13          	srli	t3,t3,0x3c
    130c:	03c8d893          	srli	a7,a7,0x3c
    1310:	03c85813          	srli	a6,a6,0x3c
    1314:	9171                	srli	a0,a0,0x3c
    1316:	91f1                	srli	a1,a1,0x3c
    1318:	9271                	srli	a2,a2,0x3c
    131a:	92f1                	srli	a3,a3,0x3c
    131c:	95be                	add	a1,a1,a5
    131e:	963e                	add	a2,a2,a5
    1320:	96be                	add	a3,a3,a5
    1322:	943e                	add	s0,s0,a5
    1324:	93be                	add	t2,t2,a5
    1326:	92be                	add	t0,t0,a5
    1328:	9fbe                	add	t6,t6,a5
    132a:	9f3e                	add	t5,t5,a5
    132c:	9ebe                	add	t4,t4,a5
    132e:	9e3e                	add	t3,t3,a5
    1330:	98be                	add	a7,a7,a5
    1332:	933e                	add	t1,t1,a5
    1334:	983e                	add	a6,a6,a5
    1336:	953e                	add	a0,a0,a5
    1338:	0005c983          	lbu	s3,0(a1)
    133c:	00044403          	lbu	s0,0(s0)
    1340:	00064583          	lbu	a1,0(a2)
    1344:	0003c383          	lbu	t2,0(t2)
    1348:	0006c603          	lbu	a2,0(a3)
    134c:	0002c283          	lbu	t0,0(t0)
    1350:	000fcf83          	lbu	t6,0(t6)
    1354:	000f4f03          	lbu	t5,0(t5)
    1358:	000ece83          	lbu	t4,0(t4)
    135c:	000e4e03          	lbu	t3,0(t3)
    1360:	0008c883          	lbu	a7,0(a7)
    1364:	00034303          	lbu	t1,0(t1)
    1368:	00084803          	lbu	a6,0(a6)
    136c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1370:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1374:	92f1                	srli	a3,a3,0x3c
    1376:	8b3d                	andi	a4,a4,15
    1378:	96be                	add	a3,a3,a5
    137a:	97ba                	add	a5,a5,a4
    137c:	00810d23          	sb	s0,26(sp)
    1380:	00710da3          	sb	t2,27(sp)
    1384:	00510e23          	sb	t0,28(sp)
    1388:	01f10ea3          	sb	t6,29(sp)
    138c:	01e10f23          	sb	t5,30(sp)
    1390:	01d10fa3          	sb	t4,31(sp)
    1394:	03c10023          	sb	t3,32(sp)
    1398:	031100a3          	sb	a7,33(sp)
    139c:	02610123          	sb	t1,34(sp)
    13a0:	030101a3          	sb	a6,35(sp)
    13a4:	02a10223          	sb	a0,36(sp)
    13a8:	033102a3          	sb	s3,37(sp)
    13ac:	02b10323          	sb	a1,38(sp)
    13b0:	02c103a3          	sb	a2,39(sp)
    13b4:	0006c683          	lbu	a3,0(a3)
    13b8:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    13bc:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13c0:	02d10423          	sb	a3,40(sp)
    13c4:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    13c8:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    13cc:	11578263          	beq	a5,s5,14d0 <printf+0x2b6>
		len = out_unlocked(s, l);
    13d0:	45c9                	li	a1,18
    13d2:	0828                	addi	a0,sp,24
    13d4:	2d2000ef          	jal	ra,16a6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13d8:	00248993          	addi	s3,s1,2
		if (!*s)
    13dc:	0009c783          	lbu	a5,0(s3)
    13e0:	e6079ee3          	bnez	a5,125c <printf+0x42>
	}
	va_end(ap);
    13e4:	70e6                	ld	ra,120(sp)
    13e6:	7446                	ld	s0,112(sp)
    13e8:	74a6                	ld	s1,104(sp)
    13ea:	7906                	ld	s2,96(sp)
    13ec:	69e6                	ld	s3,88(sp)
    13ee:	6a46                	ld	s4,80(sp)
    13f0:	6aa6                	ld	s5,72(sp)
    13f2:	6b06                	ld	s6,64(sp)
    13f4:	6129                	addi	sp,sp,192
    13f6:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13f8:	0005c783          	lbu	a5,0(a1)
    13fc:	84ae                	mv	s1,a1
    13fe:	01278963          	beq	a5,s2,1410 <printf+0x1f6>
    1402:	b5ad                	j	126c <printf+0x52>
    1404:	0024c783          	lbu	a5,2(s1)
    1408:	0585                	addi	a1,a1,1
    140a:	0489                	addi	s1,s1,2
    140c:	e72790e3          	bne	a5,s2,126c <printf+0x52>
    1410:	0014c783          	lbu	a5,1(s1)
    1414:	ff2788e3          	beq	a5,s2,1404 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1418:	108a2783          	lw	a5,264(s4)
		l = z - a;
    141c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1420:	e5579ce3          	bne	a5,s5,1278 <printf+0x5e>
		mutex_lock(buffer_lock);
    1424:	10ca2503          	lw	a0,268(s4)
    1428:	292010ef          	jal	ra,26ba <mutex_lock>
		len = out_unlocked(s, l);
    142c:	85a2                	mv	a1,s0
    142e:	854e                	mv	a0,s3
    1430:	276000ef          	jal	ra,16a6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1434:	10ca2503          	lw	a0,268(s4)
    1438:	28e010ef          	jal	ra,26c6 <mutex_unlock>
		if (l)
    143c:	e40404e3          	beqz	s0,1284 <printf+0x6a>
    1440:	89a6                	mv	s3,s1
    1442:	bd09                	j	1254 <printf+0x3a>
		switch (s[1]) {
    1444:	07800713          	li	a4,120
    1448:	04e79363          	bne	a5,a4,148e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    144c:	67c2                	ld	a5,16(sp)
    144e:	45c1                	li	a1,16
		s += 2;
    1450:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1454:	4388                	lw	a0,0(a5)
    1456:	07a1                	addi	a5,a5,8
    1458:	e83e                	sd	a5,16(sp)
    145a:	5f8000ef          	jal	ra,1a52 <printint.constprop.0>
		s += 2;
    145e:	bfbd                	j	13dc <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1460:	67c2                	ld	a5,16(sp)
    1462:	6380                	ld	s0,0(a5)
    1464:	07a1                	addi	a5,a5,8
    1466:	e83e                	sd	a5,16(sp)
    1468:	1c040163          	beqz	s0,162a <printf+0x410>
			l = strnlen(a, 200);
    146c:	0c800593          	li	a1,200
    1470:	8522                	mv	a0,s0
    1472:	3f7000ef          	jal	ra,2068 <strnlen>
	if (buffer_lock_enabled == 1) {
    1476:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    147a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    147e:	19578663          	beq	a5,s5,160a <printf+0x3f0>
		len = out_unlocked(s, l);
    1482:	8522                	mv	a0,s0
    1484:	222000ef          	jal	ra,16a6 <out_unlocked>
		s += 2;
    1488:	00248993          	addi	s3,s1,2
    148c:	bf81                	j	13dc <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    148e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1492:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1496:	0f578663          	beq	a5,s5,1582 <printf+0x368>
		len = out_unlocked(s, l);
    149a:	0828                	addi	a0,sp,24
    149c:	316000ef          	jal	ra,17b2 <out_unlocked.constprop.0>
			putchar(s[1]);
    14a0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14a4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14a8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14ac:	05578163          	beq	a5,s5,14ee <printf+0x2d4>
		len = out_unlocked(s, l);
    14b0:	0828                	addi	a0,sp,24
    14b2:	300000ef          	jal	ra,17b2 <out_unlocked.constprop.0>
		s += 2;
    14b6:	00248993          	addi	s3,s1,2
    14ba:	b70d                	j	13dc <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    14bc:	67c2                	ld	a5,16(sp)
    14be:	45a9                	li	a1,10
		s += 2;
    14c0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    14c4:	4388                	lw	a0,0(a5)
    14c6:	07a1                	addi	a5,a5,8
    14c8:	e83e                	sd	a5,16(sp)
    14ca:	588000ef          	jal	ra,1a52 <printint.constprop.0>
		s += 2;
    14ce:	b739                	j	13dc <printf+0x1c2>
		mutex_lock(buffer_lock);
    14d0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14d4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14d8:	1e2010ef          	jal	ra,26ba <mutex_lock>
		len = out_unlocked(s, l);
    14dc:	45c9                	li	a1,18
    14de:	0828                	addi	a0,sp,24
    14e0:	1c6000ef          	jal	ra,16a6 <out_unlocked>
		mutex_unlock(buffer_lock);
    14e4:	10ca2503          	lw	a0,268(s4)
    14e8:	1de010ef          	jal	ra,26c6 <mutex_unlock>
		s += 2;
    14ec:	bdc5                	j	13dc <printf+0x1c2>
		mutex_lock(buffer_lock);
    14ee:	10ca2503          	lw	a0,268(s4)
    14f2:	1c8010ef          	jal	ra,26ba <mutex_lock>
		buffer[buffer_len++] = c;
    14f6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14fa:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14fe:	0017861b          	addiw	a2,a5,1
    1502:	97d2                	add	a5,a5,s4
    1504:	00ca2023          	sw	a2,0(s4)
    1508:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    150c:	00c6cc63          	blt	a3,a2,1524 <printf+0x30a>
    1510:	47a9                	li	a5,10
    1512:	06f40663          	beq	s0,a5,157e <printf+0x364>
		mutex_unlock(buffer_lock);
    1516:	10ca2503          	lw	a0,268(s4)
		s += 2;
    151a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    151e:	1a8010ef          	jal	ra,26c6 <mutex_unlock>
		s += 2;
    1522:	bd6d                	j	13dc <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1524:	10000793          	li	a5,256
    1528:	00f61e63          	bne	a2,a5,1544 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    152c:	00001597          	auipc	a1,0x1
    1530:	3e458593          	addi	a1,a1,996 # 2910 <buffer>
    1534:	4505                	li	a0,1
    1536:	70d000ef          	jal	ra,2442 <write>
	buffer_len = 0;
    153a:	00001797          	auipc	a5,0x1
    153e:	3c07a723          	sw	zero,974(a5) # 2908 <buffer_len>
			if (r < 0) {
    1542:	bfd1                	j	1516 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1544:	709000ef          	jal	ra,244c <getpid>
    1548:	842a                	mv	s0,a0
    154a:	00001517          	auipc	a0,0x1
    154e:	2ce50513          	addi	a0,a0,718 # 2818 <enable_deadlock_detect+0xfe>
    1552:	5d1000ef          	jal	ra,2322 <basename>
    1556:	872a                	mv	a4,a0
    1558:	00001617          	auipc	a2,0x1
    155c:	21860613          	addi	a2,a2,536 # 2770 <enable_deadlock_detect+0x56>
    1560:	05400793          	li	a5,84
    1564:	86a2                	mv	a3,s0
    1566:	45fd                	li	a1,31
    1568:	00001517          	auipc	a0,0x1
    156c:	2f050513          	addi	a0,a0,752 # 2858 <enable_deadlock_detect+0x13e>
    1570:	cabff0ef          	jal	ra,121a <printf>
    1574:	557d                	li	a0,-1
    1576:	707000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    157a:	000a2603          	lw	a2,0(s4)
    157e:	de41                	beqz	a2,1516 <printf+0x2fc>
    1580:	b775                	j	152c <printf+0x312>
		mutex_lock(buffer_lock);
    1582:	10ca2503          	lw	a0,268(s4)
    1586:	134010ef          	jal	ra,26ba <mutex_lock>
		buffer[buffer_len++] = c;
    158a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    158e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1592:	0017861b          	addiw	a2,a5,1
    1596:	97d2                	add	a5,a5,s4
    1598:	00ca2023          	sw	a2,0(s4)
    159c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15a0:	02c6d163          	bge	a3,a2,15c2 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15a4:	10000793          	li	a5,256
    15a8:	02f61263          	bne	a2,a5,15cc <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15ac:	00001597          	auipc	a1,0x1
    15b0:	36458593          	addi	a1,a1,868 # 2910 <buffer>
    15b4:	4505                	li	a0,1
    15b6:	68d000ef          	jal	ra,2442 <write>
	buffer_len = 0;
    15ba:	00001797          	auipc	a5,0x1
    15be:	3407a723          	sw	zero,846(a5) # 2908 <buffer_len>
		mutex_unlock(buffer_lock);
    15c2:	10ca2503          	lw	a0,268(s4)
    15c6:	100010ef          	jal	ra,26c6 <mutex_unlock>
    15ca:	bdd9                	j	14a0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    15cc:	681000ef          	jal	ra,244c <getpid>
    15d0:	842a                	mv	s0,a0
    15d2:	00001517          	auipc	a0,0x1
    15d6:	24650513          	addi	a0,a0,582 # 2818 <enable_deadlock_detect+0xfe>
    15da:	549000ef          	jal	ra,2322 <basename>
    15de:	872a                	mv	a4,a0
    15e0:	00001617          	auipc	a2,0x1
    15e4:	19060613          	addi	a2,a2,400 # 2770 <enable_deadlock_detect+0x56>
    15e8:	05400793          	li	a5,84
    15ec:	86a2                	mv	a3,s0
    15ee:	45fd                	li	a1,31
    15f0:	00001517          	auipc	a0,0x1
    15f4:	26850513          	addi	a0,a0,616 # 2858 <enable_deadlock_detect+0x13e>
    15f8:	c23ff0ef          	jal	ra,121a <printf>
    15fc:	557d                	li	a0,-1
    15fe:	67f000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    1602:	000a2603          	lw	a2,0(s4)
    1606:	de55                	beqz	a2,15c2 <printf+0x3a8>
    1608:	b755                	j	15ac <printf+0x392>
		mutex_lock(buffer_lock);
    160a:	10ca2503          	lw	a0,268(s4)
    160e:	e42e                	sd	a1,8(sp)
		s += 2;
    1610:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1614:	0a6010ef          	jal	ra,26ba <mutex_lock>
		len = out_unlocked(s, l);
    1618:	65a2                	ld	a1,8(sp)
    161a:	8522                	mv	a0,s0
    161c:	08a000ef          	jal	ra,16a6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1620:	10ca2503          	lw	a0,268(s4)
    1624:	0a2010ef          	jal	ra,26c6 <mutex_unlock>
		s += 2;
    1628:	bb55                	j	13dc <printf+0x1c2>
				a = "(null)";
    162a:	00001417          	auipc	s0,0x1
    162e:	1e640413          	addi	s0,s0,486 # 2810 <enable_deadlock_detect+0xf6>
    1632:	bd2d                	j	146c <printf+0x252>

0000000000001634 <enable_thread_io_buffer>:
{
    1634:	1101                	addi	sp,sp,-32
    1636:	e822                	sd	s0,16(sp)
    1638:	ec06                	sd	ra,24(sp)
    163a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    163c:	00001417          	auipc	s0,0x1
    1640:	2cc40413          	addi	s0,s0,716 # 2908 <buffer_len>
    1644:	05a010ef          	jal	ra,269e <mutex_create>
    1648:	10a42623          	sw	a0,268(s0)
    164c:	00054a63          	bltz	a0,1660 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1650:	4785                	li	a5,1
}
    1652:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1654:	10f42423          	sw	a5,264(s0)
}
    1658:	6442                	ld	s0,16(sp)
    165a:	64a2                	ld	s1,8(sp)
    165c:	6105                	addi	sp,sp,32
    165e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1660:	5ed000ef          	jal	ra,244c <getpid>
    1664:	84aa                	mv	s1,a0
    1666:	00001517          	auipc	a0,0x1
    166a:	1b250513          	addi	a0,a0,434 # 2818 <enable_deadlock_detect+0xfe>
    166e:	4b5000ef          	jal	ra,2322 <basename>
    1672:	872a                	mv	a4,a0
    1674:	04800793          	li	a5,72
    1678:	86a6                	mv	a3,s1
    167a:	00001517          	auipc	a0,0x1
    167e:	21e50513          	addi	a0,a0,542 # 2898 <enable_deadlock_detect+0x17e>
    1682:	00001617          	auipc	a2,0x1
    1686:	0ee60613          	addi	a2,a2,238 # 2770 <enable_deadlock_detect+0x56>
    168a:	45fd                	li	a1,31
    168c:	b8fff0ef          	jal	ra,121a <printf>
    1690:	557d                	li	a0,-1
    1692:	5eb000ef          	jal	ra,247c <exit>
	buffer_lock_enabled = 1;
    1696:	4785                	li	a5,1
}
    1698:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    169a:	10f42423          	sw	a5,264(s0)
}
    169e:	6442                	ld	s0,16(sp)
    16a0:	64a2                	ld	s1,8(sp)
    16a2:	6105                	addi	sp,sp,32
    16a4:	8082                	ret

00000000000016a6 <out_unlocked>:
{
    16a6:	7159                	addi	sp,sp,-112
    16a8:	f486                	sd	ra,104(sp)
    16aa:	f0a2                	sd	s0,96(sp)
    16ac:	eca6                	sd	s1,88(sp)
    16ae:	e8ca                	sd	s2,80(sp)
    16b0:	e4ce                	sd	s3,72(sp)
    16b2:	e0d2                	sd	s4,64(sp)
    16b4:	fc56                	sd	s5,56(sp)
    16b6:	f85a                	sd	s6,48(sp)
    16b8:	f45e                	sd	s7,40(sp)
    16ba:	f062                	sd	s8,32(sp)
    16bc:	ec66                	sd	s9,24(sp)
    16be:	e86a                	sd	s10,16(sp)
    16c0:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    16c2:	0e058663          	beqz	a1,17ae <out_unlocked+0x108>
    16c6:	842a                	mv	s0,a0
    16c8:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    16cc:	4981                	li	s3,0
    16ce:	00001d17          	auipc	s10,0x1
    16d2:	23ad0d13          	addi	s10,s10,570 # 2908 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16d6:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16da:	00001b17          	auipc	s6,0x1
    16de:	236b0b13          	addi	s6,s6,566 # 2910 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16e2:	10000a93          	li	s5,256
    16e6:	00001c97          	auipc	s9,0x1
    16ea:	132c8c93          	addi	s9,s9,306 # 2818 <enable_deadlock_detect+0xfe>
    16ee:	00001c17          	auipc	s8,0x1
    16f2:	082c0c13          	addi	s8,s8,130 # 2770 <enable_deadlock_detect+0x56>
    16f6:	00001b97          	auipc	s7,0x1
    16fa:	162b8b93          	addi	s7,s7,354 # 2858 <enable_deadlock_detect+0x13e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16fe:	4a29                	li	s4,10
    1700:	a031                	j	170c <out_unlocked+0x66>
    1702:	09468863          	beq	a3,s4,1792 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1706:	0405                	addi	s0,s0,1
    1708:	04848163          	beq	s1,s0,174a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    170c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1710:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1714:	0017861b          	addiw	a2,a5,1
    1718:	97ea                	add	a5,a5,s10
    171a:	00cd2023          	sw	a2,0(s10)
    171e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1722:	fec950e3          	bge	s2,a2,1702 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1726:	05561263          	bne	a2,s5,176a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    172a:	85da                	mv	a1,s6
    172c:	4505                	li	a0,1
    172e:	515000ef          	jal	ra,2442 <write>
    1732:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1734:	00001797          	auipc	a5,0x1
    1738:	1c07aa23          	sw	zero,468(a5) # 2908 <buffer_len>
			if (r < 0) {
    173c:	06054763          	bltz	a0,17aa <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1740:	0405                	addi	s0,s0,1
			ret += r;
    1742:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1746:	fc8493e3          	bne	s1,s0,170c <out_unlocked+0x66>
}
    174a:	70a6                	ld	ra,104(sp)
    174c:	7406                	ld	s0,96(sp)
    174e:	64e6                	ld	s1,88(sp)
    1750:	6946                	ld	s2,80(sp)
    1752:	6a06                	ld	s4,64(sp)
    1754:	7ae2                	ld	s5,56(sp)
    1756:	7b42                	ld	s6,48(sp)
    1758:	7ba2                	ld	s7,40(sp)
    175a:	7c02                	ld	s8,32(sp)
    175c:	6ce2                	ld	s9,24(sp)
    175e:	6d42                	ld	s10,16(sp)
    1760:	6da2                	ld	s11,8(sp)
    1762:	854e                	mv	a0,s3
    1764:	69a6                	ld	s3,72(sp)
    1766:	6165                	addi	sp,sp,112
    1768:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    176a:	4e3000ef          	jal	ra,244c <getpid>
    176e:	8daa                	mv	s11,a0
    1770:	8566                	mv	a0,s9
    1772:	3b1000ef          	jal	ra,2322 <basename>
    1776:	872a                	mv	a4,a0
    1778:	8662                	mv	a2,s8
    177a:	05400793          	li	a5,84
    177e:	86ee                	mv	a3,s11
    1780:	45fd                	li	a1,31
    1782:	855e                	mv	a0,s7
    1784:	a97ff0ef          	jal	ra,121a <printf>
    1788:	557d                	li	a0,-1
    178a:	4f3000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    178e:	000d2603          	lw	a2,0(s10)
    1792:	da35                	beqz	a2,1706 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1794:	85da                	mv	a1,s6
    1796:	4505                	li	a0,1
    1798:	4ab000ef          	jal	ra,2442 <write>
    179c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    179e:	00001797          	auipc	a5,0x1
    17a2:	1607a523          	sw	zero,362(a5) # 2908 <buffer_len>
			if (r < 0) {
    17a6:	f8055de3          	bgez	a0,1740 <out_unlocked+0x9a>
    17aa:	89aa                	mv	s3,a0
    17ac:	bf79                	j	174a <out_unlocked+0xa4>
	int ret = 0;
    17ae:	4981                	li	s3,0
    17b0:	bf69                	j	174a <out_unlocked+0xa4>

00000000000017b2 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17b2:	1101                	addi	sp,sp,-32
    17b4:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17b6:	00001497          	auipc	s1,0x1
    17ba:	15248493          	addi	s1,s1,338 # 2908 <buffer_len>
    17be:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    17c0:	ec06                	sd	ra,24(sp)
    17c2:	e822                	sd	s0,16(sp)
		char c = s[i];
    17c4:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    17c8:	0017861b          	addiw	a2,a5,1
    17cc:	97a6                	add	a5,a5,s1
    17ce:	00e78423          	sb	a4,8(a5)
    17d2:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17d4:	0ff00793          	li	a5,255
    17d8:	00c7cc63          	blt	a5,a2,17f0 <out_unlocked.constprop.0+0x3e>
    17dc:	47a9                	li	a5,10
    17de:	06f70c63          	beq	a4,a5,1856 <out_unlocked.constprop.0+0xa4>
    17e2:	4601                	li	a2,0
}
    17e4:	60e2                	ld	ra,24(sp)
    17e6:	6442                	ld	s0,16(sp)
    17e8:	64a2                	ld	s1,8(sp)
    17ea:	8532                	mv	a0,a2
    17ec:	6105                	addi	sp,sp,32
    17ee:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17f0:	10000793          	li	a5,256
    17f4:	02f61563          	bne	a2,a5,181e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17f8:	00001597          	auipc	a1,0x1
    17fc:	11858593          	addi	a1,a1,280 # 2910 <buffer>
    1800:	4505                	li	a0,1
    1802:	441000ef          	jal	ra,2442 <write>
}
    1806:	60e2                	ld	ra,24(sp)
    1808:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    180a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    180e:	00001797          	auipc	a5,0x1
    1812:	0e07ad23          	sw	zero,250(a5) # 2908 <buffer_len>
}
    1816:	64a2                	ld	s1,8(sp)
    1818:	8532                	mv	a0,a2
    181a:	6105                	addi	sp,sp,32
    181c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    181e:	42f000ef          	jal	ra,244c <getpid>
    1822:	842a                	mv	s0,a0
    1824:	00001517          	auipc	a0,0x1
    1828:	ff450513          	addi	a0,a0,-12 # 2818 <enable_deadlock_detect+0xfe>
    182c:	2f7000ef          	jal	ra,2322 <basename>
    1830:	872a                	mv	a4,a0
    1832:	00001617          	auipc	a2,0x1
    1836:	f3e60613          	addi	a2,a2,-194 # 2770 <enable_deadlock_detect+0x56>
    183a:	05400793          	li	a5,84
    183e:	86a2                	mv	a3,s0
    1840:	45fd                	li	a1,31
    1842:	00001517          	auipc	a0,0x1
    1846:	01650513          	addi	a0,a0,22 # 2858 <enable_deadlock_detect+0x13e>
    184a:	9d1ff0ef          	jal	ra,121a <printf>
    184e:	557d                	li	a0,-1
    1850:	42d000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    1854:	4090                	lw	a2,0(s1)
    1856:	d659                	beqz	a2,17e4 <out_unlocked.constprop.0+0x32>
    1858:	b745                	j	17f8 <out_unlocked.constprop.0+0x46>

000000000000185a <putchar>:
{
    185a:	7139                	addi	sp,sp,-64
    185c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    185e:	00001497          	auipc	s1,0x1
    1862:	0aa48493          	addi	s1,s1,170 # 2908 <buffer_len>
    1866:	1084a703          	lw	a4,264(s1)
{
    186a:	f822                	sd	s0,48(sp)
	char byte = c;
    186c:	0ff57413          	zext.b	s0,a0
{
    1870:	fc06                	sd	ra,56(sp)
	char byte = c;
    1872:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1876:	4785                	li	a5,1
    1878:	00f70d63          	beq	a4,a5,1892 <putchar+0x38>
		len = out_unlocked(s, l);
    187c:	01f10513          	addi	a0,sp,31
    1880:	f33ff0ef          	jal	ra,17b2 <out_unlocked.constprop.0>
}
    1884:	70e2                	ld	ra,56(sp)
    1886:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1888:	862a                	mv	a2,a0
}
    188a:	74a2                	ld	s1,40(sp)
    188c:	8532                	mv	a0,a2
    188e:	6121                	addi	sp,sp,64
    1890:	8082                	ret
		mutex_lock(buffer_lock);
    1892:	10c4a503          	lw	a0,268(s1)
    1896:	625000ef          	jal	ra,26ba <mutex_lock>
		buffer[buffer_len++] = c;
    189a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    189c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18a0:	0017861b          	addiw	a2,a5,1
    18a4:	97a6                	add	a5,a5,s1
    18a6:	c090                	sw	a2,0(s1)
    18a8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ac:	02c6c263          	blt	a3,a2,18d0 <putchar+0x76>
    18b0:	47a9                	li	a5,10
    18b2:	06f40d63          	beq	s0,a5,192c <putchar+0xd2>
    18b6:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18b8:	10c4a503          	lw	a0,268(s1)
    18bc:	e432                	sd	a2,8(sp)
    18be:	609000ef          	jal	ra,26c6 <mutex_unlock>
    18c2:	6622                	ld	a2,8(sp)
}
    18c4:	70e2                	ld	ra,56(sp)
    18c6:	7442                	ld	s0,48(sp)
    18c8:	74a2                	ld	s1,40(sp)
    18ca:	8532                	mv	a0,a2
    18cc:	6121                	addi	sp,sp,64
    18ce:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18d0:	10000793          	li	a5,256
    18d4:	02f61063          	bne	a2,a5,18f4 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18d8:	00001597          	auipc	a1,0x1
    18dc:	03858593          	addi	a1,a1,56 # 2910 <buffer>
    18e0:	4505                	li	a0,1
    18e2:	361000ef          	jal	ra,2442 <write>
    18e6:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18ea:	00001797          	auipc	a5,0x1
    18ee:	0007af23          	sw	zero,30(a5) # 2908 <buffer_len>
			if (r < 0) {
    18f2:	b7d9                	j	18b8 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18f4:	359000ef          	jal	ra,244c <getpid>
    18f8:	842a                	mv	s0,a0
    18fa:	00001517          	auipc	a0,0x1
    18fe:	f1e50513          	addi	a0,a0,-226 # 2818 <enable_deadlock_detect+0xfe>
    1902:	221000ef          	jal	ra,2322 <basename>
    1906:	872a                	mv	a4,a0
    1908:	00001617          	auipc	a2,0x1
    190c:	e6860613          	addi	a2,a2,-408 # 2770 <enable_deadlock_detect+0x56>
    1910:	05400793          	li	a5,84
    1914:	86a2                	mv	a3,s0
    1916:	45fd                	li	a1,31
    1918:	00001517          	auipc	a0,0x1
    191c:	f4050513          	addi	a0,a0,-192 # 2858 <enable_deadlock_detect+0x13e>
    1920:	8fbff0ef          	jal	ra,121a <printf>
    1924:	557d                	li	a0,-1
    1926:	357000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    192a:	4090                	lw	a2,0(s1)
    192c:	d651                	beqz	a2,18b8 <putchar+0x5e>
    192e:	b76d                	j	18d8 <putchar+0x7e>

0000000000001930 <puts>:
{
    1930:	7139                	addi	sp,sp,-64
    1932:	f822                	sd	s0,48(sp)
    1934:	f426                	sd	s1,40(sp)
    1936:	fc06                	sd	ra,56(sp)
    1938:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    193a:	00001417          	auipc	s0,0x1
    193e:	fce40413          	addi	s0,s0,-50 # 2908 <buffer_len>
{
    1942:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1944:	638000ef          	jal	ra,1f7c <strlen>
	if (buffer_lock_enabled == 1) {
    1948:	10842703          	lw	a4,264(s0)
    194c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    194e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1950:	04f70563          	beq	a4,a5,199a <puts+0x6a>
		len = out_unlocked(s, l);
    1954:	8526                	mv	a0,s1
    1956:	d51ff0ef          	jal	ra,16a6 <out_unlocked>
    195a:	892a                	mv	s2,a0
    195c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    195e:	00095963          	bgez	s2,1970 <puts+0x40>
}
    1962:	70e2                	ld	ra,56(sp)
    1964:	7442                	ld	s0,48(sp)
    1966:	7902                	ld	s2,32(sp)
    1968:	8526                	mv	a0,s1
    196a:	74a2                	ld	s1,40(sp)
    196c:	6121                	addi	sp,sp,64
    196e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1970:	10842703          	lw	a4,264(s0)
	char byte = c;
    1974:	44a9                	li	s1,10
    1976:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    197a:	4785                	li	a5,1
    197c:	02f70e63          	beq	a4,a5,19b8 <puts+0x88>
		len = out_unlocked(s, l);
    1980:	01f10513          	addi	a0,sp,31
    1984:	e2fff0ef          	jal	ra,17b2 <out_unlocked.constprop.0>
}
    1988:	70e2                	ld	ra,56(sp)
    198a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    198c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1990:	7902                	ld	s2,32(sp)
    1992:	8526                	mv	a0,s1
    1994:	74a2                	ld	s1,40(sp)
    1996:	6121                	addi	sp,sp,64
    1998:	8082                	ret
		mutex_lock(buffer_lock);
    199a:	e42a                	sd	a0,8(sp)
    199c:	10c42503          	lw	a0,268(s0)
    19a0:	51b000ef          	jal	ra,26ba <mutex_lock>
		len = out_unlocked(s, l);
    19a4:	65a2                	ld	a1,8(sp)
    19a6:	8526                	mv	a0,s1
    19a8:	cffff0ef          	jal	ra,16a6 <out_unlocked>
    19ac:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19ae:	10c42503          	lw	a0,268(s0)
    19b2:	515000ef          	jal	ra,26c6 <mutex_unlock>
    19b6:	b75d                	j	195c <puts+0x2c>
		mutex_lock(buffer_lock);
    19b8:	10c42503          	lw	a0,268(s0)
    19bc:	4ff000ef          	jal	ra,26ba <mutex_lock>
		buffer[buffer_len++] = c;
    19c0:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19c2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19c6:	0017861b          	addiw	a2,a5,1
    19ca:	97a2                	add	a5,a5,s0
    19cc:	c010                	sw	a2,0(s0)
    19ce:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d2:	06c6dc63          	bge	a3,a2,1a4a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    19d6:	10000793          	li	a5,256
    19da:	02f61c63          	bne	a2,a5,1a12 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19de:	00001597          	auipc	a1,0x1
    19e2:	f3258593          	addi	a1,a1,-206 # 2910 <buffer>
    19e6:	4505                	li	a0,1
    19e8:	25b000ef          	jal	ra,2442 <write>
			if (r < 0) {
    19ec:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19ee:	00001797          	auipc	a5,0x1
    19f2:	f007ad23          	sw	zero,-230(a5) # 2908 <buffer_len>
			if (r < 0) {
    19f6:	04054c63          	bltz	a0,1a4e <puts+0x11e>
			if (r < buffer_len) {
    19fa:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19fc:	10c42503          	lw	a0,268(s0)
    1a00:	4c7000ef          	jal	ra,26c6 <mutex_unlock>
}
    1a04:	70e2                	ld	ra,56(sp)
    1a06:	7442                	ld	s0,48(sp)
    1a08:	7902                	ld	s2,32(sp)
    1a0a:	8526                	mv	a0,s1
    1a0c:	74a2                	ld	s1,40(sp)
    1a0e:	6121                	addi	sp,sp,64
    1a10:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a12:	23b000ef          	jal	ra,244c <getpid>
    1a16:	84aa                	mv	s1,a0
    1a18:	00001517          	auipc	a0,0x1
    1a1c:	e0050513          	addi	a0,a0,-512 # 2818 <enable_deadlock_detect+0xfe>
    1a20:	103000ef          	jal	ra,2322 <basename>
    1a24:	872a                	mv	a4,a0
    1a26:	00001617          	auipc	a2,0x1
    1a2a:	d4a60613          	addi	a2,a2,-694 # 2770 <enable_deadlock_detect+0x56>
    1a2e:	05400793          	li	a5,84
    1a32:	86a6                	mv	a3,s1
    1a34:	45fd                	li	a1,31
    1a36:	00001517          	auipc	a0,0x1
    1a3a:	e2250513          	addi	a0,a0,-478 # 2858 <enable_deadlock_detect+0x13e>
    1a3e:	fdcff0ef          	jal	ra,121a <printf>
    1a42:	557d                	li	a0,-1
    1a44:	239000ef          	jal	ra,247c <exit>
	if (buffer_len == 0)
    1a48:	4010                	lw	a2,0(s0)
    1a4a:	da45                	beqz	a2,19fa <puts+0xca>
    1a4c:	bf49                	j	19de <puts+0xae>
    1a4e:	54fd                	li	s1,-1
    1a50:	b775                	j	19fc <puts+0xcc>

0000000000001a52 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a52:	715d                	addi	sp,sp,-80
    1a54:	e486                	sd	ra,72(sp)
    1a56:	e0a2                	sd	s0,64(sp)
    1a58:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a5a:	14054363          	bltz	a0,1ba0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a5e:	02b577bb          	remuw	a5,a0,a1
    1a62:	00001617          	auipc	a2,0x1
    1a66:	fb660613          	addi	a2,a2,-74 # 2a18 <digits>
	buf[16] = 0;
    1a6a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a6e:	0005871b          	sext.w	a4,a1
    1a72:	1782                	slli	a5,a5,0x20
    1a74:	9381                	srli	a5,a5,0x20
    1a76:	97b2                	add	a5,a5,a2
    1a78:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a7c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a80:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a84:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a86:	0eb56763          	bltu	a0,a1,1b74 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a8a:	02e877bb          	remuw	a5,a6,a4
    1a8e:	1782                	slli	a5,a5,0x20
    1a90:	9381                	srli	a5,a5,0x20
    1a92:	97b2                	add	a5,a5,a2
    1a94:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a98:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a9c:	02f10323          	sb	a5,38(sp)
    1aa0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1aa2:	0ce86963          	bltu	a6,a4,1b74 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aa6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1aaa:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1aae:	1582                	slli	a1,a1,0x20
    1ab0:	9181                	srli	a1,a1,0x20
    1ab2:	95b2                	add	a1,a1,a2
    1ab4:	0005c583          	lbu	a1,0(a1)
    1ab8:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1abc:	0007859b          	sext.w	a1,a5
    1ac0:	16e6e563          	bltu	a3,a4,1c2a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ac4:	02e7f6bb          	remuw	a3,a5,a4
    1ac8:	1682                	slli	a3,a3,0x20
    1aca:	9281                	srli	a3,a3,0x20
    1acc:	96b2                	add	a3,a3,a2
    1ace:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ad2:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ad6:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1ada:	16e5e163          	bltu	a1,a4,1c3c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1ade:	02e876bb          	remuw	a3,a6,a4
    1ae2:	1682                	slli	a3,a3,0x20
    1ae4:	9281                	srli	a3,a3,0x20
    1ae6:	96b2                	add	a3,a3,a2
    1ae8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aec:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1af0:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1af4:	14e86d63          	bltu	a6,a4,1c4e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1af8:	02e5f6bb          	remuw	a3,a1,a4
    1afc:	1682                	slli	a3,a3,0x20
    1afe:	9281                	srli	a3,a3,0x20
    1b00:	96b2                	add	a3,a3,a2
    1b02:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b06:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b0a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b0e:	10e5e563          	bltu	a1,a4,1c18 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b12:	02e876bb          	remuw	a3,a6,a4
    1b16:	1682                	slli	a3,a3,0x20
    1b18:	9281                	srli	a3,a3,0x20
    1b1a:	96b2                	add	a3,a3,a2
    1b1c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b20:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b24:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b28:	14e86263          	bltu	a6,a4,1c6c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b2c:	02e5f6bb          	remuw	a3,a1,a4
    1b30:	1682                	slli	a3,a3,0x20
    1b32:	9281                	srli	a3,a3,0x20
    1b34:	96b2                	add	a3,a3,a2
    1b36:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b3a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b3e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b42:	14e5e463          	bltu	a1,a4,1c8a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b46:	02e876bb          	remuw	a3,a6,a4
    1b4a:	1682                	slli	a3,a3,0x20
    1b4c:	9281                	srli	a3,a3,0x20
    1b4e:	96b2                	add	a3,a3,a2
    1b50:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b54:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b58:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b5c:	14e86063          	bltu	a6,a4,1c9c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b60:	1782                	slli	a5,a5,0x20
    1b62:	9381                	srli	a5,a5,0x20
    1b64:	97b2                	add	a5,a5,a2
    1b66:	0007c703          	lbu	a4,0(a5)
    1b6a:	4799                	li	a5,6
    1b6c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b70:	10054763          	bltz	a0,1c7e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b74:	00001497          	auipc	s1,0x1
    1b78:	d9448493          	addi	s1,s1,-620 # 2908 <buffer_len>
    1b7c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b80:	0828                	addi	a0,sp,24
    1b82:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b84:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b86:	00f50433          	add	s0,a0,a5
    1b8a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b8c:	06e68463          	beq	a3,a4,1bf4 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b90:	8522                	mv	a0,s0
    1b92:	b15ff0ef          	jal	ra,16a6 <out_unlocked>
}
    1b96:	60a6                	ld	ra,72(sp)
    1b98:	6406                	ld	s0,64(sp)
    1b9a:	74e2                	ld	s1,56(sp)
    1b9c:	6161                	addi	sp,sp,80
    1b9e:	8082                	ret
		x = -xx;
    1ba0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1ba4:	02b877bb          	remuw	a5,a6,a1
    1ba8:	00001617          	auipc	a2,0x1
    1bac:	e7060613          	addi	a2,a2,-400 # 2a18 <digits>
	buf[16] = 0;
    1bb0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bb4:	0005871b          	sext.w	a4,a1
    1bb8:	1782                	slli	a5,a5,0x20
    1bba:	9381                	srli	a5,a5,0x20
    1bbc:	97b2                	add	a5,a5,a2
    1bbe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bc2:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1bc6:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1bca:	08b86b63          	bltu	a6,a1,1c60 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1bce:	02e8f7bb          	remuw	a5,a7,a4
    1bd2:	1782                	slli	a5,a5,0x20
    1bd4:	9381                	srli	a5,a5,0x20
    1bd6:	97b2                	add	a5,a5,a2
    1bd8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bdc:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1be0:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1be4:	ece8f1e3          	bgeu	a7,a4,1aa6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1be8:	02d00793          	li	a5,45
    1bec:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1bf0:	47b5                	li	a5,13
    1bf2:	b749                	j	1b74 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1bf4:	10c4a503          	lw	a0,268(s1)
    1bf8:	e42e                	sd	a1,8(sp)
    1bfa:	2c1000ef          	jal	ra,26ba <mutex_lock>
		len = out_unlocked(s, l);
    1bfe:	65a2                	ld	a1,8(sp)
    1c00:	8522                	mv	a0,s0
    1c02:	aa5ff0ef          	jal	ra,16a6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c06:	10c4a503          	lw	a0,268(s1)
    1c0a:	2bd000ef          	jal	ra,26c6 <mutex_unlock>
}
    1c0e:	60a6                	ld	ra,72(sp)
    1c10:	6406                	ld	s0,64(sp)
    1c12:	74e2                	ld	s1,56(sp)
    1c14:	6161                	addi	sp,sp,80
    1c16:	8082                	ret
		buf[i--] = digits[x % base];
    1c18:	47a9                	li	a5,10
	if (sign)
    1c1a:	f4055de3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1e:	02d00793          	li	a5,45
    1c22:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c26:	47a5                	li	a5,9
    1c28:	b7b1                	j	1b74 <printint.constprop.0+0x122>
    1c2a:	47b5                	li	a5,13
	if (sign)
    1c2c:	f40554e3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c30:	02d00793          	li	a5,45
    1c34:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c38:	47b1                	li	a5,12
    1c3a:	bf2d                	j	1b74 <printint.constprop.0+0x122>
    1c3c:	47b1                	li	a5,12
	if (sign)
    1c3e:	f2055be3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c42:	02d00793          	li	a5,45
    1c46:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c4a:	47ad                	li	a5,11
    1c4c:	b725                	j	1b74 <printint.constprop.0+0x122>
    1c4e:	47ad                	li	a5,11
	if (sign)
    1c50:	f20552e3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c54:	02d00793          	li	a5,45
    1c58:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c5c:	47a9                	li	a5,10
    1c5e:	bf19                	j	1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c60:	02d00793          	li	a5,45
    1c64:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c68:	47b9                	li	a5,14
    1c6a:	b729                	j	1b74 <printint.constprop.0+0x122>
    1c6c:	47a5                	li	a5,9
	if (sign)
    1c6e:	f00553e3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c72:	02d00793          	li	a5,45
    1c76:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c7a:	47a1                	li	a5,8
    1c7c:	bde5                	j	1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c7e:	02d00793          	li	a5,45
    1c82:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c86:	4795                	li	a5,5
    1c88:	b5f5                	j	1b74 <printint.constprop.0+0x122>
    1c8a:	47a1                	li	a5,8
	if (sign)
    1c8c:	ee0554e3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c90:	02d00793          	li	a5,45
    1c94:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c98:	479d                	li	a5,7
    1c9a:	bde9                	j	1b74 <printint.constprop.0+0x122>
    1c9c:	479d                	li	a5,7
	if (sign)
    1c9e:	ec055be3          	bgez	a0,1b74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca2:	02d00793          	li	a5,45
    1ca6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1caa:	4799                	li	a5,6
    1cac:	b5e1                	j	1b74 <printint.constprop.0+0x122>

0000000000001cae <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cae:	02000793          	li	a5,32
    1cb2:	00f50663          	beq	a0,a5,1cbe <isspace+0x10>
    1cb6:	355d                	addiw	a0,a0,-9
    1cb8:	00553513          	sltiu	a0,a0,5
    1cbc:	8082                	ret
    1cbe:	4505                	li	a0,1
}
    1cc0:	8082                	ret

0000000000001cc2 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1cc2:	fd05051b          	addiw	a0,a0,-48
}
    1cc6:	00a53513          	sltiu	a0,a0,10
    1cca:	8082                	ret

0000000000001ccc <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1ccc:	02000613          	li	a2,32
    1cd0:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1cd2:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cd6:	ff77869b          	addiw	a3,a5,-9
    1cda:	04c78c63          	beq	a5,a2,1d32 <atoi+0x66>
    1cde:	0007871b          	sext.w	a4,a5
    1ce2:	04d5f863          	bgeu	a1,a3,1d32 <atoi+0x66>
		s++;
	switch (*s) {
    1ce6:	02b00693          	li	a3,43
    1cea:	04d78963          	beq	a5,a3,1d3c <atoi+0x70>
    1cee:	02d00693          	li	a3,45
    1cf2:	06d78263          	beq	a5,a3,1d56 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1cf6:	fd07061b          	addiw	a2,a4,-48
    1cfa:	47a5                	li	a5,9
    1cfc:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cfe:	4e01                	li	t3,0
	while (isdigit(*s))
    1d00:	04c7e963          	bltu	a5,a2,1d52 <atoi+0x86>
	int n = 0, neg = 0;
    1d04:	4501                	li	a0,0
	while (isdigit(*s))
    1d06:	4825                	li	a6,9
    1d08:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d0c:	0025179b          	slliw	a5,a0,0x2
    1d10:	9fa9                	addw	a5,a5,a0
    1d12:	fd07031b          	addiw	t1,a4,-48
    1d16:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d1a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d1e:	0685                	addi	a3,a3,1
    1d20:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d24:	0006071b          	sext.w	a4,a2
    1d28:	feb870e3          	bgeu	a6,a1,1d08 <atoi+0x3c>
	return neg ? n : -n;
    1d2c:	000e0563          	beqz	t3,1d36 <atoi+0x6a>
}
    1d30:	8082                	ret
		s++;
    1d32:	0505                	addi	a0,a0,1
    1d34:	bf79                	j	1cd2 <atoi+0x6>
	return neg ? n : -n;
    1d36:	4113053b          	subw	a0,t1,a7
    1d3a:	8082                	ret
	while (isdigit(*s))
    1d3c:	00154703          	lbu	a4,1(a0)
    1d40:	47a5                	li	a5,9
		s++;
    1d42:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d46:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d4a:	4e01                	li	t3,0
	while (isdigit(*s))
    1d4c:	2701                	sext.w	a4,a4
    1d4e:	fac7fbe3          	bgeu	a5,a2,1d04 <atoi+0x38>
    1d52:	4501                	li	a0,0
}
    1d54:	8082                	ret
	while (isdigit(*s))
    1d56:	00154703          	lbu	a4,1(a0)
    1d5a:	47a5                	li	a5,9
		s++;
    1d5c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d60:	fd07061b          	addiw	a2,a4,-48
    1d64:	2701                	sext.w	a4,a4
    1d66:	fec7e6e3          	bltu	a5,a2,1d52 <atoi+0x86>
		neg = 1;
    1d6a:	4e05                	li	t3,1
    1d6c:	bf61                	j	1d04 <atoi+0x38>

0000000000001d6e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d6e:	16060d63          	beqz	a2,1ee8 <memset+0x17a>
    1d72:	40a007b3          	neg	a5,a0
    1d76:	8b9d                	andi	a5,a5,7
    1d78:	00778693          	addi	a3,a5,7
    1d7c:	482d                	li	a6,11
    1d7e:	0ff5f713          	zext.b	a4,a1
    1d82:	fff60593          	addi	a1,a2,-1
    1d86:	1706e263          	bltu	a3,a6,1eea <memset+0x17c>
    1d8a:	16d5ea63          	bltu	a1,a3,1efe <memset+0x190>
    1d8e:	16078563          	beqz	a5,1ef8 <memset+0x18a>
    1d92:	00e50023          	sb	a4,0(a0)
    1d96:	4685                	li	a3,1
    1d98:	00150593          	addi	a1,a0,1
    1d9c:	14d78c63          	beq	a5,a3,1ef4 <memset+0x186>
    1da0:	00e500a3          	sb	a4,1(a0)
    1da4:	4689                	li	a3,2
    1da6:	00250593          	addi	a1,a0,2
    1daa:	14d78d63          	beq	a5,a3,1f04 <memset+0x196>
    1dae:	00e50123          	sb	a4,2(a0)
    1db2:	468d                	li	a3,3
    1db4:	00350593          	addi	a1,a0,3
    1db8:	12d78b63          	beq	a5,a3,1eee <memset+0x180>
    1dbc:	00e501a3          	sb	a4,3(a0)
    1dc0:	4691                	li	a3,4
    1dc2:	00450593          	addi	a1,a0,4
    1dc6:	14d78163          	beq	a5,a3,1f08 <memset+0x19a>
    1dca:	00e50223          	sb	a4,4(a0)
    1dce:	4695                	li	a3,5
    1dd0:	00550593          	addi	a1,a0,5
    1dd4:	12d78c63          	beq	a5,a3,1f0c <memset+0x19e>
    1dd8:	00e502a3          	sb	a4,5(a0)
    1ddc:	469d                	li	a3,7
    1dde:	00650593          	addi	a1,a0,6
    1de2:	12d79763          	bne	a5,a3,1f10 <memset+0x1a2>
    1de6:	00750593          	addi	a1,a0,7
    1dea:	00e50323          	sb	a4,6(a0)
    1dee:	481d                	li	a6,7
    1df0:	00871693          	slli	a3,a4,0x8
    1df4:	01071893          	slli	a7,a4,0x10
    1df8:	8ed9                	or	a3,a3,a4
    1dfa:	01871313          	slli	t1,a4,0x18
    1dfe:	0116e6b3          	or	a3,a3,a7
    1e02:	0066e6b3          	or	a3,a3,t1
    1e06:	02071893          	slli	a7,a4,0x20
    1e0a:	02871e13          	slli	t3,a4,0x28
    1e0e:	0116e6b3          	or	a3,a3,a7
    1e12:	40f60333          	sub	t1,a2,a5
    1e16:	03071893          	slli	a7,a4,0x30
    1e1a:	01c6e6b3          	or	a3,a3,t3
    1e1e:	0116e6b3          	or	a3,a3,a7
    1e22:	03871e13          	slli	t3,a4,0x38
    1e26:	97aa                	add	a5,a5,a0
    1e28:	ff837893          	andi	a7,t1,-8
    1e2c:	01c6e6b3          	or	a3,a3,t3
    1e30:	98be                	add	a7,a7,a5
    1e32:	e394                	sd	a3,0(a5)
    1e34:	07a1                	addi	a5,a5,8
    1e36:	ff179ee3          	bne	a5,a7,1e32 <memset+0xc4>
    1e3a:	ff837893          	andi	a7,t1,-8
    1e3e:	011587b3          	add	a5,a1,a7
    1e42:	010886bb          	addw	a3,a7,a6
    1e46:	0b130663          	beq	t1,a7,1ef2 <memset+0x184>
    1e4a:	00e78023          	sb	a4,0(a5)
    1e4e:	0016859b          	addiw	a1,a3,1
    1e52:	08c5fb63          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e56:	00e780a3          	sb	a4,1(a5)
    1e5a:	0026859b          	addiw	a1,a3,2
    1e5e:	08c5f563          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e62:	00e78123          	sb	a4,2(a5)
    1e66:	0036859b          	addiw	a1,a3,3
    1e6a:	06c5ff63          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e6e:	00e781a3          	sb	a4,3(a5)
    1e72:	0046859b          	addiw	a1,a3,4
    1e76:	06c5f963          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e7a:	00e78223          	sb	a4,4(a5)
    1e7e:	0056859b          	addiw	a1,a3,5
    1e82:	06c5f363          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e86:	00e782a3          	sb	a4,5(a5)
    1e8a:	0066859b          	addiw	a1,a3,6
    1e8e:	04c5fd63          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e92:	00e78323          	sb	a4,6(a5)
    1e96:	0076859b          	addiw	a1,a3,7
    1e9a:	04c5f763          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1e9e:	00e783a3          	sb	a4,7(a5)
    1ea2:	0086859b          	addiw	a1,a3,8
    1ea6:	04c5f163          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1eaa:	00e78423          	sb	a4,8(a5)
    1eae:	0096859b          	addiw	a1,a3,9
    1eb2:	02c5fb63          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1eb6:	00e784a3          	sb	a4,9(a5)
    1eba:	00a6859b          	addiw	a1,a3,10
    1ebe:	02c5f563          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1ec2:	00e78523          	sb	a4,10(a5)
    1ec6:	00b6859b          	addiw	a1,a3,11
    1eca:	00c5ff63          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1ece:	00e785a3          	sb	a4,11(a5)
    1ed2:	00c6859b          	addiw	a1,a3,12
    1ed6:	00c5f963          	bgeu	a1,a2,1ee8 <memset+0x17a>
    1eda:	00e78623          	sb	a4,12(a5)
    1ede:	26b5                	addiw	a3,a3,13
    1ee0:	00c6f463          	bgeu	a3,a2,1ee8 <memset+0x17a>
    1ee4:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1ee8:	8082                	ret
    1eea:	46ad                	li	a3,11
    1eec:	bd79                	j	1d8a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1eee:	480d                	li	a6,3
    1ef0:	b701                	j	1df0 <memset+0x82>
    1ef2:	8082                	ret
    1ef4:	4805                	li	a6,1
    1ef6:	bded                	j	1df0 <memset+0x82>
    1ef8:	85aa                	mv	a1,a0
    1efa:	4801                	li	a6,0
    1efc:	bdd5                	j	1df0 <memset+0x82>
    1efe:	87aa                	mv	a5,a0
    1f00:	4681                	li	a3,0
    1f02:	b7a1                	j	1e4a <memset+0xdc>
    1f04:	4809                	li	a6,2
    1f06:	b5ed                	j	1df0 <memset+0x82>
    1f08:	4811                	li	a6,4
    1f0a:	b5dd                	j	1df0 <memset+0x82>
    1f0c:	4815                	li	a6,5
    1f0e:	b5cd                	j	1df0 <memset+0x82>
    1f10:	4819                	li	a6,6
    1f12:	bdf9                	j	1df0 <memset+0x82>

0000000000001f14 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f14:	00054783          	lbu	a5,0(a0)
    1f18:	0005c703          	lbu	a4,0(a1)
    1f1c:	00e79863          	bne	a5,a4,1f2c <strcmp+0x18>
    1f20:	0505                	addi	a0,a0,1
    1f22:	0585                	addi	a1,a1,1
    1f24:	fbe5                	bnez	a5,1f14 <strcmp>
    1f26:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f28:	9d19                	subw	a0,a0,a4
    1f2a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f2c:	0007851b          	sext.w	a0,a5
    1f30:	bfe5                	j	1f28 <strcmp+0x14>

0000000000001f32 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f32:	ca15                	beqz	a2,1f66 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f34:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f38:	167d                	addi	a2,a2,-1
    1f3a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f3e:	eb99                	bnez	a5,1f54 <strncmp+0x22>
    1f40:	a815                	j	1f74 <strncmp+0x42>
    1f42:	00a68e63          	beq	a3,a0,1f5e <strncmp+0x2c>
    1f46:	0505                	addi	a0,a0,1
    1f48:	00f71b63          	bne	a4,a5,1f5e <strncmp+0x2c>
    1f4c:	00054783          	lbu	a5,0(a0)
    1f50:	cf89                	beqz	a5,1f6a <strncmp+0x38>
    1f52:	85b2                	mv	a1,a2
    1f54:	0005c703          	lbu	a4,0(a1)
    1f58:	00158613          	addi	a2,a1,1
    1f5c:	f37d                	bnez	a4,1f42 <strncmp+0x10>
		;
	return *l - *r;
    1f5e:	0007851b          	sext.w	a0,a5
    1f62:	9d19                	subw	a0,a0,a4
    1f64:	8082                	ret
		return 0;
    1f66:	4501                	li	a0,0
}
    1f68:	8082                	ret
	return *l - *r;
    1f6a:	0015c703          	lbu	a4,1(a1)
    1f6e:	4501                	li	a0,0
    1f70:	9d19                	subw	a0,a0,a4
    1f72:	8082                	ret
    1f74:	0005c703          	lbu	a4,0(a1)
    1f78:	4501                	li	a0,0
    1f7a:	b7e5                	j	1f62 <strncmp+0x30>

0000000000001f7c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f7c:	00757793          	andi	a5,a0,7
    1f80:	cf89                	beqz	a5,1f9a <strlen+0x1e>
    1f82:	87aa                	mv	a5,a0
    1f84:	a029                	j	1f8e <strlen+0x12>
    1f86:	0785                	addi	a5,a5,1
    1f88:	0077f713          	andi	a4,a5,7
    1f8c:	cb01                	beqz	a4,1f9c <strlen+0x20>
		if (!*s)
    1f8e:	0007c703          	lbu	a4,0(a5)
    1f92:	fb75                	bnez	a4,1f86 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f94:	40a78533          	sub	a0,a5,a0
}
    1f98:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f9a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f9c:	6394                	ld	a3,0(a5)
    1f9e:	00001597          	auipc	a1,0x1
    1fa2:	9525b583          	ld	a1,-1710(a1) # 28f0 <enable_deadlock_detect+0x1d6>
    1fa6:	00001617          	auipc	a2,0x1
    1faa:	95263603          	ld	a2,-1710(a2) # 28f8 <enable_deadlock_detect+0x1de>
    1fae:	a019                	j	1fb4 <strlen+0x38>
    1fb0:	6794                	ld	a3,8(a5)
    1fb2:	07a1                	addi	a5,a5,8
    1fb4:	00b68733          	add	a4,a3,a1
    1fb8:	fff6c693          	not	a3,a3
    1fbc:	8f75                	and	a4,a4,a3
    1fbe:	8f71                	and	a4,a4,a2
    1fc0:	db65                	beqz	a4,1fb0 <strlen+0x34>
	for (; *s; s++)
    1fc2:	0007c703          	lbu	a4,0(a5)
    1fc6:	d779                	beqz	a4,1f94 <strlen+0x18>
    1fc8:	0017c703          	lbu	a4,1(a5)
    1fcc:	0785                	addi	a5,a5,1
    1fce:	d379                	beqz	a4,1f94 <strlen+0x18>
    1fd0:	0017c703          	lbu	a4,1(a5)
    1fd4:	0785                	addi	a5,a5,1
    1fd6:	fb6d                	bnez	a4,1fc8 <strlen+0x4c>
    1fd8:	bf75                	j	1f94 <strlen+0x18>

0000000000001fda <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fda:	00757713          	andi	a4,a0,7
{
    1fde:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1fe0:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fe4:	cb19                	beqz	a4,1ffa <memchr+0x20>
    1fe6:	ce25                	beqz	a2,205e <memchr+0x84>
    1fe8:	0007c703          	lbu	a4,0(a5)
    1fec:	04b70e63          	beq	a4,a1,2048 <memchr+0x6e>
    1ff0:	0785                	addi	a5,a5,1
    1ff2:	0077f713          	andi	a4,a5,7
    1ff6:	167d                	addi	a2,a2,-1
    1ff8:	f77d                	bnez	a4,1fe6 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1ffa:	4501                	li	a0,0
	if (n && *s != c) {
    1ffc:	c235                	beqz	a2,2060 <memchr+0x86>
    1ffe:	0007c703          	lbu	a4,0(a5)
    2002:	04b70363          	beq	a4,a1,2048 <memchr+0x6e>
		size_t k = ONES * c;
    2006:	00001517          	auipc	a0,0x1
    200a:	8fa53503          	ld	a0,-1798(a0) # 2900 <enable_deadlock_detect+0x1e6>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    200e:	471d                	li	a4,7
		size_t k = ONES * c;
    2010:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2014:	02c77a63          	bgeu	a4,a2,2048 <memchr+0x6e>
    2018:	00001897          	auipc	a7,0x1
    201c:	8d88b883          	ld	a7,-1832(a7) # 28f0 <enable_deadlock_detect+0x1d6>
    2020:	00001817          	auipc	a6,0x1
    2024:	8d883803          	ld	a6,-1832(a6) # 28f8 <enable_deadlock_detect+0x1de>
    2028:	431d                	li	t1,7
    202a:	a029                	j	2034 <memchr+0x5a>
		     w++, n -= SS)
    202c:	1661                	addi	a2,a2,-8
    202e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2030:	02c37963          	bgeu	t1,a2,2062 <memchr+0x88>
    2034:	6398                	ld	a4,0(a5)
    2036:	8f29                	xor	a4,a4,a0
    2038:	011706b3          	add	a3,a4,a7
    203c:	fff74713          	not	a4,a4
    2040:	8f75                	and	a4,a4,a3
    2042:	01077733          	and	a4,a4,a6
    2046:	d37d                	beqz	a4,202c <memchr+0x52>
{
    2048:	853e                	mv	a0,a5
    204a:	97b2                	add	a5,a5,a2
    204c:	a021                	j	2054 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    204e:	0505                	addi	a0,a0,1
    2050:	00f50763          	beq	a0,a5,205e <memchr+0x84>
    2054:	00054703          	lbu	a4,0(a0)
    2058:	feb71be3          	bne	a4,a1,204e <memchr+0x74>
    205c:	8082                	ret
	return n ? (void *)s : 0;
    205e:	4501                	li	a0,0
}
    2060:	8082                	ret
	return n ? (void *)s : 0;
    2062:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2064:	f275                	bnez	a2,2048 <memchr+0x6e>
}
    2066:	8082                	ret

0000000000002068 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2068:	1101                	addi	sp,sp,-32
    206a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    206c:	862e                	mv	a2,a1
{
    206e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2070:	4581                	li	a1,0
{
    2072:	e426                	sd	s1,8(sp)
    2074:	ec06                	sd	ra,24(sp)
    2076:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2078:	f63ff0ef          	jal	ra,1fda <memchr>
	return p ? p - s : n;
    207c:	c519                	beqz	a0,208a <strnlen+0x22>
}
    207e:	60e2                	ld	ra,24(sp)
    2080:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2082:	8d05                	sub	a0,a0,s1
}
    2084:	64a2                	ld	s1,8(sp)
    2086:	6105                	addi	sp,sp,32
    2088:	8082                	ret
    208a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    208c:	8522                	mv	a0,s0
}
    208e:	6442                	ld	s0,16(sp)
    2090:	64a2                	ld	s1,8(sp)
    2092:	6105                	addi	sp,sp,32
    2094:	8082                	ret

0000000000002096 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2096:	00a5c7b3          	xor	a5,a1,a0
    209a:	8b9d                	andi	a5,a5,7
    209c:	eb95                	bnez	a5,20d0 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    209e:	0075f793          	andi	a5,a1,7
    20a2:	e7b1                	bnez	a5,20ee <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20a4:	6198                	ld	a4,0(a1)
    20a6:	00001617          	auipc	a2,0x1
    20aa:	84a63603          	ld	a2,-1974(a2) # 28f0 <enable_deadlock_detect+0x1d6>
    20ae:	00001817          	auipc	a6,0x1
    20b2:	84a83803          	ld	a6,-1974(a6) # 28f8 <enable_deadlock_detect+0x1de>
    20b6:	a029                	j	20c0 <stpcpy+0x2a>
    20b8:	05a1                	addi	a1,a1,8
    20ba:	e118                	sd	a4,0(a0)
    20bc:	6198                	ld	a4,0(a1)
    20be:	0521                	addi	a0,a0,8
    20c0:	00c707b3          	add	a5,a4,a2
    20c4:	fff74693          	not	a3,a4
    20c8:	8ff5                	and	a5,a5,a3
    20ca:	0107f7b3          	and	a5,a5,a6
    20ce:	d7ed                	beqz	a5,20b8 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    20d0:	0005c783          	lbu	a5,0(a1)
    20d4:	00f50023          	sb	a5,0(a0)
    20d8:	c785                	beqz	a5,2100 <stpcpy+0x6a>
    20da:	0015c783          	lbu	a5,1(a1)
    20de:	0505                	addi	a0,a0,1
    20e0:	0585                	addi	a1,a1,1
    20e2:	00f50023          	sb	a5,0(a0)
    20e6:	fbf5                	bnez	a5,20da <stpcpy+0x44>
		;
	return d;
}
    20e8:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20ea:	0505                	addi	a0,a0,1
    20ec:	df45                	beqz	a4,20a4 <stpcpy+0xe>
			if (!(*d = *s))
    20ee:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20f2:	0585                	addi	a1,a1,1
    20f4:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20f8:	00f50023          	sb	a5,0(a0)
    20fc:	f7fd                	bnez	a5,20ea <stpcpy+0x54>
}
    20fe:	8082                	ret
    2100:	8082                	ret

0000000000002102 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2102:	00a5c7b3          	xor	a5,a1,a0
    2106:	8b9d                	andi	a5,a5,7
    2108:	1a079863          	bnez	a5,22b8 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    210c:	0075f793          	andi	a5,a1,7
    2110:	16078463          	beqz	a5,2278 <stpncpy+0x176>
    2114:	ea01                	bnez	a2,2124 <stpncpy+0x22>
    2116:	a421                	j	231e <stpncpy+0x21c>
    2118:	167d                	addi	a2,a2,-1
    211a:	0505                	addi	a0,a0,1
    211c:	14070e63          	beqz	a4,2278 <stpncpy+0x176>
    2120:	1a060863          	beqz	a2,22d0 <stpncpy+0x1ce>
    2124:	0005c783          	lbu	a5,0(a1)
    2128:	0585                	addi	a1,a1,1
    212a:	0075f713          	andi	a4,a1,7
    212e:	00f50023          	sb	a5,0(a0)
    2132:	f3fd                	bnez	a5,2118 <stpncpy+0x16>
    2134:	4805                	li	a6,1
    2136:	1a061863          	bnez	a2,22e6 <stpncpy+0x1e4>
    213a:	40a007b3          	neg	a5,a0
    213e:	8b9d                	andi	a5,a5,7
    2140:	4681                	li	a3,0
    2142:	18061a63          	bnez	a2,22d6 <stpncpy+0x1d4>
    2146:	00778713          	addi	a4,a5,7
    214a:	45ad                	li	a1,11
    214c:	18b76363          	bltu	a4,a1,22d2 <stpncpy+0x1d0>
    2150:	1ae6eb63          	bltu	a3,a4,2306 <stpncpy+0x204>
    2154:	1a078363          	beqz	a5,22fa <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2158:	00050023          	sb	zero,0(a0)
    215c:	4685                	li	a3,1
    215e:	00150713          	addi	a4,a0,1
    2162:	18d78f63          	beq	a5,a3,2300 <stpncpy+0x1fe>
    2166:	000500a3          	sb	zero,1(a0)
    216a:	4689                	li	a3,2
    216c:	00250713          	addi	a4,a0,2
    2170:	18d78e63          	beq	a5,a3,230c <stpncpy+0x20a>
    2174:	00050123          	sb	zero,2(a0)
    2178:	468d                	li	a3,3
    217a:	00350713          	addi	a4,a0,3
    217e:	16d78c63          	beq	a5,a3,22f6 <stpncpy+0x1f4>
    2182:	000501a3          	sb	zero,3(a0)
    2186:	4691                	li	a3,4
    2188:	00450713          	addi	a4,a0,4
    218c:	18d78263          	beq	a5,a3,2310 <stpncpy+0x20e>
    2190:	00050223          	sb	zero,4(a0)
    2194:	4695                	li	a3,5
    2196:	00550713          	addi	a4,a0,5
    219a:	16d78d63          	beq	a5,a3,2314 <stpncpy+0x212>
    219e:	000502a3          	sb	zero,5(a0)
    21a2:	469d                	li	a3,7
    21a4:	00650713          	addi	a4,a0,6
    21a8:	16d79863          	bne	a5,a3,2318 <stpncpy+0x216>
    21ac:	00750713          	addi	a4,a0,7
    21b0:	00050323          	sb	zero,6(a0)
    21b4:	40f80833          	sub	a6,a6,a5
    21b8:	ff887593          	andi	a1,a6,-8
    21bc:	97aa                	add	a5,a5,a0
    21be:	95be                	add	a1,a1,a5
    21c0:	0007b023          	sd	zero,0(a5)
    21c4:	07a1                	addi	a5,a5,8
    21c6:	feb79de3          	bne	a5,a1,21c0 <stpncpy+0xbe>
    21ca:	ff887593          	andi	a1,a6,-8
    21ce:	9ead                	addw	a3,a3,a1
    21d0:	00b707b3          	add	a5,a4,a1
    21d4:	12b80863          	beq	a6,a1,2304 <stpncpy+0x202>
    21d8:	00078023          	sb	zero,0(a5)
    21dc:	0016871b          	addiw	a4,a3,1
    21e0:	0ec77863          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    21e4:	000780a3          	sb	zero,1(a5)
    21e8:	0026871b          	addiw	a4,a3,2
    21ec:	0ec77263          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    21f0:	00078123          	sb	zero,2(a5)
    21f4:	0036871b          	addiw	a4,a3,3
    21f8:	0cc77c63          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    21fc:	000781a3          	sb	zero,3(a5)
    2200:	0046871b          	addiw	a4,a3,4
    2204:	0cc77663          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2208:	00078223          	sb	zero,4(a5)
    220c:	0056871b          	addiw	a4,a3,5
    2210:	0cc77063          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2214:	000782a3          	sb	zero,5(a5)
    2218:	0066871b          	addiw	a4,a3,6
    221c:	0ac77a63          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2220:	00078323          	sb	zero,6(a5)
    2224:	0076871b          	addiw	a4,a3,7
    2228:	0ac77463          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    222c:	000783a3          	sb	zero,7(a5)
    2230:	0086871b          	addiw	a4,a3,8
    2234:	08c77e63          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2238:	00078423          	sb	zero,8(a5)
    223c:	0096871b          	addiw	a4,a3,9
    2240:	08c77863          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2244:	000784a3          	sb	zero,9(a5)
    2248:	00a6871b          	addiw	a4,a3,10
    224c:	08c77263          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2250:	00078523          	sb	zero,10(a5)
    2254:	00b6871b          	addiw	a4,a3,11
    2258:	06c77c63          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    225c:	000785a3          	sb	zero,11(a5)
    2260:	00c6871b          	addiw	a4,a3,12
    2264:	06c77663          	bgeu	a4,a2,22d0 <stpncpy+0x1ce>
    2268:	00078623          	sb	zero,12(a5)
    226c:	26b5                	addiw	a3,a3,13
    226e:	06c6f163          	bgeu	a3,a2,22d0 <stpncpy+0x1ce>
    2272:	000786a3          	sb	zero,13(a5)
    2276:	8082                	ret
			;
		if (!n || !*s)
    2278:	c645                	beqz	a2,2320 <stpncpy+0x21e>
    227a:	0005c783          	lbu	a5,0(a1)
    227e:	ea078be3          	beqz	a5,2134 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2282:	479d                	li	a5,7
    2284:	02c7ff63          	bgeu	a5,a2,22c2 <stpncpy+0x1c0>
    2288:	00000897          	auipc	a7,0x0
    228c:	6688b883          	ld	a7,1640(a7) # 28f0 <enable_deadlock_detect+0x1d6>
    2290:	00000817          	auipc	a6,0x0
    2294:	66883803          	ld	a6,1640(a6) # 28f8 <enable_deadlock_detect+0x1de>
    2298:	431d                	li	t1,7
    229a:	6198                	ld	a4,0(a1)
    229c:	011707b3          	add	a5,a4,a7
    22a0:	fff74693          	not	a3,a4
    22a4:	8ff5                	and	a5,a5,a3
    22a6:	0107f7b3          	and	a5,a5,a6
    22aa:	ef81                	bnez	a5,22c2 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22ac:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22ae:	1661                	addi	a2,a2,-8
    22b0:	05a1                	addi	a1,a1,8
    22b2:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22b4:	fec363e3          	bltu	t1,a2,229a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22b8:	e609                	bnez	a2,22c2 <stpncpy+0x1c0>
    22ba:	a08d                	j	231c <stpncpy+0x21a>
    22bc:	167d                	addi	a2,a2,-1
    22be:	0505                	addi	a0,a0,1
    22c0:	ca01                	beqz	a2,22d0 <stpncpy+0x1ce>
    22c2:	0005c783          	lbu	a5,0(a1)
    22c6:	0585                	addi	a1,a1,1
    22c8:	00f50023          	sb	a5,0(a0)
    22cc:	fbe5                	bnez	a5,22bc <stpncpy+0x1ba>
		;
tail:
    22ce:	b59d                	j	2134 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    22d0:	8082                	ret
    22d2:	472d                	li	a4,11
    22d4:	bdb5                	j	2150 <stpncpy+0x4e>
    22d6:	00778713          	addi	a4,a5,7
    22da:	45ad                	li	a1,11
    22dc:	fff60693          	addi	a3,a2,-1
    22e0:	e6b778e3          	bgeu	a4,a1,2150 <stpncpy+0x4e>
    22e4:	b7fd                	j	22d2 <stpncpy+0x1d0>
    22e6:	40a007b3          	neg	a5,a0
    22ea:	8832                	mv	a6,a2
    22ec:	8b9d                	andi	a5,a5,7
    22ee:	4681                	li	a3,0
    22f0:	e4060be3          	beqz	a2,2146 <stpncpy+0x44>
    22f4:	b7cd                	j	22d6 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22f6:	468d                	li	a3,3
    22f8:	bd75                	j	21b4 <stpncpy+0xb2>
    22fa:	872a                	mv	a4,a0
    22fc:	4681                	li	a3,0
    22fe:	bd5d                	j	21b4 <stpncpy+0xb2>
    2300:	4685                	li	a3,1
    2302:	bd4d                	j	21b4 <stpncpy+0xb2>
    2304:	8082                	ret
    2306:	87aa                	mv	a5,a0
    2308:	4681                	li	a3,0
    230a:	b5f9                	j	21d8 <stpncpy+0xd6>
    230c:	4689                	li	a3,2
    230e:	b55d                	j	21b4 <stpncpy+0xb2>
    2310:	4691                	li	a3,4
    2312:	b54d                	j	21b4 <stpncpy+0xb2>
    2314:	4695                	li	a3,5
    2316:	bd79                	j	21b4 <stpncpy+0xb2>
    2318:	4699                	li	a3,6
    231a:	bd69                	j	21b4 <stpncpy+0xb2>
    231c:	8082                	ret
    231e:	8082                	ret
    2320:	8082                	ret

0000000000002322 <basename>:

char *basename(char *s)
{
    2322:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2324:	c54d                	beqz	a0,23ce <basename+0xac>
    2326:	00054783          	lbu	a5,0(a0)
		return ".";
    232a:	00000517          	auipc	a0,0x0
    232e:	5be50513          	addi	a0,a0,1470 # 28e8 <enable_deadlock_detect+0x1ce>
	if (!s || !*s)
    2332:	e391                	bnez	a5,2336 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2334:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2336:	0076f713          	andi	a4,a3,7
    233a:	87b6                	mv	a5,a3
    233c:	cf51                	beqz	a4,23d8 <basename+0xb6>
    233e:	0785                	addi	a5,a5,1
    2340:	0077f713          	andi	a4,a5,7
    2344:	c729                	beqz	a4,238e <basename+0x6c>
		if (!*s)
    2346:	0007c703          	lbu	a4,0(a5)
    234a:	fb75                	bnez	a4,233e <basename+0x1c>
	return s - a;
    234c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    234e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2350:	cf8d                	beqz	a5,238a <basename+0x68>
    2352:	00f68733          	add	a4,a3,a5
    2356:	02f00593          	li	a1,47
    235a:	a031                	j	2366 <basename+0x44>
		s[i] = 0;
    235c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2360:	17fd                	addi	a5,a5,-1
    2362:	177d                	addi	a4,a4,-1
    2364:	c39d                	beqz	a5,238a <basename+0x68>
    2366:	00074603          	lbu	a2,0(a4)
    236a:	feb609e3          	beq	a2,a1,235c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    236e:	02f00613          	li	a2,47
    2372:	a011                	j	2376 <basename+0x54>
    2374:	cb99                	beqz	a5,238a <basename+0x68>
    2376:	853e                	mv	a0,a5
    2378:	17fd                	addi	a5,a5,-1
    237a:	00f68733          	add	a4,a3,a5
    237e:	00074703          	lbu	a4,0(a4)
    2382:	fec719e3          	bne	a4,a2,2374 <basename+0x52>
	return s + i;
    2386:	9536                	add	a0,a0,a3
    2388:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    238a:	8536                	mv	a0,a3
    238c:	8082                	ret
    238e:	6390                	ld	a2,0(a5)
    2390:	00000517          	auipc	a0,0x0
    2394:	56053503          	ld	a0,1376(a0) # 28f0 <enable_deadlock_detect+0x1d6>
    2398:	00000597          	auipc	a1,0x0
    239c:	5605b583          	ld	a1,1376(a1) # 28f8 <enable_deadlock_detect+0x1de>
    23a0:	fff64713          	not	a4,a2
    23a4:	962a                	add	a2,a2,a0
    23a6:	8f71                	and	a4,a4,a2
    23a8:	8f6d                	and	a4,a4,a1
    23aa:	eb11                	bnez	a4,23be <basename+0x9c>
    23ac:	6790                	ld	a2,8(a5)
    23ae:	07a1                	addi	a5,a5,8
    23b0:	00a60733          	add	a4,a2,a0
    23b4:	fff64613          	not	a2,a2
    23b8:	8f71                	and	a4,a4,a2
    23ba:	8f6d                	and	a4,a4,a1
    23bc:	db65                	beqz	a4,23ac <basename+0x8a>
	for (; *s; s++)
    23be:	0007c703          	lbu	a4,0(a5)
    23c2:	d749                	beqz	a4,234c <basename+0x2a>
    23c4:	0017c703          	lbu	a4,1(a5)
    23c8:	0785                	addi	a5,a5,1
    23ca:	ff6d                	bnez	a4,23c4 <basename+0xa2>
    23cc:	b741                	j	234c <basename+0x2a>
		return ".";
    23ce:	00000517          	auipc	a0,0x0
    23d2:	51a50513          	addi	a0,a0,1306 # 28e8 <enable_deadlock_detect+0x1ce>
    23d6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23d8:	6290                	ld	a2,0(a3)
    23da:	00000517          	auipc	a0,0x0
    23de:	51653503          	ld	a0,1302(a0) # 28f0 <enable_deadlock_detect+0x1d6>
    23e2:	00000597          	auipc	a1,0x0
    23e6:	5165b583          	ld	a1,1302(a1) # 28f8 <enable_deadlock_detect+0x1de>
    23ea:	fff64713          	not	a4,a2
    23ee:	962a                	add	a2,a2,a0
    23f0:	8f71                	and	a4,a4,a2
    23f2:	8f6d                	and	a4,a4,a1
    23f4:	df45                	beqz	a4,23ac <basename+0x8a>
    23f6:	b7f9                	j	23c4 <basename+0xa2>

00000000000023f8 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23f8:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23fc:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23fe:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2402:	2501                	sext.w	a0,a0
    2404:	8082                	ret

0000000000002406 <close>:

int close(int fd)
{
	if (fd == 1) {
    2406:	4785                	li	a5,1
    2408:	00f50863          	beq	a0,a5,2418 <close+0x12>
	register long a7 __asm__("a7") = n;
    240c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2410:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2414:	2501                	sext.w	a0,a0
    2416:	8082                	ret
{
    2418:	1101                	addi	sp,sp,-32
    241a:	ec06                	sd	ra,24(sp)
    241c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    241e:	cdffe0ef          	jal	ra,10fc <__write_buffer>
		__clear_buffer();
    2422:	d03fe0ef          	jal	ra,1124 <__clear_buffer>
    2426:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2428:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    242c:	00000073          	ecall
}
    2430:	60e2                	ld	ra,24(sp)
    2432:	2501                	sext.w	a0,a0
    2434:	6105                	addi	sp,sp,32
    2436:	8082                	ret

0000000000002438 <read>:
	register long a7 __asm__("a7") = n;
    2438:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    243c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2440:	8082                	ret

0000000000002442 <write>:
	register long a7 __asm__("a7") = n;
    2442:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2446:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    244a:	8082                	ret

000000000000244c <getpid>:
	register long a7 __asm__("a7") = n;
    244c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2450:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2454:	2501                	sext.w	a0,a0
    2456:	8082                	ret

0000000000002458 <getppid>:
	register long a7 __asm__("a7") = n;
    2458:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    245c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2460:	2501                	sext.w	a0,a0
    2462:	8082                	ret

0000000000002464 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2464:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2468:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    246c:	2501                	sext.w	a0,a0
    246e:	8082                	ret

0000000000002470 <fork>:
	register long a7 __asm__("a7") = n;
    2470:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2474:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2478:	2501                	sext.w	a0,a0
    247a:	8082                	ret

000000000000247c <exit>:

void exit(int code)
{
    247c:	1141                	addi	sp,sp,-16
    247e:	e406                	sd	ra,8(sp)
    2480:	e022                	sd	s0,0(sp)
    2482:	842a                	mv	s0,a0
	__write_buffer();
    2484:	c79fe0ef          	jal	ra,10fc <__write_buffer>
	__clear_buffer();
    2488:	c9dfe0ef          	jal	ra,1124 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    248c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2490:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2492:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2496:	60a2                	ld	ra,8(sp)
    2498:	6402                	ld	s0,0(sp)
    249a:	0141                	addi	sp,sp,16
    249c:	8082                	ret

000000000000249e <waitpid>:
	register long a7 __asm__("a7") = n;
    249e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24a6:	2501                	sext.w	a0,a0
    24a8:	8082                	ret

00000000000024aa <exec>:
	register long a7 __asm__("a7") = n;
    24aa:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ae:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24b2:	2501                	sext.w	a0,a0
    24b4:	8082                	ret

00000000000024b6 <get_mtime>:

int64 get_mtime()
{
    24b6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24b8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24bc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    24be:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    24c4:	2501                	sext.w	a0,a0
    24c6:	ed01                	bnez	a0,24de <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    24c8:	6722                	ld	a4,8(sp)
    24ca:	3e800793          	li	a5,1000
    24ce:	6682                	ld	a3,0(sp)
    24d0:	02f75733          	divu	a4,a4,a5
    24d4:	02d78533          	mul	a0,a5,a3
    24d8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24da:	0141                	addi	sp,sp,16
    24dc:	8082                	ret
	return -1;
    24de:	557d                	li	a0,-1
    24e0:	bfed                	j	24da <get_mtime+0x24>

00000000000024e2 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24e2:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e6:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24ea:	2501                	sext.w	a0,a0
    24ec:	8082                	ret

00000000000024ee <sleep>:

int sleep(unsigned long long time)
{
    24ee:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24f0:	880a                	mv	a6,sp
{
    24f2:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24f4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24f8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24fa:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24fc:	00000073          	ecall
	if (err == 0) {
    2500:	2501                	sext.w	a0,a0
    2502:	ed31                	bnez	a0,255e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2504:	6722                	ld	a4,8(sp)
    2506:	3e800793          	li	a5,1000
    250a:	6682                	ld	a3,0(sp)
    250c:	02f75733          	divu	a4,a4,a5
    2510:	02d787b3          	mul	a5,a5,a3
    2514:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2516:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    251a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    251c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    251e:	00000073          	ecall
	if (err == 0) {
    2522:	2501                	sext.w	a0,a0
    2524:	e915                	bnez	a0,2558 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2526:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2528:	3e800693          	li	a3,1000
    252c:	a819                	j	2542 <sleep+0x54>
	__asm_syscall("r"(a7))
    252e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2532:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2536:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2538:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    253a:	00000073          	ecall
	if (err == 0) {
    253e:	2501                	sext.w	a0,a0
    2540:	ed01                	bnez	a0,2558 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2542:	6722                	ld	a4,8(sp)
    2544:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2546:	07c00893          	li	a7,124
    254a:	02d75733          	divu	a4,a4,a3
    254e:	02f687b3          	mul	a5,a3,a5
    2552:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2554:	fcc7ede3          	bltu	a5,a2,252e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2558:	4501                	li	a0,0
    255a:	0141                	addi	sp,sp,16
    255c:	8082                	ret
    255e:	57fd                	li	a5,-1
    2560:	bf5d                	j	2516 <sleep+0x28>

0000000000002562 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2562:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2566:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    256a:	2501                	sext.w	a0,a0
    256c:	8082                	ret

000000000000256e <set_priority>:
	register long a7 __asm__("a7") = n;
    256e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2572:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2576:	2501                	sext.w	a0,a0
    2578:	8082                	ret

000000000000257a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    257a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    257e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2582:	2501                	sext.w	a0,a0
    2584:	8082                	ret

0000000000002586 <munmap>:
	register long a7 __asm__("a7") = n;
    2586:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    258e:	2501                	sext.w	a0,a0
    2590:	8082                	ret

0000000000002592 <wait>:

int wait(int *code)
{
    2592:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2594:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2598:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259a:	00000073          	ecall
	return waitpid(-1, code);
}
    259e:	2501                	sext.w	a0,a0
    25a0:	8082                	ret

00000000000025a2 <spawn>:
	register long a7 __asm__("a7") = n;
    25a2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25a6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25aa:	2501                	sext.w	a0,a0
    25ac:	8082                	ret

00000000000025ae <pipe>:
	register long a7 __asm__("a7") = n;
    25ae:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25b2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25b6:	2501                	sext.w	a0,a0
    25b8:	8082                	ret

00000000000025ba <mailread>:
	register long a7 __asm__("a7") = n;
    25ba:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25be:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    25c2:	2501                	sext.w	a0,a0
    25c4:	8082                	ret

00000000000025c6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    25c6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ca:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    25ce:	2501                	sext.w	a0,a0
    25d0:	8082                	ret

00000000000025d2 <fstat>:
	register long a7 __asm__("a7") = n;
    25d2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25d6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25da:	2501                	sext.w	a0,a0
    25dc:	8082                	ret

00000000000025de <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25de:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25e0:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25e4:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25e6:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25ea:	2501                	sext.w	a0,a0
    25ec:	8082                	ret

00000000000025ee <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25ee:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25f0:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25f4:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25f6:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25fa:	2501                	sext.w	a0,a0
    25fc:	8082                	ret

00000000000025fe <link>:

int link(char *old_path, char *new_path)
{
    25fe:	87aa                	mv	a5,a0
    2600:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2602:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2606:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    260a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    260c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2610:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2612:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2616:	2501                	sext.w	a0,a0
    2618:	8082                	ret

000000000000261a <unlink>:

int unlink(char *path)
{
    261a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    261c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2620:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2624:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2626:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    262a:	2501                	sext.w	a0,a0
    262c:	8082                	ret

000000000000262e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    262e:	00000797          	auipc	a5,0x0
    2632:	40a7b783          	ld	a5,1034(a5) # 2a38 <_GLOBAL_OFFSET_TABLE_+0x8>
    2636:	439c                	lw	a5,0(a5)
    2638:	c799                	beqz	a5,2646 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    263a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    263e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2642:	2501                	sext.w	a0,a0
    2644:	8082                	ret
{
    2646:	1101                	addi	sp,sp,-32
    2648:	ec06                	sd	ra,24(sp)
    264a:	e42e                	sd	a1,8(sp)
    264c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    264e:	fe7fe0ef          	jal	ra,1634 <enable_thread_io_buffer>
    2652:	65a2                	ld	a1,8(sp)
    2654:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2656:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    265a:	00000073          	ecall
}
    265e:	60e2                	ld	ra,24(sp)
    2660:	2501                	sext.w	a0,a0
    2662:	6105                	addi	sp,sp,32
    2664:	8082                	ret

0000000000002666 <gettid>:
	register long a7 __asm__("a7") = n;
    2666:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    266a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    266e:	2501                	sext.w	a0,a0
    2670:	8082                	ret

0000000000002672 <waittid>:

int waittid(int tid)
{
    2672:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2674:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2678:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    267c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    267e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2680:	00e51e63          	bne	a0,a4,269c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2684:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2688:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    268c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2690:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2696:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2698:	fee506e3          	beq	a0,a4,2684 <waittid+0x12>
	}
	return ret;
}
    269c:	8082                	ret

000000000000269e <mutex_create>:
	register long a7 __asm__("a7") = n;
    269e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26a2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26a4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26a8:	2501                	sext.w	a0,a0
    26aa:	8082                	ret

00000000000026ac <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26ac:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26b0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26b2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26b6:	2501                	sext.w	a0,a0
    26b8:	8082                	ret

00000000000026ba <mutex_lock>:
	register long a7 __asm__("a7") = n;
    26ba:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    26be:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    26c2:	2501                	sext.w	a0,a0
    26c4:	8082                	ret

00000000000026c6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    26c6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    26ca:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    26ce:	2501                	sext.w	a0,a0
    26d0:	8082                	ret

00000000000026d2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    26d2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    26d6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26da:	2501                	sext.w	a0,a0
    26dc:	8082                	ret

00000000000026de <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26de:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26e2:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26e6:	2501                	sext.w	a0,a0
    26e8:	8082                	ret

00000000000026ea <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26ea:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26ee:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26f2:	2501                	sext.w	a0,a0
    26f4:	8082                	ret

00000000000026f6 <condvar_create>:
	register long a7 __asm__("a7") = n;
    26f6:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26fa:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26fe:	2501                	sext.w	a0,a0
    2700:	8082                	ret

0000000000002702 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2702:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2706:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    270a:	2501                	sext.w	a0,a0
    270c:	8082                	ret

000000000000270e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    270e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2712:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2716:	2501                	sext.w	a0,a0
    2718:	8082                	ret

000000000000271a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    271a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    271e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2722:	2501                	sext.w	a0,a0
    2724:	8082                	ret
