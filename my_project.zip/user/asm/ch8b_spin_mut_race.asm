
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_spin_mut_race:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a49d                	j	1266 <__start_main>

0000000000001002 <fun>:
int a;

int threads[thread_count];

void fun()
{
    1002:	715d                	addi	sp,sp,-80
    1004:	fc26                	sd	s1,56(sp)
	for (int i = 0; i < per_thread; i++) {
		assert_eq(mutex_lock(mutex_id), 0);
		// Force to extend the time of a++
		int old_a = a;
		for (int i = 0; i < 500; i++) {
			t = t * t % 10007;
    1006:	6489                	lui	s1,0x2
{
    1008:	e0a2                	sd	s0,64(sp)
    100a:	f84a                	sd	s2,48(sp)
    100c:	f44e                	sd	s3,40(sp)
    100e:	f052                	sd	s4,32(sp)
    1010:	ec56                	sd	s5,24(sp)
    1012:	e85a                	sd	s6,16(sp)
    1014:	e486                	sd	ra,72(sp)
    1016:	e45e                	sd	s7,8(sp)
    1018:	e062                	sd	s8,0(sp)
    101a:	06400993          	li	s3,100
	int t = 2;
    101e:	4409                	li	s0,2
    1020:	00002917          	auipc	s2,0x2
    1024:	b0090913          	addi	s2,s2,-1280 # 2b20 <mutex_id>
		assert_eq(mutex_lock(mutex_id), 0);
    1028:	00002b17          	auipc	s6,0x2
    102c:	8a8b0b13          	addi	s6,s6,-1880 # 28d0 <enable_deadlock_detect+0x10>
    1030:	00002a97          	auipc	s5,0x2
    1034:	8f0a8a93          	addi	s5,s5,-1808 # 2920 <enable_deadlock_detect+0x60>
    1038:	00002a17          	auipc	s4,0x2
    103c:	8f0a0a13          	addi	s4,s4,-1808 # 2928 <enable_deadlock_detect+0x68>
			t = t * t % 10007;
    1040:	7174849b          	addiw	s1,s1,1815
		assert_eq(mutex_lock(mutex_id), 0);
    1044:	00092503          	lw	a0,0(s2)
    1048:	019010ef          	jal	ra,2860 <mutex_lock>
    104c:	ed35                	bnez	a0,10c8 <fun+0xc6>
		int old_a = a;
    104e:	00492703          	lw	a4,4(s2)
    1052:	1f400793          	li	a5,500
			t = t * t % 10007;
    1056:	0284043b          	mulw	s0,s0,s0
		for (int i = 0; i < 500; i++) {
    105a:	37fd                	addiw	a5,a5,-1
			t = t * t % 10007;
    105c:	0294643b          	remw	s0,s0,s1
		for (int i = 0; i < 500; i++) {
    1060:	fbfd                	bnez	a5,1056 <fun+0x54>
		}
		a = old_a + 1;
		// A time cost a++ ends
		assert_eq(mutex_unlock(mutex_id), 0);
    1062:	00092503          	lw	a0,0(s2)
		a = old_a + 1;
    1066:	0017079b          	addiw	a5,a4,1
    106a:	00f92223          	sw	a5,4(s2)
		assert_eq(mutex_unlock(mutex_id), 0);
    106e:	7fe010ef          	jal	ra,286c <mutex_unlock>
    1072:	e115                	bnez	a0,1096 <fun+0x94>
	for (int i = 0; i < per_thread; i++) {
    1074:	39fd                	addiw	s3,s3,-1
    1076:	fc0997e3          	bnez	s3,1044 <fun+0x42>
	}
	exit(t);
    107a:	8522                	mv	a0,s0
}
    107c:	6406                	ld	s0,64(sp)
    107e:	60a6                	ld	ra,72(sp)
    1080:	74e2                	ld	s1,56(sp)
    1082:	7942                	ld	s2,48(sp)
    1084:	79a2                	ld	s3,40(sp)
    1086:	7a02                	ld	s4,32(sp)
    1088:	6ae2                	ld	s5,24(sp)
    108a:	6b42                	ld	s6,16(sp)
    108c:	6ba2                	ld	s7,8(sp)
    108e:	6c02                	ld	s8,0(sp)
    1090:	6161                	addi	sp,sp,80
	exit(t);
    1092:	5900106f          	j	2622 <exit>
		assert_eq(mutex_unlock(mutex_id), 0);
    1096:	55c010ef          	jal	ra,25f2 <getpid>
    109a:	8baa                	mv	s7,a0
    109c:	855a                	mv	a0,s6
    109e:	42a010ef          	jal	ra,24c8 <basename>
    10a2:	8c2a                	mv	s8,a0
    10a4:	00092503          	lw	a0,0(s2)
    10a8:	7c4010ef          	jal	ra,286c <mutex_unlock>
    10ac:	882a                	mv	a6,a0
    10ae:	4881                	li	a7,0
    10b0:	8552                	mv	a0,s4
    10b2:	47f5                	li	a5,29
    10b4:	8762                	mv	a4,s8
    10b6:	86de                	mv	a3,s7
    10b8:	8656                	mv	a2,s5
    10ba:	45fd                	li	a1,31
    10bc:	304000ef          	jal	ra,13c0 <printf>
    10c0:	557d                	li	a0,-1
    10c2:	560010ef          	jal	ra,2622 <exit>
    10c6:	b77d                	j	1074 <fun+0x72>
		assert_eq(mutex_lock(mutex_id), 0);
    10c8:	52a010ef          	jal	ra,25f2 <getpid>
    10cc:	8baa                	mv	s7,a0
    10ce:	855a                	mv	a0,s6
    10d0:	3f8010ef          	jal	ra,24c8 <basename>
    10d4:	8c2a                	mv	s8,a0
    10d6:	00092503          	lw	a0,0(s2)
    10da:	786010ef          	jal	ra,2860 <mutex_lock>
    10de:	882a                	mv	a6,a0
    10e0:	4881                	li	a7,0
    10e2:	8552                	mv	a0,s4
    10e4:	47d5                	li	a5,21
    10e6:	8762                	mv	a4,s8
    10e8:	86de                	mv	a3,s7
    10ea:	8656                	mv	a2,s5
    10ec:	45fd                	li	a1,31
    10ee:	2d2000ef          	jal	ra,13c0 <printf>
    10f2:	557d                	li	a0,-1
    10f4:	52e010ef          	jal	ra,2622 <exit>
    10f8:	bf99                	j	104e <fun+0x4c>

00000000000010fa <main>:

int main()
{
    10fa:	711d                	addi	sp,sp,-96
    10fc:	ec86                	sd	ra,88(sp)
    10fe:	e862                	sd	s8,16(sp)
    1100:	e466                	sd	s9,8(sp)
    1102:	e8a2                	sd	s0,80(sp)
    1104:	e4a6                	sd	s1,72(sp)
    1106:	e0ca                	sd	s2,64(sp)
    1108:	fc4e                	sd	s3,56(sp)
    110a:	f852                	sd	s4,48(sp)
    110c:	f456                	sd	s5,40(sp)
    110e:	f05a                	sd	s6,32(sp)
    1110:	ec5e                	sd	s7,24(sp)
	int64 start = get_mtime();
    1112:	54a010ef          	jal	ra,265c <get_mtime>
    1116:	8c2a                	mv	s8,a0
	assert((mutex_id = mutex_create()) >= 0);
    1118:	00002c97          	auipc	s9,0x2
    111c:	a08c8c93          	addi	s9,s9,-1528 # 2b20 <mutex_id>
    1120:	724010ef          	jal	ra,2844 <mutex_create>
    1124:	00aca023          	sw	a0,0(s9)
    1128:	10054363          	bltz	a0,122e <main+0x134>
    112c:	00002417          	auipc	s0,0x2
    1130:	9fc40413          	addi	s0,s0,-1540 # 2b28 <threads>
    1134:	00002917          	auipc	s2,0x2
    1138:	a3090913          	addi	s2,s2,-1488 # 2b64 <threads+0x3c>
{
    113c:	84a2                	mv	s1,s0
	for (int i = 0; i < thread_count; i++) {
		threads[i] = thread_create(fun, 0);
    113e:	00000997          	auipc	s3,0x0
    1142:	ec498993          	addi	s3,s3,-316 # 1002 <fun>
		assert(threads[i] > 0);
    1146:	00001b97          	auipc	s7,0x1
    114a:	78ab8b93          	addi	s7,s7,1930 # 28d0 <enable_deadlock_detect+0x10>
    114e:	00001b17          	auipc	s6,0x1
    1152:	7d2b0b13          	addi	s6,s6,2002 # 2920 <enable_deadlock_detect+0x60>
    1156:	00002a97          	auipc	s5,0x2
    115a:	85aa8a93          	addi	s5,s5,-1958 # 29b0 <enable_deadlock_detect+0xf0>
		threads[i] = thread_create(fun, 0);
    115e:	4581                	li	a1,0
    1160:	854e                	mv	a0,s3
    1162:	672010ef          	jal	ra,27d4 <thread_create>
    1166:	c088                	sw	a0,0(s1)
	for (int i = 0; i < thread_count; i++) {
    1168:	0491                	addi	s1,s1,4
		assert(threads[i] > 0);
    116a:	08a05d63          	blez	a0,1204 <main+0x10a>
	for (int i = 0; i < thread_count; i++) {
    116e:	ff2498e3          	bne	s1,s2,115e <main+0x64>
	}
	for (int i = 0; i < thread_count; i++) {
		waittid(threads[i]);
    1172:	4008                	lw	a0,0(s0)
	for (int i = 0; i < thread_count; i++) {
    1174:	0411                	addi	s0,s0,4
		waittid(threads[i]);
    1176:	6a2010ef          	jal	ra,2818 <waittid>
	for (int i = 0; i < thread_count; i++) {
    117a:	ff241ce3          	bne	s0,s2,1172 <main+0x78>
	}
	int64 stop = get_mtime();
    117e:	4de010ef          	jal	ra,265c <get_mtime>
	printf("time cost is %d ms\n", (int)(stop - start));
    1182:	418505bb          	subw	a1,a0,s8
    1186:	00002517          	auipc	a0,0x2
    118a:	86250513          	addi	a0,a0,-1950 # 29e8 <enable_deadlock_detect+0x128>
    118e:	232000ef          	jal	ra,13c0 <printf>
	assert_eq(a, per_thread * thread_count);
    1192:	004ca703          	lw	a4,4(s9)
    1196:	5dc00793          	li	a5,1500
    119a:	04f70163          	beq	a4,a5,11dc <main+0xe2>
    119e:	454010ef          	jal	ra,25f2 <getpid>
    11a2:	842a                	mv	s0,a0
    11a4:	00001517          	auipc	a0,0x1
    11a8:	72c50513          	addi	a0,a0,1836 # 28d0 <enable_deadlock_detect+0x10>
    11ac:	31c010ef          	jal	ra,24c8 <basename>
    11b0:	004ca803          	lw	a6,4(s9)
    11b4:	872a                	mv	a4,a0
    11b6:	5dc00893          	li	a7,1500
    11ba:	00001517          	auipc	a0,0x1
    11be:	76e50513          	addi	a0,a0,1902 # 2928 <enable_deadlock_detect+0x68>
    11c2:	02f00793          	li	a5,47
    11c6:	86a2                	mv	a3,s0
    11c8:	00001617          	auipc	a2,0x1
    11cc:	75860613          	addi	a2,a2,1880 # 2920 <enable_deadlock_detect+0x60>
    11d0:	45fd                	li	a1,31
    11d2:	1ee000ef          	jal	ra,13c0 <printf>
    11d6:	557d                	li	a0,-1
    11d8:	44a010ef          	jal	ra,2622 <exit>
	puts("race adder spinning mutex passed!");
    11dc:	00002517          	auipc	a0,0x2
    11e0:	82450513          	addi	a0,a0,-2012 # 2a00 <enable_deadlock_detect+0x140>
    11e4:	0f3000ef          	jal	ra,1ad6 <puts>
	return 0;
}
    11e8:	60e6                	ld	ra,88(sp)
    11ea:	6446                	ld	s0,80(sp)
    11ec:	64a6                	ld	s1,72(sp)
    11ee:	6906                	ld	s2,64(sp)
    11f0:	79e2                	ld	s3,56(sp)
    11f2:	7a42                	ld	s4,48(sp)
    11f4:	7aa2                	ld	s5,40(sp)
    11f6:	7b02                	ld	s6,32(sp)
    11f8:	6be2                	ld	s7,24(sp)
    11fa:	6c42                	ld	s8,16(sp)
    11fc:	6ca2                	ld	s9,8(sp)
    11fe:	4501                	li	a0,0
    1200:	6125                	addi	sp,sp,96
    1202:	8082                	ret
		assert(threads[i] > 0);
    1204:	3ee010ef          	jal	ra,25f2 <getpid>
    1208:	8a2a                	mv	s4,a0
    120a:	855e                	mv	a0,s7
    120c:	2bc010ef          	jal	ra,24c8 <basename>
    1210:	872a                	mv	a4,a0
    1212:	02800793          	li	a5,40
    1216:	8556                	mv	a0,s5
    1218:	86d2                	mv	a3,s4
    121a:	865a                	mv	a2,s6
    121c:	45fd                	li	a1,31
    121e:	1a2000ef          	jal	ra,13c0 <printf>
    1222:	557d                	li	a0,-1
    1224:	3fe010ef          	jal	ra,2622 <exit>
	for (int i = 0; i < thread_count; i++) {
    1228:	f3249be3          	bne	s1,s2,115e <main+0x64>
    122c:	b799                	j	1172 <main+0x78>
	assert((mutex_id = mutex_create()) >= 0);
    122e:	3c4010ef          	jal	ra,25f2 <getpid>
    1232:	842a                	mv	s0,a0
    1234:	00001517          	auipc	a0,0x1
    1238:	69c50513          	addi	a0,a0,1692 # 28d0 <enable_deadlock_detect+0x10>
    123c:	28c010ef          	jal	ra,24c8 <basename>
    1240:	872a                	mv	a4,a0
    1242:	02500793          	li	a5,37
    1246:	00001517          	auipc	a0,0x1
    124a:	71a50513          	addi	a0,a0,1818 # 2960 <enable_deadlock_detect+0xa0>
    124e:	86a2                	mv	a3,s0
    1250:	00001617          	auipc	a2,0x1
    1254:	6d060613          	addi	a2,a2,1744 # 2920 <enable_deadlock_detect+0x60>
    1258:	45fd                	li	a1,31
    125a:	166000ef          	jal	ra,13c0 <printf>
    125e:	557d                	li	a0,-1
    1260:	3c2010ef          	jal	ra,2622 <exit>
    1264:	b5e1                	j	112c <main+0x32>

0000000000001266 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1266:	1141                	addi	sp,sp,-16
    1268:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    126a:	e91ff0ef          	jal	ra,10fa <main>
    126e:	3b4010ef          	jal	ra,2622 <exit>
	return 0;
    1272:	60a2                	ld	ra,8(sp)
    1274:	4501                	li	a0,0
    1276:	0141                	addi	sp,sp,16
    1278:	8082                	ret

000000000000127a <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    127a:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    127c:	4605                	li	a2,1
    127e:	00f10593          	addi	a1,sp,15
    1282:	4501                	li	a0,0
{
    1284:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1286:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    128a:	354010ef          	jal	ra,25de <read>
    128e:	4785                	li	a5,1
    1290:	00f51763          	bne	a0,a5,129e <getchar+0x24>
		return byte;
    1294:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1298:	60e2                	ld	ra,24(sp)
    129a:	6105                	addi	sp,sp,32
    129c:	8082                	ret
		return EOF;
    129e:	557d                	li	a0,-1
    12a0:	bfe5                	j	1298 <getchar+0x1e>

00000000000012a2 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    12a2:	00002517          	auipc	a0,0x2
    12a6:	8c652503          	lw	a0,-1850(a0) # 2b68 <buffer_len>
    12aa:	e111                	bnez	a0,12ae <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    12ac:	8082                	ret
{
    12ae:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12b0:	862a                	mv	a2,a0
    12b2:	00002597          	auipc	a1,0x2
    12b6:	8be58593          	addi	a1,a1,-1858 # 2b70 <buffer>
    12ba:	4505                	li	a0,1
{
    12bc:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12be:	32a010ef          	jal	ra,25e8 <write>
}
    12c2:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12c4:	2501                	sext.w	a0,a0
}
    12c6:	0141                	addi	sp,sp,16
    12c8:	8082                	ret

00000000000012ca <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    12ca:	00002797          	auipc	a5,0x2
    12ce:	8807af23          	sw	zero,-1890(a5) # 2b68 <buffer_len>
}
    12d2:	8082                	ret

00000000000012d4 <__fflush>:
	if (buffer_len == 0)
    12d4:	00002517          	auipc	a0,0x2
    12d8:	89452503          	lw	a0,-1900(a0) # 2b68 <buffer_len>
    12dc:	e511                	bnez	a0,12e8 <__fflush+0x14>
	buffer_len = 0;
    12de:	00002797          	auipc	a5,0x2
    12e2:	8807a523          	sw	zero,-1910(a5) # 2b68 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    12e6:	8082                	ret
{
    12e8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12ea:	862a                	mv	a2,a0
    12ec:	00002597          	auipc	a1,0x2
    12f0:	88458593          	addi	a1,a1,-1916 # 2b70 <buffer>
    12f4:	4505                	li	a0,1
{
    12f6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12f8:	2f0010ef          	jal	ra,25e8 <write>
	return r >= 0 ? 0 : r;
    12fc:	0005079b          	sext.w	a5,a0
}
    1300:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1302:	0017a793          	slti	a5,a5,1
    1306:	40f007bb          	negw	a5,a5
    130a:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    130c:	00002797          	auipc	a5,0x2
    1310:	8407ae23          	sw	zero,-1956(a5) # 2b68 <buffer_len>
	return r >= 0 ? 0 : r;
    1314:	2501                	sext.w	a0,a0
}
    1316:	0141                	addi	sp,sp,16
    1318:	8082                	ret

000000000000131a <fflush>:

int fflush(int fd)
{
    131a:	1101                	addi	sp,sp,-32
    131c:	e822                	sd	s0,16(sp)
    131e:	ec06                	sd	ra,24(sp)
    1320:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1322:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1324:	4401                	li	s0,0
	if (fd == 1) {
    1326:	00e50863          	beq	a0,a4,1336 <fflush+0x1c>
}
    132a:	60e2                	ld	ra,24(sp)
    132c:	8522                	mv	a0,s0
    132e:	6442                	ld	s0,16(sp)
    1330:	64a2                	ld	s1,8(sp)
    1332:	6105                	addi	sp,sp,32
    1334:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1336:	00002497          	auipc	s1,0x2
    133a:	83248493          	addi	s1,s1,-1998 # 2b68 <buffer_len>
    133e:	1084a703          	lw	a4,264(s1)
    1342:	02a70e63          	beq	a4,a0,137e <fflush+0x64>
	if (buffer_len == 0)
    1346:	4080                	lw	s0,0(s1)
    1348:	c00d                	beqz	s0,136a <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    134a:	8622                	mv	a2,s0
    134c:	00002597          	auipc	a1,0x2
    1350:	82458593          	addi	a1,a1,-2012 # 2b70 <buffer>
    1354:	294010ef          	jal	ra,25e8 <write>
	return r >= 0 ? 0 : r;
    1358:	0005079b          	sext.w	a5,a0
    135c:	0017a793          	slti	a5,a5,1
    1360:	40f007bb          	negw	a5,a5
    1364:	8d7d                	and	a0,a0,a5
    1366:	0005041b          	sext.w	s0,a0
}
    136a:	60e2                	ld	ra,24(sp)
    136c:	8522                	mv	a0,s0
    136e:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1370:	00001797          	auipc	a5,0x1
    1374:	7e07ac23          	sw	zero,2040(a5) # 2b68 <buffer_len>
}
    1378:	64a2                	ld	s1,8(sp)
    137a:	6105                	addi	sp,sp,32
    137c:	8082                	ret
			mutex_lock(buffer_lock);
    137e:	10c4a503          	lw	a0,268(s1)
    1382:	4de010ef          	jal	ra,2860 <mutex_lock>
	if (buffer_len == 0)
    1386:	4080                	lw	s0,0(s1)
    1388:	e811                	bnez	s0,139c <fflush+0x82>
			mutex_unlock(buffer_lock);
    138a:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    138e:	00001797          	auipc	a5,0x1
    1392:	7c07ad23          	sw	zero,2010(a5) # 2b68 <buffer_len>
			mutex_unlock(buffer_lock);
    1396:	4d6010ef          	jal	ra,286c <mutex_unlock>
    139a:	bf41                	j	132a <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    139c:	8622                	mv	a2,s0
    139e:	00001597          	auipc	a1,0x1
    13a2:	7d258593          	addi	a1,a1,2002 # 2b70 <buffer>
    13a6:	4505                	li	a0,1
    13a8:	240010ef          	jal	ra,25e8 <write>
	return r >= 0 ? 0 : r;
    13ac:	0005079b          	sext.w	a5,a0
    13b0:	0017a793          	slti	a5,a5,1
    13b4:	40f007bb          	negw	a5,a5
    13b8:	8d7d                	and	a0,a0,a5
    13ba:	0005041b          	sext.w	s0,a0
	return r;
    13be:	b7f1                	j	138a <fflush+0x70>

00000000000013c0 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    13c0:	7131                	addi	sp,sp,-192
    13c2:	e0da                	sd	s6,64(sp)
    13c4:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    13c6:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    13c8:	013c                	addi	a5,sp,136
{
    13ca:	f0ca                	sd	s2,96(sp)
    13cc:	ecce                	sd	s3,88(sp)
    13ce:	e8d2                	sd	s4,80(sp)
    13d0:	e4d6                	sd	s5,72(sp)
    13d2:	fc86                	sd	ra,120(sp)
    13d4:	f8a2                	sd	s0,112(sp)
    13d6:	f4a6                	sd	s1,104(sp)
    13d8:	89aa                	mv	s3,a0
    13da:	e52e                	sd	a1,136(sp)
    13dc:	e932                	sd	a2,144(sp)
    13de:	ed36                	sd	a3,152(sp)
    13e0:	f13a                	sd	a4,160(sp)
    13e2:	f942                	sd	a6,176(sp)
    13e4:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    13e6:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    13e8:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    13ec:	00001a17          	auipc	s4,0x1
    13f0:	77ca0a13          	addi	s4,s4,1916 # 2b68 <buffer_len>
    13f4:	4a85                	li	s5,1
	buf[i++] = '0';
    13f6:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13fa:	0009c783          	lbu	a5,0(s3)
    13fe:	18078663          	beqz	a5,158a <printf+0x1ca>
    1402:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1404:	19278d63          	beq	a5,s2,159e <printf+0x1de>
    1408:	0015c783          	lbu	a5,1(a1)
    140c:	0585                	addi	a1,a1,1
    140e:	fbfd                	bnez	a5,1404 <printf+0x44>
    1410:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1412:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1416:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    141a:	1b578863          	beq	a5,s5,15ca <printf+0x20a>
		len = out_unlocked(s, l);
    141e:	85a2                	mv	a1,s0
    1420:	854e                	mv	a0,s3
    1422:	42a000ef          	jal	ra,184c <out_unlocked>
		out(f, a, l);
		if (l)
    1426:	1c041063          	bnez	s0,15e6 <printf+0x226>
			continue;
		if (s[1] == 0)
    142a:	0014c783          	lbu	a5,1(s1)
    142e:	14078e63          	beqz	a5,158a <printf+0x1ca>
			break;
		switch (s[1]) {
    1432:	07300713          	li	a4,115
    1436:	1ce78863          	beq	a5,a4,1606 <printf+0x246>
    143a:	1af76863          	bltu	a4,a5,15ea <printf+0x22a>
    143e:	06400713          	li	a4,100
    1442:	22e78063          	beq	a5,a4,1662 <printf+0x2a2>
    1446:	07000713          	li	a4,112
    144a:	1ee79563          	bne	a5,a4,1634 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    144e:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1450:	00002797          	auipc	a5,0x2
    1454:	82878793          	addi	a5,a5,-2008 # 2c78 <digits>
	buf[i++] = '0';
    1458:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    145c:	6298                	ld	a4,0(a3)
    145e:	06a1                	addi	a3,a3,8
    1460:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1462:	00471393          	slli	t2,a4,0x4
    1466:	00871293          	slli	t0,a4,0x8
    146a:	00c71f93          	slli	t6,a4,0xc
    146e:	01071f13          	slli	t5,a4,0x10
    1472:	01471e93          	slli	t4,a4,0x14
    1476:	01871e13          	slli	t3,a4,0x18
    147a:	01c71893          	slli	a7,a4,0x1c
    147e:	02471813          	slli	a6,a4,0x24
    1482:	02871513          	slli	a0,a4,0x28
    1486:	02c71593          	slli	a1,a4,0x2c
    148a:	03071613          	slli	a2,a4,0x30
    148e:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1492:	03c75413          	srli	s0,a4,0x3c
    1496:	01c7531b          	srliw	t1,a4,0x1c
    149a:	03c3d393          	srli	t2,t2,0x3c
    149e:	03c2d293          	srli	t0,t0,0x3c
    14a2:	03cfdf93          	srli	t6,t6,0x3c
    14a6:	03cf5f13          	srli	t5,t5,0x3c
    14aa:	03cede93          	srli	t4,t4,0x3c
    14ae:	03ce5e13          	srli	t3,t3,0x3c
    14b2:	03c8d893          	srli	a7,a7,0x3c
    14b6:	03c85813          	srli	a6,a6,0x3c
    14ba:	9171                	srli	a0,a0,0x3c
    14bc:	91f1                	srli	a1,a1,0x3c
    14be:	9271                	srli	a2,a2,0x3c
    14c0:	92f1                	srli	a3,a3,0x3c
    14c2:	95be                	add	a1,a1,a5
    14c4:	963e                	add	a2,a2,a5
    14c6:	96be                	add	a3,a3,a5
    14c8:	943e                	add	s0,s0,a5
    14ca:	93be                	add	t2,t2,a5
    14cc:	92be                	add	t0,t0,a5
    14ce:	9fbe                	add	t6,t6,a5
    14d0:	9f3e                	add	t5,t5,a5
    14d2:	9ebe                	add	t4,t4,a5
    14d4:	9e3e                	add	t3,t3,a5
    14d6:	98be                	add	a7,a7,a5
    14d8:	933e                	add	t1,t1,a5
    14da:	983e                	add	a6,a6,a5
    14dc:	953e                	add	a0,a0,a5
    14de:	0005c983          	lbu	s3,0(a1)
    14e2:	00044403          	lbu	s0,0(s0)
    14e6:	00064583          	lbu	a1,0(a2)
    14ea:	0003c383          	lbu	t2,0(t2)
    14ee:	0006c603          	lbu	a2,0(a3)
    14f2:	0002c283          	lbu	t0,0(t0)
    14f6:	000fcf83          	lbu	t6,0(t6)
    14fa:	000f4f03          	lbu	t5,0(t5)
    14fe:	000ece83          	lbu	t4,0(t4)
    1502:	000e4e03          	lbu	t3,0(t3)
    1506:	0008c883          	lbu	a7,0(a7)
    150a:	00034303          	lbu	t1,0(t1)
    150e:	00084803          	lbu	a6,0(a6)
    1512:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1516:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    151a:	92f1                	srli	a3,a3,0x3c
    151c:	8b3d                	andi	a4,a4,15
    151e:	96be                	add	a3,a3,a5
    1520:	97ba                	add	a5,a5,a4
    1522:	00810d23          	sb	s0,26(sp)
    1526:	00710da3          	sb	t2,27(sp)
    152a:	00510e23          	sb	t0,28(sp)
    152e:	01f10ea3          	sb	t6,29(sp)
    1532:	01e10f23          	sb	t5,30(sp)
    1536:	01d10fa3          	sb	t4,31(sp)
    153a:	03c10023          	sb	t3,32(sp)
    153e:	031100a3          	sb	a7,33(sp)
    1542:	02610123          	sb	t1,34(sp)
    1546:	030101a3          	sb	a6,35(sp)
    154a:	02a10223          	sb	a0,36(sp)
    154e:	033102a3          	sb	s3,37(sp)
    1552:	02b10323          	sb	a1,38(sp)
    1556:	02c103a3          	sb	a2,39(sp)
    155a:	0006c683          	lbu	a3,0(a3)
    155e:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1562:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1566:	02d10423          	sb	a3,40(sp)
    156a:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    156e:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1572:	11578263          	beq	a5,s5,1676 <printf+0x2b6>
		len = out_unlocked(s, l);
    1576:	45c9                	li	a1,18
    1578:	0828                	addi	a0,sp,24
    157a:	2d2000ef          	jal	ra,184c <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    157e:	00248993          	addi	s3,s1,2
		if (!*s)
    1582:	0009c783          	lbu	a5,0(s3)
    1586:	e6079ee3          	bnez	a5,1402 <printf+0x42>
	}
	va_end(ap);
    158a:	70e6                	ld	ra,120(sp)
    158c:	7446                	ld	s0,112(sp)
    158e:	74a6                	ld	s1,104(sp)
    1590:	7906                	ld	s2,96(sp)
    1592:	69e6                	ld	s3,88(sp)
    1594:	6a46                	ld	s4,80(sp)
    1596:	6aa6                	ld	s5,72(sp)
    1598:	6b06                	ld	s6,64(sp)
    159a:	6129                	addi	sp,sp,192
    159c:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    159e:	0005c783          	lbu	a5,0(a1)
    15a2:	84ae                	mv	s1,a1
    15a4:	01278963          	beq	a5,s2,15b6 <printf+0x1f6>
    15a8:	b5ad                	j	1412 <printf+0x52>
    15aa:	0024c783          	lbu	a5,2(s1)
    15ae:	0585                	addi	a1,a1,1
    15b0:	0489                	addi	s1,s1,2
    15b2:	e72790e3          	bne	a5,s2,1412 <printf+0x52>
    15b6:	0014c783          	lbu	a5,1(s1)
    15ba:	ff2788e3          	beq	a5,s2,15aa <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    15be:	108a2783          	lw	a5,264(s4)
		l = z - a;
    15c2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    15c6:	e5579ce3          	bne	a5,s5,141e <printf+0x5e>
		mutex_lock(buffer_lock);
    15ca:	10ca2503          	lw	a0,268(s4)
    15ce:	292010ef          	jal	ra,2860 <mutex_lock>
		len = out_unlocked(s, l);
    15d2:	85a2                	mv	a1,s0
    15d4:	854e                	mv	a0,s3
    15d6:	276000ef          	jal	ra,184c <out_unlocked>
		mutex_unlock(buffer_lock);
    15da:	10ca2503          	lw	a0,268(s4)
    15de:	28e010ef          	jal	ra,286c <mutex_unlock>
		if (l)
    15e2:	e40404e3          	beqz	s0,142a <printf+0x6a>
    15e6:	89a6                	mv	s3,s1
    15e8:	bd09                	j	13fa <printf+0x3a>
		switch (s[1]) {
    15ea:	07800713          	li	a4,120
    15ee:	04e79363          	bne	a5,a4,1634 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    15f2:	67c2                	ld	a5,16(sp)
    15f4:	45c1                	li	a1,16
		s += 2;
    15f6:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15fa:	4388                	lw	a0,0(a5)
    15fc:	07a1                	addi	a5,a5,8
    15fe:	e83e                	sd	a5,16(sp)
    1600:	5f8000ef          	jal	ra,1bf8 <printint.constprop.0>
		s += 2;
    1604:	bfbd                	j	1582 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1606:	67c2                	ld	a5,16(sp)
    1608:	6380                	ld	s0,0(a5)
    160a:	07a1                	addi	a5,a5,8
    160c:	e83e                	sd	a5,16(sp)
    160e:	1c040163          	beqz	s0,17d0 <printf+0x410>
			l = strnlen(a, 200);
    1612:	0c800593          	li	a1,200
    1616:	8522                	mv	a0,s0
    1618:	3f7000ef          	jal	ra,220e <strnlen>
	if (buffer_lock_enabled == 1) {
    161c:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1620:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1624:	19578663          	beq	a5,s5,17b0 <printf+0x3f0>
		len = out_unlocked(s, l);
    1628:	8522                	mv	a0,s0
    162a:	222000ef          	jal	ra,184c <out_unlocked>
		s += 2;
    162e:	00248993          	addi	s3,s1,2
    1632:	bf81                	j	1582 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1634:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1638:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    163c:	0f578663          	beq	a5,s5,1728 <printf+0x368>
		len = out_unlocked(s, l);
    1640:	0828                	addi	a0,sp,24
    1642:	316000ef          	jal	ra,1958 <out_unlocked.constprop.0>
			putchar(s[1]);
    1646:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    164a:	108a2783          	lw	a5,264(s4)
	char byte = c;
    164e:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1652:	05578163          	beq	a5,s5,1694 <printf+0x2d4>
		len = out_unlocked(s, l);
    1656:	0828                	addi	a0,sp,24
    1658:	300000ef          	jal	ra,1958 <out_unlocked.constprop.0>
		s += 2;
    165c:	00248993          	addi	s3,s1,2
    1660:	b70d                	j	1582 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1662:	67c2                	ld	a5,16(sp)
    1664:	45a9                	li	a1,10
		s += 2;
    1666:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    166a:	4388                	lw	a0,0(a5)
    166c:	07a1                	addi	a5,a5,8
    166e:	e83e                	sd	a5,16(sp)
    1670:	588000ef          	jal	ra,1bf8 <printint.constprop.0>
		s += 2;
    1674:	b739                	j	1582 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1676:	10ca2503          	lw	a0,268(s4)
		s += 2;
    167a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    167e:	1e2010ef          	jal	ra,2860 <mutex_lock>
		len = out_unlocked(s, l);
    1682:	45c9                	li	a1,18
    1684:	0828                	addi	a0,sp,24
    1686:	1c6000ef          	jal	ra,184c <out_unlocked>
		mutex_unlock(buffer_lock);
    168a:	10ca2503          	lw	a0,268(s4)
    168e:	1de010ef          	jal	ra,286c <mutex_unlock>
		s += 2;
    1692:	bdc5                	j	1582 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1694:	10ca2503          	lw	a0,268(s4)
    1698:	1c8010ef          	jal	ra,2860 <mutex_lock>
		buffer[buffer_len++] = c;
    169c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16a0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16a4:	0017861b          	addiw	a2,a5,1
    16a8:	97d2                	add	a5,a5,s4
    16aa:	00ca2023          	sw	a2,0(s4)
    16ae:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16b2:	00c6cc63          	blt	a3,a2,16ca <printf+0x30a>
    16b6:	47a9                	li	a5,10
    16b8:	06f40663          	beq	s0,a5,1724 <printf+0x364>
		mutex_unlock(buffer_lock);
    16bc:	10ca2503          	lw	a0,268(s4)
		s += 2;
    16c0:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    16c4:	1a8010ef          	jal	ra,286c <mutex_unlock>
		s += 2;
    16c8:	bd6d                	j	1582 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    16ca:	10000793          	li	a5,256
    16ce:	00f61e63          	bne	a2,a5,16ea <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    16d2:	00001597          	auipc	a1,0x1
    16d6:	49e58593          	addi	a1,a1,1182 # 2b70 <buffer>
    16da:	4505                	li	a0,1
    16dc:	70d000ef          	jal	ra,25e8 <write>
	buffer_len = 0;
    16e0:	00001797          	auipc	a5,0x1
    16e4:	4807a423          	sw	zero,1160(a5) # 2b68 <buffer_len>
			if (r < 0) {
    16e8:	bfd1                	j	16bc <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    16ea:	709000ef          	jal	ra,25f2 <getpid>
    16ee:	842a                	mv	s0,a0
    16f0:	00001517          	auipc	a0,0x1
    16f4:	34050513          	addi	a0,a0,832 # 2a30 <enable_deadlock_detect+0x170>
    16f8:	5d1000ef          	jal	ra,24c8 <basename>
    16fc:	872a                	mv	a4,a0
    16fe:	00001617          	auipc	a2,0x1
    1702:	22260613          	addi	a2,a2,546 # 2920 <enable_deadlock_detect+0x60>
    1706:	05400793          	li	a5,84
    170a:	86a2                	mv	a3,s0
    170c:	45fd                	li	a1,31
    170e:	00001517          	auipc	a0,0x1
    1712:	36250513          	addi	a0,a0,866 # 2a70 <enable_deadlock_detect+0x1b0>
    1716:	cabff0ef          	jal	ra,13c0 <printf>
    171a:	557d                	li	a0,-1
    171c:	707000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    1720:	000a2603          	lw	a2,0(s4)
    1724:	de41                	beqz	a2,16bc <printf+0x2fc>
    1726:	b775                	j	16d2 <printf+0x312>
		mutex_lock(buffer_lock);
    1728:	10ca2503          	lw	a0,268(s4)
    172c:	134010ef          	jal	ra,2860 <mutex_lock>
		buffer[buffer_len++] = c;
    1730:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1734:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1738:	0017861b          	addiw	a2,a5,1
    173c:	97d2                	add	a5,a5,s4
    173e:	00ca2023          	sw	a2,0(s4)
    1742:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1746:	02c6d163          	bge	a3,a2,1768 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    174a:	10000793          	li	a5,256
    174e:	02f61263          	bne	a2,a5,1772 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1752:	00001597          	auipc	a1,0x1
    1756:	41e58593          	addi	a1,a1,1054 # 2b70 <buffer>
    175a:	4505                	li	a0,1
    175c:	68d000ef          	jal	ra,25e8 <write>
	buffer_len = 0;
    1760:	00001797          	auipc	a5,0x1
    1764:	4007a423          	sw	zero,1032(a5) # 2b68 <buffer_len>
		mutex_unlock(buffer_lock);
    1768:	10ca2503          	lw	a0,268(s4)
    176c:	100010ef          	jal	ra,286c <mutex_unlock>
    1770:	bdd9                	j	1646 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1772:	681000ef          	jal	ra,25f2 <getpid>
    1776:	842a                	mv	s0,a0
    1778:	00001517          	auipc	a0,0x1
    177c:	2b850513          	addi	a0,a0,696 # 2a30 <enable_deadlock_detect+0x170>
    1780:	549000ef          	jal	ra,24c8 <basename>
    1784:	872a                	mv	a4,a0
    1786:	00001617          	auipc	a2,0x1
    178a:	19a60613          	addi	a2,a2,410 # 2920 <enable_deadlock_detect+0x60>
    178e:	05400793          	li	a5,84
    1792:	86a2                	mv	a3,s0
    1794:	45fd                	li	a1,31
    1796:	00001517          	auipc	a0,0x1
    179a:	2da50513          	addi	a0,a0,730 # 2a70 <enable_deadlock_detect+0x1b0>
    179e:	c23ff0ef          	jal	ra,13c0 <printf>
    17a2:	557d                	li	a0,-1
    17a4:	67f000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    17a8:	000a2603          	lw	a2,0(s4)
    17ac:	de55                	beqz	a2,1768 <printf+0x3a8>
    17ae:	b755                	j	1752 <printf+0x392>
		mutex_lock(buffer_lock);
    17b0:	10ca2503          	lw	a0,268(s4)
    17b4:	e42e                	sd	a1,8(sp)
		s += 2;
    17b6:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    17ba:	0a6010ef          	jal	ra,2860 <mutex_lock>
		len = out_unlocked(s, l);
    17be:	65a2                	ld	a1,8(sp)
    17c0:	8522                	mv	a0,s0
    17c2:	08a000ef          	jal	ra,184c <out_unlocked>
		mutex_unlock(buffer_lock);
    17c6:	10ca2503          	lw	a0,268(s4)
    17ca:	0a2010ef          	jal	ra,286c <mutex_unlock>
		s += 2;
    17ce:	bb55                	j	1582 <printf+0x1c2>
				a = "(null)";
    17d0:	00001417          	auipc	s0,0x1
    17d4:	25840413          	addi	s0,s0,600 # 2a28 <enable_deadlock_detect+0x168>
    17d8:	bd2d                	j	1612 <printf+0x252>

00000000000017da <enable_thread_io_buffer>:
{
    17da:	1101                	addi	sp,sp,-32
    17dc:	e822                	sd	s0,16(sp)
    17de:	ec06                	sd	ra,24(sp)
    17e0:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    17e2:	00001417          	auipc	s0,0x1
    17e6:	38640413          	addi	s0,s0,902 # 2b68 <buffer_len>
    17ea:	05a010ef          	jal	ra,2844 <mutex_create>
    17ee:	10a42623          	sw	a0,268(s0)
    17f2:	00054a63          	bltz	a0,1806 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17f6:	4785                	li	a5,1
}
    17f8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17fa:	10f42423          	sw	a5,264(s0)
}
    17fe:	6442                	ld	s0,16(sp)
    1800:	64a2                	ld	s1,8(sp)
    1802:	6105                	addi	sp,sp,32
    1804:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1806:	5ed000ef          	jal	ra,25f2 <getpid>
    180a:	84aa                	mv	s1,a0
    180c:	00001517          	auipc	a0,0x1
    1810:	22450513          	addi	a0,a0,548 # 2a30 <enable_deadlock_detect+0x170>
    1814:	4b5000ef          	jal	ra,24c8 <basename>
    1818:	872a                	mv	a4,a0
    181a:	04800793          	li	a5,72
    181e:	86a6                	mv	a3,s1
    1820:	00001517          	auipc	a0,0x1
    1824:	29050513          	addi	a0,a0,656 # 2ab0 <enable_deadlock_detect+0x1f0>
    1828:	00001617          	auipc	a2,0x1
    182c:	0f860613          	addi	a2,a2,248 # 2920 <enable_deadlock_detect+0x60>
    1830:	45fd                	li	a1,31
    1832:	b8fff0ef          	jal	ra,13c0 <printf>
    1836:	557d                	li	a0,-1
    1838:	5eb000ef          	jal	ra,2622 <exit>
	buffer_lock_enabled = 1;
    183c:	4785                	li	a5,1
}
    183e:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1840:	10f42423          	sw	a5,264(s0)
}
    1844:	6442                	ld	s0,16(sp)
    1846:	64a2                	ld	s1,8(sp)
    1848:	6105                	addi	sp,sp,32
    184a:	8082                	ret

000000000000184c <out_unlocked>:
{
    184c:	7159                	addi	sp,sp,-112
    184e:	f486                	sd	ra,104(sp)
    1850:	f0a2                	sd	s0,96(sp)
    1852:	eca6                	sd	s1,88(sp)
    1854:	e8ca                	sd	s2,80(sp)
    1856:	e4ce                	sd	s3,72(sp)
    1858:	e0d2                	sd	s4,64(sp)
    185a:	fc56                	sd	s5,56(sp)
    185c:	f85a                	sd	s6,48(sp)
    185e:	f45e                	sd	s7,40(sp)
    1860:	f062                	sd	s8,32(sp)
    1862:	ec66                	sd	s9,24(sp)
    1864:	e86a                	sd	s10,16(sp)
    1866:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1868:	0e058663          	beqz	a1,1954 <out_unlocked+0x108>
    186c:	842a                	mv	s0,a0
    186e:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1872:	4981                	li	s3,0
    1874:	00001d17          	auipc	s10,0x1
    1878:	2f4d0d13          	addi	s10,s10,756 # 2b68 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    187c:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1880:	00001b17          	auipc	s6,0x1
    1884:	2f0b0b13          	addi	s6,s6,752 # 2b70 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1888:	10000a93          	li	s5,256
    188c:	00001c97          	auipc	s9,0x1
    1890:	1a4c8c93          	addi	s9,s9,420 # 2a30 <enable_deadlock_detect+0x170>
    1894:	00001c17          	auipc	s8,0x1
    1898:	08cc0c13          	addi	s8,s8,140 # 2920 <enable_deadlock_detect+0x60>
    189c:	00001b97          	auipc	s7,0x1
    18a0:	1d4b8b93          	addi	s7,s7,468 # 2a70 <enable_deadlock_detect+0x1b0>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18a4:	4a29                	li	s4,10
    18a6:	a031                	j	18b2 <out_unlocked+0x66>
    18a8:	09468863          	beq	a3,s4,1938 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    18ac:	0405                	addi	s0,s0,1
    18ae:	04848163          	beq	s1,s0,18f0 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    18b2:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    18b6:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    18ba:	0017861b          	addiw	a2,a5,1
    18be:	97ea                	add	a5,a5,s10
    18c0:	00cd2023          	sw	a2,0(s10)
    18c4:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18c8:	fec950e3          	bge	s2,a2,18a8 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    18cc:	05561263          	bne	a2,s5,1910 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    18d0:	85da                	mv	a1,s6
    18d2:	4505                	li	a0,1
    18d4:	515000ef          	jal	ra,25e8 <write>
    18d8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18da:	00001797          	auipc	a5,0x1
    18de:	2807a723          	sw	zero,654(a5) # 2b68 <buffer_len>
			if (r < 0) {
    18e2:	06054763          	bltz	a0,1950 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    18e6:	0405                	addi	s0,s0,1
			ret += r;
    18e8:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    18ec:	fc8493e3          	bne	s1,s0,18b2 <out_unlocked+0x66>
}
    18f0:	70a6                	ld	ra,104(sp)
    18f2:	7406                	ld	s0,96(sp)
    18f4:	64e6                	ld	s1,88(sp)
    18f6:	6946                	ld	s2,80(sp)
    18f8:	6a06                	ld	s4,64(sp)
    18fa:	7ae2                	ld	s5,56(sp)
    18fc:	7b42                	ld	s6,48(sp)
    18fe:	7ba2                	ld	s7,40(sp)
    1900:	7c02                	ld	s8,32(sp)
    1902:	6ce2                	ld	s9,24(sp)
    1904:	6d42                	ld	s10,16(sp)
    1906:	6da2                	ld	s11,8(sp)
    1908:	854e                	mv	a0,s3
    190a:	69a6                	ld	s3,72(sp)
    190c:	6165                	addi	sp,sp,112
    190e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1910:	4e3000ef          	jal	ra,25f2 <getpid>
    1914:	8daa                	mv	s11,a0
    1916:	8566                	mv	a0,s9
    1918:	3b1000ef          	jal	ra,24c8 <basename>
    191c:	872a                	mv	a4,a0
    191e:	8662                	mv	a2,s8
    1920:	05400793          	li	a5,84
    1924:	86ee                	mv	a3,s11
    1926:	45fd                	li	a1,31
    1928:	855e                	mv	a0,s7
    192a:	a97ff0ef          	jal	ra,13c0 <printf>
    192e:	557d                	li	a0,-1
    1930:	4f3000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    1934:	000d2603          	lw	a2,0(s10)
    1938:	da35                	beqz	a2,18ac <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    193a:	85da                	mv	a1,s6
    193c:	4505                	li	a0,1
    193e:	4ab000ef          	jal	ra,25e8 <write>
    1942:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1944:	00001797          	auipc	a5,0x1
    1948:	2207a223          	sw	zero,548(a5) # 2b68 <buffer_len>
			if (r < 0) {
    194c:	f8055de3          	bgez	a0,18e6 <out_unlocked+0x9a>
    1950:	89aa                	mv	s3,a0
    1952:	bf79                	j	18f0 <out_unlocked+0xa4>
	int ret = 0;
    1954:	4981                	li	s3,0
    1956:	bf69                	j	18f0 <out_unlocked+0xa4>

0000000000001958 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1958:	1101                	addi	sp,sp,-32
    195a:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    195c:	00001497          	auipc	s1,0x1
    1960:	20c48493          	addi	s1,s1,524 # 2b68 <buffer_len>
    1964:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1966:	ec06                	sd	ra,24(sp)
    1968:	e822                	sd	s0,16(sp)
		char c = s[i];
    196a:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    196e:	0017861b          	addiw	a2,a5,1
    1972:	97a6                	add	a5,a5,s1
    1974:	00e78423          	sb	a4,8(a5)
    1978:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    197a:	0ff00793          	li	a5,255
    197e:	00c7cc63          	blt	a5,a2,1996 <out_unlocked.constprop.0+0x3e>
    1982:	47a9                	li	a5,10
    1984:	06f70c63          	beq	a4,a5,19fc <out_unlocked.constprop.0+0xa4>
    1988:	4601                	li	a2,0
}
    198a:	60e2                	ld	ra,24(sp)
    198c:	6442                	ld	s0,16(sp)
    198e:	64a2                	ld	s1,8(sp)
    1990:	8532                	mv	a0,a2
    1992:	6105                	addi	sp,sp,32
    1994:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1996:	10000793          	li	a5,256
    199a:	02f61563          	bne	a2,a5,19c4 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    199e:	00001597          	auipc	a1,0x1
    19a2:	1d258593          	addi	a1,a1,466 # 2b70 <buffer>
    19a6:	4505                	li	a0,1
    19a8:	441000ef          	jal	ra,25e8 <write>
}
    19ac:	60e2                	ld	ra,24(sp)
    19ae:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    19b0:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19b4:	00001797          	auipc	a5,0x1
    19b8:	1a07aa23          	sw	zero,436(a5) # 2b68 <buffer_len>
}
    19bc:	64a2                	ld	s1,8(sp)
    19be:	8532                	mv	a0,a2
    19c0:	6105                	addi	sp,sp,32
    19c2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19c4:	42f000ef          	jal	ra,25f2 <getpid>
    19c8:	842a                	mv	s0,a0
    19ca:	00001517          	auipc	a0,0x1
    19ce:	06650513          	addi	a0,a0,102 # 2a30 <enable_deadlock_detect+0x170>
    19d2:	2f7000ef          	jal	ra,24c8 <basename>
    19d6:	872a                	mv	a4,a0
    19d8:	00001617          	auipc	a2,0x1
    19dc:	f4860613          	addi	a2,a2,-184 # 2920 <enable_deadlock_detect+0x60>
    19e0:	05400793          	li	a5,84
    19e4:	86a2                	mv	a3,s0
    19e6:	45fd                	li	a1,31
    19e8:	00001517          	auipc	a0,0x1
    19ec:	08850513          	addi	a0,a0,136 # 2a70 <enable_deadlock_detect+0x1b0>
    19f0:	9d1ff0ef          	jal	ra,13c0 <printf>
    19f4:	557d                	li	a0,-1
    19f6:	42d000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    19fa:	4090                	lw	a2,0(s1)
    19fc:	d659                	beqz	a2,198a <out_unlocked.constprop.0+0x32>
    19fe:	b745                	j	199e <out_unlocked.constprop.0+0x46>

0000000000001a00 <putchar>:
{
    1a00:	7139                	addi	sp,sp,-64
    1a02:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1a04:	00001497          	auipc	s1,0x1
    1a08:	16448493          	addi	s1,s1,356 # 2b68 <buffer_len>
    1a0c:	1084a703          	lw	a4,264(s1)
{
    1a10:	f822                	sd	s0,48(sp)
	char byte = c;
    1a12:	0ff57413          	zext.b	s0,a0
{
    1a16:	fc06                	sd	ra,56(sp)
	char byte = c;
    1a18:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1a1c:	4785                	li	a5,1
    1a1e:	00f70d63          	beq	a4,a5,1a38 <putchar+0x38>
		len = out_unlocked(s, l);
    1a22:	01f10513          	addi	a0,sp,31
    1a26:	f33ff0ef          	jal	ra,1958 <out_unlocked.constprop.0>
}
    1a2a:	70e2                	ld	ra,56(sp)
    1a2c:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1a2e:	862a                	mv	a2,a0
}
    1a30:	74a2                	ld	s1,40(sp)
    1a32:	8532                	mv	a0,a2
    1a34:	6121                	addi	sp,sp,64
    1a36:	8082                	ret
		mutex_lock(buffer_lock);
    1a38:	10c4a503          	lw	a0,268(s1)
    1a3c:	625000ef          	jal	ra,2860 <mutex_lock>
		buffer[buffer_len++] = c;
    1a40:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a42:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a46:	0017861b          	addiw	a2,a5,1
    1a4a:	97a6                	add	a5,a5,s1
    1a4c:	c090                	sw	a2,0(s1)
    1a4e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a52:	02c6c263          	blt	a3,a2,1a76 <putchar+0x76>
    1a56:	47a9                	li	a5,10
    1a58:	06f40d63          	beq	s0,a5,1ad2 <putchar+0xd2>
    1a5c:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a5e:	10c4a503          	lw	a0,268(s1)
    1a62:	e432                	sd	a2,8(sp)
    1a64:	609000ef          	jal	ra,286c <mutex_unlock>
    1a68:	6622                	ld	a2,8(sp)
}
    1a6a:	70e2                	ld	ra,56(sp)
    1a6c:	7442                	ld	s0,48(sp)
    1a6e:	74a2                	ld	s1,40(sp)
    1a70:	8532                	mv	a0,a2
    1a72:	6121                	addi	sp,sp,64
    1a74:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a76:	10000793          	li	a5,256
    1a7a:	02f61063          	bne	a2,a5,1a9a <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a7e:	00001597          	auipc	a1,0x1
    1a82:	0f258593          	addi	a1,a1,242 # 2b70 <buffer>
    1a86:	4505                	li	a0,1
    1a88:	361000ef          	jal	ra,25e8 <write>
    1a8c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a90:	00001797          	auipc	a5,0x1
    1a94:	0c07ac23          	sw	zero,216(a5) # 2b68 <buffer_len>
			if (r < 0) {
    1a98:	b7d9                	j	1a5e <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a9a:	359000ef          	jal	ra,25f2 <getpid>
    1a9e:	842a                	mv	s0,a0
    1aa0:	00001517          	auipc	a0,0x1
    1aa4:	f9050513          	addi	a0,a0,-112 # 2a30 <enable_deadlock_detect+0x170>
    1aa8:	221000ef          	jal	ra,24c8 <basename>
    1aac:	872a                	mv	a4,a0
    1aae:	00001617          	auipc	a2,0x1
    1ab2:	e7260613          	addi	a2,a2,-398 # 2920 <enable_deadlock_detect+0x60>
    1ab6:	05400793          	li	a5,84
    1aba:	86a2                	mv	a3,s0
    1abc:	45fd                	li	a1,31
    1abe:	00001517          	auipc	a0,0x1
    1ac2:	fb250513          	addi	a0,a0,-78 # 2a70 <enable_deadlock_detect+0x1b0>
    1ac6:	8fbff0ef          	jal	ra,13c0 <printf>
    1aca:	557d                	li	a0,-1
    1acc:	357000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    1ad0:	4090                	lw	a2,0(s1)
    1ad2:	d651                	beqz	a2,1a5e <putchar+0x5e>
    1ad4:	b76d                	j	1a7e <putchar+0x7e>

0000000000001ad6 <puts>:
{
    1ad6:	7139                	addi	sp,sp,-64
    1ad8:	f822                	sd	s0,48(sp)
    1ada:	f426                	sd	s1,40(sp)
    1adc:	fc06                	sd	ra,56(sp)
    1ade:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1ae0:	00001417          	auipc	s0,0x1
    1ae4:	08840413          	addi	s0,s0,136 # 2b68 <buffer_len>
{
    1ae8:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aea:	638000ef          	jal	ra,2122 <strlen>
	if (buffer_lock_enabled == 1) {
    1aee:	10842703          	lw	a4,264(s0)
    1af2:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1af4:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1af6:	04f70563          	beq	a4,a5,1b40 <puts+0x6a>
		len = out_unlocked(s, l);
    1afa:	8526                	mv	a0,s1
    1afc:	d51ff0ef          	jal	ra,184c <out_unlocked>
    1b00:	892a                	mv	s2,a0
    1b02:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b04:	00095963          	bgez	s2,1b16 <puts+0x40>
}
    1b08:	70e2                	ld	ra,56(sp)
    1b0a:	7442                	ld	s0,48(sp)
    1b0c:	7902                	ld	s2,32(sp)
    1b0e:	8526                	mv	a0,s1
    1b10:	74a2                	ld	s1,40(sp)
    1b12:	6121                	addi	sp,sp,64
    1b14:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1b16:	10842703          	lw	a4,264(s0)
	char byte = c;
    1b1a:	44a9                	li	s1,10
    1b1c:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1b20:	4785                	li	a5,1
    1b22:	02f70e63          	beq	a4,a5,1b5e <puts+0x88>
		len = out_unlocked(s, l);
    1b26:	01f10513          	addi	a0,sp,31
    1b2a:	e2fff0ef          	jal	ra,1958 <out_unlocked.constprop.0>
}
    1b2e:	70e2                	ld	ra,56(sp)
    1b30:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b32:	41f5549b          	sraiw	s1,a0,0x1f
}
    1b36:	7902                	ld	s2,32(sp)
    1b38:	8526                	mv	a0,s1
    1b3a:	74a2                	ld	s1,40(sp)
    1b3c:	6121                	addi	sp,sp,64
    1b3e:	8082                	ret
		mutex_lock(buffer_lock);
    1b40:	e42a                	sd	a0,8(sp)
    1b42:	10c42503          	lw	a0,268(s0)
    1b46:	51b000ef          	jal	ra,2860 <mutex_lock>
		len = out_unlocked(s, l);
    1b4a:	65a2                	ld	a1,8(sp)
    1b4c:	8526                	mv	a0,s1
    1b4e:	cffff0ef          	jal	ra,184c <out_unlocked>
    1b52:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b54:	10c42503          	lw	a0,268(s0)
    1b58:	515000ef          	jal	ra,286c <mutex_unlock>
    1b5c:	b75d                	j	1b02 <puts+0x2c>
		mutex_lock(buffer_lock);
    1b5e:	10c42503          	lw	a0,268(s0)
    1b62:	4ff000ef          	jal	ra,2860 <mutex_lock>
		buffer[buffer_len++] = c;
    1b66:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b68:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b6c:	0017861b          	addiw	a2,a5,1
    1b70:	97a2                	add	a5,a5,s0
    1b72:	c010                	sw	a2,0(s0)
    1b74:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b78:	06c6dc63          	bge	a3,a2,1bf0 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b7c:	10000793          	li	a5,256
    1b80:	02f61c63          	bne	a2,a5,1bb8 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b84:	00001597          	auipc	a1,0x1
    1b88:	fec58593          	addi	a1,a1,-20 # 2b70 <buffer>
    1b8c:	4505                	li	a0,1
    1b8e:	25b000ef          	jal	ra,25e8 <write>
			if (r < 0) {
    1b92:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b94:	00001797          	auipc	a5,0x1
    1b98:	fc07aa23          	sw	zero,-44(a5) # 2b68 <buffer_len>
			if (r < 0) {
    1b9c:	04054c63          	bltz	a0,1bf4 <puts+0x11e>
			if (r < buffer_len) {
    1ba0:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1ba2:	10c42503          	lw	a0,268(s0)
    1ba6:	4c7000ef          	jal	ra,286c <mutex_unlock>
}
    1baa:	70e2                	ld	ra,56(sp)
    1bac:	7442                	ld	s0,48(sp)
    1bae:	7902                	ld	s2,32(sp)
    1bb0:	8526                	mv	a0,s1
    1bb2:	74a2                	ld	s1,40(sp)
    1bb4:	6121                	addi	sp,sp,64
    1bb6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bb8:	23b000ef          	jal	ra,25f2 <getpid>
    1bbc:	84aa                	mv	s1,a0
    1bbe:	00001517          	auipc	a0,0x1
    1bc2:	e7250513          	addi	a0,a0,-398 # 2a30 <enable_deadlock_detect+0x170>
    1bc6:	103000ef          	jal	ra,24c8 <basename>
    1bca:	872a                	mv	a4,a0
    1bcc:	00001617          	auipc	a2,0x1
    1bd0:	d5460613          	addi	a2,a2,-684 # 2920 <enable_deadlock_detect+0x60>
    1bd4:	05400793          	li	a5,84
    1bd8:	86a6                	mv	a3,s1
    1bda:	45fd                	li	a1,31
    1bdc:	00001517          	auipc	a0,0x1
    1be0:	e9450513          	addi	a0,a0,-364 # 2a70 <enable_deadlock_detect+0x1b0>
    1be4:	fdcff0ef          	jal	ra,13c0 <printf>
    1be8:	557d                	li	a0,-1
    1bea:	239000ef          	jal	ra,2622 <exit>
	if (buffer_len == 0)
    1bee:	4010                	lw	a2,0(s0)
    1bf0:	da45                	beqz	a2,1ba0 <puts+0xca>
    1bf2:	bf49                	j	1b84 <puts+0xae>
    1bf4:	54fd                	li	s1,-1
    1bf6:	b775                	j	1ba2 <puts+0xcc>

0000000000001bf8 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1bf8:	715d                	addi	sp,sp,-80
    1bfa:	e486                	sd	ra,72(sp)
    1bfc:	e0a2                	sd	s0,64(sp)
    1bfe:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1c00:	14054363          	bltz	a0,1d46 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1c04:	02b577bb          	remuw	a5,a0,a1
    1c08:	00001617          	auipc	a2,0x1
    1c0c:	07060613          	addi	a2,a2,112 # 2c78 <digits>
	buf[16] = 0;
    1c10:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c14:	0005871b          	sext.w	a4,a1
    1c18:	1782                	slli	a5,a5,0x20
    1c1a:	9381                	srli	a5,a5,0x20
    1c1c:	97b2                	add	a5,a5,a2
    1c1e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c22:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1c26:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1c2a:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1c2c:	0eb56763          	bltu	a0,a1,1d1a <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c30:	02e877bb          	remuw	a5,a6,a4
    1c34:	1782                	slli	a5,a5,0x20
    1c36:	9381                	srli	a5,a5,0x20
    1c38:	97b2                	add	a5,a5,a2
    1c3a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c3e:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1c42:	02f10323          	sb	a5,38(sp)
    1c46:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1c48:	0ce86963          	bltu	a6,a4,1d1a <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c4c:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c50:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c54:	1582                	slli	a1,a1,0x20
    1c56:	9181                	srli	a1,a1,0x20
    1c58:	95b2                	add	a1,a1,a2
    1c5a:	0005c583          	lbu	a1,0(a1)
    1c5e:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c62:	0007859b          	sext.w	a1,a5
    1c66:	16e6e563          	bltu	a3,a4,1dd0 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c6a:	02e7f6bb          	remuw	a3,a5,a4
    1c6e:	1682                	slli	a3,a3,0x20
    1c70:	9281                	srli	a3,a3,0x20
    1c72:	96b2                	add	a3,a3,a2
    1c74:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c78:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c7c:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c80:	16e5e163          	bltu	a1,a4,1de2 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c84:	02e876bb          	remuw	a3,a6,a4
    1c88:	1682                	slli	a3,a3,0x20
    1c8a:	9281                	srli	a3,a3,0x20
    1c8c:	96b2                	add	a3,a3,a2
    1c8e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c92:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c96:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c9a:	14e86d63          	bltu	a6,a4,1df4 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c9e:	02e5f6bb          	remuw	a3,a1,a4
    1ca2:	1682                	slli	a3,a3,0x20
    1ca4:	9281                	srli	a3,a3,0x20
    1ca6:	96b2                	add	a3,a3,a2
    1ca8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cac:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1cb0:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1cb4:	10e5e563          	bltu	a1,a4,1dbe <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1cb8:	02e876bb          	remuw	a3,a6,a4
    1cbc:	1682                	slli	a3,a3,0x20
    1cbe:	9281                	srli	a3,a3,0x20
    1cc0:	96b2                	add	a3,a3,a2
    1cc2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cc6:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cca:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1cce:	14e86263          	bltu	a6,a4,1e12 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1cd2:	02e5f6bb          	remuw	a3,a1,a4
    1cd6:	1682                	slli	a3,a3,0x20
    1cd8:	9281                	srli	a3,a3,0x20
    1cda:	96b2                	add	a3,a3,a2
    1cdc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ce0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ce4:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ce8:	14e5e463          	bltu	a1,a4,1e30 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1cec:	02e876bb          	remuw	a3,a6,a4
    1cf0:	1682                	slli	a3,a3,0x20
    1cf2:	9281                	srli	a3,a3,0x20
    1cf4:	96b2                	add	a3,a3,a2
    1cf6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cfa:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1cfe:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1d02:	14e86063          	bltu	a6,a4,1e42 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1d06:	1782                	slli	a5,a5,0x20
    1d08:	9381                	srli	a5,a5,0x20
    1d0a:	97b2                	add	a5,a5,a2
    1d0c:	0007c703          	lbu	a4,0(a5)
    1d10:	4799                	li	a5,6
    1d12:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1d16:	10054763          	bltz	a0,1e24 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1d1a:	00001497          	auipc	s1,0x1
    1d1e:	e4e48493          	addi	s1,s1,-434 # 2b68 <buffer_len>
    1d22:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1d26:	0828                	addi	a0,sp,24
    1d28:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1d2a:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1d2c:	00f50433          	add	s0,a0,a5
    1d30:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1d32:	06e68463          	beq	a3,a4,1d9a <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1d36:	8522                	mv	a0,s0
    1d38:	b15ff0ef          	jal	ra,184c <out_unlocked>
}
    1d3c:	60a6                	ld	ra,72(sp)
    1d3e:	6406                	ld	s0,64(sp)
    1d40:	74e2                	ld	s1,56(sp)
    1d42:	6161                	addi	sp,sp,80
    1d44:	8082                	ret
		x = -xx;
    1d46:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d4a:	02b877bb          	remuw	a5,a6,a1
    1d4e:	00001617          	auipc	a2,0x1
    1d52:	f2a60613          	addi	a2,a2,-214 # 2c78 <digits>
	buf[16] = 0;
    1d56:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d5a:	0005871b          	sext.w	a4,a1
    1d5e:	1782                	slli	a5,a5,0x20
    1d60:	9381                	srli	a5,a5,0x20
    1d62:	97b2                	add	a5,a5,a2
    1d64:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d68:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d6c:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d70:	08b86b63          	bltu	a6,a1,1e06 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d74:	02e8f7bb          	remuw	a5,a7,a4
    1d78:	1782                	slli	a5,a5,0x20
    1d7a:	9381                	srli	a5,a5,0x20
    1d7c:	97b2                	add	a5,a5,a2
    1d7e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d82:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d86:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d8a:	ece8f1e3          	bgeu	a7,a4,1c4c <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d8e:	02d00793          	li	a5,45
    1d92:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d96:	47b5                	li	a5,13
    1d98:	b749                	j	1d1a <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d9a:	10c4a503          	lw	a0,268(s1)
    1d9e:	e42e                	sd	a1,8(sp)
    1da0:	2c1000ef          	jal	ra,2860 <mutex_lock>
		len = out_unlocked(s, l);
    1da4:	65a2                	ld	a1,8(sp)
    1da6:	8522                	mv	a0,s0
    1da8:	aa5ff0ef          	jal	ra,184c <out_unlocked>
		mutex_unlock(buffer_lock);
    1dac:	10c4a503          	lw	a0,268(s1)
    1db0:	2bd000ef          	jal	ra,286c <mutex_unlock>
}
    1db4:	60a6                	ld	ra,72(sp)
    1db6:	6406                	ld	s0,64(sp)
    1db8:	74e2                	ld	s1,56(sp)
    1dba:	6161                	addi	sp,sp,80
    1dbc:	8082                	ret
		buf[i--] = digits[x % base];
    1dbe:	47a9                	li	a5,10
	if (sign)
    1dc0:	f4055de3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dc4:	02d00793          	li	a5,45
    1dc8:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1dcc:	47a5                	li	a5,9
    1dce:	b7b1                	j	1d1a <printint.constprop.0+0x122>
    1dd0:	47b5                	li	a5,13
	if (sign)
    1dd2:	f40554e3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dd6:	02d00793          	li	a5,45
    1dda:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1dde:	47b1                	li	a5,12
    1de0:	bf2d                	j	1d1a <printint.constprop.0+0x122>
    1de2:	47b1                	li	a5,12
	if (sign)
    1de4:	f2055be3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de8:	02d00793          	li	a5,45
    1dec:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1df0:	47ad                	li	a5,11
    1df2:	b725                	j	1d1a <printint.constprop.0+0x122>
    1df4:	47ad                	li	a5,11
	if (sign)
    1df6:	f20552e3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dfa:	02d00793          	li	a5,45
    1dfe:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1e02:	47a9                	li	a5,10
    1e04:	bf19                	j	1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e06:	02d00793          	li	a5,45
    1e0a:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1e0e:	47b9                	li	a5,14
    1e10:	b729                	j	1d1a <printint.constprop.0+0x122>
    1e12:	47a5                	li	a5,9
	if (sign)
    1e14:	f00553e3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e18:	02d00793          	li	a5,45
    1e1c:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1e20:	47a1                	li	a5,8
    1e22:	bde5                	j	1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e24:	02d00793          	li	a5,45
    1e28:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1e2c:	4795                	li	a5,5
    1e2e:	b5f5                	j	1d1a <printint.constprop.0+0x122>
    1e30:	47a1                	li	a5,8
	if (sign)
    1e32:	ee0554e3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e36:	02d00793          	li	a5,45
    1e3a:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1e3e:	479d                	li	a5,7
    1e40:	bde9                	j	1d1a <printint.constprop.0+0x122>
    1e42:	479d                	li	a5,7
	if (sign)
    1e44:	ec055be3          	bgez	a0,1d1a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e48:	02d00793          	li	a5,45
    1e4c:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e50:	4799                	li	a5,6
    1e52:	b5e1                	j	1d1a <printint.constprop.0+0x122>

0000000000001e54 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e54:	02000793          	li	a5,32
    1e58:	00f50663          	beq	a0,a5,1e64 <isspace+0x10>
    1e5c:	355d                	addiw	a0,a0,-9
    1e5e:	00553513          	sltiu	a0,a0,5
    1e62:	8082                	ret
    1e64:	4505                	li	a0,1
}
    1e66:	8082                	ret

0000000000001e68 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e68:	fd05051b          	addiw	a0,a0,-48
}
    1e6c:	00a53513          	sltiu	a0,a0,10
    1e70:	8082                	ret

0000000000001e72 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e72:	02000613          	li	a2,32
    1e76:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e78:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e7c:	ff77869b          	addiw	a3,a5,-9
    1e80:	04c78c63          	beq	a5,a2,1ed8 <atoi+0x66>
    1e84:	0007871b          	sext.w	a4,a5
    1e88:	04d5f863          	bgeu	a1,a3,1ed8 <atoi+0x66>
		s++;
	switch (*s) {
    1e8c:	02b00693          	li	a3,43
    1e90:	04d78963          	beq	a5,a3,1ee2 <atoi+0x70>
    1e94:	02d00693          	li	a3,45
    1e98:	06d78263          	beq	a5,a3,1efc <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e9c:	fd07061b          	addiw	a2,a4,-48
    1ea0:	47a5                	li	a5,9
    1ea2:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1ea4:	4e01                	li	t3,0
	while (isdigit(*s))
    1ea6:	04c7e963          	bltu	a5,a2,1ef8 <atoi+0x86>
	int n = 0, neg = 0;
    1eaa:	4501                	li	a0,0
	while (isdigit(*s))
    1eac:	4825                	li	a6,9
    1eae:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1eb2:	0025179b          	slliw	a5,a0,0x2
    1eb6:	9fa9                	addw	a5,a5,a0
    1eb8:	fd07031b          	addiw	t1,a4,-48
    1ebc:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ec0:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ec4:	0685                	addi	a3,a3,1
    1ec6:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1eca:	0006071b          	sext.w	a4,a2
    1ece:	feb870e3          	bgeu	a6,a1,1eae <atoi+0x3c>
	return neg ? n : -n;
    1ed2:	000e0563          	beqz	t3,1edc <atoi+0x6a>
}
    1ed6:	8082                	ret
		s++;
    1ed8:	0505                	addi	a0,a0,1
    1eda:	bf79                	j	1e78 <atoi+0x6>
	return neg ? n : -n;
    1edc:	4113053b          	subw	a0,t1,a7
    1ee0:	8082                	ret
	while (isdigit(*s))
    1ee2:	00154703          	lbu	a4,1(a0)
    1ee6:	47a5                	li	a5,9
		s++;
    1ee8:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1eec:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1ef0:	4e01                	li	t3,0
	while (isdigit(*s))
    1ef2:	2701                	sext.w	a4,a4
    1ef4:	fac7fbe3          	bgeu	a5,a2,1eaa <atoi+0x38>
    1ef8:	4501                	li	a0,0
}
    1efa:	8082                	ret
	while (isdigit(*s))
    1efc:	00154703          	lbu	a4,1(a0)
    1f00:	47a5                	li	a5,9
		s++;
    1f02:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1f06:	fd07061b          	addiw	a2,a4,-48
    1f0a:	2701                	sext.w	a4,a4
    1f0c:	fec7e6e3          	bltu	a5,a2,1ef8 <atoi+0x86>
		neg = 1;
    1f10:	4e05                	li	t3,1
    1f12:	bf61                	j	1eaa <atoi+0x38>

0000000000001f14 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f14:	16060d63          	beqz	a2,208e <memset+0x17a>
    1f18:	40a007b3          	neg	a5,a0
    1f1c:	8b9d                	andi	a5,a5,7
    1f1e:	00778693          	addi	a3,a5,7
    1f22:	482d                	li	a6,11
    1f24:	0ff5f713          	zext.b	a4,a1
    1f28:	fff60593          	addi	a1,a2,-1
    1f2c:	1706e263          	bltu	a3,a6,2090 <memset+0x17c>
    1f30:	16d5ea63          	bltu	a1,a3,20a4 <memset+0x190>
    1f34:	16078563          	beqz	a5,209e <memset+0x18a>
    1f38:	00e50023          	sb	a4,0(a0)
    1f3c:	4685                	li	a3,1
    1f3e:	00150593          	addi	a1,a0,1
    1f42:	14d78c63          	beq	a5,a3,209a <memset+0x186>
    1f46:	00e500a3          	sb	a4,1(a0)
    1f4a:	4689                	li	a3,2
    1f4c:	00250593          	addi	a1,a0,2
    1f50:	14d78d63          	beq	a5,a3,20aa <memset+0x196>
    1f54:	00e50123          	sb	a4,2(a0)
    1f58:	468d                	li	a3,3
    1f5a:	00350593          	addi	a1,a0,3
    1f5e:	12d78b63          	beq	a5,a3,2094 <memset+0x180>
    1f62:	00e501a3          	sb	a4,3(a0)
    1f66:	4691                	li	a3,4
    1f68:	00450593          	addi	a1,a0,4
    1f6c:	14d78163          	beq	a5,a3,20ae <memset+0x19a>
    1f70:	00e50223          	sb	a4,4(a0)
    1f74:	4695                	li	a3,5
    1f76:	00550593          	addi	a1,a0,5
    1f7a:	12d78c63          	beq	a5,a3,20b2 <memset+0x19e>
    1f7e:	00e502a3          	sb	a4,5(a0)
    1f82:	469d                	li	a3,7
    1f84:	00650593          	addi	a1,a0,6
    1f88:	12d79763          	bne	a5,a3,20b6 <memset+0x1a2>
    1f8c:	00750593          	addi	a1,a0,7
    1f90:	00e50323          	sb	a4,6(a0)
    1f94:	481d                	li	a6,7
    1f96:	00871693          	slli	a3,a4,0x8
    1f9a:	01071893          	slli	a7,a4,0x10
    1f9e:	8ed9                	or	a3,a3,a4
    1fa0:	01871313          	slli	t1,a4,0x18
    1fa4:	0116e6b3          	or	a3,a3,a7
    1fa8:	0066e6b3          	or	a3,a3,t1
    1fac:	02071893          	slli	a7,a4,0x20
    1fb0:	02871e13          	slli	t3,a4,0x28
    1fb4:	0116e6b3          	or	a3,a3,a7
    1fb8:	40f60333          	sub	t1,a2,a5
    1fbc:	03071893          	slli	a7,a4,0x30
    1fc0:	01c6e6b3          	or	a3,a3,t3
    1fc4:	0116e6b3          	or	a3,a3,a7
    1fc8:	03871e13          	slli	t3,a4,0x38
    1fcc:	97aa                	add	a5,a5,a0
    1fce:	ff837893          	andi	a7,t1,-8
    1fd2:	01c6e6b3          	or	a3,a3,t3
    1fd6:	98be                	add	a7,a7,a5
    1fd8:	e394                	sd	a3,0(a5)
    1fda:	07a1                	addi	a5,a5,8
    1fdc:	ff179ee3          	bne	a5,a7,1fd8 <memset+0xc4>
    1fe0:	ff837893          	andi	a7,t1,-8
    1fe4:	011587b3          	add	a5,a1,a7
    1fe8:	010886bb          	addw	a3,a7,a6
    1fec:	0b130663          	beq	t1,a7,2098 <memset+0x184>
    1ff0:	00e78023          	sb	a4,0(a5)
    1ff4:	0016859b          	addiw	a1,a3,1
    1ff8:	08c5fb63          	bgeu	a1,a2,208e <memset+0x17a>
    1ffc:	00e780a3          	sb	a4,1(a5)
    2000:	0026859b          	addiw	a1,a3,2
    2004:	08c5f563          	bgeu	a1,a2,208e <memset+0x17a>
    2008:	00e78123          	sb	a4,2(a5)
    200c:	0036859b          	addiw	a1,a3,3
    2010:	06c5ff63          	bgeu	a1,a2,208e <memset+0x17a>
    2014:	00e781a3          	sb	a4,3(a5)
    2018:	0046859b          	addiw	a1,a3,4
    201c:	06c5f963          	bgeu	a1,a2,208e <memset+0x17a>
    2020:	00e78223          	sb	a4,4(a5)
    2024:	0056859b          	addiw	a1,a3,5
    2028:	06c5f363          	bgeu	a1,a2,208e <memset+0x17a>
    202c:	00e782a3          	sb	a4,5(a5)
    2030:	0066859b          	addiw	a1,a3,6
    2034:	04c5fd63          	bgeu	a1,a2,208e <memset+0x17a>
    2038:	00e78323          	sb	a4,6(a5)
    203c:	0076859b          	addiw	a1,a3,7
    2040:	04c5f763          	bgeu	a1,a2,208e <memset+0x17a>
    2044:	00e783a3          	sb	a4,7(a5)
    2048:	0086859b          	addiw	a1,a3,8
    204c:	04c5f163          	bgeu	a1,a2,208e <memset+0x17a>
    2050:	00e78423          	sb	a4,8(a5)
    2054:	0096859b          	addiw	a1,a3,9
    2058:	02c5fb63          	bgeu	a1,a2,208e <memset+0x17a>
    205c:	00e784a3          	sb	a4,9(a5)
    2060:	00a6859b          	addiw	a1,a3,10
    2064:	02c5f563          	bgeu	a1,a2,208e <memset+0x17a>
    2068:	00e78523          	sb	a4,10(a5)
    206c:	00b6859b          	addiw	a1,a3,11
    2070:	00c5ff63          	bgeu	a1,a2,208e <memset+0x17a>
    2074:	00e785a3          	sb	a4,11(a5)
    2078:	00c6859b          	addiw	a1,a3,12
    207c:	00c5f963          	bgeu	a1,a2,208e <memset+0x17a>
    2080:	00e78623          	sb	a4,12(a5)
    2084:	26b5                	addiw	a3,a3,13
    2086:	00c6f463          	bgeu	a3,a2,208e <memset+0x17a>
    208a:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    208e:	8082                	ret
    2090:	46ad                	li	a3,11
    2092:	bd79                	j	1f30 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2094:	480d                	li	a6,3
    2096:	b701                	j	1f96 <memset+0x82>
    2098:	8082                	ret
    209a:	4805                	li	a6,1
    209c:	bded                	j	1f96 <memset+0x82>
    209e:	85aa                	mv	a1,a0
    20a0:	4801                	li	a6,0
    20a2:	bdd5                	j	1f96 <memset+0x82>
    20a4:	87aa                	mv	a5,a0
    20a6:	4681                	li	a3,0
    20a8:	b7a1                	j	1ff0 <memset+0xdc>
    20aa:	4809                	li	a6,2
    20ac:	b5ed                	j	1f96 <memset+0x82>
    20ae:	4811                	li	a6,4
    20b0:	b5dd                	j	1f96 <memset+0x82>
    20b2:	4815                	li	a6,5
    20b4:	b5cd                	j	1f96 <memset+0x82>
    20b6:	4819                	li	a6,6
    20b8:	bdf9                	j	1f96 <memset+0x82>

00000000000020ba <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    20ba:	00054783          	lbu	a5,0(a0)
    20be:	0005c703          	lbu	a4,0(a1)
    20c2:	00e79863          	bne	a5,a4,20d2 <strcmp+0x18>
    20c6:	0505                	addi	a0,a0,1
    20c8:	0585                	addi	a1,a1,1
    20ca:	fbe5                	bnez	a5,20ba <strcmp>
    20cc:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    20ce:	9d19                	subw	a0,a0,a4
    20d0:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    20d2:	0007851b          	sext.w	a0,a5
    20d6:	bfe5                	j	20ce <strcmp+0x14>

00000000000020d8 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    20d8:	ca15                	beqz	a2,210c <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20da:	00054783          	lbu	a5,0(a0)
	if (!n--)
    20de:	167d                	addi	a2,a2,-1
    20e0:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20e4:	eb99                	bnez	a5,20fa <strncmp+0x22>
    20e6:	a815                	j	211a <strncmp+0x42>
    20e8:	00a68e63          	beq	a3,a0,2104 <strncmp+0x2c>
    20ec:	0505                	addi	a0,a0,1
    20ee:	00f71b63          	bne	a4,a5,2104 <strncmp+0x2c>
    20f2:	00054783          	lbu	a5,0(a0)
    20f6:	cf89                	beqz	a5,2110 <strncmp+0x38>
    20f8:	85b2                	mv	a1,a2
    20fa:	0005c703          	lbu	a4,0(a1)
    20fe:	00158613          	addi	a2,a1,1
    2102:	f37d                	bnez	a4,20e8 <strncmp+0x10>
		;
	return *l - *r;
    2104:	0007851b          	sext.w	a0,a5
    2108:	9d19                	subw	a0,a0,a4
    210a:	8082                	ret
		return 0;
    210c:	4501                	li	a0,0
}
    210e:	8082                	ret
	return *l - *r;
    2110:	0015c703          	lbu	a4,1(a1)
    2114:	4501                	li	a0,0
    2116:	9d19                	subw	a0,a0,a4
    2118:	8082                	ret
    211a:	0005c703          	lbu	a4,0(a1)
    211e:	4501                	li	a0,0
    2120:	b7e5                	j	2108 <strncmp+0x30>

0000000000002122 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2122:	00757793          	andi	a5,a0,7
    2126:	cf89                	beqz	a5,2140 <strlen+0x1e>
    2128:	87aa                	mv	a5,a0
    212a:	a029                	j	2134 <strlen+0x12>
    212c:	0785                	addi	a5,a5,1
    212e:	0077f713          	andi	a4,a5,7
    2132:	cb01                	beqz	a4,2142 <strlen+0x20>
		if (!*s)
    2134:	0007c703          	lbu	a4,0(a5)
    2138:	fb75                	bnez	a4,212c <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    213a:	40a78533          	sub	a0,a5,a0
}
    213e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2140:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2142:	6394                	ld	a3,0(a5)
    2144:	00001597          	auipc	a1,0x1
    2148:	9c45b583          	ld	a1,-1596(a1) # 2b08 <enable_deadlock_detect+0x248>
    214c:	00001617          	auipc	a2,0x1
    2150:	9c463603          	ld	a2,-1596(a2) # 2b10 <enable_deadlock_detect+0x250>
    2154:	a019                	j	215a <strlen+0x38>
    2156:	6794                	ld	a3,8(a5)
    2158:	07a1                	addi	a5,a5,8
    215a:	00b68733          	add	a4,a3,a1
    215e:	fff6c693          	not	a3,a3
    2162:	8f75                	and	a4,a4,a3
    2164:	8f71                	and	a4,a4,a2
    2166:	db65                	beqz	a4,2156 <strlen+0x34>
	for (; *s; s++)
    2168:	0007c703          	lbu	a4,0(a5)
    216c:	d779                	beqz	a4,213a <strlen+0x18>
    216e:	0017c703          	lbu	a4,1(a5)
    2172:	0785                	addi	a5,a5,1
    2174:	d379                	beqz	a4,213a <strlen+0x18>
    2176:	0017c703          	lbu	a4,1(a5)
    217a:	0785                	addi	a5,a5,1
    217c:	fb6d                	bnez	a4,216e <strlen+0x4c>
    217e:	bf75                	j	213a <strlen+0x18>

0000000000002180 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2180:	00757713          	andi	a4,a0,7
{
    2184:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2186:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    218a:	cb19                	beqz	a4,21a0 <memchr+0x20>
    218c:	ce25                	beqz	a2,2204 <memchr+0x84>
    218e:	0007c703          	lbu	a4,0(a5)
    2192:	04b70e63          	beq	a4,a1,21ee <memchr+0x6e>
    2196:	0785                	addi	a5,a5,1
    2198:	0077f713          	andi	a4,a5,7
    219c:	167d                	addi	a2,a2,-1
    219e:	f77d                	bnez	a4,218c <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    21a0:	4501                	li	a0,0
	if (n && *s != c) {
    21a2:	c235                	beqz	a2,2206 <memchr+0x86>
    21a4:	0007c703          	lbu	a4,0(a5)
    21a8:	04b70363          	beq	a4,a1,21ee <memchr+0x6e>
		size_t k = ONES * c;
    21ac:	00001517          	auipc	a0,0x1
    21b0:	96c53503          	ld	a0,-1684(a0) # 2b18 <enable_deadlock_detect+0x258>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21b4:	471d                	li	a4,7
		size_t k = ONES * c;
    21b6:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21ba:	02c77a63          	bgeu	a4,a2,21ee <memchr+0x6e>
    21be:	00001897          	auipc	a7,0x1
    21c2:	94a8b883          	ld	a7,-1718(a7) # 2b08 <enable_deadlock_detect+0x248>
    21c6:	00001817          	auipc	a6,0x1
    21ca:	94a83803          	ld	a6,-1718(a6) # 2b10 <enable_deadlock_detect+0x250>
    21ce:	431d                	li	t1,7
    21d0:	a029                	j	21da <memchr+0x5a>
		     w++, n -= SS)
    21d2:	1661                	addi	a2,a2,-8
    21d4:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21d6:	02c37963          	bgeu	t1,a2,2208 <memchr+0x88>
    21da:	6398                	ld	a4,0(a5)
    21dc:	8f29                	xor	a4,a4,a0
    21de:	011706b3          	add	a3,a4,a7
    21e2:	fff74713          	not	a4,a4
    21e6:	8f75                	and	a4,a4,a3
    21e8:	01077733          	and	a4,a4,a6
    21ec:	d37d                	beqz	a4,21d2 <memchr+0x52>
{
    21ee:	853e                	mv	a0,a5
    21f0:	97b2                	add	a5,a5,a2
    21f2:	a021                	j	21fa <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21f4:	0505                	addi	a0,a0,1
    21f6:	00f50763          	beq	a0,a5,2204 <memchr+0x84>
    21fa:	00054703          	lbu	a4,0(a0)
    21fe:	feb71be3          	bne	a4,a1,21f4 <memchr+0x74>
    2202:	8082                	ret
	return n ? (void *)s : 0;
    2204:	4501                	li	a0,0
}
    2206:	8082                	ret
	return n ? (void *)s : 0;
    2208:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    220a:	f275                	bnez	a2,21ee <memchr+0x6e>
}
    220c:	8082                	ret

000000000000220e <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    220e:	1101                	addi	sp,sp,-32
    2210:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2212:	862e                	mv	a2,a1
{
    2214:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2216:	4581                	li	a1,0
{
    2218:	e426                	sd	s1,8(sp)
    221a:	ec06                	sd	ra,24(sp)
    221c:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    221e:	f63ff0ef          	jal	ra,2180 <memchr>
	return p ? p - s : n;
    2222:	c519                	beqz	a0,2230 <strnlen+0x22>
}
    2224:	60e2                	ld	ra,24(sp)
    2226:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2228:	8d05                	sub	a0,a0,s1
}
    222a:	64a2                	ld	s1,8(sp)
    222c:	6105                	addi	sp,sp,32
    222e:	8082                	ret
    2230:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2232:	8522                	mv	a0,s0
}
    2234:	6442                	ld	s0,16(sp)
    2236:	64a2                	ld	s1,8(sp)
    2238:	6105                	addi	sp,sp,32
    223a:	8082                	ret

000000000000223c <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    223c:	00a5c7b3          	xor	a5,a1,a0
    2240:	8b9d                	andi	a5,a5,7
    2242:	eb95                	bnez	a5,2276 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2244:	0075f793          	andi	a5,a1,7
    2248:	e7b1                	bnez	a5,2294 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    224a:	6198                	ld	a4,0(a1)
    224c:	00001617          	auipc	a2,0x1
    2250:	8bc63603          	ld	a2,-1860(a2) # 2b08 <enable_deadlock_detect+0x248>
    2254:	00001817          	auipc	a6,0x1
    2258:	8bc83803          	ld	a6,-1860(a6) # 2b10 <enable_deadlock_detect+0x250>
    225c:	a029                	j	2266 <stpcpy+0x2a>
    225e:	05a1                	addi	a1,a1,8
    2260:	e118                	sd	a4,0(a0)
    2262:	6198                	ld	a4,0(a1)
    2264:	0521                	addi	a0,a0,8
    2266:	00c707b3          	add	a5,a4,a2
    226a:	fff74693          	not	a3,a4
    226e:	8ff5                	and	a5,a5,a3
    2270:	0107f7b3          	and	a5,a5,a6
    2274:	d7ed                	beqz	a5,225e <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2276:	0005c783          	lbu	a5,0(a1)
    227a:	00f50023          	sb	a5,0(a0)
    227e:	c785                	beqz	a5,22a6 <stpcpy+0x6a>
    2280:	0015c783          	lbu	a5,1(a1)
    2284:	0505                	addi	a0,a0,1
    2286:	0585                	addi	a1,a1,1
    2288:	00f50023          	sb	a5,0(a0)
    228c:	fbf5                	bnez	a5,2280 <stpcpy+0x44>
		;
	return d;
}
    228e:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2290:	0505                	addi	a0,a0,1
    2292:	df45                	beqz	a4,224a <stpcpy+0xe>
			if (!(*d = *s))
    2294:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2298:	0585                	addi	a1,a1,1
    229a:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    229e:	00f50023          	sb	a5,0(a0)
    22a2:	f7fd                	bnez	a5,2290 <stpcpy+0x54>
}
    22a4:	8082                	ret
    22a6:	8082                	ret

00000000000022a8 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    22a8:	00a5c7b3          	xor	a5,a1,a0
    22ac:	8b9d                	andi	a5,a5,7
    22ae:	1a079863          	bnez	a5,245e <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    22b2:	0075f793          	andi	a5,a1,7
    22b6:	16078463          	beqz	a5,241e <stpncpy+0x176>
    22ba:	ea01                	bnez	a2,22ca <stpncpy+0x22>
    22bc:	a421                	j	24c4 <stpncpy+0x21c>
    22be:	167d                	addi	a2,a2,-1
    22c0:	0505                	addi	a0,a0,1
    22c2:	14070e63          	beqz	a4,241e <stpncpy+0x176>
    22c6:	1a060863          	beqz	a2,2476 <stpncpy+0x1ce>
    22ca:	0005c783          	lbu	a5,0(a1)
    22ce:	0585                	addi	a1,a1,1
    22d0:	0075f713          	andi	a4,a1,7
    22d4:	00f50023          	sb	a5,0(a0)
    22d8:	f3fd                	bnez	a5,22be <stpncpy+0x16>
    22da:	4805                	li	a6,1
    22dc:	1a061863          	bnez	a2,248c <stpncpy+0x1e4>
    22e0:	40a007b3          	neg	a5,a0
    22e4:	8b9d                	andi	a5,a5,7
    22e6:	4681                	li	a3,0
    22e8:	18061a63          	bnez	a2,247c <stpncpy+0x1d4>
    22ec:	00778713          	addi	a4,a5,7
    22f0:	45ad                	li	a1,11
    22f2:	18b76363          	bltu	a4,a1,2478 <stpncpy+0x1d0>
    22f6:	1ae6eb63          	bltu	a3,a4,24ac <stpncpy+0x204>
    22fa:	1a078363          	beqz	a5,24a0 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22fe:	00050023          	sb	zero,0(a0)
    2302:	4685                	li	a3,1
    2304:	00150713          	addi	a4,a0,1
    2308:	18d78f63          	beq	a5,a3,24a6 <stpncpy+0x1fe>
    230c:	000500a3          	sb	zero,1(a0)
    2310:	4689                	li	a3,2
    2312:	00250713          	addi	a4,a0,2
    2316:	18d78e63          	beq	a5,a3,24b2 <stpncpy+0x20a>
    231a:	00050123          	sb	zero,2(a0)
    231e:	468d                	li	a3,3
    2320:	00350713          	addi	a4,a0,3
    2324:	16d78c63          	beq	a5,a3,249c <stpncpy+0x1f4>
    2328:	000501a3          	sb	zero,3(a0)
    232c:	4691                	li	a3,4
    232e:	00450713          	addi	a4,a0,4
    2332:	18d78263          	beq	a5,a3,24b6 <stpncpy+0x20e>
    2336:	00050223          	sb	zero,4(a0)
    233a:	4695                	li	a3,5
    233c:	00550713          	addi	a4,a0,5
    2340:	16d78d63          	beq	a5,a3,24ba <stpncpy+0x212>
    2344:	000502a3          	sb	zero,5(a0)
    2348:	469d                	li	a3,7
    234a:	00650713          	addi	a4,a0,6
    234e:	16d79863          	bne	a5,a3,24be <stpncpy+0x216>
    2352:	00750713          	addi	a4,a0,7
    2356:	00050323          	sb	zero,6(a0)
    235a:	40f80833          	sub	a6,a6,a5
    235e:	ff887593          	andi	a1,a6,-8
    2362:	97aa                	add	a5,a5,a0
    2364:	95be                	add	a1,a1,a5
    2366:	0007b023          	sd	zero,0(a5)
    236a:	07a1                	addi	a5,a5,8
    236c:	feb79de3          	bne	a5,a1,2366 <stpncpy+0xbe>
    2370:	ff887593          	andi	a1,a6,-8
    2374:	9ead                	addw	a3,a3,a1
    2376:	00b707b3          	add	a5,a4,a1
    237a:	12b80863          	beq	a6,a1,24aa <stpncpy+0x202>
    237e:	00078023          	sb	zero,0(a5)
    2382:	0016871b          	addiw	a4,a3,1
    2386:	0ec77863          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    238a:	000780a3          	sb	zero,1(a5)
    238e:	0026871b          	addiw	a4,a3,2
    2392:	0ec77263          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    2396:	00078123          	sb	zero,2(a5)
    239a:	0036871b          	addiw	a4,a3,3
    239e:	0cc77c63          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23a2:	000781a3          	sb	zero,3(a5)
    23a6:	0046871b          	addiw	a4,a3,4
    23aa:	0cc77663          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23ae:	00078223          	sb	zero,4(a5)
    23b2:	0056871b          	addiw	a4,a3,5
    23b6:	0cc77063          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23ba:	000782a3          	sb	zero,5(a5)
    23be:	0066871b          	addiw	a4,a3,6
    23c2:	0ac77a63          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23c6:	00078323          	sb	zero,6(a5)
    23ca:	0076871b          	addiw	a4,a3,7
    23ce:	0ac77463          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23d2:	000783a3          	sb	zero,7(a5)
    23d6:	0086871b          	addiw	a4,a3,8
    23da:	08c77e63          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23de:	00078423          	sb	zero,8(a5)
    23e2:	0096871b          	addiw	a4,a3,9
    23e6:	08c77863          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23ea:	000784a3          	sb	zero,9(a5)
    23ee:	00a6871b          	addiw	a4,a3,10
    23f2:	08c77263          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    23f6:	00078523          	sb	zero,10(a5)
    23fa:	00b6871b          	addiw	a4,a3,11
    23fe:	06c77c63          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    2402:	000785a3          	sb	zero,11(a5)
    2406:	00c6871b          	addiw	a4,a3,12
    240a:	06c77663          	bgeu	a4,a2,2476 <stpncpy+0x1ce>
    240e:	00078623          	sb	zero,12(a5)
    2412:	26b5                	addiw	a3,a3,13
    2414:	06c6f163          	bgeu	a3,a2,2476 <stpncpy+0x1ce>
    2418:	000786a3          	sb	zero,13(a5)
    241c:	8082                	ret
			;
		if (!n || !*s)
    241e:	c645                	beqz	a2,24c6 <stpncpy+0x21e>
    2420:	0005c783          	lbu	a5,0(a1)
    2424:	ea078be3          	beqz	a5,22da <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2428:	479d                	li	a5,7
    242a:	02c7ff63          	bgeu	a5,a2,2468 <stpncpy+0x1c0>
    242e:	00000897          	auipc	a7,0x0
    2432:	6da8b883          	ld	a7,1754(a7) # 2b08 <enable_deadlock_detect+0x248>
    2436:	00000817          	auipc	a6,0x0
    243a:	6da83803          	ld	a6,1754(a6) # 2b10 <enable_deadlock_detect+0x250>
    243e:	431d                	li	t1,7
    2440:	6198                	ld	a4,0(a1)
    2442:	011707b3          	add	a5,a4,a7
    2446:	fff74693          	not	a3,a4
    244a:	8ff5                	and	a5,a5,a3
    244c:	0107f7b3          	and	a5,a5,a6
    2450:	ef81                	bnez	a5,2468 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2452:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2454:	1661                	addi	a2,a2,-8
    2456:	05a1                	addi	a1,a1,8
    2458:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    245a:	fec363e3          	bltu	t1,a2,2440 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    245e:	e609                	bnez	a2,2468 <stpncpy+0x1c0>
    2460:	a08d                	j	24c2 <stpncpy+0x21a>
    2462:	167d                	addi	a2,a2,-1
    2464:	0505                	addi	a0,a0,1
    2466:	ca01                	beqz	a2,2476 <stpncpy+0x1ce>
    2468:	0005c783          	lbu	a5,0(a1)
    246c:	0585                	addi	a1,a1,1
    246e:	00f50023          	sb	a5,0(a0)
    2472:	fbe5                	bnez	a5,2462 <stpncpy+0x1ba>
		;
tail:
    2474:	b59d                	j	22da <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2476:	8082                	ret
    2478:	472d                	li	a4,11
    247a:	bdb5                	j	22f6 <stpncpy+0x4e>
    247c:	00778713          	addi	a4,a5,7
    2480:	45ad                	li	a1,11
    2482:	fff60693          	addi	a3,a2,-1
    2486:	e6b778e3          	bgeu	a4,a1,22f6 <stpncpy+0x4e>
    248a:	b7fd                	j	2478 <stpncpy+0x1d0>
    248c:	40a007b3          	neg	a5,a0
    2490:	8832                	mv	a6,a2
    2492:	8b9d                	andi	a5,a5,7
    2494:	4681                	li	a3,0
    2496:	e4060be3          	beqz	a2,22ec <stpncpy+0x44>
    249a:	b7cd                	j	247c <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    249c:	468d                	li	a3,3
    249e:	bd75                	j	235a <stpncpy+0xb2>
    24a0:	872a                	mv	a4,a0
    24a2:	4681                	li	a3,0
    24a4:	bd5d                	j	235a <stpncpy+0xb2>
    24a6:	4685                	li	a3,1
    24a8:	bd4d                	j	235a <stpncpy+0xb2>
    24aa:	8082                	ret
    24ac:	87aa                	mv	a5,a0
    24ae:	4681                	li	a3,0
    24b0:	b5f9                	j	237e <stpncpy+0xd6>
    24b2:	4689                	li	a3,2
    24b4:	b55d                	j	235a <stpncpy+0xb2>
    24b6:	4691                	li	a3,4
    24b8:	b54d                	j	235a <stpncpy+0xb2>
    24ba:	4695                	li	a3,5
    24bc:	bd79                	j	235a <stpncpy+0xb2>
    24be:	4699                	li	a3,6
    24c0:	bd69                	j	235a <stpncpy+0xb2>
    24c2:	8082                	ret
    24c4:	8082                	ret
    24c6:	8082                	ret

00000000000024c8 <basename>:

char *basename(char *s)
{
    24c8:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    24ca:	c54d                	beqz	a0,2574 <basename+0xac>
    24cc:	00054783          	lbu	a5,0(a0)
		return ".";
    24d0:	00000517          	auipc	a0,0x0
    24d4:	63050513          	addi	a0,a0,1584 # 2b00 <enable_deadlock_detect+0x240>
	if (!s || !*s)
    24d8:	e391                	bnez	a5,24dc <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    24da:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    24dc:	0076f713          	andi	a4,a3,7
    24e0:	87b6                	mv	a5,a3
    24e2:	cf51                	beqz	a4,257e <basename+0xb6>
    24e4:	0785                	addi	a5,a5,1
    24e6:	0077f713          	andi	a4,a5,7
    24ea:	c729                	beqz	a4,2534 <basename+0x6c>
		if (!*s)
    24ec:	0007c703          	lbu	a4,0(a5)
    24f0:	fb75                	bnez	a4,24e4 <basename+0x1c>
	return s - a;
    24f2:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24f4:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24f6:	cf8d                	beqz	a5,2530 <basename+0x68>
    24f8:	00f68733          	add	a4,a3,a5
    24fc:	02f00593          	li	a1,47
    2500:	a031                	j	250c <basename+0x44>
		s[i] = 0;
    2502:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2506:	17fd                	addi	a5,a5,-1
    2508:	177d                	addi	a4,a4,-1
    250a:	c39d                	beqz	a5,2530 <basename+0x68>
    250c:	00074603          	lbu	a2,0(a4)
    2510:	feb609e3          	beq	a2,a1,2502 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2514:	02f00613          	li	a2,47
    2518:	a011                	j	251c <basename+0x54>
    251a:	cb99                	beqz	a5,2530 <basename+0x68>
    251c:	853e                	mv	a0,a5
    251e:	17fd                	addi	a5,a5,-1
    2520:	00f68733          	add	a4,a3,a5
    2524:	00074703          	lbu	a4,0(a4)
    2528:	fec719e3          	bne	a4,a2,251a <basename+0x52>
	return s + i;
    252c:	9536                	add	a0,a0,a3
    252e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2530:	8536                	mv	a0,a3
    2532:	8082                	ret
    2534:	6390                	ld	a2,0(a5)
    2536:	00000517          	auipc	a0,0x0
    253a:	5d253503          	ld	a0,1490(a0) # 2b08 <enable_deadlock_detect+0x248>
    253e:	00000597          	auipc	a1,0x0
    2542:	5d25b583          	ld	a1,1490(a1) # 2b10 <enable_deadlock_detect+0x250>
    2546:	fff64713          	not	a4,a2
    254a:	962a                	add	a2,a2,a0
    254c:	8f71                	and	a4,a4,a2
    254e:	8f6d                	and	a4,a4,a1
    2550:	eb11                	bnez	a4,2564 <basename+0x9c>
    2552:	6790                	ld	a2,8(a5)
    2554:	07a1                	addi	a5,a5,8
    2556:	00a60733          	add	a4,a2,a0
    255a:	fff64613          	not	a2,a2
    255e:	8f71                	and	a4,a4,a2
    2560:	8f6d                	and	a4,a4,a1
    2562:	db65                	beqz	a4,2552 <basename+0x8a>
	for (; *s; s++)
    2564:	0007c703          	lbu	a4,0(a5)
    2568:	d749                	beqz	a4,24f2 <basename+0x2a>
    256a:	0017c703          	lbu	a4,1(a5)
    256e:	0785                	addi	a5,a5,1
    2570:	ff6d                	bnez	a4,256a <basename+0xa2>
    2572:	b741                	j	24f2 <basename+0x2a>
		return ".";
    2574:	00000517          	auipc	a0,0x0
    2578:	58c50513          	addi	a0,a0,1420 # 2b00 <enable_deadlock_detect+0x240>
    257c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    257e:	6290                	ld	a2,0(a3)
    2580:	00000517          	auipc	a0,0x0
    2584:	58853503          	ld	a0,1416(a0) # 2b08 <enable_deadlock_detect+0x248>
    2588:	00000597          	auipc	a1,0x0
    258c:	5885b583          	ld	a1,1416(a1) # 2b10 <enable_deadlock_detect+0x250>
    2590:	fff64713          	not	a4,a2
    2594:	962a                	add	a2,a2,a0
    2596:	8f71                	and	a4,a4,a2
    2598:	8f6d                	and	a4,a4,a1
    259a:	df45                	beqz	a4,2552 <basename+0x8a>
    259c:	b7f9                	j	256a <basename+0xa2>

000000000000259e <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    259e:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    25a2:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25a4:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    25a8:	2501                	sext.w	a0,a0
    25aa:	8082                	ret

00000000000025ac <close>:

int close(int fd)
{
	if (fd == 1) {
    25ac:	4785                	li	a5,1
    25ae:	00f50863          	beq	a0,a5,25be <close+0x12>
	register long a7 __asm__("a7") = n;
    25b2:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25b6:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    25ba:	2501                	sext.w	a0,a0
    25bc:	8082                	ret
{
    25be:	1101                	addi	sp,sp,-32
    25c0:	ec06                	sd	ra,24(sp)
    25c2:	e42a                	sd	a0,8(sp)
		__write_buffer();
    25c4:	cdffe0ef          	jal	ra,12a2 <__write_buffer>
		__clear_buffer();
    25c8:	d03fe0ef          	jal	ra,12ca <__clear_buffer>
    25cc:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    25ce:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25d2:	00000073          	ecall
}
    25d6:	60e2                	ld	ra,24(sp)
    25d8:	2501                	sext.w	a0,a0
    25da:	6105                	addi	sp,sp,32
    25dc:	8082                	ret

00000000000025de <read>:
	register long a7 __asm__("a7") = n;
    25de:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25e2:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    25e6:	8082                	ret

00000000000025e8 <write>:
	register long a7 __asm__("a7") = n;
    25e8:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ec:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    25f0:	8082                	ret

00000000000025f2 <getpid>:
	register long a7 __asm__("a7") = n;
    25f2:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25f6:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25fa:	2501                	sext.w	a0,a0
    25fc:	8082                	ret

00000000000025fe <getppid>:
	register long a7 __asm__("a7") = n;
    25fe:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2602:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2606:	2501                	sext.w	a0,a0
    2608:	8082                	ret

000000000000260a <sched_yield>:
	register long a7 __asm__("a7") = n;
    260a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    260e:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2612:	2501                	sext.w	a0,a0
    2614:	8082                	ret

0000000000002616 <fork>:
	register long a7 __asm__("a7") = n;
    2616:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    261a:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    261e:	2501                	sext.w	a0,a0
    2620:	8082                	ret

0000000000002622 <exit>:

void exit(int code)
{
    2622:	1141                	addi	sp,sp,-16
    2624:	e406                	sd	ra,8(sp)
    2626:	e022                	sd	s0,0(sp)
    2628:	842a                	mv	s0,a0
	__write_buffer();
    262a:	c79fe0ef          	jal	ra,12a2 <__write_buffer>
	__clear_buffer();
    262e:	c9dfe0ef          	jal	ra,12ca <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2632:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2636:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2638:	00000073          	ecall
	syscall(SYS_exit, code);
}
    263c:	60a2                	ld	ra,8(sp)
    263e:	6402                	ld	s0,0(sp)
    2640:	0141                	addi	sp,sp,16
    2642:	8082                	ret

0000000000002644 <waitpid>:
	register long a7 __asm__("a7") = n;
    2644:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2648:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    264c:	2501                	sext.w	a0,a0
    264e:	8082                	ret

0000000000002650 <exec>:
	register long a7 __asm__("a7") = n;
    2650:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2654:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2658:	2501                	sext.w	a0,a0
    265a:	8082                	ret

000000000000265c <get_mtime>:

int64 get_mtime()
{
    265c:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    265e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2662:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2664:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2666:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    266a:	2501                	sext.w	a0,a0
    266c:	ed01                	bnez	a0,2684 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    266e:	6722                	ld	a4,8(sp)
    2670:	3e800793          	li	a5,1000
    2674:	6682                	ld	a3,0(sp)
    2676:	02f75733          	divu	a4,a4,a5
    267a:	02d78533          	mul	a0,a5,a3
    267e:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2680:	0141                	addi	sp,sp,16
    2682:	8082                	ret
	return -1;
    2684:	557d                	li	a0,-1
    2686:	bfed                	j	2680 <get_mtime+0x24>

0000000000002688 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2688:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268c:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2690:	2501                	sext.w	a0,a0
    2692:	8082                	ret

0000000000002694 <sleep>:

int sleep(unsigned long long time)
{
    2694:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2696:	880a                	mv	a6,sp
{
    2698:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    269a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    269e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26a0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26a2:	00000073          	ecall
	if (err == 0) {
    26a6:	2501                	sext.w	a0,a0
    26a8:	ed31                	bnez	a0,2704 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    26aa:	6722                	ld	a4,8(sp)
    26ac:	3e800793          	li	a5,1000
    26b0:	6682                	ld	a3,0(sp)
    26b2:	02f75733          	divu	a4,a4,a5
    26b6:	02d787b3          	mul	a5,a5,a3
    26ba:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    26bc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26c0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26c2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c4:	00000073          	ecall
	if (err == 0) {
    26c8:	2501                	sext.w	a0,a0
    26ca:	e915                	bnez	a0,26fe <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    26cc:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    26ce:	3e800693          	li	a3,1000
    26d2:	a819                	j	26e8 <sleep+0x54>
	__asm_syscall("r"(a7))
    26d4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26d8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26dc:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26de:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26e0:	00000073          	ecall
	if (err == 0) {
    26e4:	2501                	sext.w	a0,a0
    26e6:	ed01                	bnez	a0,26fe <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    26e8:	6722                	ld	a4,8(sp)
    26ea:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    26ec:	07c00893          	li	a7,124
    26f0:	02d75733          	divu	a4,a4,a3
    26f4:	02f687b3          	mul	a5,a3,a5
    26f8:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26fa:	fcc7ede3          	bltu	a5,a2,26d4 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26fe:	4501                	li	a0,0
    2700:	0141                	addi	sp,sp,16
    2702:	8082                	ret
    2704:	57fd                	li	a5,-1
    2706:	bf5d                	j	26bc <sleep+0x28>

0000000000002708 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2708:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    270c:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2710:	2501                	sext.w	a0,a0
    2712:	8082                	ret

0000000000002714 <set_priority>:
	register long a7 __asm__("a7") = n;
    2714:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2718:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    271c:	2501                	sext.w	a0,a0
    271e:	8082                	ret

0000000000002720 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2720:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2724:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2728:	2501                	sext.w	a0,a0
    272a:	8082                	ret

000000000000272c <munmap>:
	register long a7 __asm__("a7") = n;
    272c:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2730:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2734:	2501                	sext.w	a0,a0
    2736:	8082                	ret

0000000000002738 <wait>:

int wait(int *code)
{
    2738:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    273a:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    273e:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2740:	00000073          	ecall
	return waitpid(-1, code);
}
    2744:	2501                	sext.w	a0,a0
    2746:	8082                	ret

0000000000002748 <spawn>:
	register long a7 __asm__("a7") = n;
    2748:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    274c:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2750:	2501                	sext.w	a0,a0
    2752:	8082                	ret

0000000000002754 <pipe>:
	register long a7 __asm__("a7") = n;
    2754:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2758:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    275c:	2501                	sext.w	a0,a0
    275e:	8082                	ret

0000000000002760 <mailread>:
	register long a7 __asm__("a7") = n;
    2760:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2764:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret

000000000000276c <mailwrite>:
	register long a7 __asm__("a7") = n;
    276c:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2770:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2774:	2501                	sext.w	a0,a0
    2776:	8082                	ret

0000000000002778 <fstat>:
	register long a7 __asm__("a7") = n;
    2778:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    277c:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2780:	2501                	sext.w	a0,a0
    2782:	8082                	ret

0000000000002784 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2784:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2786:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    278a:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    278c:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2790:	2501                	sext.w	a0,a0
    2792:	8082                	ret

0000000000002794 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2794:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2796:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    279a:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    279c:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    27a0:	2501                	sext.w	a0,a0
    27a2:	8082                	ret

00000000000027a4 <link>:

int link(char *old_path, char *new_path)
{
    27a4:	87aa                	mv	a5,a0
    27a6:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    27a8:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    27ac:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    27b0:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    27b2:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    27b6:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27b8:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    27bc:	2501                	sext.w	a0,a0
    27be:	8082                	ret

00000000000027c0 <unlink>:

int unlink(char *path)
{
    27c0:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27c2:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    27c6:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    27ca:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27cc:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    27d0:	2501                	sext.w	a0,a0
    27d2:	8082                	ret

00000000000027d4 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    27d4:	00000797          	auipc	a5,0x0
    27d8:	4c47b783          	ld	a5,1220(a5) # 2c98 <_GLOBAL_OFFSET_TABLE_+0x8>
    27dc:	439c                	lw	a5,0(a5)
    27de:	c799                	beqz	a5,27ec <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    27e0:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27e4:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    27e8:	2501                	sext.w	a0,a0
    27ea:	8082                	ret
{
    27ec:	1101                	addi	sp,sp,-32
    27ee:	ec06                	sd	ra,24(sp)
    27f0:	e42e                	sd	a1,8(sp)
    27f2:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27f4:	fe7fe0ef          	jal	ra,17da <enable_thread_io_buffer>
    27f8:	65a2                	ld	a1,8(sp)
    27fa:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27fc:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2800:	00000073          	ecall
}
    2804:	60e2                	ld	ra,24(sp)
    2806:	2501                	sext.w	a0,a0
    2808:	6105                	addi	sp,sp,32
    280a:	8082                	ret

000000000000280c <gettid>:
	register long a7 __asm__("a7") = n;
    280c:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2810:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2814:	2501                	sext.w	a0,a0
    2816:	8082                	ret

0000000000002818 <waittid>:

int waittid(int tid)
{
    2818:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    281a:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    281e:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2822:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2824:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2826:	00e51e63          	bne	a0,a4,2842 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    282a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    282e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2832:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2836:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2838:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    283c:	2501                	sext.w	a0,a0
	while (ret == -2) {
    283e:	fee506e3          	beq	a0,a4,282a <waittid+0x12>
	}
	return ret;
}
    2842:	8082                	ret

0000000000002844 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2844:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2848:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    284a:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    284e:	2501                	sext.w	a0,a0
    2850:	8082                	ret

0000000000002852 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2852:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2856:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2858:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    285c:	2501                	sext.w	a0,a0
    285e:	8082                	ret

0000000000002860 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2860:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2864:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2868:	2501                	sext.w	a0,a0
    286a:	8082                	ret

000000000000286c <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    286c:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2870:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2874:	2501                	sext.w	a0,a0
    2876:	8082                	ret

0000000000002878 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2878:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    287c:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2880:	2501                	sext.w	a0,a0
    2882:	8082                	ret

0000000000002884 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2884:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2888:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    288c:	2501                	sext.w	a0,a0
    288e:	8082                	ret

0000000000002890 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2890:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2894:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2898:	2501                	sext.w	a0,a0
    289a:	8082                	ret

000000000000289c <condvar_create>:
	register long a7 __asm__("a7") = n;
    289c:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    28a0:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    28a4:	2501                	sext.w	a0,a0
    28a6:	8082                	ret

00000000000028a8 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    28a8:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    28ac:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    28b0:	2501                	sext.w	a0,a0
    28b2:	8082                	ret

00000000000028b4 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    28b4:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28b8:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    28bc:	2501                	sext.w	a0,a0
    28be:	8082                	ret

00000000000028c0 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    28c0:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    28c4:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    28c8:	2501                	sext.w	a0,a0
    28ca:	8082                	ret
