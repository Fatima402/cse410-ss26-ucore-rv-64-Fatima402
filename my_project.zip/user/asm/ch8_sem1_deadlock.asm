
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8_sem1_deadlock:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a1c1                	j	14c0 <__start_main>

0000000000001002 <sem_alloc>:
		exit(-1);
	}
}

void sem_alloc(int tid)
{
    1002:	1101                	addi	sp,sp,-32
    1004:	ec06                	sd	ra,24(sp)
    1006:	e822                	sd	s0,16(sp)
    1008:	e426                	sd	s1,8(sp)
	switch (tid) {
    100a:	4709                	li	a4,2
    100c:	02e50563          	beq	a0,a4,1036 <sem_alloc+0x34>
    1010:	470d                	li	a4,3
    1012:	08e50163          	beq	a0,a4,1094 <sem_alloc+0x92>
    1016:	4705                	li	a4,1
    1018:	04e50963          	beq	a0,a4,106a <sem_alloc+0x68>
		break;
	case 3:
		assert_eq(semaphore_down(3), 0);
		break;
	default:
		exit(1);
    101c:	4505                	li	a0,1
    101e:	05f010ef          	jal	ra,287c <exit>
	}
	semaphore_down(semaphore_barrier_id);
}
    1022:	6442                	ld	s0,16(sp)
    1024:	60e2                	ld	ra,24(sp)
    1026:	64a2                	ld	s1,8(sp)
	semaphore_down(semaphore_barrier_id);
    1028:	00002517          	auipc	a0,0x2
    102c:	d4052503          	lw	a0,-704(a0) # 2d68 <semaphore_barrier_id>
}
    1030:	6105                	addi	sp,sp,32
	semaphore_down(semaphore_barrier_id);
    1032:	2b90106f          	j	2aea <semaphore_down>
		assert_eq(semaphore_down(1), 0);
    1036:	4505                	li	a0,1
    1038:	2b3010ef          	jal	ra,2aea <semaphore_down>
    103c:	e955                	bnez	a0,10f0 <sem_alloc+0xee>
		assert_eq(semaphore_down(2), 0);
    103e:	4509                	li	a0,2
    1040:	2ab010ef          	jal	ra,2aea <semaphore_down>
    1044:	dd79                	beqz	a0,1022 <sem_alloc+0x20>
    1046:	007010ef          	jal	ra,284c <getpid>
    104a:	842a                	mv	s0,a0
    104c:	00002517          	auipc	a0,0x2
    1050:	adc50513          	addi	a0,a0,-1316 # 2b28 <enable_deadlock_detect+0xe>
    1054:	6ce010ef          	jal	ra,2722 <basename>
    1058:	84aa                	mv	s1,a0
    105a:	4509                	li	a0,2
    105c:	28f010ef          	jal	ra,2aea <semaphore_down>
    1060:	4881                	li	a7,0
    1062:	882a                	mv	a6,a0
    1064:	02300793          	li	a5,35
    1068:	a891                	j	10bc <sem_alloc+0xba>
		assert_eq(semaphore_down(2), 0);
    106a:	4509                	li	a0,2
    106c:	27f010ef          	jal	ra,2aea <semaphore_down>
    1070:	d94d                	beqz	a0,1022 <sem_alloc+0x20>
    1072:	7da010ef          	jal	ra,284c <getpid>
    1076:	842a                	mv	s0,a0
    1078:	00002517          	auipc	a0,0x2
    107c:	ab050513          	addi	a0,a0,-1360 # 2b28 <enable_deadlock_detect+0xe>
    1080:	6a2010ef          	jal	ra,2722 <basename>
    1084:	84aa                	mv	s1,a0
    1086:	4509                	li	a0,2
    1088:	263010ef          	jal	ra,2aea <semaphore_down>
    108c:	4881                	li	a7,0
    108e:	882a                	mv	a6,a0
    1090:	47fd                	li	a5,31
    1092:	a02d                	j	10bc <sem_alloc+0xba>
		assert_eq(semaphore_down(3), 0);
    1094:	257010ef          	jal	ra,2aea <semaphore_down>
    1098:	d549                	beqz	a0,1022 <sem_alloc+0x20>
    109a:	7b2010ef          	jal	ra,284c <getpid>
    109e:	842a                	mv	s0,a0
    10a0:	00002517          	auipc	a0,0x2
    10a4:	a8850513          	addi	a0,a0,-1400 # 2b28 <enable_deadlock_detect+0xe>
    10a8:	67a010ef          	jal	ra,2722 <basename>
    10ac:	84aa                	mv	s1,a0
    10ae:	450d                	li	a0,3
    10b0:	23b010ef          	jal	ra,2aea <semaphore_down>
    10b4:	4881                	li	a7,0
    10b6:	882a                	mv	a6,a0
    10b8:	02600793          	li	a5,38
		assert_eq(semaphore_down(2), 0);
    10bc:	8726                	mv	a4,s1
    10be:	86a2                	mv	a3,s0
    10c0:	00002617          	auipc	a2,0x2
    10c4:	ab860613          	addi	a2,a2,-1352 # 2b78 <enable_deadlock_detect+0x5e>
    10c8:	45fd                	li	a1,31
    10ca:	00002517          	auipc	a0,0x2
    10ce:	ab650513          	addi	a0,a0,-1354 # 2b80 <enable_deadlock_detect+0x66>
    10d2:	548000ef          	jal	ra,161a <printf>
    10d6:	557d                	li	a0,-1
    10d8:	7a4010ef          	jal	ra,287c <exit>
}
    10dc:	6442                	ld	s0,16(sp)
    10de:	60e2                	ld	ra,24(sp)
    10e0:	64a2                	ld	s1,8(sp)
	semaphore_down(semaphore_barrier_id);
    10e2:	00002517          	auipc	a0,0x2
    10e6:	c8652503          	lw	a0,-890(a0) # 2d68 <semaphore_barrier_id>
}
    10ea:	6105                	addi	sp,sp,32
	semaphore_down(semaphore_barrier_id);
    10ec:	1ff0106f          	j	2aea <semaphore_down>
		assert_eq(semaphore_down(1), 0);
    10f0:	75c010ef          	jal	ra,284c <getpid>
    10f4:	842a                	mv	s0,a0
    10f6:	00002517          	auipc	a0,0x2
    10fa:	a3250513          	addi	a0,a0,-1486 # 2b28 <enable_deadlock_detect+0xe>
    10fe:	624010ef          	jal	ra,2722 <basename>
    1102:	84aa                	mv	s1,a0
    1104:	4505                	li	a0,1
    1106:	1e5010ef          	jal	ra,2aea <semaphore_down>
    110a:	882a                	mv	a6,a0
    110c:	4881                	li	a7,0
    110e:	00002517          	auipc	a0,0x2
    1112:	a7250513          	addi	a0,a0,-1422 # 2b80 <enable_deadlock_detect+0x66>
    1116:	02200793          	li	a5,34
    111a:	8726                	mv	a4,s1
    111c:	86a2                	mv	a3,s0
    111e:	00002617          	auipc	a2,0x2
    1122:	a5a60613          	addi	a2,a2,-1446 # 2b78 <enable_deadlock_detect+0x5e>
    1126:	45fd                	li	a1,31
    1128:	4f2000ef          	jal	ra,161a <printf>
    112c:	557d                	li	a0,-1
    112e:	74e010ef          	jal	ra,287c <exit>
    1132:	b731                	j	103e <sem_alloc+0x3c>

0000000000001134 <sem_dealloc>:

void sem_dealloc(int tid)
{
    1134:	1101                	addi	sp,sp,-32
    1136:	e822                	sd	s0,16(sp)
    1138:	842a                	mv	s0,a0
	semaphore_up(semaphore_barrier_id);
    113a:	00002517          	auipc	a0,0x2
    113e:	c2e52503          	lw	a0,-978(a0) # 2d68 <semaphore_barrier_id>
{
    1142:	ec06                	sd	ra,24(sp)
    1144:	e426                	sd	s1,8(sp)
	semaphore_up(semaphore_barrier_id);
    1146:	199010ef          	jal	ra,2ade <semaphore_up>
	switch (tid) {
    114a:	4789                	li	a5,2
    114c:	00f40f63          	beq	s0,a5,116a <sem_dealloc+0x36>
    1150:	478d                	li	a5,3
    1152:	06f40463          	beq	s0,a5,11ba <sem_dealloc+0x86>
    1156:	4785                	li	a5,1
		break;
	case 3:
		assert_eq(semaphore_up(3), 0);
		break;
	default:
		exit(1);
    1158:	4505                	li	a0,1
	switch (tid) {
    115a:	02f40663          	beq	s0,a5,1186 <sem_dealloc+0x52>
	}
}
    115e:	6442                	ld	s0,16(sp)
    1160:	60e2                	ld	ra,24(sp)
    1162:	64a2                	ld	s1,8(sp)
    1164:	6105                	addi	sp,sp,32
		exit(1);
    1166:	7160106f          	j	287c <exit>
		assert_eq(semaphore_up(1), 0);
    116a:	4505                	li	a0,1
    116c:	173010ef          	jal	ra,2ade <semaphore_up>
    1170:	0c051463          	bnez	a0,1238 <sem_dealloc+0x104>
		assert_eq(semaphore_up(2), 0);
    1174:	4509                	li	a0,2
    1176:	169010ef          	jal	ra,2ade <semaphore_up>
    117a:	e949                	bnez	a0,120c <sem_dealloc+0xd8>
}
    117c:	60e2                	ld	ra,24(sp)
    117e:	6442                	ld	s0,16(sp)
    1180:	64a2                	ld	s1,8(sp)
    1182:	6105                	addi	sp,sp,32
    1184:	8082                	ret
		assert_eq(semaphore_up(2), 0);
    1186:	4509                	li	a0,2
    1188:	157010ef          	jal	ra,2ade <semaphore_up>
    118c:	d965                	beqz	a0,117c <sem_dealloc+0x48>
    118e:	6be010ef          	jal	ra,284c <getpid>
    1192:	842a                	mv	s0,a0
    1194:	00002517          	auipc	a0,0x2
    1198:	99450513          	addi	a0,a0,-1644 # 2b28 <enable_deadlock_detect+0xe>
    119c:	586010ef          	jal	ra,2722 <basename>
    11a0:	84aa                	mv	s1,a0
    11a2:	4509                	li	a0,2
    11a4:	13b010ef          	jal	ra,2ade <semaphore_up>
    11a8:	882a                	mv	a6,a0
    11aa:	4881                	li	a7,0
    11ac:	00002517          	auipc	a0,0x2
    11b0:	9d450513          	addi	a0,a0,-1580 # 2b80 <enable_deadlock_detect+0x66>
    11b4:	03300793          	li	a5,51
    11b8:	a815                	j	11ec <sem_dealloc+0xb8>
		assert_eq(semaphore_up(3), 0);
    11ba:	450d                	li	a0,3
    11bc:	123010ef          	jal	ra,2ade <semaphore_up>
    11c0:	dd55                	beqz	a0,117c <sem_dealloc+0x48>
    11c2:	68a010ef          	jal	ra,284c <getpid>
    11c6:	842a                	mv	s0,a0
    11c8:	00002517          	auipc	a0,0x2
    11cc:	96050513          	addi	a0,a0,-1696 # 2b28 <enable_deadlock_detect+0xe>
    11d0:	552010ef          	jal	ra,2722 <basename>
    11d4:	84aa                	mv	s1,a0
    11d6:	450d                	li	a0,3
    11d8:	107010ef          	jal	ra,2ade <semaphore_up>
    11dc:	882a                	mv	a6,a0
    11de:	4881                	li	a7,0
    11e0:	00002517          	auipc	a0,0x2
    11e4:	9a050513          	addi	a0,a0,-1632 # 2b80 <enable_deadlock_detect+0x66>
    11e8:	03a00793          	li	a5,58
		assert_eq(semaphore_up(2), 0);
    11ec:	8726                	mv	a4,s1
    11ee:	86a2                	mv	a3,s0
    11f0:	00002617          	auipc	a2,0x2
    11f4:	98860613          	addi	a2,a2,-1656 # 2b78 <enable_deadlock_detect+0x5e>
    11f8:	45fd                	li	a1,31
    11fa:	420000ef          	jal	ra,161a <printf>
}
    11fe:	6442                	ld	s0,16(sp)
    1200:	60e2                	ld	ra,24(sp)
    1202:	64a2                	ld	s1,8(sp)
		assert_eq(semaphore_up(2), 0);
    1204:	557d                	li	a0,-1
}
    1206:	6105                	addi	sp,sp,32
		exit(1);
    1208:	6740106f          	j	287c <exit>
		assert_eq(semaphore_up(2), 0);
    120c:	640010ef          	jal	ra,284c <getpid>
    1210:	842a                	mv	s0,a0
    1212:	00002517          	auipc	a0,0x2
    1216:	91650513          	addi	a0,a0,-1770 # 2b28 <enable_deadlock_detect+0xe>
    121a:	508010ef          	jal	ra,2722 <basename>
    121e:	84aa                	mv	s1,a0
    1220:	4509                	li	a0,2
    1222:	0bd010ef          	jal	ra,2ade <semaphore_up>
    1226:	882a                	mv	a6,a0
    1228:	4881                	li	a7,0
    122a:	00002517          	auipc	a0,0x2
    122e:	95650513          	addi	a0,a0,-1706 # 2b80 <enable_deadlock_detect+0x66>
    1232:	03700793          	li	a5,55
    1236:	bf5d                	j	11ec <sem_dealloc+0xb8>
		assert_eq(semaphore_up(1), 0);
    1238:	614010ef          	jal	ra,284c <getpid>
    123c:	842a                	mv	s0,a0
    123e:	00002517          	auipc	a0,0x2
    1242:	8ea50513          	addi	a0,a0,-1814 # 2b28 <enable_deadlock_detect+0xe>
    1246:	4dc010ef          	jal	ra,2722 <basename>
    124a:	84aa                	mv	s1,a0
    124c:	4505                	li	a0,1
    124e:	091010ef          	jal	ra,2ade <semaphore_up>
    1252:	882a                	mv	a6,a0
    1254:	4881                	li	a7,0
    1256:	00002517          	auipc	a0,0x2
    125a:	92a50513          	addi	a0,a0,-1750 # 2b80 <enable_deadlock_detect+0x66>
    125e:	03600793          	li	a5,54
    1262:	8726                	mv	a4,s1
    1264:	86a2                	mv	a3,s0
    1266:	00002617          	auipc	a2,0x2
    126a:	91260613          	addi	a2,a2,-1774 # 2b78 <enable_deadlock_detect+0x5e>
    126e:	45fd                	li	a1,31
    1270:	3aa000ef          	jal	ra,161a <printf>
    1274:	557d                	li	a0,-1
    1276:	606010ef          	jal	ra,287c <exit>
    127a:	bded                	j	1174 <sem_dealloc+0x40>

000000000000127c <deadlock_test>:

void deadlock_test(long _id)
{
    127c:	1101                	addi	sp,sp,-32
    127e:	e426                	sd	s1,8(sp)
	int tid = _id + 1;
    1280:	0015049b          	addiw	s1,a0,1
{
    1284:	e822                	sd	s0,16(sp)
    1286:	842a                	mv	s0,a0
	sem_alloc(tid);
    1288:	8526                	mv	a0,s1
{
    128a:	ec06                	sd	ra,24(sp)
	int sem_id = request[tid - 1];
    128c:	2401                	sext.w	s0,s0
	sem_alloc(tid);
    128e:	d75ff0ef          	jal	ra,1002 <sem_alloc>
	int sem_id = request[tid - 1];
    1292:	040a                	slli	s0,s0,0x2
    1294:	00002797          	auipc	a5,0x2
    1298:	bec78793          	addi	a5,a5,-1044 # 2e80 <request>
    129c:	97a2                	add	a5,a5,s0
    129e:	4380                	lw	s0,0(a5)
	if (semaphore_down(sem_id) == -0xdead) {
    12a0:	8522                	mv	a0,s0
    12a2:	049010ef          	jal	ra,2aea <semaphore_down>
    12a6:	77c9                	lui	a5,0xffff2
    12a8:	15378793          	addi	a5,a5,339 # ffffffffffff2153 <.got.plt+0xfffffffffffef28b>
    12ac:	00f50f63          	beq	a0,a5,12ca <deadlock_test+0x4e>
	try_sem_down(tid, sem_id);
	semaphore_up(sem_id);
    12b0:	8522                	mv	a0,s0
    12b2:	02d010ef          	jal	ra,2ade <semaphore_up>
	sem_dealloc(tid);
    12b6:	8526                	mv	a0,s1
    12b8:	e7dff0ef          	jal	ra,1134 <sem_dealloc>
	exit(0);
}
    12bc:	6442                	ld	s0,16(sp)
    12be:	60e2                	ld	ra,24(sp)
    12c0:	64a2                	ld	s1,8(sp)
	exit(0);
    12c2:	4501                	li	a0,0
}
    12c4:	6105                	addi	sp,sp,32
	exit(0);
    12c6:	5b60106f          	j	287c <exit>
		sem_dealloc(tid);
    12ca:	8526                	mv	a0,s1
    12cc:	e69ff0ef          	jal	ra,1134 <sem_dealloc>
		exit(-1);
    12d0:	557d                	li	a0,-1
    12d2:	5aa010ef          	jal	ra,287c <exit>
}
    12d6:	bfe9                	j	12b0 <deadlock_test+0x34>

00000000000012d8 <try_sem_down>:
{
    12d8:	1141                	addi	sp,sp,-16
    12da:	e022                	sd	s0,0(sp)
    12dc:	842a                	mv	s0,a0
	if (semaphore_down(sem_id) == -0xdead) {
    12de:	852e                	mv	a0,a1
{
    12e0:	e406                	sd	ra,8(sp)
	if (semaphore_down(sem_id) == -0xdead) {
    12e2:	009010ef          	jal	ra,2aea <semaphore_down>
    12e6:	77c9                	lui	a5,0xffff2
    12e8:	15378793          	addi	a5,a5,339 # ffffffffffff2153 <.got.plt+0xfffffffffffef28b>
    12ec:	00f50663          	beq	a0,a5,12f8 <try_sem_down+0x20>
}
    12f0:	60a2                	ld	ra,8(sp)
    12f2:	6402                	ld	s0,0(sp)
    12f4:	0141                	addi	sp,sp,16
    12f6:	8082                	ret
		sem_dealloc(tid);
    12f8:	8522                	mv	a0,s0
    12fa:	e3bff0ef          	jal	ra,1134 <sem_dealloc>
}
    12fe:	6402                	ld	s0,0(sp)
    1300:	60a2                	ld	ra,8(sp)
		exit(-1);
    1302:	557d                	li	a0,-1
}
    1304:	0141                	addi	sp,sp,16
		exit(-1);
    1306:	5760106f          	j	287c <exit>

000000000000130a <main>:

int main()
{
    130a:	711d                	addi	sp,sp,-96
	enable_deadlock_detect(1);
    130c:	4505                	li	a0,1
{
    130e:	ec86                	sd	ra,88(sp)
    1310:	fc4e                	sd	s3,56(sp)
    1312:	e8a2                	sd	s0,80(sp)
    1314:	e4a6                	sd	s1,72(sp)
    1316:	e0ca                	sd	s2,64(sp)
    1318:	f852                	sd	s4,48(sp)
    131a:	f456                	sd	s5,40(sp)
    131c:	f05a                	sd	s6,32(sp)
    131e:	ec5e                	sd	s7,24(sp)
    1320:	e862                	sd	s8,16(sp)
	enable_deadlock_detect(1);
    1322:	7f8010ef          	jal	ra,2b1a <enable_deadlock_detect>
	assert((semaphore_barrier_id = semaphore_create(THREAD_N)) == 0);
    1326:	450d                	li	a0,3
    1328:	7aa010ef          	jal	ra,2ad2 <semaphore_create>
    132c:	00002997          	auipc	s3,0x2
    1330:	a3c98993          	addi	s3,s3,-1476 # 2d68 <semaphore_barrier_id>
    1334:	00a9a023          	sw	a0,0(s3)
    1338:	10051a63          	bnez	a0,144c <main+0x142>
	for (int i = 0; i < THREAD_N; i++) {
		semaphore_down(semaphore_barrier_id);
    133c:	7ae010ef          	jal	ra,2aea <semaphore_down>
    1340:	0009a503          	lw	a0,0(s3)
    1344:	00002497          	auipc	s1,0x2
    1348:	b4c48493          	addi	s1,s1,-1204 # 2e90 <res_num>
	}
	for (int i = 0; i < RES_TYPE; i++) {
    134c:	4401                	li	s0,0
		semaphore_down(semaphore_barrier_id);
    134e:	79c010ef          	jal	ra,2aea <semaphore_down>
    1352:	0009a503          	lw	a0,0(s3)
	for (int i = 0; i < RES_TYPE; i++) {
    1356:	4a8d                	li	s5,3
		assert_eq(semaphore_create(res_num[i]), i + 1);
    1358:	00001c17          	auipc	s8,0x1
    135c:	7d0c0c13          	addi	s8,s8,2000 # 2b28 <enable_deadlock_detect+0xe>
		semaphore_down(semaphore_barrier_id);
    1360:	78a010ef          	jal	ra,2aea <semaphore_down>
		assert_eq(semaphore_create(res_num[i]), i + 1);
    1364:	00002b97          	auipc	s7,0x2
    1368:	814b8b93          	addi	s7,s7,-2028 # 2b78 <enable_deadlock_detect+0x5e>
    136c:	00002b17          	auipc	s6,0x2
    1370:	814b0b13          	addi	s6,s6,-2028 # 2b80 <enable_deadlock_detect+0x66>
    1374:	0004a903          	lw	s2,0(s1)
    1378:	2405                	addiw	s0,s0,1
    137a:	854a                	mv	a0,s2
    137c:	756010ef          	jal	ra,2ad2 <semaphore_create>
    1380:	0c850263          	beq	a0,s0,1444 <main+0x13a>
    1384:	4c8010ef          	jal	ra,284c <getpid>
    1388:	8a2a                	mv	s4,a0
    138a:	8562                	mv	a0,s8
    138c:	396010ef          	jal	ra,2722 <basename>
    1390:	872a                	mv	a4,a0
    1392:	854a                	mv	a0,s2
    1394:	893a                	mv	s2,a4
    1396:	73c010ef          	jal	ra,2ad2 <semaphore_create>
    139a:	882a                	mv	a6,a0
    139c:	88a2                	mv	a7,s0
    139e:	05400793          	li	a5,84
    13a2:	874a                	mv	a4,s2
    13a4:	86d2                	mv	a3,s4
    13a6:	865e                	mv	a2,s7
    13a8:	45fd                	li	a1,31
    13aa:	855a                	mv	a0,s6
    13ac:	26e000ef          	jal	ra,161a <printf>
    13b0:	557d                	li	a0,-1
    13b2:	4ca010ef          	jal	ra,287c <exit>
	for (int i = 0; i < RES_TYPE; i++) {
    13b6:	0491                	addi	s1,s1,4
    13b8:	fb541ee3          	bne	s0,s5,1374 <main+0x6a>
	}
	int threads[THREAD_N] = {};
    13bc:	840a                	mv	s0,sp
    13be:	e002                	sd	zero,0(sp)
    13c0:	c402                	sw	zero,8(sp)
    13c2:	8922                	mv	s2,s0
    13c4:	4481                	li	s1,0
	for (int i = 0; i < THREAD_N; i++) {
		threads[i] = thread_create(deadlock_test, (void *)i);
    13c6:	00000a97          	auipc	s5,0x0
    13ca:	eb6a8a93          	addi	s5,s5,-330 # 127c <deadlock_test>
	for (int i = 0; i < THREAD_N; i++) {
    13ce:	4a0d                	li	s4,3
		threads[i] = thread_create(deadlock_test, (void *)i);
    13d0:	85a6                	mv	a1,s1
    13d2:	8556                	mv	a0,s5
    13d4:	65a010ef          	jal	ra,2a2e <thread_create>
    13d8:	00a92023          	sw	a0,0(s2)
	for (int i = 0; i < THREAD_N; i++) {
    13dc:	0485                	addi	s1,s1,1
    13de:	0911                	addi	s2,s2,4
    13e0:	ff4498e3          	bne	s1,s4,13d0 <main+0xc6>
	}
	sleep(500);
    13e4:	1f400513          	li	a0,500
    13e8:	506010ef          	jal	ra,28ee <sleep>
	for (int i = 0; i < THREAD_N; i++) {
		semaphore_up(semaphore_barrier_id);
    13ec:	0009a503          	lw	a0,0(s3)
    13f0:	00c40913          	addi	s2,s0,12
	}
	int fail = 0;
    13f4:	4481                	li	s1,0
		semaphore_up(semaphore_barrier_id);
    13f6:	6e8010ef          	jal	ra,2ade <semaphore_up>
    13fa:	0009a503          	lw	a0,0(s3)
    13fe:	6e0010ef          	jal	ra,2ade <semaphore_up>
    1402:	0009a503          	lw	a0,0(s3)
    1406:	6d8010ef          	jal	ra,2ade <semaphore_up>
	for (int i = 0; i < THREAD_N; i++) {
		fail += waittid(threads[i]) != 0;
    140a:	4008                	lw	a0,0(s0)
	for (int i = 0; i < THREAD_N; i++) {
    140c:	0411                	addi	s0,s0,4
		fail += waittid(threads[i]) != 0;
    140e:	664010ef          	jal	ra,2a72 <waittid>
    1412:	00a03533          	snez	a0,a0
    1416:	9ca9                	addw	s1,s1,a0
	for (int i = 0; i < THREAD_N; i++) {
    1418:	fe8919e3          	bne	s2,s0,140a <main+0x100>
	}
	assert(fail > 0);
    141c:	c4b5                	beqz	s1,1488 <main+0x17e>
	puts("deadlock test semaphore 1 OK!");
    141e:	00002517          	auipc	a0,0x2
    1422:	83250513          	addi	a0,a0,-1998 # 2c50 <enable_deadlock_detect+0x136>
    1426:	10b000ef          	jal	ra,1d30 <puts>
	return 0;
}
    142a:	60e6                	ld	ra,88(sp)
    142c:	6446                	ld	s0,80(sp)
    142e:	64a6                	ld	s1,72(sp)
    1430:	6906                	ld	s2,64(sp)
    1432:	79e2                	ld	s3,56(sp)
    1434:	7a42                	ld	s4,48(sp)
    1436:	7aa2                	ld	s5,40(sp)
    1438:	7b02                	ld	s6,32(sp)
    143a:	6be2                	ld	s7,24(sp)
    143c:	6c42                	ld	s8,16(sp)
    143e:	4501                	li	a0,0
    1440:	6125                	addi	sp,sp,96
    1442:	8082                	ret
	for (int i = 0; i < RES_TYPE; i++) {
    1444:	0491                	addi	s1,s1,4
    1446:	f35417e3          	bne	s0,s5,1374 <main+0x6a>
    144a:	bf8d                	j	13bc <main+0xb2>
	assert((semaphore_barrier_id = semaphore_create(THREAD_N)) == 0);
    144c:	400010ef          	jal	ra,284c <getpid>
    1450:	842a                	mv	s0,a0
    1452:	00001517          	auipc	a0,0x1
    1456:	6d650513          	addi	a0,a0,1750 # 2b28 <enable_deadlock_detect+0xe>
    145a:	2c8010ef          	jal	ra,2722 <basename>
    145e:	872a                	mv	a4,a0
    1460:	04f00793          	li	a5,79
    1464:	86a2                	mv	a3,s0
    1466:	00001617          	auipc	a2,0x1
    146a:	71260613          	addi	a2,a2,1810 # 2b78 <enable_deadlock_detect+0x5e>
    146e:	45fd                	li	a1,31
    1470:	00001517          	auipc	a0,0x1
    1474:	74850513          	addi	a0,a0,1864 # 2bb8 <enable_deadlock_detect+0x9e>
    1478:	1a2000ef          	jal	ra,161a <printf>
    147c:	557d                	li	a0,-1
    147e:	3fe010ef          	jal	ra,287c <exit>
		semaphore_down(semaphore_barrier_id);
    1482:	0009a503          	lw	a0,0(s3)
    1486:	bd5d                	j	133c <main+0x32>
	assert(fail > 0);
    1488:	3c4010ef          	jal	ra,284c <getpid>
    148c:	842a                	mv	s0,a0
    148e:	00001517          	auipc	a0,0x1
    1492:	69a50513          	addi	a0,a0,1690 # 2b28 <enable_deadlock_detect+0xe>
    1496:	28c010ef          	jal	ra,2722 <basename>
    149a:	872a                	mv	a4,a0
    149c:	06200793          	li	a5,98
    14a0:	00001517          	auipc	a0,0x1
    14a4:	77850513          	addi	a0,a0,1912 # 2c18 <enable_deadlock_detect+0xfe>
    14a8:	86a2                	mv	a3,s0
    14aa:	00001617          	auipc	a2,0x1
    14ae:	6ce60613          	addi	a2,a2,1742 # 2b78 <enable_deadlock_detect+0x5e>
    14b2:	45fd                	li	a1,31
    14b4:	166000ef          	jal	ra,161a <printf>
    14b8:	557d                	li	a0,-1
    14ba:	3c2010ef          	jal	ra,287c <exit>
    14be:	b785                	j	141e <main+0x114>

00000000000014c0 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    14c0:	1141                	addi	sp,sp,-16
    14c2:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    14c4:	e47ff0ef          	jal	ra,130a <main>
    14c8:	3b4010ef          	jal	ra,287c <exit>
	return 0;
    14cc:	60a2                	ld	ra,8(sp)
    14ce:	4501                	li	a0,0
    14d0:	0141                	addi	sp,sp,16
    14d2:	8082                	ret

00000000000014d4 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    14d4:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    14d6:	4605                	li	a2,1
    14d8:	00f10593          	addi	a1,sp,15
    14dc:	4501                	li	a0,0
{
    14de:	ec06                	sd	ra,24(sp)
	char byte = 0;
    14e0:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    14e4:	354010ef          	jal	ra,2838 <read>
    14e8:	4785                	li	a5,1
    14ea:	00f51763          	bne	a0,a5,14f8 <getchar+0x24>
		return byte;
    14ee:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    14f2:	60e2                	ld	ra,24(sp)
    14f4:	6105                	addi	sp,sp,32
    14f6:	8082                	ret
		return EOF;
    14f8:	557d                	li	a0,-1
    14fa:	bfe5                	j	14f2 <getchar+0x1e>

00000000000014fc <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    14fc:	00002517          	auipc	a0,0x2
    1500:	87452503          	lw	a0,-1932(a0) # 2d70 <buffer_len>
    1504:	e111                	bnez	a0,1508 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1506:	8082                	ret
{
    1508:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    150a:	862a                	mv	a2,a0
    150c:	00002597          	auipc	a1,0x2
    1510:	86c58593          	addi	a1,a1,-1940 # 2d78 <buffer>
    1514:	4505                	li	a0,1
{
    1516:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1518:	32a010ef          	jal	ra,2842 <write>
}
    151c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    151e:	2501                	sext.w	a0,a0
}
    1520:	0141                	addi	sp,sp,16
    1522:	8082                	ret

0000000000001524 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1524:	00002797          	auipc	a5,0x2
    1528:	8407a623          	sw	zero,-1972(a5) # 2d70 <buffer_len>
}
    152c:	8082                	ret

000000000000152e <__fflush>:
	if (buffer_len == 0)
    152e:	00002517          	auipc	a0,0x2
    1532:	84252503          	lw	a0,-1982(a0) # 2d70 <buffer_len>
    1536:	e511                	bnez	a0,1542 <__fflush+0x14>
	buffer_len = 0;
    1538:	00002797          	auipc	a5,0x2
    153c:	8207ac23          	sw	zero,-1992(a5) # 2d70 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1540:	8082                	ret
{
    1542:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1544:	862a                	mv	a2,a0
    1546:	00002597          	auipc	a1,0x2
    154a:	83258593          	addi	a1,a1,-1998 # 2d78 <buffer>
    154e:	4505                	li	a0,1
{
    1550:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1552:	2f0010ef          	jal	ra,2842 <write>
	return r >= 0 ? 0 : r;
    1556:	0005079b          	sext.w	a5,a0
}
    155a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    155c:	0017a793          	slti	a5,a5,1
    1560:	40f007bb          	negw	a5,a5
    1564:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1566:	00002797          	auipc	a5,0x2
    156a:	8007a523          	sw	zero,-2038(a5) # 2d70 <buffer_len>
	return r >= 0 ? 0 : r;
    156e:	2501                	sext.w	a0,a0
}
    1570:	0141                	addi	sp,sp,16
    1572:	8082                	ret

0000000000001574 <fflush>:

int fflush(int fd)
{
    1574:	1101                	addi	sp,sp,-32
    1576:	e822                	sd	s0,16(sp)
    1578:	ec06                	sd	ra,24(sp)
    157a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    157c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    157e:	4401                	li	s0,0
	if (fd == 1) {
    1580:	00e50863          	beq	a0,a4,1590 <fflush+0x1c>
}
    1584:	60e2                	ld	ra,24(sp)
    1586:	8522                	mv	a0,s0
    1588:	6442                	ld	s0,16(sp)
    158a:	64a2                	ld	s1,8(sp)
    158c:	6105                	addi	sp,sp,32
    158e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1590:	00001497          	auipc	s1,0x1
    1594:	7e048493          	addi	s1,s1,2016 # 2d70 <buffer_len>
    1598:	1084a703          	lw	a4,264(s1)
    159c:	02a70e63          	beq	a4,a0,15d8 <fflush+0x64>
	if (buffer_len == 0)
    15a0:	4080                	lw	s0,0(s1)
    15a2:	c00d                	beqz	s0,15c4 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    15a4:	8622                	mv	a2,s0
    15a6:	00001597          	auipc	a1,0x1
    15aa:	7d258593          	addi	a1,a1,2002 # 2d78 <buffer>
    15ae:	294010ef          	jal	ra,2842 <write>
	return r >= 0 ? 0 : r;
    15b2:	0005079b          	sext.w	a5,a0
    15b6:	0017a793          	slti	a5,a5,1
    15ba:	40f007bb          	negw	a5,a5
    15be:	8d7d                	and	a0,a0,a5
    15c0:	0005041b          	sext.w	s0,a0
}
    15c4:	60e2                	ld	ra,24(sp)
    15c6:	8522                	mv	a0,s0
    15c8:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    15ca:	00001797          	auipc	a5,0x1
    15ce:	7a07a323          	sw	zero,1958(a5) # 2d70 <buffer_len>
}
    15d2:	64a2                	ld	s1,8(sp)
    15d4:	6105                	addi	sp,sp,32
    15d6:	8082                	ret
			mutex_lock(buffer_lock);
    15d8:	10c4a503          	lw	a0,268(s1)
    15dc:	4de010ef          	jal	ra,2aba <mutex_lock>
	if (buffer_len == 0)
    15e0:	4080                	lw	s0,0(s1)
    15e2:	e811                	bnez	s0,15f6 <fflush+0x82>
			mutex_unlock(buffer_lock);
    15e4:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    15e8:	00001797          	auipc	a5,0x1
    15ec:	7807a423          	sw	zero,1928(a5) # 2d70 <buffer_len>
			mutex_unlock(buffer_lock);
    15f0:	4d6010ef          	jal	ra,2ac6 <mutex_unlock>
    15f4:	bf41                	j	1584 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    15f6:	8622                	mv	a2,s0
    15f8:	00001597          	auipc	a1,0x1
    15fc:	78058593          	addi	a1,a1,1920 # 2d78 <buffer>
    1600:	4505                	li	a0,1
    1602:	240010ef          	jal	ra,2842 <write>
	return r >= 0 ? 0 : r;
    1606:	0005079b          	sext.w	a5,a0
    160a:	0017a793          	slti	a5,a5,1
    160e:	40f007bb          	negw	a5,a5
    1612:	8d7d                	and	a0,a0,a5
    1614:	0005041b          	sext.w	s0,a0
	return r;
    1618:	b7f1                	j	15e4 <fflush+0x70>

000000000000161a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    161a:	7131                	addi	sp,sp,-192
    161c:	e0da                	sd	s6,64(sp)
    161e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1620:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1622:	013c                	addi	a5,sp,136
{
    1624:	f0ca                	sd	s2,96(sp)
    1626:	ecce                	sd	s3,88(sp)
    1628:	e8d2                	sd	s4,80(sp)
    162a:	e4d6                	sd	s5,72(sp)
    162c:	fc86                	sd	ra,120(sp)
    162e:	f8a2                	sd	s0,112(sp)
    1630:	f4a6                	sd	s1,104(sp)
    1632:	89aa                	mv	s3,a0
    1634:	e52e                	sd	a1,136(sp)
    1636:	e932                	sd	a2,144(sp)
    1638:	ed36                	sd	a3,152(sp)
    163a:	f13a                	sd	a4,160(sp)
    163c:	f942                	sd	a6,176(sp)
    163e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1640:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1642:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1646:	00001a17          	auipc	s4,0x1
    164a:	72aa0a13          	addi	s4,s4,1834 # 2d70 <buffer_len>
    164e:	4a85                	li	s5,1
	buf[i++] = '0';
    1650:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1654:	0009c783          	lbu	a5,0(s3)
    1658:	18078663          	beqz	a5,17e4 <printf+0x1ca>
    165c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    165e:	19278d63          	beq	a5,s2,17f8 <printf+0x1de>
    1662:	0015c783          	lbu	a5,1(a1)
    1666:	0585                	addi	a1,a1,1
    1668:	fbfd                	bnez	a5,165e <printf+0x44>
    166a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    166c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1670:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1674:	1b578863          	beq	a5,s5,1824 <printf+0x20a>
		len = out_unlocked(s, l);
    1678:	85a2                	mv	a1,s0
    167a:	854e                	mv	a0,s3
    167c:	42a000ef          	jal	ra,1aa6 <out_unlocked>
		out(f, a, l);
		if (l)
    1680:	1c041063          	bnez	s0,1840 <printf+0x226>
			continue;
		if (s[1] == 0)
    1684:	0014c783          	lbu	a5,1(s1)
    1688:	14078e63          	beqz	a5,17e4 <printf+0x1ca>
			break;
		switch (s[1]) {
    168c:	07300713          	li	a4,115
    1690:	1ce78863          	beq	a5,a4,1860 <printf+0x246>
    1694:	1af76863          	bltu	a4,a5,1844 <printf+0x22a>
    1698:	06400713          	li	a4,100
    169c:	22e78063          	beq	a5,a4,18bc <printf+0x2a2>
    16a0:	07000713          	li	a4,112
    16a4:	1ee79563          	bne	a5,a4,188e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    16a8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16aa:	00001797          	auipc	a5,0x1
    16ae:	7f678793          	addi	a5,a5,2038 # 2ea0 <digits>
	buf[i++] = '0';
    16b2:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    16b6:	6298                	ld	a4,0(a3)
    16b8:	06a1                	addi	a3,a3,8
    16ba:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    16bc:	00471393          	slli	t2,a4,0x4
    16c0:	00871293          	slli	t0,a4,0x8
    16c4:	00c71f93          	slli	t6,a4,0xc
    16c8:	01071f13          	slli	t5,a4,0x10
    16cc:	01471e93          	slli	t4,a4,0x14
    16d0:	01871e13          	slli	t3,a4,0x18
    16d4:	01c71893          	slli	a7,a4,0x1c
    16d8:	02471813          	slli	a6,a4,0x24
    16dc:	02871513          	slli	a0,a4,0x28
    16e0:	02c71593          	slli	a1,a4,0x2c
    16e4:	03071613          	slli	a2,a4,0x30
    16e8:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16ec:	03c75413          	srli	s0,a4,0x3c
    16f0:	01c7531b          	srliw	t1,a4,0x1c
    16f4:	03c3d393          	srli	t2,t2,0x3c
    16f8:	03c2d293          	srli	t0,t0,0x3c
    16fc:	03cfdf93          	srli	t6,t6,0x3c
    1700:	03cf5f13          	srli	t5,t5,0x3c
    1704:	03cede93          	srli	t4,t4,0x3c
    1708:	03ce5e13          	srli	t3,t3,0x3c
    170c:	03c8d893          	srli	a7,a7,0x3c
    1710:	03c85813          	srli	a6,a6,0x3c
    1714:	9171                	srli	a0,a0,0x3c
    1716:	91f1                	srli	a1,a1,0x3c
    1718:	9271                	srli	a2,a2,0x3c
    171a:	92f1                	srli	a3,a3,0x3c
    171c:	95be                	add	a1,a1,a5
    171e:	963e                	add	a2,a2,a5
    1720:	96be                	add	a3,a3,a5
    1722:	943e                	add	s0,s0,a5
    1724:	93be                	add	t2,t2,a5
    1726:	92be                	add	t0,t0,a5
    1728:	9fbe                	add	t6,t6,a5
    172a:	9f3e                	add	t5,t5,a5
    172c:	9ebe                	add	t4,t4,a5
    172e:	9e3e                	add	t3,t3,a5
    1730:	98be                	add	a7,a7,a5
    1732:	933e                	add	t1,t1,a5
    1734:	983e                	add	a6,a6,a5
    1736:	953e                	add	a0,a0,a5
    1738:	0005c983          	lbu	s3,0(a1)
    173c:	00044403          	lbu	s0,0(s0)
    1740:	00064583          	lbu	a1,0(a2)
    1744:	0003c383          	lbu	t2,0(t2)
    1748:	0006c603          	lbu	a2,0(a3)
    174c:	0002c283          	lbu	t0,0(t0)
    1750:	000fcf83          	lbu	t6,0(t6)
    1754:	000f4f03          	lbu	t5,0(t5)
    1758:	000ece83          	lbu	t4,0(t4)
    175c:	000e4e03          	lbu	t3,0(t3)
    1760:	0008c883          	lbu	a7,0(a7)
    1764:	00034303          	lbu	t1,0(t1)
    1768:	00084803          	lbu	a6,0(a6)
    176c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1770:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1774:	92f1                	srli	a3,a3,0x3c
    1776:	8b3d                	andi	a4,a4,15
    1778:	96be                	add	a3,a3,a5
    177a:	97ba                	add	a5,a5,a4
    177c:	00810d23          	sb	s0,26(sp)
    1780:	00710da3          	sb	t2,27(sp)
    1784:	00510e23          	sb	t0,28(sp)
    1788:	01f10ea3          	sb	t6,29(sp)
    178c:	01e10f23          	sb	t5,30(sp)
    1790:	01d10fa3          	sb	t4,31(sp)
    1794:	03c10023          	sb	t3,32(sp)
    1798:	031100a3          	sb	a7,33(sp)
    179c:	02610123          	sb	t1,34(sp)
    17a0:	030101a3          	sb	a6,35(sp)
    17a4:	02a10223          	sb	a0,36(sp)
    17a8:	033102a3          	sb	s3,37(sp)
    17ac:	02b10323          	sb	a1,38(sp)
    17b0:	02c103a3          	sb	a2,39(sp)
    17b4:	0006c683          	lbu	a3,0(a3)
    17b8:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    17bc:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    17c0:	02d10423          	sb	a3,40(sp)
    17c4:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    17c8:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    17cc:	11578263          	beq	a5,s5,18d0 <printf+0x2b6>
		len = out_unlocked(s, l);
    17d0:	45c9                	li	a1,18
    17d2:	0828                	addi	a0,sp,24
    17d4:	2d2000ef          	jal	ra,1aa6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    17d8:	00248993          	addi	s3,s1,2
		if (!*s)
    17dc:	0009c783          	lbu	a5,0(s3)
    17e0:	e6079ee3          	bnez	a5,165c <printf+0x42>
	}
	va_end(ap);
    17e4:	70e6                	ld	ra,120(sp)
    17e6:	7446                	ld	s0,112(sp)
    17e8:	74a6                	ld	s1,104(sp)
    17ea:	7906                	ld	s2,96(sp)
    17ec:	69e6                	ld	s3,88(sp)
    17ee:	6a46                	ld	s4,80(sp)
    17f0:	6aa6                	ld	s5,72(sp)
    17f2:	6b06                	ld	s6,64(sp)
    17f4:	6129                	addi	sp,sp,192
    17f6:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    17f8:	0005c783          	lbu	a5,0(a1)
    17fc:	84ae                	mv	s1,a1
    17fe:	01278963          	beq	a5,s2,1810 <printf+0x1f6>
    1802:	b5ad                	j	166c <printf+0x52>
    1804:	0024c783          	lbu	a5,2(s1)
    1808:	0585                	addi	a1,a1,1
    180a:	0489                	addi	s1,s1,2
    180c:	e72790e3          	bne	a5,s2,166c <printf+0x52>
    1810:	0014c783          	lbu	a5,1(s1)
    1814:	ff2788e3          	beq	a5,s2,1804 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1818:	108a2783          	lw	a5,264(s4)
		l = z - a;
    181c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1820:	e5579ce3          	bne	a5,s5,1678 <printf+0x5e>
		mutex_lock(buffer_lock);
    1824:	10ca2503          	lw	a0,268(s4)
    1828:	292010ef          	jal	ra,2aba <mutex_lock>
		len = out_unlocked(s, l);
    182c:	85a2                	mv	a1,s0
    182e:	854e                	mv	a0,s3
    1830:	276000ef          	jal	ra,1aa6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1834:	10ca2503          	lw	a0,268(s4)
    1838:	28e010ef          	jal	ra,2ac6 <mutex_unlock>
		if (l)
    183c:	e40404e3          	beqz	s0,1684 <printf+0x6a>
    1840:	89a6                	mv	s3,s1
    1842:	bd09                	j	1654 <printf+0x3a>
		switch (s[1]) {
    1844:	07800713          	li	a4,120
    1848:	04e79363          	bne	a5,a4,188e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    184c:	67c2                	ld	a5,16(sp)
    184e:	45c1                	li	a1,16
		s += 2;
    1850:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1854:	4388                	lw	a0,0(a5)
    1856:	07a1                	addi	a5,a5,8
    1858:	e83e                	sd	a5,16(sp)
    185a:	5f8000ef          	jal	ra,1e52 <printint.constprop.0>
		s += 2;
    185e:	bfbd                	j	17dc <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1860:	67c2                	ld	a5,16(sp)
    1862:	6380                	ld	s0,0(a5)
    1864:	07a1                	addi	a5,a5,8
    1866:	e83e                	sd	a5,16(sp)
    1868:	1c040163          	beqz	s0,1a2a <printf+0x410>
			l = strnlen(a, 200);
    186c:	0c800593          	li	a1,200
    1870:	8522                	mv	a0,s0
    1872:	3f7000ef          	jal	ra,2468 <strnlen>
	if (buffer_lock_enabled == 1) {
    1876:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    187a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    187e:	19578663          	beq	a5,s5,1a0a <printf+0x3f0>
		len = out_unlocked(s, l);
    1882:	8522                	mv	a0,s0
    1884:	222000ef          	jal	ra,1aa6 <out_unlocked>
		s += 2;
    1888:	00248993          	addi	s3,s1,2
    188c:	bf81                	j	17dc <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    188e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1892:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1896:	0f578663          	beq	a5,s5,1982 <printf+0x368>
		len = out_unlocked(s, l);
    189a:	0828                	addi	a0,sp,24
    189c:	316000ef          	jal	ra,1bb2 <out_unlocked.constprop.0>
			putchar(s[1]);
    18a0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    18a4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18a8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    18ac:	05578163          	beq	a5,s5,18ee <printf+0x2d4>
		len = out_unlocked(s, l);
    18b0:	0828                	addi	a0,sp,24
    18b2:	300000ef          	jal	ra,1bb2 <out_unlocked.constprop.0>
		s += 2;
    18b6:	00248993          	addi	s3,s1,2
    18ba:	b70d                	j	17dc <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    18bc:	67c2                	ld	a5,16(sp)
    18be:	45a9                	li	a1,10
		s += 2;
    18c0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    18c4:	4388                	lw	a0,0(a5)
    18c6:	07a1                	addi	a5,a5,8
    18c8:	e83e                	sd	a5,16(sp)
    18ca:	588000ef          	jal	ra,1e52 <printint.constprop.0>
		s += 2;
    18ce:	b739                	j	17dc <printf+0x1c2>
		mutex_lock(buffer_lock);
    18d0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    18d4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    18d8:	1e2010ef          	jal	ra,2aba <mutex_lock>
		len = out_unlocked(s, l);
    18dc:	45c9                	li	a1,18
    18de:	0828                	addi	a0,sp,24
    18e0:	1c6000ef          	jal	ra,1aa6 <out_unlocked>
		mutex_unlock(buffer_lock);
    18e4:	10ca2503          	lw	a0,268(s4)
    18e8:	1de010ef          	jal	ra,2ac6 <mutex_unlock>
		s += 2;
    18ec:	bdc5                	j	17dc <printf+0x1c2>
		mutex_lock(buffer_lock);
    18ee:	10ca2503          	lw	a0,268(s4)
    18f2:	1c8010ef          	jal	ra,2aba <mutex_lock>
		buffer[buffer_len++] = c;
    18f6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18fa:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18fe:	0017861b          	addiw	a2,a5,1
    1902:	97d2                	add	a5,a5,s4
    1904:	00ca2023          	sw	a2,0(s4)
    1908:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    190c:	00c6cc63          	blt	a3,a2,1924 <printf+0x30a>
    1910:	47a9                	li	a5,10
    1912:	06f40663          	beq	s0,a5,197e <printf+0x364>
		mutex_unlock(buffer_lock);
    1916:	10ca2503          	lw	a0,268(s4)
		s += 2;
    191a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    191e:	1a8010ef          	jal	ra,2ac6 <mutex_unlock>
		s += 2;
    1922:	bd6d                	j	17dc <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1924:	10000793          	li	a5,256
    1928:	00f61e63          	bne	a2,a5,1944 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    192c:	00001597          	auipc	a1,0x1
    1930:	44c58593          	addi	a1,a1,1100 # 2d78 <buffer>
    1934:	4505                	li	a0,1
    1936:	70d000ef          	jal	ra,2842 <write>
	buffer_len = 0;
    193a:	00001797          	auipc	a5,0x1
    193e:	4207ab23          	sw	zero,1078(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1942:	bfd1                	j	1916 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1944:	709000ef          	jal	ra,284c <getpid>
    1948:	842a                	mv	s0,a0
    194a:	00001517          	auipc	a0,0x1
    194e:	32e50513          	addi	a0,a0,814 # 2c78 <enable_deadlock_detect+0x15e>
    1952:	5d1000ef          	jal	ra,2722 <basename>
    1956:	872a                	mv	a4,a0
    1958:	00001617          	auipc	a2,0x1
    195c:	22060613          	addi	a2,a2,544 # 2b78 <enable_deadlock_detect+0x5e>
    1960:	05400793          	li	a5,84
    1964:	86a2                	mv	a3,s0
    1966:	45fd                	li	a1,31
    1968:	00001517          	auipc	a0,0x1
    196c:	35050513          	addi	a0,a0,848 # 2cb8 <enable_deadlock_detect+0x19e>
    1970:	cabff0ef          	jal	ra,161a <printf>
    1974:	557d                	li	a0,-1
    1976:	707000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    197a:	000a2603          	lw	a2,0(s4)
    197e:	de41                	beqz	a2,1916 <printf+0x2fc>
    1980:	b775                	j	192c <printf+0x312>
		mutex_lock(buffer_lock);
    1982:	10ca2503          	lw	a0,268(s4)
    1986:	134010ef          	jal	ra,2aba <mutex_lock>
		buffer[buffer_len++] = c;
    198a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    198e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1992:	0017861b          	addiw	a2,a5,1
    1996:	97d2                	add	a5,a5,s4
    1998:	00ca2023          	sw	a2,0(s4)
    199c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19a0:	02c6d163          	bge	a3,a2,19c2 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    19a4:	10000793          	li	a5,256
    19a8:	02f61263          	bne	a2,a5,19cc <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    19ac:	00001597          	auipc	a1,0x1
    19b0:	3cc58593          	addi	a1,a1,972 # 2d78 <buffer>
    19b4:	4505                	li	a0,1
    19b6:	68d000ef          	jal	ra,2842 <write>
	buffer_len = 0;
    19ba:	00001797          	auipc	a5,0x1
    19be:	3a07ab23          	sw	zero,950(a5) # 2d70 <buffer_len>
		mutex_unlock(buffer_lock);
    19c2:	10ca2503          	lw	a0,268(s4)
    19c6:	100010ef          	jal	ra,2ac6 <mutex_unlock>
    19ca:	bdd9                	j	18a0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    19cc:	681000ef          	jal	ra,284c <getpid>
    19d0:	842a                	mv	s0,a0
    19d2:	00001517          	auipc	a0,0x1
    19d6:	2a650513          	addi	a0,a0,678 # 2c78 <enable_deadlock_detect+0x15e>
    19da:	549000ef          	jal	ra,2722 <basename>
    19de:	872a                	mv	a4,a0
    19e0:	00001617          	auipc	a2,0x1
    19e4:	19860613          	addi	a2,a2,408 # 2b78 <enable_deadlock_detect+0x5e>
    19e8:	05400793          	li	a5,84
    19ec:	86a2                	mv	a3,s0
    19ee:	45fd                	li	a1,31
    19f0:	00001517          	auipc	a0,0x1
    19f4:	2c850513          	addi	a0,a0,712 # 2cb8 <enable_deadlock_detect+0x19e>
    19f8:	c23ff0ef          	jal	ra,161a <printf>
    19fc:	557d                	li	a0,-1
    19fe:	67f000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    1a02:	000a2603          	lw	a2,0(s4)
    1a06:	de55                	beqz	a2,19c2 <printf+0x3a8>
    1a08:	b755                	j	19ac <printf+0x392>
		mutex_lock(buffer_lock);
    1a0a:	10ca2503          	lw	a0,268(s4)
    1a0e:	e42e                	sd	a1,8(sp)
		s += 2;
    1a10:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1a14:	0a6010ef          	jal	ra,2aba <mutex_lock>
		len = out_unlocked(s, l);
    1a18:	65a2                	ld	a1,8(sp)
    1a1a:	8522                	mv	a0,s0
    1a1c:	08a000ef          	jal	ra,1aa6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1a20:	10ca2503          	lw	a0,268(s4)
    1a24:	0a2010ef          	jal	ra,2ac6 <mutex_unlock>
		s += 2;
    1a28:	bb55                	j	17dc <printf+0x1c2>
				a = "(null)";
    1a2a:	00001417          	auipc	s0,0x1
    1a2e:	24640413          	addi	s0,s0,582 # 2c70 <enable_deadlock_detect+0x156>
    1a32:	bd2d                	j	186c <printf+0x252>

0000000000001a34 <enable_thread_io_buffer>:
{
    1a34:	1101                	addi	sp,sp,-32
    1a36:	e822                	sd	s0,16(sp)
    1a38:	ec06                	sd	ra,24(sp)
    1a3a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1a3c:	00001417          	auipc	s0,0x1
    1a40:	33440413          	addi	s0,s0,820 # 2d70 <buffer_len>
    1a44:	05a010ef          	jal	ra,2a9e <mutex_create>
    1a48:	10a42623          	sw	a0,268(s0)
    1a4c:	00054a63          	bltz	a0,1a60 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1a50:	4785                	li	a5,1
}
    1a52:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1a54:	10f42423          	sw	a5,264(s0)
}
    1a58:	6442                	ld	s0,16(sp)
    1a5a:	64a2                	ld	s1,8(sp)
    1a5c:	6105                	addi	sp,sp,32
    1a5e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1a60:	5ed000ef          	jal	ra,284c <getpid>
    1a64:	84aa                	mv	s1,a0
    1a66:	00001517          	auipc	a0,0x1
    1a6a:	21250513          	addi	a0,a0,530 # 2c78 <enable_deadlock_detect+0x15e>
    1a6e:	4b5000ef          	jal	ra,2722 <basename>
    1a72:	872a                	mv	a4,a0
    1a74:	04800793          	li	a5,72
    1a78:	86a6                	mv	a3,s1
    1a7a:	00001517          	auipc	a0,0x1
    1a7e:	27e50513          	addi	a0,a0,638 # 2cf8 <enable_deadlock_detect+0x1de>
    1a82:	00001617          	auipc	a2,0x1
    1a86:	0f660613          	addi	a2,a2,246 # 2b78 <enable_deadlock_detect+0x5e>
    1a8a:	45fd                	li	a1,31
    1a8c:	b8fff0ef          	jal	ra,161a <printf>
    1a90:	557d                	li	a0,-1
    1a92:	5eb000ef          	jal	ra,287c <exit>
	buffer_lock_enabled = 1;
    1a96:	4785                	li	a5,1
}
    1a98:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1a9a:	10f42423          	sw	a5,264(s0)
}
    1a9e:	6442                	ld	s0,16(sp)
    1aa0:	64a2                	ld	s1,8(sp)
    1aa2:	6105                	addi	sp,sp,32
    1aa4:	8082                	ret

0000000000001aa6 <out_unlocked>:
{
    1aa6:	7159                	addi	sp,sp,-112
    1aa8:	f486                	sd	ra,104(sp)
    1aaa:	f0a2                	sd	s0,96(sp)
    1aac:	eca6                	sd	s1,88(sp)
    1aae:	e8ca                	sd	s2,80(sp)
    1ab0:	e4ce                	sd	s3,72(sp)
    1ab2:	e0d2                	sd	s4,64(sp)
    1ab4:	fc56                	sd	s5,56(sp)
    1ab6:	f85a                	sd	s6,48(sp)
    1ab8:	f45e                	sd	s7,40(sp)
    1aba:	f062                	sd	s8,32(sp)
    1abc:	ec66                	sd	s9,24(sp)
    1abe:	e86a                	sd	s10,16(sp)
    1ac0:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1ac2:	0e058663          	beqz	a1,1bae <out_unlocked+0x108>
    1ac6:	842a                	mv	s0,a0
    1ac8:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1acc:	4981                	li	s3,0
    1ace:	00001d17          	auipc	s10,0x1
    1ad2:	2a2d0d13          	addi	s10,s10,674 # 2d70 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1ad6:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1ada:	00001b17          	auipc	s6,0x1
    1ade:	29eb0b13          	addi	s6,s6,670 # 2d78 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1ae2:	10000a93          	li	s5,256
    1ae6:	00001c97          	auipc	s9,0x1
    1aea:	192c8c93          	addi	s9,s9,402 # 2c78 <enable_deadlock_detect+0x15e>
    1aee:	00001c17          	auipc	s8,0x1
    1af2:	08ac0c13          	addi	s8,s8,138 # 2b78 <enable_deadlock_detect+0x5e>
    1af6:	00001b97          	auipc	s7,0x1
    1afa:	1c2b8b93          	addi	s7,s7,450 # 2cb8 <enable_deadlock_detect+0x19e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1afe:	4a29                	li	s4,10
    1b00:	a031                	j	1b0c <out_unlocked+0x66>
    1b02:	09468863          	beq	a3,s4,1b92 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1b06:	0405                	addi	s0,s0,1
    1b08:	04848163          	beq	s1,s0,1b4a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1b0c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1b10:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1b14:	0017861b          	addiw	a2,a5,1
    1b18:	97ea                	add	a5,a5,s10
    1b1a:	00cd2023          	sw	a2,0(s10)
    1b1e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b22:	fec950e3          	bge	s2,a2,1b02 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1b26:	05561263          	bne	a2,s5,1b6a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1b2a:	85da                	mv	a1,s6
    1b2c:	4505                	li	a0,1
    1b2e:	515000ef          	jal	ra,2842 <write>
    1b32:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b34:	00001797          	auipc	a5,0x1
    1b38:	2207ae23          	sw	zero,572(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1b3c:	06054763          	bltz	a0,1baa <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1b40:	0405                	addi	s0,s0,1
			ret += r;
    1b42:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1b46:	fc8493e3          	bne	s1,s0,1b0c <out_unlocked+0x66>
}
    1b4a:	70a6                	ld	ra,104(sp)
    1b4c:	7406                	ld	s0,96(sp)
    1b4e:	64e6                	ld	s1,88(sp)
    1b50:	6946                	ld	s2,80(sp)
    1b52:	6a06                	ld	s4,64(sp)
    1b54:	7ae2                	ld	s5,56(sp)
    1b56:	7b42                	ld	s6,48(sp)
    1b58:	7ba2                	ld	s7,40(sp)
    1b5a:	7c02                	ld	s8,32(sp)
    1b5c:	6ce2                	ld	s9,24(sp)
    1b5e:	6d42                	ld	s10,16(sp)
    1b60:	6da2                	ld	s11,8(sp)
    1b62:	854e                	mv	a0,s3
    1b64:	69a6                	ld	s3,72(sp)
    1b66:	6165                	addi	sp,sp,112
    1b68:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b6a:	4e3000ef          	jal	ra,284c <getpid>
    1b6e:	8daa                	mv	s11,a0
    1b70:	8566                	mv	a0,s9
    1b72:	3b1000ef          	jal	ra,2722 <basename>
    1b76:	872a                	mv	a4,a0
    1b78:	8662                	mv	a2,s8
    1b7a:	05400793          	li	a5,84
    1b7e:	86ee                	mv	a3,s11
    1b80:	45fd                	li	a1,31
    1b82:	855e                	mv	a0,s7
    1b84:	a97ff0ef          	jal	ra,161a <printf>
    1b88:	557d                	li	a0,-1
    1b8a:	4f3000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    1b8e:	000d2603          	lw	a2,0(s10)
    1b92:	da35                	beqz	a2,1b06 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1b94:	85da                	mv	a1,s6
    1b96:	4505                	li	a0,1
    1b98:	4ab000ef          	jal	ra,2842 <write>
    1b9c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b9e:	00001797          	auipc	a5,0x1
    1ba2:	1c07a923          	sw	zero,466(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1ba6:	f8055de3          	bgez	a0,1b40 <out_unlocked+0x9a>
    1baa:	89aa                	mv	s3,a0
    1bac:	bf79                	j	1b4a <out_unlocked+0xa4>
	int ret = 0;
    1bae:	4981                	li	s3,0
    1bb0:	bf69                	j	1b4a <out_unlocked+0xa4>

0000000000001bb2 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1bb2:	1101                	addi	sp,sp,-32
    1bb4:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1bb6:	00001497          	auipc	s1,0x1
    1bba:	1ba48493          	addi	s1,s1,442 # 2d70 <buffer_len>
    1bbe:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1bc0:	ec06                	sd	ra,24(sp)
    1bc2:	e822                	sd	s0,16(sp)
		char c = s[i];
    1bc4:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1bc8:	0017861b          	addiw	a2,a5,1
    1bcc:	97a6                	add	a5,a5,s1
    1bce:	00e78423          	sb	a4,8(a5)
    1bd2:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1bd4:	0ff00793          	li	a5,255
    1bd8:	00c7cc63          	blt	a5,a2,1bf0 <out_unlocked.constprop.0+0x3e>
    1bdc:	47a9                	li	a5,10
    1bde:	06f70c63          	beq	a4,a5,1c56 <out_unlocked.constprop.0+0xa4>
    1be2:	4601                	li	a2,0
}
    1be4:	60e2                	ld	ra,24(sp)
    1be6:	6442                	ld	s0,16(sp)
    1be8:	64a2                	ld	s1,8(sp)
    1bea:	8532                	mv	a0,a2
    1bec:	6105                	addi	sp,sp,32
    1bee:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bf0:	10000793          	li	a5,256
    1bf4:	02f61563          	bne	a2,a5,1c1e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1bf8:	00001597          	auipc	a1,0x1
    1bfc:	18058593          	addi	a1,a1,384 # 2d78 <buffer>
    1c00:	4505                	li	a0,1
    1c02:	441000ef          	jal	ra,2842 <write>
}
    1c06:	60e2                	ld	ra,24(sp)
    1c08:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1c0a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1c0e:	00001797          	auipc	a5,0x1
    1c12:	1607a123          	sw	zero,354(a5) # 2d70 <buffer_len>
}
    1c16:	64a2                	ld	s1,8(sp)
    1c18:	8532                	mv	a0,a2
    1c1a:	6105                	addi	sp,sp,32
    1c1c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c1e:	42f000ef          	jal	ra,284c <getpid>
    1c22:	842a                	mv	s0,a0
    1c24:	00001517          	auipc	a0,0x1
    1c28:	05450513          	addi	a0,a0,84 # 2c78 <enable_deadlock_detect+0x15e>
    1c2c:	2f7000ef          	jal	ra,2722 <basename>
    1c30:	872a                	mv	a4,a0
    1c32:	00001617          	auipc	a2,0x1
    1c36:	f4660613          	addi	a2,a2,-186 # 2b78 <enable_deadlock_detect+0x5e>
    1c3a:	05400793          	li	a5,84
    1c3e:	86a2                	mv	a3,s0
    1c40:	45fd                	li	a1,31
    1c42:	00001517          	auipc	a0,0x1
    1c46:	07650513          	addi	a0,a0,118 # 2cb8 <enable_deadlock_detect+0x19e>
    1c4a:	9d1ff0ef          	jal	ra,161a <printf>
    1c4e:	557d                	li	a0,-1
    1c50:	42d000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    1c54:	4090                	lw	a2,0(s1)
    1c56:	d659                	beqz	a2,1be4 <out_unlocked.constprop.0+0x32>
    1c58:	b745                	j	1bf8 <out_unlocked.constprop.0+0x46>

0000000000001c5a <putchar>:
{
    1c5a:	7139                	addi	sp,sp,-64
    1c5c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1c5e:	00001497          	auipc	s1,0x1
    1c62:	11248493          	addi	s1,s1,274 # 2d70 <buffer_len>
    1c66:	1084a703          	lw	a4,264(s1)
{
    1c6a:	f822                	sd	s0,48(sp)
	char byte = c;
    1c6c:	0ff57413          	zext.b	s0,a0
{
    1c70:	fc06                	sd	ra,56(sp)
	char byte = c;
    1c72:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1c76:	4785                	li	a5,1
    1c78:	00f70d63          	beq	a4,a5,1c92 <putchar+0x38>
		len = out_unlocked(s, l);
    1c7c:	01f10513          	addi	a0,sp,31
    1c80:	f33ff0ef          	jal	ra,1bb2 <out_unlocked.constprop.0>
}
    1c84:	70e2                	ld	ra,56(sp)
    1c86:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1c88:	862a                	mv	a2,a0
}
    1c8a:	74a2                	ld	s1,40(sp)
    1c8c:	8532                	mv	a0,a2
    1c8e:	6121                	addi	sp,sp,64
    1c90:	8082                	ret
		mutex_lock(buffer_lock);
    1c92:	10c4a503          	lw	a0,268(s1)
    1c96:	625000ef          	jal	ra,2aba <mutex_lock>
		buffer[buffer_len++] = c;
    1c9a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c9c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1ca0:	0017861b          	addiw	a2,a5,1
    1ca4:	97a6                	add	a5,a5,s1
    1ca6:	c090                	sw	a2,0(s1)
    1ca8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cac:	02c6c263          	blt	a3,a2,1cd0 <putchar+0x76>
    1cb0:	47a9                	li	a5,10
    1cb2:	06f40d63          	beq	s0,a5,1d2c <putchar+0xd2>
    1cb6:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1cb8:	10c4a503          	lw	a0,268(s1)
    1cbc:	e432                	sd	a2,8(sp)
    1cbe:	609000ef          	jal	ra,2ac6 <mutex_unlock>
    1cc2:	6622                	ld	a2,8(sp)
}
    1cc4:	70e2                	ld	ra,56(sp)
    1cc6:	7442                	ld	s0,48(sp)
    1cc8:	74a2                	ld	s1,40(sp)
    1cca:	8532                	mv	a0,a2
    1ccc:	6121                	addi	sp,sp,64
    1cce:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1cd0:	10000793          	li	a5,256
    1cd4:	02f61063          	bne	a2,a5,1cf4 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1cd8:	00001597          	auipc	a1,0x1
    1cdc:	0a058593          	addi	a1,a1,160 # 2d78 <buffer>
    1ce0:	4505                	li	a0,1
    1ce2:	361000ef          	jal	ra,2842 <write>
    1ce6:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1cea:	00001797          	auipc	a5,0x1
    1cee:	0807a323          	sw	zero,134(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1cf2:	b7d9                	j	1cb8 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1cf4:	359000ef          	jal	ra,284c <getpid>
    1cf8:	842a                	mv	s0,a0
    1cfa:	00001517          	auipc	a0,0x1
    1cfe:	f7e50513          	addi	a0,a0,-130 # 2c78 <enable_deadlock_detect+0x15e>
    1d02:	221000ef          	jal	ra,2722 <basename>
    1d06:	872a                	mv	a4,a0
    1d08:	00001617          	auipc	a2,0x1
    1d0c:	e7060613          	addi	a2,a2,-400 # 2b78 <enable_deadlock_detect+0x5e>
    1d10:	05400793          	li	a5,84
    1d14:	86a2                	mv	a3,s0
    1d16:	45fd                	li	a1,31
    1d18:	00001517          	auipc	a0,0x1
    1d1c:	fa050513          	addi	a0,a0,-96 # 2cb8 <enable_deadlock_detect+0x19e>
    1d20:	8fbff0ef          	jal	ra,161a <printf>
    1d24:	557d                	li	a0,-1
    1d26:	357000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    1d2a:	4090                	lw	a2,0(s1)
    1d2c:	d651                	beqz	a2,1cb8 <putchar+0x5e>
    1d2e:	b76d                	j	1cd8 <putchar+0x7e>

0000000000001d30 <puts>:
{
    1d30:	7139                	addi	sp,sp,-64
    1d32:	f822                	sd	s0,48(sp)
    1d34:	f426                	sd	s1,40(sp)
    1d36:	fc06                	sd	ra,56(sp)
    1d38:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1d3a:	00001417          	auipc	s0,0x1
    1d3e:	03640413          	addi	s0,s0,54 # 2d70 <buffer_len>
{
    1d42:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d44:	638000ef          	jal	ra,237c <strlen>
	if (buffer_lock_enabled == 1) {
    1d48:	10842703          	lw	a4,264(s0)
    1d4c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d4e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1d50:	04f70563          	beq	a4,a5,1d9a <puts+0x6a>
		len = out_unlocked(s, l);
    1d54:	8526                	mv	a0,s1
    1d56:	d51ff0ef          	jal	ra,1aa6 <out_unlocked>
    1d5a:	892a                	mv	s2,a0
    1d5c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d5e:	00095963          	bgez	s2,1d70 <puts+0x40>
}
    1d62:	70e2                	ld	ra,56(sp)
    1d64:	7442                	ld	s0,48(sp)
    1d66:	7902                	ld	s2,32(sp)
    1d68:	8526                	mv	a0,s1
    1d6a:	74a2                	ld	s1,40(sp)
    1d6c:	6121                	addi	sp,sp,64
    1d6e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1d70:	10842703          	lw	a4,264(s0)
	char byte = c;
    1d74:	44a9                	li	s1,10
    1d76:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1d7a:	4785                	li	a5,1
    1d7c:	02f70e63          	beq	a4,a5,1db8 <puts+0x88>
		len = out_unlocked(s, l);
    1d80:	01f10513          	addi	a0,sp,31
    1d84:	e2fff0ef          	jal	ra,1bb2 <out_unlocked.constprop.0>
}
    1d88:	70e2                	ld	ra,56(sp)
    1d8a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d8c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1d90:	7902                	ld	s2,32(sp)
    1d92:	8526                	mv	a0,s1
    1d94:	74a2                	ld	s1,40(sp)
    1d96:	6121                	addi	sp,sp,64
    1d98:	8082                	ret
		mutex_lock(buffer_lock);
    1d9a:	e42a                	sd	a0,8(sp)
    1d9c:	10c42503          	lw	a0,268(s0)
    1da0:	51b000ef          	jal	ra,2aba <mutex_lock>
		len = out_unlocked(s, l);
    1da4:	65a2                	ld	a1,8(sp)
    1da6:	8526                	mv	a0,s1
    1da8:	cffff0ef          	jal	ra,1aa6 <out_unlocked>
    1dac:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1dae:	10c42503          	lw	a0,268(s0)
    1db2:	515000ef          	jal	ra,2ac6 <mutex_unlock>
    1db6:	b75d                	j	1d5c <puts+0x2c>
		mutex_lock(buffer_lock);
    1db8:	10c42503          	lw	a0,268(s0)
    1dbc:	4ff000ef          	jal	ra,2aba <mutex_lock>
		buffer[buffer_len++] = c;
    1dc0:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1dc2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1dc6:	0017861b          	addiw	a2,a5,1
    1dca:	97a2                	add	a5,a5,s0
    1dcc:	c010                	sw	a2,0(s0)
    1dce:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1dd2:	06c6dc63          	bge	a3,a2,1e4a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1dd6:	10000793          	li	a5,256
    1dda:	02f61c63          	bne	a2,a5,1e12 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1dde:	00001597          	auipc	a1,0x1
    1de2:	f9a58593          	addi	a1,a1,-102 # 2d78 <buffer>
    1de6:	4505                	li	a0,1
    1de8:	25b000ef          	jal	ra,2842 <write>
			if (r < 0) {
    1dec:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1dee:	00001797          	auipc	a5,0x1
    1df2:	f807a123          	sw	zero,-126(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1df6:	04054c63          	bltz	a0,1e4e <puts+0x11e>
			if (r < buffer_len) {
    1dfa:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1dfc:	10c42503          	lw	a0,268(s0)
    1e00:	4c7000ef          	jal	ra,2ac6 <mutex_unlock>
}
    1e04:	70e2                	ld	ra,56(sp)
    1e06:	7442                	ld	s0,48(sp)
    1e08:	7902                	ld	s2,32(sp)
    1e0a:	8526                	mv	a0,s1
    1e0c:	74a2                	ld	s1,40(sp)
    1e0e:	6121                	addi	sp,sp,64
    1e10:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1e12:	23b000ef          	jal	ra,284c <getpid>
    1e16:	84aa                	mv	s1,a0
    1e18:	00001517          	auipc	a0,0x1
    1e1c:	e6050513          	addi	a0,a0,-416 # 2c78 <enable_deadlock_detect+0x15e>
    1e20:	103000ef          	jal	ra,2722 <basename>
    1e24:	872a                	mv	a4,a0
    1e26:	00001617          	auipc	a2,0x1
    1e2a:	d5260613          	addi	a2,a2,-686 # 2b78 <enable_deadlock_detect+0x5e>
    1e2e:	05400793          	li	a5,84
    1e32:	86a6                	mv	a3,s1
    1e34:	45fd                	li	a1,31
    1e36:	00001517          	auipc	a0,0x1
    1e3a:	e8250513          	addi	a0,a0,-382 # 2cb8 <enable_deadlock_detect+0x19e>
    1e3e:	fdcff0ef          	jal	ra,161a <printf>
    1e42:	557d                	li	a0,-1
    1e44:	239000ef          	jal	ra,287c <exit>
	if (buffer_len == 0)
    1e48:	4010                	lw	a2,0(s0)
    1e4a:	da45                	beqz	a2,1dfa <puts+0xca>
    1e4c:	bf49                	j	1dde <puts+0xae>
    1e4e:	54fd                	li	s1,-1
    1e50:	b775                	j	1dfc <puts+0xcc>

0000000000001e52 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1e52:	715d                	addi	sp,sp,-80
    1e54:	e486                	sd	ra,72(sp)
    1e56:	e0a2                	sd	s0,64(sp)
    1e58:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1e5a:	14054363          	bltz	a0,1fa0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1e5e:	02b577bb          	remuw	a5,a0,a1
    1e62:	00001617          	auipc	a2,0x1
    1e66:	03e60613          	addi	a2,a2,62 # 2ea0 <digits>
	buf[16] = 0;
    1e6a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e6e:	0005871b          	sext.w	a4,a1
    1e72:	1782                	slli	a5,a5,0x20
    1e74:	9381                	srli	a5,a5,0x20
    1e76:	97b2                	add	a5,a5,a2
    1e78:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e7c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1e80:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1e84:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1e86:	0eb56763          	bltu	a0,a1,1f74 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1e8a:	02e877bb          	remuw	a5,a6,a4
    1e8e:	1782                	slli	a5,a5,0x20
    1e90:	9381                	srli	a5,a5,0x20
    1e92:	97b2                	add	a5,a5,a2
    1e94:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e98:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1e9c:	02f10323          	sb	a5,38(sp)
    1ea0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ea2:	0ce86963          	bltu	a6,a4,1f74 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ea6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1eaa:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1eae:	1582                	slli	a1,a1,0x20
    1eb0:	9181                	srli	a1,a1,0x20
    1eb2:	95b2                	add	a1,a1,a2
    1eb4:	0005c583          	lbu	a1,0(a1)
    1eb8:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1ebc:	0007859b          	sext.w	a1,a5
    1ec0:	16e6e563          	bltu	a3,a4,202a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ec4:	02e7f6bb          	remuw	a3,a5,a4
    1ec8:	1682                	slli	a3,a3,0x20
    1eca:	9281                	srli	a3,a3,0x20
    1ecc:	96b2                	add	a3,a3,a2
    1ece:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ed2:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ed6:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1eda:	16e5e163          	bltu	a1,a4,203c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1ede:	02e876bb          	remuw	a3,a6,a4
    1ee2:	1682                	slli	a3,a3,0x20
    1ee4:	9281                	srli	a3,a3,0x20
    1ee6:	96b2                	add	a3,a3,a2
    1ee8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1eec:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ef0:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1ef4:	14e86d63          	bltu	a6,a4,204e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1ef8:	02e5f6bb          	remuw	a3,a1,a4
    1efc:	1682                	slli	a3,a3,0x20
    1efe:	9281                	srli	a3,a3,0x20
    1f00:	96b2                	add	a3,a3,a2
    1f02:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f06:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f0a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1f0e:	10e5e563          	bltu	a1,a4,2018 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1f12:	02e876bb          	remuw	a3,a6,a4
    1f16:	1682                	slli	a3,a3,0x20
    1f18:	9281                	srli	a3,a3,0x20
    1f1a:	96b2                	add	a3,a3,a2
    1f1c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f20:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f24:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1f28:	14e86263          	bltu	a6,a4,206c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1f2c:	02e5f6bb          	remuw	a3,a1,a4
    1f30:	1682                	slli	a3,a3,0x20
    1f32:	9281                	srli	a3,a3,0x20
    1f34:	96b2                	add	a3,a3,a2
    1f36:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f3a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f3e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1f42:	14e5e463          	bltu	a1,a4,208a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1f46:	02e876bb          	remuw	a3,a6,a4
    1f4a:	1682                	slli	a3,a3,0x20
    1f4c:	9281                	srli	a3,a3,0x20
    1f4e:	96b2                	add	a3,a3,a2
    1f50:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f54:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1f58:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1f5c:	14e86063          	bltu	a6,a4,209c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1f60:	1782                	slli	a5,a5,0x20
    1f62:	9381                	srli	a5,a5,0x20
    1f64:	97b2                	add	a5,a5,a2
    1f66:	0007c703          	lbu	a4,0(a5)
    1f6a:	4799                	li	a5,6
    1f6c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1f70:	10054763          	bltz	a0,207e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1f74:	00001497          	auipc	s1,0x1
    1f78:	dfc48493          	addi	s1,s1,-516 # 2d70 <buffer_len>
    1f7c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1f80:	0828                	addi	a0,sp,24
    1f82:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1f84:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1f86:	00f50433          	add	s0,a0,a5
    1f8a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1f8c:	06e68463          	beq	a3,a4,1ff4 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1f90:	8522                	mv	a0,s0
    1f92:	b15ff0ef          	jal	ra,1aa6 <out_unlocked>
}
    1f96:	60a6                	ld	ra,72(sp)
    1f98:	6406                	ld	s0,64(sp)
    1f9a:	74e2                	ld	s1,56(sp)
    1f9c:	6161                	addi	sp,sp,80
    1f9e:	8082                	ret
		x = -xx;
    1fa0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1fa4:	02b877bb          	remuw	a5,a6,a1
    1fa8:	00001617          	auipc	a2,0x1
    1fac:	ef860613          	addi	a2,a2,-264 # 2ea0 <digits>
	buf[16] = 0;
    1fb0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1fb4:	0005871b          	sext.w	a4,a1
    1fb8:	1782                	slli	a5,a5,0x20
    1fba:	9381                	srli	a5,a5,0x20
    1fbc:	97b2                	add	a5,a5,a2
    1fbe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1fc2:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1fc6:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1fca:	08b86b63          	bltu	a6,a1,2060 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1fce:	02e8f7bb          	remuw	a5,a7,a4
    1fd2:	1782                	slli	a5,a5,0x20
    1fd4:	9381                	srli	a5,a5,0x20
    1fd6:	97b2                	add	a5,a5,a2
    1fd8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1fdc:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1fe0:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1fe4:	ece8f1e3          	bgeu	a7,a4,1ea6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1fe8:	02d00793          	li	a5,45
    1fec:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1ff0:	47b5                	li	a5,13
    1ff2:	b749                	j	1f74 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1ff4:	10c4a503          	lw	a0,268(s1)
    1ff8:	e42e                	sd	a1,8(sp)
    1ffa:	2c1000ef          	jal	ra,2aba <mutex_lock>
		len = out_unlocked(s, l);
    1ffe:	65a2                	ld	a1,8(sp)
    2000:	8522                	mv	a0,s0
    2002:	aa5ff0ef          	jal	ra,1aa6 <out_unlocked>
		mutex_unlock(buffer_lock);
    2006:	10c4a503          	lw	a0,268(s1)
    200a:	2bd000ef          	jal	ra,2ac6 <mutex_unlock>
}
    200e:	60a6                	ld	ra,72(sp)
    2010:	6406                	ld	s0,64(sp)
    2012:	74e2                	ld	s1,56(sp)
    2014:	6161                	addi	sp,sp,80
    2016:	8082                	ret
		buf[i--] = digits[x % base];
    2018:	47a9                	li	a5,10
	if (sign)
    201a:	f4055de3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    201e:	02d00793          	li	a5,45
    2022:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    2026:	47a5                	li	a5,9
    2028:	b7b1                	j	1f74 <printint.constprop.0+0x122>
    202a:	47b5                	li	a5,13
	if (sign)
    202c:	f40554e3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2030:	02d00793          	li	a5,45
    2034:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    2038:	47b1                	li	a5,12
    203a:	bf2d                	j	1f74 <printint.constprop.0+0x122>
    203c:	47b1                	li	a5,12
	if (sign)
    203e:	f2055be3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2042:	02d00793          	li	a5,45
    2046:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    204a:	47ad                	li	a5,11
    204c:	b725                	j	1f74 <printint.constprop.0+0x122>
    204e:	47ad                	li	a5,11
	if (sign)
    2050:	f20552e3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2054:	02d00793          	li	a5,45
    2058:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    205c:	47a9                	li	a5,10
    205e:	bf19                	j	1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2060:	02d00793          	li	a5,45
    2064:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    2068:	47b9                	li	a5,14
    206a:	b729                	j	1f74 <printint.constprop.0+0x122>
    206c:	47a5                	li	a5,9
	if (sign)
    206e:	f00553e3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2072:	02d00793          	li	a5,45
    2076:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    207a:	47a1                	li	a5,8
    207c:	bde5                	j	1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    207e:	02d00793          	li	a5,45
    2082:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    2086:	4795                	li	a5,5
    2088:	b5f5                	j	1f74 <printint.constprop.0+0x122>
    208a:	47a1                	li	a5,8
	if (sign)
    208c:	ee0554e3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2090:	02d00793          	li	a5,45
    2094:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    2098:	479d                	li	a5,7
    209a:	bde9                	j	1f74 <printint.constprop.0+0x122>
    209c:	479d                	li	a5,7
	if (sign)
    209e:	ec055be3          	bgez	a0,1f74 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20a2:	02d00793          	li	a5,45
    20a6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    20aa:	4799                	li	a5,6
    20ac:	b5e1                	j	1f74 <printint.constprop.0+0x122>

00000000000020ae <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    20ae:	02000793          	li	a5,32
    20b2:	00f50663          	beq	a0,a5,20be <isspace+0x10>
    20b6:	355d                	addiw	a0,a0,-9
    20b8:	00553513          	sltiu	a0,a0,5
    20bc:	8082                	ret
    20be:	4505                	li	a0,1
}
    20c0:	8082                	ret

00000000000020c2 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    20c2:	fd05051b          	addiw	a0,a0,-48
}
    20c6:	00a53513          	sltiu	a0,a0,10
    20ca:	8082                	ret

00000000000020cc <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    20cc:	02000613          	li	a2,32
    20d0:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    20d2:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    20d6:	ff77869b          	addiw	a3,a5,-9
    20da:	04c78c63          	beq	a5,a2,2132 <atoi+0x66>
    20de:	0007871b          	sext.w	a4,a5
    20e2:	04d5f863          	bgeu	a1,a3,2132 <atoi+0x66>
		s++;
	switch (*s) {
    20e6:	02b00693          	li	a3,43
    20ea:	04d78963          	beq	a5,a3,213c <atoi+0x70>
    20ee:	02d00693          	li	a3,45
    20f2:	06d78263          	beq	a5,a3,2156 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    20f6:	fd07061b          	addiw	a2,a4,-48
    20fa:	47a5                	li	a5,9
    20fc:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    20fe:	4e01                	li	t3,0
	while (isdigit(*s))
    2100:	04c7e963          	bltu	a5,a2,2152 <atoi+0x86>
	int n = 0, neg = 0;
    2104:	4501                	li	a0,0
	while (isdigit(*s))
    2106:	4825                	li	a6,9
    2108:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    210c:	0025179b          	slliw	a5,a0,0x2
    2110:	9fa9                	addw	a5,a5,a0
    2112:	fd07031b          	addiw	t1,a4,-48
    2116:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    211a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    211e:	0685                	addi	a3,a3,1
    2120:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    2124:	0006071b          	sext.w	a4,a2
    2128:	feb870e3          	bgeu	a6,a1,2108 <atoi+0x3c>
	return neg ? n : -n;
    212c:	000e0563          	beqz	t3,2136 <atoi+0x6a>
}
    2130:	8082                	ret
		s++;
    2132:	0505                	addi	a0,a0,1
    2134:	bf79                	j	20d2 <atoi+0x6>
	return neg ? n : -n;
    2136:	4113053b          	subw	a0,t1,a7
    213a:	8082                	ret
	while (isdigit(*s))
    213c:	00154703          	lbu	a4,1(a0)
    2140:	47a5                	li	a5,9
		s++;
    2142:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2146:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    214a:	4e01                	li	t3,0
	while (isdigit(*s))
    214c:	2701                	sext.w	a4,a4
    214e:	fac7fbe3          	bgeu	a5,a2,2104 <atoi+0x38>
    2152:	4501                	li	a0,0
}
    2154:	8082                	ret
	while (isdigit(*s))
    2156:	00154703          	lbu	a4,1(a0)
    215a:	47a5                	li	a5,9
		s++;
    215c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2160:	fd07061b          	addiw	a2,a4,-48
    2164:	2701                	sext.w	a4,a4
    2166:	fec7e6e3          	bltu	a5,a2,2152 <atoi+0x86>
		neg = 1;
    216a:	4e05                	li	t3,1
    216c:	bf61                	j	2104 <atoi+0x38>

000000000000216e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    216e:	16060d63          	beqz	a2,22e8 <memset+0x17a>
    2172:	40a007b3          	neg	a5,a0
    2176:	8b9d                	andi	a5,a5,7
    2178:	00778693          	addi	a3,a5,7
    217c:	482d                	li	a6,11
    217e:	0ff5f713          	zext.b	a4,a1
    2182:	fff60593          	addi	a1,a2,-1
    2186:	1706e263          	bltu	a3,a6,22ea <memset+0x17c>
    218a:	16d5ea63          	bltu	a1,a3,22fe <memset+0x190>
    218e:	16078563          	beqz	a5,22f8 <memset+0x18a>
    2192:	00e50023          	sb	a4,0(a0)
    2196:	4685                	li	a3,1
    2198:	00150593          	addi	a1,a0,1
    219c:	14d78c63          	beq	a5,a3,22f4 <memset+0x186>
    21a0:	00e500a3          	sb	a4,1(a0)
    21a4:	4689                	li	a3,2
    21a6:	00250593          	addi	a1,a0,2
    21aa:	14d78d63          	beq	a5,a3,2304 <memset+0x196>
    21ae:	00e50123          	sb	a4,2(a0)
    21b2:	468d                	li	a3,3
    21b4:	00350593          	addi	a1,a0,3
    21b8:	12d78b63          	beq	a5,a3,22ee <memset+0x180>
    21bc:	00e501a3          	sb	a4,3(a0)
    21c0:	4691                	li	a3,4
    21c2:	00450593          	addi	a1,a0,4
    21c6:	14d78163          	beq	a5,a3,2308 <memset+0x19a>
    21ca:	00e50223          	sb	a4,4(a0)
    21ce:	4695                	li	a3,5
    21d0:	00550593          	addi	a1,a0,5
    21d4:	12d78c63          	beq	a5,a3,230c <memset+0x19e>
    21d8:	00e502a3          	sb	a4,5(a0)
    21dc:	469d                	li	a3,7
    21de:	00650593          	addi	a1,a0,6
    21e2:	12d79763          	bne	a5,a3,2310 <memset+0x1a2>
    21e6:	00750593          	addi	a1,a0,7
    21ea:	00e50323          	sb	a4,6(a0)
    21ee:	481d                	li	a6,7
    21f0:	00871693          	slli	a3,a4,0x8
    21f4:	01071893          	slli	a7,a4,0x10
    21f8:	8ed9                	or	a3,a3,a4
    21fa:	01871313          	slli	t1,a4,0x18
    21fe:	0116e6b3          	or	a3,a3,a7
    2202:	0066e6b3          	or	a3,a3,t1
    2206:	02071893          	slli	a7,a4,0x20
    220a:	02871e13          	slli	t3,a4,0x28
    220e:	0116e6b3          	or	a3,a3,a7
    2212:	40f60333          	sub	t1,a2,a5
    2216:	03071893          	slli	a7,a4,0x30
    221a:	01c6e6b3          	or	a3,a3,t3
    221e:	0116e6b3          	or	a3,a3,a7
    2222:	03871e13          	slli	t3,a4,0x38
    2226:	97aa                	add	a5,a5,a0
    2228:	ff837893          	andi	a7,t1,-8
    222c:	01c6e6b3          	or	a3,a3,t3
    2230:	98be                	add	a7,a7,a5
    2232:	e394                	sd	a3,0(a5)
    2234:	07a1                	addi	a5,a5,8
    2236:	ff179ee3          	bne	a5,a7,2232 <memset+0xc4>
    223a:	ff837893          	andi	a7,t1,-8
    223e:	011587b3          	add	a5,a1,a7
    2242:	010886bb          	addw	a3,a7,a6
    2246:	0b130663          	beq	t1,a7,22f2 <memset+0x184>
    224a:	00e78023          	sb	a4,0(a5)
    224e:	0016859b          	addiw	a1,a3,1
    2252:	08c5fb63          	bgeu	a1,a2,22e8 <memset+0x17a>
    2256:	00e780a3          	sb	a4,1(a5)
    225a:	0026859b          	addiw	a1,a3,2
    225e:	08c5f563          	bgeu	a1,a2,22e8 <memset+0x17a>
    2262:	00e78123          	sb	a4,2(a5)
    2266:	0036859b          	addiw	a1,a3,3
    226a:	06c5ff63          	bgeu	a1,a2,22e8 <memset+0x17a>
    226e:	00e781a3          	sb	a4,3(a5)
    2272:	0046859b          	addiw	a1,a3,4
    2276:	06c5f963          	bgeu	a1,a2,22e8 <memset+0x17a>
    227a:	00e78223          	sb	a4,4(a5)
    227e:	0056859b          	addiw	a1,a3,5
    2282:	06c5f363          	bgeu	a1,a2,22e8 <memset+0x17a>
    2286:	00e782a3          	sb	a4,5(a5)
    228a:	0066859b          	addiw	a1,a3,6
    228e:	04c5fd63          	bgeu	a1,a2,22e8 <memset+0x17a>
    2292:	00e78323          	sb	a4,6(a5)
    2296:	0076859b          	addiw	a1,a3,7
    229a:	04c5f763          	bgeu	a1,a2,22e8 <memset+0x17a>
    229e:	00e783a3          	sb	a4,7(a5)
    22a2:	0086859b          	addiw	a1,a3,8
    22a6:	04c5f163          	bgeu	a1,a2,22e8 <memset+0x17a>
    22aa:	00e78423          	sb	a4,8(a5)
    22ae:	0096859b          	addiw	a1,a3,9
    22b2:	02c5fb63          	bgeu	a1,a2,22e8 <memset+0x17a>
    22b6:	00e784a3          	sb	a4,9(a5)
    22ba:	00a6859b          	addiw	a1,a3,10
    22be:	02c5f563          	bgeu	a1,a2,22e8 <memset+0x17a>
    22c2:	00e78523          	sb	a4,10(a5)
    22c6:	00b6859b          	addiw	a1,a3,11
    22ca:	00c5ff63          	bgeu	a1,a2,22e8 <memset+0x17a>
    22ce:	00e785a3          	sb	a4,11(a5)
    22d2:	00c6859b          	addiw	a1,a3,12
    22d6:	00c5f963          	bgeu	a1,a2,22e8 <memset+0x17a>
    22da:	00e78623          	sb	a4,12(a5)
    22de:	26b5                	addiw	a3,a3,13
    22e0:	00c6f463          	bgeu	a3,a2,22e8 <memset+0x17a>
    22e4:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    22e8:	8082                	ret
    22ea:	46ad                	li	a3,11
    22ec:	bd79                	j	218a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22ee:	480d                	li	a6,3
    22f0:	b701                	j	21f0 <memset+0x82>
    22f2:	8082                	ret
    22f4:	4805                	li	a6,1
    22f6:	bded                	j	21f0 <memset+0x82>
    22f8:	85aa                	mv	a1,a0
    22fa:	4801                	li	a6,0
    22fc:	bdd5                	j	21f0 <memset+0x82>
    22fe:	87aa                	mv	a5,a0
    2300:	4681                	li	a3,0
    2302:	b7a1                	j	224a <memset+0xdc>
    2304:	4809                	li	a6,2
    2306:	b5ed                	j	21f0 <memset+0x82>
    2308:	4811                	li	a6,4
    230a:	b5dd                	j	21f0 <memset+0x82>
    230c:	4815                	li	a6,5
    230e:	b5cd                	j	21f0 <memset+0x82>
    2310:	4819                	li	a6,6
    2312:	bdf9                	j	21f0 <memset+0x82>

0000000000002314 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2314:	00054783          	lbu	a5,0(a0)
    2318:	0005c703          	lbu	a4,0(a1)
    231c:	00e79863          	bne	a5,a4,232c <strcmp+0x18>
    2320:	0505                	addi	a0,a0,1
    2322:	0585                	addi	a1,a1,1
    2324:	fbe5                	bnez	a5,2314 <strcmp>
    2326:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2328:	9d19                	subw	a0,a0,a4
    232a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    232c:	0007851b          	sext.w	a0,a5
    2330:	bfe5                	j	2328 <strcmp+0x14>

0000000000002332 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2332:	ca15                	beqz	a2,2366 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2334:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2338:	167d                	addi	a2,a2,-1
    233a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    233e:	eb99                	bnez	a5,2354 <strncmp+0x22>
    2340:	a815                	j	2374 <strncmp+0x42>
    2342:	00a68e63          	beq	a3,a0,235e <strncmp+0x2c>
    2346:	0505                	addi	a0,a0,1
    2348:	00f71b63          	bne	a4,a5,235e <strncmp+0x2c>
    234c:	00054783          	lbu	a5,0(a0)
    2350:	cf89                	beqz	a5,236a <strncmp+0x38>
    2352:	85b2                	mv	a1,a2
    2354:	0005c703          	lbu	a4,0(a1)
    2358:	00158613          	addi	a2,a1,1
    235c:	f37d                	bnez	a4,2342 <strncmp+0x10>
		;
	return *l - *r;
    235e:	0007851b          	sext.w	a0,a5
    2362:	9d19                	subw	a0,a0,a4
    2364:	8082                	ret
		return 0;
    2366:	4501                	li	a0,0
}
    2368:	8082                	ret
	return *l - *r;
    236a:	0015c703          	lbu	a4,1(a1)
    236e:	4501                	li	a0,0
    2370:	9d19                	subw	a0,a0,a4
    2372:	8082                	ret
    2374:	0005c703          	lbu	a4,0(a1)
    2378:	4501                	li	a0,0
    237a:	b7e5                	j	2362 <strncmp+0x30>

000000000000237c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    237c:	00757793          	andi	a5,a0,7
    2380:	cf89                	beqz	a5,239a <strlen+0x1e>
    2382:	87aa                	mv	a5,a0
    2384:	a029                	j	238e <strlen+0x12>
    2386:	0785                	addi	a5,a5,1
    2388:	0077f713          	andi	a4,a5,7
    238c:	cb01                	beqz	a4,239c <strlen+0x20>
		if (!*s)
    238e:	0007c703          	lbu	a4,0(a5)
    2392:	fb75                	bnez	a4,2386 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2394:	40a78533          	sub	a0,a5,a0
}
    2398:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    239a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    239c:	6394                	ld	a3,0(a5)
    239e:	00001597          	auipc	a1,0x1
    23a2:	9b25b583          	ld	a1,-1614(a1) # 2d50 <enable_deadlock_detect+0x236>
    23a6:	00001617          	auipc	a2,0x1
    23aa:	9b263603          	ld	a2,-1614(a2) # 2d58 <enable_deadlock_detect+0x23e>
    23ae:	a019                	j	23b4 <strlen+0x38>
    23b0:	6794                	ld	a3,8(a5)
    23b2:	07a1                	addi	a5,a5,8
    23b4:	00b68733          	add	a4,a3,a1
    23b8:	fff6c693          	not	a3,a3
    23bc:	8f75                	and	a4,a4,a3
    23be:	8f71                	and	a4,a4,a2
    23c0:	db65                	beqz	a4,23b0 <strlen+0x34>
	for (; *s; s++)
    23c2:	0007c703          	lbu	a4,0(a5)
    23c6:	d779                	beqz	a4,2394 <strlen+0x18>
    23c8:	0017c703          	lbu	a4,1(a5)
    23cc:	0785                	addi	a5,a5,1
    23ce:	d379                	beqz	a4,2394 <strlen+0x18>
    23d0:	0017c703          	lbu	a4,1(a5)
    23d4:	0785                	addi	a5,a5,1
    23d6:	fb6d                	bnez	a4,23c8 <strlen+0x4c>
    23d8:	bf75                	j	2394 <strlen+0x18>

00000000000023da <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    23da:	00757713          	andi	a4,a0,7
{
    23de:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    23e0:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    23e4:	cb19                	beqz	a4,23fa <memchr+0x20>
    23e6:	ce25                	beqz	a2,245e <memchr+0x84>
    23e8:	0007c703          	lbu	a4,0(a5)
    23ec:	04b70e63          	beq	a4,a1,2448 <memchr+0x6e>
    23f0:	0785                	addi	a5,a5,1
    23f2:	0077f713          	andi	a4,a5,7
    23f6:	167d                	addi	a2,a2,-1
    23f8:	f77d                	bnez	a4,23e6 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    23fa:	4501                	li	a0,0
	if (n && *s != c) {
    23fc:	c235                	beqz	a2,2460 <memchr+0x86>
    23fe:	0007c703          	lbu	a4,0(a5)
    2402:	04b70363          	beq	a4,a1,2448 <memchr+0x6e>
		size_t k = ONES * c;
    2406:	00001517          	auipc	a0,0x1
    240a:	95a53503          	ld	a0,-1702(a0) # 2d60 <enable_deadlock_detect+0x246>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    240e:	471d                	li	a4,7
		size_t k = ONES * c;
    2410:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2414:	02c77a63          	bgeu	a4,a2,2448 <memchr+0x6e>
    2418:	00001897          	auipc	a7,0x1
    241c:	9388b883          	ld	a7,-1736(a7) # 2d50 <enable_deadlock_detect+0x236>
    2420:	00001817          	auipc	a6,0x1
    2424:	93883803          	ld	a6,-1736(a6) # 2d58 <enable_deadlock_detect+0x23e>
    2428:	431d                	li	t1,7
    242a:	a029                	j	2434 <memchr+0x5a>
		     w++, n -= SS)
    242c:	1661                	addi	a2,a2,-8
    242e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2430:	02c37963          	bgeu	t1,a2,2462 <memchr+0x88>
    2434:	6398                	ld	a4,0(a5)
    2436:	8f29                	xor	a4,a4,a0
    2438:	011706b3          	add	a3,a4,a7
    243c:	fff74713          	not	a4,a4
    2440:	8f75                	and	a4,a4,a3
    2442:	01077733          	and	a4,a4,a6
    2446:	d37d                	beqz	a4,242c <memchr+0x52>
{
    2448:	853e                	mv	a0,a5
    244a:	97b2                	add	a5,a5,a2
    244c:	a021                	j	2454 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    244e:	0505                	addi	a0,a0,1
    2450:	00f50763          	beq	a0,a5,245e <memchr+0x84>
    2454:	00054703          	lbu	a4,0(a0)
    2458:	feb71be3          	bne	a4,a1,244e <memchr+0x74>
    245c:	8082                	ret
	return n ? (void *)s : 0;
    245e:	4501                	li	a0,0
}
    2460:	8082                	ret
	return n ? (void *)s : 0;
    2462:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2464:	f275                	bnez	a2,2448 <memchr+0x6e>
}
    2466:	8082                	ret

0000000000002468 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2468:	1101                	addi	sp,sp,-32
    246a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    246c:	862e                	mv	a2,a1
{
    246e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2470:	4581                	li	a1,0
{
    2472:	e426                	sd	s1,8(sp)
    2474:	ec06                	sd	ra,24(sp)
    2476:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2478:	f63ff0ef          	jal	ra,23da <memchr>
	return p ? p - s : n;
    247c:	c519                	beqz	a0,248a <strnlen+0x22>
}
    247e:	60e2                	ld	ra,24(sp)
    2480:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2482:	8d05                	sub	a0,a0,s1
}
    2484:	64a2                	ld	s1,8(sp)
    2486:	6105                	addi	sp,sp,32
    2488:	8082                	ret
    248a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    248c:	8522                	mv	a0,s0
}
    248e:	6442                	ld	s0,16(sp)
    2490:	64a2                	ld	s1,8(sp)
    2492:	6105                	addi	sp,sp,32
    2494:	8082                	ret

0000000000002496 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2496:	00a5c7b3          	xor	a5,a1,a0
    249a:	8b9d                	andi	a5,a5,7
    249c:	eb95                	bnez	a5,24d0 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    249e:	0075f793          	andi	a5,a1,7
    24a2:	e7b1                	bnez	a5,24ee <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    24a4:	6198                	ld	a4,0(a1)
    24a6:	00001617          	auipc	a2,0x1
    24aa:	8aa63603          	ld	a2,-1878(a2) # 2d50 <enable_deadlock_detect+0x236>
    24ae:	00001817          	auipc	a6,0x1
    24b2:	8aa83803          	ld	a6,-1878(a6) # 2d58 <enable_deadlock_detect+0x23e>
    24b6:	a029                	j	24c0 <stpcpy+0x2a>
    24b8:	05a1                	addi	a1,a1,8
    24ba:	e118                	sd	a4,0(a0)
    24bc:	6198                	ld	a4,0(a1)
    24be:	0521                	addi	a0,a0,8
    24c0:	00c707b3          	add	a5,a4,a2
    24c4:	fff74693          	not	a3,a4
    24c8:	8ff5                	and	a5,a5,a3
    24ca:	0107f7b3          	and	a5,a5,a6
    24ce:	d7ed                	beqz	a5,24b8 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    24d0:	0005c783          	lbu	a5,0(a1)
    24d4:	00f50023          	sb	a5,0(a0)
    24d8:	c785                	beqz	a5,2500 <stpcpy+0x6a>
    24da:	0015c783          	lbu	a5,1(a1)
    24de:	0505                	addi	a0,a0,1
    24e0:	0585                	addi	a1,a1,1
    24e2:	00f50023          	sb	a5,0(a0)
    24e6:	fbf5                	bnez	a5,24da <stpcpy+0x44>
		;
	return d;
}
    24e8:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    24ea:	0505                	addi	a0,a0,1
    24ec:	df45                	beqz	a4,24a4 <stpcpy+0xe>
			if (!(*d = *s))
    24ee:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    24f2:	0585                	addi	a1,a1,1
    24f4:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    24f8:	00f50023          	sb	a5,0(a0)
    24fc:	f7fd                	bnez	a5,24ea <stpcpy+0x54>
}
    24fe:	8082                	ret
    2500:	8082                	ret

0000000000002502 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2502:	00a5c7b3          	xor	a5,a1,a0
    2506:	8b9d                	andi	a5,a5,7
    2508:	1a079863          	bnez	a5,26b8 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    250c:	0075f793          	andi	a5,a1,7
    2510:	16078463          	beqz	a5,2678 <stpncpy+0x176>
    2514:	ea01                	bnez	a2,2524 <stpncpy+0x22>
    2516:	a421                	j	271e <stpncpy+0x21c>
    2518:	167d                	addi	a2,a2,-1
    251a:	0505                	addi	a0,a0,1
    251c:	14070e63          	beqz	a4,2678 <stpncpy+0x176>
    2520:	1a060863          	beqz	a2,26d0 <stpncpy+0x1ce>
    2524:	0005c783          	lbu	a5,0(a1)
    2528:	0585                	addi	a1,a1,1
    252a:	0075f713          	andi	a4,a1,7
    252e:	00f50023          	sb	a5,0(a0)
    2532:	f3fd                	bnez	a5,2518 <stpncpy+0x16>
    2534:	4805                	li	a6,1
    2536:	1a061863          	bnez	a2,26e6 <stpncpy+0x1e4>
    253a:	40a007b3          	neg	a5,a0
    253e:	8b9d                	andi	a5,a5,7
    2540:	4681                	li	a3,0
    2542:	18061a63          	bnez	a2,26d6 <stpncpy+0x1d4>
    2546:	00778713          	addi	a4,a5,7
    254a:	45ad                	li	a1,11
    254c:	18b76363          	bltu	a4,a1,26d2 <stpncpy+0x1d0>
    2550:	1ae6eb63          	bltu	a3,a4,2706 <stpncpy+0x204>
    2554:	1a078363          	beqz	a5,26fa <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2558:	00050023          	sb	zero,0(a0)
    255c:	4685                	li	a3,1
    255e:	00150713          	addi	a4,a0,1
    2562:	18d78f63          	beq	a5,a3,2700 <stpncpy+0x1fe>
    2566:	000500a3          	sb	zero,1(a0)
    256a:	4689                	li	a3,2
    256c:	00250713          	addi	a4,a0,2
    2570:	18d78e63          	beq	a5,a3,270c <stpncpy+0x20a>
    2574:	00050123          	sb	zero,2(a0)
    2578:	468d                	li	a3,3
    257a:	00350713          	addi	a4,a0,3
    257e:	16d78c63          	beq	a5,a3,26f6 <stpncpy+0x1f4>
    2582:	000501a3          	sb	zero,3(a0)
    2586:	4691                	li	a3,4
    2588:	00450713          	addi	a4,a0,4
    258c:	18d78263          	beq	a5,a3,2710 <stpncpy+0x20e>
    2590:	00050223          	sb	zero,4(a0)
    2594:	4695                	li	a3,5
    2596:	00550713          	addi	a4,a0,5
    259a:	16d78d63          	beq	a5,a3,2714 <stpncpy+0x212>
    259e:	000502a3          	sb	zero,5(a0)
    25a2:	469d                	li	a3,7
    25a4:	00650713          	addi	a4,a0,6
    25a8:	16d79863          	bne	a5,a3,2718 <stpncpy+0x216>
    25ac:	00750713          	addi	a4,a0,7
    25b0:	00050323          	sb	zero,6(a0)
    25b4:	40f80833          	sub	a6,a6,a5
    25b8:	ff887593          	andi	a1,a6,-8
    25bc:	97aa                	add	a5,a5,a0
    25be:	95be                	add	a1,a1,a5
    25c0:	0007b023          	sd	zero,0(a5)
    25c4:	07a1                	addi	a5,a5,8
    25c6:	feb79de3          	bne	a5,a1,25c0 <stpncpy+0xbe>
    25ca:	ff887593          	andi	a1,a6,-8
    25ce:	9ead                	addw	a3,a3,a1
    25d0:	00b707b3          	add	a5,a4,a1
    25d4:	12b80863          	beq	a6,a1,2704 <stpncpy+0x202>
    25d8:	00078023          	sb	zero,0(a5)
    25dc:	0016871b          	addiw	a4,a3,1
    25e0:	0ec77863          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    25e4:	000780a3          	sb	zero,1(a5)
    25e8:	0026871b          	addiw	a4,a3,2
    25ec:	0ec77263          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    25f0:	00078123          	sb	zero,2(a5)
    25f4:	0036871b          	addiw	a4,a3,3
    25f8:	0cc77c63          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    25fc:	000781a3          	sb	zero,3(a5)
    2600:	0046871b          	addiw	a4,a3,4
    2604:	0cc77663          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2608:	00078223          	sb	zero,4(a5)
    260c:	0056871b          	addiw	a4,a3,5
    2610:	0cc77063          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2614:	000782a3          	sb	zero,5(a5)
    2618:	0066871b          	addiw	a4,a3,6
    261c:	0ac77a63          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2620:	00078323          	sb	zero,6(a5)
    2624:	0076871b          	addiw	a4,a3,7
    2628:	0ac77463          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    262c:	000783a3          	sb	zero,7(a5)
    2630:	0086871b          	addiw	a4,a3,8
    2634:	08c77e63          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2638:	00078423          	sb	zero,8(a5)
    263c:	0096871b          	addiw	a4,a3,9
    2640:	08c77863          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2644:	000784a3          	sb	zero,9(a5)
    2648:	00a6871b          	addiw	a4,a3,10
    264c:	08c77263          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2650:	00078523          	sb	zero,10(a5)
    2654:	00b6871b          	addiw	a4,a3,11
    2658:	06c77c63          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    265c:	000785a3          	sb	zero,11(a5)
    2660:	00c6871b          	addiw	a4,a3,12
    2664:	06c77663          	bgeu	a4,a2,26d0 <stpncpy+0x1ce>
    2668:	00078623          	sb	zero,12(a5)
    266c:	26b5                	addiw	a3,a3,13
    266e:	06c6f163          	bgeu	a3,a2,26d0 <stpncpy+0x1ce>
    2672:	000786a3          	sb	zero,13(a5)
    2676:	8082                	ret
			;
		if (!n || !*s)
    2678:	c645                	beqz	a2,2720 <stpncpy+0x21e>
    267a:	0005c783          	lbu	a5,0(a1)
    267e:	ea078be3          	beqz	a5,2534 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2682:	479d                	li	a5,7
    2684:	02c7ff63          	bgeu	a5,a2,26c2 <stpncpy+0x1c0>
    2688:	00000897          	auipc	a7,0x0
    268c:	6c88b883          	ld	a7,1736(a7) # 2d50 <enable_deadlock_detect+0x236>
    2690:	00000817          	auipc	a6,0x0
    2694:	6c883803          	ld	a6,1736(a6) # 2d58 <enable_deadlock_detect+0x23e>
    2698:	431d                	li	t1,7
    269a:	6198                	ld	a4,0(a1)
    269c:	011707b3          	add	a5,a4,a7
    26a0:	fff74693          	not	a3,a4
    26a4:	8ff5                	and	a5,a5,a3
    26a6:	0107f7b3          	and	a5,a5,a6
    26aa:	ef81                	bnez	a5,26c2 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    26ac:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    26ae:	1661                	addi	a2,a2,-8
    26b0:	05a1                	addi	a1,a1,8
    26b2:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    26b4:	fec363e3          	bltu	t1,a2,269a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    26b8:	e609                	bnez	a2,26c2 <stpncpy+0x1c0>
    26ba:	a08d                	j	271c <stpncpy+0x21a>
    26bc:	167d                	addi	a2,a2,-1
    26be:	0505                	addi	a0,a0,1
    26c0:	ca01                	beqz	a2,26d0 <stpncpy+0x1ce>
    26c2:	0005c783          	lbu	a5,0(a1)
    26c6:	0585                	addi	a1,a1,1
    26c8:	00f50023          	sb	a5,0(a0)
    26cc:	fbe5                	bnez	a5,26bc <stpncpy+0x1ba>
		;
tail:
    26ce:	b59d                	j	2534 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    26d0:	8082                	ret
    26d2:	472d                	li	a4,11
    26d4:	bdb5                	j	2550 <stpncpy+0x4e>
    26d6:	00778713          	addi	a4,a5,7
    26da:	45ad                	li	a1,11
    26dc:	fff60693          	addi	a3,a2,-1
    26e0:	e6b778e3          	bgeu	a4,a1,2550 <stpncpy+0x4e>
    26e4:	b7fd                	j	26d2 <stpncpy+0x1d0>
    26e6:	40a007b3          	neg	a5,a0
    26ea:	8832                	mv	a6,a2
    26ec:	8b9d                	andi	a5,a5,7
    26ee:	4681                	li	a3,0
    26f0:	e4060be3          	beqz	a2,2546 <stpncpy+0x44>
    26f4:	b7cd                	j	26d6 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    26f6:	468d                	li	a3,3
    26f8:	bd75                	j	25b4 <stpncpy+0xb2>
    26fa:	872a                	mv	a4,a0
    26fc:	4681                	li	a3,0
    26fe:	bd5d                	j	25b4 <stpncpy+0xb2>
    2700:	4685                	li	a3,1
    2702:	bd4d                	j	25b4 <stpncpy+0xb2>
    2704:	8082                	ret
    2706:	87aa                	mv	a5,a0
    2708:	4681                	li	a3,0
    270a:	b5f9                	j	25d8 <stpncpy+0xd6>
    270c:	4689                	li	a3,2
    270e:	b55d                	j	25b4 <stpncpy+0xb2>
    2710:	4691                	li	a3,4
    2712:	b54d                	j	25b4 <stpncpy+0xb2>
    2714:	4695                	li	a3,5
    2716:	bd79                	j	25b4 <stpncpy+0xb2>
    2718:	4699                	li	a3,6
    271a:	bd69                	j	25b4 <stpncpy+0xb2>
    271c:	8082                	ret
    271e:	8082                	ret
    2720:	8082                	ret

0000000000002722 <basename>:

char *basename(char *s)
{
    2722:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2724:	c54d                	beqz	a0,27ce <basename+0xac>
    2726:	00054783          	lbu	a5,0(a0)
		return ".";
    272a:	00000517          	auipc	a0,0x0
    272e:	61e50513          	addi	a0,a0,1566 # 2d48 <enable_deadlock_detect+0x22e>
	if (!s || !*s)
    2732:	e391                	bnez	a5,2736 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2734:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2736:	0076f713          	andi	a4,a3,7
    273a:	87b6                	mv	a5,a3
    273c:	cf51                	beqz	a4,27d8 <basename+0xb6>
    273e:	0785                	addi	a5,a5,1
    2740:	0077f713          	andi	a4,a5,7
    2744:	c729                	beqz	a4,278e <basename+0x6c>
		if (!*s)
    2746:	0007c703          	lbu	a4,0(a5)
    274a:	fb75                	bnez	a4,273e <basename+0x1c>
	return s - a;
    274c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    274e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2750:	cf8d                	beqz	a5,278a <basename+0x68>
    2752:	00f68733          	add	a4,a3,a5
    2756:	02f00593          	li	a1,47
    275a:	a031                	j	2766 <basename+0x44>
		s[i] = 0;
    275c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2760:	17fd                	addi	a5,a5,-1
    2762:	177d                	addi	a4,a4,-1
    2764:	c39d                	beqz	a5,278a <basename+0x68>
    2766:	00074603          	lbu	a2,0(a4)
    276a:	feb609e3          	beq	a2,a1,275c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    276e:	02f00613          	li	a2,47
    2772:	a011                	j	2776 <basename+0x54>
    2774:	cb99                	beqz	a5,278a <basename+0x68>
    2776:	853e                	mv	a0,a5
    2778:	17fd                	addi	a5,a5,-1
    277a:	00f68733          	add	a4,a3,a5
    277e:	00074703          	lbu	a4,0(a4)
    2782:	fec719e3          	bne	a4,a2,2774 <basename+0x52>
	return s + i;
    2786:	9536                	add	a0,a0,a3
    2788:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    278a:	8536                	mv	a0,a3
    278c:	8082                	ret
    278e:	6390                	ld	a2,0(a5)
    2790:	00000517          	auipc	a0,0x0
    2794:	5c053503          	ld	a0,1472(a0) # 2d50 <enable_deadlock_detect+0x236>
    2798:	00000597          	auipc	a1,0x0
    279c:	5c05b583          	ld	a1,1472(a1) # 2d58 <enable_deadlock_detect+0x23e>
    27a0:	fff64713          	not	a4,a2
    27a4:	962a                	add	a2,a2,a0
    27a6:	8f71                	and	a4,a4,a2
    27a8:	8f6d                	and	a4,a4,a1
    27aa:	eb11                	bnez	a4,27be <basename+0x9c>
    27ac:	6790                	ld	a2,8(a5)
    27ae:	07a1                	addi	a5,a5,8
    27b0:	00a60733          	add	a4,a2,a0
    27b4:	fff64613          	not	a2,a2
    27b8:	8f71                	and	a4,a4,a2
    27ba:	8f6d                	and	a4,a4,a1
    27bc:	db65                	beqz	a4,27ac <basename+0x8a>
	for (; *s; s++)
    27be:	0007c703          	lbu	a4,0(a5)
    27c2:	d749                	beqz	a4,274c <basename+0x2a>
    27c4:	0017c703          	lbu	a4,1(a5)
    27c8:	0785                	addi	a5,a5,1
    27ca:	ff6d                	bnez	a4,27c4 <basename+0xa2>
    27cc:	b741                	j	274c <basename+0x2a>
		return ".";
    27ce:	00000517          	auipc	a0,0x0
    27d2:	57a50513          	addi	a0,a0,1402 # 2d48 <enable_deadlock_detect+0x22e>
    27d6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    27d8:	6290                	ld	a2,0(a3)
    27da:	00000517          	auipc	a0,0x0
    27de:	57653503          	ld	a0,1398(a0) # 2d50 <enable_deadlock_detect+0x236>
    27e2:	00000597          	auipc	a1,0x0
    27e6:	5765b583          	ld	a1,1398(a1) # 2d58 <enable_deadlock_detect+0x23e>
    27ea:	fff64713          	not	a4,a2
    27ee:	962a                	add	a2,a2,a0
    27f0:	8f71                	and	a4,a4,a2
    27f2:	8f6d                	and	a4,a4,a1
    27f4:	df45                	beqz	a4,27ac <basename+0x8a>
    27f6:	b7f9                	j	27c4 <basename+0xa2>

00000000000027f8 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    27f8:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    27fc:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27fe:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2802:	2501                	sext.w	a0,a0
    2804:	8082                	ret

0000000000002806 <close>:

int close(int fd)
{
	if (fd == 1) {
    2806:	4785                	li	a5,1
    2808:	00f50863          	beq	a0,a5,2818 <close+0x12>
	register long a7 __asm__("a7") = n;
    280c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2810:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2814:	2501                	sext.w	a0,a0
    2816:	8082                	ret
{
    2818:	1101                	addi	sp,sp,-32
    281a:	ec06                	sd	ra,24(sp)
    281c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    281e:	cdffe0ef          	jal	ra,14fc <__write_buffer>
		__clear_buffer();
    2822:	d03fe0ef          	jal	ra,1524 <__clear_buffer>
    2826:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2828:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    282c:	00000073          	ecall
}
    2830:	60e2                	ld	ra,24(sp)
    2832:	2501                	sext.w	a0,a0
    2834:	6105                	addi	sp,sp,32
    2836:	8082                	ret

0000000000002838 <read>:
	register long a7 __asm__("a7") = n;
    2838:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    283c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2840:	8082                	ret

0000000000002842 <write>:
	register long a7 __asm__("a7") = n;
    2842:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2846:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    284a:	8082                	ret

000000000000284c <getpid>:
	register long a7 __asm__("a7") = n;
    284c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2850:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2854:	2501                	sext.w	a0,a0
    2856:	8082                	ret

0000000000002858 <getppid>:
	register long a7 __asm__("a7") = n;
    2858:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    285c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2860:	2501                	sext.w	a0,a0
    2862:	8082                	ret

0000000000002864 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2864:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2868:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    286c:	2501                	sext.w	a0,a0
    286e:	8082                	ret

0000000000002870 <fork>:
	register long a7 __asm__("a7") = n;
    2870:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2874:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2878:	2501                	sext.w	a0,a0
    287a:	8082                	ret

000000000000287c <exit>:

void exit(int code)
{
    287c:	1141                	addi	sp,sp,-16
    287e:	e406                	sd	ra,8(sp)
    2880:	e022                	sd	s0,0(sp)
    2882:	842a                	mv	s0,a0
	__write_buffer();
    2884:	c79fe0ef          	jal	ra,14fc <__write_buffer>
	__clear_buffer();
    2888:	c9dfe0ef          	jal	ra,1524 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    288c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2890:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2892:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2896:	60a2                	ld	ra,8(sp)
    2898:	6402                	ld	s0,0(sp)
    289a:	0141                	addi	sp,sp,16
    289c:	8082                	ret

000000000000289e <waitpid>:
	register long a7 __asm__("a7") = n;
    289e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28a2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    28a6:	2501                	sext.w	a0,a0
    28a8:	8082                	ret

00000000000028aa <exec>:
	register long a7 __asm__("a7") = n;
    28aa:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28ae:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    28b2:	2501                	sext.w	a0,a0
    28b4:	8082                	ret

00000000000028b6 <get_mtime>:

int64 get_mtime()
{
    28b6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    28b8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    28bc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    28be:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28c0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    28c4:	2501                	sext.w	a0,a0
    28c6:	ed01                	bnez	a0,28de <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    28c8:	6722                	ld	a4,8(sp)
    28ca:	3e800793          	li	a5,1000
    28ce:	6682                	ld	a3,0(sp)
    28d0:	02f75733          	divu	a4,a4,a5
    28d4:	02d78533          	mul	a0,a5,a3
    28d8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    28da:	0141                	addi	sp,sp,16
    28dc:	8082                	ret
	return -1;
    28de:	557d                	li	a0,-1
    28e0:	bfed                	j	28da <get_mtime+0x24>

00000000000028e2 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    28e2:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28e6:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    28ea:	2501                	sext.w	a0,a0
    28ec:	8082                	ret

00000000000028ee <sleep>:

int sleep(unsigned long long time)
{
    28ee:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    28f0:	880a                	mv	a6,sp
{
    28f2:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    28f4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    28f8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    28fa:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28fc:	00000073          	ecall
	if (err == 0) {
    2900:	2501                	sext.w	a0,a0
    2902:	ed31                	bnez	a0,295e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2904:	6722                	ld	a4,8(sp)
    2906:	3e800793          	li	a5,1000
    290a:	6682                	ld	a3,0(sp)
    290c:	02f75733          	divu	a4,a4,a5
    2910:	02d787b3          	mul	a5,a5,a3
    2914:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2916:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    291a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    291c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    291e:	00000073          	ecall
	if (err == 0) {
    2922:	2501                	sext.w	a0,a0
    2924:	e915                	bnez	a0,2958 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2926:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2928:	3e800693          	li	a3,1000
    292c:	a819                	j	2942 <sleep+0x54>
	__asm_syscall("r"(a7))
    292e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2932:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2936:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2938:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    293a:	00000073          	ecall
	if (err == 0) {
    293e:	2501                	sext.w	a0,a0
    2940:	ed01                	bnez	a0,2958 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2942:	6722                	ld	a4,8(sp)
    2944:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2946:	07c00893          	li	a7,124
    294a:	02d75733          	divu	a4,a4,a3
    294e:	02f687b3          	mul	a5,a3,a5
    2952:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2954:	fcc7ede3          	bltu	a5,a2,292e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2958:	4501                	li	a0,0
    295a:	0141                	addi	sp,sp,16
    295c:	8082                	ret
    295e:	57fd                	li	a5,-1
    2960:	bf5d                	j	2916 <sleep+0x28>

0000000000002962 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2962:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2966:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    296a:	2501                	sext.w	a0,a0
    296c:	8082                	ret

000000000000296e <set_priority>:
	register long a7 __asm__("a7") = n;
    296e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2972:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2976:	2501                	sext.w	a0,a0
    2978:	8082                	ret

000000000000297a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    297a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    297e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2982:	2501                	sext.w	a0,a0
    2984:	8082                	ret

0000000000002986 <munmap>:
	register long a7 __asm__("a7") = n;
    2986:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    298a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    298e:	2501                	sext.w	a0,a0
    2990:	8082                	ret

0000000000002992 <wait>:

int wait(int *code)
{
    2992:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2994:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2998:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    299a:	00000073          	ecall
	return waitpid(-1, code);
}
    299e:	2501                	sext.w	a0,a0
    29a0:	8082                	ret

00000000000029a2 <spawn>:
	register long a7 __asm__("a7") = n;
    29a2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    29a6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    29aa:	2501                	sext.w	a0,a0
    29ac:	8082                	ret

00000000000029ae <pipe>:
	register long a7 __asm__("a7") = n;
    29ae:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    29b2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    29b6:	2501                	sext.w	a0,a0
    29b8:	8082                	ret

00000000000029ba <mailread>:
	register long a7 __asm__("a7") = n;
    29ba:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29be:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    29c2:	2501                	sext.w	a0,a0
    29c4:	8082                	ret

00000000000029c6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    29c6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    29ca:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    29ce:	2501                	sext.w	a0,a0
    29d0:	8082                	ret

00000000000029d2 <fstat>:
	register long a7 __asm__("a7") = n;
    29d2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29d6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    29da:	2501                	sext.w	a0,a0
    29dc:	8082                	ret

00000000000029de <sys_linkat>:
	register long a4 __asm__("a4") = e;
    29de:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    29e0:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    29e4:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    29e6:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    29ea:	2501                	sext.w	a0,a0
    29ec:	8082                	ret

00000000000029ee <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    29ee:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    29f0:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    29f4:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    29f6:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    29fa:	2501                	sext.w	a0,a0
    29fc:	8082                	ret

00000000000029fe <link>:

int link(char *old_path, char *new_path)
{
    29fe:	87aa                	mv	a5,a0
    2a00:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2a02:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2a06:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2a0a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2a0c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2a10:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a12:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2a16:	2501                	sext.w	a0,a0
    2a18:	8082                	ret

0000000000002a1a <unlink>:

int unlink(char *path)
{
    2a1a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2a1c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2a20:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2a24:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a26:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2a2a:	2501                	sext.w	a0,a0
    2a2c:	8082                	ret

0000000000002a2e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2a2e:	00000797          	auipc	a5,0x0
    2a32:	4927b783          	ld	a5,1170(a5) # 2ec0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2a36:	439c                	lw	a5,0(a5)
    2a38:	c799                	beqz	a5,2a46 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2a3a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a3e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2a42:	2501                	sext.w	a0,a0
    2a44:	8082                	ret
{
    2a46:	1101                	addi	sp,sp,-32
    2a48:	ec06                	sd	ra,24(sp)
    2a4a:	e42e                	sd	a1,8(sp)
    2a4c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2a4e:	fe7fe0ef          	jal	ra,1a34 <enable_thread_io_buffer>
    2a52:	65a2                	ld	a1,8(sp)
    2a54:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2a56:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a5a:	00000073          	ecall
}
    2a5e:	60e2                	ld	ra,24(sp)
    2a60:	2501                	sext.w	a0,a0
    2a62:	6105                	addi	sp,sp,32
    2a64:	8082                	ret

0000000000002a66 <gettid>:
	register long a7 __asm__("a7") = n;
    2a66:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2a6a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2a6e:	2501                	sext.w	a0,a0
    2a70:	8082                	ret

0000000000002a72 <waittid>:

int waittid(int tid)
{
    2a72:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2a74:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2a78:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2a7c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2a7e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2a80:	00e51e63          	bne	a0,a4,2a9c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2a84:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2a88:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2a8c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2a90:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2a92:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2a96:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2a98:	fee506e3          	beq	a0,a4,2a84 <waittid+0x12>
	}
	return ret;
}
    2a9c:	8082                	ret

0000000000002a9e <mutex_create>:
	register long a7 __asm__("a7") = n;
    2a9e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2aa2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2aa4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2aa8:	2501                	sext.w	a0,a0
    2aaa:	8082                	ret

0000000000002aac <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2aac:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2ab0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2ab2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2ab6:	2501                	sext.w	a0,a0
    2ab8:	8082                	ret

0000000000002aba <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2aba:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2abe:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2ac2:	2501                	sext.w	a0,a0
    2ac4:	8082                	ret

0000000000002ac6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2ac6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2aca:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2ace:	2501                	sext.w	a0,a0
    2ad0:	8082                	ret

0000000000002ad2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2ad2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2ad6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2ada:	2501                	sext.w	a0,a0
    2adc:	8082                	ret

0000000000002ade <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2ade:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2ae2:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2ae6:	2501                	sext.w	a0,a0
    2ae8:	8082                	ret

0000000000002aea <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2aea:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2aee:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2af2:	2501                	sext.w	a0,a0
    2af4:	8082                	ret

0000000000002af6 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2af6:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2afa:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2afe:	2501                	sext.w	a0,a0
    2b00:	8082                	ret

0000000000002b02 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2b02:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2b06:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2b0a:	2501                	sext.w	a0,a0
    2b0c:	8082                	ret

0000000000002b0e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2b0e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2b12:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2b16:	2501                	sext.w	a0,a0
    2b18:	8082                	ret

0000000000002b1a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2b1a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2b1e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2b22:	2501                	sext.w	a0,a0
    2b24:	8082                	ret
