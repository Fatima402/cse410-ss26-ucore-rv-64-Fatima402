
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_panic:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0a9                	j	104a <__start_main>

0000000000001002 <main>:
#include <unistd.h>

/// 测试文件基本读写，输出　Test file0 OK! 就算正确。

int main()
{
    1002:	1141                	addi	sp,sp,-16
    1004:	e406                	sd	ra,8(sp)
    1006:	e022                	sd	s0,0(sp)
	int a = 0;
	int b = 1;
	assert_eq(a, b);
    1008:	3ce010ef          	jal	ra,23d6 <getpid>
    100c:	842a                	mv	s0,a0
    100e:	00001517          	auipc	a0,0x1
    1012:	6a250513          	addi	a0,a0,1698 # 26b0 <enable_deadlock_detect+0xc>
    1016:	296010ef          	jal	ra,22ac <basename>
    101a:	872a                	mv	a4,a0
    101c:	86a2                	mv	a3,s0
    101e:	4885                	li	a7,1
    1020:	4801                	li	a6,0
    1022:	47b5                	li	a5,13
    1024:	00001617          	auipc	a2,0x1
    1028:	6d460613          	addi	a2,a2,1748 # 26f8 <enable_deadlock_detect+0x54>
    102c:	45fd                	li	a1,31
    102e:	00001517          	auipc	a0,0x1
    1032:	6d250513          	addi	a0,a0,1746 # 2700 <enable_deadlock_detect+0x5c>
    1036:	16e000ef          	jal	ra,11a4 <printf>
    103a:	557d                	li	a0,-1
    103c:	3ca010ef          	jal	ra,2406 <exit>
	return 0;
    1040:	60a2                	ld	ra,8(sp)
    1042:	6402                	ld	s0,0(sp)
    1044:	4501                	li	a0,0
    1046:	0141                	addi	sp,sp,16
    1048:	8082                	ret

000000000000104a <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    104a:	1141                	addi	sp,sp,-16
    104c:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    104e:	fb5ff0ef          	jal	ra,1002 <main>
    1052:	3b4010ef          	jal	ra,2406 <exit>
	return 0;
    1056:	60a2                	ld	ra,8(sp)
    1058:	4501                	li	a0,0
    105a:	0141                	addi	sp,sp,16
    105c:	8082                	ret

000000000000105e <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    105e:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1060:	4605                	li	a2,1
    1062:	00f10593          	addi	a1,sp,15
    1066:	4501                	li	a0,0
{
    1068:	ec06                	sd	ra,24(sp)
	char byte = 0;
    106a:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    106e:	354010ef          	jal	ra,23c2 <read>
    1072:	4785                	li	a5,1
    1074:	00f51763          	bne	a0,a5,1082 <getchar+0x24>
		return byte;
    1078:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    107c:	60e2                	ld	ra,24(sp)
    107e:	6105                	addi	sp,sp,32
    1080:	8082                	ret
		return EOF;
    1082:	557d                	li	a0,-1
    1084:	bfe5                	j	107c <getchar+0x1e>

0000000000001086 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1086:	00001517          	auipc	a0,0x1
    108a:	7aa52503          	lw	a0,1962(a0) # 2830 <buffer_len>
    108e:	e111                	bnez	a0,1092 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1090:	8082                	ret
{
    1092:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1094:	862a                	mv	a2,a0
    1096:	00001597          	auipc	a1,0x1
    109a:	7a258593          	addi	a1,a1,1954 # 2838 <buffer>
    109e:	4505                	li	a0,1
{
    10a0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10a2:	32a010ef          	jal	ra,23cc <write>
}
    10a6:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10a8:	2501                	sext.w	a0,a0
}
    10aa:	0141                	addi	sp,sp,16
    10ac:	8082                	ret

00000000000010ae <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10ae:	00001797          	auipc	a5,0x1
    10b2:	7807a123          	sw	zero,1922(a5) # 2830 <buffer_len>
}
    10b6:	8082                	ret

00000000000010b8 <__fflush>:
	if (buffer_len == 0)
    10b8:	00001517          	auipc	a0,0x1
    10bc:	77852503          	lw	a0,1912(a0) # 2830 <buffer_len>
    10c0:	e511                	bnez	a0,10cc <__fflush+0x14>
	buffer_len = 0;
    10c2:	00001797          	auipc	a5,0x1
    10c6:	7607a723          	sw	zero,1902(a5) # 2830 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10ca:	8082                	ret
{
    10cc:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ce:	862a                	mv	a2,a0
    10d0:	00001597          	auipc	a1,0x1
    10d4:	76858593          	addi	a1,a1,1896 # 2838 <buffer>
    10d8:	4505                	li	a0,1
{
    10da:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10dc:	2f0010ef          	jal	ra,23cc <write>
	return r >= 0 ? 0 : r;
    10e0:	0005079b          	sext.w	a5,a0
}
    10e4:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10e6:	0017a793          	slti	a5,a5,1
    10ea:	40f007bb          	negw	a5,a5
    10ee:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10f0:	00001797          	auipc	a5,0x1
    10f4:	7407a023          	sw	zero,1856(a5) # 2830 <buffer_len>
	return r >= 0 ? 0 : r;
    10f8:	2501                	sext.w	a0,a0
}
    10fa:	0141                	addi	sp,sp,16
    10fc:	8082                	ret

00000000000010fe <fflush>:

int fflush(int fd)
{
    10fe:	1101                	addi	sp,sp,-32
    1100:	e822                	sd	s0,16(sp)
    1102:	ec06                	sd	ra,24(sp)
    1104:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1106:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1108:	4401                	li	s0,0
	if (fd == 1) {
    110a:	00e50863          	beq	a0,a4,111a <fflush+0x1c>
}
    110e:	60e2                	ld	ra,24(sp)
    1110:	8522                	mv	a0,s0
    1112:	6442                	ld	s0,16(sp)
    1114:	64a2                	ld	s1,8(sp)
    1116:	6105                	addi	sp,sp,32
    1118:	8082                	ret
		if (buffer_lock_enabled == 1) {
    111a:	00001497          	auipc	s1,0x1
    111e:	71648493          	addi	s1,s1,1814 # 2830 <buffer_len>
    1122:	1084a703          	lw	a4,264(s1)
    1126:	02a70e63          	beq	a4,a0,1162 <fflush+0x64>
	if (buffer_len == 0)
    112a:	4080                	lw	s0,0(s1)
    112c:	c00d                	beqz	s0,114e <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    112e:	8622                	mv	a2,s0
    1130:	00001597          	auipc	a1,0x1
    1134:	70858593          	addi	a1,a1,1800 # 2838 <buffer>
    1138:	294010ef          	jal	ra,23cc <write>
	return r >= 0 ? 0 : r;
    113c:	0005079b          	sext.w	a5,a0
    1140:	0017a793          	slti	a5,a5,1
    1144:	40f007bb          	negw	a5,a5
    1148:	8d7d                	and	a0,a0,a5
    114a:	0005041b          	sext.w	s0,a0
}
    114e:	60e2                	ld	ra,24(sp)
    1150:	8522                	mv	a0,s0
    1152:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1154:	00001797          	auipc	a5,0x1
    1158:	6c07ae23          	sw	zero,1756(a5) # 2830 <buffer_len>
}
    115c:	64a2                	ld	s1,8(sp)
    115e:	6105                	addi	sp,sp,32
    1160:	8082                	ret
			mutex_lock(buffer_lock);
    1162:	10c4a503          	lw	a0,268(s1)
    1166:	4de010ef          	jal	ra,2644 <mutex_lock>
	if (buffer_len == 0)
    116a:	4080                	lw	s0,0(s1)
    116c:	e811                	bnez	s0,1180 <fflush+0x82>
			mutex_unlock(buffer_lock);
    116e:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1172:	00001797          	auipc	a5,0x1
    1176:	6a07af23          	sw	zero,1726(a5) # 2830 <buffer_len>
			mutex_unlock(buffer_lock);
    117a:	4d6010ef          	jal	ra,2650 <mutex_unlock>
    117e:	bf41                	j	110e <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1180:	8622                	mv	a2,s0
    1182:	00001597          	auipc	a1,0x1
    1186:	6b658593          	addi	a1,a1,1718 # 2838 <buffer>
    118a:	4505                	li	a0,1
    118c:	240010ef          	jal	ra,23cc <write>
	return r >= 0 ? 0 : r;
    1190:	0005079b          	sext.w	a5,a0
    1194:	0017a793          	slti	a5,a5,1
    1198:	40f007bb          	negw	a5,a5
    119c:	8d7d                	and	a0,a0,a5
    119e:	0005041b          	sext.w	s0,a0
	return r;
    11a2:	b7f1                	j	116e <fflush+0x70>

00000000000011a4 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11a4:	7131                	addi	sp,sp,-192
    11a6:	e0da                	sd	s6,64(sp)
    11a8:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11aa:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11ac:	013c                	addi	a5,sp,136
{
    11ae:	f0ca                	sd	s2,96(sp)
    11b0:	ecce                	sd	s3,88(sp)
    11b2:	e8d2                	sd	s4,80(sp)
    11b4:	e4d6                	sd	s5,72(sp)
    11b6:	fc86                	sd	ra,120(sp)
    11b8:	f8a2                	sd	s0,112(sp)
    11ba:	f4a6                	sd	s1,104(sp)
    11bc:	89aa                	mv	s3,a0
    11be:	e52e                	sd	a1,136(sp)
    11c0:	e932                	sd	a2,144(sp)
    11c2:	ed36                	sd	a3,152(sp)
    11c4:	f13a                	sd	a4,160(sp)
    11c6:	f942                	sd	a6,176(sp)
    11c8:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11ca:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11cc:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11d0:	00001a17          	auipc	s4,0x1
    11d4:	660a0a13          	addi	s4,s4,1632 # 2830 <buffer_len>
    11d8:	4a85                	li	s5,1
	buf[i++] = '0';
    11da:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11de:	0009c783          	lbu	a5,0(s3)
    11e2:	18078663          	beqz	a5,136e <printf+0x1ca>
    11e6:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11e8:	19278d63          	beq	a5,s2,1382 <printf+0x1de>
    11ec:	0015c783          	lbu	a5,1(a1)
    11f0:	0585                	addi	a1,a1,1
    11f2:	fbfd                	bnez	a5,11e8 <printf+0x44>
    11f4:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11f6:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    11fa:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    11fe:	1b578863          	beq	a5,s5,13ae <printf+0x20a>
		len = out_unlocked(s, l);
    1202:	85a2                	mv	a1,s0
    1204:	854e                	mv	a0,s3
    1206:	42a000ef          	jal	ra,1630 <out_unlocked>
		out(f, a, l);
		if (l)
    120a:	1c041063          	bnez	s0,13ca <printf+0x226>
			continue;
		if (s[1] == 0)
    120e:	0014c783          	lbu	a5,1(s1)
    1212:	14078e63          	beqz	a5,136e <printf+0x1ca>
			break;
		switch (s[1]) {
    1216:	07300713          	li	a4,115
    121a:	1ce78863          	beq	a5,a4,13ea <printf+0x246>
    121e:	1af76863          	bltu	a4,a5,13ce <printf+0x22a>
    1222:	06400713          	li	a4,100
    1226:	22e78063          	beq	a5,a4,1446 <printf+0x2a2>
    122a:	07000713          	li	a4,112
    122e:	1ee79563          	bne	a5,a4,1418 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1232:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1234:	00001797          	auipc	a5,0x1
    1238:	70c78793          	addi	a5,a5,1804 # 2940 <digits>
	buf[i++] = '0';
    123c:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1240:	6298                	ld	a4,0(a3)
    1242:	06a1                	addi	a3,a3,8
    1244:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1246:	00471393          	slli	t2,a4,0x4
    124a:	00871293          	slli	t0,a4,0x8
    124e:	00c71f93          	slli	t6,a4,0xc
    1252:	01071f13          	slli	t5,a4,0x10
    1256:	01471e93          	slli	t4,a4,0x14
    125a:	01871e13          	slli	t3,a4,0x18
    125e:	01c71893          	slli	a7,a4,0x1c
    1262:	02471813          	slli	a6,a4,0x24
    1266:	02871513          	slli	a0,a4,0x28
    126a:	02c71593          	slli	a1,a4,0x2c
    126e:	03071613          	slli	a2,a4,0x30
    1272:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1276:	03c75413          	srli	s0,a4,0x3c
    127a:	01c7531b          	srliw	t1,a4,0x1c
    127e:	03c3d393          	srli	t2,t2,0x3c
    1282:	03c2d293          	srli	t0,t0,0x3c
    1286:	03cfdf93          	srli	t6,t6,0x3c
    128a:	03cf5f13          	srli	t5,t5,0x3c
    128e:	03cede93          	srli	t4,t4,0x3c
    1292:	03ce5e13          	srli	t3,t3,0x3c
    1296:	03c8d893          	srli	a7,a7,0x3c
    129a:	03c85813          	srli	a6,a6,0x3c
    129e:	9171                	srli	a0,a0,0x3c
    12a0:	91f1                	srli	a1,a1,0x3c
    12a2:	9271                	srli	a2,a2,0x3c
    12a4:	92f1                	srli	a3,a3,0x3c
    12a6:	95be                	add	a1,a1,a5
    12a8:	963e                	add	a2,a2,a5
    12aa:	96be                	add	a3,a3,a5
    12ac:	943e                	add	s0,s0,a5
    12ae:	93be                	add	t2,t2,a5
    12b0:	92be                	add	t0,t0,a5
    12b2:	9fbe                	add	t6,t6,a5
    12b4:	9f3e                	add	t5,t5,a5
    12b6:	9ebe                	add	t4,t4,a5
    12b8:	9e3e                	add	t3,t3,a5
    12ba:	98be                	add	a7,a7,a5
    12bc:	933e                	add	t1,t1,a5
    12be:	983e                	add	a6,a6,a5
    12c0:	953e                	add	a0,a0,a5
    12c2:	0005c983          	lbu	s3,0(a1)
    12c6:	00044403          	lbu	s0,0(s0)
    12ca:	00064583          	lbu	a1,0(a2)
    12ce:	0003c383          	lbu	t2,0(t2)
    12d2:	0006c603          	lbu	a2,0(a3)
    12d6:	0002c283          	lbu	t0,0(t0)
    12da:	000fcf83          	lbu	t6,0(t6)
    12de:	000f4f03          	lbu	t5,0(t5)
    12e2:	000ece83          	lbu	t4,0(t4)
    12e6:	000e4e03          	lbu	t3,0(t3)
    12ea:	0008c883          	lbu	a7,0(a7)
    12ee:	00034303          	lbu	t1,0(t1)
    12f2:	00084803          	lbu	a6,0(a6)
    12f6:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12fa:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12fe:	92f1                	srli	a3,a3,0x3c
    1300:	8b3d                	andi	a4,a4,15
    1302:	96be                	add	a3,a3,a5
    1304:	97ba                	add	a5,a5,a4
    1306:	00810d23          	sb	s0,26(sp)
    130a:	00710da3          	sb	t2,27(sp)
    130e:	00510e23          	sb	t0,28(sp)
    1312:	01f10ea3          	sb	t6,29(sp)
    1316:	01e10f23          	sb	t5,30(sp)
    131a:	01d10fa3          	sb	t4,31(sp)
    131e:	03c10023          	sb	t3,32(sp)
    1322:	031100a3          	sb	a7,33(sp)
    1326:	02610123          	sb	t1,34(sp)
    132a:	030101a3          	sb	a6,35(sp)
    132e:	02a10223          	sb	a0,36(sp)
    1332:	033102a3          	sb	s3,37(sp)
    1336:	02b10323          	sb	a1,38(sp)
    133a:	02c103a3          	sb	a2,39(sp)
    133e:	0006c683          	lbu	a3,0(a3)
    1342:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1346:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    134a:	02d10423          	sb	a3,40(sp)
    134e:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1352:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1356:	11578263          	beq	a5,s5,145a <printf+0x2b6>
		len = out_unlocked(s, l);
    135a:	45c9                	li	a1,18
    135c:	0828                	addi	a0,sp,24
    135e:	2d2000ef          	jal	ra,1630 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1362:	00248993          	addi	s3,s1,2
		if (!*s)
    1366:	0009c783          	lbu	a5,0(s3)
    136a:	e6079ee3          	bnez	a5,11e6 <printf+0x42>
	}
	va_end(ap);
    136e:	70e6                	ld	ra,120(sp)
    1370:	7446                	ld	s0,112(sp)
    1372:	74a6                	ld	s1,104(sp)
    1374:	7906                	ld	s2,96(sp)
    1376:	69e6                	ld	s3,88(sp)
    1378:	6a46                	ld	s4,80(sp)
    137a:	6aa6                	ld	s5,72(sp)
    137c:	6b06                	ld	s6,64(sp)
    137e:	6129                	addi	sp,sp,192
    1380:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1382:	0005c783          	lbu	a5,0(a1)
    1386:	84ae                	mv	s1,a1
    1388:	01278963          	beq	a5,s2,139a <printf+0x1f6>
    138c:	b5ad                	j	11f6 <printf+0x52>
    138e:	0024c783          	lbu	a5,2(s1)
    1392:	0585                	addi	a1,a1,1
    1394:	0489                	addi	s1,s1,2
    1396:	e72790e3          	bne	a5,s2,11f6 <printf+0x52>
    139a:	0014c783          	lbu	a5,1(s1)
    139e:	ff2788e3          	beq	a5,s2,138e <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13a2:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13a6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13aa:	e5579ce3          	bne	a5,s5,1202 <printf+0x5e>
		mutex_lock(buffer_lock);
    13ae:	10ca2503          	lw	a0,268(s4)
    13b2:	292010ef          	jal	ra,2644 <mutex_lock>
		len = out_unlocked(s, l);
    13b6:	85a2                	mv	a1,s0
    13b8:	854e                	mv	a0,s3
    13ba:	276000ef          	jal	ra,1630 <out_unlocked>
		mutex_unlock(buffer_lock);
    13be:	10ca2503          	lw	a0,268(s4)
    13c2:	28e010ef          	jal	ra,2650 <mutex_unlock>
		if (l)
    13c6:	e40404e3          	beqz	s0,120e <printf+0x6a>
    13ca:	89a6                	mv	s3,s1
    13cc:	bd09                	j	11de <printf+0x3a>
		switch (s[1]) {
    13ce:	07800713          	li	a4,120
    13d2:	04e79363          	bne	a5,a4,1418 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13d6:	67c2                	ld	a5,16(sp)
    13d8:	45c1                	li	a1,16
		s += 2;
    13da:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13de:	4388                	lw	a0,0(a5)
    13e0:	07a1                	addi	a5,a5,8
    13e2:	e83e                	sd	a5,16(sp)
    13e4:	5f8000ef          	jal	ra,19dc <printint.constprop.0>
		s += 2;
    13e8:	bfbd                	j	1366 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13ea:	67c2                	ld	a5,16(sp)
    13ec:	6380                	ld	s0,0(a5)
    13ee:	07a1                	addi	a5,a5,8
    13f0:	e83e                	sd	a5,16(sp)
    13f2:	1c040163          	beqz	s0,15b4 <printf+0x410>
			l = strnlen(a, 200);
    13f6:	0c800593          	li	a1,200
    13fa:	8522                	mv	a0,s0
    13fc:	3f7000ef          	jal	ra,1ff2 <strnlen>
	if (buffer_lock_enabled == 1) {
    1400:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1404:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1408:	19578663          	beq	a5,s5,1594 <printf+0x3f0>
		len = out_unlocked(s, l);
    140c:	8522                	mv	a0,s0
    140e:	222000ef          	jal	ra,1630 <out_unlocked>
		s += 2;
    1412:	00248993          	addi	s3,s1,2
    1416:	bf81                	j	1366 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1418:	108a2783          	lw	a5,264(s4)
	char byte = c;
    141c:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1420:	0f578663          	beq	a5,s5,150c <printf+0x368>
		len = out_unlocked(s, l);
    1424:	0828                	addi	a0,sp,24
    1426:	316000ef          	jal	ra,173c <out_unlocked.constprop.0>
			putchar(s[1]);
    142a:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    142e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1432:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1436:	05578163          	beq	a5,s5,1478 <printf+0x2d4>
		len = out_unlocked(s, l);
    143a:	0828                	addi	a0,sp,24
    143c:	300000ef          	jal	ra,173c <out_unlocked.constprop.0>
		s += 2;
    1440:	00248993          	addi	s3,s1,2
    1444:	b70d                	j	1366 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1446:	67c2                	ld	a5,16(sp)
    1448:	45a9                	li	a1,10
		s += 2;
    144a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    144e:	4388                	lw	a0,0(a5)
    1450:	07a1                	addi	a5,a5,8
    1452:	e83e                	sd	a5,16(sp)
    1454:	588000ef          	jal	ra,19dc <printint.constprop.0>
		s += 2;
    1458:	b739                	j	1366 <printf+0x1c2>
		mutex_lock(buffer_lock);
    145a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    145e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1462:	1e2010ef          	jal	ra,2644 <mutex_lock>
		len = out_unlocked(s, l);
    1466:	45c9                	li	a1,18
    1468:	0828                	addi	a0,sp,24
    146a:	1c6000ef          	jal	ra,1630 <out_unlocked>
		mutex_unlock(buffer_lock);
    146e:	10ca2503          	lw	a0,268(s4)
    1472:	1de010ef          	jal	ra,2650 <mutex_unlock>
		s += 2;
    1476:	bdc5                	j	1366 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1478:	10ca2503          	lw	a0,268(s4)
    147c:	1c8010ef          	jal	ra,2644 <mutex_lock>
		buffer[buffer_len++] = c;
    1480:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1484:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1488:	0017861b          	addiw	a2,a5,1
    148c:	97d2                	add	a5,a5,s4
    148e:	00ca2023          	sw	a2,0(s4)
    1492:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1496:	00c6cc63          	blt	a3,a2,14ae <printf+0x30a>
    149a:	47a9                	li	a5,10
    149c:	06f40663          	beq	s0,a5,1508 <printf+0x364>
		mutex_unlock(buffer_lock);
    14a0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14a4:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14a8:	1a8010ef          	jal	ra,2650 <mutex_unlock>
		s += 2;
    14ac:	bd6d                	j	1366 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14ae:	10000793          	li	a5,256
    14b2:	00f61e63          	bne	a2,a5,14ce <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14b6:	00001597          	auipc	a1,0x1
    14ba:	38258593          	addi	a1,a1,898 # 2838 <buffer>
    14be:	4505                	li	a0,1
    14c0:	70d000ef          	jal	ra,23cc <write>
	buffer_len = 0;
    14c4:	00001797          	auipc	a5,0x1
    14c8:	3607a623          	sw	zero,876(a5) # 2830 <buffer_len>
			if (r < 0) {
    14cc:	bfd1                	j	14a0 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14ce:	709000ef          	jal	ra,23d6 <getpid>
    14d2:	842a                	mv	s0,a0
    14d4:	00001517          	auipc	a0,0x1
    14d8:	26c50513          	addi	a0,a0,620 # 2740 <enable_deadlock_detect+0x9c>
    14dc:	5d1000ef          	jal	ra,22ac <basename>
    14e0:	872a                	mv	a4,a0
    14e2:	00001617          	auipc	a2,0x1
    14e6:	21660613          	addi	a2,a2,534 # 26f8 <enable_deadlock_detect+0x54>
    14ea:	05400793          	li	a5,84
    14ee:	86a2                	mv	a3,s0
    14f0:	45fd                	li	a1,31
    14f2:	00001517          	auipc	a0,0x1
    14f6:	28e50513          	addi	a0,a0,654 # 2780 <enable_deadlock_detect+0xdc>
    14fa:	cabff0ef          	jal	ra,11a4 <printf>
    14fe:	557d                	li	a0,-1
    1500:	707000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    1504:	000a2603          	lw	a2,0(s4)
    1508:	de41                	beqz	a2,14a0 <printf+0x2fc>
    150a:	b775                	j	14b6 <printf+0x312>
		mutex_lock(buffer_lock);
    150c:	10ca2503          	lw	a0,268(s4)
    1510:	134010ef          	jal	ra,2644 <mutex_lock>
		buffer[buffer_len++] = c;
    1514:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1518:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    151c:	0017861b          	addiw	a2,a5,1
    1520:	97d2                	add	a5,a5,s4
    1522:	00ca2023          	sw	a2,0(s4)
    1526:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    152a:	02c6d163          	bge	a3,a2,154c <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    152e:	10000793          	li	a5,256
    1532:	02f61263          	bne	a2,a5,1556 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1536:	00001597          	auipc	a1,0x1
    153a:	30258593          	addi	a1,a1,770 # 2838 <buffer>
    153e:	4505                	li	a0,1
    1540:	68d000ef          	jal	ra,23cc <write>
	buffer_len = 0;
    1544:	00001797          	auipc	a5,0x1
    1548:	2e07a623          	sw	zero,748(a5) # 2830 <buffer_len>
		mutex_unlock(buffer_lock);
    154c:	10ca2503          	lw	a0,268(s4)
    1550:	100010ef          	jal	ra,2650 <mutex_unlock>
    1554:	bdd9                	j	142a <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1556:	681000ef          	jal	ra,23d6 <getpid>
    155a:	842a                	mv	s0,a0
    155c:	00001517          	auipc	a0,0x1
    1560:	1e450513          	addi	a0,a0,484 # 2740 <enable_deadlock_detect+0x9c>
    1564:	549000ef          	jal	ra,22ac <basename>
    1568:	872a                	mv	a4,a0
    156a:	00001617          	auipc	a2,0x1
    156e:	18e60613          	addi	a2,a2,398 # 26f8 <enable_deadlock_detect+0x54>
    1572:	05400793          	li	a5,84
    1576:	86a2                	mv	a3,s0
    1578:	45fd                	li	a1,31
    157a:	00001517          	auipc	a0,0x1
    157e:	20650513          	addi	a0,a0,518 # 2780 <enable_deadlock_detect+0xdc>
    1582:	c23ff0ef          	jal	ra,11a4 <printf>
    1586:	557d                	li	a0,-1
    1588:	67f000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    158c:	000a2603          	lw	a2,0(s4)
    1590:	de55                	beqz	a2,154c <printf+0x3a8>
    1592:	b755                	j	1536 <printf+0x392>
		mutex_lock(buffer_lock);
    1594:	10ca2503          	lw	a0,268(s4)
    1598:	e42e                	sd	a1,8(sp)
		s += 2;
    159a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    159e:	0a6010ef          	jal	ra,2644 <mutex_lock>
		len = out_unlocked(s, l);
    15a2:	65a2                	ld	a1,8(sp)
    15a4:	8522                	mv	a0,s0
    15a6:	08a000ef          	jal	ra,1630 <out_unlocked>
		mutex_unlock(buffer_lock);
    15aa:	10ca2503          	lw	a0,268(s4)
    15ae:	0a2010ef          	jal	ra,2650 <mutex_unlock>
		s += 2;
    15b2:	bb55                	j	1366 <printf+0x1c2>
				a = "(null)";
    15b4:	00001417          	auipc	s0,0x1
    15b8:	18440413          	addi	s0,s0,388 # 2738 <enable_deadlock_detect+0x94>
    15bc:	bd2d                	j	13f6 <printf+0x252>

00000000000015be <enable_thread_io_buffer>:
{
    15be:	1101                	addi	sp,sp,-32
    15c0:	e822                	sd	s0,16(sp)
    15c2:	ec06                	sd	ra,24(sp)
    15c4:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15c6:	00001417          	auipc	s0,0x1
    15ca:	26a40413          	addi	s0,s0,618 # 2830 <buffer_len>
    15ce:	05a010ef          	jal	ra,2628 <mutex_create>
    15d2:	10a42623          	sw	a0,268(s0)
    15d6:	00054a63          	bltz	a0,15ea <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15da:	4785                	li	a5,1
}
    15dc:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15de:	10f42423          	sw	a5,264(s0)
}
    15e2:	6442                	ld	s0,16(sp)
    15e4:	64a2                	ld	s1,8(sp)
    15e6:	6105                	addi	sp,sp,32
    15e8:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15ea:	5ed000ef          	jal	ra,23d6 <getpid>
    15ee:	84aa                	mv	s1,a0
    15f0:	00001517          	auipc	a0,0x1
    15f4:	15050513          	addi	a0,a0,336 # 2740 <enable_deadlock_detect+0x9c>
    15f8:	4b5000ef          	jal	ra,22ac <basename>
    15fc:	872a                	mv	a4,a0
    15fe:	04800793          	li	a5,72
    1602:	86a6                	mv	a3,s1
    1604:	00001517          	auipc	a0,0x1
    1608:	1bc50513          	addi	a0,a0,444 # 27c0 <enable_deadlock_detect+0x11c>
    160c:	00001617          	auipc	a2,0x1
    1610:	0ec60613          	addi	a2,a2,236 # 26f8 <enable_deadlock_detect+0x54>
    1614:	45fd                	li	a1,31
    1616:	b8fff0ef          	jal	ra,11a4 <printf>
    161a:	557d                	li	a0,-1
    161c:	5eb000ef          	jal	ra,2406 <exit>
	buffer_lock_enabled = 1;
    1620:	4785                	li	a5,1
}
    1622:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1624:	10f42423          	sw	a5,264(s0)
}
    1628:	6442                	ld	s0,16(sp)
    162a:	64a2                	ld	s1,8(sp)
    162c:	6105                	addi	sp,sp,32
    162e:	8082                	ret

0000000000001630 <out_unlocked>:
{
    1630:	7159                	addi	sp,sp,-112
    1632:	f486                	sd	ra,104(sp)
    1634:	f0a2                	sd	s0,96(sp)
    1636:	eca6                	sd	s1,88(sp)
    1638:	e8ca                	sd	s2,80(sp)
    163a:	e4ce                	sd	s3,72(sp)
    163c:	e0d2                	sd	s4,64(sp)
    163e:	fc56                	sd	s5,56(sp)
    1640:	f85a                	sd	s6,48(sp)
    1642:	f45e                	sd	s7,40(sp)
    1644:	f062                	sd	s8,32(sp)
    1646:	ec66                	sd	s9,24(sp)
    1648:	e86a                	sd	s10,16(sp)
    164a:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    164c:	0e058663          	beqz	a1,1738 <out_unlocked+0x108>
    1650:	842a                	mv	s0,a0
    1652:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1656:	4981                	li	s3,0
    1658:	00001d17          	auipc	s10,0x1
    165c:	1d8d0d13          	addi	s10,s10,472 # 2830 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1660:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1664:	00001b17          	auipc	s6,0x1
    1668:	1d4b0b13          	addi	s6,s6,468 # 2838 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    166c:	10000a93          	li	s5,256
    1670:	00001c97          	auipc	s9,0x1
    1674:	0d0c8c93          	addi	s9,s9,208 # 2740 <enable_deadlock_detect+0x9c>
    1678:	00001c17          	auipc	s8,0x1
    167c:	080c0c13          	addi	s8,s8,128 # 26f8 <enable_deadlock_detect+0x54>
    1680:	00001b97          	auipc	s7,0x1
    1684:	100b8b93          	addi	s7,s7,256 # 2780 <enable_deadlock_detect+0xdc>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1688:	4a29                	li	s4,10
    168a:	a031                	j	1696 <out_unlocked+0x66>
    168c:	09468863          	beq	a3,s4,171c <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1690:	0405                	addi	s0,s0,1
    1692:	04848163          	beq	s1,s0,16d4 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1696:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    169a:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    169e:	0017861b          	addiw	a2,a5,1
    16a2:	97ea                	add	a5,a5,s10
    16a4:	00cd2023          	sw	a2,0(s10)
    16a8:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ac:	fec950e3          	bge	s2,a2,168c <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16b0:	05561263          	bne	a2,s5,16f4 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16b4:	85da                	mv	a1,s6
    16b6:	4505                	li	a0,1
    16b8:	515000ef          	jal	ra,23cc <write>
    16bc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16be:	00001797          	auipc	a5,0x1
    16c2:	1607a923          	sw	zero,370(a5) # 2830 <buffer_len>
			if (r < 0) {
    16c6:	06054763          	bltz	a0,1734 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16ca:	0405                	addi	s0,s0,1
			ret += r;
    16cc:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16d0:	fc8493e3          	bne	s1,s0,1696 <out_unlocked+0x66>
}
    16d4:	70a6                	ld	ra,104(sp)
    16d6:	7406                	ld	s0,96(sp)
    16d8:	64e6                	ld	s1,88(sp)
    16da:	6946                	ld	s2,80(sp)
    16dc:	6a06                	ld	s4,64(sp)
    16de:	7ae2                	ld	s5,56(sp)
    16e0:	7b42                	ld	s6,48(sp)
    16e2:	7ba2                	ld	s7,40(sp)
    16e4:	7c02                	ld	s8,32(sp)
    16e6:	6ce2                	ld	s9,24(sp)
    16e8:	6d42                	ld	s10,16(sp)
    16ea:	6da2                	ld	s11,8(sp)
    16ec:	854e                	mv	a0,s3
    16ee:	69a6                	ld	s3,72(sp)
    16f0:	6165                	addi	sp,sp,112
    16f2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16f4:	4e3000ef          	jal	ra,23d6 <getpid>
    16f8:	8daa                	mv	s11,a0
    16fa:	8566                	mv	a0,s9
    16fc:	3b1000ef          	jal	ra,22ac <basename>
    1700:	872a                	mv	a4,a0
    1702:	8662                	mv	a2,s8
    1704:	05400793          	li	a5,84
    1708:	86ee                	mv	a3,s11
    170a:	45fd                	li	a1,31
    170c:	855e                	mv	a0,s7
    170e:	a97ff0ef          	jal	ra,11a4 <printf>
    1712:	557d                	li	a0,-1
    1714:	4f3000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    1718:	000d2603          	lw	a2,0(s10)
    171c:	da35                	beqz	a2,1690 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    171e:	85da                	mv	a1,s6
    1720:	4505                	li	a0,1
    1722:	4ab000ef          	jal	ra,23cc <write>
    1726:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1728:	00001797          	auipc	a5,0x1
    172c:	1007a423          	sw	zero,264(a5) # 2830 <buffer_len>
			if (r < 0) {
    1730:	f8055de3          	bgez	a0,16ca <out_unlocked+0x9a>
    1734:	89aa                	mv	s3,a0
    1736:	bf79                	j	16d4 <out_unlocked+0xa4>
	int ret = 0;
    1738:	4981                	li	s3,0
    173a:	bf69                	j	16d4 <out_unlocked+0xa4>

000000000000173c <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    173c:	1101                	addi	sp,sp,-32
    173e:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1740:	00001497          	auipc	s1,0x1
    1744:	0f048493          	addi	s1,s1,240 # 2830 <buffer_len>
    1748:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    174a:	ec06                	sd	ra,24(sp)
    174c:	e822                	sd	s0,16(sp)
		char c = s[i];
    174e:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1752:	0017861b          	addiw	a2,a5,1
    1756:	97a6                	add	a5,a5,s1
    1758:	00e78423          	sb	a4,8(a5)
    175c:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    175e:	0ff00793          	li	a5,255
    1762:	00c7cc63          	blt	a5,a2,177a <out_unlocked.constprop.0+0x3e>
    1766:	47a9                	li	a5,10
    1768:	06f70c63          	beq	a4,a5,17e0 <out_unlocked.constprop.0+0xa4>
    176c:	4601                	li	a2,0
}
    176e:	60e2                	ld	ra,24(sp)
    1770:	6442                	ld	s0,16(sp)
    1772:	64a2                	ld	s1,8(sp)
    1774:	8532                	mv	a0,a2
    1776:	6105                	addi	sp,sp,32
    1778:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    177a:	10000793          	li	a5,256
    177e:	02f61563          	bne	a2,a5,17a8 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1782:	00001597          	auipc	a1,0x1
    1786:	0b658593          	addi	a1,a1,182 # 2838 <buffer>
    178a:	4505                	li	a0,1
    178c:	441000ef          	jal	ra,23cc <write>
}
    1790:	60e2                	ld	ra,24(sp)
    1792:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1794:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1798:	00001797          	auipc	a5,0x1
    179c:	0807ac23          	sw	zero,152(a5) # 2830 <buffer_len>
}
    17a0:	64a2                	ld	s1,8(sp)
    17a2:	8532                	mv	a0,a2
    17a4:	6105                	addi	sp,sp,32
    17a6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17a8:	42f000ef          	jal	ra,23d6 <getpid>
    17ac:	842a                	mv	s0,a0
    17ae:	00001517          	auipc	a0,0x1
    17b2:	f9250513          	addi	a0,a0,-110 # 2740 <enable_deadlock_detect+0x9c>
    17b6:	2f7000ef          	jal	ra,22ac <basename>
    17ba:	872a                	mv	a4,a0
    17bc:	00001617          	auipc	a2,0x1
    17c0:	f3c60613          	addi	a2,a2,-196 # 26f8 <enable_deadlock_detect+0x54>
    17c4:	05400793          	li	a5,84
    17c8:	86a2                	mv	a3,s0
    17ca:	45fd                	li	a1,31
    17cc:	00001517          	auipc	a0,0x1
    17d0:	fb450513          	addi	a0,a0,-76 # 2780 <enable_deadlock_detect+0xdc>
    17d4:	9d1ff0ef          	jal	ra,11a4 <printf>
    17d8:	557d                	li	a0,-1
    17da:	42d000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    17de:	4090                	lw	a2,0(s1)
    17e0:	d659                	beqz	a2,176e <out_unlocked.constprop.0+0x32>
    17e2:	b745                	j	1782 <out_unlocked.constprop.0+0x46>

00000000000017e4 <putchar>:
{
    17e4:	7139                	addi	sp,sp,-64
    17e6:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17e8:	00001497          	auipc	s1,0x1
    17ec:	04848493          	addi	s1,s1,72 # 2830 <buffer_len>
    17f0:	1084a703          	lw	a4,264(s1)
{
    17f4:	f822                	sd	s0,48(sp)
	char byte = c;
    17f6:	0ff57413          	zext.b	s0,a0
{
    17fa:	fc06                	sd	ra,56(sp)
	char byte = c;
    17fc:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1800:	4785                	li	a5,1
    1802:	00f70d63          	beq	a4,a5,181c <putchar+0x38>
		len = out_unlocked(s, l);
    1806:	01f10513          	addi	a0,sp,31
    180a:	f33ff0ef          	jal	ra,173c <out_unlocked.constprop.0>
}
    180e:	70e2                	ld	ra,56(sp)
    1810:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1812:	862a                	mv	a2,a0
}
    1814:	74a2                	ld	s1,40(sp)
    1816:	8532                	mv	a0,a2
    1818:	6121                	addi	sp,sp,64
    181a:	8082                	ret
		mutex_lock(buffer_lock);
    181c:	10c4a503          	lw	a0,268(s1)
    1820:	625000ef          	jal	ra,2644 <mutex_lock>
		buffer[buffer_len++] = c;
    1824:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1826:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    182a:	0017861b          	addiw	a2,a5,1
    182e:	97a6                	add	a5,a5,s1
    1830:	c090                	sw	a2,0(s1)
    1832:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1836:	02c6c263          	blt	a3,a2,185a <putchar+0x76>
    183a:	47a9                	li	a5,10
    183c:	06f40d63          	beq	s0,a5,18b6 <putchar+0xd2>
    1840:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1842:	10c4a503          	lw	a0,268(s1)
    1846:	e432                	sd	a2,8(sp)
    1848:	609000ef          	jal	ra,2650 <mutex_unlock>
    184c:	6622                	ld	a2,8(sp)
}
    184e:	70e2                	ld	ra,56(sp)
    1850:	7442                	ld	s0,48(sp)
    1852:	74a2                	ld	s1,40(sp)
    1854:	8532                	mv	a0,a2
    1856:	6121                	addi	sp,sp,64
    1858:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    185a:	10000793          	li	a5,256
    185e:	02f61063          	bne	a2,a5,187e <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1862:	00001597          	auipc	a1,0x1
    1866:	fd658593          	addi	a1,a1,-42 # 2838 <buffer>
    186a:	4505                	li	a0,1
    186c:	361000ef          	jal	ra,23cc <write>
    1870:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1874:	00001797          	auipc	a5,0x1
    1878:	fa07ae23          	sw	zero,-68(a5) # 2830 <buffer_len>
			if (r < 0) {
    187c:	b7d9                	j	1842 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    187e:	359000ef          	jal	ra,23d6 <getpid>
    1882:	842a                	mv	s0,a0
    1884:	00001517          	auipc	a0,0x1
    1888:	ebc50513          	addi	a0,a0,-324 # 2740 <enable_deadlock_detect+0x9c>
    188c:	221000ef          	jal	ra,22ac <basename>
    1890:	872a                	mv	a4,a0
    1892:	00001617          	auipc	a2,0x1
    1896:	e6660613          	addi	a2,a2,-410 # 26f8 <enable_deadlock_detect+0x54>
    189a:	05400793          	li	a5,84
    189e:	86a2                	mv	a3,s0
    18a0:	45fd                	li	a1,31
    18a2:	00001517          	auipc	a0,0x1
    18a6:	ede50513          	addi	a0,a0,-290 # 2780 <enable_deadlock_detect+0xdc>
    18aa:	8fbff0ef          	jal	ra,11a4 <printf>
    18ae:	557d                	li	a0,-1
    18b0:	357000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    18b4:	4090                	lw	a2,0(s1)
    18b6:	d651                	beqz	a2,1842 <putchar+0x5e>
    18b8:	b76d                	j	1862 <putchar+0x7e>

00000000000018ba <puts>:
{
    18ba:	7139                	addi	sp,sp,-64
    18bc:	f822                	sd	s0,48(sp)
    18be:	f426                	sd	s1,40(sp)
    18c0:	fc06                	sd	ra,56(sp)
    18c2:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18c4:	00001417          	auipc	s0,0x1
    18c8:	f6c40413          	addi	s0,s0,-148 # 2830 <buffer_len>
{
    18cc:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ce:	638000ef          	jal	ra,1f06 <strlen>
	if (buffer_lock_enabled == 1) {
    18d2:	10842703          	lw	a4,264(s0)
    18d6:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18d8:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18da:	04f70563          	beq	a4,a5,1924 <puts+0x6a>
		len = out_unlocked(s, l);
    18de:	8526                	mv	a0,s1
    18e0:	d51ff0ef          	jal	ra,1630 <out_unlocked>
    18e4:	892a                	mv	s2,a0
    18e6:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18e8:	00095963          	bgez	s2,18fa <puts+0x40>
}
    18ec:	70e2                	ld	ra,56(sp)
    18ee:	7442                	ld	s0,48(sp)
    18f0:	7902                	ld	s2,32(sp)
    18f2:	8526                	mv	a0,s1
    18f4:	74a2                	ld	s1,40(sp)
    18f6:	6121                	addi	sp,sp,64
    18f8:	8082                	ret
	if (buffer_lock_enabled == 1) {
    18fa:	10842703          	lw	a4,264(s0)
	char byte = c;
    18fe:	44a9                	li	s1,10
    1900:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1904:	4785                	li	a5,1
    1906:	02f70e63          	beq	a4,a5,1942 <puts+0x88>
		len = out_unlocked(s, l);
    190a:	01f10513          	addi	a0,sp,31
    190e:	e2fff0ef          	jal	ra,173c <out_unlocked.constprop.0>
}
    1912:	70e2                	ld	ra,56(sp)
    1914:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1916:	41f5549b          	sraiw	s1,a0,0x1f
}
    191a:	7902                	ld	s2,32(sp)
    191c:	8526                	mv	a0,s1
    191e:	74a2                	ld	s1,40(sp)
    1920:	6121                	addi	sp,sp,64
    1922:	8082                	ret
		mutex_lock(buffer_lock);
    1924:	e42a                	sd	a0,8(sp)
    1926:	10c42503          	lw	a0,268(s0)
    192a:	51b000ef          	jal	ra,2644 <mutex_lock>
		len = out_unlocked(s, l);
    192e:	65a2                	ld	a1,8(sp)
    1930:	8526                	mv	a0,s1
    1932:	cffff0ef          	jal	ra,1630 <out_unlocked>
    1936:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1938:	10c42503          	lw	a0,268(s0)
    193c:	515000ef          	jal	ra,2650 <mutex_unlock>
    1940:	b75d                	j	18e6 <puts+0x2c>
		mutex_lock(buffer_lock);
    1942:	10c42503          	lw	a0,268(s0)
    1946:	4ff000ef          	jal	ra,2644 <mutex_lock>
		buffer[buffer_len++] = c;
    194a:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    194c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1950:	0017861b          	addiw	a2,a5,1
    1954:	97a2                	add	a5,a5,s0
    1956:	c010                	sw	a2,0(s0)
    1958:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    195c:	06c6dc63          	bge	a3,a2,19d4 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1960:	10000793          	li	a5,256
    1964:	02f61c63          	bne	a2,a5,199c <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1968:	00001597          	auipc	a1,0x1
    196c:	ed058593          	addi	a1,a1,-304 # 2838 <buffer>
    1970:	4505                	li	a0,1
    1972:	25b000ef          	jal	ra,23cc <write>
			if (r < 0) {
    1976:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1978:	00001797          	auipc	a5,0x1
    197c:	ea07ac23          	sw	zero,-328(a5) # 2830 <buffer_len>
			if (r < 0) {
    1980:	04054c63          	bltz	a0,19d8 <puts+0x11e>
			if (r < buffer_len) {
    1984:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1986:	10c42503          	lw	a0,268(s0)
    198a:	4c7000ef          	jal	ra,2650 <mutex_unlock>
}
    198e:	70e2                	ld	ra,56(sp)
    1990:	7442                	ld	s0,48(sp)
    1992:	7902                	ld	s2,32(sp)
    1994:	8526                	mv	a0,s1
    1996:	74a2                	ld	s1,40(sp)
    1998:	6121                	addi	sp,sp,64
    199a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    199c:	23b000ef          	jal	ra,23d6 <getpid>
    19a0:	84aa                	mv	s1,a0
    19a2:	00001517          	auipc	a0,0x1
    19a6:	d9e50513          	addi	a0,a0,-610 # 2740 <enable_deadlock_detect+0x9c>
    19aa:	103000ef          	jal	ra,22ac <basename>
    19ae:	872a                	mv	a4,a0
    19b0:	00001617          	auipc	a2,0x1
    19b4:	d4860613          	addi	a2,a2,-696 # 26f8 <enable_deadlock_detect+0x54>
    19b8:	05400793          	li	a5,84
    19bc:	86a6                	mv	a3,s1
    19be:	45fd                	li	a1,31
    19c0:	00001517          	auipc	a0,0x1
    19c4:	dc050513          	addi	a0,a0,-576 # 2780 <enable_deadlock_detect+0xdc>
    19c8:	fdcff0ef          	jal	ra,11a4 <printf>
    19cc:	557d                	li	a0,-1
    19ce:	239000ef          	jal	ra,2406 <exit>
	if (buffer_len == 0)
    19d2:	4010                	lw	a2,0(s0)
    19d4:	da45                	beqz	a2,1984 <puts+0xca>
    19d6:	bf49                	j	1968 <puts+0xae>
    19d8:	54fd                	li	s1,-1
    19da:	b775                	j	1986 <puts+0xcc>

00000000000019dc <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19dc:	715d                	addi	sp,sp,-80
    19de:	e486                	sd	ra,72(sp)
    19e0:	e0a2                	sd	s0,64(sp)
    19e2:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19e4:	14054363          	bltz	a0,1b2a <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19e8:	02b577bb          	remuw	a5,a0,a1
    19ec:	00001617          	auipc	a2,0x1
    19f0:	f5460613          	addi	a2,a2,-172 # 2940 <digits>
	buf[16] = 0;
    19f4:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19f8:	0005871b          	sext.w	a4,a1
    19fc:	1782                	slli	a5,a5,0x20
    19fe:	9381                	srli	a5,a5,0x20
    1a00:	97b2                	add	a5,a5,a2
    1a02:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a06:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a0a:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a0e:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a10:	0eb56763          	bltu	a0,a1,1afe <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a14:	02e877bb          	remuw	a5,a6,a4
    1a18:	1782                	slli	a5,a5,0x20
    1a1a:	9381                	srli	a5,a5,0x20
    1a1c:	97b2                	add	a5,a5,a2
    1a1e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a22:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a26:	02f10323          	sb	a5,38(sp)
    1a2a:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a2c:	0ce86963          	bltu	a6,a4,1afe <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a30:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a34:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a38:	1582                	slli	a1,a1,0x20
    1a3a:	9181                	srli	a1,a1,0x20
    1a3c:	95b2                	add	a1,a1,a2
    1a3e:	0005c583          	lbu	a1,0(a1)
    1a42:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a46:	0007859b          	sext.w	a1,a5
    1a4a:	16e6e563          	bltu	a3,a4,1bb4 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a4e:	02e7f6bb          	remuw	a3,a5,a4
    1a52:	1682                	slli	a3,a3,0x20
    1a54:	9281                	srli	a3,a3,0x20
    1a56:	96b2                	add	a3,a3,a2
    1a58:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a5c:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a60:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a64:	16e5e163          	bltu	a1,a4,1bc6 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a68:	02e876bb          	remuw	a3,a6,a4
    1a6c:	1682                	slli	a3,a3,0x20
    1a6e:	9281                	srli	a3,a3,0x20
    1a70:	96b2                	add	a3,a3,a2
    1a72:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a76:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a7a:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a7e:	14e86d63          	bltu	a6,a4,1bd8 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a82:	02e5f6bb          	remuw	a3,a1,a4
    1a86:	1682                	slli	a3,a3,0x20
    1a88:	9281                	srli	a3,a3,0x20
    1a8a:	96b2                	add	a3,a3,a2
    1a8c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a90:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a94:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a98:	10e5e563          	bltu	a1,a4,1ba2 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1a9c:	02e876bb          	remuw	a3,a6,a4
    1aa0:	1682                	slli	a3,a3,0x20
    1aa2:	9281                	srli	a3,a3,0x20
    1aa4:	96b2                	add	a3,a3,a2
    1aa6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aaa:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1aae:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ab2:	14e86263          	bltu	a6,a4,1bf6 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1ab6:	02e5f6bb          	remuw	a3,a1,a4
    1aba:	1682                	slli	a3,a3,0x20
    1abc:	9281                	srli	a3,a3,0x20
    1abe:	96b2                	add	a3,a3,a2
    1ac0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ac4:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ac8:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1acc:	14e5e463          	bltu	a1,a4,1c14 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ad0:	02e876bb          	remuw	a3,a6,a4
    1ad4:	1682                	slli	a3,a3,0x20
    1ad6:	9281                	srli	a3,a3,0x20
    1ad8:	96b2                	add	a3,a3,a2
    1ada:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ade:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ae2:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1ae6:	14e86063          	bltu	a6,a4,1c26 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1aea:	1782                	slli	a5,a5,0x20
    1aec:	9381                	srli	a5,a5,0x20
    1aee:	97b2                	add	a5,a5,a2
    1af0:	0007c703          	lbu	a4,0(a5)
    1af4:	4799                	li	a5,6
    1af6:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1afa:	10054763          	bltz	a0,1c08 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1afe:	00001497          	auipc	s1,0x1
    1b02:	d3248493          	addi	s1,s1,-718 # 2830 <buffer_len>
    1b06:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b0a:	0828                	addi	a0,sp,24
    1b0c:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b0e:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b10:	00f50433          	add	s0,a0,a5
    1b14:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b16:	06e68463          	beq	a3,a4,1b7e <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b1a:	8522                	mv	a0,s0
    1b1c:	b15ff0ef          	jal	ra,1630 <out_unlocked>
}
    1b20:	60a6                	ld	ra,72(sp)
    1b22:	6406                	ld	s0,64(sp)
    1b24:	74e2                	ld	s1,56(sp)
    1b26:	6161                	addi	sp,sp,80
    1b28:	8082                	ret
		x = -xx;
    1b2a:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b2e:	02b877bb          	remuw	a5,a6,a1
    1b32:	00001617          	auipc	a2,0x1
    1b36:	e0e60613          	addi	a2,a2,-498 # 2940 <digits>
	buf[16] = 0;
    1b3a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b3e:	0005871b          	sext.w	a4,a1
    1b42:	1782                	slli	a5,a5,0x20
    1b44:	9381                	srli	a5,a5,0x20
    1b46:	97b2                	add	a5,a5,a2
    1b48:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b4c:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b50:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b54:	08b86b63          	bltu	a6,a1,1bea <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b58:	02e8f7bb          	remuw	a5,a7,a4
    1b5c:	1782                	slli	a5,a5,0x20
    1b5e:	9381                	srli	a5,a5,0x20
    1b60:	97b2                	add	a5,a5,a2
    1b62:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b66:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b6a:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b6e:	ece8f1e3          	bgeu	a7,a4,1a30 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b72:	02d00793          	li	a5,45
    1b76:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b7a:	47b5                	li	a5,13
    1b7c:	b749                	j	1afe <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b7e:	10c4a503          	lw	a0,268(s1)
    1b82:	e42e                	sd	a1,8(sp)
    1b84:	2c1000ef          	jal	ra,2644 <mutex_lock>
		len = out_unlocked(s, l);
    1b88:	65a2                	ld	a1,8(sp)
    1b8a:	8522                	mv	a0,s0
    1b8c:	aa5ff0ef          	jal	ra,1630 <out_unlocked>
		mutex_unlock(buffer_lock);
    1b90:	10c4a503          	lw	a0,268(s1)
    1b94:	2bd000ef          	jal	ra,2650 <mutex_unlock>
}
    1b98:	60a6                	ld	ra,72(sp)
    1b9a:	6406                	ld	s0,64(sp)
    1b9c:	74e2                	ld	s1,56(sp)
    1b9e:	6161                	addi	sp,sp,80
    1ba0:	8082                	ret
		buf[i--] = digits[x % base];
    1ba2:	47a9                	li	a5,10
	if (sign)
    1ba4:	f4055de3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ba8:	02d00793          	li	a5,45
    1bac:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bb0:	47a5                	li	a5,9
    1bb2:	b7b1                	j	1afe <printint.constprop.0+0x122>
    1bb4:	47b5                	li	a5,13
	if (sign)
    1bb6:	f40554e3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bba:	02d00793          	li	a5,45
    1bbe:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1bc2:	47b1                	li	a5,12
    1bc4:	bf2d                	j	1afe <printint.constprop.0+0x122>
    1bc6:	47b1                	li	a5,12
	if (sign)
    1bc8:	f2055be3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bcc:	02d00793          	li	a5,45
    1bd0:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bd4:	47ad                	li	a5,11
    1bd6:	b725                	j	1afe <printint.constprop.0+0x122>
    1bd8:	47ad                	li	a5,11
	if (sign)
    1bda:	f20552e3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bde:	02d00793          	li	a5,45
    1be2:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1be6:	47a9                	li	a5,10
    1be8:	bf19                	j	1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bea:	02d00793          	li	a5,45
    1bee:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bf2:	47b9                	li	a5,14
    1bf4:	b729                	j	1afe <printint.constprop.0+0x122>
    1bf6:	47a5                	li	a5,9
	if (sign)
    1bf8:	f00553e3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bfc:	02d00793          	li	a5,45
    1c00:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c04:	47a1                	li	a5,8
    1c06:	bde5                	j	1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c08:	02d00793          	li	a5,45
    1c0c:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c10:	4795                	li	a5,5
    1c12:	b5f5                	j	1afe <printint.constprop.0+0x122>
    1c14:	47a1                	li	a5,8
	if (sign)
    1c16:	ee0554e3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1a:	02d00793          	li	a5,45
    1c1e:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c22:	479d                	li	a5,7
    1c24:	bde9                	j	1afe <printint.constprop.0+0x122>
    1c26:	479d                	li	a5,7
	if (sign)
    1c28:	ec055be3          	bgez	a0,1afe <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c2c:	02d00793          	li	a5,45
    1c30:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c34:	4799                	li	a5,6
    1c36:	b5e1                	j	1afe <printint.constprop.0+0x122>

0000000000001c38 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c38:	02000793          	li	a5,32
    1c3c:	00f50663          	beq	a0,a5,1c48 <isspace+0x10>
    1c40:	355d                	addiw	a0,a0,-9
    1c42:	00553513          	sltiu	a0,a0,5
    1c46:	8082                	ret
    1c48:	4505                	li	a0,1
}
    1c4a:	8082                	ret

0000000000001c4c <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c4c:	fd05051b          	addiw	a0,a0,-48
}
    1c50:	00a53513          	sltiu	a0,a0,10
    1c54:	8082                	ret

0000000000001c56 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c56:	02000613          	li	a2,32
    1c5a:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c5c:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c60:	ff77869b          	addiw	a3,a5,-9
    1c64:	04c78c63          	beq	a5,a2,1cbc <atoi+0x66>
    1c68:	0007871b          	sext.w	a4,a5
    1c6c:	04d5f863          	bgeu	a1,a3,1cbc <atoi+0x66>
		s++;
	switch (*s) {
    1c70:	02b00693          	li	a3,43
    1c74:	04d78963          	beq	a5,a3,1cc6 <atoi+0x70>
    1c78:	02d00693          	li	a3,45
    1c7c:	06d78263          	beq	a5,a3,1ce0 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c80:	fd07061b          	addiw	a2,a4,-48
    1c84:	47a5                	li	a5,9
    1c86:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c88:	4e01                	li	t3,0
	while (isdigit(*s))
    1c8a:	04c7e963          	bltu	a5,a2,1cdc <atoi+0x86>
	int n = 0, neg = 0;
    1c8e:	4501                	li	a0,0
	while (isdigit(*s))
    1c90:	4825                	li	a6,9
    1c92:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c96:	0025179b          	slliw	a5,a0,0x2
    1c9a:	9fa9                	addw	a5,a5,a0
    1c9c:	fd07031b          	addiw	t1,a4,-48
    1ca0:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ca4:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ca8:	0685                	addi	a3,a3,1
    1caa:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cae:	0006071b          	sext.w	a4,a2
    1cb2:	feb870e3          	bgeu	a6,a1,1c92 <atoi+0x3c>
	return neg ? n : -n;
    1cb6:	000e0563          	beqz	t3,1cc0 <atoi+0x6a>
}
    1cba:	8082                	ret
		s++;
    1cbc:	0505                	addi	a0,a0,1
    1cbe:	bf79                	j	1c5c <atoi+0x6>
	return neg ? n : -n;
    1cc0:	4113053b          	subw	a0,t1,a7
    1cc4:	8082                	ret
	while (isdigit(*s))
    1cc6:	00154703          	lbu	a4,1(a0)
    1cca:	47a5                	li	a5,9
		s++;
    1ccc:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cd0:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cd4:	4e01                	li	t3,0
	while (isdigit(*s))
    1cd6:	2701                	sext.w	a4,a4
    1cd8:	fac7fbe3          	bgeu	a5,a2,1c8e <atoi+0x38>
    1cdc:	4501                	li	a0,0
}
    1cde:	8082                	ret
	while (isdigit(*s))
    1ce0:	00154703          	lbu	a4,1(a0)
    1ce4:	47a5                	li	a5,9
		s++;
    1ce6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cea:	fd07061b          	addiw	a2,a4,-48
    1cee:	2701                	sext.w	a4,a4
    1cf0:	fec7e6e3          	bltu	a5,a2,1cdc <atoi+0x86>
		neg = 1;
    1cf4:	4e05                	li	t3,1
    1cf6:	bf61                	j	1c8e <atoi+0x38>

0000000000001cf8 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cf8:	16060d63          	beqz	a2,1e72 <memset+0x17a>
    1cfc:	40a007b3          	neg	a5,a0
    1d00:	8b9d                	andi	a5,a5,7
    1d02:	00778693          	addi	a3,a5,7
    1d06:	482d                	li	a6,11
    1d08:	0ff5f713          	zext.b	a4,a1
    1d0c:	fff60593          	addi	a1,a2,-1
    1d10:	1706e263          	bltu	a3,a6,1e74 <memset+0x17c>
    1d14:	16d5ea63          	bltu	a1,a3,1e88 <memset+0x190>
    1d18:	16078563          	beqz	a5,1e82 <memset+0x18a>
    1d1c:	00e50023          	sb	a4,0(a0)
    1d20:	4685                	li	a3,1
    1d22:	00150593          	addi	a1,a0,1
    1d26:	14d78c63          	beq	a5,a3,1e7e <memset+0x186>
    1d2a:	00e500a3          	sb	a4,1(a0)
    1d2e:	4689                	li	a3,2
    1d30:	00250593          	addi	a1,a0,2
    1d34:	14d78d63          	beq	a5,a3,1e8e <memset+0x196>
    1d38:	00e50123          	sb	a4,2(a0)
    1d3c:	468d                	li	a3,3
    1d3e:	00350593          	addi	a1,a0,3
    1d42:	12d78b63          	beq	a5,a3,1e78 <memset+0x180>
    1d46:	00e501a3          	sb	a4,3(a0)
    1d4a:	4691                	li	a3,4
    1d4c:	00450593          	addi	a1,a0,4
    1d50:	14d78163          	beq	a5,a3,1e92 <memset+0x19a>
    1d54:	00e50223          	sb	a4,4(a0)
    1d58:	4695                	li	a3,5
    1d5a:	00550593          	addi	a1,a0,5
    1d5e:	12d78c63          	beq	a5,a3,1e96 <memset+0x19e>
    1d62:	00e502a3          	sb	a4,5(a0)
    1d66:	469d                	li	a3,7
    1d68:	00650593          	addi	a1,a0,6
    1d6c:	12d79763          	bne	a5,a3,1e9a <memset+0x1a2>
    1d70:	00750593          	addi	a1,a0,7
    1d74:	00e50323          	sb	a4,6(a0)
    1d78:	481d                	li	a6,7
    1d7a:	00871693          	slli	a3,a4,0x8
    1d7e:	01071893          	slli	a7,a4,0x10
    1d82:	8ed9                	or	a3,a3,a4
    1d84:	01871313          	slli	t1,a4,0x18
    1d88:	0116e6b3          	or	a3,a3,a7
    1d8c:	0066e6b3          	or	a3,a3,t1
    1d90:	02071893          	slli	a7,a4,0x20
    1d94:	02871e13          	slli	t3,a4,0x28
    1d98:	0116e6b3          	or	a3,a3,a7
    1d9c:	40f60333          	sub	t1,a2,a5
    1da0:	03071893          	slli	a7,a4,0x30
    1da4:	01c6e6b3          	or	a3,a3,t3
    1da8:	0116e6b3          	or	a3,a3,a7
    1dac:	03871e13          	slli	t3,a4,0x38
    1db0:	97aa                	add	a5,a5,a0
    1db2:	ff837893          	andi	a7,t1,-8
    1db6:	01c6e6b3          	or	a3,a3,t3
    1dba:	98be                	add	a7,a7,a5
    1dbc:	e394                	sd	a3,0(a5)
    1dbe:	07a1                	addi	a5,a5,8
    1dc0:	ff179ee3          	bne	a5,a7,1dbc <memset+0xc4>
    1dc4:	ff837893          	andi	a7,t1,-8
    1dc8:	011587b3          	add	a5,a1,a7
    1dcc:	010886bb          	addw	a3,a7,a6
    1dd0:	0b130663          	beq	t1,a7,1e7c <memset+0x184>
    1dd4:	00e78023          	sb	a4,0(a5)
    1dd8:	0016859b          	addiw	a1,a3,1
    1ddc:	08c5fb63          	bgeu	a1,a2,1e72 <memset+0x17a>
    1de0:	00e780a3          	sb	a4,1(a5)
    1de4:	0026859b          	addiw	a1,a3,2
    1de8:	08c5f563          	bgeu	a1,a2,1e72 <memset+0x17a>
    1dec:	00e78123          	sb	a4,2(a5)
    1df0:	0036859b          	addiw	a1,a3,3
    1df4:	06c5ff63          	bgeu	a1,a2,1e72 <memset+0x17a>
    1df8:	00e781a3          	sb	a4,3(a5)
    1dfc:	0046859b          	addiw	a1,a3,4
    1e00:	06c5f963          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e04:	00e78223          	sb	a4,4(a5)
    1e08:	0056859b          	addiw	a1,a3,5
    1e0c:	06c5f363          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e10:	00e782a3          	sb	a4,5(a5)
    1e14:	0066859b          	addiw	a1,a3,6
    1e18:	04c5fd63          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e1c:	00e78323          	sb	a4,6(a5)
    1e20:	0076859b          	addiw	a1,a3,7
    1e24:	04c5f763          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e28:	00e783a3          	sb	a4,7(a5)
    1e2c:	0086859b          	addiw	a1,a3,8
    1e30:	04c5f163          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e34:	00e78423          	sb	a4,8(a5)
    1e38:	0096859b          	addiw	a1,a3,9
    1e3c:	02c5fb63          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e40:	00e784a3          	sb	a4,9(a5)
    1e44:	00a6859b          	addiw	a1,a3,10
    1e48:	02c5f563          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e4c:	00e78523          	sb	a4,10(a5)
    1e50:	00b6859b          	addiw	a1,a3,11
    1e54:	00c5ff63          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e58:	00e785a3          	sb	a4,11(a5)
    1e5c:	00c6859b          	addiw	a1,a3,12
    1e60:	00c5f963          	bgeu	a1,a2,1e72 <memset+0x17a>
    1e64:	00e78623          	sb	a4,12(a5)
    1e68:	26b5                	addiw	a3,a3,13
    1e6a:	00c6f463          	bgeu	a3,a2,1e72 <memset+0x17a>
    1e6e:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e72:	8082                	ret
    1e74:	46ad                	li	a3,11
    1e76:	bd79                	j	1d14 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e78:	480d                	li	a6,3
    1e7a:	b701                	j	1d7a <memset+0x82>
    1e7c:	8082                	ret
    1e7e:	4805                	li	a6,1
    1e80:	bded                	j	1d7a <memset+0x82>
    1e82:	85aa                	mv	a1,a0
    1e84:	4801                	li	a6,0
    1e86:	bdd5                	j	1d7a <memset+0x82>
    1e88:	87aa                	mv	a5,a0
    1e8a:	4681                	li	a3,0
    1e8c:	b7a1                	j	1dd4 <memset+0xdc>
    1e8e:	4809                	li	a6,2
    1e90:	b5ed                	j	1d7a <memset+0x82>
    1e92:	4811                	li	a6,4
    1e94:	b5dd                	j	1d7a <memset+0x82>
    1e96:	4815                	li	a6,5
    1e98:	b5cd                	j	1d7a <memset+0x82>
    1e9a:	4819                	li	a6,6
    1e9c:	bdf9                	j	1d7a <memset+0x82>

0000000000001e9e <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1e9e:	00054783          	lbu	a5,0(a0)
    1ea2:	0005c703          	lbu	a4,0(a1)
    1ea6:	00e79863          	bne	a5,a4,1eb6 <strcmp+0x18>
    1eaa:	0505                	addi	a0,a0,1
    1eac:	0585                	addi	a1,a1,1
    1eae:	fbe5                	bnez	a5,1e9e <strcmp>
    1eb0:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1eb2:	9d19                	subw	a0,a0,a4
    1eb4:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1eb6:	0007851b          	sext.w	a0,a5
    1eba:	bfe5                	j	1eb2 <strcmp+0x14>

0000000000001ebc <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ebc:	ca15                	beqz	a2,1ef0 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ebe:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ec2:	167d                	addi	a2,a2,-1
    1ec4:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ec8:	eb99                	bnez	a5,1ede <strncmp+0x22>
    1eca:	a815                	j	1efe <strncmp+0x42>
    1ecc:	00a68e63          	beq	a3,a0,1ee8 <strncmp+0x2c>
    1ed0:	0505                	addi	a0,a0,1
    1ed2:	00f71b63          	bne	a4,a5,1ee8 <strncmp+0x2c>
    1ed6:	00054783          	lbu	a5,0(a0)
    1eda:	cf89                	beqz	a5,1ef4 <strncmp+0x38>
    1edc:	85b2                	mv	a1,a2
    1ede:	0005c703          	lbu	a4,0(a1)
    1ee2:	00158613          	addi	a2,a1,1
    1ee6:	f37d                	bnez	a4,1ecc <strncmp+0x10>
		;
	return *l - *r;
    1ee8:	0007851b          	sext.w	a0,a5
    1eec:	9d19                	subw	a0,a0,a4
    1eee:	8082                	ret
		return 0;
    1ef0:	4501                	li	a0,0
}
    1ef2:	8082                	ret
	return *l - *r;
    1ef4:	0015c703          	lbu	a4,1(a1)
    1ef8:	4501                	li	a0,0
    1efa:	9d19                	subw	a0,a0,a4
    1efc:	8082                	ret
    1efe:	0005c703          	lbu	a4,0(a1)
    1f02:	4501                	li	a0,0
    1f04:	b7e5                	j	1eec <strncmp+0x30>

0000000000001f06 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f06:	00757793          	andi	a5,a0,7
    1f0a:	cf89                	beqz	a5,1f24 <strlen+0x1e>
    1f0c:	87aa                	mv	a5,a0
    1f0e:	a029                	j	1f18 <strlen+0x12>
    1f10:	0785                	addi	a5,a5,1
    1f12:	0077f713          	andi	a4,a5,7
    1f16:	cb01                	beqz	a4,1f26 <strlen+0x20>
		if (!*s)
    1f18:	0007c703          	lbu	a4,0(a5)
    1f1c:	fb75                	bnez	a4,1f10 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f1e:	40a78533          	sub	a0,a5,a0
}
    1f22:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f24:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f26:	6394                	ld	a3,0(a5)
    1f28:	00001597          	auipc	a1,0x1
    1f2c:	8f05b583          	ld	a1,-1808(a1) # 2818 <enable_deadlock_detect+0x174>
    1f30:	00001617          	auipc	a2,0x1
    1f34:	8f063603          	ld	a2,-1808(a2) # 2820 <enable_deadlock_detect+0x17c>
    1f38:	a019                	j	1f3e <strlen+0x38>
    1f3a:	6794                	ld	a3,8(a5)
    1f3c:	07a1                	addi	a5,a5,8
    1f3e:	00b68733          	add	a4,a3,a1
    1f42:	fff6c693          	not	a3,a3
    1f46:	8f75                	and	a4,a4,a3
    1f48:	8f71                	and	a4,a4,a2
    1f4a:	db65                	beqz	a4,1f3a <strlen+0x34>
	for (; *s; s++)
    1f4c:	0007c703          	lbu	a4,0(a5)
    1f50:	d779                	beqz	a4,1f1e <strlen+0x18>
    1f52:	0017c703          	lbu	a4,1(a5)
    1f56:	0785                	addi	a5,a5,1
    1f58:	d379                	beqz	a4,1f1e <strlen+0x18>
    1f5a:	0017c703          	lbu	a4,1(a5)
    1f5e:	0785                	addi	a5,a5,1
    1f60:	fb6d                	bnez	a4,1f52 <strlen+0x4c>
    1f62:	bf75                	j	1f1e <strlen+0x18>

0000000000001f64 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f64:	00757713          	andi	a4,a0,7
{
    1f68:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f6a:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f6e:	cb19                	beqz	a4,1f84 <memchr+0x20>
    1f70:	ce25                	beqz	a2,1fe8 <memchr+0x84>
    1f72:	0007c703          	lbu	a4,0(a5)
    1f76:	04b70e63          	beq	a4,a1,1fd2 <memchr+0x6e>
    1f7a:	0785                	addi	a5,a5,1
    1f7c:	0077f713          	andi	a4,a5,7
    1f80:	167d                	addi	a2,a2,-1
    1f82:	f77d                	bnez	a4,1f70 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f84:	4501                	li	a0,0
	if (n && *s != c) {
    1f86:	c235                	beqz	a2,1fea <memchr+0x86>
    1f88:	0007c703          	lbu	a4,0(a5)
    1f8c:	04b70363          	beq	a4,a1,1fd2 <memchr+0x6e>
		size_t k = ONES * c;
    1f90:	00001517          	auipc	a0,0x1
    1f94:	89853503          	ld	a0,-1896(a0) # 2828 <enable_deadlock_detect+0x184>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f98:	471d                	li	a4,7
		size_t k = ONES * c;
    1f9a:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f9e:	02c77a63          	bgeu	a4,a2,1fd2 <memchr+0x6e>
    1fa2:	00001897          	auipc	a7,0x1
    1fa6:	8768b883          	ld	a7,-1930(a7) # 2818 <enable_deadlock_detect+0x174>
    1faa:	00001817          	auipc	a6,0x1
    1fae:	87683803          	ld	a6,-1930(a6) # 2820 <enable_deadlock_detect+0x17c>
    1fb2:	431d                	li	t1,7
    1fb4:	a029                	j	1fbe <memchr+0x5a>
		     w++, n -= SS)
    1fb6:	1661                	addi	a2,a2,-8
    1fb8:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fba:	02c37963          	bgeu	t1,a2,1fec <memchr+0x88>
    1fbe:	6398                	ld	a4,0(a5)
    1fc0:	8f29                	xor	a4,a4,a0
    1fc2:	011706b3          	add	a3,a4,a7
    1fc6:	fff74713          	not	a4,a4
    1fca:	8f75                	and	a4,a4,a3
    1fcc:	01077733          	and	a4,a4,a6
    1fd0:	d37d                	beqz	a4,1fb6 <memchr+0x52>
{
    1fd2:	853e                	mv	a0,a5
    1fd4:	97b2                	add	a5,a5,a2
    1fd6:	a021                	j	1fde <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fd8:	0505                	addi	a0,a0,1
    1fda:	00f50763          	beq	a0,a5,1fe8 <memchr+0x84>
    1fde:	00054703          	lbu	a4,0(a0)
    1fe2:	feb71be3          	bne	a4,a1,1fd8 <memchr+0x74>
    1fe6:	8082                	ret
	return n ? (void *)s : 0;
    1fe8:	4501                	li	a0,0
}
    1fea:	8082                	ret
	return n ? (void *)s : 0;
    1fec:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1fee:	f275                	bnez	a2,1fd2 <memchr+0x6e>
}
    1ff0:	8082                	ret

0000000000001ff2 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1ff2:	1101                	addi	sp,sp,-32
    1ff4:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1ff6:	862e                	mv	a2,a1
{
    1ff8:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    1ffa:	4581                	li	a1,0
{
    1ffc:	e426                	sd	s1,8(sp)
    1ffe:	ec06                	sd	ra,24(sp)
    2000:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2002:	f63ff0ef          	jal	ra,1f64 <memchr>
	return p ? p - s : n;
    2006:	c519                	beqz	a0,2014 <strnlen+0x22>
}
    2008:	60e2                	ld	ra,24(sp)
    200a:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    200c:	8d05                	sub	a0,a0,s1
}
    200e:	64a2                	ld	s1,8(sp)
    2010:	6105                	addi	sp,sp,32
    2012:	8082                	ret
    2014:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2016:	8522                	mv	a0,s0
}
    2018:	6442                	ld	s0,16(sp)
    201a:	64a2                	ld	s1,8(sp)
    201c:	6105                	addi	sp,sp,32
    201e:	8082                	ret

0000000000002020 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2020:	00a5c7b3          	xor	a5,a1,a0
    2024:	8b9d                	andi	a5,a5,7
    2026:	eb95                	bnez	a5,205a <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2028:	0075f793          	andi	a5,a1,7
    202c:	e7b1                	bnez	a5,2078 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    202e:	6198                	ld	a4,0(a1)
    2030:	00000617          	auipc	a2,0x0
    2034:	7e863603          	ld	a2,2024(a2) # 2818 <enable_deadlock_detect+0x174>
    2038:	00000817          	auipc	a6,0x0
    203c:	7e883803          	ld	a6,2024(a6) # 2820 <enable_deadlock_detect+0x17c>
    2040:	a029                	j	204a <stpcpy+0x2a>
    2042:	05a1                	addi	a1,a1,8
    2044:	e118                	sd	a4,0(a0)
    2046:	6198                	ld	a4,0(a1)
    2048:	0521                	addi	a0,a0,8
    204a:	00c707b3          	add	a5,a4,a2
    204e:	fff74693          	not	a3,a4
    2052:	8ff5                	and	a5,a5,a3
    2054:	0107f7b3          	and	a5,a5,a6
    2058:	d7ed                	beqz	a5,2042 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    205a:	0005c783          	lbu	a5,0(a1)
    205e:	00f50023          	sb	a5,0(a0)
    2062:	c785                	beqz	a5,208a <stpcpy+0x6a>
    2064:	0015c783          	lbu	a5,1(a1)
    2068:	0505                	addi	a0,a0,1
    206a:	0585                	addi	a1,a1,1
    206c:	00f50023          	sb	a5,0(a0)
    2070:	fbf5                	bnez	a5,2064 <stpcpy+0x44>
		;
	return d;
}
    2072:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2074:	0505                	addi	a0,a0,1
    2076:	df45                	beqz	a4,202e <stpcpy+0xe>
			if (!(*d = *s))
    2078:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    207c:	0585                	addi	a1,a1,1
    207e:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2082:	00f50023          	sb	a5,0(a0)
    2086:	f7fd                	bnez	a5,2074 <stpcpy+0x54>
}
    2088:	8082                	ret
    208a:	8082                	ret

000000000000208c <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    208c:	00a5c7b3          	xor	a5,a1,a0
    2090:	8b9d                	andi	a5,a5,7
    2092:	1a079863          	bnez	a5,2242 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2096:	0075f793          	andi	a5,a1,7
    209a:	16078463          	beqz	a5,2202 <stpncpy+0x176>
    209e:	ea01                	bnez	a2,20ae <stpncpy+0x22>
    20a0:	a421                	j	22a8 <stpncpy+0x21c>
    20a2:	167d                	addi	a2,a2,-1
    20a4:	0505                	addi	a0,a0,1
    20a6:	14070e63          	beqz	a4,2202 <stpncpy+0x176>
    20aa:	1a060863          	beqz	a2,225a <stpncpy+0x1ce>
    20ae:	0005c783          	lbu	a5,0(a1)
    20b2:	0585                	addi	a1,a1,1
    20b4:	0075f713          	andi	a4,a1,7
    20b8:	00f50023          	sb	a5,0(a0)
    20bc:	f3fd                	bnez	a5,20a2 <stpncpy+0x16>
    20be:	4805                	li	a6,1
    20c0:	1a061863          	bnez	a2,2270 <stpncpy+0x1e4>
    20c4:	40a007b3          	neg	a5,a0
    20c8:	8b9d                	andi	a5,a5,7
    20ca:	4681                	li	a3,0
    20cc:	18061a63          	bnez	a2,2260 <stpncpy+0x1d4>
    20d0:	00778713          	addi	a4,a5,7
    20d4:	45ad                	li	a1,11
    20d6:	18b76363          	bltu	a4,a1,225c <stpncpy+0x1d0>
    20da:	1ae6eb63          	bltu	a3,a4,2290 <stpncpy+0x204>
    20de:	1a078363          	beqz	a5,2284 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20e2:	00050023          	sb	zero,0(a0)
    20e6:	4685                	li	a3,1
    20e8:	00150713          	addi	a4,a0,1
    20ec:	18d78f63          	beq	a5,a3,228a <stpncpy+0x1fe>
    20f0:	000500a3          	sb	zero,1(a0)
    20f4:	4689                	li	a3,2
    20f6:	00250713          	addi	a4,a0,2
    20fa:	18d78e63          	beq	a5,a3,2296 <stpncpy+0x20a>
    20fe:	00050123          	sb	zero,2(a0)
    2102:	468d                	li	a3,3
    2104:	00350713          	addi	a4,a0,3
    2108:	16d78c63          	beq	a5,a3,2280 <stpncpy+0x1f4>
    210c:	000501a3          	sb	zero,3(a0)
    2110:	4691                	li	a3,4
    2112:	00450713          	addi	a4,a0,4
    2116:	18d78263          	beq	a5,a3,229a <stpncpy+0x20e>
    211a:	00050223          	sb	zero,4(a0)
    211e:	4695                	li	a3,5
    2120:	00550713          	addi	a4,a0,5
    2124:	16d78d63          	beq	a5,a3,229e <stpncpy+0x212>
    2128:	000502a3          	sb	zero,5(a0)
    212c:	469d                	li	a3,7
    212e:	00650713          	addi	a4,a0,6
    2132:	16d79863          	bne	a5,a3,22a2 <stpncpy+0x216>
    2136:	00750713          	addi	a4,a0,7
    213a:	00050323          	sb	zero,6(a0)
    213e:	40f80833          	sub	a6,a6,a5
    2142:	ff887593          	andi	a1,a6,-8
    2146:	97aa                	add	a5,a5,a0
    2148:	95be                	add	a1,a1,a5
    214a:	0007b023          	sd	zero,0(a5)
    214e:	07a1                	addi	a5,a5,8
    2150:	feb79de3          	bne	a5,a1,214a <stpncpy+0xbe>
    2154:	ff887593          	andi	a1,a6,-8
    2158:	9ead                	addw	a3,a3,a1
    215a:	00b707b3          	add	a5,a4,a1
    215e:	12b80863          	beq	a6,a1,228e <stpncpy+0x202>
    2162:	00078023          	sb	zero,0(a5)
    2166:	0016871b          	addiw	a4,a3,1
    216a:	0ec77863          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    216e:	000780a3          	sb	zero,1(a5)
    2172:	0026871b          	addiw	a4,a3,2
    2176:	0ec77263          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    217a:	00078123          	sb	zero,2(a5)
    217e:	0036871b          	addiw	a4,a3,3
    2182:	0cc77c63          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    2186:	000781a3          	sb	zero,3(a5)
    218a:	0046871b          	addiw	a4,a3,4
    218e:	0cc77663          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    2192:	00078223          	sb	zero,4(a5)
    2196:	0056871b          	addiw	a4,a3,5
    219a:	0cc77063          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    219e:	000782a3          	sb	zero,5(a5)
    21a2:	0066871b          	addiw	a4,a3,6
    21a6:	0ac77a63          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21aa:	00078323          	sb	zero,6(a5)
    21ae:	0076871b          	addiw	a4,a3,7
    21b2:	0ac77463          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21b6:	000783a3          	sb	zero,7(a5)
    21ba:	0086871b          	addiw	a4,a3,8
    21be:	08c77e63          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21c2:	00078423          	sb	zero,8(a5)
    21c6:	0096871b          	addiw	a4,a3,9
    21ca:	08c77863          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21ce:	000784a3          	sb	zero,9(a5)
    21d2:	00a6871b          	addiw	a4,a3,10
    21d6:	08c77263          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21da:	00078523          	sb	zero,10(a5)
    21de:	00b6871b          	addiw	a4,a3,11
    21e2:	06c77c63          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21e6:	000785a3          	sb	zero,11(a5)
    21ea:	00c6871b          	addiw	a4,a3,12
    21ee:	06c77663          	bgeu	a4,a2,225a <stpncpy+0x1ce>
    21f2:	00078623          	sb	zero,12(a5)
    21f6:	26b5                	addiw	a3,a3,13
    21f8:	06c6f163          	bgeu	a3,a2,225a <stpncpy+0x1ce>
    21fc:	000786a3          	sb	zero,13(a5)
    2200:	8082                	ret
			;
		if (!n || !*s)
    2202:	c645                	beqz	a2,22aa <stpncpy+0x21e>
    2204:	0005c783          	lbu	a5,0(a1)
    2208:	ea078be3          	beqz	a5,20be <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    220c:	479d                	li	a5,7
    220e:	02c7ff63          	bgeu	a5,a2,224c <stpncpy+0x1c0>
    2212:	00000897          	auipc	a7,0x0
    2216:	6068b883          	ld	a7,1542(a7) # 2818 <enable_deadlock_detect+0x174>
    221a:	00000817          	auipc	a6,0x0
    221e:	60683803          	ld	a6,1542(a6) # 2820 <enable_deadlock_detect+0x17c>
    2222:	431d                	li	t1,7
    2224:	6198                	ld	a4,0(a1)
    2226:	011707b3          	add	a5,a4,a7
    222a:	fff74693          	not	a3,a4
    222e:	8ff5                	and	a5,a5,a3
    2230:	0107f7b3          	and	a5,a5,a6
    2234:	ef81                	bnez	a5,224c <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2236:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2238:	1661                	addi	a2,a2,-8
    223a:	05a1                	addi	a1,a1,8
    223c:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    223e:	fec363e3          	bltu	t1,a2,2224 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2242:	e609                	bnez	a2,224c <stpncpy+0x1c0>
    2244:	a08d                	j	22a6 <stpncpy+0x21a>
    2246:	167d                	addi	a2,a2,-1
    2248:	0505                	addi	a0,a0,1
    224a:	ca01                	beqz	a2,225a <stpncpy+0x1ce>
    224c:	0005c783          	lbu	a5,0(a1)
    2250:	0585                	addi	a1,a1,1
    2252:	00f50023          	sb	a5,0(a0)
    2256:	fbe5                	bnez	a5,2246 <stpncpy+0x1ba>
		;
tail:
    2258:	b59d                	j	20be <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    225a:	8082                	ret
    225c:	472d                	li	a4,11
    225e:	bdb5                	j	20da <stpncpy+0x4e>
    2260:	00778713          	addi	a4,a5,7
    2264:	45ad                	li	a1,11
    2266:	fff60693          	addi	a3,a2,-1
    226a:	e6b778e3          	bgeu	a4,a1,20da <stpncpy+0x4e>
    226e:	b7fd                	j	225c <stpncpy+0x1d0>
    2270:	40a007b3          	neg	a5,a0
    2274:	8832                	mv	a6,a2
    2276:	8b9d                	andi	a5,a5,7
    2278:	4681                	li	a3,0
    227a:	e4060be3          	beqz	a2,20d0 <stpncpy+0x44>
    227e:	b7cd                	j	2260 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2280:	468d                	li	a3,3
    2282:	bd75                	j	213e <stpncpy+0xb2>
    2284:	872a                	mv	a4,a0
    2286:	4681                	li	a3,0
    2288:	bd5d                	j	213e <stpncpy+0xb2>
    228a:	4685                	li	a3,1
    228c:	bd4d                	j	213e <stpncpy+0xb2>
    228e:	8082                	ret
    2290:	87aa                	mv	a5,a0
    2292:	4681                	li	a3,0
    2294:	b5f9                	j	2162 <stpncpy+0xd6>
    2296:	4689                	li	a3,2
    2298:	b55d                	j	213e <stpncpy+0xb2>
    229a:	4691                	li	a3,4
    229c:	b54d                	j	213e <stpncpy+0xb2>
    229e:	4695                	li	a3,5
    22a0:	bd79                	j	213e <stpncpy+0xb2>
    22a2:	4699                	li	a3,6
    22a4:	bd69                	j	213e <stpncpy+0xb2>
    22a6:	8082                	ret
    22a8:	8082                	ret
    22aa:	8082                	ret

00000000000022ac <basename>:

char *basename(char *s)
{
    22ac:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22ae:	c54d                	beqz	a0,2358 <basename+0xac>
    22b0:	00054783          	lbu	a5,0(a0)
		return ".";
    22b4:	00000517          	auipc	a0,0x0
    22b8:	55c50513          	addi	a0,a0,1372 # 2810 <enable_deadlock_detect+0x16c>
	if (!s || !*s)
    22bc:	e391                	bnez	a5,22c0 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22be:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22c0:	0076f713          	andi	a4,a3,7
    22c4:	87b6                	mv	a5,a3
    22c6:	cf51                	beqz	a4,2362 <basename+0xb6>
    22c8:	0785                	addi	a5,a5,1
    22ca:	0077f713          	andi	a4,a5,7
    22ce:	c729                	beqz	a4,2318 <basename+0x6c>
		if (!*s)
    22d0:	0007c703          	lbu	a4,0(a5)
    22d4:	fb75                	bnez	a4,22c8 <basename+0x1c>
	return s - a;
    22d6:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22d8:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22da:	cf8d                	beqz	a5,2314 <basename+0x68>
    22dc:	00f68733          	add	a4,a3,a5
    22e0:	02f00593          	li	a1,47
    22e4:	a031                	j	22f0 <basename+0x44>
		s[i] = 0;
    22e6:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22ea:	17fd                	addi	a5,a5,-1
    22ec:	177d                	addi	a4,a4,-1
    22ee:	c39d                	beqz	a5,2314 <basename+0x68>
    22f0:	00074603          	lbu	a2,0(a4)
    22f4:	feb609e3          	beq	a2,a1,22e6 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22f8:	02f00613          	li	a2,47
    22fc:	a011                	j	2300 <basename+0x54>
    22fe:	cb99                	beqz	a5,2314 <basename+0x68>
    2300:	853e                	mv	a0,a5
    2302:	17fd                	addi	a5,a5,-1
    2304:	00f68733          	add	a4,a3,a5
    2308:	00074703          	lbu	a4,0(a4)
    230c:	fec719e3          	bne	a4,a2,22fe <basename+0x52>
	return s + i;
    2310:	9536                	add	a0,a0,a3
    2312:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2314:	8536                	mv	a0,a3
    2316:	8082                	ret
    2318:	6390                	ld	a2,0(a5)
    231a:	00000517          	auipc	a0,0x0
    231e:	4fe53503          	ld	a0,1278(a0) # 2818 <enable_deadlock_detect+0x174>
    2322:	00000597          	auipc	a1,0x0
    2326:	4fe5b583          	ld	a1,1278(a1) # 2820 <enable_deadlock_detect+0x17c>
    232a:	fff64713          	not	a4,a2
    232e:	962a                	add	a2,a2,a0
    2330:	8f71                	and	a4,a4,a2
    2332:	8f6d                	and	a4,a4,a1
    2334:	eb11                	bnez	a4,2348 <basename+0x9c>
    2336:	6790                	ld	a2,8(a5)
    2338:	07a1                	addi	a5,a5,8
    233a:	00a60733          	add	a4,a2,a0
    233e:	fff64613          	not	a2,a2
    2342:	8f71                	and	a4,a4,a2
    2344:	8f6d                	and	a4,a4,a1
    2346:	db65                	beqz	a4,2336 <basename+0x8a>
	for (; *s; s++)
    2348:	0007c703          	lbu	a4,0(a5)
    234c:	d749                	beqz	a4,22d6 <basename+0x2a>
    234e:	0017c703          	lbu	a4,1(a5)
    2352:	0785                	addi	a5,a5,1
    2354:	ff6d                	bnez	a4,234e <basename+0xa2>
    2356:	b741                	j	22d6 <basename+0x2a>
		return ".";
    2358:	00000517          	auipc	a0,0x0
    235c:	4b850513          	addi	a0,a0,1208 # 2810 <enable_deadlock_detect+0x16c>
    2360:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2362:	6290                	ld	a2,0(a3)
    2364:	00000517          	auipc	a0,0x0
    2368:	4b453503          	ld	a0,1204(a0) # 2818 <enable_deadlock_detect+0x174>
    236c:	00000597          	auipc	a1,0x0
    2370:	4b45b583          	ld	a1,1204(a1) # 2820 <enable_deadlock_detect+0x17c>
    2374:	fff64713          	not	a4,a2
    2378:	962a                	add	a2,a2,a0
    237a:	8f71                	and	a4,a4,a2
    237c:	8f6d                	and	a4,a4,a1
    237e:	df45                	beqz	a4,2336 <basename+0x8a>
    2380:	b7f9                	j	234e <basename+0xa2>

0000000000002382 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2382:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2386:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2388:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    238c:	2501                	sext.w	a0,a0
    238e:	8082                	ret

0000000000002390 <close>:

int close(int fd)
{
	if (fd == 1) {
    2390:	4785                	li	a5,1
    2392:	00f50863          	beq	a0,a5,23a2 <close+0x12>
	register long a7 __asm__("a7") = n;
    2396:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    239a:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    239e:	2501                	sext.w	a0,a0
    23a0:	8082                	ret
{
    23a2:	1101                	addi	sp,sp,-32
    23a4:	ec06                	sd	ra,24(sp)
    23a6:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23a8:	cdffe0ef          	jal	ra,1086 <__write_buffer>
		__clear_buffer();
    23ac:	d03fe0ef          	jal	ra,10ae <__clear_buffer>
    23b0:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23b2:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23b6:	00000073          	ecall
}
    23ba:	60e2                	ld	ra,24(sp)
    23bc:	2501                	sext.w	a0,a0
    23be:	6105                	addi	sp,sp,32
    23c0:	8082                	ret

00000000000023c2 <read>:
	register long a7 __asm__("a7") = n;
    23c2:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23c6:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23ca:	8082                	ret

00000000000023cc <write>:
	register long a7 __asm__("a7") = n;
    23cc:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23d0:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23d4:	8082                	ret

00000000000023d6 <getpid>:
	register long a7 __asm__("a7") = n;
    23d6:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23da:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23de:	2501                	sext.w	a0,a0
    23e0:	8082                	ret

00000000000023e2 <getppid>:
	register long a7 __asm__("a7") = n;
    23e2:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23e6:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23ea:	2501                	sext.w	a0,a0
    23ec:	8082                	ret

00000000000023ee <sched_yield>:
	register long a7 __asm__("a7") = n;
    23ee:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23f2:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23f6:	2501                	sext.w	a0,a0
    23f8:	8082                	ret

00000000000023fa <fork>:
	register long a7 __asm__("a7") = n;
    23fa:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    23fe:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2402:	2501                	sext.w	a0,a0
    2404:	8082                	ret

0000000000002406 <exit>:

void exit(int code)
{
    2406:	1141                	addi	sp,sp,-16
    2408:	e406                	sd	ra,8(sp)
    240a:	e022                	sd	s0,0(sp)
    240c:	842a                	mv	s0,a0
	__write_buffer();
    240e:	c79fe0ef          	jal	ra,1086 <__write_buffer>
	__clear_buffer();
    2412:	c9dfe0ef          	jal	ra,10ae <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2416:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    241a:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    241c:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2420:	60a2                	ld	ra,8(sp)
    2422:	6402                	ld	s0,0(sp)
    2424:	0141                	addi	sp,sp,16
    2426:	8082                	ret

0000000000002428 <waitpid>:
	register long a7 __asm__("a7") = n;
    2428:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    242c:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2430:	2501                	sext.w	a0,a0
    2432:	8082                	ret

0000000000002434 <exec>:
	register long a7 __asm__("a7") = n;
    2434:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2438:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    243c:	2501                	sext.w	a0,a0
    243e:	8082                	ret

0000000000002440 <get_mtime>:

int64 get_mtime()
{
    2440:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2442:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2446:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2448:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    244a:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    244e:	2501                	sext.w	a0,a0
    2450:	ed01                	bnez	a0,2468 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2452:	6722                	ld	a4,8(sp)
    2454:	3e800793          	li	a5,1000
    2458:	6682                	ld	a3,0(sp)
    245a:	02f75733          	divu	a4,a4,a5
    245e:	02d78533          	mul	a0,a5,a3
    2462:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2464:	0141                	addi	sp,sp,16
    2466:	8082                	ret
	return -1;
    2468:	557d                	li	a0,-1
    246a:	bfed                	j	2464 <get_mtime+0x24>

000000000000246c <sys_get_time>:
	register long a7 __asm__("a7") = n;
    246c:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2470:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2474:	2501                	sext.w	a0,a0
    2476:	8082                	ret

0000000000002478 <sleep>:

int sleep(unsigned long long time)
{
    2478:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    247a:	880a                	mv	a6,sp
{
    247c:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    247e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2482:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2484:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2486:	00000073          	ecall
	if (err == 0) {
    248a:	2501                	sext.w	a0,a0
    248c:	ed31                	bnez	a0,24e8 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    248e:	6722                	ld	a4,8(sp)
    2490:	3e800793          	li	a5,1000
    2494:	6682                	ld	a3,0(sp)
    2496:	02f75733          	divu	a4,a4,a5
    249a:	02d787b3          	mul	a5,a5,a3
    249e:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24a0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a4:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24a6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a8:	00000073          	ecall
	if (err == 0) {
    24ac:	2501                	sext.w	a0,a0
    24ae:	e915                	bnez	a0,24e2 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24b0:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24b2:	3e800693          	li	a3,1000
    24b6:	a819                	j	24cc <sleep+0x54>
	__asm_syscall("r"(a7))
    24b8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24bc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c4:	00000073          	ecall
	if (err == 0) {
    24c8:	2501                	sext.w	a0,a0
    24ca:	ed01                	bnez	a0,24e2 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24cc:	6722                	ld	a4,8(sp)
    24ce:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24d0:	07c00893          	li	a7,124
    24d4:	02d75733          	divu	a4,a4,a3
    24d8:	02f687b3          	mul	a5,a3,a5
    24dc:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24de:	fcc7ede3          	bltu	a5,a2,24b8 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24e2:	4501                	li	a0,0
    24e4:	0141                	addi	sp,sp,16
    24e6:	8082                	ret
    24e8:	57fd                	li	a5,-1
    24ea:	bf5d                	j	24a0 <sleep+0x28>

00000000000024ec <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24ec:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24f0:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24f4:	2501                	sext.w	a0,a0
    24f6:	8082                	ret

00000000000024f8 <set_priority>:
	register long a7 __asm__("a7") = n;
    24f8:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    24fc:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2500:	2501                	sext.w	a0,a0
    2502:	8082                	ret

0000000000002504 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2504:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2508:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    250c:	2501                	sext.w	a0,a0
    250e:	8082                	ret

0000000000002510 <munmap>:
	register long a7 __asm__("a7") = n;
    2510:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2514:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2518:	2501                	sext.w	a0,a0
    251a:	8082                	ret

000000000000251c <wait>:

int wait(int *code)
{
    251c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    251e:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2522:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2524:	00000073          	ecall
	return waitpid(-1, code);
}
    2528:	2501                	sext.w	a0,a0
    252a:	8082                	ret

000000000000252c <spawn>:
	register long a7 __asm__("a7") = n;
    252c:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2530:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2534:	2501                	sext.w	a0,a0
    2536:	8082                	ret

0000000000002538 <pipe>:
	register long a7 __asm__("a7") = n;
    2538:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    253c:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2540:	2501                	sext.w	a0,a0
    2542:	8082                	ret

0000000000002544 <mailread>:
	register long a7 __asm__("a7") = n;
    2544:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2548:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    254c:	2501                	sext.w	a0,a0
    254e:	8082                	ret

0000000000002550 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2550:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2554:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2558:	2501                	sext.w	a0,a0
    255a:	8082                	ret

000000000000255c <fstat>:
	register long a7 __asm__("a7") = n;
    255c:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2560:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2564:	2501                	sext.w	a0,a0
    2566:	8082                	ret

0000000000002568 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2568:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    256a:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    256e:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2570:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2574:	2501                	sext.w	a0,a0
    2576:	8082                	ret

0000000000002578 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2578:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    257a:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    257e:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2580:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2584:	2501                	sext.w	a0,a0
    2586:	8082                	ret

0000000000002588 <link>:

int link(char *old_path, char *new_path)
{
    2588:	87aa                	mv	a5,a0
    258a:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    258c:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2590:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2594:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2596:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    259a:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    259c:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25a0:	2501                	sext.w	a0,a0
    25a2:	8082                	ret

00000000000025a4 <unlink>:

int unlink(char *path)
{
    25a4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25a6:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25aa:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25ae:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25b0:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25b4:	2501                	sext.w	a0,a0
    25b6:	8082                	ret

00000000000025b8 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25b8:	00000797          	auipc	a5,0x0
    25bc:	3a87b783          	ld	a5,936(a5) # 2960 <_GLOBAL_OFFSET_TABLE_+0x8>
    25c0:	439c                	lw	a5,0(a5)
    25c2:	c799                	beqz	a5,25d0 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25c4:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c8:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25cc:	2501                	sext.w	a0,a0
    25ce:	8082                	ret
{
    25d0:	1101                	addi	sp,sp,-32
    25d2:	ec06                	sd	ra,24(sp)
    25d4:	e42e                	sd	a1,8(sp)
    25d6:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25d8:	fe7fe0ef          	jal	ra,15be <enable_thread_io_buffer>
    25dc:	65a2                	ld	a1,8(sp)
    25de:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25e0:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e4:	00000073          	ecall
}
    25e8:	60e2                	ld	ra,24(sp)
    25ea:	2501                	sext.w	a0,a0
    25ec:	6105                	addi	sp,sp,32
    25ee:	8082                	ret

00000000000025f0 <gettid>:
	register long a7 __asm__("a7") = n;
    25f0:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25f4:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25f8:	2501                	sext.w	a0,a0
    25fa:	8082                	ret

00000000000025fc <waittid>:

int waittid(int tid)
{
    25fc:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    25fe:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2602:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2606:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2608:	2501                	sext.w	a0,a0
	while (ret == -2) {
    260a:	00e51e63          	bne	a0,a4,2626 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    260e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2612:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2616:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    261a:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    261c:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2620:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2622:	fee506e3          	beq	a0,a4,260e <waittid+0x12>
	}
	return ret;
}
    2626:	8082                	ret

0000000000002628 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2628:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    262c:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    262e:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2632:	2501                	sext.w	a0,a0
    2634:	8082                	ret

0000000000002636 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2636:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    263a:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    263c:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2640:	2501                	sext.w	a0,a0
    2642:	8082                	ret

0000000000002644 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2644:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2648:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    264c:	2501                	sext.w	a0,a0
    264e:	8082                	ret

0000000000002650 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2650:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2654:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2658:	2501                	sext.w	a0,a0
    265a:	8082                	ret

000000000000265c <semaphore_create>:
	register long a7 __asm__("a7") = n;
    265c:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2660:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2664:	2501                	sext.w	a0,a0
    2666:	8082                	ret

0000000000002668 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2668:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    266c:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2674:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2678:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2680:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2684:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <condvar_signal>:
	register long a7 __asm__("a7") = n;
    268c:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2690:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret

0000000000002698 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2698:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    269c:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26a0:	2501                	sext.w	a0,a0
    26a2:	8082                	ret

00000000000026a4 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26a4:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26a8:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret
