
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_sync_sem:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a245                	j	11a0 <__start_main>

0000000000001002 <first>:
#include <unistd.h>

int sem_sync_id;

void first()
{
    1002:	1101                	addi	sp,sp,-32
	sleep(10);
    1004:	4529                	li	a0,10
{
    1006:	ec06                	sd	ra,24(sp)
    1008:	e822                	sd	s0,16(sp)
    100a:	e426                	sd	s1,8(sp)
	sleep(10);
    100c:	5c2010ef          	jal	ra,25ce <sleep>
	puts("First work and wakeup Second");
    1010:	00001517          	auipc	a0,0x1
    1014:	7f850513          	addi	a0,a0,2040 # 2808 <enable_deadlock_detect+0xe>
    1018:	1f9000ef          	jal	ra,1a10 <puts>
	assert_eq(semaphore_up(sem_sync_id), 0);
    101c:	00002417          	auipc	s0,0x2
    1020:	a4440413          	addi	s0,s0,-1468 # 2a60 <sem_sync_id>
    1024:	4008                	lw	a0,0(s0)
    1026:	798010ef          	jal	ra,27be <semaphore_up>
    102a:	e901                	bnez	a0,103a <first+0x38>
	exit(0);
}
    102c:	6442                	ld	s0,16(sp)
    102e:	60e2                	ld	ra,24(sp)
    1030:	64a2                	ld	s1,8(sp)
	exit(0);
    1032:	4501                	li	a0,0
}
    1034:	6105                	addi	sp,sp,32
	exit(0);
    1036:	5260106f          	j	255c <exit>
	assert_eq(semaphore_up(sem_sync_id), 0);
    103a:	4f2010ef          	jal	ra,252c <getpid>
    103e:	84aa                	mv	s1,a0
    1040:	00001517          	auipc	a0,0x1
    1044:	7e850513          	addi	a0,a0,2024 # 2828 <enable_deadlock_detect+0x2e>
    1048:	3ba010ef          	jal	ra,2402 <basename>
    104c:	872a                	mv	a4,a0
    104e:	4008                	lw	a0,0(s0)
    1050:	843a                	mv	s0,a4
    1052:	76c010ef          	jal	ra,27be <semaphore_up>
    1056:	882a                	mv	a6,a0
    1058:	8722                	mv	a4,s0
    105a:	86a6                	mv	a3,s1
    105c:	4881                	li	a7,0
    105e:	00002517          	auipc	a0,0x2
    1062:	81a50513          	addi	a0,a0,-2022 # 2878 <enable_deadlock_detect+0x7e>
    1066:	47b5                	li	a5,13
    1068:	00002617          	auipc	a2,0x2
    106c:	80860613          	addi	a2,a2,-2040 # 2870 <enable_deadlock_detect+0x76>
    1070:	45fd                	li	a1,31
    1072:	288000ef          	jal	ra,12fa <printf>
    1076:	557d                	li	a0,-1
    1078:	4e4010ef          	jal	ra,255c <exit>
}
    107c:	6442                	ld	s0,16(sp)
    107e:	60e2                	ld	ra,24(sp)
    1080:	64a2                	ld	s1,8(sp)
	exit(0);
    1082:	4501                	li	a0,0
}
    1084:	6105                	addi	sp,sp,32
	exit(0);
    1086:	4d60106f          	j	255c <exit>

000000000000108a <second>:

void second()
{
    108a:	1101                	addi	sp,sp,-32
	puts("Second want to continue,but need to wait first");
    108c:	00002517          	auipc	a0,0x2
    1090:	82450513          	addi	a0,a0,-2012 # 28b0 <enable_deadlock_detect+0xb6>
{
    1094:	e822                	sd	s0,16(sp)
    1096:	ec06                	sd	ra,24(sp)
    1098:	e426                	sd	s1,8(sp)
	assert_eq(semaphore_down(sem_sync_id), 0);
    109a:	00002417          	auipc	s0,0x2
    109e:	9c640413          	addi	s0,s0,-1594 # 2a60 <sem_sync_id>
	puts("Second want to continue,but need to wait first");
    10a2:	16f000ef          	jal	ra,1a10 <puts>
	assert_eq(semaphore_down(sem_sync_id), 0);
    10a6:	4008                	lw	a0,0(s0)
    10a8:	722010ef          	jal	ra,27ca <semaphore_down>
    10ac:	ed11                	bnez	a0,10c8 <second+0x3e>
	puts("Second can work now");
    10ae:	00002517          	auipc	a0,0x2
    10b2:	83250513          	addi	a0,a0,-1998 # 28e0 <enable_deadlock_detect+0xe6>
    10b6:	15b000ef          	jal	ra,1a10 <puts>
	exit(0);
}
    10ba:	6442                	ld	s0,16(sp)
    10bc:	60e2                	ld	ra,24(sp)
    10be:	64a2                	ld	s1,8(sp)
	exit(0);
    10c0:	4501                	li	a0,0
}
    10c2:	6105                	addi	sp,sp,32
	exit(0);
    10c4:	4980106f          	j	255c <exit>
	assert_eq(semaphore_down(sem_sync_id), 0);
    10c8:	464010ef          	jal	ra,252c <getpid>
    10cc:	84aa                	mv	s1,a0
    10ce:	00001517          	auipc	a0,0x1
    10d2:	75a50513          	addi	a0,a0,1882 # 2828 <enable_deadlock_detect+0x2e>
    10d6:	32c010ef          	jal	ra,2402 <basename>
    10da:	872a                	mv	a4,a0
    10dc:	4008                	lw	a0,0(s0)
    10de:	843a                	mv	s0,a4
    10e0:	6ea010ef          	jal	ra,27ca <semaphore_down>
    10e4:	882a                	mv	a6,a0
    10e6:	4881                	li	a7,0
    10e8:	00001517          	auipc	a0,0x1
    10ec:	79050513          	addi	a0,a0,1936 # 2878 <enable_deadlock_detect+0x7e>
    10f0:	47d1                	li	a5,20
    10f2:	8722                	mv	a4,s0
    10f4:	86a6                	mv	a3,s1
    10f6:	00001617          	auipc	a2,0x1
    10fa:	77a60613          	addi	a2,a2,1914 # 2870 <enable_deadlock_detect+0x76>
    10fe:	45fd                	li	a1,31
    1100:	1fa000ef          	jal	ra,12fa <printf>
    1104:	557d                	li	a0,-1
    1106:	456010ef          	jal	ra,255c <exit>
    110a:	b755                	j	10ae <second+0x24>

000000000000110c <main>:

int main()
{
    110c:	1101                	addi	sp,sp,-32
	assert((sem_sync_id = semaphore_create(0)) >= 0);
    110e:	4501                	li	a0,0
{
    1110:	ec06                	sd	ra,24(sp)
    1112:	e822                	sd	s0,16(sp)
    1114:	e426                	sd	s1,8(sp)
	assert((sem_sync_id = semaphore_create(0)) >= 0);
    1116:	69c010ef          	jal	ra,27b2 <semaphore_create>
    111a:	00002797          	auipc	a5,0x2
    111e:	94a7a323          	sw	a0,-1722(a5) # 2a60 <sem_sync_id>
    1122:	04054463          	bltz	a0,116a <main+0x5e>
	int threads[2];
	threads[0] = thread_create(first, 0);
    1126:	4581                	li	a1,0
    1128:	00000517          	auipc	a0,0x0
    112c:	eda50513          	addi	a0,a0,-294 # 1002 <first>
    1130:	5de010ef          	jal	ra,270e <thread_create>
	threads[1] = thread_create(second, 0);
    1134:	4581                	li	a1,0
	threads[0] = thread_create(first, 0);
    1136:	84aa                	mv	s1,a0
	threads[1] = thread_create(second, 0);
    1138:	00000517          	auipc	a0,0x0
    113c:	f5250513          	addi	a0,a0,-174 # 108a <second>
    1140:	5ce010ef          	jal	ra,270e <thread_create>
    1144:	842a                	mv	s0,a0
	waittid(threads[0]);
    1146:	8526                	mv	a0,s1
    1148:	60a010ef          	jal	ra,2752 <waittid>
	waittid(threads[1]);
    114c:	8522                	mv	a0,s0
    114e:	604010ef          	jal	ra,2752 <waittid>
	puts("sync_sem passed!");
    1152:	00001517          	auipc	a0,0x1
    1156:	7fe50513          	addi	a0,a0,2046 # 2950 <enable_deadlock_detect+0x156>
    115a:	0b7000ef          	jal	ra,1a10 <puts>
	return 0;
    115e:	60e2                	ld	ra,24(sp)
    1160:	6442                	ld	s0,16(sp)
    1162:	64a2                	ld	s1,8(sp)
    1164:	4501                	li	a0,0
    1166:	6105                	addi	sp,sp,32
    1168:	8082                	ret
	assert((sem_sync_id = semaphore_create(0)) >= 0);
    116a:	3c2010ef          	jal	ra,252c <getpid>
    116e:	842a                	mv	s0,a0
    1170:	00001517          	auipc	a0,0x1
    1174:	6b850513          	addi	a0,a0,1720 # 2828 <enable_deadlock_detect+0x2e>
    1178:	28a010ef          	jal	ra,2402 <basename>
    117c:	872a                	mv	a4,a0
    117e:	47ed                	li	a5,27
    1180:	00001517          	auipc	a0,0x1
    1184:	77850513          	addi	a0,a0,1912 # 28f8 <enable_deadlock_detect+0xfe>
    1188:	86a2                	mv	a3,s0
    118a:	00001617          	auipc	a2,0x1
    118e:	6e660613          	addi	a2,a2,1766 # 2870 <enable_deadlock_detect+0x76>
    1192:	45fd                	li	a1,31
    1194:	166000ef          	jal	ra,12fa <printf>
    1198:	557d                	li	a0,-1
    119a:	3c2010ef          	jal	ra,255c <exit>
    119e:	b761                	j	1126 <main+0x1a>

00000000000011a0 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    11a0:	1141                	addi	sp,sp,-16
    11a2:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    11a4:	f69ff0ef          	jal	ra,110c <main>
    11a8:	3b4010ef          	jal	ra,255c <exit>
	return 0;
    11ac:	60a2                	ld	ra,8(sp)
    11ae:	4501                	li	a0,0
    11b0:	0141                	addi	sp,sp,16
    11b2:	8082                	ret

00000000000011b4 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    11b4:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    11b6:	4605                	li	a2,1
    11b8:	00f10593          	addi	a1,sp,15
    11bc:	4501                	li	a0,0
{
    11be:	ec06                	sd	ra,24(sp)
	char byte = 0;
    11c0:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    11c4:	354010ef          	jal	ra,2518 <read>
    11c8:	4785                	li	a5,1
    11ca:	00f51763          	bne	a0,a5,11d8 <getchar+0x24>
		return byte;
    11ce:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    11d2:	60e2                	ld	ra,24(sp)
    11d4:	6105                	addi	sp,sp,32
    11d6:	8082                	ret
		return EOF;
    11d8:	557d                	li	a0,-1
    11da:	bfe5                	j	11d2 <getchar+0x1e>

00000000000011dc <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    11dc:	00002517          	auipc	a0,0x2
    11e0:	88c52503          	lw	a0,-1908(a0) # 2a68 <buffer_len>
    11e4:	e111                	bnez	a0,11e8 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    11e6:	8082                	ret
{
    11e8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11ea:	862a                	mv	a2,a0
    11ec:	00002597          	auipc	a1,0x2
    11f0:	88458593          	addi	a1,a1,-1916 # 2a70 <buffer>
    11f4:	4505                	li	a0,1
{
    11f6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11f8:	32a010ef          	jal	ra,2522 <write>
}
    11fc:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11fe:	2501                	sext.w	a0,a0
}
    1200:	0141                	addi	sp,sp,16
    1202:	8082                	ret

0000000000001204 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1204:	00002797          	auipc	a5,0x2
    1208:	8607a223          	sw	zero,-1948(a5) # 2a68 <buffer_len>
}
    120c:	8082                	ret

000000000000120e <__fflush>:
	if (buffer_len == 0)
    120e:	00002517          	auipc	a0,0x2
    1212:	85a52503          	lw	a0,-1958(a0) # 2a68 <buffer_len>
    1216:	e511                	bnez	a0,1222 <__fflush+0x14>
	buffer_len = 0;
    1218:	00002797          	auipc	a5,0x2
    121c:	8407a823          	sw	zero,-1968(a5) # 2a68 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1220:	8082                	ret
{
    1222:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1224:	862a                	mv	a2,a0
    1226:	00002597          	auipc	a1,0x2
    122a:	84a58593          	addi	a1,a1,-1974 # 2a70 <buffer>
    122e:	4505                	li	a0,1
{
    1230:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1232:	2f0010ef          	jal	ra,2522 <write>
	return r >= 0 ? 0 : r;
    1236:	0005079b          	sext.w	a5,a0
}
    123a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    123c:	0017a793          	slti	a5,a5,1
    1240:	40f007bb          	negw	a5,a5
    1244:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1246:	00002797          	auipc	a5,0x2
    124a:	8207a123          	sw	zero,-2014(a5) # 2a68 <buffer_len>
	return r >= 0 ? 0 : r;
    124e:	2501                	sext.w	a0,a0
}
    1250:	0141                	addi	sp,sp,16
    1252:	8082                	ret

0000000000001254 <fflush>:

int fflush(int fd)
{
    1254:	1101                	addi	sp,sp,-32
    1256:	e822                	sd	s0,16(sp)
    1258:	ec06                	sd	ra,24(sp)
    125a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    125c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    125e:	4401                	li	s0,0
	if (fd == 1) {
    1260:	00e50863          	beq	a0,a4,1270 <fflush+0x1c>
}
    1264:	60e2                	ld	ra,24(sp)
    1266:	8522                	mv	a0,s0
    1268:	6442                	ld	s0,16(sp)
    126a:	64a2                	ld	s1,8(sp)
    126c:	6105                	addi	sp,sp,32
    126e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1270:	00001497          	auipc	s1,0x1
    1274:	7f848493          	addi	s1,s1,2040 # 2a68 <buffer_len>
    1278:	1084a703          	lw	a4,264(s1)
    127c:	02a70e63          	beq	a4,a0,12b8 <fflush+0x64>
	if (buffer_len == 0)
    1280:	4080                	lw	s0,0(s1)
    1282:	c00d                	beqz	s0,12a4 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1284:	8622                	mv	a2,s0
    1286:	00001597          	auipc	a1,0x1
    128a:	7ea58593          	addi	a1,a1,2026 # 2a70 <buffer>
    128e:	294010ef          	jal	ra,2522 <write>
	return r >= 0 ? 0 : r;
    1292:	0005079b          	sext.w	a5,a0
    1296:	0017a793          	slti	a5,a5,1
    129a:	40f007bb          	negw	a5,a5
    129e:	8d7d                	and	a0,a0,a5
    12a0:	0005041b          	sext.w	s0,a0
}
    12a4:	60e2                	ld	ra,24(sp)
    12a6:	8522                	mv	a0,s0
    12a8:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    12aa:	00001797          	auipc	a5,0x1
    12ae:	7a07af23          	sw	zero,1982(a5) # 2a68 <buffer_len>
}
    12b2:	64a2                	ld	s1,8(sp)
    12b4:	6105                	addi	sp,sp,32
    12b6:	8082                	ret
			mutex_lock(buffer_lock);
    12b8:	10c4a503          	lw	a0,268(s1)
    12bc:	4de010ef          	jal	ra,279a <mutex_lock>
	if (buffer_len == 0)
    12c0:	4080                	lw	s0,0(s1)
    12c2:	e811                	bnez	s0,12d6 <fflush+0x82>
			mutex_unlock(buffer_lock);
    12c4:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    12c8:	00001797          	auipc	a5,0x1
    12cc:	7a07a023          	sw	zero,1952(a5) # 2a68 <buffer_len>
			mutex_unlock(buffer_lock);
    12d0:	4d6010ef          	jal	ra,27a6 <mutex_unlock>
    12d4:	bf41                	j	1264 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    12d6:	8622                	mv	a2,s0
    12d8:	00001597          	auipc	a1,0x1
    12dc:	79858593          	addi	a1,a1,1944 # 2a70 <buffer>
    12e0:	4505                	li	a0,1
    12e2:	240010ef          	jal	ra,2522 <write>
	return r >= 0 ? 0 : r;
    12e6:	0005079b          	sext.w	a5,a0
    12ea:	0017a793          	slti	a5,a5,1
    12ee:	40f007bb          	negw	a5,a5
    12f2:	8d7d                	and	a0,a0,a5
    12f4:	0005041b          	sext.w	s0,a0
	return r;
    12f8:	b7f1                	j	12c4 <fflush+0x70>

00000000000012fa <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    12fa:	7131                	addi	sp,sp,-192
    12fc:	e0da                	sd	s6,64(sp)
    12fe:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1300:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1302:	013c                	addi	a5,sp,136
{
    1304:	f0ca                	sd	s2,96(sp)
    1306:	ecce                	sd	s3,88(sp)
    1308:	e8d2                	sd	s4,80(sp)
    130a:	e4d6                	sd	s5,72(sp)
    130c:	fc86                	sd	ra,120(sp)
    130e:	f8a2                	sd	s0,112(sp)
    1310:	f4a6                	sd	s1,104(sp)
    1312:	89aa                	mv	s3,a0
    1314:	e52e                	sd	a1,136(sp)
    1316:	e932                	sd	a2,144(sp)
    1318:	ed36                	sd	a3,152(sp)
    131a:	f13a                	sd	a4,160(sp)
    131c:	f942                	sd	a6,176(sp)
    131e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1320:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1322:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1326:	00001a17          	auipc	s4,0x1
    132a:	742a0a13          	addi	s4,s4,1858 # 2a68 <buffer_len>
    132e:	4a85                	li	s5,1
	buf[i++] = '0';
    1330:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1334:	0009c783          	lbu	a5,0(s3)
    1338:	18078663          	beqz	a5,14c4 <printf+0x1ca>
    133c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    133e:	19278d63          	beq	a5,s2,14d8 <printf+0x1de>
    1342:	0015c783          	lbu	a5,1(a1)
    1346:	0585                	addi	a1,a1,1
    1348:	fbfd                	bnez	a5,133e <printf+0x44>
    134a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    134c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1350:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1354:	1b578863          	beq	a5,s5,1504 <printf+0x20a>
		len = out_unlocked(s, l);
    1358:	85a2                	mv	a1,s0
    135a:	854e                	mv	a0,s3
    135c:	42a000ef          	jal	ra,1786 <out_unlocked>
		out(f, a, l);
		if (l)
    1360:	1c041063          	bnez	s0,1520 <printf+0x226>
			continue;
		if (s[1] == 0)
    1364:	0014c783          	lbu	a5,1(s1)
    1368:	14078e63          	beqz	a5,14c4 <printf+0x1ca>
			break;
		switch (s[1]) {
    136c:	07300713          	li	a4,115
    1370:	1ce78863          	beq	a5,a4,1540 <printf+0x246>
    1374:	1af76863          	bltu	a4,a5,1524 <printf+0x22a>
    1378:	06400713          	li	a4,100
    137c:	22e78063          	beq	a5,a4,159c <printf+0x2a2>
    1380:	07000713          	li	a4,112
    1384:	1ee79563          	bne	a5,a4,156e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1388:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    138a:	00001797          	auipc	a5,0x1
    138e:	7ee78793          	addi	a5,a5,2030 # 2b78 <digits>
	buf[i++] = '0';
    1392:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1396:	6298                	ld	a4,0(a3)
    1398:	06a1                	addi	a3,a3,8
    139a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    139c:	00471393          	slli	t2,a4,0x4
    13a0:	00871293          	slli	t0,a4,0x8
    13a4:	00c71f93          	slli	t6,a4,0xc
    13a8:	01071f13          	slli	t5,a4,0x10
    13ac:	01471e93          	slli	t4,a4,0x14
    13b0:	01871e13          	slli	t3,a4,0x18
    13b4:	01c71893          	slli	a7,a4,0x1c
    13b8:	02471813          	slli	a6,a4,0x24
    13bc:	02871513          	slli	a0,a4,0x28
    13c0:	02c71593          	slli	a1,a4,0x2c
    13c4:	03071613          	slli	a2,a4,0x30
    13c8:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13cc:	03c75413          	srli	s0,a4,0x3c
    13d0:	01c7531b          	srliw	t1,a4,0x1c
    13d4:	03c3d393          	srli	t2,t2,0x3c
    13d8:	03c2d293          	srli	t0,t0,0x3c
    13dc:	03cfdf93          	srli	t6,t6,0x3c
    13e0:	03cf5f13          	srli	t5,t5,0x3c
    13e4:	03cede93          	srli	t4,t4,0x3c
    13e8:	03ce5e13          	srli	t3,t3,0x3c
    13ec:	03c8d893          	srli	a7,a7,0x3c
    13f0:	03c85813          	srli	a6,a6,0x3c
    13f4:	9171                	srli	a0,a0,0x3c
    13f6:	91f1                	srli	a1,a1,0x3c
    13f8:	9271                	srli	a2,a2,0x3c
    13fa:	92f1                	srli	a3,a3,0x3c
    13fc:	95be                	add	a1,a1,a5
    13fe:	963e                	add	a2,a2,a5
    1400:	96be                	add	a3,a3,a5
    1402:	943e                	add	s0,s0,a5
    1404:	93be                	add	t2,t2,a5
    1406:	92be                	add	t0,t0,a5
    1408:	9fbe                	add	t6,t6,a5
    140a:	9f3e                	add	t5,t5,a5
    140c:	9ebe                	add	t4,t4,a5
    140e:	9e3e                	add	t3,t3,a5
    1410:	98be                	add	a7,a7,a5
    1412:	933e                	add	t1,t1,a5
    1414:	983e                	add	a6,a6,a5
    1416:	953e                	add	a0,a0,a5
    1418:	0005c983          	lbu	s3,0(a1)
    141c:	00044403          	lbu	s0,0(s0)
    1420:	00064583          	lbu	a1,0(a2)
    1424:	0003c383          	lbu	t2,0(t2)
    1428:	0006c603          	lbu	a2,0(a3)
    142c:	0002c283          	lbu	t0,0(t0)
    1430:	000fcf83          	lbu	t6,0(t6)
    1434:	000f4f03          	lbu	t5,0(t5)
    1438:	000ece83          	lbu	t4,0(t4)
    143c:	000e4e03          	lbu	t3,0(t3)
    1440:	0008c883          	lbu	a7,0(a7)
    1444:	00034303          	lbu	t1,0(t1)
    1448:	00084803          	lbu	a6,0(a6)
    144c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1450:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1454:	92f1                	srli	a3,a3,0x3c
    1456:	8b3d                	andi	a4,a4,15
    1458:	96be                	add	a3,a3,a5
    145a:	97ba                	add	a5,a5,a4
    145c:	00810d23          	sb	s0,26(sp)
    1460:	00710da3          	sb	t2,27(sp)
    1464:	00510e23          	sb	t0,28(sp)
    1468:	01f10ea3          	sb	t6,29(sp)
    146c:	01e10f23          	sb	t5,30(sp)
    1470:	01d10fa3          	sb	t4,31(sp)
    1474:	03c10023          	sb	t3,32(sp)
    1478:	031100a3          	sb	a7,33(sp)
    147c:	02610123          	sb	t1,34(sp)
    1480:	030101a3          	sb	a6,35(sp)
    1484:	02a10223          	sb	a0,36(sp)
    1488:	033102a3          	sb	s3,37(sp)
    148c:	02b10323          	sb	a1,38(sp)
    1490:	02c103a3          	sb	a2,39(sp)
    1494:	0006c683          	lbu	a3,0(a3)
    1498:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    149c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14a0:	02d10423          	sb	a3,40(sp)
    14a4:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    14a8:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    14ac:	11578263          	beq	a5,s5,15b0 <printf+0x2b6>
		len = out_unlocked(s, l);
    14b0:	45c9                	li	a1,18
    14b2:	0828                	addi	a0,sp,24
    14b4:	2d2000ef          	jal	ra,1786 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    14b8:	00248993          	addi	s3,s1,2
		if (!*s)
    14bc:	0009c783          	lbu	a5,0(s3)
    14c0:	e6079ee3          	bnez	a5,133c <printf+0x42>
	}
	va_end(ap);
    14c4:	70e6                	ld	ra,120(sp)
    14c6:	7446                	ld	s0,112(sp)
    14c8:	74a6                	ld	s1,104(sp)
    14ca:	7906                	ld	s2,96(sp)
    14cc:	69e6                	ld	s3,88(sp)
    14ce:	6a46                	ld	s4,80(sp)
    14d0:	6aa6                	ld	s5,72(sp)
    14d2:	6b06                	ld	s6,64(sp)
    14d4:	6129                	addi	sp,sp,192
    14d6:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    14d8:	0005c783          	lbu	a5,0(a1)
    14dc:	84ae                	mv	s1,a1
    14de:	01278963          	beq	a5,s2,14f0 <printf+0x1f6>
    14e2:	b5ad                	j	134c <printf+0x52>
    14e4:	0024c783          	lbu	a5,2(s1)
    14e8:	0585                	addi	a1,a1,1
    14ea:	0489                	addi	s1,s1,2
    14ec:	e72790e3          	bne	a5,s2,134c <printf+0x52>
    14f0:	0014c783          	lbu	a5,1(s1)
    14f4:	ff2788e3          	beq	a5,s2,14e4 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    14f8:	108a2783          	lw	a5,264(s4)
		l = z - a;
    14fc:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1500:	e5579ce3          	bne	a5,s5,1358 <printf+0x5e>
		mutex_lock(buffer_lock);
    1504:	10ca2503          	lw	a0,268(s4)
    1508:	292010ef          	jal	ra,279a <mutex_lock>
		len = out_unlocked(s, l);
    150c:	85a2                	mv	a1,s0
    150e:	854e                	mv	a0,s3
    1510:	276000ef          	jal	ra,1786 <out_unlocked>
		mutex_unlock(buffer_lock);
    1514:	10ca2503          	lw	a0,268(s4)
    1518:	28e010ef          	jal	ra,27a6 <mutex_unlock>
		if (l)
    151c:	e40404e3          	beqz	s0,1364 <printf+0x6a>
    1520:	89a6                	mv	s3,s1
    1522:	bd09                	j	1334 <printf+0x3a>
		switch (s[1]) {
    1524:	07800713          	li	a4,120
    1528:	04e79363          	bne	a5,a4,156e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    152c:	67c2                	ld	a5,16(sp)
    152e:	45c1                	li	a1,16
		s += 2;
    1530:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1534:	4388                	lw	a0,0(a5)
    1536:	07a1                	addi	a5,a5,8
    1538:	e83e                	sd	a5,16(sp)
    153a:	5f8000ef          	jal	ra,1b32 <printint.constprop.0>
		s += 2;
    153e:	bfbd                	j	14bc <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1540:	67c2                	ld	a5,16(sp)
    1542:	6380                	ld	s0,0(a5)
    1544:	07a1                	addi	a5,a5,8
    1546:	e83e                	sd	a5,16(sp)
    1548:	1c040163          	beqz	s0,170a <printf+0x410>
			l = strnlen(a, 200);
    154c:	0c800593          	li	a1,200
    1550:	8522                	mv	a0,s0
    1552:	3f7000ef          	jal	ra,2148 <strnlen>
	if (buffer_lock_enabled == 1) {
    1556:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    155a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    155e:	19578663          	beq	a5,s5,16ea <printf+0x3f0>
		len = out_unlocked(s, l);
    1562:	8522                	mv	a0,s0
    1564:	222000ef          	jal	ra,1786 <out_unlocked>
		s += 2;
    1568:	00248993          	addi	s3,s1,2
    156c:	bf81                	j	14bc <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    156e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1572:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1576:	0f578663          	beq	a5,s5,1662 <printf+0x368>
		len = out_unlocked(s, l);
    157a:	0828                	addi	a0,sp,24
    157c:	316000ef          	jal	ra,1892 <out_unlocked.constprop.0>
			putchar(s[1]);
    1580:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1584:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1588:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    158c:	05578163          	beq	a5,s5,15ce <printf+0x2d4>
		len = out_unlocked(s, l);
    1590:	0828                	addi	a0,sp,24
    1592:	300000ef          	jal	ra,1892 <out_unlocked.constprop.0>
		s += 2;
    1596:	00248993          	addi	s3,s1,2
    159a:	b70d                	j	14bc <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    159c:	67c2                	ld	a5,16(sp)
    159e:	45a9                	li	a1,10
		s += 2;
    15a0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    15a4:	4388                	lw	a0,0(a5)
    15a6:	07a1                	addi	a5,a5,8
    15a8:	e83e                	sd	a5,16(sp)
    15aa:	588000ef          	jal	ra,1b32 <printint.constprop.0>
		s += 2;
    15ae:	b739                	j	14bc <printf+0x1c2>
		mutex_lock(buffer_lock);
    15b0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15b4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15b8:	1e2010ef          	jal	ra,279a <mutex_lock>
		len = out_unlocked(s, l);
    15bc:	45c9                	li	a1,18
    15be:	0828                	addi	a0,sp,24
    15c0:	1c6000ef          	jal	ra,1786 <out_unlocked>
		mutex_unlock(buffer_lock);
    15c4:	10ca2503          	lw	a0,268(s4)
    15c8:	1de010ef          	jal	ra,27a6 <mutex_unlock>
		s += 2;
    15cc:	bdc5                	j	14bc <printf+0x1c2>
		mutex_lock(buffer_lock);
    15ce:	10ca2503          	lw	a0,268(s4)
    15d2:	1c8010ef          	jal	ra,279a <mutex_lock>
		buffer[buffer_len++] = c;
    15d6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15da:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15de:	0017861b          	addiw	a2,a5,1
    15e2:	97d2                	add	a5,a5,s4
    15e4:	00ca2023          	sw	a2,0(s4)
    15e8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15ec:	00c6cc63          	blt	a3,a2,1604 <printf+0x30a>
    15f0:	47a9                	li	a5,10
    15f2:	06f40663          	beq	s0,a5,165e <printf+0x364>
		mutex_unlock(buffer_lock);
    15f6:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15fa:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    15fe:	1a8010ef          	jal	ra,27a6 <mutex_unlock>
		s += 2;
    1602:	bd6d                	j	14bc <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1604:	10000793          	li	a5,256
    1608:	00f61e63          	bne	a2,a5,1624 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    160c:	00001597          	auipc	a1,0x1
    1610:	46458593          	addi	a1,a1,1124 # 2a70 <buffer>
    1614:	4505                	li	a0,1
    1616:	70d000ef          	jal	ra,2522 <write>
	buffer_len = 0;
    161a:	00001797          	auipc	a5,0x1
    161e:	4407a723          	sw	zero,1102(a5) # 2a68 <buffer_len>
			if (r < 0) {
    1622:	bfd1                	j	15f6 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1624:	709000ef          	jal	ra,252c <getpid>
    1628:	842a                	mv	s0,a0
    162a:	00001517          	auipc	a0,0x1
    162e:	34650513          	addi	a0,a0,838 # 2970 <enable_deadlock_detect+0x176>
    1632:	5d1000ef          	jal	ra,2402 <basename>
    1636:	872a                	mv	a4,a0
    1638:	00001617          	auipc	a2,0x1
    163c:	23860613          	addi	a2,a2,568 # 2870 <enable_deadlock_detect+0x76>
    1640:	05400793          	li	a5,84
    1644:	86a2                	mv	a3,s0
    1646:	45fd                	li	a1,31
    1648:	00001517          	auipc	a0,0x1
    164c:	36850513          	addi	a0,a0,872 # 29b0 <enable_deadlock_detect+0x1b6>
    1650:	cabff0ef          	jal	ra,12fa <printf>
    1654:	557d                	li	a0,-1
    1656:	707000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    165a:	000a2603          	lw	a2,0(s4)
    165e:	de41                	beqz	a2,15f6 <printf+0x2fc>
    1660:	b775                	j	160c <printf+0x312>
		mutex_lock(buffer_lock);
    1662:	10ca2503          	lw	a0,268(s4)
    1666:	134010ef          	jal	ra,279a <mutex_lock>
		buffer[buffer_len++] = c;
    166a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    166e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1672:	0017861b          	addiw	a2,a5,1
    1676:	97d2                	add	a5,a5,s4
    1678:	00ca2023          	sw	a2,0(s4)
    167c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1680:	02c6d163          	bge	a3,a2,16a2 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1684:	10000793          	li	a5,256
    1688:	02f61263          	bne	a2,a5,16ac <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    168c:	00001597          	auipc	a1,0x1
    1690:	3e458593          	addi	a1,a1,996 # 2a70 <buffer>
    1694:	4505                	li	a0,1
    1696:	68d000ef          	jal	ra,2522 <write>
	buffer_len = 0;
    169a:	00001797          	auipc	a5,0x1
    169e:	3c07a723          	sw	zero,974(a5) # 2a68 <buffer_len>
		mutex_unlock(buffer_lock);
    16a2:	10ca2503          	lw	a0,268(s4)
    16a6:	100010ef          	jal	ra,27a6 <mutex_unlock>
    16aa:	bdd9                	j	1580 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    16ac:	681000ef          	jal	ra,252c <getpid>
    16b0:	842a                	mv	s0,a0
    16b2:	00001517          	auipc	a0,0x1
    16b6:	2be50513          	addi	a0,a0,702 # 2970 <enable_deadlock_detect+0x176>
    16ba:	549000ef          	jal	ra,2402 <basename>
    16be:	872a                	mv	a4,a0
    16c0:	00001617          	auipc	a2,0x1
    16c4:	1b060613          	addi	a2,a2,432 # 2870 <enable_deadlock_detect+0x76>
    16c8:	05400793          	li	a5,84
    16cc:	86a2                	mv	a3,s0
    16ce:	45fd                	li	a1,31
    16d0:	00001517          	auipc	a0,0x1
    16d4:	2e050513          	addi	a0,a0,736 # 29b0 <enable_deadlock_detect+0x1b6>
    16d8:	c23ff0ef          	jal	ra,12fa <printf>
    16dc:	557d                	li	a0,-1
    16de:	67f000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    16e2:	000a2603          	lw	a2,0(s4)
    16e6:	de55                	beqz	a2,16a2 <printf+0x3a8>
    16e8:	b755                	j	168c <printf+0x392>
		mutex_lock(buffer_lock);
    16ea:	10ca2503          	lw	a0,268(s4)
    16ee:	e42e                	sd	a1,8(sp)
		s += 2;
    16f0:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16f4:	0a6010ef          	jal	ra,279a <mutex_lock>
		len = out_unlocked(s, l);
    16f8:	65a2                	ld	a1,8(sp)
    16fa:	8522                	mv	a0,s0
    16fc:	08a000ef          	jal	ra,1786 <out_unlocked>
		mutex_unlock(buffer_lock);
    1700:	10ca2503          	lw	a0,268(s4)
    1704:	0a2010ef          	jal	ra,27a6 <mutex_unlock>
		s += 2;
    1708:	bb55                	j	14bc <printf+0x1c2>
				a = "(null)";
    170a:	00001417          	auipc	s0,0x1
    170e:	25e40413          	addi	s0,s0,606 # 2968 <enable_deadlock_detect+0x16e>
    1712:	bd2d                	j	154c <printf+0x252>

0000000000001714 <enable_thread_io_buffer>:
{
    1714:	1101                	addi	sp,sp,-32
    1716:	e822                	sd	s0,16(sp)
    1718:	ec06                	sd	ra,24(sp)
    171a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    171c:	00001417          	auipc	s0,0x1
    1720:	34c40413          	addi	s0,s0,844 # 2a68 <buffer_len>
    1724:	05a010ef          	jal	ra,277e <mutex_create>
    1728:	10a42623          	sw	a0,268(s0)
    172c:	00054a63          	bltz	a0,1740 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1730:	4785                	li	a5,1
}
    1732:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1734:	10f42423          	sw	a5,264(s0)
}
    1738:	6442                	ld	s0,16(sp)
    173a:	64a2                	ld	s1,8(sp)
    173c:	6105                	addi	sp,sp,32
    173e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1740:	5ed000ef          	jal	ra,252c <getpid>
    1744:	84aa                	mv	s1,a0
    1746:	00001517          	auipc	a0,0x1
    174a:	22a50513          	addi	a0,a0,554 # 2970 <enable_deadlock_detect+0x176>
    174e:	4b5000ef          	jal	ra,2402 <basename>
    1752:	872a                	mv	a4,a0
    1754:	04800793          	li	a5,72
    1758:	86a6                	mv	a3,s1
    175a:	00001517          	auipc	a0,0x1
    175e:	29650513          	addi	a0,a0,662 # 29f0 <enable_deadlock_detect+0x1f6>
    1762:	00001617          	auipc	a2,0x1
    1766:	10e60613          	addi	a2,a2,270 # 2870 <enable_deadlock_detect+0x76>
    176a:	45fd                	li	a1,31
    176c:	b8fff0ef          	jal	ra,12fa <printf>
    1770:	557d                	li	a0,-1
    1772:	5eb000ef          	jal	ra,255c <exit>
	buffer_lock_enabled = 1;
    1776:	4785                	li	a5,1
}
    1778:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    177a:	10f42423          	sw	a5,264(s0)
}
    177e:	6442                	ld	s0,16(sp)
    1780:	64a2                	ld	s1,8(sp)
    1782:	6105                	addi	sp,sp,32
    1784:	8082                	ret

0000000000001786 <out_unlocked>:
{
    1786:	7159                	addi	sp,sp,-112
    1788:	f486                	sd	ra,104(sp)
    178a:	f0a2                	sd	s0,96(sp)
    178c:	eca6                	sd	s1,88(sp)
    178e:	e8ca                	sd	s2,80(sp)
    1790:	e4ce                	sd	s3,72(sp)
    1792:	e0d2                	sd	s4,64(sp)
    1794:	fc56                	sd	s5,56(sp)
    1796:	f85a                	sd	s6,48(sp)
    1798:	f45e                	sd	s7,40(sp)
    179a:	f062                	sd	s8,32(sp)
    179c:	ec66                	sd	s9,24(sp)
    179e:	e86a                	sd	s10,16(sp)
    17a0:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    17a2:	0e058663          	beqz	a1,188e <out_unlocked+0x108>
    17a6:	842a                	mv	s0,a0
    17a8:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    17ac:	4981                	li	s3,0
    17ae:	00001d17          	auipc	s10,0x1
    17b2:	2bad0d13          	addi	s10,s10,698 # 2a68 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17b6:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    17ba:	00001b17          	auipc	s6,0x1
    17be:	2b6b0b13          	addi	s6,s6,694 # 2a70 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    17c2:	10000a93          	li	s5,256
    17c6:	00001c97          	auipc	s9,0x1
    17ca:	1aac8c93          	addi	s9,s9,426 # 2970 <enable_deadlock_detect+0x176>
    17ce:	00001c17          	auipc	s8,0x1
    17d2:	0a2c0c13          	addi	s8,s8,162 # 2870 <enable_deadlock_detect+0x76>
    17d6:	00001b97          	auipc	s7,0x1
    17da:	1dab8b93          	addi	s7,s7,474 # 29b0 <enable_deadlock_detect+0x1b6>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17de:	4a29                	li	s4,10
    17e0:	a031                	j	17ec <out_unlocked+0x66>
    17e2:	09468863          	beq	a3,s4,1872 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    17e6:	0405                	addi	s0,s0,1
    17e8:	04848163          	beq	s1,s0,182a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    17ec:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    17f0:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    17f4:	0017861b          	addiw	a2,a5,1
    17f8:	97ea                	add	a5,a5,s10
    17fa:	00cd2023          	sw	a2,0(s10)
    17fe:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1802:	fec950e3          	bge	s2,a2,17e2 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1806:	05561263          	bne	a2,s5,184a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    180a:	85da                	mv	a1,s6
    180c:	4505                	li	a0,1
    180e:	515000ef          	jal	ra,2522 <write>
    1812:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1814:	00001797          	auipc	a5,0x1
    1818:	2407aa23          	sw	zero,596(a5) # 2a68 <buffer_len>
			if (r < 0) {
    181c:	06054763          	bltz	a0,188a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1820:	0405                	addi	s0,s0,1
			ret += r;
    1822:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1826:	fc8493e3          	bne	s1,s0,17ec <out_unlocked+0x66>
}
    182a:	70a6                	ld	ra,104(sp)
    182c:	7406                	ld	s0,96(sp)
    182e:	64e6                	ld	s1,88(sp)
    1830:	6946                	ld	s2,80(sp)
    1832:	6a06                	ld	s4,64(sp)
    1834:	7ae2                	ld	s5,56(sp)
    1836:	7b42                	ld	s6,48(sp)
    1838:	7ba2                	ld	s7,40(sp)
    183a:	7c02                	ld	s8,32(sp)
    183c:	6ce2                	ld	s9,24(sp)
    183e:	6d42                	ld	s10,16(sp)
    1840:	6da2                	ld	s11,8(sp)
    1842:	854e                	mv	a0,s3
    1844:	69a6                	ld	s3,72(sp)
    1846:	6165                	addi	sp,sp,112
    1848:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    184a:	4e3000ef          	jal	ra,252c <getpid>
    184e:	8daa                	mv	s11,a0
    1850:	8566                	mv	a0,s9
    1852:	3b1000ef          	jal	ra,2402 <basename>
    1856:	872a                	mv	a4,a0
    1858:	8662                	mv	a2,s8
    185a:	05400793          	li	a5,84
    185e:	86ee                	mv	a3,s11
    1860:	45fd                	li	a1,31
    1862:	855e                	mv	a0,s7
    1864:	a97ff0ef          	jal	ra,12fa <printf>
    1868:	557d                	li	a0,-1
    186a:	4f3000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    186e:	000d2603          	lw	a2,0(s10)
    1872:	da35                	beqz	a2,17e6 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1874:	85da                	mv	a1,s6
    1876:	4505                	li	a0,1
    1878:	4ab000ef          	jal	ra,2522 <write>
    187c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    187e:	00001797          	auipc	a5,0x1
    1882:	1e07a523          	sw	zero,490(a5) # 2a68 <buffer_len>
			if (r < 0) {
    1886:	f8055de3          	bgez	a0,1820 <out_unlocked+0x9a>
    188a:	89aa                	mv	s3,a0
    188c:	bf79                	j	182a <out_unlocked+0xa4>
	int ret = 0;
    188e:	4981                	li	s3,0
    1890:	bf69                	j	182a <out_unlocked+0xa4>

0000000000001892 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1892:	1101                	addi	sp,sp,-32
    1894:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1896:	00001497          	auipc	s1,0x1
    189a:	1d248493          	addi	s1,s1,466 # 2a68 <buffer_len>
    189e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    18a0:	ec06                	sd	ra,24(sp)
    18a2:	e822                	sd	s0,16(sp)
		char c = s[i];
    18a4:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    18a8:	0017861b          	addiw	a2,a5,1
    18ac:	97a6                	add	a5,a5,s1
    18ae:	00e78423          	sb	a4,8(a5)
    18b2:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b4:	0ff00793          	li	a5,255
    18b8:	00c7cc63          	blt	a5,a2,18d0 <out_unlocked.constprop.0+0x3e>
    18bc:	47a9                	li	a5,10
    18be:	06f70c63          	beq	a4,a5,1936 <out_unlocked.constprop.0+0xa4>
    18c2:	4601                	li	a2,0
}
    18c4:	60e2                	ld	ra,24(sp)
    18c6:	6442                	ld	s0,16(sp)
    18c8:	64a2                	ld	s1,8(sp)
    18ca:	8532                	mv	a0,a2
    18cc:	6105                	addi	sp,sp,32
    18ce:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18d0:	10000793          	li	a5,256
    18d4:	02f61563          	bne	a2,a5,18fe <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    18d8:	00001597          	auipc	a1,0x1
    18dc:	19858593          	addi	a1,a1,408 # 2a70 <buffer>
    18e0:	4505                	li	a0,1
    18e2:	441000ef          	jal	ra,2522 <write>
}
    18e6:	60e2                	ld	ra,24(sp)
    18e8:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    18ea:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18ee:	00001797          	auipc	a5,0x1
    18f2:	1607ad23          	sw	zero,378(a5) # 2a68 <buffer_len>
}
    18f6:	64a2                	ld	s1,8(sp)
    18f8:	8532                	mv	a0,a2
    18fa:	6105                	addi	sp,sp,32
    18fc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18fe:	42f000ef          	jal	ra,252c <getpid>
    1902:	842a                	mv	s0,a0
    1904:	00001517          	auipc	a0,0x1
    1908:	06c50513          	addi	a0,a0,108 # 2970 <enable_deadlock_detect+0x176>
    190c:	2f7000ef          	jal	ra,2402 <basename>
    1910:	872a                	mv	a4,a0
    1912:	00001617          	auipc	a2,0x1
    1916:	f5e60613          	addi	a2,a2,-162 # 2870 <enable_deadlock_detect+0x76>
    191a:	05400793          	li	a5,84
    191e:	86a2                	mv	a3,s0
    1920:	45fd                	li	a1,31
    1922:	00001517          	auipc	a0,0x1
    1926:	08e50513          	addi	a0,a0,142 # 29b0 <enable_deadlock_detect+0x1b6>
    192a:	9d1ff0ef          	jal	ra,12fa <printf>
    192e:	557d                	li	a0,-1
    1930:	42d000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    1934:	4090                	lw	a2,0(s1)
    1936:	d659                	beqz	a2,18c4 <out_unlocked.constprop.0+0x32>
    1938:	b745                	j	18d8 <out_unlocked.constprop.0+0x46>

000000000000193a <putchar>:
{
    193a:	7139                	addi	sp,sp,-64
    193c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    193e:	00001497          	auipc	s1,0x1
    1942:	12a48493          	addi	s1,s1,298 # 2a68 <buffer_len>
    1946:	1084a703          	lw	a4,264(s1)
{
    194a:	f822                	sd	s0,48(sp)
	char byte = c;
    194c:	0ff57413          	zext.b	s0,a0
{
    1950:	fc06                	sd	ra,56(sp)
	char byte = c;
    1952:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1956:	4785                	li	a5,1
    1958:	00f70d63          	beq	a4,a5,1972 <putchar+0x38>
		len = out_unlocked(s, l);
    195c:	01f10513          	addi	a0,sp,31
    1960:	f33ff0ef          	jal	ra,1892 <out_unlocked.constprop.0>
}
    1964:	70e2                	ld	ra,56(sp)
    1966:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1968:	862a                	mv	a2,a0
}
    196a:	74a2                	ld	s1,40(sp)
    196c:	8532                	mv	a0,a2
    196e:	6121                	addi	sp,sp,64
    1970:	8082                	ret
		mutex_lock(buffer_lock);
    1972:	10c4a503          	lw	a0,268(s1)
    1976:	625000ef          	jal	ra,279a <mutex_lock>
		buffer[buffer_len++] = c;
    197a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    197c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1980:	0017861b          	addiw	a2,a5,1
    1984:	97a6                	add	a5,a5,s1
    1986:	c090                	sw	a2,0(s1)
    1988:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    198c:	02c6c263          	blt	a3,a2,19b0 <putchar+0x76>
    1990:	47a9                	li	a5,10
    1992:	06f40d63          	beq	s0,a5,1a0c <putchar+0xd2>
    1996:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1998:	10c4a503          	lw	a0,268(s1)
    199c:	e432                	sd	a2,8(sp)
    199e:	609000ef          	jal	ra,27a6 <mutex_unlock>
    19a2:	6622                	ld	a2,8(sp)
}
    19a4:	70e2                	ld	ra,56(sp)
    19a6:	7442                	ld	s0,48(sp)
    19a8:	74a2                	ld	s1,40(sp)
    19aa:	8532                	mv	a0,a2
    19ac:	6121                	addi	sp,sp,64
    19ae:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19b0:	10000793          	li	a5,256
    19b4:	02f61063          	bne	a2,a5,19d4 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    19b8:	00001597          	auipc	a1,0x1
    19bc:	0b858593          	addi	a1,a1,184 # 2a70 <buffer>
    19c0:	4505                	li	a0,1
    19c2:	361000ef          	jal	ra,2522 <write>
    19c6:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19ca:	00001797          	auipc	a5,0x1
    19ce:	0807af23          	sw	zero,158(a5) # 2a68 <buffer_len>
			if (r < 0) {
    19d2:	b7d9                	j	1998 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    19d4:	359000ef          	jal	ra,252c <getpid>
    19d8:	842a                	mv	s0,a0
    19da:	00001517          	auipc	a0,0x1
    19de:	f9650513          	addi	a0,a0,-106 # 2970 <enable_deadlock_detect+0x176>
    19e2:	221000ef          	jal	ra,2402 <basename>
    19e6:	872a                	mv	a4,a0
    19e8:	00001617          	auipc	a2,0x1
    19ec:	e8860613          	addi	a2,a2,-376 # 2870 <enable_deadlock_detect+0x76>
    19f0:	05400793          	li	a5,84
    19f4:	86a2                	mv	a3,s0
    19f6:	45fd                	li	a1,31
    19f8:	00001517          	auipc	a0,0x1
    19fc:	fb850513          	addi	a0,a0,-72 # 29b0 <enable_deadlock_detect+0x1b6>
    1a00:	8fbff0ef          	jal	ra,12fa <printf>
    1a04:	557d                	li	a0,-1
    1a06:	357000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    1a0a:	4090                	lw	a2,0(s1)
    1a0c:	d651                	beqz	a2,1998 <putchar+0x5e>
    1a0e:	b76d                	j	19b8 <putchar+0x7e>

0000000000001a10 <puts>:
{
    1a10:	7139                	addi	sp,sp,-64
    1a12:	f822                	sd	s0,48(sp)
    1a14:	f426                	sd	s1,40(sp)
    1a16:	fc06                	sd	ra,56(sp)
    1a18:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a1a:	00001417          	auipc	s0,0x1
    1a1e:	04e40413          	addi	s0,s0,78 # 2a68 <buffer_len>
{
    1a22:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a24:	638000ef          	jal	ra,205c <strlen>
	if (buffer_lock_enabled == 1) {
    1a28:	10842703          	lw	a4,264(s0)
    1a2c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a2e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1a30:	04f70563          	beq	a4,a5,1a7a <puts+0x6a>
		len = out_unlocked(s, l);
    1a34:	8526                	mv	a0,s1
    1a36:	d51ff0ef          	jal	ra,1786 <out_unlocked>
    1a3a:	892a                	mv	s2,a0
    1a3c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a3e:	00095963          	bgez	s2,1a50 <puts+0x40>
}
    1a42:	70e2                	ld	ra,56(sp)
    1a44:	7442                	ld	s0,48(sp)
    1a46:	7902                	ld	s2,32(sp)
    1a48:	8526                	mv	a0,s1
    1a4a:	74a2                	ld	s1,40(sp)
    1a4c:	6121                	addi	sp,sp,64
    1a4e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a50:	10842703          	lw	a4,264(s0)
	char byte = c;
    1a54:	44a9                	li	s1,10
    1a56:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1a5a:	4785                	li	a5,1
    1a5c:	02f70e63          	beq	a4,a5,1a98 <puts+0x88>
		len = out_unlocked(s, l);
    1a60:	01f10513          	addi	a0,sp,31
    1a64:	e2fff0ef          	jal	ra,1892 <out_unlocked.constprop.0>
}
    1a68:	70e2                	ld	ra,56(sp)
    1a6a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a6c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a70:	7902                	ld	s2,32(sp)
    1a72:	8526                	mv	a0,s1
    1a74:	74a2                	ld	s1,40(sp)
    1a76:	6121                	addi	sp,sp,64
    1a78:	8082                	ret
		mutex_lock(buffer_lock);
    1a7a:	e42a                	sd	a0,8(sp)
    1a7c:	10c42503          	lw	a0,268(s0)
    1a80:	51b000ef          	jal	ra,279a <mutex_lock>
		len = out_unlocked(s, l);
    1a84:	65a2                	ld	a1,8(sp)
    1a86:	8526                	mv	a0,s1
    1a88:	cffff0ef          	jal	ra,1786 <out_unlocked>
    1a8c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a8e:	10c42503          	lw	a0,268(s0)
    1a92:	515000ef          	jal	ra,27a6 <mutex_unlock>
    1a96:	b75d                	j	1a3c <puts+0x2c>
		mutex_lock(buffer_lock);
    1a98:	10c42503          	lw	a0,268(s0)
    1a9c:	4ff000ef          	jal	ra,279a <mutex_lock>
		buffer[buffer_len++] = c;
    1aa0:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1aa2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1aa6:	0017861b          	addiw	a2,a5,1
    1aaa:	97a2                	add	a5,a5,s0
    1aac:	c010                	sw	a2,0(s0)
    1aae:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1ab2:	06c6dc63          	bge	a3,a2,1b2a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1ab6:	10000793          	li	a5,256
    1aba:	02f61c63          	bne	a2,a5,1af2 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1abe:	00001597          	auipc	a1,0x1
    1ac2:	fb258593          	addi	a1,a1,-78 # 2a70 <buffer>
    1ac6:	4505                	li	a0,1
    1ac8:	25b000ef          	jal	ra,2522 <write>
			if (r < 0) {
    1acc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1ace:	00001797          	auipc	a5,0x1
    1ad2:	f807ad23          	sw	zero,-102(a5) # 2a68 <buffer_len>
			if (r < 0) {
    1ad6:	04054c63          	bltz	a0,1b2e <puts+0x11e>
			if (r < buffer_len) {
    1ada:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1adc:	10c42503          	lw	a0,268(s0)
    1ae0:	4c7000ef          	jal	ra,27a6 <mutex_unlock>
}
    1ae4:	70e2                	ld	ra,56(sp)
    1ae6:	7442                	ld	s0,48(sp)
    1ae8:	7902                	ld	s2,32(sp)
    1aea:	8526                	mv	a0,s1
    1aec:	74a2                	ld	s1,40(sp)
    1aee:	6121                	addi	sp,sp,64
    1af0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1af2:	23b000ef          	jal	ra,252c <getpid>
    1af6:	84aa                	mv	s1,a0
    1af8:	00001517          	auipc	a0,0x1
    1afc:	e7850513          	addi	a0,a0,-392 # 2970 <enable_deadlock_detect+0x176>
    1b00:	103000ef          	jal	ra,2402 <basename>
    1b04:	872a                	mv	a4,a0
    1b06:	00001617          	auipc	a2,0x1
    1b0a:	d6a60613          	addi	a2,a2,-662 # 2870 <enable_deadlock_detect+0x76>
    1b0e:	05400793          	li	a5,84
    1b12:	86a6                	mv	a3,s1
    1b14:	45fd                	li	a1,31
    1b16:	00001517          	auipc	a0,0x1
    1b1a:	e9a50513          	addi	a0,a0,-358 # 29b0 <enable_deadlock_detect+0x1b6>
    1b1e:	fdcff0ef          	jal	ra,12fa <printf>
    1b22:	557d                	li	a0,-1
    1b24:	239000ef          	jal	ra,255c <exit>
	if (buffer_len == 0)
    1b28:	4010                	lw	a2,0(s0)
    1b2a:	da45                	beqz	a2,1ada <puts+0xca>
    1b2c:	bf49                	j	1abe <puts+0xae>
    1b2e:	54fd                	li	s1,-1
    1b30:	b775                	j	1adc <puts+0xcc>

0000000000001b32 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1b32:	715d                	addi	sp,sp,-80
    1b34:	e486                	sd	ra,72(sp)
    1b36:	e0a2                	sd	s0,64(sp)
    1b38:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1b3a:	14054363          	bltz	a0,1c80 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1b3e:	02b577bb          	remuw	a5,a0,a1
    1b42:	00001617          	auipc	a2,0x1
    1b46:	03660613          	addi	a2,a2,54 # 2b78 <digits>
	buf[16] = 0;
    1b4a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b4e:	0005871b          	sext.w	a4,a1
    1b52:	1782                	slli	a5,a5,0x20
    1b54:	9381                	srli	a5,a5,0x20
    1b56:	97b2                	add	a5,a5,a2
    1b58:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b5c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b60:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b64:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b66:	0eb56763          	bltu	a0,a1,1c54 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b6a:	02e877bb          	remuw	a5,a6,a4
    1b6e:	1782                	slli	a5,a5,0x20
    1b70:	9381                	srli	a5,a5,0x20
    1b72:	97b2                	add	a5,a5,a2
    1b74:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b78:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b7c:	02f10323          	sb	a5,38(sp)
    1b80:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b82:	0ce86963          	bltu	a6,a4,1c54 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b86:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b8a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b8e:	1582                	slli	a1,a1,0x20
    1b90:	9181                	srli	a1,a1,0x20
    1b92:	95b2                	add	a1,a1,a2
    1b94:	0005c583          	lbu	a1,0(a1)
    1b98:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b9c:	0007859b          	sext.w	a1,a5
    1ba0:	16e6e563          	bltu	a3,a4,1d0a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ba4:	02e7f6bb          	remuw	a3,a5,a4
    1ba8:	1682                	slli	a3,a3,0x20
    1baa:	9281                	srli	a3,a3,0x20
    1bac:	96b2                	add	a3,a3,a2
    1bae:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bb2:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1bb6:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1bba:	16e5e163          	bltu	a1,a4,1d1c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1bbe:	02e876bb          	remuw	a3,a6,a4
    1bc2:	1682                	slli	a3,a3,0x20
    1bc4:	9281                	srli	a3,a3,0x20
    1bc6:	96b2                	add	a3,a3,a2
    1bc8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bcc:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1bd0:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1bd4:	14e86d63          	bltu	a6,a4,1d2e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1bd8:	02e5f6bb          	remuw	a3,a1,a4
    1bdc:	1682                	slli	a3,a3,0x20
    1bde:	9281                	srli	a3,a3,0x20
    1be0:	96b2                	add	a3,a3,a2
    1be2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1be6:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bea:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1bee:	10e5e563          	bltu	a1,a4,1cf8 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1bf2:	02e876bb          	remuw	a3,a6,a4
    1bf6:	1682                	slli	a3,a3,0x20
    1bf8:	9281                	srli	a3,a3,0x20
    1bfa:	96b2                	add	a3,a3,a2
    1bfc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c00:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c04:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c08:	14e86263          	bltu	a6,a4,1d4c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c0c:	02e5f6bb          	remuw	a3,a1,a4
    1c10:	1682                	slli	a3,a3,0x20
    1c12:	9281                	srli	a3,a3,0x20
    1c14:	96b2                	add	a3,a3,a2
    1c16:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c1a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c1e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c22:	14e5e463          	bltu	a1,a4,1d6a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1c26:	02e876bb          	remuw	a3,a6,a4
    1c2a:	1682                	slli	a3,a3,0x20
    1c2c:	9281                	srli	a3,a3,0x20
    1c2e:	96b2                	add	a3,a3,a2
    1c30:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c34:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1c38:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1c3c:	14e86063          	bltu	a6,a4,1d7c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1c40:	1782                	slli	a5,a5,0x20
    1c42:	9381                	srli	a5,a5,0x20
    1c44:	97b2                	add	a5,a5,a2
    1c46:	0007c703          	lbu	a4,0(a5)
    1c4a:	4799                	li	a5,6
    1c4c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c50:	10054763          	bltz	a0,1d5e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1c54:	00001497          	auipc	s1,0x1
    1c58:	e1448493          	addi	s1,s1,-492 # 2a68 <buffer_len>
    1c5c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c60:	0828                	addi	a0,sp,24
    1c62:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c64:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c66:	00f50433          	add	s0,a0,a5
    1c6a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c6c:	06e68463          	beq	a3,a4,1cd4 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c70:	8522                	mv	a0,s0
    1c72:	b15ff0ef          	jal	ra,1786 <out_unlocked>
}
    1c76:	60a6                	ld	ra,72(sp)
    1c78:	6406                	ld	s0,64(sp)
    1c7a:	74e2                	ld	s1,56(sp)
    1c7c:	6161                	addi	sp,sp,80
    1c7e:	8082                	ret
		x = -xx;
    1c80:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c84:	02b877bb          	remuw	a5,a6,a1
    1c88:	00001617          	auipc	a2,0x1
    1c8c:	ef060613          	addi	a2,a2,-272 # 2b78 <digits>
	buf[16] = 0;
    1c90:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c94:	0005871b          	sext.w	a4,a1
    1c98:	1782                	slli	a5,a5,0x20
    1c9a:	9381                	srli	a5,a5,0x20
    1c9c:	97b2                	add	a5,a5,a2
    1c9e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ca2:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1ca6:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1caa:	08b86b63          	bltu	a6,a1,1d40 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1cae:	02e8f7bb          	remuw	a5,a7,a4
    1cb2:	1782                	slli	a5,a5,0x20
    1cb4:	9381                	srli	a5,a5,0x20
    1cb6:	97b2                	add	a5,a5,a2
    1cb8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cbc:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1cc0:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1cc4:	ece8f1e3          	bgeu	a7,a4,1b86 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1cc8:	02d00793          	li	a5,45
    1ccc:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1cd0:	47b5                	li	a5,13
    1cd2:	b749                	j	1c54 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1cd4:	10c4a503          	lw	a0,268(s1)
    1cd8:	e42e                	sd	a1,8(sp)
    1cda:	2c1000ef          	jal	ra,279a <mutex_lock>
		len = out_unlocked(s, l);
    1cde:	65a2                	ld	a1,8(sp)
    1ce0:	8522                	mv	a0,s0
    1ce2:	aa5ff0ef          	jal	ra,1786 <out_unlocked>
		mutex_unlock(buffer_lock);
    1ce6:	10c4a503          	lw	a0,268(s1)
    1cea:	2bd000ef          	jal	ra,27a6 <mutex_unlock>
}
    1cee:	60a6                	ld	ra,72(sp)
    1cf0:	6406                	ld	s0,64(sp)
    1cf2:	74e2                	ld	s1,56(sp)
    1cf4:	6161                	addi	sp,sp,80
    1cf6:	8082                	ret
		buf[i--] = digits[x % base];
    1cf8:	47a9                	li	a5,10
	if (sign)
    1cfa:	f4055de3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cfe:	02d00793          	li	a5,45
    1d02:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d06:	47a5                	li	a5,9
    1d08:	b7b1                	j	1c54 <printint.constprop.0+0x122>
    1d0a:	47b5                	li	a5,13
	if (sign)
    1d0c:	f40554e3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d10:	02d00793          	li	a5,45
    1d14:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d18:	47b1                	li	a5,12
    1d1a:	bf2d                	j	1c54 <printint.constprop.0+0x122>
    1d1c:	47b1                	li	a5,12
	if (sign)
    1d1e:	f2055be3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d22:	02d00793          	li	a5,45
    1d26:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d2a:	47ad                	li	a5,11
    1d2c:	b725                	j	1c54 <printint.constprop.0+0x122>
    1d2e:	47ad                	li	a5,11
	if (sign)
    1d30:	f20552e3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d34:	02d00793          	li	a5,45
    1d38:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1d3c:	47a9                	li	a5,10
    1d3e:	bf19                	j	1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d40:	02d00793          	li	a5,45
    1d44:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1d48:	47b9                	li	a5,14
    1d4a:	b729                	j	1c54 <printint.constprop.0+0x122>
    1d4c:	47a5                	li	a5,9
	if (sign)
    1d4e:	f00553e3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d52:	02d00793          	li	a5,45
    1d56:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1d5a:	47a1                	li	a5,8
    1d5c:	bde5                	j	1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d5e:	02d00793          	li	a5,45
    1d62:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d66:	4795                	li	a5,5
    1d68:	b5f5                	j	1c54 <printint.constprop.0+0x122>
    1d6a:	47a1                	li	a5,8
	if (sign)
    1d6c:	ee0554e3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d70:	02d00793          	li	a5,45
    1d74:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d78:	479d                	li	a5,7
    1d7a:	bde9                	j	1c54 <printint.constprop.0+0x122>
    1d7c:	479d                	li	a5,7
	if (sign)
    1d7e:	ec055be3          	bgez	a0,1c54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d82:	02d00793          	li	a5,45
    1d86:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d8a:	4799                	li	a5,6
    1d8c:	b5e1                	j	1c54 <printint.constprop.0+0x122>

0000000000001d8e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d8e:	02000793          	li	a5,32
    1d92:	00f50663          	beq	a0,a5,1d9e <isspace+0x10>
    1d96:	355d                	addiw	a0,a0,-9
    1d98:	00553513          	sltiu	a0,a0,5
    1d9c:	8082                	ret
    1d9e:	4505                	li	a0,1
}
    1da0:	8082                	ret

0000000000001da2 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1da2:	fd05051b          	addiw	a0,a0,-48
}
    1da6:	00a53513          	sltiu	a0,a0,10
    1daa:	8082                	ret

0000000000001dac <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1dac:	02000613          	li	a2,32
    1db0:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1db2:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1db6:	ff77869b          	addiw	a3,a5,-9
    1dba:	04c78c63          	beq	a5,a2,1e12 <atoi+0x66>
    1dbe:	0007871b          	sext.w	a4,a5
    1dc2:	04d5f863          	bgeu	a1,a3,1e12 <atoi+0x66>
		s++;
	switch (*s) {
    1dc6:	02b00693          	li	a3,43
    1dca:	04d78963          	beq	a5,a3,1e1c <atoi+0x70>
    1dce:	02d00693          	li	a3,45
    1dd2:	06d78263          	beq	a5,a3,1e36 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1dd6:	fd07061b          	addiw	a2,a4,-48
    1dda:	47a5                	li	a5,9
    1ddc:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1dde:	4e01                	li	t3,0
	while (isdigit(*s))
    1de0:	04c7e963          	bltu	a5,a2,1e32 <atoi+0x86>
	int n = 0, neg = 0;
    1de4:	4501                	li	a0,0
	while (isdigit(*s))
    1de6:	4825                	li	a6,9
    1de8:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1dec:	0025179b          	slliw	a5,a0,0x2
    1df0:	9fa9                	addw	a5,a5,a0
    1df2:	fd07031b          	addiw	t1,a4,-48
    1df6:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1dfa:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1dfe:	0685                	addi	a3,a3,1
    1e00:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e04:	0006071b          	sext.w	a4,a2
    1e08:	feb870e3          	bgeu	a6,a1,1de8 <atoi+0x3c>
	return neg ? n : -n;
    1e0c:	000e0563          	beqz	t3,1e16 <atoi+0x6a>
}
    1e10:	8082                	ret
		s++;
    1e12:	0505                	addi	a0,a0,1
    1e14:	bf79                	j	1db2 <atoi+0x6>
	return neg ? n : -n;
    1e16:	4113053b          	subw	a0,t1,a7
    1e1a:	8082                	ret
	while (isdigit(*s))
    1e1c:	00154703          	lbu	a4,1(a0)
    1e20:	47a5                	li	a5,9
		s++;
    1e22:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e26:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e2a:	4e01                	li	t3,0
	while (isdigit(*s))
    1e2c:	2701                	sext.w	a4,a4
    1e2e:	fac7fbe3          	bgeu	a5,a2,1de4 <atoi+0x38>
    1e32:	4501                	li	a0,0
}
    1e34:	8082                	ret
	while (isdigit(*s))
    1e36:	00154703          	lbu	a4,1(a0)
    1e3a:	47a5                	li	a5,9
		s++;
    1e3c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e40:	fd07061b          	addiw	a2,a4,-48
    1e44:	2701                	sext.w	a4,a4
    1e46:	fec7e6e3          	bltu	a5,a2,1e32 <atoi+0x86>
		neg = 1;
    1e4a:	4e05                	li	t3,1
    1e4c:	bf61                	j	1de4 <atoi+0x38>

0000000000001e4e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e4e:	16060d63          	beqz	a2,1fc8 <memset+0x17a>
    1e52:	40a007b3          	neg	a5,a0
    1e56:	8b9d                	andi	a5,a5,7
    1e58:	00778693          	addi	a3,a5,7
    1e5c:	482d                	li	a6,11
    1e5e:	0ff5f713          	zext.b	a4,a1
    1e62:	fff60593          	addi	a1,a2,-1
    1e66:	1706e263          	bltu	a3,a6,1fca <memset+0x17c>
    1e6a:	16d5ea63          	bltu	a1,a3,1fde <memset+0x190>
    1e6e:	16078563          	beqz	a5,1fd8 <memset+0x18a>
    1e72:	00e50023          	sb	a4,0(a0)
    1e76:	4685                	li	a3,1
    1e78:	00150593          	addi	a1,a0,1
    1e7c:	14d78c63          	beq	a5,a3,1fd4 <memset+0x186>
    1e80:	00e500a3          	sb	a4,1(a0)
    1e84:	4689                	li	a3,2
    1e86:	00250593          	addi	a1,a0,2
    1e8a:	14d78d63          	beq	a5,a3,1fe4 <memset+0x196>
    1e8e:	00e50123          	sb	a4,2(a0)
    1e92:	468d                	li	a3,3
    1e94:	00350593          	addi	a1,a0,3
    1e98:	12d78b63          	beq	a5,a3,1fce <memset+0x180>
    1e9c:	00e501a3          	sb	a4,3(a0)
    1ea0:	4691                	li	a3,4
    1ea2:	00450593          	addi	a1,a0,4
    1ea6:	14d78163          	beq	a5,a3,1fe8 <memset+0x19a>
    1eaa:	00e50223          	sb	a4,4(a0)
    1eae:	4695                	li	a3,5
    1eb0:	00550593          	addi	a1,a0,5
    1eb4:	12d78c63          	beq	a5,a3,1fec <memset+0x19e>
    1eb8:	00e502a3          	sb	a4,5(a0)
    1ebc:	469d                	li	a3,7
    1ebe:	00650593          	addi	a1,a0,6
    1ec2:	12d79763          	bne	a5,a3,1ff0 <memset+0x1a2>
    1ec6:	00750593          	addi	a1,a0,7
    1eca:	00e50323          	sb	a4,6(a0)
    1ece:	481d                	li	a6,7
    1ed0:	00871693          	slli	a3,a4,0x8
    1ed4:	01071893          	slli	a7,a4,0x10
    1ed8:	8ed9                	or	a3,a3,a4
    1eda:	01871313          	slli	t1,a4,0x18
    1ede:	0116e6b3          	or	a3,a3,a7
    1ee2:	0066e6b3          	or	a3,a3,t1
    1ee6:	02071893          	slli	a7,a4,0x20
    1eea:	02871e13          	slli	t3,a4,0x28
    1eee:	0116e6b3          	or	a3,a3,a7
    1ef2:	40f60333          	sub	t1,a2,a5
    1ef6:	03071893          	slli	a7,a4,0x30
    1efa:	01c6e6b3          	or	a3,a3,t3
    1efe:	0116e6b3          	or	a3,a3,a7
    1f02:	03871e13          	slli	t3,a4,0x38
    1f06:	97aa                	add	a5,a5,a0
    1f08:	ff837893          	andi	a7,t1,-8
    1f0c:	01c6e6b3          	or	a3,a3,t3
    1f10:	98be                	add	a7,a7,a5
    1f12:	e394                	sd	a3,0(a5)
    1f14:	07a1                	addi	a5,a5,8
    1f16:	ff179ee3          	bne	a5,a7,1f12 <memset+0xc4>
    1f1a:	ff837893          	andi	a7,t1,-8
    1f1e:	011587b3          	add	a5,a1,a7
    1f22:	010886bb          	addw	a3,a7,a6
    1f26:	0b130663          	beq	t1,a7,1fd2 <memset+0x184>
    1f2a:	00e78023          	sb	a4,0(a5)
    1f2e:	0016859b          	addiw	a1,a3,1
    1f32:	08c5fb63          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f36:	00e780a3          	sb	a4,1(a5)
    1f3a:	0026859b          	addiw	a1,a3,2
    1f3e:	08c5f563          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f42:	00e78123          	sb	a4,2(a5)
    1f46:	0036859b          	addiw	a1,a3,3
    1f4a:	06c5ff63          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f4e:	00e781a3          	sb	a4,3(a5)
    1f52:	0046859b          	addiw	a1,a3,4
    1f56:	06c5f963          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f5a:	00e78223          	sb	a4,4(a5)
    1f5e:	0056859b          	addiw	a1,a3,5
    1f62:	06c5f363          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f66:	00e782a3          	sb	a4,5(a5)
    1f6a:	0066859b          	addiw	a1,a3,6
    1f6e:	04c5fd63          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f72:	00e78323          	sb	a4,6(a5)
    1f76:	0076859b          	addiw	a1,a3,7
    1f7a:	04c5f763          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f7e:	00e783a3          	sb	a4,7(a5)
    1f82:	0086859b          	addiw	a1,a3,8
    1f86:	04c5f163          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f8a:	00e78423          	sb	a4,8(a5)
    1f8e:	0096859b          	addiw	a1,a3,9
    1f92:	02c5fb63          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1f96:	00e784a3          	sb	a4,9(a5)
    1f9a:	00a6859b          	addiw	a1,a3,10
    1f9e:	02c5f563          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1fa2:	00e78523          	sb	a4,10(a5)
    1fa6:	00b6859b          	addiw	a1,a3,11
    1faa:	00c5ff63          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1fae:	00e785a3          	sb	a4,11(a5)
    1fb2:	00c6859b          	addiw	a1,a3,12
    1fb6:	00c5f963          	bgeu	a1,a2,1fc8 <memset+0x17a>
    1fba:	00e78623          	sb	a4,12(a5)
    1fbe:	26b5                	addiw	a3,a3,13
    1fc0:	00c6f463          	bgeu	a3,a2,1fc8 <memset+0x17a>
    1fc4:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1fc8:	8082                	ret
    1fca:	46ad                	li	a3,11
    1fcc:	bd79                	j	1e6a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fce:	480d                	li	a6,3
    1fd0:	b701                	j	1ed0 <memset+0x82>
    1fd2:	8082                	ret
    1fd4:	4805                	li	a6,1
    1fd6:	bded                	j	1ed0 <memset+0x82>
    1fd8:	85aa                	mv	a1,a0
    1fda:	4801                	li	a6,0
    1fdc:	bdd5                	j	1ed0 <memset+0x82>
    1fde:	87aa                	mv	a5,a0
    1fe0:	4681                	li	a3,0
    1fe2:	b7a1                	j	1f2a <memset+0xdc>
    1fe4:	4809                	li	a6,2
    1fe6:	b5ed                	j	1ed0 <memset+0x82>
    1fe8:	4811                	li	a6,4
    1fea:	b5dd                	j	1ed0 <memset+0x82>
    1fec:	4815                	li	a6,5
    1fee:	b5cd                	j	1ed0 <memset+0x82>
    1ff0:	4819                	li	a6,6
    1ff2:	bdf9                	j	1ed0 <memset+0x82>

0000000000001ff4 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ff4:	00054783          	lbu	a5,0(a0)
    1ff8:	0005c703          	lbu	a4,0(a1)
    1ffc:	00e79863          	bne	a5,a4,200c <strcmp+0x18>
    2000:	0505                	addi	a0,a0,1
    2002:	0585                	addi	a1,a1,1
    2004:	fbe5                	bnez	a5,1ff4 <strcmp>
    2006:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2008:	9d19                	subw	a0,a0,a4
    200a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    200c:	0007851b          	sext.w	a0,a5
    2010:	bfe5                	j	2008 <strcmp+0x14>

0000000000002012 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2012:	ca15                	beqz	a2,2046 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2014:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2018:	167d                	addi	a2,a2,-1
    201a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    201e:	eb99                	bnez	a5,2034 <strncmp+0x22>
    2020:	a815                	j	2054 <strncmp+0x42>
    2022:	00a68e63          	beq	a3,a0,203e <strncmp+0x2c>
    2026:	0505                	addi	a0,a0,1
    2028:	00f71b63          	bne	a4,a5,203e <strncmp+0x2c>
    202c:	00054783          	lbu	a5,0(a0)
    2030:	cf89                	beqz	a5,204a <strncmp+0x38>
    2032:	85b2                	mv	a1,a2
    2034:	0005c703          	lbu	a4,0(a1)
    2038:	00158613          	addi	a2,a1,1
    203c:	f37d                	bnez	a4,2022 <strncmp+0x10>
		;
	return *l - *r;
    203e:	0007851b          	sext.w	a0,a5
    2042:	9d19                	subw	a0,a0,a4
    2044:	8082                	ret
		return 0;
    2046:	4501                	li	a0,0
}
    2048:	8082                	ret
	return *l - *r;
    204a:	0015c703          	lbu	a4,1(a1)
    204e:	4501                	li	a0,0
    2050:	9d19                	subw	a0,a0,a4
    2052:	8082                	ret
    2054:	0005c703          	lbu	a4,0(a1)
    2058:	4501                	li	a0,0
    205a:	b7e5                	j	2042 <strncmp+0x30>

000000000000205c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    205c:	00757793          	andi	a5,a0,7
    2060:	cf89                	beqz	a5,207a <strlen+0x1e>
    2062:	87aa                	mv	a5,a0
    2064:	a029                	j	206e <strlen+0x12>
    2066:	0785                	addi	a5,a5,1
    2068:	0077f713          	andi	a4,a5,7
    206c:	cb01                	beqz	a4,207c <strlen+0x20>
		if (!*s)
    206e:	0007c703          	lbu	a4,0(a5)
    2072:	fb75                	bnez	a4,2066 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2074:	40a78533          	sub	a0,a5,a0
}
    2078:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    207a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    207c:	6394                	ld	a3,0(a5)
    207e:	00001597          	auipc	a1,0x1
    2082:	9ca5b583          	ld	a1,-1590(a1) # 2a48 <enable_deadlock_detect+0x24e>
    2086:	00001617          	auipc	a2,0x1
    208a:	9ca63603          	ld	a2,-1590(a2) # 2a50 <enable_deadlock_detect+0x256>
    208e:	a019                	j	2094 <strlen+0x38>
    2090:	6794                	ld	a3,8(a5)
    2092:	07a1                	addi	a5,a5,8
    2094:	00b68733          	add	a4,a3,a1
    2098:	fff6c693          	not	a3,a3
    209c:	8f75                	and	a4,a4,a3
    209e:	8f71                	and	a4,a4,a2
    20a0:	db65                	beqz	a4,2090 <strlen+0x34>
	for (; *s; s++)
    20a2:	0007c703          	lbu	a4,0(a5)
    20a6:	d779                	beqz	a4,2074 <strlen+0x18>
    20a8:	0017c703          	lbu	a4,1(a5)
    20ac:	0785                	addi	a5,a5,1
    20ae:	d379                	beqz	a4,2074 <strlen+0x18>
    20b0:	0017c703          	lbu	a4,1(a5)
    20b4:	0785                	addi	a5,a5,1
    20b6:	fb6d                	bnez	a4,20a8 <strlen+0x4c>
    20b8:	bf75                	j	2074 <strlen+0x18>

00000000000020ba <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    20ba:	00757713          	andi	a4,a0,7
{
    20be:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    20c0:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    20c4:	cb19                	beqz	a4,20da <memchr+0x20>
    20c6:	ce25                	beqz	a2,213e <memchr+0x84>
    20c8:	0007c703          	lbu	a4,0(a5)
    20cc:	04b70e63          	beq	a4,a1,2128 <memchr+0x6e>
    20d0:	0785                	addi	a5,a5,1
    20d2:	0077f713          	andi	a4,a5,7
    20d6:	167d                	addi	a2,a2,-1
    20d8:	f77d                	bnez	a4,20c6 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    20da:	4501                	li	a0,0
	if (n && *s != c) {
    20dc:	c235                	beqz	a2,2140 <memchr+0x86>
    20de:	0007c703          	lbu	a4,0(a5)
    20e2:	04b70363          	beq	a4,a1,2128 <memchr+0x6e>
		size_t k = ONES * c;
    20e6:	00001517          	auipc	a0,0x1
    20ea:	97253503          	ld	a0,-1678(a0) # 2a58 <enable_deadlock_detect+0x25e>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20ee:	471d                	li	a4,7
		size_t k = ONES * c;
    20f0:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20f4:	02c77a63          	bgeu	a4,a2,2128 <memchr+0x6e>
    20f8:	00001897          	auipc	a7,0x1
    20fc:	9508b883          	ld	a7,-1712(a7) # 2a48 <enable_deadlock_detect+0x24e>
    2100:	00001817          	auipc	a6,0x1
    2104:	95083803          	ld	a6,-1712(a6) # 2a50 <enable_deadlock_detect+0x256>
    2108:	431d                	li	t1,7
    210a:	a029                	j	2114 <memchr+0x5a>
		     w++, n -= SS)
    210c:	1661                	addi	a2,a2,-8
    210e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2110:	02c37963          	bgeu	t1,a2,2142 <memchr+0x88>
    2114:	6398                	ld	a4,0(a5)
    2116:	8f29                	xor	a4,a4,a0
    2118:	011706b3          	add	a3,a4,a7
    211c:	fff74713          	not	a4,a4
    2120:	8f75                	and	a4,a4,a3
    2122:	01077733          	and	a4,a4,a6
    2126:	d37d                	beqz	a4,210c <memchr+0x52>
{
    2128:	853e                	mv	a0,a5
    212a:	97b2                	add	a5,a5,a2
    212c:	a021                	j	2134 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    212e:	0505                	addi	a0,a0,1
    2130:	00f50763          	beq	a0,a5,213e <memchr+0x84>
    2134:	00054703          	lbu	a4,0(a0)
    2138:	feb71be3          	bne	a4,a1,212e <memchr+0x74>
    213c:	8082                	ret
	return n ? (void *)s : 0;
    213e:	4501                	li	a0,0
}
    2140:	8082                	ret
	return n ? (void *)s : 0;
    2142:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2144:	f275                	bnez	a2,2128 <memchr+0x6e>
}
    2146:	8082                	ret

0000000000002148 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2148:	1101                	addi	sp,sp,-32
    214a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    214c:	862e                	mv	a2,a1
{
    214e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2150:	4581                	li	a1,0
{
    2152:	e426                	sd	s1,8(sp)
    2154:	ec06                	sd	ra,24(sp)
    2156:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2158:	f63ff0ef          	jal	ra,20ba <memchr>
	return p ? p - s : n;
    215c:	c519                	beqz	a0,216a <strnlen+0x22>
}
    215e:	60e2                	ld	ra,24(sp)
    2160:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2162:	8d05                	sub	a0,a0,s1
}
    2164:	64a2                	ld	s1,8(sp)
    2166:	6105                	addi	sp,sp,32
    2168:	8082                	ret
    216a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    216c:	8522                	mv	a0,s0
}
    216e:	6442                	ld	s0,16(sp)
    2170:	64a2                	ld	s1,8(sp)
    2172:	6105                	addi	sp,sp,32
    2174:	8082                	ret

0000000000002176 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2176:	00a5c7b3          	xor	a5,a1,a0
    217a:	8b9d                	andi	a5,a5,7
    217c:	eb95                	bnez	a5,21b0 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    217e:	0075f793          	andi	a5,a1,7
    2182:	e7b1                	bnez	a5,21ce <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2184:	6198                	ld	a4,0(a1)
    2186:	00001617          	auipc	a2,0x1
    218a:	8c263603          	ld	a2,-1854(a2) # 2a48 <enable_deadlock_detect+0x24e>
    218e:	00001817          	auipc	a6,0x1
    2192:	8c283803          	ld	a6,-1854(a6) # 2a50 <enable_deadlock_detect+0x256>
    2196:	a029                	j	21a0 <stpcpy+0x2a>
    2198:	05a1                	addi	a1,a1,8
    219a:	e118                	sd	a4,0(a0)
    219c:	6198                	ld	a4,0(a1)
    219e:	0521                	addi	a0,a0,8
    21a0:	00c707b3          	add	a5,a4,a2
    21a4:	fff74693          	not	a3,a4
    21a8:	8ff5                	and	a5,a5,a3
    21aa:	0107f7b3          	and	a5,a5,a6
    21ae:	d7ed                	beqz	a5,2198 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    21b0:	0005c783          	lbu	a5,0(a1)
    21b4:	00f50023          	sb	a5,0(a0)
    21b8:	c785                	beqz	a5,21e0 <stpcpy+0x6a>
    21ba:	0015c783          	lbu	a5,1(a1)
    21be:	0505                	addi	a0,a0,1
    21c0:	0585                	addi	a1,a1,1
    21c2:	00f50023          	sb	a5,0(a0)
    21c6:	fbf5                	bnez	a5,21ba <stpcpy+0x44>
		;
	return d;
}
    21c8:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    21ca:	0505                	addi	a0,a0,1
    21cc:	df45                	beqz	a4,2184 <stpcpy+0xe>
			if (!(*d = *s))
    21ce:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    21d2:	0585                	addi	a1,a1,1
    21d4:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    21d8:	00f50023          	sb	a5,0(a0)
    21dc:	f7fd                	bnez	a5,21ca <stpcpy+0x54>
}
    21de:	8082                	ret
    21e0:	8082                	ret

00000000000021e2 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    21e2:	00a5c7b3          	xor	a5,a1,a0
    21e6:	8b9d                	andi	a5,a5,7
    21e8:	1a079863          	bnez	a5,2398 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    21ec:	0075f793          	andi	a5,a1,7
    21f0:	16078463          	beqz	a5,2358 <stpncpy+0x176>
    21f4:	ea01                	bnez	a2,2204 <stpncpy+0x22>
    21f6:	a421                	j	23fe <stpncpy+0x21c>
    21f8:	167d                	addi	a2,a2,-1
    21fa:	0505                	addi	a0,a0,1
    21fc:	14070e63          	beqz	a4,2358 <stpncpy+0x176>
    2200:	1a060863          	beqz	a2,23b0 <stpncpy+0x1ce>
    2204:	0005c783          	lbu	a5,0(a1)
    2208:	0585                	addi	a1,a1,1
    220a:	0075f713          	andi	a4,a1,7
    220e:	00f50023          	sb	a5,0(a0)
    2212:	f3fd                	bnez	a5,21f8 <stpncpy+0x16>
    2214:	4805                	li	a6,1
    2216:	1a061863          	bnez	a2,23c6 <stpncpy+0x1e4>
    221a:	40a007b3          	neg	a5,a0
    221e:	8b9d                	andi	a5,a5,7
    2220:	4681                	li	a3,0
    2222:	18061a63          	bnez	a2,23b6 <stpncpy+0x1d4>
    2226:	00778713          	addi	a4,a5,7
    222a:	45ad                	li	a1,11
    222c:	18b76363          	bltu	a4,a1,23b2 <stpncpy+0x1d0>
    2230:	1ae6eb63          	bltu	a3,a4,23e6 <stpncpy+0x204>
    2234:	1a078363          	beqz	a5,23da <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2238:	00050023          	sb	zero,0(a0)
    223c:	4685                	li	a3,1
    223e:	00150713          	addi	a4,a0,1
    2242:	18d78f63          	beq	a5,a3,23e0 <stpncpy+0x1fe>
    2246:	000500a3          	sb	zero,1(a0)
    224a:	4689                	li	a3,2
    224c:	00250713          	addi	a4,a0,2
    2250:	18d78e63          	beq	a5,a3,23ec <stpncpy+0x20a>
    2254:	00050123          	sb	zero,2(a0)
    2258:	468d                	li	a3,3
    225a:	00350713          	addi	a4,a0,3
    225e:	16d78c63          	beq	a5,a3,23d6 <stpncpy+0x1f4>
    2262:	000501a3          	sb	zero,3(a0)
    2266:	4691                	li	a3,4
    2268:	00450713          	addi	a4,a0,4
    226c:	18d78263          	beq	a5,a3,23f0 <stpncpy+0x20e>
    2270:	00050223          	sb	zero,4(a0)
    2274:	4695                	li	a3,5
    2276:	00550713          	addi	a4,a0,5
    227a:	16d78d63          	beq	a5,a3,23f4 <stpncpy+0x212>
    227e:	000502a3          	sb	zero,5(a0)
    2282:	469d                	li	a3,7
    2284:	00650713          	addi	a4,a0,6
    2288:	16d79863          	bne	a5,a3,23f8 <stpncpy+0x216>
    228c:	00750713          	addi	a4,a0,7
    2290:	00050323          	sb	zero,6(a0)
    2294:	40f80833          	sub	a6,a6,a5
    2298:	ff887593          	andi	a1,a6,-8
    229c:	97aa                	add	a5,a5,a0
    229e:	95be                	add	a1,a1,a5
    22a0:	0007b023          	sd	zero,0(a5)
    22a4:	07a1                	addi	a5,a5,8
    22a6:	feb79de3          	bne	a5,a1,22a0 <stpncpy+0xbe>
    22aa:	ff887593          	andi	a1,a6,-8
    22ae:	9ead                	addw	a3,a3,a1
    22b0:	00b707b3          	add	a5,a4,a1
    22b4:	12b80863          	beq	a6,a1,23e4 <stpncpy+0x202>
    22b8:	00078023          	sb	zero,0(a5)
    22bc:	0016871b          	addiw	a4,a3,1
    22c0:	0ec77863          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    22c4:	000780a3          	sb	zero,1(a5)
    22c8:	0026871b          	addiw	a4,a3,2
    22cc:	0ec77263          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    22d0:	00078123          	sb	zero,2(a5)
    22d4:	0036871b          	addiw	a4,a3,3
    22d8:	0cc77c63          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    22dc:	000781a3          	sb	zero,3(a5)
    22e0:	0046871b          	addiw	a4,a3,4
    22e4:	0cc77663          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    22e8:	00078223          	sb	zero,4(a5)
    22ec:	0056871b          	addiw	a4,a3,5
    22f0:	0cc77063          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    22f4:	000782a3          	sb	zero,5(a5)
    22f8:	0066871b          	addiw	a4,a3,6
    22fc:	0ac77a63          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    2300:	00078323          	sb	zero,6(a5)
    2304:	0076871b          	addiw	a4,a3,7
    2308:	0ac77463          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    230c:	000783a3          	sb	zero,7(a5)
    2310:	0086871b          	addiw	a4,a3,8
    2314:	08c77e63          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    2318:	00078423          	sb	zero,8(a5)
    231c:	0096871b          	addiw	a4,a3,9
    2320:	08c77863          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    2324:	000784a3          	sb	zero,9(a5)
    2328:	00a6871b          	addiw	a4,a3,10
    232c:	08c77263          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    2330:	00078523          	sb	zero,10(a5)
    2334:	00b6871b          	addiw	a4,a3,11
    2338:	06c77c63          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    233c:	000785a3          	sb	zero,11(a5)
    2340:	00c6871b          	addiw	a4,a3,12
    2344:	06c77663          	bgeu	a4,a2,23b0 <stpncpy+0x1ce>
    2348:	00078623          	sb	zero,12(a5)
    234c:	26b5                	addiw	a3,a3,13
    234e:	06c6f163          	bgeu	a3,a2,23b0 <stpncpy+0x1ce>
    2352:	000786a3          	sb	zero,13(a5)
    2356:	8082                	ret
			;
		if (!n || !*s)
    2358:	c645                	beqz	a2,2400 <stpncpy+0x21e>
    235a:	0005c783          	lbu	a5,0(a1)
    235e:	ea078be3          	beqz	a5,2214 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2362:	479d                	li	a5,7
    2364:	02c7ff63          	bgeu	a5,a2,23a2 <stpncpy+0x1c0>
    2368:	00000897          	auipc	a7,0x0
    236c:	6e08b883          	ld	a7,1760(a7) # 2a48 <enable_deadlock_detect+0x24e>
    2370:	00000817          	auipc	a6,0x0
    2374:	6e083803          	ld	a6,1760(a6) # 2a50 <enable_deadlock_detect+0x256>
    2378:	431d                	li	t1,7
    237a:	6198                	ld	a4,0(a1)
    237c:	011707b3          	add	a5,a4,a7
    2380:	fff74693          	not	a3,a4
    2384:	8ff5                	and	a5,a5,a3
    2386:	0107f7b3          	and	a5,a5,a6
    238a:	ef81                	bnez	a5,23a2 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    238c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    238e:	1661                	addi	a2,a2,-8
    2390:	05a1                	addi	a1,a1,8
    2392:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2394:	fec363e3          	bltu	t1,a2,237a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2398:	e609                	bnez	a2,23a2 <stpncpy+0x1c0>
    239a:	a08d                	j	23fc <stpncpy+0x21a>
    239c:	167d                	addi	a2,a2,-1
    239e:	0505                	addi	a0,a0,1
    23a0:	ca01                	beqz	a2,23b0 <stpncpy+0x1ce>
    23a2:	0005c783          	lbu	a5,0(a1)
    23a6:	0585                	addi	a1,a1,1
    23a8:	00f50023          	sb	a5,0(a0)
    23ac:	fbe5                	bnez	a5,239c <stpncpy+0x1ba>
		;
tail:
    23ae:	b59d                	j	2214 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    23b0:	8082                	ret
    23b2:	472d                	li	a4,11
    23b4:	bdb5                	j	2230 <stpncpy+0x4e>
    23b6:	00778713          	addi	a4,a5,7
    23ba:	45ad                	li	a1,11
    23bc:	fff60693          	addi	a3,a2,-1
    23c0:	e6b778e3          	bgeu	a4,a1,2230 <stpncpy+0x4e>
    23c4:	b7fd                	j	23b2 <stpncpy+0x1d0>
    23c6:	40a007b3          	neg	a5,a0
    23ca:	8832                	mv	a6,a2
    23cc:	8b9d                	andi	a5,a5,7
    23ce:	4681                	li	a3,0
    23d0:	e4060be3          	beqz	a2,2226 <stpncpy+0x44>
    23d4:	b7cd                	j	23b6 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23d6:	468d                	li	a3,3
    23d8:	bd75                	j	2294 <stpncpy+0xb2>
    23da:	872a                	mv	a4,a0
    23dc:	4681                	li	a3,0
    23de:	bd5d                	j	2294 <stpncpy+0xb2>
    23e0:	4685                	li	a3,1
    23e2:	bd4d                	j	2294 <stpncpy+0xb2>
    23e4:	8082                	ret
    23e6:	87aa                	mv	a5,a0
    23e8:	4681                	li	a3,0
    23ea:	b5f9                	j	22b8 <stpncpy+0xd6>
    23ec:	4689                	li	a3,2
    23ee:	b55d                	j	2294 <stpncpy+0xb2>
    23f0:	4691                	li	a3,4
    23f2:	b54d                	j	2294 <stpncpy+0xb2>
    23f4:	4695                	li	a3,5
    23f6:	bd79                	j	2294 <stpncpy+0xb2>
    23f8:	4699                	li	a3,6
    23fa:	bd69                	j	2294 <stpncpy+0xb2>
    23fc:	8082                	ret
    23fe:	8082                	ret
    2400:	8082                	ret

0000000000002402 <basename>:

char *basename(char *s)
{
    2402:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2404:	c54d                	beqz	a0,24ae <basename+0xac>
    2406:	00054783          	lbu	a5,0(a0)
		return ".";
    240a:	00000517          	auipc	a0,0x0
    240e:	63650513          	addi	a0,a0,1590 # 2a40 <enable_deadlock_detect+0x246>
	if (!s || !*s)
    2412:	e391                	bnez	a5,2416 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2414:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2416:	0076f713          	andi	a4,a3,7
    241a:	87b6                	mv	a5,a3
    241c:	cf51                	beqz	a4,24b8 <basename+0xb6>
    241e:	0785                	addi	a5,a5,1
    2420:	0077f713          	andi	a4,a5,7
    2424:	c729                	beqz	a4,246e <basename+0x6c>
		if (!*s)
    2426:	0007c703          	lbu	a4,0(a5)
    242a:	fb75                	bnez	a4,241e <basename+0x1c>
	return s - a;
    242c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    242e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2430:	cf8d                	beqz	a5,246a <basename+0x68>
    2432:	00f68733          	add	a4,a3,a5
    2436:	02f00593          	li	a1,47
    243a:	a031                	j	2446 <basename+0x44>
		s[i] = 0;
    243c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2440:	17fd                	addi	a5,a5,-1
    2442:	177d                	addi	a4,a4,-1
    2444:	c39d                	beqz	a5,246a <basename+0x68>
    2446:	00074603          	lbu	a2,0(a4)
    244a:	feb609e3          	beq	a2,a1,243c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    244e:	02f00613          	li	a2,47
    2452:	a011                	j	2456 <basename+0x54>
    2454:	cb99                	beqz	a5,246a <basename+0x68>
    2456:	853e                	mv	a0,a5
    2458:	17fd                	addi	a5,a5,-1
    245a:	00f68733          	add	a4,a3,a5
    245e:	00074703          	lbu	a4,0(a4)
    2462:	fec719e3          	bne	a4,a2,2454 <basename+0x52>
	return s + i;
    2466:	9536                	add	a0,a0,a3
    2468:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    246a:	8536                	mv	a0,a3
    246c:	8082                	ret
    246e:	6390                	ld	a2,0(a5)
    2470:	00000517          	auipc	a0,0x0
    2474:	5d853503          	ld	a0,1496(a0) # 2a48 <enable_deadlock_detect+0x24e>
    2478:	00000597          	auipc	a1,0x0
    247c:	5d85b583          	ld	a1,1496(a1) # 2a50 <enable_deadlock_detect+0x256>
    2480:	fff64713          	not	a4,a2
    2484:	962a                	add	a2,a2,a0
    2486:	8f71                	and	a4,a4,a2
    2488:	8f6d                	and	a4,a4,a1
    248a:	eb11                	bnez	a4,249e <basename+0x9c>
    248c:	6790                	ld	a2,8(a5)
    248e:	07a1                	addi	a5,a5,8
    2490:	00a60733          	add	a4,a2,a0
    2494:	fff64613          	not	a2,a2
    2498:	8f71                	and	a4,a4,a2
    249a:	8f6d                	and	a4,a4,a1
    249c:	db65                	beqz	a4,248c <basename+0x8a>
	for (; *s; s++)
    249e:	0007c703          	lbu	a4,0(a5)
    24a2:	d749                	beqz	a4,242c <basename+0x2a>
    24a4:	0017c703          	lbu	a4,1(a5)
    24a8:	0785                	addi	a5,a5,1
    24aa:	ff6d                	bnez	a4,24a4 <basename+0xa2>
    24ac:	b741                	j	242c <basename+0x2a>
		return ".";
    24ae:	00000517          	auipc	a0,0x0
    24b2:	59250513          	addi	a0,a0,1426 # 2a40 <enable_deadlock_detect+0x246>
    24b6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24b8:	6290                	ld	a2,0(a3)
    24ba:	00000517          	auipc	a0,0x0
    24be:	58e53503          	ld	a0,1422(a0) # 2a48 <enable_deadlock_detect+0x24e>
    24c2:	00000597          	auipc	a1,0x0
    24c6:	58e5b583          	ld	a1,1422(a1) # 2a50 <enable_deadlock_detect+0x256>
    24ca:	fff64713          	not	a4,a2
    24ce:	962a                	add	a2,a2,a0
    24d0:	8f71                	and	a4,a4,a2
    24d2:	8f6d                	and	a4,a4,a1
    24d4:	df45                	beqz	a4,248c <basename+0x8a>
    24d6:	b7f9                	j	24a4 <basename+0xa2>

00000000000024d8 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    24d8:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    24dc:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24de:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    24e2:	2501                	sext.w	a0,a0
    24e4:	8082                	ret

00000000000024e6 <close>:

int close(int fd)
{
	if (fd == 1) {
    24e6:	4785                	li	a5,1
    24e8:	00f50863          	beq	a0,a5,24f8 <close+0x12>
	register long a7 __asm__("a7") = n;
    24ec:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24f0:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    24f4:	2501                	sext.w	a0,a0
    24f6:	8082                	ret
{
    24f8:	1101                	addi	sp,sp,-32
    24fa:	ec06                	sd	ra,24(sp)
    24fc:	e42a                	sd	a0,8(sp)
		__write_buffer();
    24fe:	cdffe0ef          	jal	ra,11dc <__write_buffer>
		__clear_buffer();
    2502:	d03fe0ef          	jal	ra,1204 <__clear_buffer>
    2506:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2508:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    250c:	00000073          	ecall
}
    2510:	60e2                	ld	ra,24(sp)
    2512:	2501                	sext.w	a0,a0
    2514:	6105                	addi	sp,sp,32
    2516:	8082                	ret

0000000000002518 <read>:
	register long a7 __asm__("a7") = n;
    2518:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    251c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2520:	8082                	ret

0000000000002522 <write>:
	register long a7 __asm__("a7") = n;
    2522:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2526:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    252a:	8082                	ret

000000000000252c <getpid>:
	register long a7 __asm__("a7") = n;
    252c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2530:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2534:	2501                	sext.w	a0,a0
    2536:	8082                	ret

0000000000002538 <getppid>:
	register long a7 __asm__("a7") = n;
    2538:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    253c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2540:	2501                	sext.w	a0,a0
    2542:	8082                	ret

0000000000002544 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2544:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2548:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    254c:	2501                	sext.w	a0,a0
    254e:	8082                	ret

0000000000002550 <fork>:
	register long a7 __asm__("a7") = n;
    2550:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2554:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2558:	2501                	sext.w	a0,a0
    255a:	8082                	ret

000000000000255c <exit>:

void exit(int code)
{
    255c:	1141                	addi	sp,sp,-16
    255e:	e406                	sd	ra,8(sp)
    2560:	e022                	sd	s0,0(sp)
    2562:	842a                	mv	s0,a0
	__write_buffer();
    2564:	c79fe0ef          	jal	ra,11dc <__write_buffer>
	__clear_buffer();
    2568:	c9dfe0ef          	jal	ra,1204 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    256c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2570:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2572:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2576:	60a2                	ld	ra,8(sp)
    2578:	6402                	ld	s0,0(sp)
    257a:	0141                	addi	sp,sp,16
    257c:	8082                	ret

000000000000257e <waitpid>:
	register long a7 __asm__("a7") = n;
    257e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2582:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2586:	2501                	sext.w	a0,a0
    2588:	8082                	ret

000000000000258a <exec>:
	register long a7 __asm__("a7") = n;
    258a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2592:	2501                	sext.w	a0,a0
    2594:	8082                	ret

0000000000002596 <get_mtime>:

int64 get_mtime()
{
    2596:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2598:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    259c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    259e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25a0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    25a4:	2501                	sext.w	a0,a0
    25a6:	ed01                	bnez	a0,25be <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    25a8:	6722                	ld	a4,8(sp)
    25aa:	3e800793          	li	a5,1000
    25ae:	6682                	ld	a3,0(sp)
    25b0:	02f75733          	divu	a4,a4,a5
    25b4:	02d78533          	mul	a0,a5,a3
    25b8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    25ba:	0141                	addi	sp,sp,16
    25bc:	8082                	ret
	return -1;
    25be:	557d                	li	a0,-1
    25c0:	bfed                	j	25ba <get_mtime+0x24>

00000000000025c2 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    25c2:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c6:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    25ca:	2501                	sext.w	a0,a0
    25cc:	8082                	ret

00000000000025ce <sleep>:

int sleep(unsigned long long time)
{
    25ce:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    25d0:	880a                	mv	a6,sp
{
    25d2:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    25d4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25d8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25da:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25dc:	00000073          	ecall
	if (err == 0) {
    25e0:	2501                	sext.w	a0,a0
    25e2:	ed31                	bnez	a0,263e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    25e4:	6722                	ld	a4,8(sp)
    25e6:	3e800793          	li	a5,1000
    25ea:	6682                	ld	a3,0(sp)
    25ec:	02f75733          	divu	a4,a4,a5
    25f0:	02d787b3          	mul	a5,a5,a3
    25f4:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    25f6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25fa:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25fc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fe:	00000073          	ecall
	if (err == 0) {
    2602:	2501                	sext.w	a0,a0
    2604:	e915                	bnez	a0,2638 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2606:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2608:	3e800693          	li	a3,1000
    260c:	a819                	j	2622 <sleep+0x54>
	__asm_syscall("r"(a7))
    260e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2612:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2616:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2618:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261a:	00000073          	ecall
	if (err == 0) {
    261e:	2501                	sext.w	a0,a0
    2620:	ed01                	bnez	a0,2638 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2622:	6722                	ld	a4,8(sp)
    2624:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2626:	07c00893          	li	a7,124
    262a:	02d75733          	divu	a4,a4,a3
    262e:	02f687b3          	mul	a5,a3,a5
    2632:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2634:	fcc7ede3          	bltu	a5,a2,260e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2638:	4501                	li	a0,0
    263a:	0141                	addi	sp,sp,16
    263c:	8082                	ret
    263e:	57fd                	li	a5,-1
    2640:	bf5d                	j	25f6 <sleep+0x28>

0000000000002642 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2642:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2646:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    264a:	2501                	sext.w	a0,a0
    264c:	8082                	ret

000000000000264e <set_priority>:
	register long a7 __asm__("a7") = n;
    264e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2652:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret

000000000000265a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    265a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    265e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2662:	2501                	sext.w	a0,a0
    2664:	8082                	ret

0000000000002666 <munmap>:
	register long a7 __asm__("a7") = n;
    2666:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    266e:	2501                	sext.w	a0,a0
    2670:	8082                	ret

0000000000002672 <wait>:

int wait(int *code)
{
    2672:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2674:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2678:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267a:	00000073          	ecall
	return waitpid(-1, code);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <spawn>:
	register long a7 __asm__("a7") = n;
    2682:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2686:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <pipe>:
	register long a7 __asm__("a7") = n;
    268e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2696:	2501                	sext.w	a0,a0
    2698:	8082                	ret

000000000000269a <mailread>:
	register long a7 __asm__("a7") = n;
    269a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    269e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    26a6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26aa:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <fstat>:
	register long a7 __asm__("a7") = n;
    26b2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <sys_linkat>:
	register long a4 __asm__("a4") = e;
    26be:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    26c0:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    26c4:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26c6:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    26ca:	2501                	sext.w	a0,a0
    26cc:	8082                	ret

00000000000026ce <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    26ce:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    26d0:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    26d4:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26d6:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    26da:	2501                	sext.w	a0,a0
    26dc:	8082                	ret

00000000000026de <link>:

int link(char *old_path, char *new_path)
{
    26de:	87aa                	mv	a5,a0
    26e0:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    26e2:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    26e6:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    26ea:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    26ec:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    26f0:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26f2:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    26f6:	2501                	sext.w	a0,a0
    26f8:	8082                	ret

00000000000026fa <unlink>:

int unlink(char *path)
{
    26fa:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26fc:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2700:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2704:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2706:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    270a:	2501                	sext.w	a0,a0
    270c:	8082                	ret

000000000000270e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    270e:	00000797          	auipc	a5,0x0
    2712:	48a7b783          	ld	a5,1162(a5) # 2b98 <_GLOBAL_OFFSET_TABLE_+0x8>
    2716:	439c                	lw	a5,0(a5)
    2718:	c799                	beqz	a5,2726 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    271a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    271e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2722:	2501                	sext.w	a0,a0
    2724:	8082                	ret
{
    2726:	1101                	addi	sp,sp,-32
    2728:	ec06                	sd	ra,24(sp)
    272a:	e42e                	sd	a1,8(sp)
    272c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    272e:	fe7fe0ef          	jal	ra,1714 <enable_thread_io_buffer>
    2732:	65a2                	ld	a1,8(sp)
    2734:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2736:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    273a:	00000073          	ecall
}
    273e:	60e2                	ld	ra,24(sp)
    2740:	2501                	sext.w	a0,a0
    2742:	6105                	addi	sp,sp,32
    2744:	8082                	ret

0000000000002746 <gettid>:
	register long a7 __asm__("a7") = n;
    2746:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    274a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    274e:	2501                	sext.w	a0,a0
    2750:	8082                	ret

0000000000002752 <waittid>:

int waittid(int tid)
{
    2752:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2754:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2758:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    275c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    275e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2760:	00e51e63          	bne	a0,a4,277c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2764:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2768:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    276c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2770:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2772:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2776:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2778:	fee506e3          	beq	a0,a4,2764 <waittid+0x12>
	}
	return ret;
}
    277c:	8082                	ret

000000000000277e <mutex_create>:
	register long a7 __asm__("a7") = n;
    277e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2782:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2784:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2788:	2501                	sext.w	a0,a0
    278a:	8082                	ret

000000000000278c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    278c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2790:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2792:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2796:	2501                	sext.w	a0,a0
    2798:	8082                	ret

000000000000279a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    279a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    279e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    27a2:	2501                	sext.w	a0,a0
    27a4:	8082                	ret

00000000000027a6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    27a6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    27aa:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    27ae:	2501                	sext.w	a0,a0
    27b0:	8082                	ret

00000000000027b2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    27b2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    27b6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    27ba:	2501                	sext.w	a0,a0
    27bc:	8082                	ret

00000000000027be <semaphore_up>:
	register long a7 __asm__("a7") = n;
    27be:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    27c2:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    27c6:	2501                	sext.w	a0,a0
    27c8:	8082                	ret

00000000000027ca <semaphore_down>:
	register long a7 __asm__("a7") = n;
    27ca:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    27ce:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    27d2:	2501                	sext.w	a0,a0
    27d4:	8082                	ret

00000000000027d6 <condvar_create>:
	register long a7 __asm__("a7") = n;
    27d6:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    27da:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    27de:	2501                	sext.w	a0,a0
    27e0:	8082                	ret

00000000000027e2 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    27e2:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    27e6:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    27ea:	2501                	sext.w	a0,a0
    27ec:	8082                	ret

00000000000027ee <condvar_wait>:
	register long a7 __asm__("a7") = n;
    27ee:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27f2:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    27f6:	2501                	sext.w	a0,a0
    27f8:	8082                	ret

00000000000027fa <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    27fa:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    27fe:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2802:	2501                	sext.w	a0,a0
    2804:	8082                	ret
