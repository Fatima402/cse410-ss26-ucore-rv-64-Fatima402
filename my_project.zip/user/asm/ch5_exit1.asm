
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_exit1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0b9                	j	104e <__start_main>

0000000000001002 <main>:
/*
辅助测例，正常退出，不输出 FAIL 即可。
*/

int main()
{
    1002:	1141                	addi	sp,sp,-16
	exit(-233);
    1004:	f1700513          	li	a0,-233
{
    1008:	e406                	sd	ra,8(sp)
    100a:	e022                	sd	s0,0(sp)
	exit(-233);
    100c:	3fe010ef          	jal	ra,240a <exit>
	panic("FAIL: T.T\n");
    1010:	3ca010ef          	jal	ra,23da <getpid>
    1014:	842a                	mv	s0,a0
    1016:	00001517          	auipc	a0,0x1
    101a:	6a250513          	addi	a0,a0,1698 # 26b8 <enable_deadlock_detect+0x10>
    101e:	292010ef          	jal	ra,22b0 <basename>
    1022:	872a                	mv	a4,a0
    1024:	86a2                	mv	a3,s0
    1026:	47ad                	li	a5,11
    1028:	00001617          	auipc	a2,0x1
    102c:	6d860613          	addi	a2,a2,1752 # 2700 <enable_deadlock_detect+0x58>
    1030:	45fd                	li	a1,31
    1032:	00001517          	auipc	a0,0x1
    1036:	6d650513          	addi	a0,a0,1750 # 2708 <enable_deadlock_detect+0x60>
    103a:	16e000ef          	jal	ra,11a8 <printf>
    103e:	557d                	li	a0,-1
    1040:	3ca010ef          	jal	ra,240a <exit>
	return 0;
    1044:	60a2                	ld	ra,8(sp)
    1046:	6402                	ld	s0,0(sp)
    1048:	4501                	li	a0,0
    104a:	0141                	addi	sp,sp,16
    104c:	8082                	ret

000000000000104e <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    104e:	1141                	addi	sp,sp,-16
    1050:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1052:	fb1ff0ef          	jal	ra,1002 <main>
    1056:	3b4010ef          	jal	ra,240a <exit>
	return 0;
    105a:	60a2                	ld	ra,8(sp)
    105c:	4501                	li	a0,0
    105e:	0141                	addi	sp,sp,16
    1060:	8082                	ret

0000000000001062 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1062:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1064:	4605                	li	a2,1
    1066:	00f10593          	addi	a1,sp,15
    106a:	4501                	li	a0,0
{
    106c:	ec06                	sd	ra,24(sp)
	char byte = 0;
    106e:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1072:	354010ef          	jal	ra,23c6 <read>
    1076:	4785                	li	a5,1
    1078:	00f51763          	bne	a0,a5,1086 <getchar+0x24>
		return byte;
    107c:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1080:	60e2                	ld	ra,24(sp)
    1082:	6105                	addi	sp,sp,32
    1084:	8082                	ret
		return EOF;
    1086:	557d                	li	a0,-1
    1088:	bfe5                	j	1080 <getchar+0x1e>

000000000000108a <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    108a:	00001517          	auipc	a0,0x1
    108e:	79e52503          	lw	a0,1950(a0) # 2828 <buffer_len>
    1092:	e111                	bnez	a0,1096 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1094:	8082                	ret
{
    1096:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1098:	862a                	mv	a2,a0
    109a:	00001597          	auipc	a1,0x1
    109e:	79658593          	addi	a1,a1,1942 # 2830 <buffer>
    10a2:	4505                	li	a0,1
{
    10a4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10a6:	32a010ef          	jal	ra,23d0 <write>
}
    10aa:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10ac:	2501                	sext.w	a0,a0
}
    10ae:	0141                	addi	sp,sp,16
    10b0:	8082                	ret

00000000000010b2 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10b2:	00001797          	auipc	a5,0x1
    10b6:	7607ab23          	sw	zero,1910(a5) # 2828 <buffer_len>
}
    10ba:	8082                	ret

00000000000010bc <__fflush>:
	if (buffer_len == 0)
    10bc:	00001517          	auipc	a0,0x1
    10c0:	76c52503          	lw	a0,1900(a0) # 2828 <buffer_len>
    10c4:	e511                	bnez	a0,10d0 <__fflush+0x14>
	buffer_len = 0;
    10c6:	00001797          	auipc	a5,0x1
    10ca:	7607a123          	sw	zero,1890(a5) # 2828 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10ce:	8082                	ret
{
    10d0:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10d2:	862a                	mv	a2,a0
    10d4:	00001597          	auipc	a1,0x1
    10d8:	75c58593          	addi	a1,a1,1884 # 2830 <buffer>
    10dc:	4505                	li	a0,1
{
    10de:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10e0:	2f0010ef          	jal	ra,23d0 <write>
	return r >= 0 ? 0 : r;
    10e4:	0005079b          	sext.w	a5,a0
}
    10e8:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10ea:	0017a793          	slti	a5,a5,1
    10ee:	40f007bb          	negw	a5,a5
    10f2:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10f4:	00001797          	auipc	a5,0x1
    10f8:	7207aa23          	sw	zero,1844(a5) # 2828 <buffer_len>
	return r >= 0 ? 0 : r;
    10fc:	2501                	sext.w	a0,a0
}
    10fe:	0141                	addi	sp,sp,16
    1100:	8082                	ret

0000000000001102 <fflush>:

int fflush(int fd)
{
    1102:	1101                	addi	sp,sp,-32
    1104:	e822                	sd	s0,16(sp)
    1106:	ec06                	sd	ra,24(sp)
    1108:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    110a:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    110c:	4401                	li	s0,0
	if (fd == 1) {
    110e:	00e50863          	beq	a0,a4,111e <fflush+0x1c>
}
    1112:	60e2                	ld	ra,24(sp)
    1114:	8522                	mv	a0,s0
    1116:	6442                	ld	s0,16(sp)
    1118:	64a2                	ld	s1,8(sp)
    111a:	6105                	addi	sp,sp,32
    111c:	8082                	ret
		if (buffer_lock_enabled == 1) {
    111e:	00001497          	auipc	s1,0x1
    1122:	70a48493          	addi	s1,s1,1802 # 2828 <buffer_len>
    1126:	1084a703          	lw	a4,264(s1)
    112a:	02a70e63          	beq	a4,a0,1166 <fflush+0x64>
	if (buffer_len == 0)
    112e:	4080                	lw	s0,0(s1)
    1130:	c00d                	beqz	s0,1152 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1132:	8622                	mv	a2,s0
    1134:	00001597          	auipc	a1,0x1
    1138:	6fc58593          	addi	a1,a1,1788 # 2830 <buffer>
    113c:	294010ef          	jal	ra,23d0 <write>
	return r >= 0 ? 0 : r;
    1140:	0005079b          	sext.w	a5,a0
    1144:	0017a793          	slti	a5,a5,1
    1148:	40f007bb          	negw	a5,a5
    114c:	8d7d                	and	a0,a0,a5
    114e:	0005041b          	sext.w	s0,a0
}
    1152:	60e2                	ld	ra,24(sp)
    1154:	8522                	mv	a0,s0
    1156:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1158:	00001797          	auipc	a5,0x1
    115c:	6c07a823          	sw	zero,1744(a5) # 2828 <buffer_len>
}
    1160:	64a2                	ld	s1,8(sp)
    1162:	6105                	addi	sp,sp,32
    1164:	8082                	ret
			mutex_lock(buffer_lock);
    1166:	10c4a503          	lw	a0,268(s1)
    116a:	4de010ef          	jal	ra,2648 <mutex_lock>
	if (buffer_len == 0)
    116e:	4080                	lw	s0,0(s1)
    1170:	e811                	bnez	s0,1184 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1172:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1176:	00001797          	auipc	a5,0x1
    117a:	6a07a923          	sw	zero,1714(a5) # 2828 <buffer_len>
			mutex_unlock(buffer_lock);
    117e:	4d6010ef          	jal	ra,2654 <mutex_unlock>
    1182:	bf41                	j	1112 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1184:	8622                	mv	a2,s0
    1186:	00001597          	auipc	a1,0x1
    118a:	6aa58593          	addi	a1,a1,1706 # 2830 <buffer>
    118e:	4505                	li	a0,1
    1190:	240010ef          	jal	ra,23d0 <write>
	return r >= 0 ? 0 : r;
    1194:	0005079b          	sext.w	a5,a0
    1198:	0017a793          	slti	a5,a5,1
    119c:	40f007bb          	negw	a5,a5
    11a0:	8d7d                	and	a0,a0,a5
    11a2:	0005041b          	sext.w	s0,a0
	return r;
    11a6:	b7f1                	j	1172 <fflush+0x70>

00000000000011a8 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11a8:	7131                	addi	sp,sp,-192
    11aa:	e0da                	sd	s6,64(sp)
    11ac:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11ae:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11b0:	013c                	addi	a5,sp,136
{
    11b2:	f0ca                	sd	s2,96(sp)
    11b4:	ecce                	sd	s3,88(sp)
    11b6:	e8d2                	sd	s4,80(sp)
    11b8:	e4d6                	sd	s5,72(sp)
    11ba:	fc86                	sd	ra,120(sp)
    11bc:	f8a2                	sd	s0,112(sp)
    11be:	f4a6                	sd	s1,104(sp)
    11c0:	89aa                	mv	s3,a0
    11c2:	e52e                	sd	a1,136(sp)
    11c4:	e932                	sd	a2,144(sp)
    11c6:	ed36                	sd	a3,152(sp)
    11c8:	f13a                	sd	a4,160(sp)
    11ca:	f942                	sd	a6,176(sp)
    11cc:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11ce:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11d0:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11d4:	00001a17          	auipc	s4,0x1
    11d8:	654a0a13          	addi	s4,s4,1620 # 2828 <buffer_len>
    11dc:	4a85                	li	s5,1
	buf[i++] = '0';
    11de:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11e2:	0009c783          	lbu	a5,0(s3)
    11e6:	18078663          	beqz	a5,1372 <printf+0x1ca>
    11ea:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11ec:	19278d63          	beq	a5,s2,1386 <printf+0x1de>
    11f0:	0015c783          	lbu	a5,1(a1)
    11f4:	0585                	addi	a1,a1,1
    11f6:	fbfd                	bnez	a5,11ec <printf+0x44>
    11f8:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11fa:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    11fe:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1202:	1b578863          	beq	a5,s5,13b2 <printf+0x20a>
		len = out_unlocked(s, l);
    1206:	85a2                	mv	a1,s0
    1208:	854e                	mv	a0,s3
    120a:	42a000ef          	jal	ra,1634 <out_unlocked>
		out(f, a, l);
		if (l)
    120e:	1c041063          	bnez	s0,13ce <printf+0x226>
			continue;
		if (s[1] == 0)
    1212:	0014c783          	lbu	a5,1(s1)
    1216:	14078e63          	beqz	a5,1372 <printf+0x1ca>
			break;
		switch (s[1]) {
    121a:	07300713          	li	a4,115
    121e:	1ce78863          	beq	a5,a4,13ee <printf+0x246>
    1222:	1af76863          	bltu	a4,a5,13d2 <printf+0x22a>
    1226:	06400713          	li	a4,100
    122a:	22e78063          	beq	a5,a4,144a <printf+0x2a2>
    122e:	07000713          	li	a4,112
    1232:	1ee79563          	bne	a5,a4,141c <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1236:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1238:	00001797          	auipc	a5,0x1
    123c:	70078793          	addi	a5,a5,1792 # 2938 <digits>
	buf[i++] = '0';
    1240:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1244:	6298                	ld	a4,0(a3)
    1246:	06a1                	addi	a3,a3,8
    1248:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    124a:	00471393          	slli	t2,a4,0x4
    124e:	00871293          	slli	t0,a4,0x8
    1252:	00c71f93          	slli	t6,a4,0xc
    1256:	01071f13          	slli	t5,a4,0x10
    125a:	01471e93          	slli	t4,a4,0x14
    125e:	01871e13          	slli	t3,a4,0x18
    1262:	01c71893          	slli	a7,a4,0x1c
    1266:	02471813          	slli	a6,a4,0x24
    126a:	02871513          	slli	a0,a4,0x28
    126e:	02c71593          	slli	a1,a4,0x2c
    1272:	03071613          	slli	a2,a4,0x30
    1276:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    127a:	03c75413          	srli	s0,a4,0x3c
    127e:	01c7531b          	srliw	t1,a4,0x1c
    1282:	03c3d393          	srli	t2,t2,0x3c
    1286:	03c2d293          	srli	t0,t0,0x3c
    128a:	03cfdf93          	srli	t6,t6,0x3c
    128e:	03cf5f13          	srli	t5,t5,0x3c
    1292:	03cede93          	srli	t4,t4,0x3c
    1296:	03ce5e13          	srli	t3,t3,0x3c
    129a:	03c8d893          	srli	a7,a7,0x3c
    129e:	03c85813          	srli	a6,a6,0x3c
    12a2:	9171                	srli	a0,a0,0x3c
    12a4:	91f1                	srli	a1,a1,0x3c
    12a6:	9271                	srli	a2,a2,0x3c
    12a8:	92f1                	srli	a3,a3,0x3c
    12aa:	95be                	add	a1,a1,a5
    12ac:	963e                	add	a2,a2,a5
    12ae:	96be                	add	a3,a3,a5
    12b0:	943e                	add	s0,s0,a5
    12b2:	93be                	add	t2,t2,a5
    12b4:	92be                	add	t0,t0,a5
    12b6:	9fbe                	add	t6,t6,a5
    12b8:	9f3e                	add	t5,t5,a5
    12ba:	9ebe                	add	t4,t4,a5
    12bc:	9e3e                	add	t3,t3,a5
    12be:	98be                	add	a7,a7,a5
    12c0:	933e                	add	t1,t1,a5
    12c2:	983e                	add	a6,a6,a5
    12c4:	953e                	add	a0,a0,a5
    12c6:	0005c983          	lbu	s3,0(a1)
    12ca:	00044403          	lbu	s0,0(s0)
    12ce:	00064583          	lbu	a1,0(a2)
    12d2:	0003c383          	lbu	t2,0(t2)
    12d6:	0006c603          	lbu	a2,0(a3)
    12da:	0002c283          	lbu	t0,0(t0)
    12de:	000fcf83          	lbu	t6,0(t6)
    12e2:	000f4f03          	lbu	t5,0(t5)
    12e6:	000ece83          	lbu	t4,0(t4)
    12ea:	000e4e03          	lbu	t3,0(t3)
    12ee:	0008c883          	lbu	a7,0(a7)
    12f2:	00034303          	lbu	t1,0(t1)
    12f6:	00084803          	lbu	a6,0(a6)
    12fa:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12fe:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1302:	92f1                	srli	a3,a3,0x3c
    1304:	8b3d                	andi	a4,a4,15
    1306:	96be                	add	a3,a3,a5
    1308:	97ba                	add	a5,a5,a4
    130a:	00810d23          	sb	s0,26(sp)
    130e:	00710da3          	sb	t2,27(sp)
    1312:	00510e23          	sb	t0,28(sp)
    1316:	01f10ea3          	sb	t6,29(sp)
    131a:	01e10f23          	sb	t5,30(sp)
    131e:	01d10fa3          	sb	t4,31(sp)
    1322:	03c10023          	sb	t3,32(sp)
    1326:	031100a3          	sb	a7,33(sp)
    132a:	02610123          	sb	t1,34(sp)
    132e:	030101a3          	sb	a6,35(sp)
    1332:	02a10223          	sb	a0,36(sp)
    1336:	033102a3          	sb	s3,37(sp)
    133a:	02b10323          	sb	a1,38(sp)
    133e:	02c103a3          	sb	a2,39(sp)
    1342:	0006c683          	lbu	a3,0(a3)
    1346:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    134a:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    134e:	02d10423          	sb	a3,40(sp)
    1352:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1356:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    135a:	11578263          	beq	a5,s5,145e <printf+0x2b6>
		len = out_unlocked(s, l);
    135e:	45c9                	li	a1,18
    1360:	0828                	addi	a0,sp,24
    1362:	2d2000ef          	jal	ra,1634 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1366:	00248993          	addi	s3,s1,2
		if (!*s)
    136a:	0009c783          	lbu	a5,0(s3)
    136e:	e6079ee3          	bnez	a5,11ea <printf+0x42>
	}
	va_end(ap);
    1372:	70e6                	ld	ra,120(sp)
    1374:	7446                	ld	s0,112(sp)
    1376:	74a6                	ld	s1,104(sp)
    1378:	7906                	ld	s2,96(sp)
    137a:	69e6                	ld	s3,88(sp)
    137c:	6a46                	ld	s4,80(sp)
    137e:	6aa6                	ld	s5,72(sp)
    1380:	6b06                	ld	s6,64(sp)
    1382:	6129                	addi	sp,sp,192
    1384:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1386:	0005c783          	lbu	a5,0(a1)
    138a:	84ae                	mv	s1,a1
    138c:	01278963          	beq	a5,s2,139e <printf+0x1f6>
    1390:	b5ad                	j	11fa <printf+0x52>
    1392:	0024c783          	lbu	a5,2(s1)
    1396:	0585                	addi	a1,a1,1
    1398:	0489                	addi	s1,s1,2
    139a:	e72790e3          	bne	a5,s2,11fa <printf+0x52>
    139e:	0014c783          	lbu	a5,1(s1)
    13a2:	ff2788e3          	beq	a5,s2,1392 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13a6:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13aa:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13ae:	e5579ce3          	bne	a5,s5,1206 <printf+0x5e>
		mutex_lock(buffer_lock);
    13b2:	10ca2503          	lw	a0,268(s4)
    13b6:	292010ef          	jal	ra,2648 <mutex_lock>
		len = out_unlocked(s, l);
    13ba:	85a2                	mv	a1,s0
    13bc:	854e                	mv	a0,s3
    13be:	276000ef          	jal	ra,1634 <out_unlocked>
		mutex_unlock(buffer_lock);
    13c2:	10ca2503          	lw	a0,268(s4)
    13c6:	28e010ef          	jal	ra,2654 <mutex_unlock>
		if (l)
    13ca:	e40404e3          	beqz	s0,1212 <printf+0x6a>
    13ce:	89a6                	mv	s3,s1
    13d0:	bd09                	j	11e2 <printf+0x3a>
		switch (s[1]) {
    13d2:	07800713          	li	a4,120
    13d6:	04e79363          	bne	a5,a4,141c <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13da:	67c2                	ld	a5,16(sp)
    13dc:	45c1                	li	a1,16
		s += 2;
    13de:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13e2:	4388                	lw	a0,0(a5)
    13e4:	07a1                	addi	a5,a5,8
    13e6:	e83e                	sd	a5,16(sp)
    13e8:	5f8000ef          	jal	ra,19e0 <printint.constprop.0>
		s += 2;
    13ec:	bfbd                	j	136a <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13ee:	67c2                	ld	a5,16(sp)
    13f0:	6380                	ld	s0,0(a5)
    13f2:	07a1                	addi	a5,a5,8
    13f4:	e83e                	sd	a5,16(sp)
    13f6:	1c040163          	beqz	s0,15b8 <printf+0x410>
			l = strnlen(a, 200);
    13fa:	0c800593          	li	a1,200
    13fe:	8522                	mv	a0,s0
    1400:	3f7000ef          	jal	ra,1ff6 <strnlen>
	if (buffer_lock_enabled == 1) {
    1404:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1408:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    140c:	19578663          	beq	a5,s5,1598 <printf+0x3f0>
		len = out_unlocked(s, l);
    1410:	8522                	mv	a0,s0
    1412:	222000ef          	jal	ra,1634 <out_unlocked>
		s += 2;
    1416:	00248993          	addi	s3,s1,2
    141a:	bf81                	j	136a <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    141c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1420:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1424:	0f578663          	beq	a5,s5,1510 <printf+0x368>
		len = out_unlocked(s, l);
    1428:	0828                	addi	a0,sp,24
    142a:	316000ef          	jal	ra,1740 <out_unlocked.constprop.0>
			putchar(s[1]);
    142e:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1432:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1436:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    143a:	05578163          	beq	a5,s5,147c <printf+0x2d4>
		len = out_unlocked(s, l);
    143e:	0828                	addi	a0,sp,24
    1440:	300000ef          	jal	ra,1740 <out_unlocked.constprop.0>
		s += 2;
    1444:	00248993          	addi	s3,s1,2
    1448:	b70d                	j	136a <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    144a:	67c2                	ld	a5,16(sp)
    144c:	45a9                	li	a1,10
		s += 2;
    144e:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1452:	4388                	lw	a0,0(a5)
    1454:	07a1                	addi	a5,a5,8
    1456:	e83e                	sd	a5,16(sp)
    1458:	588000ef          	jal	ra,19e0 <printint.constprop.0>
		s += 2;
    145c:	b739                	j	136a <printf+0x1c2>
		mutex_lock(buffer_lock);
    145e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1462:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1466:	1e2010ef          	jal	ra,2648 <mutex_lock>
		len = out_unlocked(s, l);
    146a:	45c9                	li	a1,18
    146c:	0828                	addi	a0,sp,24
    146e:	1c6000ef          	jal	ra,1634 <out_unlocked>
		mutex_unlock(buffer_lock);
    1472:	10ca2503          	lw	a0,268(s4)
    1476:	1de010ef          	jal	ra,2654 <mutex_unlock>
		s += 2;
    147a:	bdc5                	j	136a <printf+0x1c2>
		mutex_lock(buffer_lock);
    147c:	10ca2503          	lw	a0,268(s4)
    1480:	1c8010ef          	jal	ra,2648 <mutex_lock>
		buffer[buffer_len++] = c;
    1484:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1488:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    148c:	0017861b          	addiw	a2,a5,1
    1490:	97d2                	add	a5,a5,s4
    1492:	00ca2023          	sw	a2,0(s4)
    1496:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    149a:	00c6cc63          	blt	a3,a2,14b2 <printf+0x30a>
    149e:	47a9                	li	a5,10
    14a0:	06f40663          	beq	s0,a5,150c <printf+0x364>
		mutex_unlock(buffer_lock);
    14a4:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14a8:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14ac:	1a8010ef          	jal	ra,2654 <mutex_unlock>
		s += 2;
    14b0:	bd6d                	j	136a <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14b2:	10000793          	li	a5,256
    14b6:	00f61e63          	bne	a2,a5,14d2 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14ba:	00001597          	auipc	a1,0x1
    14be:	37658593          	addi	a1,a1,886 # 2830 <buffer>
    14c2:	4505                	li	a0,1
    14c4:	70d000ef          	jal	ra,23d0 <write>
	buffer_len = 0;
    14c8:	00001797          	auipc	a5,0x1
    14cc:	3607a023          	sw	zero,864(a5) # 2828 <buffer_len>
			if (r < 0) {
    14d0:	bfd1                	j	14a4 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14d2:	709000ef          	jal	ra,23da <getpid>
    14d6:	842a                	mv	s0,a0
    14d8:	00001517          	auipc	a0,0x1
    14dc:	26050513          	addi	a0,a0,608 # 2738 <enable_deadlock_detect+0x90>
    14e0:	5d1000ef          	jal	ra,22b0 <basename>
    14e4:	872a                	mv	a4,a0
    14e6:	00001617          	auipc	a2,0x1
    14ea:	21a60613          	addi	a2,a2,538 # 2700 <enable_deadlock_detect+0x58>
    14ee:	05400793          	li	a5,84
    14f2:	86a2                	mv	a3,s0
    14f4:	45fd                	li	a1,31
    14f6:	00001517          	auipc	a0,0x1
    14fa:	28250513          	addi	a0,a0,642 # 2778 <enable_deadlock_detect+0xd0>
    14fe:	cabff0ef          	jal	ra,11a8 <printf>
    1502:	557d                	li	a0,-1
    1504:	707000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    1508:	000a2603          	lw	a2,0(s4)
    150c:	de41                	beqz	a2,14a4 <printf+0x2fc>
    150e:	b775                	j	14ba <printf+0x312>
		mutex_lock(buffer_lock);
    1510:	10ca2503          	lw	a0,268(s4)
    1514:	134010ef          	jal	ra,2648 <mutex_lock>
		buffer[buffer_len++] = c;
    1518:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    151c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1520:	0017861b          	addiw	a2,a5,1
    1524:	97d2                	add	a5,a5,s4
    1526:	00ca2023          	sw	a2,0(s4)
    152a:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    152e:	02c6d163          	bge	a3,a2,1550 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1532:	10000793          	li	a5,256
    1536:	02f61263          	bne	a2,a5,155a <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    153a:	00001597          	auipc	a1,0x1
    153e:	2f658593          	addi	a1,a1,758 # 2830 <buffer>
    1542:	4505                	li	a0,1
    1544:	68d000ef          	jal	ra,23d0 <write>
	buffer_len = 0;
    1548:	00001797          	auipc	a5,0x1
    154c:	2e07a023          	sw	zero,736(a5) # 2828 <buffer_len>
		mutex_unlock(buffer_lock);
    1550:	10ca2503          	lw	a0,268(s4)
    1554:	100010ef          	jal	ra,2654 <mutex_unlock>
    1558:	bdd9                	j	142e <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    155a:	681000ef          	jal	ra,23da <getpid>
    155e:	842a                	mv	s0,a0
    1560:	00001517          	auipc	a0,0x1
    1564:	1d850513          	addi	a0,a0,472 # 2738 <enable_deadlock_detect+0x90>
    1568:	549000ef          	jal	ra,22b0 <basename>
    156c:	872a                	mv	a4,a0
    156e:	00001617          	auipc	a2,0x1
    1572:	19260613          	addi	a2,a2,402 # 2700 <enable_deadlock_detect+0x58>
    1576:	05400793          	li	a5,84
    157a:	86a2                	mv	a3,s0
    157c:	45fd                	li	a1,31
    157e:	00001517          	auipc	a0,0x1
    1582:	1fa50513          	addi	a0,a0,506 # 2778 <enable_deadlock_detect+0xd0>
    1586:	c23ff0ef          	jal	ra,11a8 <printf>
    158a:	557d                	li	a0,-1
    158c:	67f000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    1590:	000a2603          	lw	a2,0(s4)
    1594:	de55                	beqz	a2,1550 <printf+0x3a8>
    1596:	b755                	j	153a <printf+0x392>
		mutex_lock(buffer_lock);
    1598:	10ca2503          	lw	a0,268(s4)
    159c:	e42e                	sd	a1,8(sp)
		s += 2;
    159e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15a2:	0a6010ef          	jal	ra,2648 <mutex_lock>
		len = out_unlocked(s, l);
    15a6:	65a2                	ld	a1,8(sp)
    15a8:	8522                	mv	a0,s0
    15aa:	08a000ef          	jal	ra,1634 <out_unlocked>
		mutex_unlock(buffer_lock);
    15ae:	10ca2503          	lw	a0,268(s4)
    15b2:	0a2010ef          	jal	ra,2654 <mutex_unlock>
		s += 2;
    15b6:	bb55                	j	136a <printf+0x1c2>
				a = "(null)";
    15b8:	00001417          	auipc	s0,0x1
    15bc:	17840413          	addi	s0,s0,376 # 2730 <enable_deadlock_detect+0x88>
    15c0:	bd2d                	j	13fa <printf+0x252>

00000000000015c2 <enable_thread_io_buffer>:
{
    15c2:	1101                	addi	sp,sp,-32
    15c4:	e822                	sd	s0,16(sp)
    15c6:	ec06                	sd	ra,24(sp)
    15c8:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15ca:	00001417          	auipc	s0,0x1
    15ce:	25e40413          	addi	s0,s0,606 # 2828 <buffer_len>
    15d2:	05a010ef          	jal	ra,262c <mutex_create>
    15d6:	10a42623          	sw	a0,268(s0)
    15da:	00054a63          	bltz	a0,15ee <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15de:	4785                	li	a5,1
}
    15e0:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15e2:	10f42423          	sw	a5,264(s0)
}
    15e6:	6442                	ld	s0,16(sp)
    15e8:	64a2                	ld	s1,8(sp)
    15ea:	6105                	addi	sp,sp,32
    15ec:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15ee:	5ed000ef          	jal	ra,23da <getpid>
    15f2:	84aa                	mv	s1,a0
    15f4:	00001517          	auipc	a0,0x1
    15f8:	14450513          	addi	a0,a0,324 # 2738 <enable_deadlock_detect+0x90>
    15fc:	4b5000ef          	jal	ra,22b0 <basename>
    1600:	872a                	mv	a4,a0
    1602:	04800793          	li	a5,72
    1606:	86a6                	mv	a3,s1
    1608:	00001517          	auipc	a0,0x1
    160c:	1b050513          	addi	a0,a0,432 # 27b8 <enable_deadlock_detect+0x110>
    1610:	00001617          	auipc	a2,0x1
    1614:	0f060613          	addi	a2,a2,240 # 2700 <enable_deadlock_detect+0x58>
    1618:	45fd                	li	a1,31
    161a:	b8fff0ef          	jal	ra,11a8 <printf>
    161e:	557d                	li	a0,-1
    1620:	5eb000ef          	jal	ra,240a <exit>
	buffer_lock_enabled = 1;
    1624:	4785                	li	a5,1
}
    1626:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1628:	10f42423          	sw	a5,264(s0)
}
    162c:	6442                	ld	s0,16(sp)
    162e:	64a2                	ld	s1,8(sp)
    1630:	6105                	addi	sp,sp,32
    1632:	8082                	ret

0000000000001634 <out_unlocked>:
{
    1634:	7159                	addi	sp,sp,-112
    1636:	f486                	sd	ra,104(sp)
    1638:	f0a2                	sd	s0,96(sp)
    163a:	eca6                	sd	s1,88(sp)
    163c:	e8ca                	sd	s2,80(sp)
    163e:	e4ce                	sd	s3,72(sp)
    1640:	e0d2                	sd	s4,64(sp)
    1642:	fc56                	sd	s5,56(sp)
    1644:	f85a                	sd	s6,48(sp)
    1646:	f45e                	sd	s7,40(sp)
    1648:	f062                	sd	s8,32(sp)
    164a:	ec66                	sd	s9,24(sp)
    164c:	e86a                	sd	s10,16(sp)
    164e:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1650:	0e058663          	beqz	a1,173c <out_unlocked+0x108>
    1654:	842a                	mv	s0,a0
    1656:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    165a:	4981                	li	s3,0
    165c:	00001d17          	auipc	s10,0x1
    1660:	1ccd0d13          	addi	s10,s10,460 # 2828 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1664:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1668:	00001b17          	auipc	s6,0x1
    166c:	1c8b0b13          	addi	s6,s6,456 # 2830 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1670:	10000a93          	li	s5,256
    1674:	00001c97          	auipc	s9,0x1
    1678:	0c4c8c93          	addi	s9,s9,196 # 2738 <enable_deadlock_detect+0x90>
    167c:	00001c17          	auipc	s8,0x1
    1680:	084c0c13          	addi	s8,s8,132 # 2700 <enable_deadlock_detect+0x58>
    1684:	00001b97          	auipc	s7,0x1
    1688:	0f4b8b93          	addi	s7,s7,244 # 2778 <enable_deadlock_detect+0xd0>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168c:	4a29                	li	s4,10
    168e:	a031                	j	169a <out_unlocked+0x66>
    1690:	09468863          	beq	a3,s4,1720 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1694:	0405                	addi	s0,s0,1
    1696:	04848163          	beq	s1,s0,16d8 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    169a:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    169e:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16a2:	0017861b          	addiw	a2,a5,1
    16a6:	97ea                	add	a5,a5,s10
    16a8:	00cd2023          	sw	a2,0(s10)
    16ac:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16b0:	fec950e3          	bge	s2,a2,1690 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16b4:	05561263          	bne	a2,s5,16f8 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16b8:	85da                	mv	a1,s6
    16ba:	4505                	li	a0,1
    16bc:	515000ef          	jal	ra,23d0 <write>
    16c0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16c2:	00001797          	auipc	a5,0x1
    16c6:	1607a323          	sw	zero,358(a5) # 2828 <buffer_len>
			if (r < 0) {
    16ca:	06054763          	bltz	a0,1738 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16ce:	0405                	addi	s0,s0,1
			ret += r;
    16d0:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16d4:	fc8493e3          	bne	s1,s0,169a <out_unlocked+0x66>
}
    16d8:	70a6                	ld	ra,104(sp)
    16da:	7406                	ld	s0,96(sp)
    16dc:	64e6                	ld	s1,88(sp)
    16de:	6946                	ld	s2,80(sp)
    16e0:	6a06                	ld	s4,64(sp)
    16e2:	7ae2                	ld	s5,56(sp)
    16e4:	7b42                	ld	s6,48(sp)
    16e6:	7ba2                	ld	s7,40(sp)
    16e8:	7c02                	ld	s8,32(sp)
    16ea:	6ce2                	ld	s9,24(sp)
    16ec:	6d42                	ld	s10,16(sp)
    16ee:	6da2                	ld	s11,8(sp)
    16f0:	854e                	mv	a0,s3
    16f2:	69a6                	ld	s3,72(sp)
    16f4:	6165                	addi	sp,sp,112
    16f6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16f8:	4e3000ef          	jal	ra,23da <getpid>
    16fc:	8daa                	mv	s11,a0
    16fe:	8566                	mv	a0,s9
    1700:	3b1000ef          	jal	ra,22b0 <basename>
    1704:	872a                	mv	a4,a0
    1706:	8662                	mv	a2,s8
    1708:	05400793          	li	a5,84
    170c:	86ee                	mv	a3,s11
    170e:	45fd                	li	a1,31
    1710:	855e                	mv	a0,s7
    1712:	a97ff0ef          	jal	ra,11a8 <printf>
    1716:	557d                	li	a0,-1
    1718:	4f3000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    171c:	000d2603          	lw	a2,0(s10)
    1720:	da35                	beqz	a2,1694 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1722:	85da                	mv	a1,s6
    1724:	4505                	li	a0,1
    1726:	4ab000ef          	jal	ra,23d0 <write>
    172a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    172c:	00001797          	auipc	a5,0x1
    1730:	0e07ae23          	sw	zero,252(a5) # 2828 <buffer_len>
			if (r < 0) {
    1734:	f8055de3          	bgez	a0,16ce <out_unlocked+0x9a>
    1738:	89aa                	mv	s3,a0
    173a:	bf79                	j	16d8 <out_unlocked+0xa4>
	int ret = 0;
    173c:	4981                	li	s3,0
    173e:	bf69                	j	16d8 <out_unlocked+0xa4>

0000000000001740 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1740:	1101                	addi	sp,sp,-32
    1742:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1744:	00001497          	auipc	s1,0x1
    1748:	0e448493          	addi	s1,s1,228 # 2828 <buffer_len>
    174c:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    174e:	ec06                	sd	ra,24(sp)
    1750:	e822                	sd	s0,16(sp)
		char c = s[i];
    1752:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1756:	0017861b          	addiw	a2,a5,1
    175a:	97a6                	add	a5,a5,s1
    175c:	00e78423          	sb	a4,8(a5)
    1760:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1762:	0ff00793          	li	a5,255
    1766:	00c7cc63          	blt	a5,a2,177e <out_unlocked.constprop.0+0x3e>
    176a:	47a9                	li	a5,10
    176c:	06f70c63          	beq	a4,a5,17e4 <out_unlocked.constprop.0+0xa4>
    1770:	4601                	li	a2,0
}
    1772:	60e2                	ld	ra,24(sp)
    1774:	6442                	ld	s0,16(sp)
    1776:	64a2                	ld	s1,8(sp)
    1778:	8532                	mv	a0,a2
    177a:	6105                	addi	sp,sp,32
    177c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    177e:	10000793          	li	a5,256
    1782:	02f61563          	bne	a2,a5,17ac <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1786:	00001597          	auipc	a1,0x1
    178a:	0aa58593          	addi	a1,a1,170 # 2830 <buffer>
    178e:	4505                	li	a0,1
    1790:	441000ef          	jal	ra,23d0 <write>
}
    1794:	60e2                	ld	ra,24(sp)
    1796:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1798:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    179c:	00001797          	auipc	a5,0x1
    17a0:	0807a623          	sw	zero,140(a5) # 2828 <buffer_len>
}
    17a4:	64a2                	ld	s1,8(sp)
    17a6:	8532                	mv	a0,a2
    17a8:	6105                	addi	sp,sp,32
    17aa:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17ac:	42f000ef          	jal	ra,23da <getpid>
    17b0:	842a                	mv	s0,a0
    17b2:	00001517          	auipc	a0,0x1
    17b6:	f8650513          	addi	a0,a0,-122 # 2738 <enable_deadlock_detect+0x90>
    17ba:	2f7000ef          	jal	ra,22b0 <basename>
    17be:	872a                	mv	a4,a0
    17c0:	00001617          	auipc	a2,0x1
    17c4:	f4060613          	addi	a2,a2,-192 # 2700 <enable_deadlock_detect+0x58>
    17c8:	05400793          	li	a5,84
    17cc:	86a2                	mv	a3,s0
    17ce:	45fd                	li	a1,31
    17d0:	00001517          	auipc	a0,0x1
    17d4:	fa850513          	addi	a0,a0,-88 # 2778 <enable_deadlock_detect+0xd0>
    17d8:	9d1ff0ef          	jal	ra,11a8 <printf>
    17dc:	557d                	li	a0,-1
    17de:	42d000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    17e2:	4090                	lw	a2,0(s1)
    17e4:	d659                	beqz	a2,1772 <out_unlocked.constprop.0+0x32>
    17e6:	b745                	j	1786 <out_unlocked.constprop.0+0x46>

00000000000017e8 <putchar>:
{
    17e8:	7139                	addi	sp,sp,-64
    17ea:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17ec:	00001497          	auipc	s1,0x1
    17f0:	03c48493          	addi	s1,s1,60 # 2828 <buffer_len>
    17f4:	1084a703          	lw	a4,264(s1)
{
    17f8:	f822                	sd	s0,48(sp)
	char byte = c;
    17fa:	0ff57413          	zext.b	s0,a0
{
    17fe:	fc06                	sd	ra,56(sp)
	char byte = c;
    1800:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1804:	4785                	li	a5,1
    1806:	00f70d63          	beq	a4,a5,1820 <putchar+0x38>
		len = out_unlocked(s, l);
    180a:	01f10513          	addi	a0,sp,31
    180e:	f33ff0ef          	jal	ra,1740 <out_unlocked.constprop.0>
}
    1812:	70e2                	ld	ra,56(sp)
    1814:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1816:	862a                	mv	a2,a0
}
    1818:	74a2                	ld	s1,40(sp)
    181a:	8532                	mv	a0,a2
    181c:	6121                	addi	sp,sp,64
    181e:	8082                	ret
		mutex_lock(buffer_lock);
    1820:	10c4a503          	lw	a0,268(s1)
    1824:	625000ef          	jal	ra,2648 <mutex_lock>
		buffer[buffer_len++] = c;
    1828:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    182a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    182e:	0017861b          	addiw	a2,a5,1
    1832:	97a6                	add	a5,a5,s1
    1834:	c090                	sw	a2,0(s1)
    1836:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    183a:	02c6c263          	blt	a3,a2,185e <putchar+0x76>
    183e:	47a9                	li	a5,10
    1840:	06f40d63          	beq	s0,a5,18ba <putchar+0xd2>
    1844:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1846:	10c4a503          	lw	a0,268(s1)
    184a:	e432                	sd	a2,8(sp)
    184c:	609000ef          	jal	ra,2654 <mutex_unlock>
    1850:	6622                	ld	a2,8(sp)
}
    1852:	70e2                	ld	ra,56(sp)
    1854:	7442                	ld	s0,48(sp)
    1856:	74a2                	ld	s1,40(sp)
    1858:	8532                	mv	a0,a2
    185a:	6121                	addi	sp,sp,64
    185c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    185e:	10000793          	li	a5,256
    1862:	02f61063          	bne	a2,a5,1882 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1866:	00001597          	auipc	a1,0x1
    186a:	fca58593          	addi	a1,a1,-54 # 2830 <buffer>
    186e:	4505                	li	a0,1
    1870:	361000ef          	jal	ra,23d0 <write>
    1874:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1878:	00001797          	auipc	a5,0x1
    187c:	fa07a823          	sw	zero,-80(a5) # 2828 <buffer_len>
			if (r < 0) {
    1880:	b7d9                	j	1846 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1882:	359000ef          	jal	ra,23da <getpid>
    1886:	842a                	mv	s0,a0
    1888:	00001517          	auipc	a0,0x1
    188c:	eb050513          	addi	a0,a0,-336 # 2738 <enable_deadlock_detect+0x90>
    1890:	221000ef          	jal	ra,22b0 <basename>
    1894:	872a                	mv	a4,a0
    1896:	00001617          	auipc	a2,0x1
    189a:	e6a60613          	addi	a2,a2,-406 # 2700 <enable_deadlock_detect+0x58>
    189e:	05400793          	li	a5,84
    18a2:	86a2                	mv	a3,s0
    18a4:	45fd                	li	a1,31
    18a6:	00001517          	auipc	a0,0x1
    18aa:	ed250513          	addi	a0,a0,-302 # 2778 <enable_deadlock_detect+0xd0>
    18ae:	8fbff0ef          	jal	ra,11a8 <printf>
    18b2:	557d                	li	a0,-1
    18b4:	357000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    18b8:	4090                	lw	a2,0(s1)
    18ba:	d651                	beqz	a2,1846 <putchar+0x5e>
    18bc:	b76d                	j	1866 <putchar+0x7e>

00000000000018be <puts>:
{
    18be:	7139                	addi	sp,sp,-64
    18c0:	f822                	sd	s0,48(sp)
    18c2:	f426                	sd	s1,40(sp)
    18c4:	fc06                	sd	ra,56(sp)
    18c6:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18c8:	00001417          	auipc	s0,0x1
    18cc:	f6040413          	addi	s0,s0,-160 # 2828 <buffer_len>
{
    18d0:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18d2:	638000ef          	jal	ra,1f0a <strlen>
	if (buffer_lock_enabled == 1) {
    18d6:	10842703          	lw	a4,264(s0)
    18da:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18dc:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18de:	04f70563          	beq	a4,a5,1928 <puts+0x6a>
		len = out_unlocked(s, l);
    18e2:	8526                	mv	a0,s1
    18e4:	d51ff0ef          	jal	ra,1634 <out_unlocked>
    18e8:	892a                	mv	s2,a0
    18ea:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ec:	00095963          	bgez	s2,18fe <puts+0x40>
}
    18f0:	70e2                	ld	ra,56(sp)
    18f2:	7442                	ld	s0,48(sp)
    18f4:	7902                	ld	s2,32(sp)
    18f6:	8526                	mv	a0,s1
    18f8:	74a2                	ld	s1,40(sp)
    18fa:	6121                	addi	sp,sp,64
    18fc:	8082                	ret
	if (buffer_lock_enabled == 1) {
    18fe:	10842703          	lw	a4,264(s0)
	char byte = c;
    1902:	44a9                	li	s1,10
    1904:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1908:	4785                	li	a5,1
    190a:	02f70e63          	beq	a4,a5,1946 <puts+0x88>
		len = out_unlocked(s, l);
    190e:	01f10513          	addi	a0,sp,31
    1912:	e2fff0ef          	jal	ra,1740 <out_unlocked.constprop.0>
}
    1916:	70e2                	ld	ra,56(sp)
    1918:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    191a:	41f5549b          	sraiw	s1,a0,0x1f
}
    191e:	7902                	ld	s2,32(sp)
    1920:	8526                	mv	a0,s1
    1922:	74a2                	ld	s1,40(sp)
    1924:	6121                	addi	sp,sp,64
    1926:	8082                	ret
		mutex_lock(buffer_lock);
    1928:	e42a                	sd	a0,8(sp)
    192a:	10c42503          	lw	a0,268(s0)
    192e:	51b000ef          	jal	ra,2648 <mutex_lock>
		len = out_unlocked(s, l);
    1932:	65a2                	ld	a1,8(sp)
    1934:	8526                	mv	a0,s1
    1936:	cffff0ef          	jal	ra,1634 <out_unlocked>
    193a:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    193c:	10c42503          	lw	a0,268(s0)
    1940:	515000ef          	jal	ra,2654 <mutex_unlock>
    1944:	b75d                	j	18ea <puts+0x2c>
		mutex_lock(buffer_lock);
    1946:	10c42503          	lw	a0,268(s0)
    194a:	4ff000ef          	jal	ra,2648 <mutex_lock>
		buffer[buffer_len++] = c;
    194e:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1950:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1954:	0017861b          	addiw	a2,a5,1
    1958:	97a2                	add	a5,a5,s0
    195a:	c010                	sw	a2,0(s0)
    195c:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1960:	06c6dc63          	bge	a3,a2,19d8 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1964:	10000793          	li	a5,256
    1968:	02f61c63          	bne	a2,a5,19a0 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    196c:	00001597          	auipc	a1,0x1
    1970:	ec458593          	addi	a1,a1,-316 # 2830 <buffer>
    1974:	4505                	li	a0,1
    1976:	25b000ef          	jal	ra,23d0 <write>
			if (r < 0) {
    197a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    197c:	00001797          	auipc	a5,0x1
    1980:	ea07a623          	sw	zero,-340(a5) # 2828 <buffer_len>
			if (r < 0) {
    1984:	04054c63          	bltz	a0,19dc <puts+0x11e>
			if (r < buffer_len) {
    1988:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    198a:	10c42503          	lw	a0,268(s0)
    198e:	4c7000ef          	jal	ra,2654 <mutex_unlock>
}
    1992:	70e2                	ld	ra,56(sp)
    1994:	7442                	ld	s0,48(sp)
    1996:	7902                	ld	s2,32(sp)
    1998:	8526                	mv	a0,s1
    199a:	74a2                	ld	s1,40(sp)
    199c:	6121                	addi	sp,sp,64
    199e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19a0:	23b000ef          	jal	ra,23da <getpid>
    19a4:	84aa                	mv	s1,a0
    19a6:	00001517          	auipc	a0,0x1
    19aa:	d9250513          	addi	a0,a0,-622 # 2738 <enable_deadlock_detect+0x90>
    19ae:	103000ef          	jal	ra,22b0 <basename>
    19b2:	872a                	mv	a4,a0
    19b4:	00001617          	auipc	a2,0x1
    19b8:	d4c60613          	addi	a2,a2,-692 # 2700 <enable_deadlock_detect+0x58>
    19bc:	05400793          	li	a5,84
    19c0:	86a6                	mv	a3,s1
    19c2:	45fd                	li	a1,31
    19c4:	00001517          	auipc	a0,0x1
    19c8:	db450513          	addi	a0,a0,-588 # 2778 <enable_deadlock_detect+0xd0>
    19cc:	fdcff0ef          	jal	ra,11a8 <printf>
    19d0:	557d                	li	a0,-1
    19d2:	239000ef          	jal	ra,240a <exit>
	if (buffer_len == 0)
    19d6:	4010                	lw	a2,0(s0)
    19d8:	da45                	beqz	a2,1988 <puts+0xca>
    19da:	bf49                	j	196c <puts+0xae>
    19dc:	54fd                	li	s1,-1
    19de:	b775                	j	198a <puts+0xcc>

00000000000019e0 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19e0:	715d                	addi	sp,sp,-80
    19e2:	e486                	sd	ra,72(sp)
    19e4:	e0a2                	sd	s0,64(sp)
    19e6:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19e8:	14054363          	bltz	a0,1b2e <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19ec:	02b577bb          	remuw	a5,a0,a1
    19f0:	00001617          	auipc	a2,0x1
    19f4:	f4860613          	addi	a2,a2,-184 # 2938 <digits>
	buf[16] = 0;
    19f8:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19fc:	0005871b          	sext.w	a4,a1
    1a00:	1782                	slli	a5,a5,0x20
    1a02:	9381                	srli	a5,a5,0x20
    1a04:	97b2                	add	a5,a5,a2
    1a06:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a0a:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a0e:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a12:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a14:	0eb56763          	bltu	a0,a1,1b02 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a18:	02e877bb          	remuw	a5,a6,a4
    1a1c:	1782                	slli	a5,a5,0x20
    1a1e:	9381                	srli	a5,a5,0x20
    1a20:	97b2                	add	a5,a5,a2
    1a22:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a26:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a2a:	02f10323          	sb	a5,38(sp)
    1a2e:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a30:	0ce86963          	bltu	a6,a4,1b02 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a34:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a38:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a3c:	1582                	slli	a1,a1,0x20
    1a3e:	9181                	srli	a1,a1,0x20
    1a40:	95b2                	add	a1,a1,a2
    1a42:	0005c583          	lbu	a1,0(a1)
    1a46:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a4a:	0007859b          	sext.w	a1,a5
    1a4e:	16e6e563          	bltu	a3,a4,1bb8 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a52:	02e7f6bb          	remuw	a3,a5,a4
    1a56:	1682                	slli	a3,a3,0x20
    1a58:	9281                	srli	a3,a3,0x20
    1a5a:	96b2                	add	a3,a3,a2
    1a5c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a60:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a64:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a68:	16e5e163          	bltu	a1,a4,1bca <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a6c:	02e876bb          	remuw	a3,a6,a4
    1a70:	1682                	slli	a3,a3,0x20
    1a72:	9281                	srli	a3,a3,0x20
    1a74:	96b2                	add	a3,a3,a2
    1a76:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a7a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a7e:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a82:	14e86d63          	bltu	a6,a4,1bdc <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a86:	02e5f6bb          	remuw	a3,a1,a4
    1a8a:	1682                	slli	a3,a3,0x20
    1a8c:	9281                	srli	a3,a3,0x20
    1a8e:	96b2                	add	a3,a3,a2
    1a90:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a94:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a98:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a9c:	10e5e563          	bltu	a1,a4,1ba6 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1aa0:	02e876bb          	remuw	a3,a6,a4
    1aa4:	1682                	slli	a3,a3,0x20
    1aa6:	9281                	srli	a3,a3,0x20
    1aa8:	96b2                	add	a3,a3,a2
    1aaa:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aae:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ab2:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ab6:	14e86263          	bltu	a6,a4,1bfa <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1aba:	02e5f6bb          	remuw	a3,a1,a4
    1abe:	1682                	slli	a3,a3,0x20
    1ac0:	9281                	srli	a3,a3,0x20
    1ac2:	96b2                	add	a3,a3,a2
    1ac4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ac8:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1acc:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ad0:	14e5e463          	bltu	a1,a4,1c18 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ad4:	02e876bb          	remuw	a3,a6,a4
    1ad8:	1682                	slli	a3,a3,0x20
    1ada:	9281                	srli	a3,a3,0x20
    1adc:	96b2                	add	a3,a3,a2
    1ade:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae2:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ae6:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1aea:	14e86063          	bltu	a6,a4,1c2a <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1aee:	1782                	slli	a5,a5,0x20
    1af0:	9381                	srli	a5,a5,0x20
    1af2:	97b2                	add	a5,a5,a2
    1af4:	0007c703          	lbu	a4,0(a5)
    1af8:	4799                	li	a5,6
    1afa:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1afe:	10054763          	bltz	a0,1c0c <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b02:	00001497          	auipc	s1,0x1
    1b06:	d2648493          	addi	s1,s1,-730 # 2828 <buffer_len>
    1b0a:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b0e:	0828                	addi	a0,sp,24
    1b10:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b12:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b14:	00f50433          	add	s0,a0,a5
    1b18:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b1a:	06e68463          	beq	a3,a4,1b82 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b1e:	8522                	mv	a0,s0
    1b20:	b15ff0ef          	jal	ra,1634 <out_unlocked>
}
    1b24:	60a6                	ld	ra,72(sp)
    1b26:	6406                	ld	s0,64(sp)
    1b28:	74e2                	ld	s1,56(sp)
    1b2a:	6161                	addi	sp,sp,80
    1b2c:	8082                	ret
		x = -xx;
    1b2e:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b32:	02b877bb          	remuw	a5,a6,a1
    1b36:	00001617          	auipc	a2,0x1
    1b3a:	e0260613          	addi	a2,a2,-510 # 2938 <digits>
	buf[16] = 0;
    1b3e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b42:	0005871b          	sext.w	a4,a1
    1b46:	1782                	slli	a5,a5,0x20
    1b48:	9381                	srli	a5,a5,0x20
    1b4a:	97b2                	add	a5,a5,a2
    1b4c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b50:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b54:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b58:	08b86b63          	bltu	a6,a1,1bee <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b5c:	02e8f7bb          	remuw	a5,a7,a4
    1b60:	1782                	slli	a5,a5,0x20
    1b62:	9381                	srli	a5,a5,0x20
    1b64:	97b2                	add	a5,a5,a2
    1b66:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b6a:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b6e:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b72:	ece8f1e3          	bgeu	a7,a4,1a34 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b76:	02d00793          	li	a5,45
    1b7a:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b7e:	47b5                	li	a5,13
    1b80:	b749                	j	1b02 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b82:	10c4a503          	lw	a0,268(s1)
    1b86:	e42e                	sd	a1,8(sp)
    1b88:	2c1000ef          	jal	ra,2648 <mutex_lock>
		len = out_unlocked(s, l);
    1b8c:	65a2                	ld	a1,8(sp)
    1b8e:	8522                	mv	a0,s0
    1b90:	aa5ff0ef          	jal	ra,1634 <out_unlocked>
		mutex_unlock(buffer_lock);
    1b94:	10c4a503          	lw	a0,268(s1)
    1b98:	2bd000ef          	jal	ra,2654 <mutex_unlock>
}
    1b9c:	60a6                	ld	ra,72(sp)
    1b9e:	6406                	ld	s0,64(sp)
    1ba0:	74e2                	ld	s1,56(sp)
    1ba2:	6161                	addi	sp,sp,80
    1ba4:	8082                	ret
		buf[i--] = digits[x % base];
    1ba6:	47a9                	li	a5,10
	if (sign)
    1ba8:	f4055de3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bac:	02d00793          	li	a5,45
    1bb0:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bb4:	47a5                	li	a5,9
    1bb6:	b7b1                	j	1b02 <printint.constprop.0+0x122>
    1bb8:	47b5                	li	a5,13
	if (sign)
    1bba:	f40554e3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bbe:	02d00793          	li	a5,45
    1bc2:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1bc6:	47b1                	li	a5,12
    1bc8:	bf2d                	j	1b02 <printint.constprop.0+0x122>
    1bca:	47b1                	li	a5,12
	if (sign)
    1bcc:	f2055be3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bd0:	02d00793          	li	a5,45
    1bd4:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bd8:	47ad                	li	a5,11
    1bda:	b725                	j	1b02 <printint.constprop.0+0x122>
    1bdc:	47ad                	li	a5,11
	if (sign)
    1bde:	f20552e3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be2:	02d00793          	li	a5,45
    1be6:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1bea:	47a9                	li	a5,10
    1bec:	bf19                	j	1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bee:	02d00793          	li	a5,45
    1bf2:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bf6:	47b9                	li	a5,14
    1bf8:	b729                	j	1b02 <printint.constprop.0+0x122>
    1bfa:	47a5                	li	a5,9
	if (sign)
    1bfc:	f00553e3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c00:	02d00793          	li	a5,45
    1c04:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c08:	47a1                	li	a5,8
    1c0a:	bde5                	j	1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0c:	02d00793          	li	a5,45
    1c10:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c14:	4795                	li	a5,5
    1c16:	b5f5                	j	1b02 <printint.constprop.0+0x122>
    1c18:	47a1                	li	a5,8
	if (sign)
    1c1a:	ee0554e3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1e:	02d00793          	li	a5,45
    1c22:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c26:	479d                	li	a5,7
    1c28:	bde9                	j	1b02 <printint.constprop.0+0x122>
    1c2a:	479d                	li	a5,7
	if (sign)
    1c2c:	ec055be3          	bgez	a0,1b02 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c30:	02d00793          	li	a5,45
    1c34:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c38:	4799                	li	a5,6
    1c3a:	b5e1                	j	1b02 <printint.constprop.0+0x122>

0000000000001c3c <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c3c:	02000793          	li	a5,32
    1c40:	00f50663          	beq	a0,a5,1c4c <isspace+0x10>
    1c44:	355d                	addiw	a0,a0,-9
    1c46:	00553513          	sltiu	a0,a0,5
    1c4a:	8082                	ret
    1c4c:	4505                	li	a0,1
}
    1c4e:	8082                	ret

0000000000001c50 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c50:	fd05051b          	addiw	a0,a0,-48
}
    1c54:	00a53513          	sltiu	a0,a0,10
    1c58:	8082                	ret

0000000000001c5a <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c5a:	02000613          	li	a2,32
    1c5e:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c60:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c64:	ff77869b          	addiw	a3,a5,-9
    1c68:	04c78c63          	beq	a5,a2,1cc0 <atoi+0x66>
    1c6c:	0007871b          	sext.w	a4,a5
    1c70:	04d5f863          	bgeu	a1,a3,1cc0 <atoi+0x66>
		s++;
	switch (*s) {
    1c74:	02b00693          	li	a3,43
    1c78:	04d78963          	beq	a5,a3,1cca <atoi+0x70>
    1c7c:	02d00693          	li	a3,45
    1c80:	06d78263          	beq	a5,a3,1ce4 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c84:	fd07061b          	addiw	a2,a4,-48
    1c88:	47a5                	li	a5,9
    1c8a:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c8c:	4e01                	li	t3,0
	while (isdigit(*s))
    1c8e:	04c7e963          	bltu	a5,a2,1ce0 <atoi+0x86>
	int n = 0, neg = 0;
    1c92:	4501                	li	a0,0
	while (isdigit(*s))
    1c94:	4825                	li	a6,9
    1c96:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c9a:	0025179b          	slliw	a5,a0,0x2
    1c9e:	9fa9                	addw	a5,a5,a0
    1ca0:	fd07031b          	addiw	t1,a4,-48
    1ca4:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ca8:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1cac:	0685                	addi	a3,a3,1
    1cae:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cb2:	0006071b          	sext.w	a4,a2
    1cb6:	feb870e3          	bgeu	a6,a1,1c96 <atoi+0x3c>
	return neg ? n : -n;
    1cba:	000e0563          	beqz	t3,1cc4 <atoi+0x6a>
}
    1cbe:	8082                	ret
		s++;
    1cc0:	0505                	addi	a0,a0,1
    1cc2:	bf79                	j	1c60 <atoi+0x6>
	return neg ? n : -n;
    1cc4:	4113053b          	subw	a0,t1,a7
    1cc8:	8082                	ret
	while (isdigit(*s))
    1cca:	00154703          	lbu	a4,1(a0)
    1cce:	47a5                	li	a5,9
		s++;
    1cd0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cd4:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cd8:	4e01                	li	t3,0
	while (isdigit(*s))
    1cda:	2701                	sext.w	a4,a4
    1cdc:	fac7fbe3          	bgeu	a5,a2,1c92 <atoi+0x38>
    1ce0:	4501                	li	a0,0
}
    1ce2:	8082                	ret
	while (isdigit(*s))
    1ce4:	00154703          	lbu	a4,1(a0)
    1ce8:	47a5                	li	a5,9
		s++;
    1cea:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cee:	fd07061b          	addiw	a2,a4,-48
    1cf2:	2701                	sext.w	a4,a4
    1cf4:	fec7e6e3          	bltu	a5,a2,1ce0 <atoi+0x86>
		neg = 1;
    1cf8:	4e05                	li	t3,1
    1cfa:	bf61                	j	1c92 <atoi+0x38>

0000000000001cfc <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cfc:	16060d63          	beqz	a2,1e76 <memset+0x17a>
    1d00:	40a007b3          	neg	a5,a0
    1d04:	8b9d                	andi	a5,a5,7
    1d06:	00778693          	addi	a3,a5,7
    1d0a:	482d                	li	a6,11
    1d0c:	0ff5f713          	zext.b	a4,a1
    1d10:	fff60593          	addi	a1,a2,-1
    1d14:	1706e263          	bltu	a3,a6,1e78 <memset+0x17c>
    1d18:	16d5ea63          	bltu	a1,a3,1e8c <memset+0x190>
    1d1c:	16078563          	beqz	a5,1e86 <memset+0x18a>
    1d20:	00e50023          	sb	a4,0(a0)
    1d24:	4685                	li	a3,1
    1d26:	00150593          	addi	a1,a0,1
    1d2a:	14d78c63          	beq	a5,a3,1e82 <memset+0x186>
    1d2e:	00e500a3          	sb	a4,1(a0)
    1d32:	4689                	li	a3,2
    1d34:	00250593          	addi	a1,a0,2
    1d38:	14d78d63          	beq	a5,a3,1e92 <memset+0x196>
    1d3c:	00e50123          	sb	a4,2(a0)
    1d40:	468d                	li	a3,3
    1d42:	00350593          	addi	a1,a0,3
    1d46:	12d78b63          	beq	a5,a3,1e7c <memset+0x180>
    1d4a:	00e501a3          	sb	a4,3(a0)
    1d4e:	4691                	li	a3,4
    1d50:	00450593          	addi	a1,a0,4
    1d54:	14d78163          	beq	a5,a3,1e96 <memset+0x19a>
    1d58:	00e50223          	sb	a4,4(a0)
    1d5c:	4695                	li	a3,5
    1d5e:	00550593          	addi	a1,a0,5
    1d62:	12d78c63          	beq	a5,a3,1e9a <memset+0x19e>
    1d66:	00e502a3          	sb	a4,5(a0)
    1d6a:	469d                	li	a3,7
    1d6c:	00650593          	addi	a1,a0,6
    1d70:	12d79763          	bne	a5,a3,1e9e <memset+0x1a2>
    1d74:	00750593          	addi	a1,a0,7
    1d78:	00e50323          	sb	a4,6(a0)
    1d7c:	481d                	li	a6,7
    1d7e:	00871693          	slli	a3,a4,0x8
    1d82:	01071893          	slli	a7,a4,0x10
    1d86:	8ed9                	or	a3,a3,a4
    1d88:	01871313          	slli	t1,a4,0x18
    1d8c:	0116e6b3          	or	a3,a3,a7
    1d90:	0066e6b3          	or	a3,a3,t1
    1d94:	02071893          	slli	a7,a4,0x20
    1d98:	02871e13          	slli	t3,a4,0x28
    1d9c:	0116e6b3          	or	a3,a3,a7
    1da0:	40f60333          	sub	t1,a2,a5
    1da4:	03071893          	slli	a7,a4,0x30
    1da8:	01c6e6b3          	or	a3,a3,t3
    1dac:	0116e6b3          	or	a3,a3,a7
    1db0:	03871e13          	slli	t3,a4,0x38
    1db4:	97aa                	add	a5,a5,a0
    1db6:	ff837893          	andi	a7,t1,-8
    1dba:	01c6e6b3          	or	a3,a3,t3
    1dbe:	98be                	add	a7,a7,a5
    1dc0:	e394                	sd	a3,0(a5)
    1dc2:	07a1                	addi	a5,a5,8
    1dc4:	ff179ee3          	bne	a5,a7,1dc0 <memset+0xc4>
    1dc8:	ff837893          	andi	a7,t1,-8
    1dcc:	011587b3          	add	a5,a1,a7
    1dd0:	010886bb          	addw	a3,a7,a6
    1dd4:	0b130663          	beq	t1,a7,1e80 <memset+0x184>
    1dd8:	00e78023          	sb	a4,0(a5)
    1ddc:	0016859b          	addiw	a1,a3,1
    1de0:	08c5fb63          	bgeu	a1,a2,1e76 <memset+0x17a>
    1de4:	00e780a3          	sb	a4,1(a5)
    1de8:	0026859b          	addiw	a1,a3,2
    1dec:	08c5f563          	bgeu	a1,a2,1e76 <memset+0x17a>
    1df0:	00e78123          	sb	a4,2(a5)
    1df4:	0036859b          	addiw	a1,a3,3
    1df8:	06c5ff63          	bgeu	a1,a2,1e76 <memset+0x17a>
    1dfc:	00e781a3          	sb	a4,3(a5)
    1e00:	0046859b          	addiw	a1,a3,4
    1e04:	06c5f963          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e08:	00e78223          	sb	a4,4(a5)
    1e0c:	0056859b          	addiw	a1,a3,5
    1e10:	06c5f363          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e14:	00e782a3          	sb	a4,5(a5)
    1e18:	0066859b          	addiw	a1,a3,6
    1e1c:	04c5fd63          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e20:	00e78323          	sb	a4,6(a5)
    1e24:	0076859b          	addiw	a1,a3,7
    1e28:	04c5f763          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e2c:	00e783a3          	sb	a4,7(a5)
    1e30:	0086859b          	addiw	a1,a3,8
    1e34:	04c5f163          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e38:	00e78423          	sb	a4,8(a5)
    1e3c:	0096859b          	addiw	a1,a3,9
    1e40:	02c5fb63          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e44:	00e784a3          	sb	a4,9(a5)
    1e48:	00a6859b          	addiw	a1,a3,10
    1e4c:	02c5f563          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e50:	00e78523          	sb	a4,10(a5)
    1e54:	00b6859b          	addiw	a1,a3,11
    1e58:	00c5ff63          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e5c:	00e785a3          	sb	a4,11(a5)
    1e60:	00c6859b          	addiw	a1,a3,12
    1e64:	00c5f963          	bgeu	a1,a2,1e76 <memset+0x17a>
    1e68:	00e78623          	sb	a4,12(a5)
    1e6c:	26b5                	addiw	a3,a3,13
    1e6e:	00c6f463          	bgeu	a3,a2,1e76 <memset+0x17a>
    1e72:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e76:	8082                	ret
    1e78:	46ad                	li	a3,11
    1e7a:	bd79                	j	1d18 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e7c:	480d                	li	a6,3
    1e7e:	b701                	j	1d7e <memset+0x82>
    1e80:	8082                	ret
    1e82:	4805                	li	a6,1
    1e84:	bded                	j	1d7e <memset+0x82>
    1e86:	85aa                	mv	a1,a0
    1e88:	4801                	li	a6,0
    1e8a:	bdd5                	j	1d7e <memset+0x82>
    1e8c:	87aa                	mv	a5,a0
    1e8e:	4681                	li	a3,0
    1e90:	b7a1                	j	1dd8 <memset+0xdc>
    1e92:	4809                	li	a6,2
    1e94:	b5ed                	j	1d7e <memset+0x82>
    1e96:	4811                	li	a6,4
    1e98:	b5dd                	j	1d7e <memset+0x82>
    1e9a:	4815                	li	a6,5
    1e9c:	b5cd                	j	1d7e <memset+0x82>
    1e9e:	4819                	li	a6,6
    1ea0:	bdf9                	j	1d7e <memset+0x82>

0000000000001ea2 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ea2:	00054783          	lbu	a5,0(a0)
    1ea6:	0005c703          	lbu	a4,0(a1)
    1eaa:	00e79863          	bne	a5,a4,1eba <strcmp+0x18>
    1eae:	0505                	addi	a0,a0,1
    1eb0:	0585                	addi	a1,a1,1
    1eb2:	fbe5                	bnez	a5,1ea2 <strcmp>
    1eb4:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1eb6:	9d19                	subw	a0,a0,a4
    1eb8:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1eba:	0007851b          	sext.w	a0,a5
    1ebe:	bfe5                	j	1eb6 <strcmp+0x14>

0000000000001ec0 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ec0:	ca15                	beqz	a2,1ef4 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ec2:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ec6:	167d                	addi	a2,a2,-1
    1ec8:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ecc:	eb99                	bnez	a5,1ee2 <strncmp+0x22>
    1ece:	a815                	j	1f02 <strncmp+0x42>
    1ed0:	00a68e63          	beq	a3,a0,1eec <strncmp+0x2c>
    1ed4:	0505                	addi	a0,a0,1
    1ed6:	00f71b63          	bne	a4,a5,1eec <strncmp+0x2c>
    1eda:	00054783          	lbu	a5,0(a0)
    1ede:	cf89                	beqz	a5,1ef8 <strncmp+0x38>
    1ee0:	85b2                	mv	a1,a2
    1ee2:	0005c703          	lbu	a4,0(a1)
    1ee6:	00158613          	addi	a2,a1,1
    1eea:	f37d                	bnez	a4,1ed0 <strncmp+0x10>
		;
	return *l - *r;
    1eec:	0007851b          	sext.w	a0,a5
    1ef0:	9d19                	subw	a0,a0,a4
    1ef2:	8082                	ret
		return 0;
    1ef4:	4501                	li	a0,0
}
    1ef6:	8082                	ret
	return *l - *r;
    1ef8:	0015c703          	lbu	a4,1(a1)
    1efc:	4501                	li	a0,0
    1efe:	9d19                	subw	a0,a0,a4
    1f00:	8082                	ret
    1f02:	0005c703          	lbu	a4,0(a1)
    1f06:	4501                	li	a0,0
    1f08:	b7e5                	j	1ef0 <strncmp+0x30>

0000000000001f0a <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f0a:	00757793          	andi	a5,a0,7
    1f0e:	cf89                	beqz	a5,1f28 <strlen+0x1e>
    1f10:	87aa                	mv	a5,a0
    1f12:	a029                	j	1f1c <strlen+0x12>
    1f14:	0785                	addi	a5,a5,1
    1f16:	0077f713          	andi	a4,a5,7
    1f1a:	cb01                	beqz	a4,1f2a <strlen+0x20>
		if (!*s)
    1f1c:	0007c703          	lbu	a4,0(a5)
    1f20:	fb75                	bnez	a4,1f14 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f22:	40a78533          	sub	a0,a5,a0
}
    1f26:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f28:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f2a:	6394                	ld	a3,0(a5)
    1f2c:	00001597          	auipc	a1,0x1
    1f30:	8e45b583          	ld	a1,-1820(a1) # 2810 <enable_deadlock_detect+0x168>
    1f34:	00001617          	auipc	a2,0x1
    1f38:	8e463603          	ld	a2,-1820(a2) # 2818 <enable_deadlock_detect+0x170>
    1f3c:	a019                	j	1f42 <strlen+0x38>
    1f3e:	6794                	ld	a3,8(a5)
    1f40:	07a1                	addi	a5,a5,8
    1f42:	00b68733          	add	a4,a3,a1
    1f46:	fff6c693          	not	a3,a3
    1f4a:	8f75                	and	a4,a4,a3
    1f4c:	8f71                	and	a4,a4,a2
    1f4e:	db65                	beqz	a4,1f3e <strlen+0x34>
	for (; *s; s++)
    1f50:	0007c703          	lbu	a4,0(a5)
    1f54:	d779                	beqz	a4,1f22 <strlen+0x18>
    1f56:	0017c703          	lbu	a4,1(a5)
    1f5a:	0785                	addi	a5,a5,1
    1f5c:	d379                	beqz	a4,1f22 <strlen+0x18>
    1f5e:	0017c703          	lbu	a4,1(a5)
    1f62:	0785                	addi	a5,a5,1
    1f64:	fb6d                	bnez	a4,1f56 <strlen+0x4c>
    1f66:	bf75                	j	1f22 <strlen+0x18>

0000000000001f68 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f68:	00757713          	andi	a4,a0,7
{
    1f6c:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f6e:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f72:	cb19                	beqz	a4,1f88 <memchr+0x20>
    1f74:	ce25                	beqz	a2,1fec <memchr+0x84>
    1f76:	0007c703          	lbu	a4,0(a5)
    1f7a:	04b70e63          	beq	a4,a1,1fd6 <memchr+0x6e>
    1f7e:	0785                	addi	a5,a5,1
    1f80:	0077f713          	andi	a4,a5,7
    1f84:	167d                	addi	a2,a2,-1
    1f86:	f77d                	bnez	a4,1f74 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f88:	4501                	li	a0,0
	if (n && *s != c) {
    1f8a:	c235                	beqz	a2,1fee <memchr+0x86>
    1f8c:	0007c703          	lbu	a4,0(a5)
    1f90:	04b70363          	beq	a4,a1,1fd6 <memchr+0x6e>
		size_t k = ONES * c;
    1f94:	00001517          	auipc	a0,0x1
    1f98:	88c53503          	ld	a0,-1908(a0) # 2820 <enable_deadlock_detect+0x178>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f9c:	471d                	li	a4,7
		size_t k = ONES * c;
    1f9e:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fa2:	02c77a63          	bgeu	a4,a2,1fd6 <memchr+0x6e>
    1fa6:	00001897          	auipc	a7,0x1
    1faa:	86a8b883          	ld	a7,-1942(a7) # 2810 <enable_deadlock_detect+0x168>
    1fae:	00001817          	auipc	a6,0x1
    1fb2:	86a83803          	ld	a6,-1942(a6) # 2818 <enable_deadlock_detect+0x170>
    1fb6:	431d                	li	t1,7
    1fb8:	a029                	j	1fc2 <memchr+0x5a>
		     w++, n -= SS)
    1fba:	1661                	addi	a2,a2,-8
    1fbc:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fbe:	02c37963          	bgeu	t1,a2,1ff0 <memchr+0x88>
    1fc2:	6398                	ld	a4,0(a5)
    1fc4:	8f29                	xor	a4,a4,a0
    1fc6:	011706b3          	add	a3,a4,a7
    1fca:	fff74713          	not	a4,a4
    1fce:	8f75                	and	a4,a4,a3
    1fd0:	01077733          	and	a4,a4,a6
    1fd4:	d37d                	beqz	a4,1fba <memchr+0x52>
{
    1fd6:	853e                	mv	a0,a5
    1fd8:	97b2                	add	a5,a5,a2
    1fda:	a021                	j	1fe2 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fdc:	0505                	addi	a0,a0,1
    1fde:	00f50763          	beq	a0,a5,1fec <memchr+0x84>
    1fe2:	00054703          	lbu	a4,0(a0)
    1fe6:	feb71be3          	bne	a4,a1,1fdc <memchr+0x74>
    1fea:	8082                	ret
	return n ? (void *)s : 0;
    1fec:	4501                	li	a0,0
}
    1fee:	8082                	ret
	return n ? (void *)s : 0;
    1ff0:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1ff2:	f275                	bnez	a2,1fd6 <memchr+0x6e>
}
    1ff4:	8082                	ret

0000000000001ff6 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1ff6:	1101                	addi	sp,sp,-32
    1ff8:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1ffa:	862e                	mv	a2,a1
{
    1ffc:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    1ffe:	4581                	li	a1,0
{
    2000:	e426                	sd	s1,8(sp)
    2002:	ec06                	sd	ra,24(sp)
    2004:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2006:	f63ff0ef          	jal	ra,1f68 <memchr>
	return p ? p - s : n;
    200a:	c519                	beqz	a0,2018 <strnlen+0x22>
}
    200c:	60e2                	ld	ra,24(sp)
    200e:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2010:	8d05                	sub	a0,a0,s1
}
    2012:	64a2                	ld	s1,8(sp)
    2014:	6105                	addi	sp,sp,32
    2016:	8082                	ret
    2018:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    201a:	8522                	mv	a0,s0
}
    201c:	6442                	ld	s0,16(sp)
    201e:	64a2                	ld	s1,8(sp)
    2020:	6105                	addi	sp,sp,32
    2022:	8082                	ret

0000000000002024 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2024:	00a5c7b3          	xor	a5,a1,a0
    2028:	8b9d                	andi	a5,a5,7
    202a:	eb95                	bnez	a5,205e <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    202c:	0075f793          	andi	a5,a1,7
    2030:	e7b1                	bnez	a5,207c <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2032:	6198                	ld	a4,0(a1)
    2034:	00000617          	auipc	a2,0x0
    2038:	7dc63603          	ld	a2,2012(a2) # 2810 <enable_deadlock_detect+0x168>
    203c:	00000817          	auipc	a6,0x0
    2040:	7dc83803          	ld	a6,2012(a6) # 2818 <enable_deadlock_detect+0x170>
    2044:	a029                	j	204e <stpcpy+0x2a>
    2046:	05a1                	addi	a1,a1,8
    2048:	e118                	sd	a4,0(a0)
    204a:	6198                	ld	a4,0(a1)
    204c:	0521                	addi	a0,a0,8
    204e:	00c707b3          	add	a5,a4,a2
    2052:	fff74693          	not	a3,a4
    2056:	8ff5                	and	a5,a5,a3
    2058:	0107f7b3          	and	a5,a5,a6
    205c:	d7ed                	beqz	a5,2046 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    205e:	0005c783          	lbu	a5,0(a1)
    2062:	00f50023          	sb	a5,0(a0)
    2066:	c785                	beqz	a5,208e <stpcpy+0x6a>
    2068:	0015c783          	lbu	a5,1(a1)
    206c:	0505                	addi	a0,a0,1
    206e:	0585                	addi	a1,a1,1
    2070:	00f50023          	sb	a5,0(a0)
    2074:	fbf5                	bnez	a5,2068 <stpcpy+0x44>
		;
	return d;
}
    2076:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2078:	0505                	addi	a0,a0,1
    207a:	df45                	beqz	a4,2032 <stpcpy+0xe>
			if (!(*d = *s))
    207c:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2080:	0585                	addi	a1,a1,1
    2082:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2086:	00f50023          	sb	a5,0(a0)
    208a:	f7fd                	bnez	a5,2078 <stpcpy+0x54>
}
    208c:	8082                	ret
    208e:	8082                	ret

0000000000002090 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2090:	00a5c7b3          	xor	a5,a1,a0
    2094:	8b9d                	andi	a5,a5,7
    2096:	1a079863          	bnez	a5,2246 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    209a:	0075f793          	andi	a5,a1,7
    209e:	16078463          	beqz	a5,2206 <stpncpy+0x176>
    20a2:	ea01                	bnez	a2,20b2 <stpncpy+0x22>
    20a4:	a421                	j	22ac <stpncpy+0x21c>
    20a6:	167d                	addi	a2,a2,-1
    20a8:	0505                	addi	a0,a0,1
    20aa:	14070e63          	beqz	a4,2206 <stpncpy+0x176>
    20ae:	1a060863          	beqz	a2,225e <stpncpy+0x1ce>
    20b2:	0005c783          	lbu	a5,0(a1)
    20b6:	0585                	addi	a1,a1,1
    20b8:	0075f713          	andi	a4,a1,7
    20bc:	00f50023          	sb	a5,0(a0)
    20c0:	f3fd                	bnez	a5,20a6 <stpncpy+0x16>
    20c2:	4805                	li	a6,1
    20c4:	1a061863          	bnez	a2,2274 <stpncpy+0x1e4>
    20c8:	40a007b3          	neg	a5,a0
    20cc:	8b9d                	andi	a5,a5,7
    20ce:	4681                	li	a3,0
    20d0:	18061a63          	bnez	a2,2264 <stpncpy+0x1d4>
    20d4:	00778713          	addi	a4,a5,7
    20d8:	45ad                	li	a1,11
    20da:	18b76363          	bltu	a4,a1,2260 <stpncpy+0x1d0>
    20de:	1ae6eb63          	bltu	a3,a4,2294 <stpncpy+0x204>
    20e2:	1a078363          	beqz	a5,2288 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20e6:	00050023          	sb	zero,0(a0)
    20ea:	4685                	li	a3,1
    20ec:	00150713          	addi	a4,a0,1
    20f0:	18d78f63          	beq	a5,a3,228e <stpncpy+0x1fe>
    20f4:	000500a3          	sb	zero,1(a0)
    20f8:	4689                	li	a3,2
    20fa:	00250713          	addi	a4,a0,2
    20fe:	18d78e63          	beq	a5,a3,229a <stpncpy+0x20a>
    2102:	00050123          	sb	zero,2(a0)
    2106:	468d                	li	a3,3
    2108:	00350713          	addi	a4,a0,3
    210c:	16d78c63          	beq	a5,a3,2284 <stpncpy+0x1f4>
    2110:	000501a3          	sb	zero,3(a0)
    2114:	4691                	li	a3,4
    2116:	00450713          	addi	a4,a0,4
    211a:	18d78263          	beq	a5,a3,229e <stpncpy+0x20e>
    211e:	00050223          	sb	zero,4(a0)
    2122:	4695                	li	a3,5
    2124:	00550713          	addi	a4,a0,5
    2128:	16d78d63          	beq	a5,a3,22a2 <stpncpy+0x212>
    212c:	000502a3          	sb	zero,5(a0)
    2130:	469d                	li	a3,7
    2132:	00650713          	addi	a4,a0,6
    2136:	16d79863          	bne	a5,a3,22a6 <stpncpy+0x216>
    213a:	00750713          	addi	a4,a0,7
    213e:	00050323          	sb	zero,6(a0)
    2142:	40f80833          	sub	a6,a6,a5
    2146:	ff887593          	andi	a1,a6,-8
    214a:	97aa                	add	a5,a5,a0
    214c:	95be                	add	a1,a1,a5
    214e:	0007b023          	sd	zero,0(a5)
    2152:	07a1                	addi	a5,a5,8
    2154:	feb79de3          	bne	a5,a1,214e <stpncpy+0xbe>
    2158:	ff887593          	andi	a1,a6,-8
    215c:	9ead                	addw	a3,a3,a1
    215e:	00b707b3          	add	a5,a4,a1
    2162:	12b80863          	beq	a6,a1,2292 <stpncpy+0x202>
    2166:	00078023          	sb	zero,0(a5)
    216a:	0016871b          	addiw	a4,a3,1
    216e:	0ec77863          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    2172:	000780a3          	sb	zero,1(a5)
    2176:	0026871b          	addiw	a4,a3,2
    217a:	0ec77263          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    217e:	00078123          	sb	zero,2(a5)
    2182:	0036871b          	addiw	a4,a3,3
    2186:	0cc77c63          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    218a:	000781a3          	sb	zero,3(a5)
    218e:	0046871b          	addiw	a4,a3,4
    2192:	0cc77663          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    2196:	00078223          	sb	zero,4(a5)
    219a:	0056871b          	addiw	a4,a3,5
    219e:	0cc77063          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21a2:	000782a3          	sb	zero,5(a5)
    21a6:	0066871b          	addiw	a4,a3,6
    21aa:	0ac77a63          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21ae:	00078323          	sb	zero,6(a5)
    21b2:	0076871b          	addiw	a4,a3,7
    21b6:	0ac77463          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21ba:	000783a3          	sb	zero,7(a5)
    21be:	0086871b          	addiw	a4,a3,8
    21c2:	08c77e63          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21c6:	00078423          	sb	zero,8(a5)
    21ca:	0096871b          	addiw	a4,a3,9
    21ce:	08c77863          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21d2:	000784a3          	sb	zero,9(a5)
    21d6:	00a6871b          	addiw	a4,a3,10
    21da:	08c77263          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21de:	00078523          	sb	zero,10(a5)
    21e2:	00b6871b          	addiw	a4,a3,11
    21e6:	06c77c63          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21ea:	000785a3          	sb	zero,11(a5)
    21ee:	00c6871b          	addiw	a4,a3,12
    21f2:	06c77663          	bgeu	a4,a2,225e <stpncpy+0x1ce>
    21f6:	00078623          	sb	zero,12(a5)
    21fa:	26b5                	addiw	a3,a3,13
    21fc:	06c6f163          	bgeu	a3,a2,225e <stpncpy+0x1ce>
    2200:	000786a3          	sb	zero,13(a5)
    2204:	8082                	ret
			;
		if (!n || !*s)
    2206:	c645                	beqz	a2,22ae <stpncpy+0x21e>
    2208:	0005c783          	lbu	a5,0(a1)
    220c:	ea078be3          	beqz	a5,20c2 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2210:	479d                	li	a5,7
    2212:	02c7ff63          	bgeu	a5,a2,2250 <stpncpy+0x1c0>
    2216:	00000897          	auipc	a7,0x0
    221a:	5fa8b883          	ld	a7,1530(a7) # 2810 <enable_deadlock_detect+0x168>
    221e:	00000817          	auipc	a6,0x0
    2222:	5fa83803          	ld	a6,1530(a6) # 2818 <enable_deadlock_detect+0x170>
    2226:	431d                	li	t1,7
    2228:	6198                	ld	a4,0(a1)
    222a:	011707b3          	add	a5,a4,a7
    222e:	fff74693          	not	a3,a4
    2232:	8ff5                	and	a5,a5,a3
    2234:	0107f7b3          	and	a5,a5,a6
    2238:	ef81                	bnez	a5,2250 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    223a:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    223c:	1661                	addi	a2,a2,-8
    223e:	05a1                	addi	a1,a1,8
    2240:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2242:	fec363e3          	bltu	t1,a2,2228 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2246:	e609                	bnez	a2,2250 <stpncpy+0x1c0>
    2248:	a08d                	j	22aa <stpncpy+0x21a>
    224a:	167d                	addi	a2,a2,-1
    224c:	0505                	addi	a0,a0,1
    224e:	ca01                	beqz	a2,225e <stpncpy+0x1ce>
    2250:	0005c783          	lbu	a5,0(a1)
    2254:	0585                	addi	a1,a1,1
    2256:	00f50023          	sb	a5,0(a0)
    225a:	fbe5                	bnez	a5,224a <stpncpy+0x1ba>
		;
tail:
    225c:	b59d                	j	20c2 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    225e:	8082                	ret
    2260:	472d                	li	a4,11
    2262:	bdb5                	j	20de <stpncpy+0x4e>
    2264:	00778713          	addi	a4,a5,7
    2268:	45ad                	li	a1,11
    226a:	fff60693          	addi	a3,a2,-1
    226e:	e6b778e3          	bgeu	a4,a1,20de <stpncpy+0x4e>
    2272:	b7fd                	j	2260 <stpncpy+0x1d0>
    2274:	40a007b3          	neg	a5,a0
    2278:	8832                	mv	a6,a2
    227a:	8b9d                	andi	a5,a5,7
    227c:	4681                	li	a3,0
    227e:	e4060be3          	beqz	a2,20d4 <stpncpy+0x44>
    2282:	b7cd                	j	2264 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2284:	468d                	li	a3,3
    2286:	bd75                	j	2142 <stpncpy+0xb2>
    2288:	872a                	mv	a4,a0
    228a:	4681                	li	a3,0
    228c:	bd5d                	j	2142 <stpncpy+0xb2>
    228e:	4685                	li	a3,1
    2290:	bd4d                	j	2142 <stpncpy+0xb2>
    2292:	8082                	ret
    2294:	87aa                	mv	a5,a0
    2296:	4681                	li	a3,0
    2298:	b5f9                	j	2166 <stpncpy+0xd6>
    229a:	4689                	li	a3,2
    229c:	b55d                	j	2142 <stpncpy+0xb2>
    229e:	4691                	li	a3,4
    22a0:	b54d                	j	2142 <stpncpy+0xb2>
    22a2:	4695                	li	a3,5
    22a4:	bd79                	j	2142 <stpncpy+0xb2>
    22a6:	4699                	li	a3,6
    22a8:	bd69                	j	2142 <stpncpy+0xb2>
    22aa:	8082                	ret
    22ac:	8082                	ret
    22ae:	8082                	ret

00000000000022b0 <basename>:

char *basename(char *s)
{
    22b0:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22b2:	c54d                	beqz	a0,235c <basename+0xac>
    22b4:	00054783          	lbu	a5,0(a0)
		return ".";
    22b8:	00000517          	auipc	a0,0x0
    22bc:	55050513          	addi	a0,a0,1360 # 2808 <enable_deadlock_detect+0x160>
	if (!s || !*s)
    22c0:	e391                	bnez	a5,22c4 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22c2:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22c4:	0076f713          	andi	a4,a3,7
    22c8:	87b6                	mv	a5,a3
    22ca:	cf51                	beqz	a4,2366 <basename+0xb6>
    22cc:	0785                	addi	a5,a5,1
    22ce:	0077f713          	andi	a4,a5,7
    22d2:	c729                	beqz	a4,231c <basename+0x6c>
		if (!*s)
    22d4:	0007c703          	lbu	a4,0(a5)
    22d8:	fb75                	bnez	a4,22cc <basename+0x1c>
	return s - a;
    22da:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22dc:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22de:	cf8d                	beqz	a5,2318 <basename+0x68>
    22e0:	00f68733          	add	a4,a3,a5
    22e4:	02f00593          	li	a1,47
    22e8:	a031                	j	22f4 <basename+0x44>
		s[i] = 0;
    22ea:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22ee:	17fd                	addi	a5,a5,-1
    22f0:	177d                	addi	a4,a4,-1
    22f2:	c39d                	beqz	a5,2318 <basename+0x68>
    22f4:	00074603          	lbu	a2,0(a4)
    22f8:	feb609e3          	beq	a2,a1,22ea <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22fc:	02f00613          	li	a2,47
    2300:	a011                	j	2304 <basename+0x54>
    2302:	cb99                	beqz	a5,2318 <basename+0x68>
    2304:	853e                	mv	a0,a5
    2306:	17fd                	addi	a5,a5,-1
    2308:	00f68733          	add	a4,a3,a5
    230c:	00074703          	lbu	a4,0(a4)
    2310:	fec719e3          	bne	a4,a2,2302 <basename+0x52>
	return s + i;
    2314:	9536                	add	a0,a0,a3
    2316:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2318:	8536                	mv	a0,a3
    231a:	8082                	ret
    231c:	6390                	ld	a2,0(a5)
    231e:	00000517          	auipc	a0,0x0
    2322:	4f253503          	ld	a0,1266(a0) # 2810 <enable_deadlock_detect+0x168>
    2326:	00000597          	auipc	a1,0x0
    232a:	4f25b583          	ld	a1,1266(a1) # 2818 <enable_deadlock_detect+0x170>
    232e:	fff64713          	not	a4,a2
    2332:	962a                	add	a2,a2,a0
    2334:	8f71                	and	a4,a4,a2
    2336:	8f6d                	and	a4,a4,a1
    2338:	eb11                	bnez	a4,234c <basename+0x9c>
    233a:	6790                	ld	a2,8(a5)
    233c:	07a1                	addi	a5,a5,8
    233e:	00a60733          	add	a4,a2,a0
    2342:	fff64613          	not	a2,a2
    2346:	8f71                	and	a4,a4,a2
    2348:	8f6d                	and	a4,a4,a1
    234a:	db65                	beqz	a4,233a <basename+0x8a>
	for (; *s; s++)
    234c:	0007c703          	lbu	a4,0(a5)
    2350:	d749                	beqz	a4,22da <basename+0x2a>
    2352:	0017c703          	lbu	a4,1(a5)
    2356:	0785                	addi	a5,a5,1
    2358:	ff6d                	bnez	a4,2352 <basename+0xa2>
    235a:	b741                	j	22da <basename+0x2a>
		return ".";
    235c:	00000517          	auipc	a0,0x0
    2360:	4ac50513          	addi	a0,a0,1196 # 2808 <enable_deadlock_detect+0x160>
    2364:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2366:	6290                	ld	a2,0(a3)
    2368:	00000517          	auipc	a0,0x0
    236c:	4a853503          	ld	a0,1192(a0) # 2810 <enable_deadlock_detect+0x168>
    2370:	00000597          	auipc	a1,0x0
    2374:	4a85b583          	ld	a1,1192(a1) # 2818 <enable_deadlock_detect+0x170>
    2378:	fff64713          	not	a4,a2
    237c:	962a                	add	a2,a2,a0
    237e:	8f71                	and	a4,a4,a2
    2380:	8f6d                	and	a4,a4,a1
    2382:	df45                	beqz	a4,233a <basename+0x8a>
    2384:	b7f9                	j	2352 <basename+0xa2>

0000000000002386 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2386:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    238a:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    238c:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2390:	2501                	sext.w	a0,a0
    2392:	8082                	ret

0000000000002394 <close>:

int close(int fd)
{
	if (fd == 1) {
    2394:	4785                	li	a5,1
    2396:	00f50863          	beq	a0,a5,23a6 <close+0x12>
	register long a7 __asm__("a7") = n;
    239a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    239e:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23a2:	2501                	sext.w	a0,a0
    23a4:	8082                	ret
{
    23a6:	1101                	addi	sp,sp,-32
    23a8:	ec06                	sd	ra,24(sp)
    23aa:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23ac:	cdffe0ef          	jal	ra,108a <__write_buffer>
		__clear_buffer();
    23b0:	d03fe0ef          	jal	ra,10b2 <__clear_buffer>
    23b4:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23b6:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23ba:	00000073          	ecall
}
    23be:	60e2                	ld	ra,24(sp)
    23c0:	2501                	sext.w	a0,a0
    23c2:	6105                	addi	sp,sp,32
    23c4:	8082                	ret

00000000000023c6 <read>:
	register long a7 __asm__("a7") = n;
    23c6:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ca:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23ce:	8082                	ret

00000000000023d0 <write>:
	register long a7 __asm__("a7") = n;
    23d0:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23d4:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23d8:	8082                	ret

00000000000023da <getpid>:
	register long a7 __asm__("a7") = n;
    23da:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23de:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23e2:	2501                	sext.w	a0,a0
    23e4:	8082                	ret

00000000000023e6 <getppid>:
	register long a7 __asm__("a7") = n;
    23e6:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23ea:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23ee:	2501                	sext.w	a0,a0
    23f0:	8082                	ret

00000000000023f2 <sched_yield>:
	register long a7 __asm__("a7") = n;
    23f2:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23f6:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23fa:	2501                	sext.w	a0,a0
    23fc:	8082                	ret

00000000000023fe <fork>:
	register long a7 __asm__("a7") = n;
    23fe:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2402:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2406:	2501                	sext.w	a0,a0
    2408:	8082                	ret

000000000000240a <exit>:

void exit(int code)
{
    240a:	1141                	addi	sp,sp,-16
    240c:	e406                	sd	ra,8(sp)
    240e:	e022                	sd	s0,0(sp)
    2410:	842a                	mv	s0,a0
	__write_buffer();
    2412:	c79fe0ef          	jal	ra,108a <__write_buffer>
	__clear_buffer();
    2416:	c9dfe0ef          	jal	ra,10b2 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    241a:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    241e:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2420:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2424:	60a2                	ld	ra,8(sp)
    2426:	6402                	ld	s0,0(sp)
    2428:	0141                	addi	sp,sp,16
    242a:	8082                	ret

000000000000242c <waitpid>:
	register long a7 __asm__("a7") = n;
    242c:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2430:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2434:	2501                	sext.w	a0,a0
    2436:	8082                	ret

0000000000002438 <exec>:
	register long a7 __asm__("a7") = n;
    2438:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    243c:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2440:	2501                	sext.w	a0,a0
    2442:	8082                	ret

0000000000002444 <get_mtime>:

int64 get_mtime()
{
    2444:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2446:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    244a:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    244c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    244e:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2452:	2501                	sext.w	a0,a0
    2454:	ed01                	bnez	a0,246c <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2456:	6722                	ld	a4,8(sp)
    2458:	3e800793          	li	a5,1000
    245c:	6682                	ld	a3,0(sp)
    245e:	02f75733          	divu	a4,a4,a5
    2462:	02d78533          	mul	a0,a5,a3
    2466:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2468:	0141                	addi	sp,sp,16
    246a:	8082                	ret
	return -1;
    246c:	557d                	li	a0,-1
    246e:	bfed                	j	2468 <get_mtime+0x24>

0000000000002470 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2470:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2474:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2478:	2501                	sext.w	a0,a0
    247a:	8082                	ret

000000000000247c <sleep>:

int sleep(unsigned long long time)
{
    247c:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    247e:	880a                	mv	a6,sp
{
    2480:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2482:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2486:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2488:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    248a:	00000073          	ecall
	if (err == 0) {
    248e:	2501                	sext.w	a0,a0
    2490:	ed31                	bnez	a0,24ec <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2492:	6722                	ld	a4,8(sp)
    2494:	3e800793          	li	a5,1000
    2498:	6682                	ld	a3,0(sp)
    249a:	02f75733          	divu	a4,a4,a5
    249e:	02d787b3          	mul	a5,a5,a3
    24a2:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24a4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24aa:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ac:	00000073          	ecall
	if (err == 0) {
    24b0:	2501                	sext.w	a0,a0
    24b2:	e915                	bnez	a0,24e6 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24b4:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24b6:	3e800693          	li	a3,1000
    24ba:	a819                	j	24d0 <sleep+0x54>
	__asm_syscall("r"(a7))
    24bc:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24c0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c4:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c8:	00000073          	ecall
	if (err == 0) {
    24cc:	2501                	sext.w	a0,a0
    24ce:	ed01                	bnez	a0,24e6 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24d0:	6722                	ld	a4,8(sp)
    24d2:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24d4:	07c00893          	li	a7,124
    24d8:	02d75733          	divu	a4,a4,a3
    24dc:	02f687b3          	mul	a5,a3,a5
    24e0:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24e2:	fcc7ede3          	bltu	a5,a2,24bc <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24e6:	4501                	li	a0,0
    24e8:	0141                	addi	sp,sp,16
    24ea:	8082                	ret
    24ec:	57fd                	li	a5,-1
    24ee:	bf5d                	j	24a4 <sleep+0x28>

00000000000024f0 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24f0:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24f4:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24f8:	2501                	sext.w	a0,a0
    24fa:	8082                	ret

00000000000024fc <set_priority>:
	register long a7 __asm__("a7") = n;
    24fc:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2500:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2504:	2501                	sext.w	a0,a0
    2506:	8082                	ret

0000000000002508 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2508:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    250c:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2510:	2501                	sext.w	a0,a0
    2512:	8082                	ret

0000000000002514 <munmap>:
	register long a7 __asm__("a7") = n;
    2514:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2518:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    251c:	2501                	sext.w	a0,a0
    251e:	8082                	ret

0000000000002520 <wait>:

int wait(int *code)
{
    2520:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2522:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2526:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2528:	00000073          	ecall
	return waitpid(-1, code);
}
    252c:	2501                	sext.w	a0,a0
    252e:	8082                	ret

0000000000002530 <spawn>:
	register long a7 __asm__("a7") = n;
    2530:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2534:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2538:	2501                	sext.w	a0,a0
    253a:	8082                	ret

000000000000253c <pipe>:
	register long a7 __asm__("a7") = n;
    253c:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2540:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2544:	2501                	sext.w	a0,a0
    2546:	8082                	ret

0000000000002548 <mailread>:
	register long a7 __asm__("a7") = n;
    2548:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254c:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2550:	2501                	sext.w	a0,a0
    2552:	8082                	ret

0000000000002554 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2554:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2558:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    255c:	2501                	sext.w	a0,a0
    255e:	8082                	ret

0000000000002560 <fstat>:
	register long a7 __asm__("a7") = n;
    2560:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2564:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2568:	2501                	sext.w	a0,a0
    256a:	8082                	ret

000000000000256c <sys_linkat>:
	register long a4 __asm__("a4") = e;
    256c:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    256e:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2572:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2574:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2578:	2501                	sext.w	a0,a0
    257a:	8082                	ret

000000000000257c <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    257c:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    257e:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2582:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2584:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2588:	2501                	sext.w	a0,a0
    258a:	8082                	ret

000000000000258c <link>:

int link(char *old_path, char *new_path)
{
    258c:	87aa                	mv	a5,a0
    258e:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2590:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2594:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2598:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    259a:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    259e:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25a0:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25a4:	2501                	sext.w	a0,a0
    25a6:	8082                	ret

00000000000025a8 <unlink>:

int unlink(char *path)
{
    25a8:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25aa:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25ae:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25b2:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25b4:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25b8:	2501                	sext.w	a0,a0
    25ba:	8082                	ret

00000000000025bc <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25bc:	00000797          	auipc	a5,0x0
    25c0:	39c7b783          	ld	a5,924(a5) # 2958 <_GLOBAL_OFFSET_TABLE_+0x8>
    25c4:	439c                	lw	a5,0(a5)
    25c6:	c799                	beqz	a5,25d4 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25c8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25cc:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25d0:	2501                	sext.w	a0,a0
    25d2:	8082                	ret
{
    25d4:	1101                	addi	sp,sp,-32
    25d6:	ec06                	sd	ra,24(sp)
    25d8:	e42e                	sd	a1,8(sp)
    25da:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25dc:	fe7fe0ef          	jal	ra,15c2 <enable_thread_io_buffer>
    25e0:	65a2                	ld	a1,8(sp)
    25e2:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25e4:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e8:	00000073          	ecall
}
    25ec:	60e2                	ld	ra,24(sp)
    25ee:	2501                	sext.w	a0,a0
    25f0:	6105                	addi	sp,sp,32
    25f2:	8082                	ret

00000000000025f4 <gettid>:
	register long a7 __asm__("a7") = n;
    25f4:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25f8:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25fc:	2501                	sext.w	a0,a0
    25fe:	8082                	ret

0000000000002600 <waittid>:

int waittid(int tid)
{
    2600:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2602:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2606:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    260a:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    260c:	2501                	sext.w	a0,a0
	while (ret == -2) {
    260e:	00e51e63          	bne	a0,a4,262a <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2612:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2616:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    261a:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    261e:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2620:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2624:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2626:	fee506e3          	beq	a0,a4,2612 <waittid+0x12>
	}
	return ret;
}
    262a:	8082                	ret

000000000000262c <mutex_create>:
	register long a7 __asm__("a7") = n;
    262c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2630:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2632:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2636:	2501                	sext.w	a0,a0
    2638:	8082                	ret

000000000000263a <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    263a:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    263e:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2640:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2644:	2501                	sext.w	a0,a0
    2646:	8082                	ret

0000000000002648 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2648:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    264c:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2650:	2501                	sext.w	a0,a0
    2652:	8082                	ret

0000000000002654 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2654:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2658:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    265c:	2501                	sext.w	a0,a0
    265e:	8082                	ret

0000000000002660 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2660:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2664:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2668:	2501                	sext.w	a0,a0
    266a:	8082                	ret

000000000000266c <semaphore_up>:
	register long a7 __asm__("a7") = n;
    266c:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2670:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2674:	2501                	sext.w	a0,a0
    2676:	8082                	ret

0000000000002678 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2678:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    267c:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2680:	2501                	sext.w	a0,a0
    2682:	8082                	ret

0000000000002684 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2684:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2688:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    268c:	2501                	sext.w	a0,a0
    268e:	8082                	ret

0000000000002690 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2690:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2694:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2698:	2501                	sext.w	a0,a0
    269a:	8082                	ret

000000000000269c <condvar_wait>:
	register long a7 __asm__("a7") = n;
    269c:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26a0:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26a4:	2501                	sext.w	a0,a0
    26a6:	8082                	ret

00000000000026a8 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26a8:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26ac:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26b0:	2501                	sext.w	a0,a0
    26b2:	8082                	ret
