
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/__ch2_bad_address:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a021                	j	1008 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

int main()
{
	int *p = (int *)0;
	*p = 0;
    1002:	00002023          	sw	zero,0(zero) # 0 <_start-0x1000>
    1006:	9002                	ebreak

0000000000001008 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1008:	1141                	addi	sp,sp,-16
    100a:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    100c:	ff7ff0ef          	jal	ra,1002 <main>
    1010:	090000ef          	jal	ra,10a0 <exit>
	return 0;
    1014:	60a2                	ld	ra,8(sp)
    1016:	4501                	li	a0,0
    1018:	0141                	addi	sp,sp,16
    101a:	8082                	ret

000000000000101c <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    101c:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    1020:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1022:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    1026:	2501                	sext.w	a0,a0
    1028:	8082                	ret

000000000000102a <close>:

int close(int fd)
{
	if (fd == 1) {
    102a:	4785                	li	a5,1
    102c:	00f50863          	beq	a0,a5,103c <close+0x12>
	register long a7 __asm__("a7") = n;
    1030:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1034:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    1038:	2501                	sext.w	a0,a0
    103a:	8082                	ret
{
    103c:	1101                	addi	sp,sp,-32
    103e:	ec06                	sd	ra,24(sp)
    1040:	e42a                	sd	a0,8(sp)
		__write_buffer();
    1042:	330000ef          	jal	ra,1372 <__write_buffer>
		__clear_buffer();
    1046:	354000ef          	jal	ra,139a <__clear_buffer>
    104a:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    104c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1050:	00000073          	ecall
}
    1054:	60e2                	ld	ra,24(sp)
    1056:	2501                	sext.w	a0,a0
    1058:	6105                	addi	sp,sp,32
    105a:	8082                	ret

000000000000105c <read>:
	register long a7 __asm__("a7") = n;
    105c:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1060:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    1064:	8082                	ret

0000000000001066 <write>:
	register long a7 __asm__("a7") = n;
    1066:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    106a:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    106e:	8082                	ret

0000000000001070 <getpid>:
	register long a7 __asm__("a7") = n;
    1070:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    1074:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    1078:	2501                	sext.w	a0,a0
    107a:	8082                	ret

000000000000107c <getppid>:
	register long a7 __asm__("a7") = n;
    107c:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    1080:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    1084:	2501                	sext.w	a0,a0
    1086:	8082                	ret

0000000000001088 <sched_yield>:
	register long a7 __asm__("a7") = n;
    1088:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    108c:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    1090:	2501                	sext.w	a0,a0
    1092:	8082                	ret

0000000000001094 <fork>:
	register long a7 __asm__("a7") = n;
    1094:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    1098:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    109c:	2501                	sext.w	a0,a0
    109e:	8082                	ret

00000000000010a0 <exit>:

void exit(int code)
{
    10a0:	1141                	addi	sp,sp,-16
    10a2:	e406                	sd	ra,8(sp)
    10a4:	e022                	sd	s0,0(sp)
    10a6:	842a                	mv	s0,a0
	__write_buffer();
    10a8:	2ca000ef          	jal	ra,1372 <__write_buffer>
	__clear_buffer();
    10ac:	2ee000ef          	jal	ra,139a <__clear_buffer>
	register long a7 __asm__("a7") = n;
    10b0:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    10b4:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    10b6:	00000073          	ecall
	syscall(SYS_exit, code);
}
    10ba:	60a2                	ld	ra,8(sp)
    10bc:	6402                	ld	s0,0(sp)
    10be:	0141                	addi	sp,sp,16
    10c0:	8082                	ret

00000000000010c2 <waitpid>:
	register long a7 __asm__("a7") = n;
    10c2:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10c6:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    10ca:	2501                	sext.w	a0,a0
    10cc:	8082                	ret

00000000000010ce <exec>:
	register long a7 __asm__("a7") = n;
    10ce:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10d2:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    10d6:	2501                	sext.w	a0,a0
    10d8:	8082                	ret

00000000000010da <get_mtime>:

int64 get_mtime()
{
    10da:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    10dc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    10e0:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    10e2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10e4:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    10e8:	2501                	sext.w	a0,a0
    10ea:	ed01                	bnez	a0,1102 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    10ec:	6722                	ld	a4,8(sp)
    10ee:	3e800793          	li	a5,1000
    10f2:	6682                	ld	a3,0(sp)
    10f4:	02f75733          	divu	a4,a4,a5
    10f8:	02d78533          	mul	a0,a5,a3
    10fc:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    10fe:	0141                	addi	sp,sp,16
    1100:	8082                	ret
	return -1;
    1102:	557d                	li	a0,-1
    1104:	bfed                	j	10fe <get_mtime+0x24>

0000000000001106 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    1106:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    110a:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    110e:	2501                	sext.w	a0,a0
    1110:	8082                	ret

0000000000001112 <sleep>:

int sleep(unsigned long long time)
{
    1112:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    1114:	880a                	mv	a6,sp
{
    1116:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    1118:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    111c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    111e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1120:	00000073          	ecall
	if (err == 0) {
    1124:	2501                	sext.w	a0,a0
    1126:	ed31                	bnez	a0,1182 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    1128:	6722                	ld	a4,8(sp)
    112a:	3e800793          	li	a5,1000
    112e:	6682                	ld	a3,0(sp)
    1130:	02f75733          	divu	a4,a4,a5
    1134:	02d787b3          	mul	a5,a5,a3
    1138:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    113a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    113e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1140:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1142:	00000073          	ecall
	if (err == 0) {
    1146:	2501                	sext.w	a0,a0
    1148:	e915                	bnez	a0,117c <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    114a:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    114c:	3e800693          	li	a3,1000
    1150:	a819                	j	1166 <sleep+0x54>
	__asm_syscall("r"(a7))
    1152:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    1156:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    115a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    115c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    115e:	00000073          	ecall
	if (err == 0) {
    1162:	2501                	sext.w	a0,a0
    1164:	ed01                	bnez	a0,117c <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    1166:	6722                	ld	a4,8(sp)
    1168:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    116a:	07c00893          	li	a7,124
    116e:	02d75733          	divu	a4,a4,a3
    1172:	02f687b3          	mul	a5,a3,a5
    1176:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    1178:	fcc7ede3          	bltu	a5,a2,1152 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    117c:	4501                	li	a0,0
    117e:	0141                	addi	sp,sp,16
    1180:	8082                	ret
    1182:	57fd                	li	a5,-1
    1184:	bf5d                	j	113a <sleep+0x28>

0000000000001186 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    1186:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    118a:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    118e:	2501                	sext.w	a0,a0
    1190:	8082                	ret

0000000000001192 <set_priority>:
	register long a7 __asm__("a7") = n;
    1192:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    1196:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    119a:	2501                	sext.w	a0,a0
    119c:	8082                	ret

000000000000119e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    119e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    11a2:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    11a6:	2501                	sext.w	a0,a0
    11a8:	8082                	ret

00000000000011aa <munmap>:
	register long a7 __asm__("a7") = n;
    11aa:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11ae:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    11b2:	2501                	sext.w	a0,a0
    11b4:	8082                	ret

00000000000011b6 <wait>:

int wait(int *code)
{
    11b6:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    11b8:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    11bc:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11be:	00000073          	ecall
	return waitpid(-1, code);
}
    11c2:	2501                	sext.w	a0,a0
    11c4:	8082                	ret

00000000000011c6 <spawn>:
	register long a7 __asm__("a7") = n;
    11c6:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    11ca:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    11ce:	2501                	sext.w	a0,a0
    11d0:	8082                	ret

00000000000011d2 <pipe>:
	register long a7 __asm__("a7") = n;
    11d2:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    11d6:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    11da:	2501                	sext.w	a0,a0
    11dc:	8082                	ret

00000000000011de <mailread>:
	register long a7 __asm__("a7") = n;
    11de:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11e2:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    11e6:	2501                	sext.w	a0,a0
    11e8:	8082                	ret

00000000000011ea <mailwrite>:
	register long a7 __asm__("a7") = n;
    11ea:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    11ee:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    11f2:	2501                	sext.w	a0,a0
    11f4:	8082                	ret

00000000000011f6 <fstat>:
	register long a7 __asm__("a7") = n;
    11f6:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11fa:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    11fe:	2501                	sext.w	a0,a0
    1200:	8082                	ret

0000000000001202 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    1202:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    1204:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    1208:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    120a:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    120e:	2501                	sext.w	a0,a0
    1210:	8082                	ret

0000000000001212 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    1212:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    1214:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    1218:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    121a:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    121e:	2501                	sext.w	a0,a0
    1220:	8082                	ret

0000000000001222 <link>:

int link(char *old_path, char *new_path)
{
    1222:	87aa                	mv	a5,a0
    1224:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    1226:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    122a:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    122e:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    1230:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    1234:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1236:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    123a:	2501                	sext.w	a0,a0
    123c:	8082                	ret

000000000000123e <unlink>:

int unlink(char *path)
{
    123e:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    1240:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    1244:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    1248:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    124a:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    124e:	2501                	sext.w	a0,a0
    1250:	8082                	ret

0000000000001252 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    1252:	00001797          	auipc	a5,0x1
    1256:	64e7b783          	ld	a5,1614(a5) # 28a0 <_GLOBAL_OFFSET_TABLE_+0x8>
    125a:	439c                	lw	a5,0(a5)
    125c:	c799                	beqz	a5,126a <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    125e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1262:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    1266:	2501                	sext.w	a0,a0
    1268:	8082                	ret
{
    126a:	1101                	addi	sp,sp,-32
    126c:	ec06                	sd	ra,24(sp)
    126e:	e42e                	sd	a1,8(sp)
    1270:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    1272:	638000ef          	jal	ra,18aa <enable_thread_io_buffer>
    1276:	65a2                	ld	a1,8(sp)
    1278:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    127a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    127e:	00000073          	ecall
}
    1282:	60e2                	ld	ra,24(sp)
    1284:	2501                	sext.w	a0,a0
    1286:	6105                	addi	sp,sp,32
    1288:	8082                	ret

000000000000128a <gettid>:
	register long a7 __asm__("a7") = n;
    128a:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    128e:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    1292:	2501                	sext.w	a0,a0
    1294:	8082                	ret

0000000000001296 <waittid>:

int waittid(int tid)
{
    1296:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    1298:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    129c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    12a0:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    12a2:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12a4:	00e51e63          	bne	a0,a4,12c0 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    12a8:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    12ac:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    12b0:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    12b4:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    12b6:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    12ba:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12bc:	fee506e3          	beq	a0,a4,12a8 <waittid+0x12>
	}
	return ret;
}
    12c0:	8082                	ret

00000000000012c2 <mutex_create>:
	register long a7 __asm__("a7") = n;
    12c2:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12c6:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    12c8:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    12cc:	2501                	sext.w	a0,a0
    12ce:	8082                	ret

00000000000012d0 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    12d0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12d4:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    12d6:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    12da:	2501                	sext.w	a0,a0
    12dc:	8082                	ret

00000000000012de <mutex_lock>:
	register long a7 __asm__("a7") = n;
    12de:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    12e2:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    12e6:	2501                	sext.w	a0,a0
    12e8:	8082                	ret

00000000000012ea <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    12ea:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    12ee:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    12f2:	2501                	sext.w	a0,a0
    12f4:	8082                	ret

00000000000012f6 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    12f6:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    12fa:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    12fe:	2501                	sext.w	a0,a0
    1300:	8082                	ret

0000000000001302 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    1302:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    1306:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    130a:	2501                	sext.w	a0,a0
    130c:	8082                	ret

000000000000130e <semaphore_down>:
	register long a7 __asm__("a7") = n;
    130e:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    1312:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    1316:	2501                	sext.w	a0,a0
    1318:	8082                	ret

000000000000131a <condvar_create>:
	register long a7 __asm__("a7") = n;
    131a:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    131e:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    1322:	2501                	sext.w	a0,a0
    1324:	8082                	ret

0000000000001326 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    1326:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    132a:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    132e:	2501                	sext.w	a0,a0
    1330:	8082                	ret

0000000000001332 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    1332:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1336:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    133a:	2501                	sext.w	a0,a0
    133c:	8082                	ret

000000000000133e <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    133e:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    1342:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    1346:	2501                	sext.w	a0,a0
    1348:	8082                	ret

000000000000134a <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    134a:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    134c:	4605                	li	a2,1
    134e:	00f10593          	addi	a1,sp,15
    1352:	4501                	li	a0,0
{
    1354:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1356:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    135a:	d03ff0ef          	jal	ra,105c <read>
    135e:	4785                	li	a5,1
    1360:	00f51763          	bne	a0,a5,136e <getchar+0x24>
		return byte;
    1364:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1368:	60e2                	ld	ra,24(sp)
    136a:	6105                	addi	sp,sp,32
    136c:	8082                	ret
		return EOF;
    136e:	557d                	li	a0,-1
    1370:	bfe5                	j	1368 <getchar+0x1e>

0000000000001372 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1372:	00001517          	auipc	a0,0x1
    1376:	3fe52503          	lw	a0,1022(a0) # 2770 <buffer_len>
    137a:	e111                	bnez	a0,137e <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    137c:	8082                	ret
{
    137e:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1380:	862a                	mv	a2,a0
    1382:	00001597          	auipc	a1,0x1
    1386:	3f658593          	addi	a1,a1,1014 # 2778 <buffer>
    138a:	4505                	li	a0,1
{
    138c:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    138e:	cd9ff0ef          	jal	ra,1066 <write>
}
    1392:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1394:	2501                	sext.w	a0,a0
}
    1396:	0141                	addi	sp,sp,16
    1398:	8082                	ret

000000000000139a <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    139a:	00001797          	auipc	a5,0x1
    139e:	3c07ab23          	sw	zero,982(a5) # 2770 <buffer_len>
}
    13a2:	8082                	ret

00000000000013a4 <__fflush>:
	if (buffer_len == 0)
    13a4:	00001517          	auipc	a0,0x1
    13a8:	3cc52503          	lw	a0,972(a0) # 2770 <buffer_len>
    13ac:	e511                	bnez	a0,13b8 <__fflush+0x14>
	buffer_len = 0;
    13ae:	00001797          	auipc	a5,0x1
    13b2:	3c07a123          	sw	zero,962(a5) # 2770 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13b6:	8082                	ret
{
    13b8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13ba:	862a                	mv	a2,a0
    13bc:	00001597          	auipc	a1,0x1
    13c0:	3bc58593          	addi	a1,a1,956 # 2778 <buffer>
    13c4:	4505                	li	a0,1
{
    13c6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13c8:	c9fff0ef          	jal	ra,1066 <write>
	return r >= 0 ? 0 : r;
    13cc:	0005079b          	sext.w	a5,a0
}
    13d0:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13d2:	0017a793          	slti	a5,a5,1
    13d6:	40f007bb          	negw	a5,a5
    13da:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13dc:	00001797          	auipc	a5,0x1
    13e0:	3807aa23          	sw	zero,916(a5) # 2770 <buffer_len>
	return r >= 0 ? 0 : r;
    13e4:	2501                	sext.w	a0,a0
}
    13e6:	0141                	addi	sp,sp,16
    13e8:	8082                	ret

00000000000013ea <fflush>:

int fflush(int fd)
{
    13ea:	1101                	addi	sp,sp,-32
    13ec:	e822                	sd	s0,16(sp)
    13ee:	ec06                	sd	ra,24(sp)
    13f0:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13f2:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13f4:	4401                	li	s0,0
	if (fd == 1) {
    13f6:	00e50863          	beq	a0,a4,1406 <fflush+0x1c>
}
    13fa:	60e2                	ld	ra,24(sp)
    13fc:	8522                	mv	a0,s0
    13fe:	6442                	ld	s0,16(sp)
    1400:	64a2                	ld	s1,8(sp)
    1402:	6105                	addi	sp,sp,32
    1404:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1406:	00001497          	auipc	s1,0x1
    140a:	36a48493          	addi	s1,s1,874 # 2770 <buffer_len>
    140e:	1084a703          	lw	a4,264(s1)
    1412:	02a70e63          	beq	a4,a0,144e <fflush+0x64>
	if (buffer_len == 0)
    1416:	4080                	lw	s0,0(s1)
    1418:	c00d                	beqz	s0,143a <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    141a:	8622                	mv	a2,s0
    141c:	00001597          	auipc	a1,0x1
    1420:	35c58593          	addi	a1,a1,860 # 2778 <buffer>
    1424:	c43ff0ef          	jal	ra,1066 <write>
	return r >= 0 ? 0 : r;
    1428:	0005079b          	sext.w	a5,a0
    142c:	0017a793          	slti	a5,a5,1
    1430:	40f007bb          	negw	a5,a5
    1434:	8d7d                	and	a0,a0,a5
    1436:	0005041b          	sext.w	s0,a0
}
    143a:	60e2                	ld	ra,24(sp)
    143c:	8522                	mv	a0,s0
    143e:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1440:	00001797          	auipc	a5,0x1
    1444:	3207a823          	sw	zero,816(a5) # 2770 <buffer_len>
}
    1448:	64a2                	ld	s1,8(sp)
    144a:	6105                	addi	sp,sp,32
    144c:	8082                	ret
			mutex_lock(buffer_lock);
    144e:	10c4a503          	lw	a0,268(s1)
    1452:	e8dff0ef          	jal	ra,12de <mutex_lock>
	if (buffer_len == 0)
    1456:	4080                	lw	s0,0(s1)
    1458:	e811                	bnez	s0,146c <fflush+0x82>
			mutex_unlock(buffer_lock);
    145a:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    145e:	00001797          	auipc	a5,0x1
    1462:	3007a923          	sw	zero,786(a5) # 2770 <buffer_len>
			mutex_unlock(buffer_lock);
    1466:	e85ff0ef          	jal	ra,12ea <mutex_unlock>
    146a:	bf41                	j	13fa <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    146c:	8622                	mv	a2,s0
    146e:	00001597          	auipc	a1,0x1
    1472:	30a58593          	addi	a1,a1,778 # 2778 <buffer>
    1476:	4505                	li	a0,1
    1478:	befff0ef          	jal	ra,1066 <write>
	return r >= 0 ? 0 : r;
    147c:	0005079b          	sext.w	a5,a0
    1480:	0017a793          	slti	a5,a5,1
    1484:	40f007bb          	negw	a5,a5
    1488:	8d7d                	and	a0,a0,a5
    148a:	0005041b          	sext.w	s0,a0
	return r;
    148e:	b7f1                	j	145a <fflush+0x70>

0000000000001490 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1490:	7131                	addi	sp,sp,-192
    1492:	e0da                	sd	s6,64(sp)
    1494:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1496:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1498:	013c                	addi	a5,sp,136
{
    149a:	f0ca                	sd	s2,96(sp)
    149c:	ecce                	sd	s3,88(sp)
    149e:	e8d2                	sd	s4,80(sp)
    14a0:	e4d6                	sd	s5,72(sp)
    14a2:	fc86                	sd	ra,120(sp)
    14a4:	f8a2                	sd	s0,112(sp)
    14a6:	f4a6                	sd	s1,104(sp)
    14a8:	89aa                	mv	s3,a0
    14aa:	e52e                	sd	a1,136(sp)
    14ac:	e932                	sd	a2,144(sp)
    14ae:	ed36                	sd	a3,152(sp)
    14b0:	f13a                	sd	a4,160(sp)
    14b2:	f942                	sd	a6,176(sp)
    14b4:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14b6:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14b8:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14bc:	00001a17          	auipc	s4,0x1
    14c0:	2b4a0a13          	addi	s4,s4,692 # 2770 <buffer_len>
    14c4:	4a85                	li	s5,1
	buf[i++] = '0';
    14c6:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14ca:	0009c783          	lbu	a5,0(s3)
    14ce:	18078663          	beqz	a5,165a <printf+0x1ca>
    14d2:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14d4:	19278d63          	beq	a5,s2,166e <printf+0x1de>
    14d8:	0015c783          	lbu	a5,1(a1)
    14dc:	0585                	addi	a1,a1,1
    14de:	fbfd                	bnez	a5,14d4 <printf+0x44>
    14e0:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14e2:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14e6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14ea:	1b578863          	beq	a5,s5,169a <printf+0x20a>
		len = out_unlocked(s, l);
    14ee:	85a2                	mv	a1,s0
    14f0:	854e                	mv	a0,s3
    14f2:	42a000ef          	jal	ra,191c <out_unlocked>
		out(f, a, l);
		if (l)
    14f6:	1c041063          	bnez	s0,16b6 <printf+0x226>
			continue;
		if (s[1] == 0)
    14fa:	0014c783          	lbu	a5,1(s1)
    14fe:	14078e63          	beqz	a5,165a <printf+0x1ca>
			break;
		switch (s[1]) {
    1502:	07300713          	li	a4,115
    1506:	1ce78863          	beq	a5,a4,16d6 <printf+0x246>
    150a:	1af76863          	bltu	a4,a5,16ba <printf+0x22a>
    150e:	06400713          	li	a4,100
    1512:	22e78063          	beq	a5,a4,1732 <printf+0x2a2>
    1516:	07000713          	li	a4,112
    151a:	1ee79563          	bne	a5,a4,1704 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    151e:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1520:	00001797          	auipc	a5,0x1
    1524:	36078793          	addi	a5,a5,864 # 2880 <digits>
	buf[i++] = '0';
    1528:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    152c:	6298                	ld	a4,0(a3)
    152e:	06a1                	addi	a3,a3,8
    1530:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1532:	00471393          	slli	t2,a4,0x4
    1536:	00871293          	slli	t0,a4,0x8
    153a:	00c71f93          	slli	t6,a4,0xc
    153e:	01071f13          	slli	t5,a4,0x10
    1542:	01471e93          	slli	t4,a4,0x14
    1546:	01871e13          	slli	t3,a4,0x18
    154a:	01c71893          	slli	a7,a4,0x1c
    154e:	02471813          	slli	a6,a4,0x24
    1552:	02871513          	slli	a0,a4,0x28
    1556:	02c71593          	slli	a1,a4,0x2c
    155a:	03071613          	slli	a2,a4,0x30
    155e:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1562:	03c75413          	srli	s0,a4,0x3c
    1566:	01c7531b          	srliw	t1,a4,0x1c
    156a:	03c3d393          	srli	t2,t2,0x3c
    156e:	03c2d293          	srli	t0,t0,0x3c
    1572:	03cfdf93          	srli	t6,t6,0x3c
    1576:	03cf5f13          	srli	t5,t5,0x3c
    157a:	03cede93          	srli	t4,t4,0x3c
    157e:	03ce5e13          	srli	t3,t3,0x3c
    1582:	03c8d893          	srli	a7,a7,0x3c
    1586:	03c85813          	srli	a6,a6,0x3c
    158a:	9171                	srli	a0,a0,0x3c
    158c:	91f1                	srli	a1,a1,0x3c
    158e:	9271                	srli	a2,a2,0x3c
    1590:	92f1                	srli	a3,a3,0x3c
    1592:	95be                	add	a1,a1,a5
    1594:	963e                	add	a2,a2,a5
    1596:	96be                	add	a3,a3,a5
    1598:	943e                	add	s0,s0,a5
    159a:	93be                	add	t2,t2,a5
    159c:	92be                	add	t0,t0,a5
    159e:	9fbe                	add	t6,t6,a5
    15a0:	9f3e                	add	t5,t5,a5
    15a2:	9ebe                	add	t4,t4,a5
    15a4:	9e3e                	add	t3,t3,a5
    15a6:	98be                	add	a7,a7,a5
    15a8:	933e                	add	t1,t1,a5
    15aa:	983e                	add	a6,a6,a5
    15ac:	953e                	add	a0,a0,a5
    15ae:	0005c983          	lbu	s3,0(a1)
    15b2:	00044403          	lbu	s0,0(s0)
    15b6:	00064583          	lbu	a1,0(a2)
    15ba:	0003c383          	lbu	t2,0(t2)
    15be:	0006c603          	lbu	a2,0(a3)
    15c2:	0002c283          	lbu	t0,0(t0)
    15c6:	000fcf83          	lbu	t6,0(t6)
    15ca:	000f4f03          	lbu	t5,0(t5)
    15ce:	000ece83          	lbu	t4,0(t4)
    15d2:	000e4e03          	lbu	t3,0(t3)
    15d6:	0008c883          	lbu	a7,0(a7)
    15da:	00034303          	lbu	t1,0(t1)
    15de:	00084803          	lbu	a6,0(a6)
    15e2:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15e6:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15ea:	92f1                	srli	a3,a3,0x3c
    15ec:	8b3d                	andi	a4,a4,15
    15ee:	96be                	add	a3,a3,a5
    15f0:	97ba                	add	a5,a5,a4
    15f2:	00810d23          	sb	s0,26(sp)
    15f6:	00710da3          	sb	t2,27(sp)
    15fa:	00510e23          	sb	t0,28(sp)
    15fe:	01f10ea3          	sb	t6,29(sp)
    1602:	01e10f23          	sb	t5,30(sp)
    1606:	01d10fa3          	sb	t4,31(sp)
    160a:	03c10023          	sb	t3,32(sp)
    160e:	031100a3          	sb	a7,33(sp)
    1612:	02610123          	sb	t1,34(sp)
    1616:	030101a3          	sb	a6,35(sp)
    161a:	02a10223          	sb	a0,36(sp)
    161e:	033102a3          	sb	s3,37(sp)
    1622:	02b10323          	sb	a1,38(sp)
    1626:	02c103a3          	sb	a2,39(sp)
    162a:	0006c683          	lbu	a3,0(a3)
    162e:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1632:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1636:	02d10423          	sb	a3,40(sp)
    163a:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    163e:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1642:	11578263          	beq	a5,s5,1746 <printf+0x2b6>
		len = out_unlocked(s, l);
    1646:	45c9                	li	a1,18
    1648:	0828                	addi	a0,sp,24
    164a:	2d2000ef          	jal	ra,191c <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    164e:	00248993          	addi	s3,s1,2
		if (!*s)
    1652:	0009c783          	lbu	a5,0(s3)
    1656:	e6079ee3          	bnez	a5,14d2 <printf+0x42>
	}
	va_end(ap);
    165a:	70e6                	ld	ra,120(sp)
    165c:	7446                	ld	s0,112(sp)
    165e:	74a6                	ld	s1,104(sp)
    1660:	7906                	ld	s2,96(sp)
    1662:	69e6                	ld	s3,88(sp)
    1664:	6a46                	ld	s4,80(sp)
    1666:	6aa6                	ld	s5,72(sp)
    1668:	6b06                	ld	s6,64(sp)
    166a:	6129                	addi	sp,sp,192
    166c:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    166e:	0005c783          	lbu	a5,0(a1)
    1672:	84ae                	mv	s1,a1
    1674:	01278963          	beq	a5,s2,1686 <printf+0x1f6>
    1678:	b5ad                	j	14e2 <printf+0x52>
    167a:	0024c783          	lbu	a5,2(s1)
    167e:	0585                	addi	a1,a1,1
    1680:	0489                	addi	s1,s1,2
    1682:	e72790e3          	bne	a5,s2,14e2 <printf+0x52>
    1686:	0014c783          	lbu	a5,1(s1)
    168a:	ff2788e3          	beq	a5,s2,167a <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    168e:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1692:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1696:	e5579ce3          	bne	a5,s5,14ee <printf+0x5e>
		mutex_lock(buffer_lock);
    169a:	10ca2503          	lw	a0,268(s4)
    169e:	c41ff0ef          	jal	ra,12de <mutex_lock>
		len = out_unlocked(s, l);
    16a2:	85a2                	mv	a1,s0
    16a4:	854e                	mv	a0,s3
    16a6:	276000ef          	jal	ra,191c <out_unlocked>
		mutex_unlock(buffer_lock);
    16aa:	10ca2503          	lw	a0,268(s4)
    16ae:	c3dff0ef          	jal	ra,12ea <mutex_unlock>
		if (l)
    16b2:	e40404e3          	beqz	s0,14fa <printf+0x6a>
    16b6:	89a6                	mv	s3,s1
    16b8:	bd09                	j	14ca <printf+0x3a>
		switch (s[1]) {
    16ba:	07800713          	li	a4,120
    16be:	04e79363          	bne	a5,a4,1704 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16c2:	67c2                	ld	a5,16(sp)
    16c4:	45c1                	li	a1,16
		s += 2;
    16c6:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16ca:	4388                	lw	a0,0(a5)
    16cc:	07a1                	addi	a5,a5,8
    16ce:	e83e                	sd	a5,16(sp)
    16d0:	5f8000ef          	jal	ra,1cc8 <printint.constprop.0>
		s += 2;
    16d4:	bfbd                	j	1652 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16d6:	67c2                	ld	a5,16(sp)
    16d8:	6380                	ld	s0,0(a5)
    16da:	07a1                	addi	a5,a5,8
    16dc:	e83e                	sd	a5,16(sp)
    16de:	1c040163          	beqz	s0,18a0 <printf+0x410>
			l = strnlen(a, 200);
    16e2:	0c800593          	li	a1,200
    16e6:	8522                	mv	a0,s0
    16e8:	3f7000ef          	jal	ra,22de <strnlen>
	if (buffer_lock_enabled == 1) {
    16ec:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16f0:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16f4:	19578663          	beq	a5,s5,1880 <printf+0x3f0>
		len = out_unlocked(s, l);
    16f8:	8522                	mv	a0,s0
    16fa:	222000ef          	jal	ra,191c <out_unlocked>
		s += 2;
    16fe:	00248993          	addi	s3,s1,2
    1702:	bf81                	j	1652 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1704:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1708:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    170c:	0f578663          	beq	a5,s5,17f8 <printf+0x368>
		len = out_unlocked(s, l);
    1710:	0828                	addi	a0,sp,24
    1712:	316000ef          	jal	ra,1a28 <out_unlocked.constprop.0>
			putchar(s[1]);
    1716:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    171a:	108a2783          	lw	a5,264(s4)
	char byte = c;
    171e:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1722:	05578163          	beq	a5,s5,1764 <printf+0x2d4>
		len = out_unlocked(s, l);
    1726:	0828                	addi	a0,sp,24
    1728:	300000ef          	jal	ra,1a28 <out_unlocked.constprop.0>
		s += 2;
    172c:	00248993          	addi	s3,s1,2
    1730:	b70d                	j	1652 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1732:	67c2                	ld	a5,16(sp)
    1734:	45a9                	li	a1,10
		s += 2;
    1736:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    173a:	4388                	lw	a0,0(a5)
    173c:	07a1                	addi	a5,a5,8
    173e:	e83e                	sd	a5,16(sp)
    1740:	588000ef          	jal	ra,1cc8 <printint.constprop.0>
		s += 2;
    1744:	b739                	j	1652 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1746:	10ca2503          	lw	a0,268(s4)
		s += 2;
    174a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    174e:	b91ff0ef          	jal	ra,12de <mutex_lock>
		len = out_unlocked(s, l);
    1752:	45c9                	li	a1,18
    1754:	0828                	addi	a0,sp,24
    1756:	1c6000ef          	jal	ra,191c <out_unlocked>
		mutex_unlock(buffer_lock);
    175a:	10ca2503          	lw	a0,268(s4)
    175e:	b8dff0ef          	jal	ra,12ea <mutex_unlock>
		s += 2;
    1762:	bdc5                	j	1652 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1764:	10ca2503          	lw	a0,268(s4)
    1768:	b77ff0ef          	jal	ra,12de <mutex_lock>
		buffer[buffer_len++] = c;
    176c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1770:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1774:	0017861b          	addiw	a2,a5,1
    1778:	97d2                	add	a5,a5,s4
    177a:	00ca2023          	sw	a2,0(s4)
    177e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1782:	00c6cc63          	blt	a3,a2,179a <printf+0x30a>
    1786:	47a9                	li	a5,10
    1788:	06f40663          	beq	s0,a5,17f4 <printf+0x364>
		mutex_unlock(buffer_lock);
    178c:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1790:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1794:	b57ff0ef          	jal	ra,12ea <mutex_unlock>
		s += 2;
    1798:	bd6d                	j	1652 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    179a:	10000793          	li	a5,256
    179e:	00f61e63          	bne	a2,a5,17ba <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    17a2:	00001597          	auipc	a1,0x1
    17a6:	fd658593          	addi	a1,a1,-42 # 2778 <buffer>
    17aa:	4505                	li	a0,1
    17ac:	8bbff0ef          	jal	ra,1066 <write>
	buffer_len = 0;
    17b0:	00001797          	auipc	a5,0x1
    17b4:	fc07a023          	sw	zero,-64(a5) # 2770 <buffer_len>
			if (r < 0) {
    17b8:	bfd1                	j	178c <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17ba:	8b7ff0ef          	jal	ra,1070 <getpid>
    17be:	842a                	mv	s0,a0
    17c0:	00001517          	auipc	a0,0x1
    17c4:	eb850513          	addi	a0,a0,-328 # 2678 <basename+0xe0>
    17c8:	5d1000ef          	jal	ra,2598 <basename>
    17cc:	872a                	mv	a4,a0
    17ce:	00001617          	auipc	a2,0x1
    17d2:	eea60613          	addi	a2,a2,-278 # 26b8 <basename+0x120>
    17d6:	05400793          	li	a5,84
    17da:	86a2                	mv	a3,s0
    17dc:	45fd                	li	a1,31
    17de:	00001517          	auipc	a0,0x1
    17e2:	ee250513          	addi	a0,a0,-286 # 26c0 <basename+0x128>
    17e6:	cabff0ef          	jal	ra,1490 <printf>
    17ea:	557d                	li	a0,-1
    17ec:	8b5ff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    17f0:	000a2603          	lw	a2,0(s4)
    17f4:	de41                	beqz	a2,178c <printf+0x2fc>
    17f6:	b775                	j	17a2 <printf+0x312>
		mutex_lock(buffer_lock);
    17f8:	10ca2503          	lw	a0,268(s4)
    17fc:	ae3ff0ef          	jal	ra,12de <mutex_lock>
		buffer[buffer_len++] = c;
    1800:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1804:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1808:	0017861b          	addiw	a2,a5,1
    180c:	97d2                	add	a5,a5,s4
    180e:	00ca2023          	sw	a2,0(s4)
    1812:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1816:	02c6d163          	bge	a3,a2,1838 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    181a:	10000793          	li	a5,256
    181e:	02f61263          	bne	a2,a5,1842 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1822:	00001597          	auipc	a1,0x1
    1826:	f5658593          	addi	a1,a1,-170 # 2778 <buffer>
    182a:	4505                	li	a0,1
    182c:	83bff0ef          	jal	ra,1066 <write>
	buffer_len = 0;
    1830:	00001797          	auipc	a5,0x1
    1834:	f407a023          	sw	zero,-192(a5) # 2770 <buffer_len>
		mutex_unlock(buffer_lock);
    1838:	10ca2503          	lw	a0,268(s4)
    183c:	aafff0ef          	jal	ra,12ea <mutex_unlock>
    1840:	bdd9                	j	1716 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1842:	82fff0ef          	jal	ra,1070 <getpid>
    1846:	842a                	mv	s0,a0
    1848:	00001517          	auipc	a0,0x1
    184c:	e3050513          	addi	a0,a0,-464 # 2678 <basename+0xe0>
    1850:	549000ef          	jal	ra,2598 <basename>
    1854:	872a                	mv	a4,a0
    1856:	00001617          	auipc	a2,0x1
    185a:	e6260613          	addi	a2,a2,-414 # 26b8 <basename+0x120>
    185e:	05400793          	li	a5,84
    1862:	86a2                	mv	a3,s0
    1864:	45fd                	li	a1,31
    1866:	00001517          	auipc	a0,0x1
    186a:	e5a50513          	addi	a0,a0,-422 # 26c0 <basename+0x128>
    186e:	c23ff0ef          	jal	ra,1490 <printf>
    1872:	557d                	li	a0,-1
    1874:	82dff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    1878:	000a2603          	lw	a2,0(s4)
    187c:	de55                	beqz	a2,1838 <printf+0x3a8>
    187e:	b755                	j	1822 <printf+0x392>
		mutex_lock(buffer_lock);
    1880:	10ca2503          	lw	a0,268(s4)
    1884:	e42e                	sd	a1,8(sp)
		s += 2;
    1886:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    188a:	a55ff0ef          	jal	ra,12de <mutex_lock>
		len = out_unlocked(s, l);
    188e:	65a2                	ld	a1,8(sp)
    1890:	8522                	mv	a0,s0
    1892:	08a000ef          	jal	ra,191c <out_unlocked>
		mutex_unlock(buffer_lock);
    1896:	10ca2503          	lw	a0,268(s4)
    189a:	a51ff0ef          	jal	ra,12ea <mutex_unlock>
		s += 2;
    189e:	bb55                	j	1652 <printf+0x1c2>
				a = "(null)";
    18a0:	00001417          	auipc	s0,0x1
    18a4:	dd040413          	addi	s0,s0,-560 # 2670 <basename+0xd8>
    18a8:	bd2d                	j	16e2 <printf+0x252>

00000000000018aa <enable_thread_io_buffer>:
{
    18aa:	1101                	addi	sp,sp,-32
    18ac:	e822                	sd	s0,16(sp)
    18ae:	ec06                	sd	ra,24(sp)
    18b0:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18b2:	00001417          	auipc	s0,0x1
    18b6:	ebe40413          	addi	s0,s0,-322 # 2770 <buffer_len>
    18ba:	a09ff0ef          	jal	ra,12c2 <mutex_create>
    18be:	10a42623          	sw	a0,268(s0)
    18c2:	00054a63          	bltz	a0,18d6 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18c6:	4785                	li	a5,1
}
    18c8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18ca:	10f42423          	sw	a5,264(s0)
}
    18ce:	6442                	ld	s0,16(sp)
    18d0:	64a2                	ld	s1,8(sp)
    18d2:	6105                	addi	sp,sp,32
    18d4:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18d6:	f9aff0ef          	jal	ra,1070 <getpid>
    18da:	84aa                	mv	s1,a0
    18dc:	00001517          	auipc	a0,0x1
    18e0:	d9c50513          	addi	a0,a0,-612 # 2678 <basename+0xe0>
    18e4:	4b5000ef          	jal	ra,2598 <basename>
    18e8:	872a                	mv	a4,a0
    18ea:	04800793          	li	a5,72
    18ee:	86a6                	mv	a3,s1
    18f0:	00001517          	auipc	a0,0x1
    18f4:	e1050513          	addi	a0,a0,-496 # 2700 <basename+0x168>
    18f8:	00001617          	auipc	a2,0x1
    18fc:	dc060613          	addi	a2,a2,-576 # 26b8 <basename+0x120>
    1900:	45fd                	li	a1,31
    1902:	b8fff0ef          	jal	ra,1490 <printf>
    1906:	557d                	li	a0,-1
    1908:	f98ff0ef          	jal	ra,10a0 <exit>
	buffer_lock_enabled = 1;
    190c:	4785                	li	a5,1
}
    190e:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1910:	10f42423          	sw	a5,264(s0)
}
    1914:	6442                	ld	s0,16(sp)
    1916:	64a2                	ld	s1,8(sp)
    1918:	6105                	addi	sp,sp,32
    191a:	8082                	ret

000000000000191c <out_unlocked>:
{
    191c:	7159                	addi	sp,sp,-112
    191e:	f486                	sd	ra,104(sp)
    1920:	f0a2                	sd	s0,96(sp)
    1922:	eca6                	sd	s1,88(sp)
    1924:	e8ca                	sd	s2,80(sp)
    1926:	e4ce                	sd	s3,72(sp)
    1928:	e0d2                	sd	s4,64(sp)
    192a:	fc56                	sd	s5,56(sp)
    192c:	f85a                	sd	s6,48(sp)
    192e:	f45e                	sd	s7,40(sp)
    1930:	f062                	sd	s8,32(sp)
    1932:	ec66                	sd	s9,24(sp)
    1934:	e86a                	sd	s10,16(sp)
    1936:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1938:	0e058663          	beqz	a1,1a24 <out_unlocked+0x108>
    193c:	842a                	mv	s0,a0
    193e:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1942:	4981                	li	s3,0
    1944:	00001d17          	auipc	s10,0x1
    1948:	e2cd0d13          	addi	s10,s10,-468 # 2770 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    194c:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1950:	00001b17          	auipc	s6,0x1
    1954:	e28b0b13          	addi	s6,s6,-472 # 2778 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1958:	10000a93          	li	s5,256
    195c:	00001c97          	auipc	s9,0x1
    1960:	d1cc8c93          	addi	s9,s9,-740 # 2678 <basename+0xe0>
    1964:	00001c17          	auipc	s8,0x1
    1968:	d54c0c13          	addi	s8,s8,-684 # 26b8 <basename+0x120>
    196c:	00001b97          	auipc	s7,0x1
    1970:	d54b8b93          	addi	s7,s7,-684 # 26c0 <basename+0x128>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1974:	4a29                	li	s4,10
    1976:	a031                	j	1982 <out_unlocked+0x66>
    1978:	09468863          	beq	a3,s4,1a08 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    197c:	0405                	addi	s0,s0,1
    197e:	04848163          	beq	s1,s0,19c0 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1982:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1986:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    198a:	0017861b          	addiw	a2,a5,1
    198e:	97ea                	add	a5,a5,s10
    1990:	00cd2023          	sw	a2,0(s10)
    1994:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1998:	fec950e3          	bge	s2,a2,1978 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    199c:	05561263          	bne	a2,s5,19e0 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    19a0:	85da                	mv	a1,s6
    19a2:	4505                	li	a0,1
    19a4:	ec2ff0ef          	jal	ra,1066 <write>
    19a8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19aa:	00001797          	auipc	a5,0x1
    19ae:	dc07a323          	sw	zero,-570(a5) # 2770 <buffer_len>
			if (r < 0) {
    19b2:	06054763          	bltz	a0,1a20 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19b6:	0405                	addi	s0,s0,1
			ret += r;
    19b8:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19bc:	fc8493e3          	bne	s1,s0,1982 <out_unlocked+0x66>
}
    19c0:	70a6                	ld	ra,104(sp)
    19c2:	7406                	ld	s0,96(sp)
    19c4:	64e6                	ld	s1,88(sp)
    19c6:	6946                	ld	s2,80(sp)
    19c8:	6a06                	ld	s4,64(sp)
    19ca:	7ae2                	ld	s5,56(sp)
    19cc:	7b42                	ld	s6,48(sp)
    19ce:	7ba2                	ld	s7,40(sp)
    19d0:	7c02                	ld	s8,32(sp)
    19d2:	6ce2                	ld	s9,24(sp)
    19d4:	6d42                	ld	s10,16(sp)
    19d6:	6da2                	ld	s11,8(sp)
    19d8:	854e                	mv	a0,s3
    19da:	69a6                	ld	s3,72(sp)
    19dc:	6165                	addi	sp,sp,112
    19de:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19e0:	e90ff0ef          	jal	ra,1070 <getpid>
    19e4:	8daa                	mv	s11,a0
    19e6:	8566                	mv	a0,s9
    19e8:	3b1000ef          	jal	ra,2598 <basename>
    19ec:	872a                	mv	a4,a0
    19ee:	8662                	mv	a2,s8
    19f0:	05400793          	li	a5,84
    19f4:	86ee                	mv	a3,s11
    19f6:	45fd                	li	a1,31
    19f8:	855e                	mv	a0,s7
    19fa:	a97ff0ef          	jal	ra,1490 <printf>
    19fe:	557d                	li	a0,-1
    1a00:	ea0ff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    1a04:	000d2603          	lw	a2,0(s10)
    1a08:	da35                	beqz	a2,197c <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a0a:	85da                	mv	a1,s6
    1a0c:	4505                	li	a0,1
    1a0e:	e58ff0ef          	jal	ra,1066 <write>
    1a12:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a14:	00001797          	auipc	a5,0x1
    1a18:	d407ae23          	sw	zero,-676(a5) # 2770 <buffer_len>
			if (r < 0) {
    1a1c:	f8055de3          	bgez	a0,19b6 <out_unlocked+0x9a>
    1a20:	89aa                	mv	s3,a0
    1a22:	bf79                	j	19c0 <out_unlocked+0xa4>
	int ret = 0;
    1a24:	4981                	li	s3,0
    1a26:	bf69                	j	19c0 <out_unlocked+0xa4>

0000000000001a28 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a28:	1101                	addi	sp,sp,-32
    1a2a:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a2c:	00001497          	auipc	s1,0x1
    1a30:	d4448493          	addi	s1,s1,-700 # 2770 <buffer_len>
    1a34:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a36:	ec06                	sd	ra,24(sp)
    1a38:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a3a:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a3e:	0017861b          	addiw	a2,a5,1
    1a42:	97a6                	add	a5,a5,s1
    1a44:	00e78423          	sb	a4,8(a5)
    1a48:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a4a:	0ff00793          	li	a5,255
    1a4e:	00c7cc63          	blt	a5,a2,1a66 <out_unlocked.constprop.0+0x3e>
    1a52:	47a9                	li	a5,10
    1a54:	06f70c63          	beq	a4,a5,1acc <out_unlocked.constprop.0+0xa4>
    1a58:	4601                	li	a2,0
}
    1a5a:	60e2                	ld	ra,24(sp)
    1a5c:	6442                	ld	s0,16(sp)
    1a5e:	64a2                	ld	s1,8(sp)
    1a60:	8532                	mv	a0,a2
    1a62:	6105                	addi	sp,sp,32
    1a64:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a66:	10000793          	li	a5,256
    1a6a:	02f61563          	bne	a2,a5,1a94 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a6e:	00001597          	auipc	a1,0x1
    1a72:	d0a58593          	addi	a1,a1,-758 # 2778 <buffer>
    1a76:	4505                	li	a0,1
    1a78:	deeff0ef          	jal	ra,1066 <write>
}
    1a7c:	60e2                	ld	ra,24(sp)
    1a7e:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a80:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a84:	00001797          	auipc	a5,0x1
    1a88:	ce07a623          	sw	zero,-788(a5) # 2770 <buffer_len>
}
    1a8c:	64a2                	ld	s1,8(sp)
    1a8e:	8532                	mv	a0,a2
    1a90:	6105                	addi	sp,sp,32
    1a92:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a94:	ddcff0ef          	jal	ra,1070 <getpid>
    1a98:	842a                	mv	s0,a0
    1a9a:	00001517          	auipc	a0,0x1
    1a9e:	bde50513          	addi	a0,a0,-1058 # 2678 <basename+0xe0>
    1aa2:	2f7000ef          	jal	ra,2598 <basename>
    1aa6:	872a                	mv	a4,a0
    1aa8:	00001617          	auipc	a2,0x1
    1aac:	c1060613          	addi	a2,a2,-1008 # 26b8 <basename+0x120>
    1ab0:	05400793          	li	a5,84
    1ab4:	86a2                	mv	a3,s0
    1ab6:	45fd                	li	a1,31
    1ab8:	00001517          	auipc	a0,0x1
    1abc:	c0850513          	addi	a0,a0,-1016 # 26c0 <basename+0x128>
    1ac0:	9d1ff0ef          	jal	ra,1490 <printf>
    1ac4:	557d                	li	a0,-1
    1ac6:	ddaff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    1aca:	4090                	lw	a2,0(s1)
    1acc:	d659                	beqz	a2,1a5a <out_unlocked.constprop.0+0x32>
    1ace:	b745                	j	1a6e <out_unlocked.constprop.0+0x46>

0000000000001ad0 <putchar>:
{
    1ad0:	7139                	addi	sp,sp,-64
    1ad2:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ad4:	00001497          	auipc	s1,0x1
    1ad8:	c9c48493          	addi	s1,s1,-868 # 2770 <buffer_len>
    1adc:	1084a703          	lw	a4,264(s1)
{
    1ae0:	f822                	sd	s0,48(sp)
	char byte = c;
    1ae2:	0ff57413          	zext.b	s0,a0
{
    1ae6:	fc06                	sd	ra,56(sp)
	char byte = c;
    1ae8:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1aec:	4785                	li	a5,1
    1aee:	00f70d63          	beq	a4,a5,1b08 <putchar+0x38>
		len = out_unlocked(s, l);
    1af2:	01f10513          	addi	a0,sp,31
    1af6:	f33ff0ef          	jal	ra,1a28 <out_unlocked.constprop.0>
}
    1afa:	70e2                	ld	ra,56(sp)
    1afc:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1afe:	862a                	mv	a2,a0
}
    1b00:	74a2                	ld	s1,40(sp)
    1b02:	8532                	mv	a0,a2
    1b04:	6121                	addi	sp,sp,64
    1b06:	8082                	ret
		mutex_lock(buffer_lock);
    1b08:	10c4a503          	lw	a0,268(s1)
    1b0c:	fd2ff0ef          	jal	ra,12de <mutex_lock>
		buffer[buffer_len++] = c;
    1b10:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b12:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b16:	0017861b          	addiw	a2,a5,1
    1b1a:	97a6                	add	a5,a5,s1
    1b1c:	c090                	sw	a2,0(s1)
    1b1e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b22:	02c6c263          	blt	a3,a2,1b46 <putchar+0x76>
    1b26:	47a9                	li	a5,10
    1b28:	06f40d63          	beq	s0,a5,1ba2 <putchar+0xd2>
    1b2c:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b2e:	10c4a503          	lw	a0,268(s1)
    1b32:	e432                	sd	a2,8(sp)
    1b34:	fb6ff0ef          	jal	ra,12ea <mutex_unlock>
    1b38:	6622                	ld	a2,8(sp)
}
    1b3a:	70e2                	ld	ra,56(sp)
    1b3c:	7442                	ld	s0,48(sp)
    1b3e:	74a2                	ld	s1,40(sp)
    1b40:	8532                	mv	a0,a2
    1b42:	6121                	addi	sp,sp,64
    1b44:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b46:	10000793          	li	a5,256
    1b4a:	02f61063          	bne	a2,a5,1b6a <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b4e:	00001597          	auipc	a1,0x1
    1b52:	c2a58593          	addi	a1,a1,-982 # 2778 <buffer>
    1b56:	4505                	li	a0,1
    1b58:	d0eff0ef          	jal	ra,1066 <write>
    1b5c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b60:	00001797          	auipc	a5,0x1
    1b64:	c007a823          	sw	zero,-1008(a5) # 2770 <buffer_len>
			if (r < 0) {
    1b68:	b7d9                	j	1b2e <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b6a:	d06ff0ef          	jal	ra,1070 <getpid>
    1b6e:	842a                	mv	s0,a0
    1b70:	00001517          	auipc	a0,0x1
    1b74:	b0850513          	addi	a0,a0,-1272 # 2678 <basename+0xe0>
    1b78:	221000ef          	jal	ra,2598 <basename>
    1b7c:	872a                	mv	a4,a0
    1b7e:	00001617          	auipc	a2,0x1
    1b82:	b3a60613          	addi	a2,a2,-1222 # 26b8 <basename+0x120>
    1b86:	05400793          	li	a5,84
    1b8a:	86a2                	mv	a3,s0
    1b8c:	45fd                	li	a1,31
    1b8e:	00001517          	auipc	a0,0x1
    1b92:	b3250513          	addi	a0,a0,-1230 # 26c0 <basename+0x128>
    1b96:	8fbff0ef          	jal	ra,1490 <printf>
    1b9a:	557d                	li	a0,-1
    1b9c:	d04ff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    1ba0:	4090                	lw	a2,0(s1)
    1ba2:	d651                	beqz	a2,1b2e <putchar+0x5e>
    1ba4:	b76d                	j	1b4e <putchar+0x7e>

0000000000001ba6 <puts>:
{
    1ba6:	7139                	addi	sp,sp,-64
    1ba8:	f822                	sd	s0,48(sp)
    1baa:	f426                	sd	s1,40(sp)
    1bac:	fc06                	sd	ra,56(sp)
    1bae:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1bb0:	00001417          	auipc	s0,0x1
    1bb4:	bc040413          	addi	s0,s0,-1088 # 2770 <buffer_len>
{
    1bb8:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bba:	638000ef          	jal	ra,21f2 <strlen>
	if (buffer_lock_enabled == 1) {
    1bbe:	10842703          	lw	a4,264(s0)
    1bc2:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bc4:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bc6:	04f70563          	beq	a4,a5,1c10 <puts+0x6a>
		len = out_unlocked(s, l);
    1bca:	8526                	mv	a0,s1
    1bcc:	d51ff0ef          	jal	ra,191c <out_unlocked>
    1bd0:	892a                	mv	s2,a0
    1bd2:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bd4:	00095963          	bgez	s2,1be6 <puts+0x40>
}
    1bd8:	70e2                	ld	ra,56(sp)
    1bda:	7442                	ld	s0,48(sp)
    1bdc:	7902                	ld	s2,32(sp)
    1bde:	8526                	mv	a0,s1
    1be0:	74a2                	ld	s1,40(sp)
    1be2:	6121                	addi	sp,sp,64
    1be4:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1be6:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bea:	44a9                	li	s1,10
    1bec:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bf0:	4785                	li	a5,1
    1bf2:	02f70e63          	beq	a4,a5,1c2e <puts+0x88>
		len = out_unlocked(s, l);
    1bf6:	01f10513          	addi	a0,sp,31
    1bfa:	e2fff0ef          	jal	ra,1a28 <out_unlocked.constprop.0>
}
    1bfe:	70e2                	ld	ra,56(sp)
    1c00:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c02:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c06:	7902                	ld	s2,32(sp)
    1c08:	8526                	mv	a0,s1
    1c0a:	74a2                	ld	s1,40(sp)
    1c0c:	6121                	addi	sp,sp,64
    1c0e:	8082                	ret
		mutex_lock(buffer_lock);
    1c10:	e42a                	sd	a0,8(sp)
    1c12:	10c42503          	lw	a0,268(s0)
    1c16:	ec8ff0ef          	jal	ra,12de <mutex_lock>
		len = out_unlocked(s, l);
    1c1a:	65a2                	ld	a1,8(sp)
    1c1c:	8526                	mv	a0,s1
    1c1e:	cffff0ef          	jal	ra,191c <out_unlocked>
    1c22:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c24:	10c42503          	lw	a0,268(s0)
    1c28:	ec2ff0ef          	jal	ra,12ea <mutex_unlock>
    1c2c:	b75d                	j	1bd2 <puts+0x2c>
		mutex_lock(buffer_lock);
    1c2e:	10c42503          	lw	a0,268(s0)
    1c32:	eacff0ef          	jal	ra,12de <mutex_lock>
		buffer[buffer_len++] = c;
    1c36:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c38:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c3c:	0017861b          	addiw	a2,a5,1
    1c40:	97a2                	add	a5,a5,s0
    1c42:	c010                	sw	a2,0(s0)
    1c44:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c48:	06c6dc63          	bge	a3,a2,1cc0 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c4c:	10000793          	li	a5,256
    1c50:	02f61c63          	bne	a2,a5,1c88 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c54:	00001597          	auipc	a1,0x1
    1c58:	b2458593          	addi	a1,a1,-1244 # 2778 <buffer>
    1c5c:	4505                	li	a0,1
    1c5e:	c08ff0ef          	jal	ra,1066 <write>
			if (r < 0) {
    1c62:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c64:	00001797          	auipc	a5,0x1
    1c68:	b007a623          	sw	zero,-1268(a5) # 2770 <buffer_len>
			if (r < 0) {
    1c6c:	04054c63          	bltz	a0,1cc4 <puts+0x11e>
			if (r < buffer_len) {
    1c70:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c72:	10c42503          	lw	a0,268(s0)
    1c76:	e74ff0ef          	jal	ra,12ea <mutex_unlock>
}
    1c7a:	70e2                	ld	ra,56(sp)
    1c7c:	7442                	ld	s0,48(sp)
    1c7e:	7902                	ld	s2,32(sp)
    1c80:	8526                	mv	a0,s1
    1c82:	74a2                	ld	s1,40(sp)
    1c84:	6121                	addi	sp,sp,64
    1c86:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c88:	be8ff0ef          	jal	ra,1070 <getpid>
    1c8c:	84aa                	mv	s1,a0
    1c8e:	00001517          	auipc	a0,0x1
    1c92:	9ea50513          	addi	a0,a0,-1558 # 2678 <basename+0xe0>
    1c96:	103000ef          	jal	ra,2598 <basename>
    1c9a:	872a                	mv	a4,a0
    1c9c:	00001617          	auipc	a2,0x1
    1ca0:	a1c60613          	addi	a2,a2,-1508 # 26b8 <basename+0x120>
    1ca4:	05400793          	li	a5,84
    1ca8:	86a6                	mv	a3,s1
    1caa:	45fd                	li	a1,31
    1cac:	00001517          	auipc	a0,0x1
    1cb0:	a1450513          	addi	a0,a0,-1516 # 26c0 <basename+0x128>
    1cb4:	fdcff0ef          	jal	ra,1490 <printf>
    1cb8:	557d                	li	a0,-1
    1cba:	be6ff0ef          	jal	ra,10a0 <exit>
	if (buffer_len == 0)
    1cbe:	4010                	lw	a2,0(s0)
    1cc0:	da45                	beqz	a2,1c70 <puts+0xca>
    1cc2:	bf49                	j	1c54 <puts+0xae>
    1cc4:	54fd                	li	s1,-1
    1cc6:	b775                	j	1c72 <puts+0xcc>

0000000000001cc8 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cc8:	715d                	addi	sp,sp,-80
    1cca:	e486                	sd	ra,72(sp)
    1ccc:	e0a2                	sd	s0,64(sp)
    1cce:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1cd0:	14054363          	bltz	a0,1e16 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1cd4:	02b577bb          	remuw	a5,a0,a1
    1cd8:	00001617          	auipc	a2,0x1
    1cdc:	ba860613          	addi	a2,a2,-1112 # 2880 <digits>
	buf[16] = 0;
    1ce0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ce4:	0005871b          	sext.w	a4,a1
    1ce8:	1782                	slli	a5,a5,0x20
    1cea:	9381                	srli	a5,a5,0x20
    1cec:	97b2                	add	a5,a5,a2
    1cee:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cf2:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1cf6:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1cfa:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1cfc:	0eb56763          	bltu	a0,a1,1dea <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d00:	02e877bb          	remuw	a5,a6,a4
    1d04:	1782                	slli	a5,a5,0x20
    1d06:	9381                	srli	a5,a5,0x20
    1d08:	97b2                	add	a5,a5,a2
    1d0a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d0e:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d12:	02f10323          	sb	a5,38(sp)
    1d16:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d18:	0ce86963          	bltu	a6,a4,1dea <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d1c:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d20:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d24:	1582                	slli	a1,a1,0x20
    1d26:	9181                	srli	a1,a1,0x20
    1d28:	95b2                	add	a1,a1,a2
    1d2a:	0005c583          	lbu	a1,0(a1)
    1d2e:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d32:	0007859b          	sext.w	a1,a5
    1d36:	16e6e563          	bltu	a3,a4,1ea0 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d3a:	02e7f6bb          	remuw	a3,a5,a4
    1d3e:	1682                	slli	a3,a3,0x20
    1d40:	9281                	srli	a3,a3,0x20
    1d42:	96b2                	add	a3,a3,a2
    1d44:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d48:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d4c:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d50:	16e5e163          	bltu	a1,a4,1eb2 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d54:	02e876bb          	remuw	a3,a6,a4
    1d58:	1682                	slli	a3,a3,0x20
    1d5a:	9281                	srli	a3,a3,0x20
    1d5c:	96b2                	add	a3,a3,a2
    1d5e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d62:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d66:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d6a:	14e86d63          	bltu	a6,a4,1ec4 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d6e:	02e5f6bb          	remuw	a3,a1,a4
    1d72:	1682                	slli	a3,a3,0x20
    1d74:	9281                	srli	a3,a3,0x20
    1d76:	96b2                	add	a3,a3,a2
    1d78:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d7c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d80:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d84:	10e5e563          	bltu	a1,a4,1e8e <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d88:	02e876bb          	remuw	a3,a6,a4
    1d8c:	1682                	slli	a3,a3,0x20
    1d8e:	9281                	srli	a3,a3,0x20
    1d90:	96b2                	add	a3,a3,a2
    1d92:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d96:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d9a:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1d9e:	14e86263          	bltu	a6,a4,1ee2 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1da2:	02e5f6bb          	remuw	a3,a1,a4
    1da6:	1682                	slli	a3,a3,0x20
    1da8:	9281                	srli	a3,a3,0x20
    1daa:	96b2                	add	a3,a3,a2
    1dac:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1db0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1db4:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1db8:	14e5e463          	bltu	a1,a4,1f00 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1dbc:	02e876bb          	remuw	a3,a6,a4
    1dc0:	1682                	slli	a3,a3,0x20
    1dc2:	9281                	srli	a3,a3,0x20
    1dc4:	96b2                	add	a3,a3,a2
    1dc6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dca:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1dce:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1dd2:	14e86063          	bltu	a6,a4,1f12 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1dd6:	1782                	slli	a5,a5,0x20
    1dd8:	9381                	srli	a5,a5,0x20
    1dda:	97b2                	add	a5,a5,a2
    1ddc:	0007c703          	lbu	a4,0(a5)
    1de0:	4799                	li	a5,6
    1de2:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1de6:	10054763          	bltz	a0,1ef4 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1dea:	00001497          	auipc	s1,0x1
    1dee:	98648493          	addi	s1,s1,-1658 # 2770 <buffer_len>
    1df2:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1df6:	0828                	addi	a0,sp,24
    1df8:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1dfa:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1dfc:	00f50433          	add	s0,a0,a5
    1e00:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1e02:	06e68463          	beq	a3,a4,1e6a <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e06:	8522                	mv	a0,s0
    1e08:	b15ff0ef          	jal	ra,191c <out_unlocked>
}
    1e0c:	60a6                	ld	ra,72(sp)
    1e0e:	6406                	ld	s0,64(sp)
    1e10:	74e2                	ld	s1,56(sp)
    1e12:	6161                	addi	sp,sp,80
    1e14:	8082                	ret
		x = -xx;
    1e16:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e1a:	02b877bb          	remuw	a5,a6,a1
    1e1e:	00001617          	auipc	a2,0x1
    1e22:	a6260613          	addi	a2,a2,-1438 # 2880 <digits>
	buf[16] = 0;
    1e26:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e2a:	0005871b          	sext.w	a4,a1
    1e2e:	1782                	slli	a5,a5,0x20
    1e30:	9381                	srli	a5,a5,0x20
    1e32:	97b2                	add	a5,a5,a2
    1e34:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e38:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e3c:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e40:	08b86b63          	bltu	a6,a1,1ed6 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e44:	02e8f7bb          	remuw	a5,a7,a4
    1e48:	1782                	slli	a5,a5,0x20
    1e4a:	9381                	srli	a5,a5,0x20
    1e4c:	97b2                	add	a5,a5,a2
    1e4e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e52:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e56:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e5a:	ece8f1e3          	bgeu	a7,a4,1d1c <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e5e:	02d00793          	li	a5,45
    1e62:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e66:	47b5                	li	a5,13
    1e68:	b749                	j	1dea <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e6a:	10c4a503          	lw	a0,268(s1)
    1e6e:	e42e                	sd	a1,8(sp)
    1e70:	c6eff0ef          	jal	ra,12de <mutex_lock>
		len = out_unlocked(s, l);
    1e74:	65a2                	ld	a1,8(sp)
    1e76:	8522                	mv	a0,s0
    1e78:	aa5ff0ef          	jal	ra,191c <out_unlocked>
		mutex_unlock(buffer_lock);
    1e7c:	10c4a503          	lw	a0,268(s1)
    1e80:	c6aff0ef          	jal	ra,12ea <mutex_unlock>
}
    1e84:	60a6                	ld	ra,72(sp)
    1e86:	6406                	ld	s0,64(sp)
    1e88:	74e2                	ld	s1,56(sp)
    1e8a:	6161                	addi	sp,sp,80
    1e8c:	8082                	ret
		buf[i--] = digits[x % base];
    1e8e:	47a9                	li	a5,10
	if (sign)
    1e90:	f4055de3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e94:	02d00793          	li	a5,45
    1e98:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e9c:	47a5                	li	a5,9
    1e9e:	b7b1                	j	1dea <printint.constprop.0+0x122>
    1ea0:	47b5                	li	a5,13
	if (sign)
    1ea2:	f40554e3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea6:	02d00793          	li	a5,45
    1eaa:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1eae:	47b1                	li	a5,12
    1eb0:	bf2d                	j	1dea <printint.constprop.0+0x122>
    1eb2:	47b1                	li	a5,12
	if (sign)
    1eb4:	f2055be3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb8:	02d00793          	li	a5,45
    1ebc:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ec0:	47ad                	li	a5,11
    1ec2:	b725                	j	1dea <printint.constprop.0+0x122>
    1ec4:	47ad                	li	a5,11
	if (sign)
    1ec6:	f20552e3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eca:	02d00793          	li	a5,45
    1ece:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ed2:	47a9                	li	a5,10
    1ed4:	bf19                	j	1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed6:	02d00793          	li	a5,45
    1eda:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ede:	47b9                	li	a5,14
    1ee0:	b729                	j	1dea <printint.constprop.0+0x122>
    1ee2:	47a5                	li	a5,9
	if (sign)
    1ee4:	f00553e3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee8:	02d00793          	li	a5,45
    1eec:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1ef0:	47a1                	li	a5,8
    1ef2:	bde5                	j	1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef4:	02d00793          	li	a5,45
    1ef8:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1efc:	4795                	li	a5,5
    1efe:	b5f5                	j	1dea <printint.constprop.0+0x122>
    1f00:	47a1                	li	a5,8
	if (sign)
    1f02:	ee0554e3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f06:	02d00793          	li	a5,45
    1f0a:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f0e:	479d                	li	a5,7
    1f10:	bde9                	j	1dea <printint.constprop.0+0x122>
    1f12:	479d                	li	a5,7
	if (sign)
    1f14:	ec055be3          	bgez	a0,1dea <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f18:	02d00793          	li	a5,45
    1f1c:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f20:	4799                	li	a5,6
    1f22:	b5e1                	j	1dea <printint.constprop.0+0x122>

0000000000001f24 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f24:	02000793          	li	a5,32
    1f28:	00f50663          	beq	a0,a5,1f34 <isspace+0x10>
    1f2c:	355d                	addiw	a0,a0,-9
    1f2e:	00553513          	sltiu	a0,a0,5
    1f32:	8082                	ret
    1f34:	4505                	li	a0,1
}
    1f36:	8082                	ret

0000000000001f38 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f38:	fd05051b          	addiw	a0,a0,-48
}
    1f3c:	00a53513          	sltiu	a0,a0,10
    1f40:	8082                	ret

0000000000001f42 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f42:	02000613          	li	a2,32
    1f46:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f48:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f4c:	ff77869b          	addiw	a3,a5,-9
    1f50:	04c78c63          	beq	a5,a2,1fa8 <atoi+0x66>
    1f54:	0007871b          	sext.w	a4,a5
    1f58:	04d5f863          	bgeu	a1,a3,1fa8 <atoi+0x66>
		s++;
	switch (*s) {
    1f5c:	02b00693          	li	a3,43
    1f60:	04d78963          	beq	a5,a3,1fb2 <atoi+0x70>
    1f64:	02d00693          	li	a3,45
    1f68:	06d78263          	beq	a5,a3,1fcc <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f6c:	fd07061b          	addiw	a2,a4,-48
    1f70:	47a5                	li	a5,9
    1f72:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f74:	4e01                	li	t3,0
	while (isdigit(*s))
    1f76:	04c7e963          	bltu	a5,a2,1fc8 <atoi+0x86>
	int n = 0, neg = 0;
    1f7a:	4501                	li	a0,0
	while (isdigit(*s))
    1f7c:	4825                	li	a6,9
    1f7e:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f82:	0025179b          	slliw	a5,a0,0x2
    1f86:	9fa9                	addw	a5,a5,a0
    1f88:	fd07031b          	addiw	t1,a4,-48
    1f8c:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f90:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f94:	0685                	addi	a3,a3,1
    1f96:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f9a:	0006071b          	sext.w	a4,a2
    1f9e:	feb870e3          	bgeu	a6,a1,1f7e <atoi+0x3c>
	return neg ? n : -n;
    1fa2:	000e0563          	beqz	t3,1fac <atoi+0x6a>
}
    1fa6:	8082                	ret
		s++;
    1fa8:	0505                	addi	a0,a0,1
    1faa:	bf79                	j	1f48 <atoi+0x6>
	return neg ? n : -n;
    1fac:	4113053b          	subw	a0,t1,a7
    1fb0:	8082                	ret
	while (isdigit(*s))
    1fb2:	00154703          	lbu	a4,1(a0)
    1fb6:	47a5                	li	a5,9
		s++;
    1fb8:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fbc:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fc0:	4e01                	li	t3,0
	while (isdigit(*s))
    1fc2:	2701                	sext.w	a4,a4
    1fc4:	fac7fbe3          	bgeu	a5,a2,1f7a <atoi+0x38>
    1fc8:	4501                	li	a0,0
}
    1fca:	8082                	ret
	while (isdigit(*s))
    1fcc:	00154703          	lbu	a4,1(a0)
    1fd0:	47a5                	li	a5,9
		s++;
    1fd2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fd6:	fd07061b          	addiw	a2,a4,-48
    1fda:	2701                	sext.w	a4,a4
    1fdc:	fec7e6e3          	bltu	a5,a2,1fc8 <atoi+0x86>
		neg = 1;
    1fe0:	4e05                	li	t3,1
    1fe2:	bf61                	j	1f7a <atoi+0x38>

0000000000001fe4 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fe4:	16060d63          	beqz	a2,215e <memset+0x17a>
    1fe8:	40a007b3          	neg	a5,a0
    1fec:	8b9d                	andi	a5,a5,7
    1fee:	00778693          	addi	a3,a5,7
    1ff2:	482d                	li	a6,11
    1ff4:	0ff5f713          	zext.b	a4,a1
    1ff8:	fff60593          	addi	a1,a2,-1
    1ffc:	1706e263          	bltu	a3,a6,2160 <memset+0x17c>
    2000:	16d5ea63          	bltu	a1,a3,2174 <memset+0x190>
    2004:	16078563          	beqz	a5,216e <memset+0x18a>
    2008:	00e50023          	sb	a4,0(a0)
    200c:	4685                	li	a3,1
    200e:	00150593          	addi	a1,a0,1
    2012:	14d78c63          	beq	a5,a3,216a <memset+0x186>
    2016:	00e500a3          	sb	a4,1(a0)
    201a:	4689                	li	a3,2
    201c:	00250593          	addi	a1,a0,2
    2020:	14d78d63          	beq	a5,a3,217a <memset+0x196>
    2024:	00e50123          	sb	a4,2(a0)
    2028:	468d                	li	a3,3
    202a:	00350593          	addi	a1,a0,3
    202e:	12d78b63          	beq	a5,a3,2164 <memset+0x180>
    2032:	00e501a3          	sb	a4,3(a0)
    2036:	4691                	li	a3,4
    2038:	00450593          	addi	a1,a0,4
    203c:	14d78163          	beq	a5,a3,217e <memset+0x19a>
    2040:	00e50223          	sb	a4,4(a0)
    2044:	4695                	li	a3,5
    2046:	00550593          	addi	a1,a0,5
    204a:	12d78c63          	beq	a5,a3,2182 <memset+0x19e>
    204e:	00e502a3          	sb	a4,5(a0)
    2052:	469d                	li	a3,7
    2054:	00650593          	addi	a1,a0,6
    2058:	12d79763          	bne	a5,a3,2186 <memset+0x1a2>
    205c:	00750593          	addi	a1,a0,7
    2060:	00e50323          	sb	a4,6(a0)
    2064:	481d                	li	a6,7
    2066:	00871693          	slli	a3,a4,0x8
    206a:	01071893          	slli	a7,a4,0x10
    206e:	8ed9                	or	a3,a3,a4
    2070:	01871313          	slli	t1,a4,0x18
    2074:	0116e6b3          	or	a3,a3,a7
    2078:	0066e6b3          	or	a3,a3,t1
    207c:	02071893          	slli	a7,a4,0x20
    2080:	02871e13          	slli	t3,a4,0x28
    2084:	0116e6b3          	or	a3,a3,a7
    2088:	40f60333          	sub	t1,a2,a5
    208c:	03071893          	slli	a7,a4,0x30
    2090:	01c6e6b3          	or	a3,a3,t3
    2094:	0116e6b3          	or	a3,a3,a7
    2098:	03871e13          	slli	t3,a4,0x38
    209c:	97aa                	add	a5,a5,a0
    209e:	ff837893          	andi	a7,t1,-8
    20a2:	01c6e6b3          	or	a3,a3,t3
    20a6:	98be                	add	a7,a7,a5
    20a8:	e394                	sd	a3,0(a5)
    20aa:	07a1                	addi	a5,a5,8
    20ac:	ff179ee3          	bne	a5,a7,20a8 <memset+0xc4>
    20b0:	ff837893          	andi	a7,t1,-8
    20b4:	011587b3          	add	a5,a1,a7
    20b8:	010886bb          	addw	a3,a7,a6
    20bc:	0b130663          	beq	t1,a7,2168 <memset+0x184>
    20c0:	00e78023          	sb	a4,0(a5)
    20c4:	0016859b          	addiw	a1,a3,1
    20c8:	08c5fb63          	bgeu	a1,a2,215e <memset+0x17a>
    20cc:	00e780a3          	sb	a4,1(a5)
    20d0:	0026859b          	addiw	a1,a3,2
    20d4:	08c5f563          	bgeu	a1,a2,215e <memset+0x17a>
    20d8:	00e78123          	sb	a4,2(a5)
    20dc:	0036859b          	addiw	a1,a3,3
    20e0:	06c5ff63          	bgeu	a1,a2,215e <memset+0x17a>
    20e4:	00e781a3          	sb	a4,3(a5)
    20e8:	0046859b          	addiw	a1,a3,4
    20ec:	06c5f963          	bgeu	a1,a2,215e <memset+0x17a>
    20f0:	00e78223          	sb	a4,4(a5)
    20f4:	0056859b          	addiw	a1,a3,5
    20f8:	06c5f363          	bgeu	a1,a2,215e <memset+0x17a>
    20fc:	00e782a3          	sb	a4,5(a5)
    2100:	0066859b          	addiw	a1,a3,6
    2104:	04c5fd63          	bgeu	a1,a2,215e <memset+0x17a>
    2108:	00e78323          	sb	a4,6(a5)
    210c:	0076859b          	addiw	a1,a3,7
    2110:	04c5f763          	bgeu	a1,a2,215e <memset+0x17a>
    2114:	00e783a3          	sb	a4,7(a5)
    2118:	0086859b          	addiw	a1,a3,8
    211c:	04c5f163          	bgeu	a1,a2,215e <memset+0x17a>
    2120:	00e78423          	sb	a4,8(a5)
    2124:	0096859b          	addiw	a1,a3,9
    2128:	02c5fb63          	bgeu	a1,a2,215e <memset+0x17a>
    212c:	00e784a3          	sb	a4,9(a5)
    2130:	00a6859b          	addiw	a1,a3,10
    2134:	02c5f563          	bgeu	a1,a2,215e <memset+0x17a>
    2138:	00e78523          	sb	a4,10(a5)
    213c:	00b6859b          	addiw	a1,a3,11
    2140:	00c5ff63          	bgeu	a1,a2,215e <memset+0x17a>
    2144:	00e785a3          	sb	a4,11(a5)
    2148:	00c6859b          	addiw	a1,a3,12
    214c:	00c5f963          	bgeu	a1,a2,215e <memset+0x17a>
    2150:	00e78623          	sb	a4,12(a5)
    2154:	26b5                	addiw	a3,a3,13
    2156:	00c6f463          	bgeu	a3,a2,215e <memset+0x17a>
    215a:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    215e:	8082                	ret
    2160:	46ad                	li	a3,11
    2162:	bd79                	j	2000 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2164:	480d                	li	a6,3
    2166:	b701                	j	2066 <memset+0x82>
    2168:	8082                	ret
    216a:	4805                	li	a6,1
    216c:	bded                	j	2066 <memset+0x82>
    216e:	85aa                	mv	a1,a0
    2170:	4801                	li	a6,0
    2172:	bdd5                	j	2066 <memset+0x82>
    2174:	87aa                	mv	a5,a0
    2176:	4681                	li	a3,0
    2178:	b7a1                	j	20c0 <memset+0xdc>
    217a:	4809                	li	a6,2
    217c:	b5ed                	j	2066 <memset+0x82>
    217e:	4811                	li	a6,4
    2180:	b5dd                	j	2066 <memset+0x82>
    2182:	4815                	li	a6,5
    2184:	b5cd                	j	2066 <memset+0x82>
    2186:	4819                	li	a6,6
    2188:	bdf9                	j	2066 <memset+0x82>

000000000000218a <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    218a:	00054783          	lbu	a5,0(a0)
    218e:	0005c703          	lbu	a4,0(a1)
    2192:	00e79863          	bne	a5,a4,21a2 <strcmp+0x18>
    2196:	0505                	addi	a0,a0,1
    2198:	0585                	addi	a1,a1,1
    219a:	fbe5                	bnez	a5,218a <strcmp>
    219c:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    219e:	9d19                	subw	a0,a0,a4
    21a0:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    21a2:	0007851b          	sext.w	a0,a5
    21a6:	bfe5                	j	219e <strcmp+0x14>

00000000000021a8 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21a8:	ca15                	beqz	a2,21dc <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21aa:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21ae:	167d                	addi	a2,a2,-1
    21b0:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21b4:	eb99                	bnez	a5,21ca <strncmp+0x22>
    21b6:	a815                	j	21ea <strncmp+0x42>
    21b8:	00a68e63          	beq	a3,a0,21d4 <strncmp+0x2c>
    21bc:	0505                	addi	a0,a0,1
    21be:	00f71b63          	bne	a4,a5,21d4 <strncmp+0x2c>
    21c2:	00054783          	lbu	a5,0(a0)
    21c6:	cf89                	beqz	a5,21e0 <strncmp+0x38>
    21c8:	85b2                	mv	a1,a2
    21ca:	0005c703          	lbu	a4,0(a1)
    21ce:	00158613          	addi	a2,a1,1
    21d2:	f37d                	bnez	a4,21b8 <strncmp+0x10>
		;
	return *l - *r;
    21d4:	0007851b          	sext.w	a0,a5
    21d8:	9d19                	subw	a0,a0,a4
    21da:	8082                	ret
		return 0;
    21dc:	4501                	li	a0,0
}
    21de:	8082                	ret
	return *l - *r;
    21e0:	0015c703          	lbu	a4,1(a1)
    21e4:	4501                	li	a0,0
    21e6:	9d19                	subw	a0,a0,a4
    21e8:	8082                	ret
    21ea:	0005c703          	lbu	a4,0(a1)
    21ee:	4501                	li	a0,0
    21f0:	b7e5                	j	21d8 <strncmp+0x30>

00000000000021f2 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21f2:	00757793          	andi	a5,a0,7
    21f6:	cf89                	beqz	a5,2210 <strlen+0x1e>
    21f8:	87aa                	mv	a5,a0
    21fa:	a029                	j	2204 <strlen+0x12>
    21fc:	0785                	addi	a5,a5,1
    21fe:	0077f713          	andi	a4,a5,7
    2202:	cb01                	beqz	a4,2212 <strlen+0x20>
		if (!*s)
    2204:	0007c703          	lbu	a4,0(a5)
    2208:	fb75                	bnez	a4,21fc <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    220a:	40a78533          	sub	a0,a5,a0
}
    220e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2210:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2212:	6394                	ld	a3,0(a5)
    2214:	00000597          	auipc	a1,0x0
    2218:	5445b583          	ld	a1,1348(a1) # 2758 <basename+0x1c0>
    221c:	00000617          	auipc	a2,0x0
    2220:	54463603          	ld	a2,1348(a2) # 2760 <basename+0x1c8>
    2224:	a019                	j	222a <strlen+0x38>
    2226:	6794                	ld	a3,8(a5)
    2228:	07a1                	addi	a5,a5,8
    222a:	00b68733          	add	a4,a3,a1
    222e:	fff6c693          	not	a3,a3
    2232:	8f75                	and	a4,a4,a3
    2234:	8f71                	and	a4,a4,a2
    2236:	db65                	beqz	a4,2226 <strlen+0x34>
	for (; *s; s++)
    2238:	0007c703          	lbu	a4,0(a5)
    223c:	d779                	beqz	a4,220a <strlen+0x18>
    223e:	0017c703          	lbu	a4,1(a5)
    2242:	0785                	addi	a5,a5,1
    2244:	d379                	beqz	a4,220a <strlen+0x18>
    2246:	0017c703          	lbu	a4,1(a5)
    224a:	0785                	addi	a5,a5,1
    224c:	fb6d                	bnez	a4,223e <strlen+0x4c>
    224e:	bf75                	j	220a <strlen+0x18>

0000000000002250 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2250:	00757713          	andi	a4,a0,7
{
    2254:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2256:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    225a:	cb19                	beqz	a4,2270 <memchr+0x20>
    225c:	ce25                	beqz	a2,22d4 <memchr+0x84>
    225e:	0007c703          	lbu	a4,0(a5)
    2262:	04b70e63          	beq	a4,a1,22be <memchr+0x6e>
    2266:	0785                	addi	a5,a5,1
    2268:	0077f713          	andi	a4,a5,7
    226c:	167d                	addi	a2,a2,-1
    226e:	f77d                	bnez	a4,225c <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2270:	4501                	li	a0,0
	if (n && *s != c) {
    2272:	c235                	beqz	a2,22d6 <memchr+0x86>
    2274:	0007c703          	lbu	a4,0(a5)
    2278:	04b70363          	beq	a4,a1,22be <memchr+0x6e>
		size_t k = ONES * c;
    227c:	00000517          	auipc	a0,0x0
    2280:	4ec53503          	ld	a0,1260(a0) # 2768 <basename+0x1d0>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2284:	471d                	li	a4,7
		size_t k = ONES * c;
    2286:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    228a:	02c77a63          	bgeu	a4,a2,22be <memchr+0x6e>
    228e:	00000897          	auipc	a7,0x0
    2292:	4ca8b883          	ld	a7,1226(a7) # 2758 <basename+0x1c0>
    2296:	00000817          	auipc	a6,0x0
    229a:	4ca83803          	ld	a6,1226(a6) # 2760 <basename+0x1c8>
    229e:	431d                	li	t1,7
    22a0:	a029                	j	22aa <memchr+0x5a>
		     w++, n -= SS)
    22a2:	1661                	addi	a2,a2,-8
    22a4:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22a6:	02c37963          	bgeu	t1,a2,22d8 <memchr+0x88>
    22aa:	6398                	ld	a4,0(a5)
    22ac:	8f29                	xor	a4,a4,a0
    22ae:	011706b3          	add	a3,a4,a7
    22b2:	fff74713          	not	a4,a4
    22b6:	8f75                	and	a4,a4,a3
    22b8:	01077733          	and	a4,a4,a6
    22bc:	d37d                	beqz	a4,22a2 <memchr+0x52>
{
    22be:	853e                	mv	a0,a5
    22c0:	97b2                	add	a5,a5,a2
    22c2:	a021                	j	22ca <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22c4:	0505                	addi	a0,a0,1
    22c6:	00f50763          	beq	a0,a5,22d4 <memchr+0x84>
    22ca:	00054703          	lbu	a4,0(a0)
    22ce:	feb71be3          	bne	a4,a1,22c4 <memchr+0x74>
    22d2:	8082                	ret
	return n ? (void *)s : 0;
    22d4:	4501                	li	a0,0
}
    22d6:	8082                	ret
	return n ? (void *)s : 0;
    22d8:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22da:	f275                	bnez	a2,22be <memchr+0x6e>
}
    22dc:	8082                	ret

00000000000022de <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22de:	1101                	addi	sp,sp,-32
    22e0:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22e2:	862e                	mv	a2,a1
{
    22e4:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22e6:	4581                	li	a1,0
{
    22e8:	e426                	sd	s1,8(sp)
    22ea:	ec06                	sd	ra,24(sp)
    22ec:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22ee:	f63ff0ef          	jal	ra,2250 <memchr>
	return p ? p - s : n;
    22f2:	c519                	beqz	a0,2300 <strnlen+0x22>
}
    22f4:	60e2                	ld	ra,24(sp)
    22f6:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22f8:	8d05                	sub	a0,a0,s1
}
    22fa:	64a2                	ld	s1,8(sp)
    22fc:	6105                	addi	sp,sp,32
    22fe:	8082                	ret
    2300:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2302:	8522                	mv	a0,s0
}
    2304:	6442                	ld	s0,16(sp)
    2306:	64a2                	ld	s1,8(sp)
    2308:	6105                	addi	sp,sp,32
    230a:	8082                	ret

000000000000230c <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    230c:	00a5c7b3          	xor	a5,a1,a0
    2310:	8b9d                	andi	a5,a5,7
    2312:	eb95                	bnez	a5,2346 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2314:	0075f793          	andi	a5,a1,7
    2318:	e7b1                	bnez	a5,2364 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    231a:	6198                	ld	a4,0(a1)
    231c:	00000617          	auipc	a2,0x0
    2320:	43c63603          	ld	a2,1084(a2) # 2758 <basename+0x1c0>
    2324:	00000817          	auipc	a6,0x0
    2328:	43c83803          	ld	a6,1084(a6) # 2760 <basename+0x1c8>
    232c:	a029                	j	2336 <stpcpy+0x2a>
    232e:	05a1                	addi	a1,a1,8
    2330:	e118                	sd	a4,0(a0)
    2332:	6198                	ld	a4,0(a1)
    2334:	0521                	addi	a0,a0,8
    2336:	00c707b3          	add	a5,a4,a2
    233a:	fff74693          	not	a3,a4
    233e:	8ff5                	and	a5,a5,a3
    2340:	0107f7b3          	and	a5,a5,a6
    2344:	d7ed                	beqz	a5,232e <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2346:	0005c783          	lbu	a5,0(a1)
    234a:	00f50023          	sb	a5,0(a0)
    234e:	c785                	beqz	a5,2376 <stpcpy+0x6a>
    2350:	0015c783          	lbu	a5,1(a1)
    2354:	0505                	addi	a0,a0,1
    2356:	0585                	addi	a1,a1,1
    2358:	00f50023          	sb	a5,0(a0)
    235c:	fbf5                	bnez	a5,2350 <stpcpy+0x44>
		;
	return d;
}
    235e:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2360:	0505                	addi	a0,a0,1
    2362:	df45                	beqz	a4,231a <stpcpy+0xe>
			if (!(*d = *s))
    2364:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2368:	0585                	addi	a1,a1,1
    236a:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    236e:	00f50023          	sb	a5,0(a0)
    2372:	f7fd                	bnez	a5,2360 <stpcpy+0x54>
}
    2374:	8082                	ret
    2376:	8082                	ret

0000000000002378 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2378:	00a5c7b3          	xor	a5,a1,a0
    237c:	8b9d                	andi	a5,a5,7
    237e:	1a079863          	bnez	a5,252e <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2382:	0075f793          	andi	a5,a1,7
    2386:	16078463          	beqz	a5,24ee <stpncpy+0x176>
    238a:	ea01                	bnez	a2,239a <stpncpy+0x22>
    238c:	a421                	j	2594 <stpncpy+0x21c>
    238e:	167d                	addi	a2,a2,-1
    2390:	0505                	addi	a0,a0,1
    2392:	14070e63          	beqz	a4,24ee <stpncpy+0x176>
    2396:	1a060863          	beqz	a2,2546 <stpncpy+0x1ce>
    239a:	0005c783          	lbu	a5,0(a1)
    239e:	0585                	addi	a1,a1,1
    23a0:	0075f713          	andi	a4,a1,7
    23a4:	00f50023          	sb	a5,0(a0)
    23a8:	f3fd                	bnez	a5,238e <stpncpy+0x16>
    23aa:	4805                	li	a6,1
    23ac:	1a061863          	bnez	a2,255c <stpncpy+0x1e4>
    23b0:	40a007b3          	neg	a5,a0
    23b4:	8b9d                	andi	a5,a5,7
    23b6:	4681                	li	a3,0
    23b8:	18061a63          	bnez	a2,254c <stpncpy+0x1d4>
    23bc:	00778713          	addi	a4,a5,7
    23c0:	45ad                	li	a1,11
    23c2:	18b76363          	bltu	a4,a1,2548 <stpncpy+0x1d0>
    23c6:	1ae6eb63          	bltu	a3,a4,257c <stpncpy+0x204>
    23ca:	1a078363          	beqz	a5,2570 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23ce:	00050023          	sb	zero,0(a0)
    23d2:	4685                	li	a3,1
    23d4:	00150713          	addi	a4,a0,1
    23d8:	18d78f63          	beq	a5,a3,2576 <stpncpy+0x1fe>
    23dc:	000500a3          	sb	zero,1(a0)
    23e0:	4689                	li	a3,2
    23e2:	00250713          	addi	a4,a0,2
    23e6:	18d78e63          	beq	a5,a3,2582 <stpncpy+0x20a>
    23ea:	00050123          	sb	zero,2(a0)
    23ee:	468d                	li	a3,3
    23f0:	00350713          	addi	a4,a0,3
    23f4:	16d78c63          	beq	a5,a3,256c <stpncpy+0x1f4>
    23f8:	000501a3          	sb	zero,3(a0)
    23fc:	4691                	li	a3,4
    23fe:	00450713          	addi	a4,a0,4
    2402:	18d78263          	beq	a5,a3,2586 <stpncpy+0x20e>
    2406:	00050223          	sb	zero,4(a0)
    240a:	4695                	li	a3,5
    240c:	00550713          	addi	a4,a0,5
    2410:	16d78d63          	beq	a5,a3,258a <stpncpy+0x212>
    2414:	000502a3          	sb	zero,5(a0)
    2418:	469d                	li	a3,7
    241a:	00650713          	addi	a4,a0,6
    241e:	16d79863          	bne	a5,a3,258e <stpncpy+0x216>
    2422:	00750713          	addi	a4,a0,7
    2426:	00050323          	sb	zero,6(a0)
    242a:	40f80833          	sub	a6,a6,a5
    242e:	ff887593          	andi	a1,a6,-8
    2432:	97aa                	add	a5,a5,a0
    2434:	95be                	add	a1,a1,a5
    2436:	0007b023          	sd	zero,0(a5)
    243a:	07a1                	addi	a5,a5,8
    243c:	feb79de3          	bne	a5,a1,2436 <stpncpy+0xbe>
    2440:	ff887593          	andi	a1,a6,-8
    2444:	9ead                	addw	a3,a3,a1
    2446:	00b707b3          	add	a5,a4,a1
    244a:	12b80863          	beq	a6,a1,257a <stpncpy+0x202>
    244e:	00078023          	sb	zero,0(a5)
    2452:	0016871b          	addiw	a4,a3,1
    2456:	0ec77863          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    245a:	000780a3          	sb	zero,1(a5)
    245e:	0026871b          	addiw	a4,a3,2
    2462:	0ec77263          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    2466:	00078123          	sb	zero,2(a5)
    246a:	0036871b          	addiw	a4,a3,3
    246e:	0cc77c63          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    2472:	000781a3          	sb	zero,3(a5)
    2476:	0046871b          	addiw	a4,a3,4
    247a:	0cc77663          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    247e:	00078223          	sb	zero,4(a5)
    2482:	0056871b          	addiw	a4,a3,5
    2486:	0cc77063          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    248a:	000782a3          	sb	zero,5(a5)
    248e:	0066871b          	addiw	a4,a3,6
    2492:	0ac77a63          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    2496:	00078323          	sb	zero,6(a5)
    249a:	0076871b          	addiw	a4,a3,7
    249e:	0ac77463          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24a2:	000783a3          	sb	zero,7(a5)
    24a6:	0086871b          	addiw	a4,a3,8
    24aa:	08c77e63          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24ae:	00078423          	sb	zero,8(a5)
    24b2:	0096871b          	addiw	a4,a3,9
    24b6:	08c77863          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24ba:	000784a3          	sb	zero,9(a5)
    24be:	00a6871b          	addiw	a4,a3,10
    24c2:	08c77263          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24c6:	00078523          	sb	zero,10(a5)
    24ca:	00b6871b          	addiw	a4,a3,11
    24ce:	06c77c63          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24d2:	000785a3          	sb	zero,11(a5)
    24d6:	00c6871b          	addiw	a4,a3,12
    24da:	06c77663          	bgeu	a4,a2,2546 <stpncpy+0x1ce>
    24de:	00078623          	sb	zero,12(a5)
    24e2:	26b5                	addiw	a3,a3,13
    24e4:	06c6f163          	bgeu	a3,a2,2546 <stpncpy+0x1ce>
    24e8:	000786a3          	sb	zero,13(a5)
    24ec:	8082                	ret
			;
		if (!n || !*s)
    24ee:	c645                	beqz	a2,2596 <stpncpy+0x21e>
    24f0:	0005c783          	lbu	a5,0(a1)
    24f4:	ea078be3          	beqz	a5,23aa <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24f8:	479d                	li	a5,7
    24fa:	02c7ff63          	bgeu	a5,a2,2538 <stpncpy+0x1c0>
    24fe:	00000897          	auipc	a7,0x0
    2502:	25a8b883          	ld	a7,602(a7) # 2758 <basename+0x1c0>
    2506:	00000817          	auipc	a6,0x0
    250a:	25a83803          	ld	a6,602(a6) # 2760 <basename+0x1c8>
    250e:	431d                	li	t1,7
    2510:	6198                	ld	a4,0(a1)
    2512:	011707b3          	add	a5,a4,a7
    2516:	fff74693          	not	a3,a4
    251a:	8ff5                	and	a5,a5,a3
    251c:	0107f7b3          	and	a5,a5,a6
    2520:	ef81                	bnez	a5,2538 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2522:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2524:	1661                	addi	a2,a2,-8
    2526:	05a1                	addi	a1,a1,8
    2528:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    252a:	fec363e3          	bltu	t1,a2,2510 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    252e:	e609                	bnez	a2,2538 <stpncpy+0x1c0>
    2530:	a08d                	j	2592 <stpncpy+0x21a>
    2532:	167d                	addi	a2,a2,-1
    2534:	0505                	addi	a0,a0,1
    2536:	ca01                	beqz	a2,2546 <stpncpy+0x1ce>
    2538:	0005c783          	lbu	a5,0(a1)
    253c:	0585                	addi	a1,a1,1
    253e:	00f50023          	sb	a5,0(a0)
    2542:	fbe5                	bnez	a5,2532 <stpncpy+0x1ba>
		;
tail:
    2544:	b59d                	j	23aa <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2546:	8082                	ret
    2548:	472d                	li	a4,11
    254a:	bdb5                	j	23c6 <stpncpy+0x4e>
    254c:	00778713          	addi	a4,a5,7
    2550:	45ad                	li	a1,11
    2552:	fff60693          	addi	a3,a2,-1
    2556:	e6b778e3          	bgeu	a4,a1,23c6 <stpncpy+0x4e>
    255a:	b7fd                	j	2548 <stpncpy+0x1d0>
    255c:	40a007b3          	neg	a5,a0
    2560:	8832                	mv	a6,a2
    2562:	8b9d                	andi	a5,a5,7
    2564:	4681                	li	a3,0
    2566:	e4060be3          	beqz	a2,23bc <stpncpy+0x44>
    256a:	b7cd                	j	254c <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    256c:	468d                	li	a3,3
    256e:	bd75                	j	242a <stpncpy+0xb2>
    2570:	872a                	mv	a4,a0
    2572:	4681                	li	a3,0
    2574:	bd5d                	j	242a <stpncpy+0xb2>
    2576:	4685                	li	a3,1
    2578:	bd4d                	j	242a <stpncpy+0xb2>
    257a:	8082                	ret
    257c:	87aa                	mv	a5,a0
    257e:	4681                	li	a3,0
    2580:	b5f9                	j	244e <stpncpy+0xd6>
    2582:	4689                	li	a3,2
    2584:	b55d                	j	242a <stpncpy+0xb2>
    2586:	4691                	li	a3,4
    2588:	b54d                	j	242a <stpncpy+0xb2>
    258a:	4695                	li	a3,5
    258c:	bd79                	j	242a <stpncpy+0xb2>
    258e:	4699                	li	a3,6
    2590:	bd69                	j	242a <stpncpy+0xb2>
    2592:	8082                	ret
    2594:	8082                	ret
    2596:	8082                	ret

0000000000002598 <basename>:

char *basename(char *s)
{
    2598:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    259a:	c54d                	beqz	a0,2644 <basename+0xac>
    259c:	00054783          	lbu	a5,0(a0)
		return ".";
    25a0:	00000517          	auipc	a0,0x0
    25a4:	1b050513          	addi	a0,a0,432 # 2750 <basename+0x1b8>
	if (!s || !*s)
    25a8:	e391                	bnez	a5,25ac <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25aa:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25ac:	0076f713          	andi	a4,a3,7
    25b0:	87b6                	mv	a5,a3
    25b2:	cf51                	beqz	a4,264e <basename+0xb6>
    25b4:	0785                	addi	a5,a5,1
    25b6:	0077f713          	andi	a4,a5,7
    25ba:	c729                	beqz	a4,2604 <basename+0x6c>
		if (!*s)
    25bc:	0007c703          	lbu	a4,0(a5)
    25c0:	fb75                	bnez	a4,25b4 <basename+0x1c>
	return s - a;
    25c2:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25c4:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25c6:	cf8d                	beqz	a5,2600 <basename+0x68>
    25c8:	00f68733          	add	a4,a3,a5
    25cc:	02f00593          	li	a1,47
    25d0:	a031                	j	25dc <basename+0x44>
		s[i] = 0;
    25d2:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25d6:	17fd                	addi	a5,a5,-1
    25d8:	177d                	addi	a4,a4,-1
    25da:	c39d                	beqz	a5,2600 <basename+0x68>
    25dc:	00074603          	lbu	a2,0(a4)
    25e0:	feb609e3          	beq	a2,a1,25d2 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25e4:	02f00613          	li	a2,47
    25e8:	a011                	j	25ec <basename+0x54>
    25ea:	cb99                	beqz	a5,2600 <basename+0x68>
    25ec:	853e                	mv	a0,a5
    25ee:	17fd                	addi	a5,a5,-1
    25f0:	00f68733          	add	a4,a3,a5
    25f4:	00074703          	lbu	a4,0(a4)
    25f8:	fec719e3          	bne	a4,a2,25ea <basename+0x52>
	return s + i;
    25fc:	9536                	add	a0,a0,a3
    25fe:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2600:	8536                	mv	a0,a3
    2602:	8082                	ret
    2604:	6390                	ld	a2,0(a5)
    2606:	00000517          	auipc	a0,0x0
    260a:	15253503          	ld	a0,338(a0) # 2758 <basename+0x1c0>
    260e:	00000597          	auipc	a1,0x0
    2612:	1525b583          	ld	a1,338(a1) # 2760 <basename+0x1c8>
    2616:	fff64713          	not	a4,a2
    261a:	962a                	add	a2,a2,a0
    261c:	8f71                	and	a4,a4,a2
    261e:	8f6d                	and	a4,a4,a1
    2620:	eb11                	bnez	a4,2634 <basename+0x9c>
    2622:	6790                	ld	a2,8(a5)
    2624:	07a1                	addi	a5,a5,8
    2626:	00a60733          	add	a4,a2,a0
    262a:	fff64613          	not	a2,a2
    262e:	8f71                	and	a4,a4,a2
    2630:	8f6d                	and	a4,a4,a1
    2632:	db65                	beqz	a4,2622 <basename+0x8a>
	for (; *s; s++)
    2634:	0007c703          	lbu	a4,0(a5)
    2638:	d749                	beqz	a4,25c2 <basename+0x2a>
    263a:	0017c703          	lbu	a4,1(a5)
    263e:	0785                	addi	a5,a5,1
    2640:	ff6d                	bnez	a4,263a <basename+0xa2>
    2642:	b741                	j	25c2 <basename+0x2a>
		return ".";
    2644:	00000517          	auipc	a0,0x0
    2648:	10c50513          	addi	a0,a0,268 # 2750 <basename+0x1b8>
    264c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    264e:	6290                	ld	a2,0(a3)
    2650:	00000517          	auipc	a0,0x0
    2654:	10853503          	ld	a0,264(a0) # 2758 <basename+0x1c0>
    2658:	00000597          	auipc	a1,0x0
    265c:	1085b583          	ld	a1,264(a1) # 2760 <basename+0x1c8>
    2660:	fff64713          	not	a4,a2
    2664:	962a                	add	a2,a2,a0
    2666:	8f71                	and	a4,a4,a2
    2668:	8f6d                	and	a4,a4,a1
    266a:	df45                	beqz	a4,2622 <basename+0x8a>
    266c:	b7f9                	j	263a <basename+0xa2>
