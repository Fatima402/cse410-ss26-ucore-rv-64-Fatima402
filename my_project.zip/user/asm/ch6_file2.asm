
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6_file2:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a6a1                	j	1348 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

/// 测试 link/unlink，输出　Test link OK! 就算正确。

int main()
{
    1002:	7129                	addi	sp,sp,-320
	char *fname = "fname2";
	char *lname0 = "linkname0";
	char *lname1 = "linkname1";
	char *lname2 = "linkname2";

	int fd = open(fname, O_CREATE | O_WRONLY);
    1004:	20100593          	li	a1,513
    1008:	00002517          	auipc	a0,0x2
    100c:	9a850513          	addi	a0,a0,-1624 # 29b0 <enable_deadlock_detect+0xe>
{
    1010:	fa22                	sd	s0,304(sp)
    1012:	fe06                	sd	ra,312(sp)
    1014:	f626                	sd	s1,296(sp)
    1016:	f24a                	sd	s2,288(sp)
    1018:	ee4e                	sd	s3,280(sp)
	int fd = open(fname, O_CREATE | O_WRONLY);
    101a:	666010ef          	jal	ra,2680 <open>
    101e:	842a                	mv	s0,a0
	assert(fd > 0);
    1020:	2ea05963          	blez	a0,1312 <main+0x310>
	link(fname, lname0);
    1024:	00002597          	auipc	a1,0x2
    1028:	a1458593          	addi	a1,a1,-1516 # 2a38 <enable_deadlock_detect+0x96>
    102c:	00002517          	auipc	a0,0x2
    1030:	98450513          	addi	a0,a0,-1660 # 29b0 <enable_deadlock_detect+0xe>
    1034:	053010ef          	jal	ra,2886 <link>
	Stat stat;
	fstat(fd, &stat);
    1038:	0024                	addi	s1,sp,8
    103a:	85a6                	mv	a1,s1
    103c:	8522                	mv	a0,s0
    103e:	01d010ef          	jal	ra,285a <fstat>
	assert_eq(stat.nlink, 2);
    1042:	4772                	lw	a4,28(sp)
    1044:	4789                	li	a5,2
    1046:	02f70e63          	beq	a4,a5,1082 <main+0x80>
    104a:	68a010ef          	jal	ra,26d4 <getpid>
    104e:	892a                	mv	s2,a0
    1050:	00002517          	auipc	a0,0x2
    1054:	96850513          	addi	a0,a0,-1688 # 29b8 <enable_deadlock_detect+0x16>
    1058:	552010ef          	jal	ra,25aa <basename>
    105c:	4872                	lw	a6,28(sp)
    105e:	872a                	mv	a4,a0
    1060:	4889                	li	a7,2
    1062:	00002517          	auipc	a0,0x2
    1066:	9e650513          	addi	a0,a0,-1562 # 2a48 <enable_deadlock_detect+0xa6>
    106a:	47d9                	li	a5,22
    106c:	86ca                	mv	a3,s2
    106e:	00002617          	auipc	a2,0x2
    1072:	99260613          	addi	a2,a2,-1646 # 2a00 <enable_deadlock_detect+0x5e>
    1076:	45fd                	li	a1,31
    1078:	42a000ef          	jal	ra,14a2 <printf>
    107c:	557d                	li	a0,-1
    107e:	686010ef          	jal	ra,2704 <exit>
	link(fname, lname1);
    1082:	00002597          	auipc	a1,0x2
    1086:	9fe58593          	addi	a1,a1,-1538 # 2a80 <enable_deadlock_detect+0xde>
    108a:	00002517          	auipc	a0,0x2
    108e:	92650513          	addi	a0,a0,-1754 # 29b0 <enable_deadlock_detect+0xe>
    1092:	7f4010ef          	jal	ra,2886 <link>
	link(fname, lname2);
    1096:	00002597          	auipc	a1,0x2
    109a:	9fa58593          	addi	a1,a1,-1542 # 2a90 <enable_deadlock_detect+0xee>
    109e:	00002517          	auipc	a0,0x2
    10a2:	91250513          	addi	a0,a0,-1774 # 29b0 <enable_deadlock_detect+0xe>
    10a6:	7e0010ef          	jal	ra,2886 <link>
	fstat(fd, &stat);
    10aa:	85a6                	mv	a1,s1
    10ac:	8522                	mv	a0,s0
    10ae:	7ac010ef          	jal	ra,285a <fstat>
	assert_eq(stat.nlink, 4);
    10b2:	4772                	lw	a4,28(sp)
    10b4:	4791                	li	a5,4
    10b6:	02f70e63          	beq	a4,a5,10f2 <main+0xf0>
    10ba:	61a010ef          	jal	ra,26d4 <getpid>
    10be:	84aa                	mv	s1,a0
    10c0:	00002517          	auipc	a0,0x2
    10c4:	8f850513          	addi	a0,a0,-1800 # 29b8 <enable_deadlock_detect+0x16>
    10c8:	4e2010ef          	jal	ra,25aa <basename>
    10cc:	4872                	lw	a6,28(sp)
    10ce:	872a                	mv	a4,a0
    10d0:	4891                	li	a7,4
    10d2:	00002517          	auipc	a0,0x2
    10d6:	97650513          	addi	a0,a0,-1674 # 2a48 <enable_deadlock_detect+0xa6>
    10da:	47e9                	li	a5,26
    10dc:	86a6                	mv	a3,s1
    10de:	00002617          	auipc	a2,0x2
    10e2:	92260613          	addi	a2,a2,-1758 # 2a00 <enable_deadlock_detect+0x5e>
    10e6:	45fd                	li	a1,31
    10e8:	3ba000ef          	jal	ra,14a2 <printf>
    10ec:	557d                	li	a0,-1
    10ee:	616010ef          	jal	ra,2704 <exit>
	write(fd, test_str, strlen(test_str));
    10f2:	00002517          	auipc	a0,0x2
    10f6:	9ae50513          	addi	a0,a0,-1618 # 2aa0 <enable_deadlock_detect+0xfe>
    10fa:	10a010ef          	jal	ra,2204 <strlen>
    10fe:	862a                	mv	a2,a0
    1100:	00002597          	auipc	a1,0x2
    1104:	9a058593          	addi	a1,a1,-1632 # 2aa0 <enable_deadlock_detect+0xfe>
    1108:	8522                	mv	a0,s0
    110a:	5c0010ef          	jal	ra,26ca <write>
	close(fd);
    110e:	8522                	mv	a0,s0
    1110:	57e010ef          	jal	ra,268e <close>

	unlink(fname);
    1114:	00002517          	auipc	a0,0x2
    1118:	89c50513          	addi	a0,a0,-1892 # 29b0 <enable_deadlock_detect+0xe>
    111c:	786010ef          	jal	ra,28a2 <unlink>
	fd = open(lname0, O_RDONLY);
    1120:	4581                	li	a1,0
    1122:	00002517          	auipc	a0,0x2
    1126:	91650513          	addi	a0,a0,-1770 # 2a38 <enable_deadlock_detect+0x96>
    112a:	556010ef          	jal	ra,2680 <open>
	Stat stat2;
	char buf[100];
	memset(buf, 0, sizeof(buf));
    112e:	1124                	addi	s1,sp,168
	fd = open(lname0, O_RDONLY);
    1130:	842a                	mv	s0,a0
	memset(buf, 0, sizeof(buf));
    1132:	06400613          	li	a2,100
    1136:	4581                	li	a1,0
    1138:	8526                	mv	a0,s1
    113a:	6bd000ef          	jal	ra,1ff6 <memset>
	int read_len = read(fd, &buf, sizeof(buf));
    113e:	06400613          	li	a2,100
    1142:	85a6                	mv	a1,s1
    1144:	8522                	mv	a0,s0
    1146:	57a010ef          	jal	ra,26c0 <read>
	assert_eq(strncmp(test_str, buf, read_len), 0);
    114a:	0005091b          	sext.w	s2,a0
    114e:	864a                	mv	a2,s2
    1150:	85a6                	mv	a1,s1
    1152:	00002517          	auipc	a0,0x2
    1156:	94e50513          	addi	a0,a0,-1714 # 2aa0 <enable_deadlock_detect+0xfe>
    115a:	060010ef          	jal	ra,21ba <strncmp>
    115e:	16051263          	bnez	a0,12c2 <main+0x2c0>
	fstat(fd, &stat2);
    1162:	08a4                	addi	s1,sp,88
    1164:	85a6                	mv	a1,s1
    1166:	8522                	mv	a0,s0
    1168:	6f2010ef          	jal	ra,285a <fstat>
	assert_eq(stat2.dev, stat.dev);
    116c:	6766                	ld	a4,88(sp)
    116e:	67a2                	ld	a5,8(sp)
    1170:	02f70f63          	beq	a4,a5,11ae <main+0x1ac>
    1174:	560010ef          	jal	ra,26d4 <getpid>
    1178:	892a                	mv	s2,a0
    117a:	00002517          	auipc	a0,0x2
    117e:	83e50513          	addi	a0,a0,-1986 # 29b8 <enable_deadlock_detect+0x16>
    1182:	428010ef          	jal	ra,25aa <basename>
    1186:	68a2                	ld	a7,8(sp)
    1188:	6866                	ld	a6,88(sp)
    118a:	872a                	mv	a4,a0
    118c:	02600793          	li	a5,38
    1190:	00002517          	auipc	a0,0x2
    1194:	8b850513          	addi	a0,a0,-1864 # 2a48 <enable_deadlock_detect+0xa6>
    1198:	86ca                	mv	a3,s2
    119a:	00002617          	auipc	a2,0x2
    119e:	86660613          	addi	a2,a2,-1946 # 2a00 <enable_deadlock_detect+0x5e>
    11a2:	45fd                	li	a1,31
    11a4:	2fe000ef          	jal	ra,14a2 <printf>
    11a8:	557d                	li	a0,-1
    11aa:	55a010ef          	jal	ra,2704 <exit>
	assert_eq(stat2.ino, stat.ino);
    11ae:	7706                	ld	a4,96(sp)
    11b0:	67c2                	ld	a5,16(sp)
    11b2:	02f70f63          	beq	a4,a5,11f0 <main+0x1ee>
    11b6:	51e010ef          	jal	ra,26d4 <getpid>
    11ba:	892a                	mv	s2,a0
    11bc:	00001517          	auipc	a0,0x1
    11c0:	7fc50513          	addi	a0,a0,2044 # 29b8 <enable_deadlock_detect+0x16>
    11c4:	3e6010ef          	jal	ra,25aa <basename>
    11c8:	68c2                	ld	a7,16(sp)
    11ca:	7806                	ld	a6,96(sp)
    11cc:	872a                	mv	a4,a0
    11ce:	02700793          	li	a5,39
    11d2:	00002517          	auipc	a0,0x2
    11d6:	87650513          	addi	a0,a0,-1930 # 2a48 <enable_deadlock_detect+0xa6>
    11da:	86ca                	mv	a3,s2
    11dc:	00002617          	auipc	a2,0x2
    11e0:	82460613          	addi	a2,a2,-2012 # 2a00 <enable_deadlock_detect+0x5e>
    11e4:	45fd                	li	a1,31
    11e6:	2bc000ef          	jal	ra,14a2 <printf>
    11ea:	557d                	li	a0,-1
    11ec:	518010ef          	jal	ra,2704 <exit>
	assert_eq(stat2.nlink, 3);
    11f0:	5736                	lw	a4,108(sp)
    11f2:	478d                	li	a5,3
    11f4:	02f70f63          	beq	a4,a5,1232 <main+0x230>
    11f8:	4dc010ef          	jal	ra,26d4 <getpid>
    11fc:	892a                	mv	s2,a0
    11fe:	00001517          	auipc	a0,0x1
    1202:	7ba50513          	addi	a0,a0,1978 # 29b8 <enable_deadlock_detect+0x16>
    1206:	3a4010ef          	jal	ra,25aa <basename>
    120a:	5836                	lw	a6,108(sp)
    120c:	872a                	mv	a4,a0
    120e:	488d                	li	a7,3
    1210:	00002517          	auipc	a0,0x2
    1214:	83850513          	addi	a0,a0,-1992 # 2a48 <enable_deadlock_detect+0xa6>
    1218:	02800793          	li	a5,40
    121c:	86ca                	mv	a3,s2
    121e:	00001617          	auipc	a2,0x1
    1222:	7e260613          	addi	a2,a2,2018 # 2a00 <enable_deadlock_detect+0x5e>
    1226:	45fd                	li	a1,31
    1228:	27a000ef          	jal	ra,14a2 <printf>
    122c:	557d                	li	a0,-1
    122e:	4d6010ef          	jal	ra,2704 <exit>
	unlink(lname1);
    1232:	00002517          	auipc	a0,0x2
    1236:	84e50513          	addi	a0,a0,-1970 # 2a80 <enable_deadlock_detect+0xde>
    123a:	668010ef          	jal	ra,28a2 <unlink>
	unlink(lname2);
    123e:	00002517          	auipc	a0,0x2
    1242:	85250513          	addi	a0,a0,-1966 # 2a90 <enable_deadlock_detect+0xee>
    1246:	65c010ef          	jal	ra,28a2 <unlink>
	fstat(fd, &stat2);
    124a:	85a6                	mv	a1,s1
    124c:	8522                	mv	a0,s0
    124e:	60c010ef          	jal	ra,285a <fstat>
	assert_eq(stat2.nlink, 1);
    1252:	5736                	lw	a4,108(sp)
    1254:	4785                	li	a5,1
    1256:	02f70f63          	beq	a4,a5,1294 <main+0x292>
    125a:	47a010ef          	jal	ra,26d4 <getpid>
    125e:	84aa                	mv	s1,a0
    1260:	00001517          	auipc	a0,0x1
    1264:	75850513          	addi	a0,a0,1880 # 29b8 <enable_deadlock_detect+0x16>
    1268:	342010ef          	jal	ra,25aa <basename>
    126c:	5836                	lw	a6,108(sp)
    126e:	872a                	mv	a4,a0
    1270:	4885                	li	a7,1
    1272:	00001517          	auipc	a0,0x1
    1276:	7d650513          	addi	a0,a0,2006 # 2a48 <enable_deadlock_detect+0xa6>
    127a:	02c00793          	li	a5,44
    127e:	86a6                	mv	a3,s1
    1280:	00001617          	auipc	a2,0x1
    1284:	78060613          	addi	a2,a2,1920 # 2a00 <enable_deadlock_detect+0x5e>
    1288:	45fd                	li	a1,31
    128a:	218000ef          	jal	ra,14a2 <printf>
    128e:	557d                	li	a0,-1
    1290:	474010ef          	jal	ra,2704 <exit>
	close(fd);
    1294:	8522                	mv	a0,s0
    1296:	3f8010ef          	jal	ra,268e <close>
	unlink(lname0);
    129a:	00001517          	auipc	a0,0x1
    129e:	79e50513          	addi	a0,a0,1950 # 2a38 <enable_deadlock_detect+0x96>
    12a2:	600010ef          	jal	ra,28a2 <unlink>
	// It's Ok if you don't delete the inode and data blocks.
	puts("Test link OK!");
    12a6:	00002517          	auipc	a0,0x2
    12aa:	80a50513          	addi	a0,a0,-2038 # 2ab0 <enable_deadlock_detect+0x10e>
    12ae:	10b000ef          	jal	ra,1bb8 <puts>
	return 0;
    12b2:	70f2                	ld	ra,312(sp)
    12b4:	7452                	ld	s0,304(sp)
    12b6:	74b2                	ld	s1,296(sp)
    12b8:	7912                	ld	s2,288(sp)
    12ba:	69f2                	ld	s3,280(sp)
    12bc:	4501                	li	a0,0
    12be:	6131                	addi	sp,sp,320
    12c0:	8082                	ret
	assert_eq(strncmp(test_str, buf, read_len), 0);
    12c2:	412010ef          	jal	ra,26d4 <getpid>
    12c6:	89aa                	mv	s3,a0
    12c8:	00001517          	auipc	a0,0x1
    12cc:	6f050513          	addi	a0,a0,1776 # 29b8 <enable_deadlock_detect+0x16>
    12d0:	2da010ef          	jal	ra,25aa <basename>
    12d4:	872a                	mv	a4,a0
    12d6:	864a                	mv	a2,s2
    12d8:	85a6                	mv	a1,s1
    12da:	00001517          	auipc	a0,0x1
    12de:	7c650513          	addi	a0,a0,1990 # 2aa0 <enable_deadlock_detect+0xfe>
    12e2:	84ba                	mv	s1,a4
    12e4:	6d7000ef          	jal	ra,21ba <strncmp>
    12e8:	882a                	mv	a6,a0
    12ea:	4881                	li	a7,0
    12ec:	00001517          	auipc	a0,0x1
    12f0:	75c50513          	addi	a0,a0,1884 # 2a48 <enable_deadlock_detect+0xa6>
    12f4:	02400793          	li	a5,36
    12f8:	8726                	mv	a4,s1
    12fa:	86ce                	mv	a3,s3
    12fc:	00001617          	auipc	a2,0x1
    1300:	70460613          	addi	a2,a2,1796 # 2a00 <enable_deadlock_detect+0x5e>
    1304:	45fd                	li	a1,31
    1306:	19c000ef          	jal	ra,14a2 <printf>
    130a:	557d                	li	a0,-1
    130c:	3f8010ef          	jal	ra,2704 <exit>
    1310:	bd89                	j	1162 <main+0x160>
	assert(fd > 0);
    1312:	3c2010ef          	jal	ra,26d4 <getpid>
    1316:	84aa                	mv	s1,a0
    1318:	00001517          	auipc	a0,0x1
    131c:	6a050513          	addi	a0,a0,1696 # 29b8 <enable_deadlock_detect+0x16>
    1320:	28a010ef          	jal	ra,25aa <basename>
    1324:	872a                	mv	a4,a0
    1326:	47c9                	li	a5,18
    1328:	00001517          	auipc	a0,0x1
    132c:	6e050513          	addi	a0,a0,1760 # 2a08 <enable_deadlock_detect+0x66>
    1330:	86a6                	mv	a3,s1
    1332:	00001617          	auipc	a2,0x1
    1336:	6ce60613          	addi	a2,a2,1742 # 2a00 <enable_deadlock_detect+0x5e>
    133a:	45fd                	li	a1,31
    133c:	166000ef          	jal	ra,14a2 <printf>
    1340:	557d                	li	a0,-1
    1342:	3c2010ef          	jal	ra,2704 <exit>
    1346:	b9f9                	j	1024 <main+0x22>

0000000000001348 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1348:	1141                	addi	sp,sp,-16
    134a:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    134c:	cb7ff0ef          	jal	ra,1002 <main>
    1350:	3b4010ef          	jal	ra,2704 <exit>
	return 0;
    1354:	60a2                	ld	ra,8(sp)
    1356:	4501                	li	a0,0
    1358:	0141                	addi	sp,sp,16
    135a:	8082                	ret

000000000000135c <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    135c:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    135e:	4605                	li	a2,1
    1360:	00f10593          	addi	a1,sp,15
    1364:	4501                	li	a0,0
{
    1366:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1368:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    136c:	354010ef          	jal	ra,26c0 <read>
    1370:	4785                	li	a5,1
    1372:	00f51763          	bne	a0,a5,1380 <getchar+0x24>
		return byte;
    1376:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    137a:	60e2                	ld	ra,24(sp)
    137c:	6105                	addi	sp,sp,32
    137e:	8082                	ret
		return EOF;
    1380:	557d                	li	a0,-1
    1382:	bfe5                	j	137a <getchar+0x1e>

0000000000001384 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1384:	00002517          	auipc	a0,0x2
    1388:	83452503          	lw	a0,-1996(a0) # 2bb8 <buffer_len>
    138c:	e111                	bnez	a0,1390 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    138e:	8082                	ret
{
    1390:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1392:	862a                	mv	a2,a0
    1394:	00002597          	auipc	a1,0x2
    1398:	82c58593          	addi	a1,a1,-2004 # 2bc0 <buffer>
    139c:	4505                	li	a0,1
{
    139e:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13a0:	32a010ef          	jal	ra,26ca <write>
}
    13a4:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13a6:	2501                	sext.w	a0,a0
}
    13a8:	0141                	addi	sp,sp,16
    13aa:	8082                	ret

00000000000013ac <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    13ac:	00002797          	auipc	a5,0x2
    13b0:	8007a623          	sw	zero,-2036(a5) # 2bb8 <buffer_len>
}
    13b4:	8082                	ret

00000000000013b6 <__fflush>:
	if (buffer_len == 0)
    13b6:	00002517          	auipc	a0,0x2
    13ba:	80252503          	lw	a0,-2046(a0) # 2bb8 <buffer_len>
    13be:	e511                	bnez	a0,13ca <__fflush+0x14>
	buffer_len = 0;
    13c0:	00001797          	auipc	a5,0x1
    13c4:	7e07ac23          	sw	zero,2040(a5) # 2bb8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13c8:	8082                	ret
{
    13ca:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13cc:	862a                	mv	a2,a0
    13ce:	00001597          	auipc	a1,0x1
    13d2:	7f258593          	addi	a1,a1,2034 # 2bc0 <buffer>
    13d6:	4505                	li	a0,1
{
    13d8:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13da:	2f0010ef          	jal	ra,26ca <write>
	return r >= 0 ? 0 : r;
    13de:	0005079b          	sext.w	a5,a0
}
    13e2:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13e4:	0017a793          	slti	a5,a5,1
    13e8:	40f007bb          	negw	a5,a5
    13ec:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13ee:	00001797          	auipc	a5,0x1
    13f2:	7c07a523          	sw	zero,1994(a5) # 2bb8 <buffer_len>
	return r >= 0 ? 0 : r;
    13f6:	2501                	sext.w	a0,a0
}
    13f8:	0141                	addi	sp,sp,16
    13fa:	8082                	ret

00000000000013fc <fflush>:

int fflush(int fd)
{
    13fc:	1101                	addi	sp,sp,-32
    13fe:	e822                	sd	s0,16(sp)
    1400:	ec06                	sd	ra,24(sp)
    1402:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1404:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1406:	4401                	li	s0,0
	if (fd == 1) {
    1408:	00e50863          	beq	a0,a4,1418 <fflush+0x1c>
}
    140c:	60e2                	ld	ra,24(sp)
    140e:	8522                	mv	a0,s0
    1410:	6442                	ld	s0,16(sp)
    1412:	64a2                	ld	s1,8(sp)
    1414:	6105                	addi	sp,sp,32
    1416:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1418:	00001497          	auipc	s1,0x1
    141c:	7a048493          	addi	s1,s1,1952 # 2bb8 <buffer_len>
    1420:	1084a703          	lw	a4,264(s1)
    1424:	02a70e63          	beq	a4,a0,1460 <fflush+0x64>
	if (buffer_len == 0)
    1428:	4080                	lw	s0,0(s1)
    142a:	c00d                	beqz	s0,144c <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    142c:	8622                	mv	a2,s0
    142e:	00001597          	auipc	a1,0x1
    1432:	79258593          	addi	a1,a1,1938 # 2bc0 <buffer>
    1436:	294010ef          	jal	ra,26ca <write>
	return r >= 0 ? 0 : r;
    143a:	0005079b          	sext.w	a5,a0
    143e:	0017a793          	slti	a5,a5,1
    1442:	40f007bb          	negw	a5,a5
    1446:	8d7d                	and	a0,a0,a5
    1448:	0005041b          	sext.w	s0,a0
}
    144c:	60e2                	ld	ra,24(sp)
    144e:	8522                	mv	a0,s0
    1450:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1452:	00001797          	auipc	a5,0x1
    1456:	7607a323          	sw	zero,1894(a5) # 2bb8 <buffer_len>
}
    145a:	64a2                	ld	s1,8(sp)
    145c:	6105                	addi	sp,sp,32
    145e:	8082                	ret
			mutex_lock(buffer_lock);
    1460:	10c4a503          	lw	a0,268(s1)
    1464:	4de010ef          	jal	ra,2942 <mutex_lock>
	if (buffer_len == 0)
    1468:	4080                	lw	s0,0(s1)
    146a:	e811                	bnez	s0,147e <fflush+0x82>
			mutex_unlock(buffer_lock);
    146c:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1470:	00001797          	auipc	a5,0x1
    1474:	7407a423          	sw	zero,1864(a5) # 2bb8 <buffer_len>
			mutex_unlock(buffer_lock);
    1478:	4d6010ef          	jal	ra,294e <mutex_unlock>
    147c:	bf41                	j	140c <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    147e:	8622                	mv	a2,s0
    1480:	00001597          	auipc	a1,0x1
    1484:	74058593          	addi	a1,a1,1856 # 2bc0 <buffer>
    1488:	4505                	li	a0,1
    148a:	240010ef          	jal	ra,26ca <write>
	return r >= 0 ? 0 : r;
    148e:	0005079b          	sext.w	a5,a0
    1492:	0017a793          	slti	a5,a5,1
    1496:	40f007bb          	negw	a5,a5
    149a:	8d7d                	and	a0,a0,a5
    149c:	0005041b          	sext.w	s0,a0
	return r;
    14a0:	b7f1                	j	146c <fflush+0x70>

00000000000014a2 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    14a2:	7131                	addi	sp,sp,-192
    14a4:	e0da                	sd	s6,64(sp)
    14a6:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    14a8:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    14aa:	013c                	addi	a5,sp,136
{
    14ac:	f0ca                	sd	s2,96(sp)
    14ae:	ecce                	sd	s3,88(sp)
    14b0:	e8d2                	sd	s4,80(sp)
    14b2:	e4d6                	sd	s5,72(sp)
    14b4:	fc86                	sd	ra,120(sp)
    14b6:	f8a2                	sd	s0,112(sp)
    14b8:	f4a6                	sd	s1,104(sp)
    14ba:	89aa                	mv	s3,a0
    14bc:	e52e                	sd	a1,136(sp)
    14be:	e932                	sd	a2,144(sp)
    14c0:	ed36                	sd	a3,152(sp)
    14c2:	f13a                	sd	a4,160(sp)
    14c4:	f942                	sd	a6,176(sp)
    14c6:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14c8:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14ca:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14ce:	00001a17          	auipc	s4,0x1
    14d2:	6eaa0a13          	addi	s4,s4,1770 # 2bb8 <buffer_len>
    14d6:	4a85                	li	s5,1
	buf[i++] = '0';
    14d8:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14dc:	0009c783          	lbu	a5,0(s3)
    14e0:	18078663          	beqz	a5,166c <printf+0x1ca>
    14e4:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14e6:	19278d63          	beq	a5,s2,1680 <printf+0x1de>
    14ea:	0015c783          	lbu	a5,1(a1)
    14ee:	0585                	addi	a1,a1,1
    14f0:	fbfd                	bnez	a5,14e6 <printf+0x44>
    14f2:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14f4:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14f8:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14fc:	1b578863          	beq	a5,s5,16ac <printf+0x20a>
		len = out_unlocked(s, l);
    1500:	85a2                	mv	a1,s0
    1502:	854e                	mv	a0,s3
    1504:	42a000ef          	jal	ra,192e <out_unlocked>
		out(f, a, l);
		if (l)
    1508:	1c041063          	bnez	s0,16c8 <printf+0x226>
			continue;
		if (s[1] == 0)
    150c:	0014c783          	lbu	a5,1(s1)
    1510:	14078e63          	beqz	a5,166c <printf+0x1ca>
			break;
		switch (s[1]) {
    1514:	07300713          	li	a4,115
    1518:	1ce78863          	beq	a5,a4,16e8 <printf+0x246>
    151c:	1af76863          	bltu	a4,a5,16cc <printf+0x22a>
    1520:	06400713          	li	a4,100
    1524:	22e78063          	beq	a5,a4,1744 <printf+0x2a2>
    1528:	07000713          	li	a4,112
    152c:	1ee79563          	bne	a5,a4,1716 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1530:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1532:	00001797          	auipc	a5,0x1
    1536:	79678793          	addi	a5,a5,1942 # 2cc8 <digits>
	buf[i++] = '0';
    153a:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    153e:	6298                	ld	a4,0(a3)
    1540:	06a1                	addi	a3,a3,8
    1542:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1544:	00471393          	slli	t2,a4,0x4
    1548:	00871293          	slli	t0,a4,0x8
    154c:	00c71f93          	slli	t6,a4,0xc
    1550:	01071f13          	slli	t5,a4,0x10
    1554:	01471e93          	slli	t4,a4,0x14
    1558:	01871e13          	slli	t3,a4,0x18
    155c:	01c71893          	slli	a7,a4,0x1c
    1560:	02471813          	slli	a6,a4,0x24
    1564:	02871513          	slli	a0,a4,0x28
    1568:	02c71593          	slli	a1,a4,0x2c
    156c:	03071613          	slli	a2,a4,0x30
    1570:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1574:	03c75413          	srli	s0,a4,0x3c
    1578:	01c7531b          	srliw	t1,a4,0x1c
    157c:	03c3d393          	srli	t2,t2,0x3c
    1580:	03c2d293          	srli	t0,t0,0x3c
    1584:	03cfdf93          	srli	t6,t6,0x3c
    1588:	03cf5f13          	srli	t5,t5,0x3c
    158c:	03cede93          	srli	t4,t4,0x3c
    1590:	03ce5e13          	srli	t3,t3,0x3c
    1594:	03c8d893          	srli	a7,a7,0x3c
    1598:	03c85813          	srli	a6,a6,0x3c
    159c:	9171                	srli	a0,a0,0x3c
    159e:	91f1                	srli	a1,a1,0x3c
    15a0:	9271                	srli	a2,a2,0x3c
    15a2:	92f1                	srli	a3,a3,0x3c
    15a4:	95be                	add	a1,a1,a5
    15a6:	963e                	add	a2,a2,a5
    15a8:	96be                	add	a3,a3,a5
    15aa:	943e                	add	s0,s0,a5
    15ac:	93be                	add	t2,t2,a5
    15ae:	92be                	add	t0,t0,a5
    15b0:	9fbe                	add	t6,t6,a5
    15b2:	9f3e                	add	t5,t5,a5
    15b4:	9ebe                	add	t4,t4,a5
    15b6:	9e3e                	add	t3,t3,a5
    15b8:	98be                	add	a7,a7,a5
    15ba:	933e                	add	t1,t1,a5
    15bc:	983e                	add	a6,a6,a5
    15be:	953e                	add	a0,a0,a5
    15c0:	0005c983          	lbu	s3,0(a1)
    15c4:	00044403          	lbu	s0,0(s0)
    15c8:	00064583          	lbu	a1,0(a2)
    15cc:	0003c383          	lbu	t2,0(t2)
    15d0:	0006c603          	lbu	a2,0(a3)
    15d4:	0002c283          	lbu	t0,0(t0)
    15d8:	000fcf83          	lbu	t6,0(t6)
    15dc:	000f4f03          	lbu	t5,0(t5)
    15e0:	000ece83          	lbu	t4,0(t4)
    15e4:	000e4e03          	lbu	t3,0(t3)
    15e8:	0008c883          	lbu	a7,0(a7)
    15ec:	00034303          	lbu	t1,0(t1)
    15f0:	00084803          	lbu	a6,0(a6)
    15f4:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15f8:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15fc:	92f1                	srli	a3,a3,0x3c
    15fe:	8b3d                	andi	a4,a4,15
    1600:	96be                	add	a3,a3,a5
    1602:	97ba                	add	a5,a5,a4
    1604:	00810d23          	sb	s0,26(sp)
    1608:	00710da3          	sb	t2,27(sp)
    160c:	00510e23          	sb	t0,28(sp)
    1610:	01f10ea3          	sb	t6,29(sp)
    1614:	01e10f23          	sb	t5,30(sp)
    1618:	01d10fa3          	sb	t4,31(sp)
    161c:	03c10023          	sb	t3,32(sp)
    1620:	031100a3          	sb	a7,33(sp)
    1624:	02610123          	sb	t1,34(sp)
    1628:	030101a3          	sb	a6,35(sp)
    162c:	02a10223          	sb	a0,36(sp)
    1630:	033102a3          	sb	s3,37(sp)
    1634:	02b10323          	sb	a1,38(sp)
    1638:	02c103a3          	sb	a2,39(sp)
    163c:	0006c683          	lbu	a3,0(a3)
    1640:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1644:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1648:	02d10423          	sb	a3,40(sp)
    164c:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1650:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1654:	11578263          	beq	a5,s5,1758 <printf+0x2b6>
		len = out_unlocked(s, l);
    1658:	45c9                	li	a1,18
    165a:	0828                	addi	a0,sp,24
    165c:	2d2000ef          	jal	ra,192e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1660:	00248993          	addi	s3,s1,2
		if (!*s)
    1664:	0009c783          	lbu	a5,0(s3)
    1668:	e6079ee3          	bnez	a5,14e4 <printf+0x42>
	}
	va_end(ap);
    166c:	70e6                	ld	ra,120(sp)
    166e:	7446                	ld	s0,112(sp)
    1670:	74a6                	ld	s1,104(sp)
    1672:	7906                	ld	s2,96(sp)
    1674:	69e6                	ld	s3,88(sp)
    1676:	6a46                	ld	s4,80(sp)
    1678:	6aa6                	ld	s5,72(sp)
    167a:	6b06                	ld	s6,64(sp)
    167c:	6129                	addi	sp,sp,192
    167e:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1680:	0005c783          	lbu	a5,0(a1)
    1684:	84ae                	mv	s1,a1
    1686:	01278963          	beq	a5,s2,1698 <printf+0x1f6>
    168a:	b5ad                	j	14f4 <printf+0x52>
    168c:	0024c783          	lbu	a5,2(s1)
    1690:	0585                	addi	a1,a1,1
    1692:	0489                	addi	s1,s1,2
    1694:	e72790e3          	bne	a5,s2,14f4 <printf+0x52>
    1698:	0014c783          	lbu	a5,1(s1)
    169c:	ff2788e3          	beq	a5,s2,168c <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    16a0:	108a2783          	lw	a5,264(s4)
		l = z - a;
    16a4:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    16a8:	e5579ce3          	bne	a5,s5,1500 <printf+0x5e>
		mutex_lock(buffer_lock);
    16ac:	10ca2503          	lw	a0,268(s4)
    16b0:	292010ef          	jal	ra,2942 <mutex_lock>
		len = out_unlocked(s, l);
    16b4:	85a2                	mv	a1,s0
    16b6:	854e                	mv	a0,s3
    16b8:	276000ef          	jal	ra,192e <out_unlocked>
		mutex_unlock(buffer_lock);
    16bc:	10ca2503          	lw	a0,268(s4)
    16c0:	28e010ef          	jal	ra,294e <mutex_unlock>
		if (l)
    16c4:	e40404e3          	beqz	s0,150c <printf+0x6a>
    16c8:	89a6                	mv	s3,s1
    16ca:	bd09                	j	14dc <printf+0x3a>
		switch (s[1]) {
    16cc:	07800713          	li	a4,120
    16d0:	04e79363          	bne	a5,a4,1716 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16d4:	67c2                	ld	a5,16(sp)
    16d6:	45c1                	li	a1,16
		s += 2;
    16d8:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16dc:	4388                	lw	a0,0(a5)
    16de:	07a1                	addi	a5,a5,8
    16e0:	e83e                	sd	a5,16(sp)
    16e2:	5f8000ef          	jal	ra,1cda <printint.constprop.0>
		s += 2;
    16e6:	bfbd                	j	1664 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16e8:	67c2                	ld	a5,16(sp)
    16ea:	6380                	ld	s0,0(a5)
    16ec:	07a1                	addi	a5,a5,8
    16ee:	e83e                	sd	a5,16(sp)
    16f0:	1c040163          	beqz	s0,18b2 <printf+0x410>
			l = strnlen(a, 200);
    16f4:	0c800593          	li	a1,200
    16f8:	8522                	mv	a0,s0
    16fa:	3f7000ef          	jal	ra,22f0 <strnlen>
	if (buffer_lock_enabled == 1) {
    16fe:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1702:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1706:	19578663          	beq	a5,s5,1892 <printf+0x3f0>
		len = out_unlocked(s, l);
    170a:	8522                	mv	a0,s0
    170c:	222000ef          	jal	ra,192e <out_unlocked>
		s += 2;
    1710:	00248993          	addi	s3,s1,2
    1714:	bf81                	j	1664 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1716:	108a2783          	lw	a5,264(s4)
	char byte = c;
    171a:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    171e:	0f578663          	beq	a5,s5,180a <printf+0x368>
		len = out_unlocked(s, l);
    1722:	0828                	addi	a0,sp,24
    1724:	316000ef          	jal	ra,1a3a <out_unlocked.constprop.0>
			putchar(s[1]);
    1728:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    172c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1730:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1734:	05578163          	beq	a5,s5,1776 <printf+0x2d4>
		len = out_unlocked(s, l);
    1738:	0828                	addi	a0,sp,24
    173a:	300000ef          	jal	ra,1a3a <out_unlocked.constprop.0>
		s += 2;
    173e:	00248993          	addi	s3,s1,2
    1742:	b70d                	j	1664 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1744:	67c2                	ld	a5,16(sp)
    1746:	45a9                	li	a1,10
		s += 2;
    1748:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    174c:	4388                	lw	a0,0(a5)
    174e:	07a1                	addi	a5,a5,8
    1750:	e83e                	sd	a5,16(sp)
    1752:	588000ef          	jal	ra,1cda <printint.constprop.0>
		s += 2;
    1756:	b739                	j	1664 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1758:	10ca2503          	lw	a0,268(s4)
		s += 2;
    175c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1760:	1e2010ef          	jal	ra,2942 <mutex_lock>
		len = out_unlocked(s, l);
    1764:	45c9                	li	a1,18
    1766:	0828                	addi	a0,sp,24
    1768:	1c6000ef          	jal	ra,192e <out_unlocked>
		mutex_unlock(buffer_lock);
    176c:	10ca2503          	lw	a0,268(s4)
    1770:	1de010ef          	jal	ra,294e <mutex_unlock>
		s += 2;
    1774:	bdc5                	j	1664 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1776:	10ca2503          	lw	a0,268(s4)
    177a:	1c8010ef          	jal	ra,2942 <mutex_lock>
		buffer[buffer_len++] = c;
    177e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1782:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1786:	0017861b          	addiw	a2,a5,1
    178a:	97d2                	add	a5,a5,s4
    178c:	00ca2023          	sw	a2,0(s4)
    1790:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1794:	00c6cc63          	blt	a3,a2,17ac <printf+0x30a>
    1798:	47a9                	li	a5,10
    179a:	06f40663          	beq	s0,a5,1806 <printf+0x364>
		mutex_unlock(buffer_lock);
    179e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    17a2:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    17a6:	1a8010ef          	jal	ra,294e <mutex_unlock>
		s += 2;
    17aa:	bd6d                	j	1664 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    17ac:	10000793          	li	a5,256
    17b0:	00f61e63          	bne	a2,a5,17cc <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    17b4:	00001597          	auipc	a1,0x1
    17b8:	40c58593          	addi	a1,a1,1036 # 2bc0 <buffer>
    17bc:	4505                	li	a0,1
    17be:	70d000ef          	jal	ra,26ca <write>
	buffer_len = 0;
    17c2:	00001797          	auipc	a5,0x1
    17c6:	3e07ab23          	sw	zero,1014(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    17ca:	bfd1                	j	179e <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17cc:	709000ef          	jal	ra,26d4 <getpid>
    17d0:	842a                	mv	s0,a0
    17d2:	00001517          	auipc	a0,0x1
    17d6:	2f650513          	addi	a0,a0,758 # 2ac8 <enable_deadlock_detect+0x126>
    17da:	5d1000ef          	jal	ra,25aa <basename>
    17de:	872a                	mv	a4,a0
    17e0:	00001617          	auipc	a2,0x1
    17e4:	22060613          	addi	a2,a2,544 # 2a00 <enable_deadlock_detect+0x5e>
    17e8:	05400793          	li	a5,84
    17ec:	86a2                	mv	a3,s0
    17ee:	45fd                	li	a1,31
    17f0:	00001517          	auipc	a0,0x1
    17f4:	31850513          	addi	a0,a0,792 # 2b08 <enable_deadlock_detect+0x166>
    17f8:	cabff0ef          	jal	ra,14a2 <printf>
    17fc:	557d                	li	a0,-1
    17fe:	707000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    1802:	000a2603          	lw	a2,0(s4)
    1806:	de41                	beqz	a2,179e <printf+0x2fc>
    1808:	b775                	j	17b4 <printf+0x312>
		mutex_lock(buffer_lock);
    180a:	10ca2503          	lw	a0,268(s4)
    180e:	134010ef          	jal	ra,2942 <mutex_lock>
		buffer[buffer_len++] = c;
    1812:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1816:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    181a:	0017861b          	addiw	a2,a5,1
    181e:	97d2                	add	a5,a5,s4
    1820:	00ca2023          	sw	a2,0(s4)
    1824:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1828:	02c6d163          	bge	a3,a2,184a <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    182c:	10000793          	li	a5,256
    1830:	02f61263          	bne	a2,a5,1854 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1834:	00001597          	auipc	a1,0x1
    1838:	38c58593          	addi	a1,a1,908 # 2bc0 <buffer>
    183c:	4505                	li	a0,1
    183e:	68d000ef          	jal	ra,26ca <write>
	buffer_len = 0;
    1842:	00001797          	auipc	a5,0x1
    1846:	3607ab23          	sw	zero,886(a5) # 2bb8 <buffer_len>
		mutex_unlock(buffer_lock);
    184a:	10ca2503          	lw	a0,268(s4)
    184e:	100010ef          	jal	ra,294e <mutex_unlock>
    1852:	bdd9                	j	1728 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1854:	681000ef          	jal	ra,26d4 <getpid>
    1858:	842a                	mv	s0,a0
    185a:	00001517          	auipc	a0,0x1
    185e:	26e50513          	addi	a0,a0,622 # 2ac8 <enable_deadlock_detect+0x126>
    1862:	549000ef          	jal	ra,25aa <basename>
    1866:	872a                	mv	a4,a0
    1868:	00001617          	auipc	a2,0x1
    186c:	19860613          	addi	a2,a2,408 # 2a00 <enable_deadlock_detect+0x5e>
    1870:	05400793          	li	a5,84
    1874:	86a2                	mv	a3,s0
    1876:	45fd                	li	a1,31
    1878:	00001517          	auipc	a0,0x1
    187c:	29050513          	addi	a0,a0,656 # 2b08 <enable_deadlock_detect+0x166>
    1880:	c23ff0ef          	jal	ra,14a2 <printf>
    1884:	557d                	li	a0,-1
    1886:	67f000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    188a:	000a2603          	lw	a2,0(s4)
    188e:	de55                	beqz	a2,184a <printf+0x3a8>
    1890:	b755                	j	1834 <printf+0x392>
		mutex_lock(buffer_lock);
    1892:	10ca2503          	lw	a0,268(s4)
    1896:	e42e                	sd	a1,8(sp)
		s += 2;
    1898:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    189c:	0a6010ef          	jal	ra,2942 <mutex_lock>
		len = out_unlocked(s, l);
    18a0:	65a2                	ld	a1,8(sp)
    18a2:	8522                	mv	a0,s0
    18a4:	08a000ef          	jal	ra,192e <out_unlocked>
		mutex_unlock(buffer_lock);
    18a8:	10ca2503          	lw	a0,268(s4)
    18ac:	0a2010ef          	jal	ra,294e <mutex_unlock>
		s += 2;
    18b0:	bb55                	j	1664 <printf+0x1c2>
				a = "(null)";
    18b2:	00001417          	auipc	s0,0x1
    18b6:	20e40413          	addi	s0,s0,526 # 2ac0 <enable_deadlock_detect+0x11e>
    18ba:	bd2d                	j	16f4 <printf+0x252>

00000000000018bc <enable_thread_io_buffer>:
{
    18bc:	1101                	addi	sp,sp,-32
    18be:	e822                	sd	s0,16(sp)
    18c0:	ec06                	sd	ra,24(sp)
    18c2:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18c4:	00001417          	auipc	s0,0x1
    18c8:	2f440413          	addi	s0,s0,756 # 2bb8 <buffer_len>
    18cc:	05a010ef          	jal	ra,2926 <mutex_create>
    18d0:	10a42623          	sw	a0,268(s0)
    18d4:	00054a63          	bltz	a0,18e8 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18d8:	4785                	li	a5,1
}
    18da:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18dc:	10f42423          	sw	a5,264(s0)
}
    18e0:	6442                	ld	s0,16(sp)
    18e2:	64a2                	ld	s1,8(sp)
    18e4:	6105                	addi	sp,sp,32
    18e6:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18e8:	5ed000ef          	jal	ra,26d4 <getpid>
    18ec:	84aa                	mv	s1,a0
    18ee:	00001517          	auipc	a0,0x1
    18f2:	1da50513          	addi	a0,a0,474 # 2ac8 <enable_deadlock_detect+0x126>
    18f6:	4b5000ef          	jal	ra,25aa <basename>
    18fa:	872a                	mv	a4,a0
    18fc:	04800793          	li	a5,72
    1900:	86a6                	mv	a3,s1
    1902:	00001517          	auipc	a0,0x1
    1906:	24650513          	addi	a0,a0,582 # 2b48 <enable_deadlock_detect+0x1a6>
    190a:	00001617          	auipc	a2,0x1
    190e:	0f660613          	addi	a2,a2,246 # 2a00 <enable_deadlock_detect+0x5e>
    1912:	45fd                	li	a1,31
    1914:	b8fff0ef          	jal	ra,14a2 <printf>
    1918:	557d                	li	a0,-1
    191a:	5eb000ef          	jal	ra,2704 <exit>
	buffer_lock_enabled = 1;
    191e:	4785                	li	a5,1
}
    1920:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1922:	10f42423          	sw	a5,264(s0)
}
    1926:	6442                	ld	s0,16(sp)
    1928:	64a2                	ld	s1,8(sp)
    192a:	6105                	addi	sp,sp,32
    192c:	8082                	ret

000000000000192e <out_unlocked>:
{
    192e:	7159                	addi	sp,sp,-112
    1930:	f486                	sd	ra,104(sp)
    1932:	f0a2                	sd	s0,96(sp)
    1934:	eca6                	sd	s1,88(sp)
    1936:	e8ca                	sd	s2,80(sp)
    1938:	e4ce                	sd	s3,72(sp)
    193a:	e0d2                	sd	s4,64(sp)
    193c:	fc56                	sd	s5,56(sp)
    193e:	f85a                	sd	s6,48(sp)
    1940:	f45e                	sd	s7,40(sp)
    1942:	f062                	sd	s8,32(sp)
    1944:	ec66                	sd	s9,24(sp)
    1946:	e86a                	sd	s10,16(sp)
    1948:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    194a:	0e058663          	beqz	a1,1a36 <out_unlocked+0x108>
    194e:	842a                	mv	s0,a0
    1950:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1954:	4981                	li	s3,0
    1956:	00001d17          	auipc	s10,0x1
    195a:	262d0d13          	addi	s10,s10,610 # 2bb8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    195e:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1962:	00001b17          	auipc	s6,0x1
    1966:	25eb0b13          	addi	s6,s6,606 # 2bc0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    196a:	10000a93          	li	s5,256
    196e:	00001c97          	auipc	s9,0x1
    1972:	15ac8c93          	addi	s9,s9,346 # 2ac8 <enable_deadlock_detect+0x126>
    1976:	00001c17          	auipc	s8,0x1
    197a:	08ac0c13          	addi	s8,s8,138 # 2a00 <enable_deadlock_detect+0x5e>
    197e:	00001b97          	auipc	s7,0x1
    1982:	18ab8b93          	addi	s7,s7,394 # 2b08 <enable_deadlock_detect+0x166>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1986:	4a29                	li	s4,10
    1988:	a031                	j	1994 <out_unlocked+0x66>
    198a:	09468863          	beq	a3,s4,1a1a <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    198e:	0405                	addi	s0,s0,1
    1990:	04848163          	beq	s1,s0,19d2 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1994:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1998:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    199c:	0017861b          	addiw	a2,a5,1
    19a0:	97ea                	add	a5,a5,s10
    19a2:	00cd2023          	sw	a2,0(s10)
    19a6:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19aa:	fec950e3          	bge	s2,a2,198a <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    19ae:	05561263          	bne	a2,s5,19f2 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    19b2:	85da                	mv	a1,s6
    19b4:	4505                	li	a0,1
    19b6:	515000ef          	jal	ra,26ca <write>
    19ba:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19bc:	00001797          	auipc	a5,0x1
    19c0:	1e07ae23          	sw	zero,508(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    19c4:	06054763          	bltz	a0,1a32 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19c8:	0405                	addi	s0,s0,1
			ret += r;
    19ca:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19ce:	fc8493e3          	bne	s1,s0,1994 <out_unlocked+0x66>
}
    19d2:	70a6                	ld	ra,104(sp)
    19d4:	7406                	ld	s0,96(sp)
    19d6:	64e6                	ld	s1,88(sp)
    19d8:	6946                	ld	s2,80(sp)
    19da:	6a06                	ld	s4,64(sp)
    19dc:	7ae2                	ld	s5,56(sp)
    19de:	7b42                	ld	s6,48(sp)
    19e0:	7ba2                	ld	s7,40(sp)
    19e2:	7c02                	ld	s8,32(sp)
    19e4:	6ce2                	ld	s9,24(sp)
    19e6:	6d42                	ld	s10,16(sp)
    19e8:	6da2                	ld	s11,8(sp)
    19ea:	854e                	mv	a0,s3
    19ec:	69a6                	ld	s3,72(sp)
    19ee:	6165                	addi	sp,sp,112
    19f0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19f2:	4e3000ef          	jal	ra,26d4 <getpid>
    19f6:	8daa                	mv	s11,a0
    19f8:	8566                	mv	a0,s9
    19fa:	3b1000ef          	jal	ra,25aa <basename>
    19fe:	872a                	mv	a4,a0
    1a00:	8662                	mv	a2,s8
    1a02:	05400793          	li	a5,84
    1a06:	86ee                	mv	a3,s11
    1a08:	45fd                	li	a1,31
    1a0a:	855e                	mv	a0,s7
    1a0c:	a97ff0ef          	jal	ra,14a2 <printf>
    1a10:	557d                	li	a0,-1
    1a12:	4f3000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    1a16:	000d2603          	lw	a2,0(s10)
    1a1a:	da35                	beqz	a2,198e <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a1c:	85da                	mv	a1,s6
    1a1e:	4505                	li	a0,1
    1a20:	4ab000ef          	jal	ra,26ca <write>
    1a24:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a26:	00001797          	auipc	a5,0x1
    1a2a:	1807a923          	sw	zero,402(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1a2e:	f8055de3          	bgez	a0,19c8 <out_unlocked+0x9a>
    1a32:	89aa                	mv	s3,a0
    1a34:	bf79                	j	19d2 <out_unlocked+0xa4>
	int ret = 0;
    1a36:	4981                	li	s3,0
    1a38:	bf69                	j	19d2 <out_unlocked+0xa4>

0000000000001a3a <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a3a:	1101                	addi	sp,sp,-32
    1a3c:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a3e:	00001497          	auipc	s1,0x1
    1a42:	17a48493          	addi	s1,s1,378 # 2bb8 <buffer_len>
    1a46:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a48:	ec06                	sd	ra,24(sp)
    1a4a:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a4c:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a50:	0017861b          	addiw	a2,a5,1
    1a54:	97a6                	add	a5,a5,s1
    1a56:	00e78423          	sb	a4,8(a5)
    1a5a:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a5c:	0ff00793          	li	a5,255
    1a60:	00c7cc63          	blt	a5,a2,1a78 <out_unlocked.constprop.0+0x3e>
    1a64:	47a9                	li	a5,10
    1a66:	06f70c63          	beq	a4,a5,1ade <out_unlocked.constprop.0+0xa4>
    1a6a:	4601                	li	a2,0
}
    1a6c:	60e2                	ld	ra,24(sp)
    1a6e:	6442                	ld	s0,16(sp)
    1a70:	64a2                	ld	s1,8(sp)
    1a72:	8532                	mv	a0,a2
    1a74:	6105                	addi	sp,sp,32
    1a76:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a78:	10000793          	li	a5,256
    1a7c:	02f61563          	bne	a2,a5,1aa6 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a80:	00001597          	auipc	a1,0x1
    1a84:	14058593          	addi	a1,a1,320 # 2bc0 <buffer>
    1a88:	4505                	li	a0,1
    1a8a:	441000ef          	jal	ra,26ca <write>
}
    1a8e:	60e2                	ld	ra,24(sp)
    1a90:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a92:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a96:	00001797          	auipc	a5,0x1
    1a9a:	1207a123          	sw	zero,290(a5) # 2bb8 <buffer_len>
}
    1a9e:	64a2                	ld	s1,8(sp)
    1aa0:	8532                	mv	a0,a2
    1aa2:	6105                	addi	sp,sp,32
    1aa4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1aa6:	42f000ef          	jal	ra,26d4 <getpid>
    1aaa:	842a                	mv	s0,a0
    1aac:	00001517          	auipc	a0,0x1
    1ab0:	01c50513          	addi	a0,a0,28 # 2ac8 <enable_deadlock_detect+0x126>
    1ab4:	2f7000ef          	jal	ra,25aa <basename>
    1ab8:	872a                	mv	a4,a0
    1aba:	00001617          	auipc	a2,0x1
    1abe:	f4660613          	addi	a2,a2,-186 # 2a00 <enable_deadlock_detect+0x5e>
    1ac2:	05400793          	li	a5,84
    1ac6:	86a2                	mv	a3,s0
    1ac8:	45fd                	li	a1,31
    1aca:	00001517          	auipc	a0,0x1
    1ace:	03e50513          	addi	a0,a0,62 # 2b08 <enable_deadlock_detect+0x166>
    1ad2:	9d1ff0ef          	jal	ra,14a2 <printf>
    1ad6:	557d                	li	a0,-1
    1ad8:	42d000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    1adc:	4090                	lw	a2,0(s1)
    1ade:	d659                	beqz	a2,1a6c <out_unlocked.constprop.0+0x32>
    1ae0:	b745                	j	1a80 <out_unlocked.constprop.0+0x46>

0000000000001ae2 <putchar>:
{
    1ae2:	7139                	addi	sp,sp,-64
    1ae4:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ae6:	00001497          	auipc	s1,0x1
    1aea:	0d248493          	addi	s1,s1,210 # 2bb8 <buffer_len>
    1aee:	1084a703          	lw	a4,264(s1)
{
    1af2:	f822                	sd	s0,48(sp)
	char byte = c;
    1af4:	0ff57413          	zext.b	s0,a0
{
    1af8:	fc06                	sd	ra,56(sp)
	char byte = c;
    1afa:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1afe:	4785                	li	a5,1
    1b00:	00f70d63          	beq	a4,a5,1b1a <putchar+0x38>
		len = out_unlocked(s, l);
    1b04:	01f10513          	addi	a0,sp,31
    1b08:	f33ff0ef          	jal	ra,1a3a <out_unlocked.constprop.0>
}
    1b0c:	70e2                	ld	ra,56(sp)
    1b0e:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1b10:	862a                	mv	a2,a0
}
    1b12:	74a2                	ld	s1,40(sp)
    1b14:	8532                	mv	a0,a2
    1b16:	6121                	addi	sp,sp,64
    1b18:	8082                	ret
		mutex_lock(buffer_lock);
    1b1a:	10c4a503          	lw	a0,268(s1)
    1b1e:	625000ef          	jal	ra,2942 <mutex_lock>
		buffer[buffer_len++] = c;
    1b22:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b24:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b28:	0017861b          	addiw	a2,a5,1
    1b2c:	97a6                	add	a5,a5,s1
    1b2e:	c090                	sw	a2,0(s1)
    1b30:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b34:	02c6c263          	blt	a3,a2,1b58 <putchar+0x76>
    1b38:	47a9                	li	a5,10
    1b3a:	06f40d63          	beq	s0,a5,1bb4 <putchar+0xd2>
    1b3e:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b40:	10c4a503          	lw	a0,268(s1)
    1b44:	e432                	sd	a2,8(sp)
    1b46:	609000ef          	jal	ra,294e <mutex_unlock>
    1b4a:	6622                	ld	a2,8(sp)
}
    1b4c:	70e2                	ld	ra,56(sp)
    1b4e:	7442                	ld	s0,48(sp)
    1b50:	74a2                	ld	s1,40(sp)
    1b52:	8532                	mv	a0,a2
    1b54:	6121                	addi	sp,sp,64
    1b56:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b58:	10000793          	li	a5,256
    1b5c:	02f61063          	bne	a2,a5,1b7c <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b60:	00001597          	auipc	a1,0x1
    1b64:	06058593          	addi	a1,a1,96 # 2bc0 <buffer>
    1b68:	4505                	li	a0,1
    1b6a:	361000ef          	jal	ra,26ca <write>
    1b6e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b72:	00001797          	auipc	a5,0x1
    1b76:	0407a323          	sw	zero,70(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1b7a:	b7d9                	j	1b40 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b7c:	359000ef          	jal	ra,26d4 <getpid>
    1b80:	842a                	mv	s0,a0
    1b82:	00001517          	auipc	a0,0x1
    1b86:	f4650513          	addi	a0,a0,-186 # 2ac8 <enable_deadlock_detect+0x126>
    1b8a:	221000ef          	jal	ra,25aa <basename>
    1b8e:	872a                	mv	a4,a0
    1b90:	00001617          	auipc	a2,0x1
    1b94:	e7060613          	addi	a2,a2,-400 # 2a00 <enable_deadlock_detect+0x5e>
    1b98:	05400793          	li	a5,84
    1b9c:	86a2                	mv	a3,s0
    1b9e:	45fd                	li	a1,31
    1ba0:	00001517          	auipc	a0,0x1
    1ba4:	f6850513          	addi	a0,a0,-152 # 2b08 <enable_deadlock_detect+0x166>
    1ba8:	8fbff0ef          	jal	ra,14a2 <printf>
    1bac:	557d                	li	a0,-1
    1bae:	357000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    1bb2:	4090                	lw	a2,0(s1)
    1bb4:	d651                	beqz	a2,1b40 <putchar+0x5e>
    1bb6:	b76d                	j	1b60 <putchar+0x7e>

0000000000001bb8 <puts>:
{
    1bb8:	7139                	addi	sp,sp,-64
    1bba:	f822                	sd	s0,48(sp)
    1bbc:	f426                	sd	s1,40(sp)
    1bbe:	fc06                	sd	ra,56(sp)
    1bc0:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1bc2:	00001417          	auipc	s0,0x1
    1bc6:	ff640413          	addi	s0,s0,-10 # 2bb8 <buffer_len>
{
    1bca:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bcc:	638000ef          	jal	ra,2204 <strlen>
	if (buffer_lock_enabled == 1) {
    1bd0:	10842703          	lw	a4,264(s0)
    1bd4:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bd6:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bd8:	04f70563          	beq	a4,a5,1c22 <puts+0x6a>
		len = out_unlocked(s, l);
    1bdc:	8526                	mv	a0,s1
    1bde:	d51ff0ef          	jal	ra,192e <out_unlocked>
    1be2:	892a                	mv	s2,a0
    1be4:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1be6:	00095963          	bgez	s2,1bf8 <puts+0x40>
}
    1bea:	70e2                	ld	ra,56(sp)
    1bec:	7442                	ld	s0,48(sp)
    1bee:	7902                	ld	s2,32(sp)
    1bf0:	8526                	mv	a0,s1
    1bf2:	74a2                	ld	s1,40(sp)
    1bf4:	6121                	addi	sp,sp,64
    1bf6:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1bf8:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bfc:	44a9                	li	s1,10
    1bfe:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1c02:	4785                	li	a5,1
    1c04:	02f70e63          	beq	a4,a5,1c40 <puts+0x88>
		len = out_unlocked(s, l);
    1c08:	01f10513          	addi	a0,sp,31
    1c0c:	e2fff0ef          	jal	ra,1a3a <out_unlocked.constprop.0>
}
    1c10:	70e2                	ld	ra,56(sp)
    1c12:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c14:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c18:	7902                	ld	s2,32(sp)
    1c1a:	8526                	mv	a0,s1
    1c1c:	74a2                	ld	s1,40(sp)
    1c1e:	6121                	addi	sp,sp,64
    1c20:	8082                	ret
		mutex_lock(buffer_lock);
    1c22:	e42a                	sd	a0,8(sp)
    1c24:	10c42503          	lw	a0,268(s0)
    1c28:	51b000ef          	jal	ra,2942 <mutex_lock>
		len = out_unlocked(s, l);
    1c2c:	65a2                	ld	a1,8(sp)
    1c2e:	8526                	mv	a0,s1
    1c30:	cffff0ef          	jal	ra,192e <out_unlocked>
    1c34:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c36:	10c42503          	lw	a0,268(s0)
    1c3a:	515000ef          	jal	ra,294e <mutex_unlock>
    1c3e:	b75d                	j	1be4 <puts+0x2c>
		mutex_lock(buffer_lock);
    1c40:	10c42503          	lw	a0,268(s0)
    1c44:	4ff000ef          	jal	ra,2942 <mutex_lock>
		buffer[buffer_len++] = c;
    1c48:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c4a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c4e:	0017861b          	addiw	a2,a5,1
    1c52:	97a2                	add	a5,a5,s0
    1c54:	c010                	sw	a2,0(s0)
    1c56:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c5a:	06c6dc63          	bge	a3,a2,1cd2 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c5e:	10000793          	li	a5,256
    1c62:	02f61c63          	bne	a2,a5,1c9a <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c66:	00001597          	auipc	a1,0x1
    1c6a:	f5a58593          	addi	a1,a1,-166 # 2bc0 <buffer>
    1c6e:	4505                	li	a0,1
    1c70:	25b000ef          	jal	ra,26ca <write>
			if (r < 0) {
    1c74:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c76:	00001797          	auipc	a5,0x1
    1c7a:	f407a123          	sw	zero,-190(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1c7e:	04054c63          	bltz	a0,1cd6 <puts+0x11e>
			if (r < buffer_len) {
    1c82:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c84:	10c42503          	lw	a0,268(s0)
    1c88:	4c7000ef          	jal	ra,294e <mutex_unlock>
}
    1c8c:	70e2                	ld	ra,56(sp)
    1c8e:	7442                	ld	s0,48(sp)
    1c90:	7902                	ld	s2,32(sp)
    1c92:	8526                	mv	a0,s1
    1c94:	74a2                	ld	s1,40(sp)
    1c96:	6121                	addi	sp,sp,64
    1c98:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c9a:	23b000ef          	jal	ra,26d4 <getpid>
    1c9e:	84aa                	mv	s1,a0
    1ca0:	00001517          	auipc	a0,0x1
    1ca4:	e2850513          	addi	a0,a0,-472 # 2ac8 <enable_deadlock_detect+0x126>
    1ca8:	103000ef          	jal	ra,25aa <basename>
    1cac:	872a                	mv	a4,a0
    1cae:	00001617          	auipc	a2,0x1
    1cb2:	d5260613          	addi	a2,a2,-686 # 2a00 <enable_deadlock_detect+0x5e>
    1cb6:	05400793          	li	a5,84
    1cba:	86a6                	mv	a3,s1
    1cbc:	45fd                	li	a1,31
    1cbe:	00001517          	auipc	a0,0x1
    1cc2:	e4a50513          	addi	a0,a0,-438 # 2b08 <enable_deadlock_detect+0x166>
    1cc6:	fdcff0ef          	jal	ra,14a2 <printf>
    1cca:	557d                	li	a0,-1
    1ccc:	239000ef          	jal	ra,2704 <exit>
	if (buffer_len == 0)
    1cd0:	4010                	lw	a2,0(s0)
    1cd2:	da45                	beqz	a2,1c82 <puts+0xca>
    1cd4:	bf49                	j	1c66 <puts+0xae>
    1cd6:	54fd                	li	s1,-1
    1cd8:	b775                	j	1c84 <puts+0xcc>

0000000000001cda <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cda:	715d                	addi	sp,sp,-80
    1cdc:	e486                	sd	ra,72(sp)
    1cde:	e0a2                	sd	s0,64(sp)
    1ce0:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1ce2:	14054363          	bltz	a0,1e28 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ce6:	02b577bb          	remuw	a5,a0,a1
    1cea:	00001617          	auipc	a2,0x1
    1cee:	fde60613          	addi	a2,a2,-34 # 2cc8 <digits>
	buf[16] = 0;
    1cf2:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1cf6:	0005871b          	sext.w	a4,a1
    1cfa:	1782                	slli	a5,a5,0x20
    1cfc:	9381                	srli	a5,a5,0x20
    1cfe:	97b2                	add	a5,a5,a2
    1d00:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d04:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1d08:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1d0c:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1d0e:	0eb56763          	bltu	a0,a1,1dfc <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d12:	02e877bb          	remuw	a5,a6,a4
    1d16:	1782                	slli	a5,a5,0x20
    1d18:	9381                	srli	a5,a5,0x20
    1d1a:	97b2                	add	a5,a5,a2
    1d1c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d20:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d24:	02f10323          	sb	a5,38(sp)
    1d28:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d2a:	0ce86963          	bltu	a6,a4,1dfc <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d2e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d32:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d36:	1582                	slli	a1,a1,0x20
    1d38:	9181                	srli	a1,a1,0x20
    1d3a:	95b2                	add	a1,a1,a2
    1d3c:	0005c583          	lbu	a1,0(a1)
    1d40:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d44:	0007859b          	sext.w	a1,a5
    1d48:	16e6e563          	bltu	a3,a4,1eb2 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d4c:	02e7f6bb          	remuw	a3,a5,a4
    1d50:	1682                	slli	a3,a3,0x20
    1d52:	9281                	srli	a3,a3,0x20
    1d54:	96b2                	add	a3,a3,a2
    1d56:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d5a:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d5e:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d62:	16e5e163          	bltu	a1,a4,1ec4 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d66:	02e876bb          	remuw	a3,a6,a4
    1d6a:	1682                	slli	a3,a3,0x20
    1d6c:	9281                	srli	a3,a3,0x20
    1d6e:	96b2                	add	a3,a3,a2
    1d70:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d74:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d78:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d7c:	14e86d63          	bltu	a6,a4,1ed6 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d80:	02e5f6bb          	remuw	a3,a1,a4
    1d84:	1682                	slli	a3,a3,0x20
    1d86:	9281                	srli	a3,a3,0x20
    1d88:	96b2                	add	a3,a3,a2
    1d8a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d8e:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d92:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d96:	10e5e563          	bltu	a1,a4,1ea0 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d9a:	02e876bb          	remuw	a3,a6,a4
    1d9e:	1682                	slli	a3,a3,0x20
    1da0:	9281                	srli	a3,a3,0x20
    1da2:	96b2                	add	a3,a3,a2
    1da4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1da8:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1dac:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1db0:	14e86263          	bltu	a6,a4,1ef4 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1db4:	02e5f6bb          	remuw	a3,a1,a4
    1db8:	1682                	slli	a3,a3,0x20
    1dba:	9281                	srli	a3,a3,0x20
    1dbc:	96b2                	add	a3,a3,a2
    1dbe:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dc2:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1dc6:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1dca:	14e5e463          	bltu	a1,a4,1f12 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1dce:	02e876bb          	remuw	a3,a6,a4
    1dd2:	1682                	slli	a3,a3,0x20
    1dd4:	9281                	srli	a3,a3,0x20
    1dd6:	96b2                	add	a3,a3,a2
    1dd8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ddc:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1de0:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1de4:	14e86063          	bltu	a6,a4,1f24 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1de8:	1782                	slli	a5,a5,0x20
    1dea:	9381                	srli	a5,a5,0x20
    1dec:	97b2                	add	a5,a5,a2
    1dee:	0007c703          	lbu	a4,0(a5)
    1df2:	4799                	li	a5,6
    1df4:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1df8:	10054763          	bltz	a0,1f06 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1dfc:	00001497          	auipc	s1,0x1
    1e00:	dbc48493          	addi	s1,s1,-580 # 2bb8 <buffer_len>
    1e04:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1e08:	0828                	addi	a0,sp,24
    1e0a:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1e0c:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1e0e:	00f50433          	add	s0,a0,a5
    1e12:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1e14:	06e68463          	beq	a3,a4,1e7c <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e18:	8522                	mv	a0,s0
    1e1a:	b15ff0ef          	jal	ra,192e <out_unlocked>
}
    1e1e:	60a6                	ld	ra,72(sp)
    1e20:	6406                	ld	s0,64(sp)
    1e22:	74e2                	ld	s1,56(sp)
    1e24:	6161                	addi	sp,sp,80
    1e26:	8082                	ret
		x = -xx;
    1e28:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e2c:	02b877bb          	remuw	a5,a6,a1
    1e30:	00001617          	auipc	a2,0x1
    1e34:	e9860613          	addi	a2,a2,-360 # 2cc8 <digits>
	buf[16] = 0;
    1e38:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e3c:	0005871b          	sext.w	a4,a1
    1e40:	1782                	slli	a5,a5,0x20
    1e42:	9381                	srli	a5,a5,0x20
    1e44:	97b2                	add	a5,a5,a2
    1e46:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e4a:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e4e:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e52:	08b86b63          	bltu	a6,a1,1ee8 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e56:	02e8f7bb          	remuw	a5,a7,a4
    1e5a:	1782                	slli	a5,a5,0x20
    1e5c:	9381                	srli	a5,a5,0x20
    1e5e:	97b2                	add	a5,a5,a2
    1e60:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e64:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e68:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e6c:	ece8f1e3          	bgeu	a7,a4,1d2e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e70:	02d00793          	li	a5,45
    1e74:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e78:	47b5                	li	a5,13
    1e7a:	b749                	j	1dfc <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e7c:	10c4a503          	lw	a0,268(s1)
    1e80:	e42e                	sd	a1,8(sp)
    1e82:	2c1000ef          	jal	ra,2942 <mutex_lock>
		len = out_unlocked(s, l);
    1e86:	65a2                	ld	a1,8(sp)
    1e88:	8522                	mv	a0,s0
    1e8a:	aa5ff0ef          	jal	ra,192e <out_unlocked>
		mutex_unlock(buffer_lock);
    1e8e:	10c4a503          	lw	a0,268(s1)
    1e92:	2bd000ef          	jal	ra,294e <mutex_unlock>
}
    1e96:	60a6                	ld	ra,72(sp)
    1e98:	6406                	ld	s0,64(sp)
    1e9a:	74e2                	ld	s1,56(sp)
    1e9c:	6161                	addi	sp,sp,80
    1e9e:	8082                	ret
		buf[i--] = digits[x % base];
    1ea0:	47a9                	li	a5,10
	if (sign)
    1ea2:	f4055de3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea6:	02d00793          	li	a5,45
    1eaa:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1eae:	47a5                	li	a5,9
    1eb0:	b7b1                	j	1dfc <printint.constprop.0+0x122>
    1eb2:	47b5                	li	a5,13
	if (sign)
    1eb4:	f40554e3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb8:	02d00793          	li	a5,45
    1ebc:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1ec0:	47b1                	li	a5,12
    1ec2:	bf2d                	j	1dfc <printint.constprop.0+0x122>
    1ec4:	47b1                	li	a5,12
	if (sign)
    1ec6:	f2055be3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eca:	02d00793          	li	a5,45
    1ece:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ed2:	47ad                	li	a5,11
    1ed4:	b725                	j	1dfc <printint.constprop.0+0x122>
    1ed6:	47ad                	li	a5,11
	if (sign)
    1ed8:	f20552e3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1edc:	02d00793          	li	a5,45
    1ee0:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ee4:	47a9                	li	a5,10
    1ee6:	bf19                	j	1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee8:	02d00793          	li	a5,45
    1eec:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ef0:	47b9                	li	a5,14
    1ef2:	b729                	j	1dfc <printint.constprop.0+0x122>
    1ef4:	47a5                	li	a5,9
	if (sign)
    1ef6:	f00553e3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1efa:	02d00793          	li	a5,45
    1efe:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1f02:	47a1                	li	a5,8
    1f04:	bde5                	j	1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f06:	02d00793          	li	a5,45
    1f0a:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1f0e:	4795                	li	a5,5
    1f10:	b5f5                	j	1dfc <printint.constprop.0+0x122>
    1f12:	47a1                	li	a5,8
	if (sign)
    1f14:	ee0554e3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f18:	02d00793          	li	a5,45
    1f1c:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f20:	479d                	li	a5,7
    1f22:	bde9                	j	1dfc <printint.constprop.0+0x122>
    1f24:	479d                	li	a5,7
	if (sign)
    1f26:	ec055be3          	bgez	a0,1dfc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f2a:	02d00793          	li	a5,45
    1f2e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f32:	4799                	li	a5,6
    1f34:	b5e1                	j	1dfc <printint.constprop.0+0x122>

0000000000001f36 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f36:	02000793          	li	a5,32
    1f3a:	00f50663          	beq	a0,a5,1f46 <isspace+0x10>
    1f3e:	355d                	addiw	a0,a0,-9
    1f40:	00553513          	sltiu	a0,a0,5
    1f44:	8082                	ret
    1f46:	4505                	li	a0,1
}
    1f48:	8082                	ret

0000000000001f4a <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f4a:	fd05051b          	addiw	a0,a0,-48
}
    1f4e:	00a53513          	sltiu	a0,a0,10
    1f52:	8082                	ret

0000000000001f54 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f54:	02000613          	li	a2,32
    1f58:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f5a:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f5e:	ff77869b          	addiw	a3,a5,-9
    1f62:	04c78c63          	beq	a5,a2,1fba <atoi+0x66>
    1f66:	0007871b          	sext.w	a4,a5
    1f6a:	04d5f863          	bgeu	a1,a3,1fba <atoi+0x66>
		s++;
	switch (*s) {
    1f6e:	02b00693          	li	a3,43
    1f72:	04d78963          	beq	a5,a3,1fc4 <atoi+0x70>
    1f76:	02d00693          	li	a3,45
    1f7a:	06d78263          	beq	a5,a3,1fde <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f7e:	fd07061b          	addiw	a2,a4,-48
    1f82:	47a5                	li	a5,9
    1f84:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f86:	4e01                	li	t3,0
	while (isdigit(*s))
    1f88:	04c7e963          	bltu	a5,a2,1fda <atoi+0x86>
	int n = 0, neg = 0;
    1f8c:	4501                	li	a0,0
	while (isdigit(*s))
    1f8e:	4825                	li	a6,9
    1f90:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f94:	0025179b          	slliw	a5,a0,0x2
    1f98:	9fa9                	addw	a5,a5,a0
    1f9a:	fd07031b          	addiw	t1,a4,-48
    1f9e:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1fa2:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1fa6:	0685                	addi	a3,a3,1
    1fa8:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1fac:	0006071b          	sext.w	a4,a2
    1fb0:	feb870e3          	bgeu	a6,a1,1f90 <atoi+0x3c>
	return neg ? n : -n;
    1fb4:	000e0563          	beqz	t3,1fbe <atoi+0x6a>
}
    1fb8:	8082                	ret
		s++;
    1fba:	0505                	addi	a0,a0,1
    1fbc:	bf79                	j	1f5a <atoi+0x6>
	return neg ? n : -n;
    1fbe:	4113053b          	subw	a0,t1,a7
    1fc2:	8082                	ret
	while (isdigit(*s))
    1fc4:	00154703          	lbu	a4,1(a0)
    1fc8:	47a5                	li	a5,9
		s++;
    1fca:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fce:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fd2:	4e01                	li	t3,0
	while (isdigit(*s))
    1fd4:	2701                	sext.w	a4,a4
    1fd6:	fac7fbe3          	bgeu	a5,a2,1f8c <atoi+0x38>
    1fda:	4501                	li	a0,0
}
    1fdc:	8082                	ret
	while (isdigit(*s))
    1fde:	00154703          	lbu	a4,1(a0)
    1fe2:	47a5                	li	a5,9
		s++;
    1fe4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fe8:	fd07061b          	addiw	a2,a4,-48
    1fec:	2701                	sext.w	a4,a4
    1fee:	fec7e6e3          	bltu	a5,a2,1fda <atoi+0x86>
		neg = 1;
    1ff2:	4e05                	li	t3,1
    1ff4:	bf61                	j	1f8c <atoi+0x38>

0000000000001ff6 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ff6:	16060d63          	beqz	a2,2170 <memset+0x17a>
    1ffa:	40a007b3          	neg	a5,a0
    1ffe:	8b9d                	andi	a5,a5,7
    2000:	00778693          	addi	a3,a5,7
    2004:	482d                	li	a6,11
    2006:	0ff5f713          	zext.b	a4,a1
    200a:	fff60593          	addi	a1,a2,-1
    200e:	1706e263          	bltu	a3,a6,2172 <memset+0x17c>
    2012:	16d5ea63          	bltu	a1,a3,2186 <memset+0x190>
    2016:	16078563          	beqz	a5,2180 <memset+0x18a>
    201a:	00e50023          	sb	a4,0(a0)
    201e:	4685                	li	a3,1
    2020:	00150593          	addi	a1,a0,1
    2024:	14d78c63          	beq	a5,a3,217c <memset+0x186>
    2028:	00e500a3          	sb	a4,1(a0)
    202c:	4689                	li	a3,2
    202e:	00250593          	addi	a1,a0,2
    2032:	14d78d63          	beq	a5,a3,218c <memset+0x196>
    2036:	00e50123          	sb	a4,2(a0)
    203a:	468d                	li	a3,3
    203c:	00350593          	addi	a1,a0,3
    2040:	12d78b63          	beq	a5,a3,2176 <memset+0x180>
    2044:	00e501a3          	sb	a4,3(a0)
    2048:	4691                	li	a3,4
    204a:	00450593          	addi	a1,a0,4
    204e:	14d78163          	beq	a5,a3,2190 <memset+0x19a>
    2052:	00e50223          	sb	a4,4(a0)
    2056:	4695                	li	a3,5
    2058:	00550593          	addi	a1,a0,5
    205c:	12d78c63          	beq	a5,a3,2194 <memset+0x19e>
    2060:	00e502a3          	sb	a4,5(a0)
    2064:	469d                	li	a3,7
    2066:	00650593          	addi	a1,a0,6
    206a:	12d79763          	bne	a5,a3,2198 <memset+0x1a2>
    206e:	00750593          	addi	a1,a0,7
    2072:	00e50323          	sb	a4,6(a0)
    2076:	481d                	li	a6,7
    2078:	00871693          	slli	a3,a4,0x8
    207c:	01071893          	slli	a7,a4,0x10
    2080:	8ed9                	or	a3,a3,a4
    2082:	01871313          	slli	t1,a4,0x18
    2086:	0116e6b3          	or	a3,a3,a7
    208a:	0066e6b3          	or	a3,a3,t1
    208e:	02071893          	slli	a7,a4,0x20
    2092:	02871e13          	slli	t3,a4,0x28
    2096:	0116e6b3          	or	a3,a3,a7
    209a:	40f60333          	sub	t1,a2,a5
    209e:	03071893          	slli	a7,a4,0x30
    20a2:	01c6e6b3          	or	a3,a3,t3
    20a6:	0116e6b3          	or	a3,a3,a7
    20aa:	03871e13          	slli	t3,a4,0x38
    20ae:	97aa                	add	a5,a5,a0
    20b0:	ff837893          	andi	a7,t1,-8
    20b4:	01c6e6b3          	or	a3,a3,t3
    20b8:	98be                	add	a7,a7,a5
    20ba:	e394                	sd	a3,0(a5)
    20bc:	07a1                	addi	a5,a5,8
    20be:	ff179ee3          	bne	a5,a7,20ba <memset+0xc4>
    20c2:	ff837893          	andi	a7,t1,-8
    20c6:	011587b3          	add	a5,a1,a7
    20ca:	010886bb          	addw	a3,a7,a6
    20ce:	0b130663          	beq	t1,a7,217a <memset+0x184>
    20d2:	00e78023          	sb	a4,0(a5)
    20d6:	0016859b          	addiw	a1,a3,1
    20da:	08c5fb63          	bgeu	a1,a2,2170 <memset+0x17a>
    20de:	00e780a3          	sb	a4,1(a5)
    20e2:	0026859b          	addiw	a1,a3,2
    20e6:	08c5f563          	bgeu	a1,a2,2170 <memset+0x17a>
    20ea:	00e78123          	sb	a4,2(a5)
    20ee:	0036859b          	addiw	a1,a3,3
    20f2:	06c5ff63          	bgeu	a1,a2,2170 <memset+0x17a>
    20f6:	00e781a3          	sb	a4,3(a5)
    20fa:	0046859b          	addiw	a1,a3,4
    20fe:	06c5f963          	bgeu	a1,a2,2170 <memset+0x17a>
    2102:	00e78223          	sb	a4,4(a5)
    2106:	0056859b          	addiw	a1,a3,5
    210a:	06c5f363          	bgeu	a1,a2,2170 <memset+0x17a>
    210e:	00e782a3          	sb	a4,5(a5)
    2112:	0066859b          	addiw	a1,a3,6
    2116:	04c5fd63          	bgeu	a1,a2,2170 <memset+0x17a>
    211a:	00e78323          	sb	a4,6(a5)
    211e:	0076859b          	addiw	a1,a3,7
    2122:	04c5f763          	bgeu	a1,a2,2170 <memset+0x17a>
    2126:	00e783a3          	sb	a4,7(a5)
    212a:	0086859b          	addiw	a1,a3,8
    212e:	04c5f163          	bgeu	a1,a2,2170 <memset+0x17a>
    2132:	00e78423          	sb	a4,8(a5)
    2136:	0096859b          	addiw	a1,a3,9
    213a:	02c5fb63          	bgeu	a1,a2,2170 <memset+0x17a>
    213e:	00e784a3          	sb	a4,9(a5)
    2142:	00a6859b          	addiw	a1,a3,10
    2146:	02c5f563          	bgeu	a1,a2,2170 <memset+0x17a>
    214a:	00e78523          	sb	a4,10(a5)
    214e:	00b6859b          	addiw	a1,a3,11
    2152:	00c5ff63          	bgeu	a1,a2,2170 <memset+0x17a>
    2156:	00e785a3          	sb	a4,11(a5)
    215a:	00c6859b          	addiw	a1,a3,12
    215e:	00c5f963          	bgeu	a1,a2,2170 <memset+0x17a>
    2162:	00e78623          	sb	a4,12(a5)
    2166:	26b5                	addiw	a3,a3,13
    2168:	00c6f463          	bgeu	a3,a2,2170 <memset+0x17a>
    216c:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2170:	8082                	ret
    2172:	46ad                	li	a3,11
    2174:	bd79                	j	2012 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2176:	480d                	li	a6,3
    2178:	b701                	j	2078 <memset+0x82>
    217a:	8082                	ret
    217c:	4805                	li	a6,1
    217e:	bded                	j	2078 <memset+0x82>
    2180:	85aa                	mv	a1,a0
    2182:	4801                	li	a6,0
    2184:	bdd5                	j	2078 <memset+0x82>
    2186:	87aa                	mv	a5,a0
    2188:	4681                	li	a3,0
    218a:	b7a1                	j	20d2 <memset+0xdc>
    218c:	4809                	li	a6,2
    218e:	b5ed                	j	2078 <memset+0x82>
    2190:	4811                	li	a6,4
    2192:	b5dd                	j	2078 <memset+0x82>
    2194:	4815                	li	a6,5
    2196:	b5cd                	j	2078 <memset+0x82>
    2198:	4819                	li	a6,6
    219a:	bdf9                	j	2078 <memset+0x82>

000000000000219c <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    219c:	00054783          	lbu	a5,0(a0)
    21a0:	0005c703          	lbu	a4,0(a1)
    21a4:	00e79863          	bne	a5,a4,21b4 <strcmp+0x18>
    21a8:	0505                	addi	a0,a0,1
    21aa:	0585                	addi	a1,a1,1
    21ac:	fbe5                	bnez	a5,219c <strcmp>
    21ae:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    21b0:	9d19                	subw	a0,a0,a4
    21b2:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    21b4:	0007851b          	sext.w	a0,a5
    21b8:	bfe5                	j	21b0 <strcmp+0x14>

00000000000021ba <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21ba:	ca15                	beqz	a2,21ee <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21bc:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21c0:	167d                	addi	a2,a2,-1
    21c2:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21c6:	eb99                	bnez	a5,21dc <strncmp+0x22>
    21c8:	a815                	j	21fc <strncmp+0x42>
    21ca:	00a68e63          	beq	a3,a0,21e6 <strncmp+0x2c>
    21ce:	0505                	addi	a0,a0,1
    21d0:	00f71b63          	bne	a4,a5,21e6 <strncmp+0x2c>
    21d4:	00054783          	lbu	a5,0(a0)
    21d8:	cf89                	beqz	a5,21f2 <strncmp+0x38>
    21da:	85b2                	mv	a1,a2
    21dc:	0005c703          	lbu	a4,0(a1)
    21e0:	00158613          	addi	a2,a1,1
    21e4:	f37d                	bnez	a4,21ca <strncmp+0x10>
		;
	return *l - *r;
    21e6:	0007851b          	sext.w	a0,a5
    21ea:	9d19                	subw	a0,a0,a4
    21ec:	8082                	ret
		return 0;
    21ee:	4501                	li	a0,0
}
    21f0:	8082                	ret
	return *l - *r;
    21f2:	0015c703          	lbu	a4,1(a1)
    21f6:	4501                	li	a0,0
    21f8:	9d19                	subw	a0,a0,a4
    21fa:	8082                	ret
    21fc:	0005c703          	lbu	a4,0(a1)
    2200:	4501                	li	a0,0
    2202:	b7e5                	j	21ea <strncmp+0x30>

0000000000002204 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2204:	00757793          	andi	a5,a0,7
    2208:	cf89                	beqz	a5,2222 <strlen+0x1e>
    220a:	87aa                	mv	a5,a0
    220c:	a029                	j	2216 <strlen+0x12>
    220e:	0785                	addi	a5,a5,1
    2210:	0077f713          	andi	a4,a5,7
    2214:	cb01                	beqz	a4,2224 <strlen+0x20>
		if (!*s)
    2216:	0007c703          	lbu	a4,0(a5)
    221a:	fb75                	bnez	a4,220e <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    221c:	40a78533          	sub	a0,a5,a0
}
    2220:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2222:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2224:	6394                	ld	a3,0(a5)
    2226:	00001597          	auipc	a1,0x1
    222a:	97a5b583          	ld	a1,-1670(a1) # 2ba0 <enable_deadlock_detect+0x1fe>
    222e:	00001617          	auipc	a2,0x1
    2232:	97a63603          	ld	a2,-1670(a2) # 2ba8 <enable_deadlock_detect+0x206>
    2236:	a019                	j	223c <strlen+0x38>
    2238:	6794                	ld	a3,8(a5)
    223a:	07a1                	addi	a5,a5,8
    223c:	00b68733          	add	a4,a3,a1
    2240:	fff6c693          	not	a3,a3
    2244:	8f75                	and	a4,a4,a3
    2246:	8f71                	and	a4,a4,a2
    2248:	db65                	beqz	a4,2238 <strlen+0x34>
	for (; *s; s++)
    224a:	0007c703          	lbu	a4,0(a5)
    224e:	d779                	beqz	a4,221c <strlen+0x18>
    2250:	0017c703          	lbu	a4,1(a5)
    2254:	0785                	addi	a5,a5,1
    2256:	d379                	beqz	a4,221c <strlen+0x18>
    2258:	0017c703          	lbu	a4,1(a5)
    225c:	0785                	addi	a5,a5,1
    225e:	fb6d                	bnez	a4,2250 <strlen+0x4c>
    2260:	bf75                	j	221c <strlen+0x18>

0000000000002262 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2262:	00757713          	andi	a4,a0,7
{
    2266:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2268:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    226c:	cb19                	beqz	a4,2282 <memchr+0x20>
    226e:	ce25                	beqz	a2,22e6 <memchr+0x84>
    2270:	0007c703          	lbu	a4,0(a5)
    2274:	04b70e63          	beq	a4,a1,22d0 <memchr+0x6e>
    2278:	0785                	addi	a5,a5,1
    227a:	0077f713          	andi	a4,a5,7
    227e:	167d                	addi	a2,a2,-1
    2280:	f77d                	bnez	a4,226e <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2282:	4501                	li	a0,0
	if (n && *s != c) {
    2284:	c235                	beqz	a2,22e8 <memchr+0x86>
    2286:	0007c703          	lbu	a4,0(a5)
    228a:	04b70363          	beq	a4,a1,22d0 <memchr+0x6e>
		size_t k = ONES * c;
    228e:	00001517          	auipc	a0,0x1
    2292:	92253503          	ld	a0,-1758(a0) # 2bb0 <enable_deadlock_detect+0x20e>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2296:	471d                	li	a4,7
		size_t k = ONES * c;
    2298:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    229c:	02c77a63          	bgeu	a4,a2,22d0 <memchr+0x6e>
    22a0:	00001897          	auipc	a7,0x1
    22a4:	9008b883          	ld	a7,-1792(a7) # 2ba0 <enable_deadlock_detect+0x1fe>
    22a8:	00001817          	auipc	a6,0x1
    22ac:	90083803          	ld	a6,-1792(a6) # 2ba8 <enable_deadlock_detect+0x206>
    22b0:	431d                	li	t1,7
    22b2:	a029                	j	22bc <memchr+0x5a>
		     w++, n -= SS)
    22b4:	1661                	addi	a2,a2,-8
    22b6:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22b8:	02c37963          	bgeu	t1,a2,22ea <memchr+0x88>
    22bc:	6398                	ld	a4,0(a5)
    22be:	8f29                	xor	a4,a4,a0
    22c0:	011706b3          	add	a3,a4,a7
    22c4:	fff74713          	not	a4,a4
    22c8:	8f75                	and	a4,a4,a3
    22ca:	01077733          	and	a4,a4,a6
    22ce:	d37d                	beqz	a4,22b4 <memchr+0x52>
{
    22d0:	853e                	mv	a0,a5
    22d2:	97b2                	add	a5,a5,a2
    22d4:	a021                	j	22dc <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22d6:	0505                	addi	a0,a0,1
    22d8:	00f50763          	beq	a0,a5,22e6 <memchr+0x84>
    22dc:	00054703          	lbu	a4,0(a0)
    22e0:	feb71be3          	bne	a4,a1,22d6 <memchr+0x74>
    22e4:	8082                	ret
	return n ? (void *)s : 0;
    22e6:	4501                	li	a0,0
}
    22e8:	8082                	ret
	return n ? (void *)s : 0;
    22ea:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22ec:	f275                	bnez	a2,22d0 <memchr+0x6e>
}
    22ee:	8082                	ret

00000000000022f0 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22f0:	1101                	addi	sp,sp,-32
    22f2:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22f4:	862e                	mv	a2,a1
{
    22f6:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22f8:	4581                	li	a1,0
{
    22fa:	e426                	sd	s1,8(sp)
    22fc:	ec06                	sd	ra,24(sp)
    22fe:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2300:	f63ff0ef          	jal	ra,2262 <memchr>
	return p ? p - s : n;
    2304:	c519                	beqz	a0,2312 <strnlen+0x22>
}
    2306:	60e2                	ld	ra,24(sp)
    2308:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    230a:	8d05                	sub	a0,a0,s1
}
    230c:	64a2                	ld	s1,8(sp)
    230e:	6105                	addi	sp,sp,32
    2310:	8082                	ret
    2312:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2314:	8522                	mv	a0,s0
}
    2316:	6442                	ld	s0,16(sp)
    2318:	64a2                	ld	s1,8(sp)
    231a:	6105                	addi	sp,sp,32
    231c:	8082                	ret

000000000000231e <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    231e:	00a5c7b3          	xor	a5,a1,a0
    2322:	8b9d                	andi	a5,a5,7
    2324:	eb95                	bnez	a5,2358 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2326:	0075f793          	andi	a5,a1,7
    232a:	e7b1                	bnez	a5,2376 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    232c:	6198                	ld	a4,0(a1)
    232e:	00001617          	auipc	a2,0x1
    2332:	87263603          	ld	a2,-1934(a2) # 2ba0 <enable_deadlock_detect+0x1fe>
    2336:	00001817          	auipc	a6,0x1
    233a:	87283803          	ld	a6,-1934(a6) # 2ba8 <enable_deadlock_detect+0x206>
    233e:	a029                	j	2348 <stpcpy+0x2a>
    2340:	05a1                	addi	a1,a1,8
    2342:	e118                	sd	a4,0(a0)
    2344:	6198                	ld	a4,0(a1)
    2346:	0521                	addi	a0,a0,8
    2348:	00c707b3          	add	a5,a4,a2
    234c:	fff74693          	not	a3,a4
    2350:	8ff5                	and	a5,a5,a3
    2352:	0107f7b3          	and	a5,a5,a6
    2356:	d7ed                	beqz	a5,2340 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2358:	0005c783          	lbu	a5,0(a1)
    235c:	00f50023          	sb	a5,0(a0)
    2360:	c785                	beqz	a5,2388 <stpcpy+0x6a>
    2362:	0015c783          	lbu	a5,1(a1)
    2366:	0505                	addi	a0,a0,1
    2368:	0585                	addi	a1,a1,1
    236a:	00f50023          	sb	a5,0(a0)
    236e:	fbf5                	bnez	a5,2362 <stpcpy+0x44>
		;
	return d;
}
    2370:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2372:	0505                	addi	a0,a0,1
    2374:	df45                	beqz	a4,232c <stpcpy+0xe>
			if (!(*d = *s))
    2376:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    237a:	0585                	addi	a1,a1,1
    237c:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2380:	00f50023          	sb	a5,0(a0)
    2384:	f7fd                	bnez	a5,2372 <stpcpy+0x54>
}
    2386:	8082                	ret
    2388:	8082                	ret

000000000000238a <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    238a:	00a5c7b3          	xor	a5,a1,a0
    238e:	8b9d                	andi	a5,a5,7
    2390:	1a079863          	bnez	a5,2540 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2394:	0075f793          	andi	a5,a1,7
    2398:	16078463          	beqz	a5,2500 <stpncpy+0x176>
    239c:	ea01                	bnez	a2,23ac <stpncpy+0x22>
    239e:	a421                	j	25a6 <stpncpy+0x21c>
    23a0:	167d                	addi	a2,a2,-1
    23a2:	0505                	addi	a0,a0,1
    23a4:	14070e63          	beqz	a4,2500 <stpncpy+0x176>
    23a8:	1a060863          	beqz	a2,2558 <stpncpy+0x1ce>
    23ac:	0005c783          	lbu	a5,0(a1)
    23b0:	0585                	addi	a1,a1,1
    23b2:	0075f713          	andi	a4,a1,7
    23b6:	00f50023          	sb	a5,0(a0)
    23ba:	f3fd                	bnez	a5,23a0 <stpncpy+0x16>
    23bc:	4805                	li	a6,1
    23be:	1a061863          	bnez	a2,256e <stpncpy+0x1e4>
    23c2:	40a007b3          	neg	a5,a0
    23c6:	8b9d                	andi	a5,a5,7
    23c8:	4681                	li	a3,0
    23ca:	18061a63          	bnez	a2,255e <stpncpy+0x1d4>
    23ce:	00778713          	addi	a4,a5,7
    23d2:	45ad                	li	a1,11
    23d4:	18b76363          	bltu	a4,a1,255a <stpncpy+0x1d0>
    23d8:	1ae6eb63          	bltu	a3,a4,258e <stpncpy+0x204>
    23dc:	1a078363          	beqz	a5,2582 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23e0:	00050023          	sb	zero,0(a0)
    23e4:	4685                	li	a3,1
    23e6:	00150713          	addi	a4,a0,1
    23ea:	18d78f63          	beq	a5,a3,2588 <stpncpy+0x1fe>
    23ee:	000500a3          	sb	zero,1(a0)
    23f2:	4689                	li	a3,2
    23f4:	00250713          	addi	a4,a0,2
    23f8:	18d78e63          	beq	a5,a3,2594 <stpncpy+0x20a>
    23fc:	00050123          	sb	zero,2(a0)
    2400:	468d                	li	a3,3
    2402:	00350713          	addi	a4,a0,3
    2406:	16d78c63          	beq	a5,a3,257e <stpncpy+0x1f4>
    240a:	000501a3          	sb	zero,3(a0)
    240e:	4691                	li	a3,4
    2410:	00450713          	addi	a4,a0,4
    2414:	18d78263          	beq	a5,a3,2598 <stpncpy+0x20e>
    2418:	00050223          	sb	zero,4(a0)
    241c:	4695                	li	a3,5
    241e:	00550713          	addi	a4,a0,5
    2422:	16d78d63          	beq	a5,a3,259c <stpncpy+0x212>
    2426:	000502a3          	sb	zero,5(a0)
    242a:	469d                	li	a3,7
    242c:	00650713          	addi	a4,a0,6
    2430:	16d79863          	bne	a5,a3,25a0 <stpncpy+0x216>
    2434:	00750713          	addi	a4,a0,7
    2438:	00050323          	sb	zero,6(a0)
    243c:	40f80833          	sub	a6,a6,a5
    2440:	ff887593          	andi	a1,a6,-8
    2444:	97aa                	add	a5,a5,a0
    2446:	95be                	add	a1,a1,a5
    2448:	0007b023          	sd	zero,0(a5)
    244c:	07a1                	addi	a5,a5,8
    244e:	feb79de3          	bne	a5,a1,2448 <stpncpy+0xbe>
    2452:	ff887593          	andi	a1,a6,-8
    2456:	9ead                	addw	a3,a3,a1
    2458:	00b707b3          	add	a5,a4,a1
    245c:	12b80863          	beq	a6,a1,258c <stpncpy+0x202>
    2460:	00078023          	sb	zero,0(a5)
    2464:	0016871b          	addiw	a4,a3,1
    2468:	0ec77863          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    246c:	000780a3          	sb	zero,1(a5)
    2470:	0026871b          	addiw	a4,a3,2
    2474:	0ec77263          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    2478:	00078123          	sb	zero,2(a5)
    247c:	0036871b          	addiw	a4,a3,3
    2480:	0cc77c63          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    2484:	000781a3          	sb	zero,3(a5)
    2488:	0046871b          	addiw	a4,a3,4
    248c:	0cc77663          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    2490:	00078223          	sb	zero,4(a5)
    2494:	0056871b          	addiw	a4,a3,5
    2498:	0cc77063          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    249c:	000782a3          	sb	zero,5(a5)
    24a0:	0066871b          	addiw	a4,a3,6
    24a4:	0ac77a63          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24a8:	00078323          	sb	zero,6(a5)
    24ac:	0076871b          	addiw	a4,a3,7
    24b0:	0ac77463          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24b4:	000783a3          	sb	zero,7(a5)
    24b8:	0086871b          	addiw	a4,a3,8
    24bc:	08c77e63          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24c0:	00078423          	sb	zero,8(a5)
    24c4:	0096871b          	addiw	a4,a3,9
    24c8:	08c77863          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24cc:	000784a3          	sb	zero,9(a5)
    24d0:	00a6871b          	addiw	a4,a3,10
    24d4:	08c77263          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24d8:	00078523          	sb	zero,10(a5)
    24dc:	00b6871b          	addiw	a4,a3,11
    24e0:	06c77c63          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24e4:	000785a3          	sb	zero,11(a5)
    24e8:	00c6871b          	addiw	a4,a3,12
    24ec:	06c77663          	bgeu	a4,a2,2558 <stpncpy+0x1ce>
    24f0:	00078623          	sb	zero,12(a5)
    24f4:	26b5                	addiw	a3,a3,13
    24f6:	06c6f163          	bgeu	a3,a2,2558 <stpncpy+0x1ce>
    24fa:	000786a3          	sb	zero,13(a5)
    24fe:	8082                	ret
			;
		if (!n || !*s)
    2500:	c645                	beqz	a2,25a8 <stpncpy+0x21e>
    2502:	0005c783          	lbu	a5,0(a1)
    2506:	ea078be3          	beqz	a5,23bc <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    250a:	479d                	li	a5,7
    250c:	02c7ff63          	bgeu	a5,a2,254a <stpncpy+0x1c0>
    2510:	00000897          	auipc	a7,0x0
    2514:	6908b883          	ld	a7,1680(a7) # 2ba0 <enable_deadlock_detect+0x1fe>
    2518:	00000817          	auipc	a6,0x0
    251c:	69083803          	ld	a6,1680(a6) # 2ba8 <enable_deadlock_detect+0x206>
    2520:	431d                	li	t1,7
    2522:	6198                	ld	a4,0(a1)
    2524:	011707b3          	add	a5,a4,a7
    2528:	fff74693          	not	a3,a4
    252c:	8ff5                	and	a5,a5,a3
    252e:	0107f7b3          	and	a5,a5,a6
    2532:	ef81                	bnez	a5,254a <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2534:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2536:	1661                	addi	a2,a2,-8
    2538:	05a1                	addi	a1,a1,8
    253a:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    253c:	fec363e3          	bltu	t1,a2,2522 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2540:	e609                	bnez	a2,254a <stpncpy+0x1c0>
    2542:	a08d                	j	25a4 <stpncpy+0x21a>
    2544:	167d                	addi	a2,a2,-1
    2546:	0505                	addi	a0,a0,1
    2548:	ca01                	beqz	a2,2558 <stpncpy+0x1ce>
    254a:	0005c783          	lbu	a5,0(a1)
    254e:	0585                	addi	a1,a1,1
    2550:	00f50023          	sb	a5,0(a0)
    2554:	fbe5                	bnez	a5,2544 <stpncpy+0x1ba>
		;
tail:
    2556:	b59d                	j	23bc <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2558:	8082                	ret
    255a:	472d                	li	a4,11
    255c:	bdb5                	j	23d8 <stpncpy+0x4e>
    255e:	00778713          	addi	a4,a5,7
    2562:	45ad                	li	a1,11
    2564:	fff60693          	addi	a3,a2,-1
    2568:	e6b778e3          	bgeu	a4,a1,23d8 <stpncpy+0x4e>
    256c:	b7fd                	j	255a <stpncpy+0x1d0>
    256e:	40a007b3          	neg	a5,a0
    2572:	8832                	mv	a6,a2
    2574:	8b9d                	andi	a5,a5,7
    2576:	4681                	li	a3,0
    2578:	e4060be3          	beqz	a2,23ce <stpncpy+0x44>
    257c:	b7cd                	j	255e <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    257e:	468d                	li	a3,3
    2580:	bd75                	j	243c <stpncpy+0xb2>
    2582:	872a                	mv	a4,a0
    2584:	4681                	li	a3,0
    2586:	bd5d                	j	243c <stpncpy+0xb2>
    2588:	4685                	li	a3,1
    258a:	bd4d                	j	243c <stpncpy+0xb2>
    258c:	8082                	ret
    258e:	87aa                	mv	a5,a0
    2590:	4681                	li	a3,0
    2592:	b5f9                	j	2460 <stpncpy+0xd6>
    2594:	4689                	li	a3,2
    2596:	b55d                	j	243c <stpncpy+0xb2>
    2598:	4691                	li	a3,4
    259a:	b54d                	j	243c <stpncpy+0xb2>
    259c:	4695                	li	a3,5
    259e:	bd79                	j	243c <stpncpy+0xb2>
    25a0:	4699                	li	a3,6
    25a2:	bd69                	j	243c <stpncpy+0xb2>
    25a4:	8082                	ret
    25a6:	8082                	ret
    25a8:	8082                	ret

00000000000025aa <basename>:

char *basename(char *s)
{
    25aa:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    25ac:	c54d                	beqz	a0,2656 <basename+0xac>
    25ae:	00054783          	lbu	a5,0(a0)
		return ".";
    25b2:	00000517          	auipc	a0,0x0
    25b6:	5e650513          	addi	a0,a0,1510 # 2b98 <enable_deadlock_detect+0x1f6>
	if (!s || !*s)
    25ba:	e391                	bnez	a5,25be <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25bc:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25be:	0076f713          	andi	a4,a3,7
    25c2:	87b6                	mv	a5,a3
    25c4:	cf51                	beqz	a4,2660 <basename+0xb6>
    25c6:	0785                	addi	a5,a5,1
    25c8:	0077f713          	andi	a4,a5,7
    25cc:	c729                	beqz	a4,2616 <basename+0x6c>
		if (!*s)
    25ce:	0007c703          	lbu	a4,0(a5)
    25d2:	fb75                	bnez	a4,25c6 <basename+0x1c>
	return s - a;
    25d4:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25d6:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25d8:	cf8d                	beqz	a5,2612 <basename+0x68>
    25da:	00f68733          	add	a4,a3,a5
    25de:	02f00593          	li	a1,47
    25e2:	a031                	j	25ee <basename+0x44>
		s[i] = 0;
    25e4:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25e8:	17fd                	addi	a5,a5,-1
    25ea:	177d                	addi	a4,a4,-1
    25ec:	c39d                	beqz	a5,2612 <basename+0x68>
    25ee:	00074603          	lbu	a2,0(a4)
    25f2:	feb609e3          	beq	a2,a1,25e4 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25f6:	02f00613          	li	a2,47
    25fa:	a011                	j	25fe <basename+0x54>
    25fc:	cb99                	beqz	a5,2612 <basename+0x68>
    25fe:	853e                	mv	a0,a5
    2600:	17fd                	addi	a5,a5,-1
    2602:	00f68733          	add	a4,a3,a5
    2606:	00074703          	lbu	a4,0(a4)
    260a:	fec719e3          	bne	a4,a2,25fc <basename+0x52>
	return s + i;
    260e:	9536                	add	a0,a0,a3
    2610:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2612:	8536                	mv	a0,a3
    2614:	8082                	ret
    2616:	6390                	ld	a2,0(a5)
    2618:	00000517          	auipc	a0,0x0
    261c:	58853503          	ld	a0,1416(a0) # 2ba0 <enable_deadlock_detect+0x1fe>
    2620:	00000597          	auipc	a1,0x0
    2624:	5885b583          	ld	a1,1416(a1) # 2ba8 <enable_deadlock_detect+0x206>
    2628:	fff64713          	not	a4,a2
    262c:	962a                	add	a2,a2,a0
    262e:	8f71                	and	a4,a4,a2
    2630:	8f6d                	and	a4,a4,a1
    2632:	eb11                	bnez	a4,2646 <basename+0x9c>
    2634:	6790                	ld	a2,8(a5)
    2636:	07a1                	addi	a5,a5,8
    2638:	00a60733          	add	a4,a2,a0
    263c:	fff64613          	not	a2,a2
    2640:	8f71                	and	a4,a4,a2
    2642:	8f6d                	and	a4,a4,a1
    2644:	db65                	beqz	a4,2634 <basename+0x8a>
	for (; *s; s++)
    2646:	0007c703          	lbu	a4,0(a5)
    264a:	d749                	beqz	a4,25d4 <basename+0x2a>
    264c:	0017c703          	lbu	a4,1(a5)
    2650:	0785                	addi	a5,a5,1
    2652:	ff6d                	bnez	a4,264c <basename+0xa2>
    2654:	b741                	j	25d4 <basename+0x2a>
		return ".";
    2656:	00000517          	auipc	a0,0x0
    265a:	54250513          	addi	a0,a0,1346 # 2b98 <enable_deadlock_detect+0x1f6>
    265e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2660:	6290                	ld	a2,0(a3)
    2662:	00000517          	auipc	a0,0x0
    2666:	53e53503          	ld	a0,1342(a0) # 2ba0 <enable_deadlock_detect+0x1fe>
    266a:	00000597          	auipc	a1,0x0
    266e:	53e5b583          	ld	a1,1342(a1) # 2ba8 <enable_deadlock_detect+0x206>
    2672:	fff64713          	not	a4,a2
    2676:	962a                	add	a2,a2,a0
    2678:	8f71                	and	a4,a4,a2
    267a:	8f6d                	and	a4,a4,a1
    267c:	df45                	beqz	a4,2634 <basename+0x8a>
    267e:	b7f9                	j	264c <basename+0xa2>

0000000000002680 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2680:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2684:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2686:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <close>:

int close(int fd)
{
	if (fd == 1) {
    268e:	4785                	li	a5,1
    2690:	00f50863          	beq	a0,a5,26a0 <close+0x12>
	register long a7 __asm__("a7") = n;
    2694:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2698:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    269c:	2501                	sext.w	a0,a0
    269e:	8082                	ret
{
    26a0:	1101                	addi	sp,sp,-32
    26a2:	ec06                	sd	ra,24(sp)
    26a4:	e42a                	sd	a0,8(sp)
		__write_buffer();
    26a6:	cdffe0ef          	jal	ra,1384 <__write_buffer>
		__clear_buffer();
    26aa:	d03fe0ef          	jal	ra,13ac <__clear_buffer>
    26ae:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    26b0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    26b4:	00000073          	ecall
}
    26b8:	60e2                	ld	ra,24(sp)
    26ba:	2501                	sext.w	a0,a0
    26bc:	6105                	addi	sp,sp,32
    26be:	8082                	ret

00000000000026c0 <read>:
	register long a7 __asm__("a7") = n;
    26c0:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26c4:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    26c8:	8082                	ret

00000000000026ca <write>:
	register long a7 __asm__("a7") = n;
    26ca:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26ce:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    26d2:	8082                	ret

00000000000026d4 <getpid>:
	register long a7 __asm__("a7") = n;
    26d4:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    26d8:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    26dc:	2501                	sext.w	a0,a0
    26de:	8082                	ret

00000000000026e0 <getppid>:
	register long a7 __asm__("a7") = n;
    26e0:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    26e4:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    26e8:	2501                	sext.w	a0,a0
    26ea:	8082                	ret

00000000000026ec <sched_yield>:
	register long a7 __asm__("a7") = n;
    26ec:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26f0:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    26f4:	2501                	sext.w	a0,a0
    26f6:	8082                	ret

00000000000026f8 <fork>:
	register long a7 __asm__("a7") = n;
    26f8:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    26fc:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2700:	2501                	sext.w	a0,a0
    2702:	8082                	ret

0000000000002704 <exit>:

void exit(int code)
{
    2704:	1141                	addi	sp,sp,-16
    2706:	e406                	sd	ra,8(sp)
    2708:	e022                	sd	s0,0(sp)
    270a:	842a                	mv	s0,a0
	__write_buffer();
    270c:	c79fe0ef          	jal	ra,1384 <__write_buffer>
	__clear_buffer();
    2710:	c9dfe0ef          	jal	ra,13ac <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2714:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2718:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    271a:	00000073          	ecall
	syscall(SYS_exit, code);
}
    271e:	60a2                	ld	ra,8(sp)
    2720:	6402                	ld	s0,0(sp)
    2722:	0141                	addi	sp,sp,16
    2724:	8082                	ret

0000000000002726 <waitpid>:
	register long a7 __asm__("a7") = n;
    2726:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    272a:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    272e:	2501                	sext.w	a0,a0
    2730:	8082                	ret

0000000000002732 <exec>:
	register long a7 __asm__("a7") = n;
    2732:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2736:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    273a:	2501                	sext.w	a0,a0
    273c:	8082                	ret

000000000000273e <get_mtime>:

int64 get_mtime()
{
    273e:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2740:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2744:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2746:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2748:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    274c:	2501                	sext.w	a0,a0
    274e:	ed01                	bnez	a0,2766 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2750:	6722                	ld	a4,8(sp)
    2752:	3e800793          	li	a5,1000
    2756:	6682                	ld	a3,0(sp)
    2758:	02f75733          	divu	a4,a4,a5
    275c:	02d78533          	mul	a0,a5,a3
    2760:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2762:	0141                	addi	sp,sp,16
    2764:	8082                	ret
	return -1;
    2766:	557d                	li	a0,-1
    2768:	bfed                	j	2762 <get_mtime+0x24>

000000000000276a <sys_get_time>:
	register long a7 __asm__("a7") = n;
    276a:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    276e:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2772:	2501                	sext.w	a0,a0
    2774:	8082                	ret

0000000000002776 <sleep>:

int sleep(unsigned long long time)
{
    2776:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2778:	880a                	mv	a6,sp
{
    277a:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    277c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2780:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2782:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2784:	00000073          	ecall
	if (err == 0) {
    2788:	2501                	sext.w	a0,a0
    278a:	ed31                	bnez	a0,27e6 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    278c:	6722                	ld	a4,8(sp)
    278e:	3e800793          	li	a5,1000
    2792:	6682                	ld	a3,0(sp)
    2794:	02f75733          	divu	a4,a4,a5
    2798:	02d787b3          	mul	a5,a5,a3
    279c:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    279e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    27a2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    27a4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27a6:	00000073          	ecall
	if (err == 0) {
    27aa:	2501                	sext.w	a0,a0
    27ac:	e915                	bnez	a0,27e0 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    27ae:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    27b0:	3e800693          	li	a3,1000
    27b4:	a819                	j	27ca <sleep+0x54>
	__asm_syscall("r"(a7))
    27b6:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    27ba:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    27be:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    27c0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27c2:	00000073          	ecall
	if (err == 0) {
    27c6:	2501                	sext.w	a0,a0
    27c8:	ed01                	bnez	a0,27e0 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    27ca:	6722                	ld	a4,8(sp)
    27cc:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    27ce:	07c00893          	li	a7,124
    27d2:	02d75733          	divu	a4,a4,a3
    27d6:	02f687b3          	mul	a5,a3,a5
    27da:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    27dc:	fcc7ede3          	bltu	a5,a2,27b6 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    27e0:	4501                	li	a0,0
    27e2:	0141                	addi	sp,sp,16
    27e4:	8082                	ret
    27e6:	57fd                	li	a5,-1
    27e8:	bf5d                	j	279e <sleep+0x28>

00000000000027ea <sys_task_info>:
	register long a7 __asm__("a7") = n;
    27ea:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    27ee:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    27f2:	2501                	sext.w	a0,a0
    27f4:	8082                	ret

00000000000027f6 <set_priority>:
	register long a7 __asm__("a7") = n;
    27f6:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    27fa:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    27fe:	2501                	sext.w	a0,a0
    2800:	8082                	ret

0000000000002802 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2802:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2806:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    280a:	2501                	sext.w	a0,a0
    280c:	8082                	ret

000000000000280e <munmap>:
	register long a7 __asm__("a7") = n;
    280e:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2812:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2816:	2501                	sext.w	a0,a0
    2818:	8082                	ret

000000000000281a <wait>:

int wait(int *code)
{
    281a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    281c:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2820:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2822:	00000073          	ecall
	return waitpid(-1, code);
}
    2826:	2501                	sext.w	a0,a0
    2828:	8082                	ret

000000000000282a <spawn>:
	register long a7 __asm__("a7") = n;
    282a:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    282e:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2832:	2501                	sext.w	a0,a0
    2834:	8082                	ret

0000000000002836 <pipe>:
	register long a7 __asm__("a7") = n;
    2836:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    283a:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    283e:	2501                	sext.w	a0,a0
    2840:	8082                	ret

0000000000002842 <mailread>:
	register long a7 __asm__("a7") = n;
    2842:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2846:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    284a:	2501                	sext.w	a0,a0
    284c:	8082                	ret

000000000000284e <mailwrite>:
	register long a7 __asm__("a7") = n;
    284e:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2852:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2856:	2501                	sext.w	a0,a0
    2858:	8082                	ret

000000000000285a <fstat>:
	register long a7 __asm__("a7") = n;
    285a:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    285e:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2862:	2501                	sext.w	a0,a0
    2864:	8082                	ret

0000000000002866 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2866:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2868:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    286c:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    286e:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2872:	2501                	sext.w	a0,a0
    2874:	8082                	ret

0000000000002876 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2876:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2878:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    287c:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    287e:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2882:	2501                	sext.w	a0,a0
    2884:	8082                	ret

0000000000002886 <link>:

int link(char *old_path, char *new_path)
{
    2886:	87aa                	mv	a5,a0
    2888:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    288a:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    288e:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2892:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2894:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2898:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    289a:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    289e:	2501                	sext.w	a0,a0
    28a0:	8082                	ret

00000000000028a2 <unlink>:

int unlink(char *path)
{
    28a2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    28a4:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    28a8:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    28ac:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    28ae:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    28b2:	2501                	sext.w	a0,a0
    28b4:	8082                	ret

00000000000028b6 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    28b6:	00000797          	auipc	a5,0x0
    28ba:	4327b783          	ld	a5,1074(a5) # 2ce8 <_GLOBAL_OFFSET_TABLE_+0x8>
    28be:	439c                	lw	a5,0(a5)
    28c0:	c799                	beqz	a5,28ce <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    28c2:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28c6:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    28ca:	2501                	sext.w	a0,a0
    28cc:	8082                	ret
{
    28ce:	1101                	addi	sp,sp,-32
    28d0:	ec06                	sd	ra,24(sp)
    28d2:	e42e                	sd	a1,8(sp)
    28d4:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    28d6:	fe7fe0ef          	jal	ra,18bc <enable_thread_io_buffer>
    28da:	65a2                	ld	a1,8(sp)
    28dc:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    28de:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28e2:	00000073          	ecall
}
    28e6:	60e2                	ld	ra,24(sp)
    28e8:	2501                	sext.w	a0,a0
    28ea:	6105                	addi	sp,sp,32
    28ec:	8082                	ret

00000000000028ee <gettid>:
	register long a7 __asm__("a7") = n;
    28ee:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    28f2:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    28f6:	2501                	sext.w	a0,a0
    28f8:	8082                	ret

00000000000028fa <waittid>:

int waittid(int tid)
{
    28fa:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    28fc:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2900:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2904:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2906:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2908:	00e51e63          	bne	a0,a4,2924 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    290c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2910:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2914:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2918:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    291a:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    291e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2920:	fee506e3          	beq	a0,a4,290c <waittid+0x12>
	}
	return ret;
}
    2924:	8082                	ret

0000000000002926 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2926:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    292a:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    292c:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2930:	2501                	sext.w	a0,a0
    2932:	8082                	ret

0000000000002934 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2934:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2938:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    293a:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    293e:	2501                	sext.w	a0,a0
    2940:	8082                	ret

0000000000002942 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2942:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2946:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    294a:	2501                	sext.w	a0,a0
    294c:	8082                	ret

000000000000294e <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    294e:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2952:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2956:	2501                	sext.w	a0,a0
    2958:	8082                	ret

000000000000295a <semaphore_create>:
	register long a7 __asm__("a7") = n;
    295a:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    295e:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2962:	2501                	sext.w	a0,a0
    2964:	8082                	ret

0000000000002966 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2966:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    296a:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    296e:	2501                	sext.w	a0,a0
    2970:	8082                	ret

0000000000002972 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2972:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2976:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    297a:	2501                	sext.w	a0,a0
    297c:	8082                	ret

000000000000297e <condvar_create>:
	register long a7 __asm__("a7") = n;
    297e:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2982:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2986:	2501                	sext.w	a0,a0
    2988:	8082                	ret

000000000000298a <condvar_signal>:
	register long a7 __asm__("a7") = n;
    298a:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    298e:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2992:	2501                	sext.w	a0,a0
    2994:	8082                	ret

0000000000002996 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2996:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    299a:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    299e:	2501                	sext.w	a0,a0
    29a0:	8082                	ret

00000000000029a2 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    29a2:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    29a6:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    29aa:	2501                	sext.w	a0,a0
    29ac:	8082                	ret
