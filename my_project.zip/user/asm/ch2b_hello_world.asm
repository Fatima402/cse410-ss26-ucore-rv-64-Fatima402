
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch2b_hello_world:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a829                	j	101a <__start_main>

0000000000001002 <main>:
/// 正确输出：
/// Hello world from user mode program!
/// Test hello_world OK!

int main()
{
    1002:	1141                	addi	sp,sp,-16
	puts("Hello world from user mode program!\nTest hello_world OK!");
    1004:	00001517          	auipc	a0,0x1
    1008:	67c50513          	addi	a0,a0,1660 # 2680 <enable_deadlock_detect+0xc>
{
    100c:	e406                	sd	ra,8(sp)
	puts("Hello world from user mode program!\nTest hello_world OK!");
    100e:	07d000ef          	jal	ra,188a <puts>
	return 0;
    1012:	60a2                	ld	ra,8(sp)
    1014:	4501                	li	a0,0
    1016:	0141                	addi	sp,sp,16
    1018:	8082                	ret

000000000000101a <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    101a:	1141                	addi	sp,sp,-16
    101c:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    101e:	fe5ff0ef          	jal	ra,1002 <main>
    1022:	3b4010ef          	jal	ra,23d6 <exit>
	return 0;
    1026:	60a2                	ld	ra,8(sp)
    1028:	4501                	li	a0,0
    102a:	0141                	addi	sp,sp,16
    102c:	8082                	ret

000000000000102e <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    102e:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1030:	4605                	li	a2,1
    1032:	00f10593          	addi	a1,sp,15
    1036:	4501                	li	a0,0
{
    1038:	ec06                	sd	ra,24(sp)
	char byte = 0;
    103a:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    103e:	354010ef          	jal	ra,2392 <read>
    1042:	4785                	li	a5,1
    1044:	00f51763          	bne	a0,a5,1052 <getchar+0x24>
		return byte;
    1048:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    104c:	60e2                	ld	ra,24(sp)
    104e:	6105                	addi	sp,sp,32
    1050:	8082                	ret
		return EOF;
    1052:	557d                	li	a0,-1
    1054:	bfe5                	j	104c <getchar+0x1e>

0000000000001056 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1056:	00001517          	auipc	a0,0x1
    105a:	76a52503          	lw	a0,1898(a0) # 27c0 <buffer_len>
    105e:	e111                	bnez	a0,1062 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1060:	8082                	ret
{
    1062:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1064:	862a                	mv	a2,a0
    1066:	00001597          	auipc	a1,0x1
    106a:	76258593          	addi	a1,a1,1890 # 27c8 <buffer>
    106e:	4505                	li	a0,1
{
    1070:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1072:	32a010ef          	jal	ra,239c <write>
}
    1076:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1078:	2501                	sext.w	a0,a0
}
    107a:	0141                	addi	sp,sp,16
    107c:	8082                	ret

000000000000107e <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    107e:	00001797          	auipc	a5,0x1
    1082:	7407a123          	sw	zero,1858(a5) # 27c0 <buffer_len>
}
    1086:	8082                	ret

0000000000001088 <__fflush>:
	if (buffer_len == 0)
    1088:	00001517          	auipc	a0,0x1
    108c:	73852503          	lw	a0,1848(a0) # 27c0 <buffer_len>
    1090:	e511                	bnez	a0,109c <__fflush+0x14>
	buffer_len = 0;
    1092:	00001797          	auipc	a5,0x1
    1096:	7207a723          	sw	zero,1838(a5) # 27c0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    109a:	8082                	ret
{
    109c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    109e:	862a                	mv	a2,a0
    10a0:	00001597          	auipc	a1,0x1
    10a4:	72858593          	addi	a1,a1,1832 # 27c8 <buffer>
    10a8:	4505                	li	a0,1
{
    10aa:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10ac:	2f0010ef          	jal	ra,239c <write>
	return r >= 0 ? 0 : r;
    10b0:	0005079b          	sext.w	a5,a0
}
    10b4:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10b6:	0017a793          	slti	a5,a5,1
    10ba:	40f007bb          	negw	a5,a5
    10be:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10c0:	00001797          	auipc	a5,0x1
    10c4:	7007a023          	sw	zero,1792(a5) # 27c0 <buffer_len>
	return r >= 0 ? 0 : r;
    10c8:	2501                	sext.w	a0,a0
}
    10ca:	0141                	addi	sp,sp,16
    10cc:	8082                	ret

00000000000010ce <fflush>:

int fflush(int fd)
{
    10ce:	1101                	addi	sp,sp,-32
    10d0:	e822                	sd	s0,16(sp)
    10d2:	ec06                	sd	ra,24(sp)
    10d4:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    10d6:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    10d8:	4401                	li	s0,0
	if (fd == 1) {
    10da:	00e50863          	beq	a0,a4,10ea <fflush+0x1c>
}
    10de:	60e2                	ld	ra,24(sp)
    10e0:	8522                	mv	a0,s0
    10e2:	6442                	ld	s0,16(sp)
    10e4:	64a2                	ld	s1,8(sp)
    10e6:	6105                	addi	sp,sp,32
    10e8:	8082                	ret
		if (buffer_lock_enabled == 1) {
    10ea:	00001497          	auipc	s1,0x1
    10ee:	6d648493          	addi	s1,s1,1750 # 27c0 <buffer_len>
    10f2:	1084a703          	lw	a4,264(s1)
    10f6:	02a70e63          	beq	a4,a0,1132 <fflush+0x64>
	if (buffer_len == 0)
    10fa:	4080                	lw	s0,0(s1)
    10fc:	c00d                	beqz	s0,111e <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    10fe:	8622                	mv	a2,s0
    1100:	00001597          	auipc	a1,0x1
    1104:	6c858593          	addi	a1,a1,1736 # 27c8 <buffer>
    1108:	294010ef          	jal	ra,239c <write>
	return r >= 0 ? 0 : r;
    110c:	0005079b          	sext.w	a5,a0
    1110:	0017a793          	slti	a5,a5,1
    1114:	40f007bb          	negw	a5,a5
    1118:	8d7d                	and	a0,a0,a5
    111a:	0005041b          	sext.w	s0,a0
}
    111e:	60e2                	ld	ra,24(sp)
    1120:	8522                	mv	a0,s0
    1122:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1124:	00001797          	auipc	a5,0x1
    1128:	6807ae23          	sw	zero,1692(a5) # 27c0 <buffer_len>
}
    112c:	64a2                	ld	s1,8(sp)
    112e:	6105                	addi	sp,sp,32
    1130:	8082                	ret
			mutex_lock(buffer_lock);
    1132:	10c4a503          	lw	a0,268(s1)
    1136:	4de010ef          	jal	ra,2614 <mutex_lock>
	if (buffer_len == 0)
    113a:	4080                	lw	s0,0(s1)
    113c:	e811                	bnez	s0,1150 <fflush+0x82>
			mutex_unlock(buffer_lock);
    113e:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1142:	00001797          	auipc	a5,0x1
    1146:	6607af23          	sw	zero,1662(a5) # 27c0 <buffer_len>
			mutex_unlock(buffer_lock);
    114a:	4d6010ef          	jal	ra,2620 <mutex_unlock>
    114e:	bf41                	j	10de <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1150:	8622                	mv	a2,s0
    1152:	00001597          	auipc	a1,0x1
    1156:	67658593          	addi	a1,a1,1654 # 27c8 <buffer>
    115a:	4505                	li	a0,1
    115c:	240010ef          	jal	ra,239c <write>
	return r >= 0 ? 0 : r;
    1160:	0005079b          	sext.w	a5,a0
    1164:	0017a793          	slti	a5,a5,1
    1168:	40f007bb          	negw	a5,a5
    116c:	8d7d                	and	a0,a0,a5
    116e:	0005041b          	sext.w	s0,a0
	return r;
    1172:	b7f1                	j	113e <fflush+0x70>

0000000000001174 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1174:	7131                	addi	sp,sp,-192
    1176:	e0da                	sd	s6,64(sp)
    1178:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    117a:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    117c:	013c                	addi	a5,sp,136
{
    117e:	f0ca                	sd	s2,96(sp)
    1180:	ecce                	sd	s3,88(sp)
    1182:	e8d2                	sd	s4,80(sp)
    1184:	e4d6                	sd	s5,72(sp)
    1186:	fc86                	sd	ra,120(sp)
    1188:	f8a2                	sd	s0,112(sp)
    118a:	f4a6                	sd	s1,104(sp)
    118c:	89aa                	mv	s3,a0
    118e:	e52e                	sd	a1,136(sp)
    1190:	e932                	sd	a2,144(sp)
    1192:	ed36                	sd	a3,152(sp)
    1194:	f13a                	sd	a4,160(sp)
    1196:	f942                	sd	a6,176(sp)
    1198:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    119a:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    119c:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11a0:	00001a17          	auipc	s4,0x1
    11a4:	620a0a13          	addi	s4,s4,1568 # 27c0 <buffer_len>
    11a8:	4a85                	li	s5,1
	buf[i++] = '0';
    11aa:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11ae:	0009c783          	lbu	a5,0(s3)
    11b2:	18078663          	beqz	a5,133e <printf+0x1ca>
    11b6:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11b8:	19278d63          	beq	a5,s2,1352 <printf+0x1de>
    11bc:	0015c783          	lbu	a5,1(a1)
    11c0:	0585                	addi	a1,a1,1
    11c2:	fbfd                	bnez	a5,11b8 <printf+0x44>
    11c4:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11c6:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    11ca:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    11ce:	1b578863          	beq	a5,s5,137e <printf+0x20a>
		len = out_unlocked(s, l);
    11d2:	85a2                	mv	a1,s0
    11d4:	854e                	mv	a0,s3
    11d6:	42a000ef          	jal	ra,1600 <out_unlocked>
		out(f, a, l);
		if (l)
    11da:	1c041063          	bnez	s0,139a <printf+0x226>
			continue;
		if (s[1] == 0)
    11de:	0014c783          	lbu	a5,1(s1)
    11e2:	14078e63          	beqz	a5,133e <printf+0x1ca>
			break;
		switch (s[1]) {
    11e6:	07300713          	li	a4,115
    11ea:	1ce78863          	beq	a5,a4,13ba <printf+0x246>
    11ee:	1af76863          	bltu	a4,a5,139e <printf+0x22a>
    11f2:	06400713          	li	a4,100
    11f6:	22e78063          	beq	a5,a4,1416 <printf+0x2a2>
    11fa:	07000713          	li	a4,112
    11fe:	1ee79563          	bne	a5,a4,13e8 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1202:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1204:	00001797          	auipc	a5,0x1
    1208:	6cc78793          	addi	a5,a5,1740 # 28d0 <digits>
	buf[i++] = '0';
    120c:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1210:	6298                	ld	a4,0(a3)
    1212:	06a1                	addi	a3,a3,8
    1214:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1216:	00471393          	slli	t2,a4,0x4
    121a:	00871293          	slli	t0,a4,0x8
    121e:	00c71f93          	slli	t6,a4,0xc
    1222:	01071f13          	slli	t5,a4,0x10
    1226:	01471e93          	slli	t4,a4,0x14
    122a:	01871e13          	slli	t3,a4,0x18
    122e:	01c71893          	slli	a7,a4,0x1c
    1232:	02471813          	slli	a6,a4,0x24
    1236:	02871513          	slli	a0,a4,0x28
    123a:	02c71593          	slli	a1,a4,0x2c
    123e:	03071613          	slli	a2,a4,0x30
    1242:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1246:	03c75413          	srli	s0,a4,0x3c
    124a:	01c7531b          	srliw	t1,a4,0x1c
    124e:	03c3d393          	srli	t2,t2,0x3c
    1252:	03c2d293          	srli	t0,t0,0x3c
    1256:	03cfdf93          	srli	t6,t6,0x3c
    125a:	03cf5f13          	srli	t5,t5,0x3c
    125e:	03cede93          	srli	t4,t4,0x3c
    1262:	03ce5e13          	srli	t3,t3,0x3c
    1266:	03c8d893          	srli	a7,a7,0x3c
    126a:	03c85813          	srli	a6,a6,0x3c
    126e:	9171                	srli	a0,a0,0x3c
    1270:	91f1                	srli	a1,a1,0x3c
    1272:	9271                	srli	a2,a2,0x3c
    1274:	92f1                	srli	a3,a3,0x3c
    1276:	95be                	add	a1,a1,a5
    1278:	963e                	add	a2,a2,a5
    127a:	96be                	add	a3,a3,a5
    127c:	943e                	add	s0,s0,a5
    127e:	93be                	add	t2,t2,a5
    1280:	92be                	add	t0,t0,a5
    1282:	9fbe                	add	t6,t6,a5
    1284:	9f3e                	add	t5,t5,a5
    1286:	9ebe                	add	t4,t4,a5
    1288:	9e3e                	add	t3,t3,a5
    128a:	98be                	add	a7,a7,a5
    128c:	933e                	add	t1,t1,a5
    128e:	983e                	add	a6,a6,a5
    1290:	953e                	add	a0,a0,a5
    1292:	0005c983          	lbu	s3,0(a1)
    1296:	00044403          	lbu	s0,0(s0)
    129a:	00064583          	lbu	a1,0(a2)
    129e:	0003c383          	lbu	t2,0(t2)
    12a2:	0006c603          	lbu	a2,0(a3)
    12a6:	0002c283          	lbu	t0,0(t0)
    12aa:	000fcf83          	lbu	t6,0(t6)
    12ae:	000f4f03          	lbu	t5,0(t5)
    12b2:	000ece83          	lbu	t4,0(t4)
    12b6:	000e4e03          	lbu	t3,0(t3)
    12ba:	0008c883          	lbu	a7,0(a7)
    12be:	00034303          	lbu	t1,0(t1)
    12c2:	00084803          	lbu	a6,0(a6)
    12c6:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12ca:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12ce:	92f1                	srli	a3,a3,0x3c
    12d0:	8b3d                	andi	a4,a4,15
    12d2:	96be                	add	a3,a3,a5
    12d4:	97ba                	add	a5,a5,a4
    12d6:	00810d23          	sb	s0,26(sp)
    12da:	00710da3          	sb	t2,27(sp)
    12de:	00510e23          	sb	t0,28(sp)
    12e2:	01f10ea3          	sb	t6,29(sp)
    12e6:	01e10f23          	sb	t5,30(sp)
    12ea:	01d10fa3          	sb	t4,31(sp)
    12ee:	03c10023          	sb	t3,32(sp)
    12f2:	031100a3          	sb	a7,33(sp)
    12f6:	02610123          	sb	t1,34(sp)
    12fa:	030101a3          	sb	a6,35(sp)
    12fe:	02a10223          	sb	a0,36(sp)
    1302:	033102a3          	sb	s3,37(sp)
    1306:	02b10323          	sb	a1,38(sp)
    130a:	02c103a3          	sb	a2,39(sp)
    130e:	0006c683          	lbu	a3,0(a3)
    1312:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1316:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    131a:	02d10423          	sb	a3,40(sp)
    131e:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1322:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1326:	11578263          	beq	a5,s5,142a <printf+0x2b6>
		len = out_unlocked(s, l);
    132a:	45c9                	li	a1,18
    132c:	0828                	addi	a0,sp,24
    132e:	2d2000ef          	jal	ra,1600 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1332:	00248993          	addi	s3,s1,2
		if (!*s)
    1336:	0009c783          	lbu	a5,0(s3)
    133a:	e6079ee3          	bnez	a5,11b6 <printf+0x42>
	}
	va_end(ap);
    133e:	70e6                	ld	ra,120(sp)
    1340:	7446                	ld	s0,112(sp)
    1342:	74a6                	ld	s1,104(sp)
    1344:	7906                	ld	s2,96(sp)
    1346:	69e6                	ld	s3,88(sp)
    1348:	6a46                	ld	s4,80(sp)
    134a:	6aa6                	ld	s5,72(sp)
    134c:	6b06                	ld	s6,64(sp)
    134e:	6129                	addi	sp,sp,192
    1350:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1352:	0005c783          	lbu	a5,0(a1)
    1356:	84ae                	mv	s1,a1
    1358:	01278963          	beq	a5,s2,136a <printf+0x1f6>
    135c:	b5ad                	j	11c6 <printf+0x52>
    135e:	0024c783          	lbu	a5,2(s1)
    1362:	0585                	addi	a1,a1,1
    1364:	0489                	addi	s1,s1,2
    1366:	e72790e3          	bne	a5,s2,11c6 <printf+0x52>
    136a:	0014c783          	lbu	a5,1(s1)
    136e:	ff2788e3          	beq	a5,s2,135e <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1372:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1376:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    137a:	e5579ce3          	bne	a5,s5,11d2 <printf+0x5e>
		mutex_lock(buffer_lock);
    137e:	10ca2503          	lw	a0,268(s4)
    1382:	292010ef          	jal	ra,2614 <mutex_lock>
		len = out_unlocked(s, l);
    1386:	85a2                	mv	a1,s0
    1388:	854e                	mv	a0,s3
    138a:	276000ef          	jal	ra,1600 <out_unlocked>
		mutex_unlock(buffer_lock);
    138e:	10ca2503          	lw	a0,268(s4)
    1392:	28e010ef          	jal	ra,2620 <mutex_unlock>
		if (l)
    1396:	e40404e3          	beqz	s0,11de <printf+0x6a>
    139a:	89a6                	mv	s3,s1
    139c:	bd09                	j	11ae <printf+0x3a>
		switch (s[1]) {
    139e:	07800713          	li	a4,120
    13a2:	04e79363          	bne	a5,a4,13e8 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13a6:	67c2                	ld	a5,16(sp)
    13a8:	45c1                	li	a1,16
		s += 2;
    13aa:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13ae:	4388                	lw	a0,0(a5)
    13b0:	07a1                	addi	a5,a5,8
    13b2:	e83e                	sd	a5,16(sp)
    13b4:	5f8000ef          	jal	ra,19ac <printint.constprop.0>
		s += 2;
    13b8:	bfbd                	j	1336 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13ba:	67c2                	ld	a5,16(sp)
    13bc:	6380                	ld	s0,0(a5)
    13be:	07a1                	addi	a5,a5,8
    13c0:	e83e                	sd	a5,16(sp)
    13c2:	1c040163          	beqz	s0,1584 <printf+0x410>
			l = strnlen(a, 200);
    13c6:	0c800593          	li	a1,200
    13ca:	8522                	mv	a0,s0
    13cc:	3f7000ef          	jal	ra,1fc2 <strnlen>
	if (buffer_lock_enabled == 1) {
    13d0:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    13d4:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    13d8:	19578663          	beq	a5,s5,1564 <printf+0x3f0>
		len = out_unlocked(s, l);
    13dc:	8522                	mv	a0,s0
    13de:	222000ef          	jal	ra,1600 <out_unlocked>
		s += 2;
    13e2:	00248993          	addi	s3,s1,2
    13e6:	bf81                	j	1336 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    13e8:	108a2783          	lw	a5,264(s4)
	char byte = c;
    13ec:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    13f0:	0f578663          	beq	a5,s5,14dc <printf+0x368>
		len = out_unlocked(s, l);
    13f4:	0828                	addi	a0,sp,24
    13f6:	316000ef          	jal	ra,170c <out_unlocked.constprop.0>
			putchar(s[1]);
    13fa:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    13fe:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1402:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1406:	05578163          	beq	a5,s5,1448 <printf+0x2d4>
		len = out_unlocked(s, l);
    140a:	0828                	addi	a0,sp,24
    140c:	300000ef          	jal	ra,170c <out_unlocked.constprop.0>
		s += 2;
    1410:	00248993          	addi	s3,s1,2
    1414:	b70d                	j	1336 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1416:	67c2                	ld	a5,16(sp)
    1418:	45a9                	li	a1,10
		s += 2;
    141a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    141e:	4388                	lw	a0,0(a5)
    1420:	07a1                	addi	a5,a5,8
    1422:	e83e                	sd	a5,16(sp)
    1424:	588000ef          	jal	ra,19ac <printint.constprop.0>
		s += 2;
    1428:	b739                	j	1336 <printf+0x1c2>
		mutex_lock(buffer_lock);
    142a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    142e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1432:	1e2010ef          	jal	ra,2614 <mutex_lock>
		len = out_unlocked(s, l);
    1436:	45c9                	li	a1,18
    1438:	0828                	addi	a0,sp,24
    143a:	1c6000ef          	jal	ra,1600 <out_unlocked>
		mutex_unlock(buffer_lock);
    143e:	10ca2503          	lw	a0,268(s4)
    1442:	1de010ef          	jal	ra,2620 <mutex_unlock>
		s += 2;
    1446:	bdc5                	j	1336 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1448:	10ca2503          	lw	a0,268(s4)
    144c:	1c8010ef          	jal	ra,2614 <mutex_lock>
		buffer[buffer_len++] = c;
    1450:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1454:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1458:	0017861b          	addiw	a2,a5,1
    145c:	97d2                	add	a5,a5,s4
    145e:	00ca2023          	sw	a2,0(s4)
    1462:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1466:	00c6cc63          	blt	a3,a2,147e <printf+0x30a>
    146a:	47a9                	li	a5,10
    146c:	06f40663          	beq	s0,a5,14d8 <printf+0x364>
		mutex_unlock(buffer_lock);
    1470:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1474:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1478:	1a8010ef          	jal	ra,2620 <mutex_unlock>
		s += 2;
    147c:	bd6d                	j	1336 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    147e:	10000793          	li	a5,256
    1482:	00f61e63          	bne	a2,a5,149e <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1486:	00001597          	auipc	a1,0x1
    148a:	34258593          	addi	a1,a1,834 # 27c8 <buffer>
    148e:	4505                	li	a0,1
    1490:	70d000ef          	jal	ra,239c <write>
	buffer_len = 0;
    1494:	00001797          	auipc	a5,0x1
    1498:	3207a623          	sw	zero,812(a5) # 27c0 <buffer_len>
			if (r < 0) {
    149c:	bfd1                	j	1470 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    149e:	709000ef          	jal	ra,23a6 <getpid>
    14a2:	842a                	mv	s0,a0
    14a4:	00001517          	auipc	a0,0x1
    14a8:	22450513          	addi	a0,a0,548 # 26c8 <enable_deadlock_detect+0x54>
    14ac:	5d1000ef          	jal	ra,227c <basename>
    14b0:	872a                	mv	a4,a0
    14b2:	00001617          	auipc	a2,0x1
    14b6:	25660613          	addi	a2,a2,598 # 2708 <enable_deadlock_detect+0x94>
    14ba:	05400793          	li	a5,84
    14be:	86a2                	mv	a3,s0
    14c0:	45fd                	li	a1,31
    14c2:	00001517          	auipc	a0,0x1
    14c6:	24e50513          	addi	a0,a0,590 # 2710 <enable_deadlock_detect+0x9c>
    14ca:	cabff0ef          	jal	ra,1174 <printf>
    14ce:	557d                	li	a0,-1
    14d0:	707000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    14d4:	000a2603          	lw	a2,0(s4)
    14d8:	de41                	beqz	a2,1470 <printf+0x2fc>
    14da:	b775                	j	1486 <printf+0x312>
		mutex_lock(buffer_lock);
    14dc:	10ca2503          	lw	a0,268(s4)
    14e0:	134010ef          	jal	ra,2614 <mutex_lock>
		buffer[buffer_len++] = c;
    14e4:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14e8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14ec:	0017861b          	addiw	a2,a5,1
    14f0:	97d2                	add	a5,a5,s4
    14f2:	00ca2023          	sw	a2,0(s4)
    14f6:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14fa:	02c6d163          	bge	a3,a2,151c <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    14fe:	10000793          	li	a5,256
    1502:	02f61263          	bne	a2,a5,1526 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1506:	00001597          	auipc	a1,0x1
    150a:	2c258593          	addi	a1,a1,706 # 27c8 <buffer>
    150e:	4505                	li	a0,1
    1510:	68d000ef          	jal	ra,239c <write>
	buffer_len = 0;
    1514:	00001797          	auipc	a5,0x1
    1518:	2a07a623          	sw	zero,684(a5) # 27c0 <buffer_len>
		mutex_unlock(buffer_lock);
    151c:	10ca2503          	lw	a0,268(s4)
    1520:	100010ef          	jal	ra,2620 <mutex_unlock>
    1524:	bdd9                	j	13fa <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1526:	681000ef          	jal	ra,23a6 <getpid>
    152a:	842a                	mv	s0,a0
    152c:	00001517          	auipc	a0,0x1
    1530:	19c50513          	addi	a0,a0,412 # 26c8 <enable_deadlock_detect+0x54>
    1534:	549000ef          	jal	ra,227c <basename>
    1538:	872a                	mv	a4,a0
    153a:	00001617          	auipc	a2,0x1
    153e:	1ce60613          	addi	a2,a2,462 # 2708 <enable_deadlock_detect+0x94>
    1542:	05400793          	li	a5,84
    1546:	86a2                	mv	a3,s0
    1548:	45fd                	li	a1,31
    154a:	00001517          	auipc	a0,0x1
    154e:	1c650513          	addi	a0,a0,454 # 2710 <enable_deadlock_detect+0x9c>
    1552:	c23ff0ef          	jal	ra,1174 <printf>
    1556:	557d                	li	a0,-1
    1558:	67f000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    155c:	000a2603          	lw	a2,0(s4)
    1560:	de55                	beqz	a2,151c <printf+0x3a8>
    1562:	b755                	j	1506 <printf+0x392>
		mutex_lock(buffer_lock);
    1564:	10ca2503          	lw	a0,268(s4)
    1568:	e42e                	sd	a1,8(sp)
		s += 2;
    156a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    156e:	0a6010ef          	jal	ra,2614 <mutex_lock>
		len = out_unlocked(s, l);
    1572:	65a2                	ld	a1,8(sp)
    1574:	8522                	mv	a0,s0
    1576:	08a000ef          	jal	ra,1600 <out_unlocked>
		mutex_unlock(buffer_lock);
    157a:	10ca2503          	lw	a0,268(s4)
    157e:	0a2010ef          	jal	ra,2620 <mutex_unlock>
		s += 2;
    1582:	bb55                	j	1336 <printf+0x1c2>
				a = "(null)";
    1584:	00001417          	auipc	s0,0x1
    1588:	13c40413          	addi	s0,s0,316 # 26c0 <enable_deadlock_detect+0x4c>
    158c:	bd2d                	j	13c6 <printf+0x252>

000000000000158e <enable_thread_io_buffer>:
{
    158e:	1101                	addi	sp,sp,-32
    1590:	e822                	sd	s0,16(sp)
    1592:	ec06                	sd	ra,24(sp)
    1594:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1596:	00001417          	auipc	s0,0x1
    159a:	22a40413          	addi	s0,s0,554 # 27c0 <buffer_len>
    159e:	05a010ef          	jal	ra,25f8 <mutex_create>
    15a2:	10a42623          	sw	a0,268(s0)
    15a6:	00054a63          	bltz	a0,15ba <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15aa:	4785                	li	a5,1
}
    15ac:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15ae:	10f42423          	sw	a5,264(s0)
}
    15b2:	6442                	ld	s0,16(sp)
    15b4:	64a2                	ld	s1,8(sp)
    15b6:	6105                	addi	sp,sp,32
    15b8:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15ba:	5ed000ef          	jal	ra,23a6 <getpid>
    15be:	84aa                	mv	s1,a0
    15c0:	00001517          	auipc	a0,0x1
    15c4:	10850513          	addi	a0,a0,264 # 26c8 <enable_deadlock_detect+0x54>
    15c8:	4b5000ef          	jal	ra,227c <basename>
    15cc:	872a                	mv	a4,a0
    15ce:	04800793          	li	a5,72
    15d2:	86a6                	mv	a3,s1
    15d4:	00001517          	auipc	a0,0x1
    15d8:	17c50513          	addi	a0,a0,380 # 2750 <enable_deadlock_detect+0xdc>
    15dc:	00001617          	auipc	a2,0x1
    15e0:	12c60613          	addi	a2,a2,300 # 2708 <enable_deadlock_detect+0x94>
    15e4:	45fd                	li	a1,31
    15e6:	b8fff0ef          	jal	ra,1174 <printf>
    15ea:	557d                	li	a0,-1
    15ec:	5eb000ef          	jal	ra,23d6 <exit>
	buffer_lock_enabled = 1;
    15f0:	4785                	li	a5,1
}
    15f2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15f4:	10f42423          	sw	a5,264(s0)
}
    15f8:	6442                	ld	s0,16(sp)
    15fa:	64a2                	ld	s1,8(sp)
    15fc:	6105                	addi	sp,sp,32
    15fe:	8082                	ret

0000000000001600 <out_unlocked>:
{
    1600:	7159                	addi	sp,sp,-112
    1602:	f486                	sd	ra,104(sp)
    1604:	f0a2                	sd	s0,96(sp)
    1606:	eca6                	sd	s1,88(sp)
    1608:	e8ca                	sd	s2,80(sp)
    160a:	e4ce                	sd	s3,72(sp)
    160c:	e0d2                	sd	s4,64(sp)
    160e:	fc56                	sd	s5,56(sp)
    1610:	f85a                	sd	s6,48(sp)
    1612:	f45e                	sd	s7,40(sp)
    1614:	f062                	sd	s8,32(sp)
    1616:	ec66                	sd	s9,24(sp)
    1618:	e86a                	sd	s10,16(sp)
    161a:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    161c:	0e058663          	beqz	a1,1708 <out_unlocked+0x108>
    1620:	842a                	mv	s0,a0
    1622:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1626:	4981                	li	s3,0
    1628:	00001d17          	auipc	s10,0x1
    162c:	198d0d13          	addi	s10,s10,408 # 27c0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1630:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1634:	00001b17          	auipc	s6,0x1
    1638:	194b0b13          	addi	s6,s6,404 # 27c8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    163c:	10000a93          	li	s5,256
    1640:	00001c97          	auipc	s9,0x1
    1644:	088c8c93          	addi	s9,s9,136 # 26c8 <enable_deadlock_detect+0x54>
    1648:	00001c17          	auipc	s8,0x1
    164c:	0c0c0c13          	addi	s8,s8,192 # 2708 <enable_deadlock_detect+0x94>
    1650:	00001b97          	auipc	s7,0x1
    1654:	0c0b8b93          	addi	s7,s7,192 # 2710 <enable_deadlock_detect+0x9c>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1658:	4a29                	li	s4,10
    165a:	a031                	j	1666 <out_unlocked+0x66>
    165c:	09468863          	beq	a3,s4,16ec <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1660:	0405                	addi	s0,s0,1
    1662:	04848163          	beq	s1,s0,16a4 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1666:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    166a:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    166e:	0017861b          	addiw	a2,a5,1
    1672:	97ea                	add	a5,a5,s10
    1674:	00cd2023          	sw	a2,0(s10)
    1678:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    167c:	fec950e3          	bge	s2,a2,165c <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1680:	05561263          	bne	a2,s5,16c4 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1684:	85da                	mv	a1,s6
    1686:	4505                	li	a0,1
    1688:	515000ef          	jal	ra,239c <write>
    168c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    168e:	00001797          	auipc	a5,0x1
    1692:	1207a923          	sw	zero,306(a5) # 27c0 <buffer_len>
			if (r < 0) {
    1696:	06054763          	bltz	a0,1704 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    169a:	0405                	addi	s0,s0,1
			ret += r;
    169c:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16a0:	fc8493e3          	bne	s1,s0,1666 <out_unlocked+0x66>
}
    16a4:	70a6                	ld	ra,104(sp)
    16a6:	7406                	ld	s0,96(sp)
    16a8:	64e6                	ld	s1,88(sp)
    16aa:	6946                	ld	s2,80(sp)
    16ac:	6a06                	ld	s4,64(sp)
    16ae:	7ae2                	ld	s5,56(sp)
    16b0:	7b42                	ld	s6,48(sp)
    16b2:	7ba2                	ld	s7,40(sp)
    16b4:	7c02                	ld	s8,32(sp)
    16b6:	6ce2                	ld	s9,24(sp)
    16b8:	6d42                	ld	s10,16(sp)
    16ba:	6da2                	ld	s11,8(sp)
    16bc:	854e                	mv	a0,s3
    16be:	69a6                	ld	s3,72(sp)
    16c0:	6165                	addi	sp,sp,112
    16c2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16c4:	4e3000ef          	jal	ra,23a6 <getpid>
    16c8:	8daa                	mv	s11,a0
    16ca:	8566                	mv	a0,s9
    16cc:	3b1000ef          	jal	ra,227c <basename>
    16d0:	872a                	mv	a4,a0
    16d2:	8662                	mv	a2,s8
    16d4:	05400793          	li	a5,84
    16d8:	86ee                	mv	a3,s11
    16da:	45fd                	li	a1,31
    16dc:	855e                	mv	a0,s7
    16de:	a97ff0ef          	jal	ra,1174 <printf>
    16e2:	557d                	li	a0,-1
    16e4:	4f3000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    16e8:	000d2603          	lw	a2,0(s10)
    16ec:	da35                	beqz	a2,1660 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    16ee:	85da                	mv	a1,s6
    16f0:	4505                	li	a0,1
    16f2:	4ab000ef          	jal	ra,239c <write>
    16f6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16f8:	00001797          	auipc	a5,0x1
    16fc:	0c07a423          	sw	zero,200(a5) # 27c0 <buffer_len>
			if (r < 0) {
    1700:	f8055de3          	bgez	a0,169a <out_unlocked+0x9a>
    1704:	89aa                	mv	s3,a0
    1706:	bf79                	j	16a4 <out_unlocked+0xa4>
	int ret = 0;
    1708:	4981                	li	s3,0
    170a:	bf69                	j	16a4 <out_unlocked+0xa4>

000000000000170c <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    170c:	1101                	addi	sp,sp,-32
    170e:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1710:	00001497          	auipc	s1,0x1
    1714:	0b048493          	addi	s1,s1,176 # 27c0 <buffer_len>
    1718:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    171a:	ec06                	sd	ra,24(sp)
    171c:	e822                	sd	s0,16(sp)
		char c = s[i];
    171e:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1722:	0017861b          	addiw	a2,a5,1
    1726:	97a6                	add	a5,a5,s1
    1728:	00e78423          	sb	a4,8(a5)
    172c:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    172e:	0ff00793          	li	a5,255
    1732:	00c7cc63          	blt	a5,a2,174a <out_unlocked.constprop.0+0x3e>
    1736:	47a9                	li	a5,10
    1738:	06f70c63          	beq	a4,a5,17b0 <out_unlocked.constprop.0+0xa4>
    173c:	4601                	li	a2,0
}
    173e:	60e2                	ld	ra,24(sp)
    1740:	6442                	ld	s0,16(sp)
    1742:	64a2                	ld	s1,8(sp)
    1744:	8532                	mv	a0,a2
    1746:	6105                	addi	sp,sp,32
    1748:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    174a:	10000793          	li	a5,256
    174e:	02f61563          	bne	a2,a5,1778 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1752:	00001597          	auipc	a1,0x1
    1756:	07658593          	addi	a1,a1,118 # 27c8 <buffer>
    175a:	4505                	li	a0,1
    175c:	441000ef          	jal	ra,239c <write>
}
    1760:	60e2                	ld	ra,24(sp)
    1762:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1764:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1768:	00001797          	auipc	a5,0x1
    176c:	0407ac23          	sw	zero,88(a5) # 27c0 <buffer_len>
}
    1770:	64a2                	ld	s1,8(sp)
    1772:	8532                	mv	a0,a2
    1774:	6105                	addi	sp,sp,32
    1776:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1778:	42f000ef          	jal	ra,23a6 <getpid>
    177c:	842a                	mv	s0,a0
    177e:	00001517          	auipc	a0,0x1
    1782:	f4a50513          	addi	a0,a0,-182 # 26c8 <enable_deadlock_detect+0x54>
    1786:	2f7000ef          	jal	ra,227c <basename>
    178a:	872a                	mv	a4,a0
    178c:	00001617          	auipc	a2,0x1
    1790:	f7c60613          	addi	a2,a2,-132 # 2708 <enable_deadlock_detect+0x94>
    1794:	05400793          	li	a5,84
    1798:	86a2                	mv	a3,s0
    179a:	45fd                	li	a1,31
    179c:	00001517          	auipc	a0,0x1
    17a0:	f7450513          	addi	a0,a0,-140 # 2710 <enable_deadlock_detect+0x9c>
    17a4:	9d1ff0ef          	jal	ra,1174 <printf>
    17a8:	557d                	li	a0,-1
    17aa:	42d000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    17ae:	4090                	lw	a2,0(s1)
    17b0:	d659                	beqz	a2,173e <out_unlocked.constprop.0+0x32>
    17b2:	b745                	j	1752 <out_unlocked.constprop.0+0x46>

00000000000017b4 <putchar>:
{
    17b4:	7139                	addi	sp,sp,-64
    17b6:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17b8:	00001497          	auipc	s1,0x1
    17bc:	00848493          	addi	s1,s1,8 # 27c0 <buffer_len>
    17c0:	1084a703          	lw	a4,264(s1)
{
    17c4:	f822                	sd	s0,48(sp)
	char byte = c;
    17c6:	0ff57413          	zext.b	s0,a0
{
    17ca:	fc06                	sd	ra,56(sp)
	char byte = c;
    17cc:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    17d0:	4785                	li	a5,1
    17d2:	00f70d63          	beq	a4,a5,17ec <putchar+0x38>
		len = out_unlocked(s, l);
    17d6:	01f10513          	addi	a0,sp,31
    17da:	f33ff0ef          	jal	ra,170c <out_unlocked.constprop.0>
}
    17de:	70e2                	ld	ra,56(sp)
    17e0:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    17e2:	862a                	mv	a2,a0
}
    17e4:	74a2                	ld	s1,40(sp)
    17e6:	8532                	mv	a0,a2
    17e8:	6121                	addi	sp,sp,64
    17ea:	8082                	ret
		mutex_lock(buffer_lock);
    17ec:	10c4a503          	lw	a0,268(s1)
    17f0:	625000ef          	jal	ra,2614 <mutex_lock>
		buffer[buffer_len++] = c;
    17f4:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17f6:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    17fa:	0017861b          	addiw	a2,a5,1
    17fe:	97a6                	add	a5,a5,s1
    1800:	c090                	sw	a2,0(s1)
    1802:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1806:	02c6c263          	blt	a3,a2,182a <putchar+0x76>
    180a:	47a9                	li	a5,10
    180c:	06f40d63          	beq	s0,a5,1886 <putchar+0xd2>
    1810:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1812:	10c4a503          	lw	a0,268(s1)
    1816:	e432                	sd	a2,8(sp)
    1818:	609000ef          	jal	ra,2620 <mutex_unlock>
    181c:	6622                	ld	a2,8(sp)
}
    181e:	70e2                	ld	ra,56(sp)
    1820:	7442                	ld	s0,48(sp)
    1822:	74a2                	ld	s1,40(sp)
    1824:	8532                	mv	a0,a2
    1826:	6121                	addi	sp,sp,64
    1828:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    182a:	10000793          	li	a5,256
    182e:	02f61063          	bne	a2,a5,184e <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1832:	00001597          	auipc	a1,0x1
    1836:	f9658593          	addi	a1,a1,-106 # 27c8 <buffer>
    183a:	4505                	li	a0,1
    183c:	361000ef          	jal	ra,239c <write>
    1840:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1844:	00001797          	auipc	a5,0x1
    1848:	f607ae23          	sw	zero,-132(a5) # 27c0 <buffer_len>
			if (r < 0) {
    184c:	b7d9                	j	1812 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    184e:	359000ef          	jal	ra,23a6 <getpid>
    1852:	842a                	mv	s0,a0
    1854:	00001517          	auipc	a0,0x1
    1858:	e7450513          	addi	a0,a0,-396 # 26c8 <enable_deadlock_detect+0x54>
    185c:	221000ef          	jal	ra,227c <basename>
    1860:	872a                	mv	a4,a0
    1862:	00001617          	auipc	a2,0x1
    1866:	ea660613          	addi	a2,a2,-346 # 2708 <enable_deadlock_detect+0x94>
    186a:	05400793          	li	a5,84
    186e:	86a2                	mv	a3,s0
    1870:	45fd                	li	a1,31
    1872:	00001517          	auipc	a0,0x1
    1876:	e9e50513          	addi	a0,a0,-354 # 2710 <enable_deadlock_detect+0x9c>
    187a:	8fbff0ef          	jal	ra,1174 <printf>
    187e:	557d                	li	a0,-1
    1880:	357000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    1884:	4090                	lw	a2,0(s1)
    1886:	d651                	beqz	a2,1812 <putchar+0x5e>
    1888:	b76d                	j	1832 <putchar+0x7e>

000000000000188a <puts>:
{
    188a:	7139                	addi	sp,sp,-64
    188c:	f822                	sd	s0,48(sp)
    188e:	f426                	sd	s1,40(sp)
    1890:	fc06                	sd	ra,56(sp)
    1892:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1894:	00001417          	auipc	s0,0x1
    1898:	f2c40413          	addi	s0,s0,-212 # 27c0 <buffer_len>
{
    189c:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    189e:	638000ef          	jal	ra,1ed6 <strlen>
	if (buffer_lock_enabled == 1) {
    18a2:	10842703          	lw	a4,264(s0)
    18a6:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18a8:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18aa:	04f70563          	beq	a4,a5,18f4 <puts+0x6a>
		len = out_unlocked(s, l);
    18ae:	8526                	mv	a0,s1
    18b0:	d51ff0ef          	jal	ra,1600 <out_unlocked>
    18b4:	892a                	mv	s2,a0
    18b6:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18b8:	00095963          	bgez	s2,18ca <puts+0x40>
}
    18bc:	70e2                	ld	ra,56(sp)
    18be:	7442                	ld	s0,48(sp)
    18c0:	7902                	ld	s2,32(sp)
    18c2:	8526                	mv	a0,s1
    18c4:	74a2                	ld	s1,40(sp)
    18c6:	6121                	addi	sp,sp,64
    18c8:	8082                	ret
	if (buffer_lock_enabled == 1) {
    18ca:	10842703          	lw	a4,264(s0)
	char byte = c;
    18ce:	44a9                	li	s1,10
    18d0:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    18d4:	4785                	li	a5,1
    18d6:	02f70e63          	beq	a4,a5,1912 <puts+0x88>
		len = out_unlocked(s, l);
    18da:	01f10513          	addi	a0,sp,31
    18de:	e2fff0ef          	jal	ra,170c <out_unlocked.constprop.0>
}
    18e2:	70e2                	ld	ra,56(sp)
    18e4:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18e6:	41f5549b          	sraiw	s1,a0,0x1f
}
    18ea:	7902                	ld	s2,32(sp)
    18ec:	8526                	mv	a0,s1
    18ee:	74a2                	ld	s1,40(sp)
    18f0:	6121                	addi	sp,sp,64
    18f2:	8082                	ret
		mutex_lock(buffer_lock);
    18f4:	e42a                	sd	a0,8(sp)
    18f6:	10c42503          	lw	a0,268(s0)
    18fa:	51b000ef          	jal	ra,2614 <mutex_lock>
		len = out_unlocked(s, l);
    18fe:	65a2                	ld	a1,8(sp)
    1900:	8526                	mv	a0,s1
    1902:	cffff0ef          	jal	ra,1600 <out_unlocked>
    1906:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1908:	10c42503          	lw	a0,268(s0)
    190c:	515000ef          	jal	ra,2620 <mutex_unlock>
    1910:	b75d                	j	18b6 <puts+0x2c>
		mutex_lock(buffer_lock);
    1912:	10c42503          	lw	a0,268(s0)
    1916:	4ff000ef          	jal	ra,2614 <mutex_lock>
		buffer[buffer_len++] = c;
    191a:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    191c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1920:	0017861b          	addiw	a2,a5,1
    1924:	97a2                	add	a5,a5,s0
    1926:	c010                	sw	a2,0(s0)
    1928:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    192c:	06c6dc63          	bge	a3,a2,19a4 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1930:	10000793          	li	a5,256
    1934:	02f61c63          	bne	a2,a5,196c <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1938:	00001597          	auipc	a1,0x1
    193c:	e9058593          	addi	a1,a1,-368 # 27c8 <buffer>
    1940:	4505                	li	a0,1
    1942:	25b000ef          	jal	ra,239c <write>
			if (r < 0) {
    1946:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1948:	00001797          	auipc	a5,0x1
    194c:	e607ac23          	sw	zero,-392(a5) # 27c0 <buffer_len>
			if (r < 0) {
    1950:	04054c63          	bltz	a0,19a8 <puts+0x11e>
			if (r < buffer_len) {
    1954:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1956:	10c42503          	lw	a0,268(s0)
    195a:	4c7000ef          	jal	ra,2620 <mutex_unlock>
}
    195e:	70e2                	ld	ra,56(sp)
    1960:	7442                	ld	s0,48(sp)
    1962:	7902                	ld	s2,32(sp)
    1964:	8526                	mv	a0,s1
    1966:	74a2                	ld	s1,40(sp)
    1968:	6121                	addi	sp,sp,64
    196a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    196c:	23b000ef          	jal	ra,23a6 <getpid>
    1970:	84aa                	mv	s1,a0
    1972:	00001517          	auipc	a0,0x1
    1976:	d5650513          	addi	a0,a0,-682 # 26c8 <enable_deadlock_detect+0x54>
    197a:	103000ef          	jal	ra,227c <basename>
    197e:	872a                	mv	a4,a0
    1980:	00001617          	auipc	a2,0x1
    1984:	d8860613          	addi	a2,a2,-632 # 2708 <enable_deadlock_detect+0x94>
    1988:	05400793          	li	a5,84
    198c:	86a6                	mv	a3,s1
    198e:	45fd                	li	a1,31
    1990:	00001517          	auipc	a0,0x1
    1994:	d8050513          	addi	a0,a0,-640 # 2710 <enable_deadlock_detect+0x9c>
    1998:	fdcff0ef          	jal	ra,1174 <printf>
    199c:	557d                	li	a0,-1
    199e:	239000ef          	jal	ra,23d6 <exit>
	if (buffer_len == 0)
    19a2:	4010                	lw	a2,0(s0)
    19a4:	da45                	beqz	a2,1954 <puts+0xca>
    19a6:	bf49                	j	1938 <puts+0xae>
    19a8:	54fd                	li	s1,-1
    19aa:	b775                	j	1956 <puts+0xcc>

00000000000019ac <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19ac:	715d                	addi	sp,sp,-80
    19ae:	e486                	sd	ra,72(sp)
    19b0:	e0a2                	sd	s0,64(sp)
    19b2:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19b4:	14054363          	bltz	a0,1afa <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19b8:	02b577bb          	remuw	a5,a0,a1
    19bc:	00001617          	auipc	a2,0x1
    19c0:	f1460613          	addi	a2,a2,-236 # 28d0 <digits>
	buf[16] = 0;
    19c4:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19c8:	0005871b          	sext.w	a4,a1
    19cc:	1782                	slli	a5,a5,0x20
    19ce:	9381                	srli	a5,a5,0x20
    19d0:	97b2                	add	a5,a5,a2
    19d2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    19d6:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    19da:	02f103a3          	sb	a5,39(sp)
	i = 15;
    19de:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    19e0:	0eb56763          	bltu	a0,a1,1ace <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    19e4:	02e877bb          	remuw	a5,a6,a4
    19e8:	1782                	slli	a5,a5,0x20
    19ea:	9381                	srli	a5,a5,0x20
    19ec:	97b2                	add	a5,a5,a2
    19ee:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    19f2:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    19f6:	02f10323          	sb	a5,38(sp)
    19fa:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    19fc:	0ce86963          	bltu	a6,a4,1ace <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a00:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a04:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a08:	1582                	slli	a1,a1,0x20
    1a0a:	9181                	srli	a1,a1,0x20
    1a0c:	95b2                	add	a1,a1,a2
    1a0e:	0005c583          	lbu	a1,0(a1)
    1a12:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a16:	0007859b          	sext.w	a1,a5
    1a1a:	16e6e563          	bltu	a3,a4,1b84 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a1e:	02e7f6bb          	remuw	a3,a5,a4
    1a22:	1682                	slli	a3,a3,0x20
    1a24:	9281                	srli	a3,a3,0x20
    1a26:	96b2                	add	a3,a3,a2
    1a28:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a2c:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a30:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a34:	16e5e163          	bltu	a1,a4,1b96 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a38:	02e876bb          	remuw	a3,a6,a4
    1a3c:	1682                	slli	a3,a3,0x20
    1a3e:	9281                	srli	a3,a3,0x20
    1a40:	96b2                	add	a3,a3,a2
    1a42:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a46:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a4a:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a4e:	14e86d63          	bltu	a6,a4,1ba8 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a52:	02e5f6bb          	remuw	a3,a1,a4
    1a56:	1682                	slli	a3,a3,0x20
    1a58:	9281                	srli	a3,a3,0x20
    1a5a:	96b2                	add	a3,a3,a2
    1a5c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a60:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a64:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a68:	10e5e563          	bltu	a1,a4,1b72 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1a6c:	02e876bb          	remuw	a3,a6,a4
    1a70:	1682                	slli	a3,a3,0x20
    1a72:	9281                	srli	a3,a3,0x20
    1a74:	96b2                	add	a3,a3,a2
    1a76:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a7a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a7e:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1a82:	14e86263          	bltu	a6,a4,1bc6 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1a86:	02e5f6bb          	remuw	a3,a1,a4
    1a8a:	1682                	slli	a3,a3,0x20
    1a8c:	9281                	srli	a3,a3,0x20
    1a8e:	96b2                	add	a3,a3,a2
    1a90:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a94:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a98:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1a9c:	14e5e463          	bltu	a1,a4,1be4 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1aa0:	02e876bb          	remuw	a3,a6,a4
    1aa4:	1682                	slli	a3,a3,0x20
    1aa6:	9281                	srli	a3,a3,0x20
    1aa8:	96b2                	add	a3,a3,a2
    1aaa:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aae:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ab2:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1ab6:	14e86063          	bltu	a6,a4,1bf6 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1aba:	1782                	slli	a5,a5,0x20
    1abc:	9381                	srli	a5,a5,0x20
    1abe:	97b2                	add	a5,a5,a2
    1ac0:	0007c703          	lbu	a4,0(a5)
    1ac4:	4799                	li	a5,6
    1ac6:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1aca:	10054763          	bltz	a0,1bd8 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1ace:	00001497          	auipc	s1,0x1
    1ad2:	cf248493          	addi	s1,s1,-782 # 27c0 <buffer_len>
    1ad6:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1ada:	0828                	addi	a0,sp,24
    1adc:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1ade:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1ae0:	00f50433          	add	s0,a0,a5
    1ae4:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1ae6:	06e68463          	beq	a3,a4,1b4e <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1aea:	8522                	mv	a0,s0
    1aec:	b15ff0ef          	jal	ra,1600 <out_unlocked>
}
    1af0:	60a6                	ld	ra,72(sp)
    1af2:	6406                	ld	s0,64(sp)
    1af4:	74e2                	ld	s1,56(sp)
    1af6:	6161                	addi	sp,sp,80
    1af8:	8082                	ret
		x = -xx;
    1afa:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1afe:	02b877bb          	remuw	a5,a6,a1
    1b02:	00001617          	auipc	a2,0x1
    1b06:	dce60613          	addi	a2,a2,-562 # 28d0 <digits>
	buf[16] = 0;
    1b0a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b0e:	0005871b          	sext.w	a4,a1
    1b12:	1782                	slli	a5,a5,0x20
    1b14:	9381                	srli	a5,a5,0x20
    1b16:	97b2                	add	a5,a5,a2
    1b18:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b1c:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b20:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b24:	08b86b63          	bltu	a6,a1,1bba <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b28:	02e8f7bb          	remuw	a5,a7,a4
    1b2c:	1782                	slli	a5,a5,0x20
    1b2e:	9381                	srli	a5,a5,0x20
    1b30:	97b2                	add	a5,a5,a2
    1b32:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b36:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b3a:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b3e:	ece8f1e3          	bgeu	a7,a4,1a00 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b42:	02d00793          	li	a5,45
    1b46:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b4a:	47b5                	li	a5,13
    1b4c:	b749                	j	1ace <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b4e:	10c4a503          	lw	a0,268(s1)
    1b52:	e42e                	sd	a1,8(sp)
    1b54:	2c1000ef          	jal	ra,2614 <mutex_lock>
		len = out_unlocked(s, l);
    1b58:	65a2                	ld	a1,8(sp)
    1b5a:	8522                	mv	a0,s0
    1b5c:	aa5ff0ef          	jal	ra,1600 <out_unlocked>
		mutex_unlock(buffer_lock);
    1b60:	10c4a503          	lw	a0,268(s1)
    1b64:	2bd000ef          	jal	ra,2620 <mutex_unlock>
}
    1b68:	60a6                	ld	ra,72(sp)
    1b6a:	6406                	ld	s0,64(sp)
    1b6c:	74e2                	ld	s1,56(sp)
    1b6e:	6161                	addi	sp,sp,80
    1b70:	8082                	ret
		buf[i--] = digits[x % base];
    1b72:	47a9                	li	a5,10
	if (sign)
    1b74:	f4055de3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1b78:	02d00793          	li	a5,45
    1b7c:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1b80:	47a5                	li	a5,9
    1b82:	b7b1                	j	1ace <printint.constprop.0+0x122>
    1b84:	47b5                	li	a5,13
	if (sign)
    1b86:	f40554e3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1b8a:	02d00793          	li	a5,45
    1b8e:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1b92:	47b1                	li	a5,12
    1b94:	bf2d                	j	1ace <printint.constprop.0+0x122>
    1b96:	47b1                	li	a5,12
	if (sign)
    1b98:	f2055be3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1b9c:	02d00793          	li	a5,45
    1ba0:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ba4:	47ad                	li	a5,11
    1ba6:	b725                	j	1ace <printint.constprop.0+0x122>
    1ba8:	47ad                	li	a5,11
	if (sign)
    1baa:	f20552e3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bae:	02d00793          	li	a5,45
    1bb2:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1bb6:	47a9                	li	a5,10
    1bb8:	bf19                	j	1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bba:	02d00793          	li	a5,45
    1bbe:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bc2:	47b9                	li	a5,14
    1bc4:	b729                	j	1ace <printint.constprop.0+0x122>
    1bc6:	47a5                	li	a5,9
	if (sign)
    1bc8:	f00553e3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bcc:	02d00793          	li	a5,45
    1bd0:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1bd4:	47a1                	li	a5,8
    1bd6:	bde5                	j	1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bd8:	02d00793          	li	a5,45
    1bdc:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1be0:	4795                	li	a5,5
    1be2:	b5f5                	j	1ace <printint.constprop.0+0x122>
    1be4:	47a1                	li	a5,8
	if (sign)
    1be6:	ee0554e3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bea:	02d00793          	li	a5,45
    1bee:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1bf2:	479d                	li	a5,7
    1bf4:	bde9                	j	1ace <printint.constprop.0+0x122>
    1bf6:	479d                	li	a5,7
	if (sign)
    1bf8:	ec055be3          	bgez	a0,1ace <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bfc:	02d00793          	li	a5,45
    1c00:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c04:	4799                	li	a5,6
    1c06:	b5e1                	j	1ace <printint.constprop.0+0x122>

0000000000001c08 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c08:	02000793          	li	a5,32
    1c0c:	00f50663          	beq	a0,a5,1c18 <isspace+0x10>
    1c10:	355d                	addiw	a0,a0,-9
    1c12:	00553513          	sltiu	a0,a0,5
    1c16:	8082                	ret
    1c18:	4505                	li	a0,1
}
    1c1a:	8082                	ret

0000000000001c1c <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c1c:	fd05051b          	addiw	a0,a0,-48
}
    1c20:	00a53513          	sltiu	a0,a0,10
    1c24:	8082                	ret

0000000000001c26 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c26:	02000613          	li	a2,32
    1c2a:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c2c:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c30:	ff77869b          	addiw	a3,a5,-9
    1c34:	04c78c63          	beq	a5,a2,1c8c <atoi+0x66>
    1c38:	0007871b          	sext.w	a4,a5
    1c3c:	04d5f863          	bgeu	a1,a3,1c8c <atoi+0x66>
		s++;
	switch (*s) {
    1c40:	02b00693          	li	a3,43
    1c44:	04d78963          	beq	a5,a3,1c96 <atoi+0x70>
    1c48:	02d00693          	li	a3,45
    1c4c:	06d78263          	beq	a5,a3,1cb0 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c50:	fd07061b          	addiw	a2,a4,-48
    1c54:	47a5                	li	a5,9
    1c56:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c58:	4e01                	li	t3,0
	while (isdigit(*s))
    1c5a:	04c7e963          	bltu	a5,a2,1cac <atoi+0x86>
	int n = 0, neg = 0;
    1c5e:	4501                	li	a0,0
	while (isdigit(*s))
    1c60:	4825                	li	a6,9
    1c62:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c66:	0025179b          	slliw	a5,a0,0x2
    1c6a:	9fa9                	addw	a5,a5,a0
    1c6c:	fd07031b          	addiw	t1,a4,-48
    1c70:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1c74:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1c78:	0685                	addi	a3,a3,1
    1c7a:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1c7e:	0006071b          	sext.w	a4,a2
    1c82:	feb870e3          	bgeu	a6,a1,1c62 <atoi+0x3c>
	return neg ? n : -n;
    1c86:	000e0563          	beqz	t3,1c90 <atoi+0x6a>
}
    1c8a:	8082                	ret
		s++;
    1c8c:	0505                	addi	a0,a0,1
    1c8e:	bf79                	j	1c2c <atoi+0x6>
	return neg ? n : -n;
    1c90:	4113053b          	subw	a0,t1,a7
    1c94:	8082                	ret
	while (isdigit(*s))
    1c96:	00154703          	lbu	a4,1(a0)
    1c9a:	47a5                	li	a5,9
		s++;
    1c9c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ca0:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1ca4:	4e01                	li	t3,0
	while (isdigit(*s))
    1ca6:	2701                	sext.w	a4,a4
    1ca8:	fac7fbe3          	bgeu	a5,a2,1c5e <atoi+0x38>
    1cac:	4501                	li	a0,0
}
    1cae:	8082                	ret
	while (isdigit(*s))
    1cb0:	00154703          	lbu	a4,1(a0)
    1cb4:	47a5                	li	a5,9
		s++;
    1cb6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cba:	fd07061b          	addiw	a2,a4,-48
    1cbe:	2701                	sext.w	a4,a4
    1cc0:	fec7e6e3          	bltu	a5,a2,1cac <atoi+0x86>
		neg = 1;
    1cc4:	4e05                	li	t3,1
    1cc6:	bf61                	j	1c5e <atoi+0x38>

0000000000001cc8 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cc8:	16060d63          	beqz	a2,1e42 <memset+0x17a>
    1ccc:	40a007b3          	neg	a5,a0
    1cd0:	8b9d                	andi	a5,a5,7
    1cd2:	00778693          	addi	a3,a5,7
    1cd6:	482d                	li	a6,11
    1cd8:	0ff5f713          	zext.b	a4,a1
    1cdc:	fff60593          	addi	a1,a2,-1
    1ce0:	1706e263          	bltu	a3,a6,1e44 <memset+0x17c>
    1ce4:	16d5ea63          	bltu	a1,a3,1e58 <memset+0x190>
    1ce8:	16078563          	beqz	a5,1e52 <memset+0x18a>
    1cec:	00e50023          	sb	a4,0(a0)
    1cf0:	4685                	li	a3,1
    1cf2:	00150593          	addi	a1,a0,1
    1cf6:	14d78c63          	beq	a5,a3,1e4e <memset+0x186>
    1cfa:	00e500a3          	sb	a4,1(a0)
    1cfe:	4689                	li	a3,2
    1d00:	00250593          	addi	a1,a0,2
    1d04:	14d78d63          	beq	a5,a3,1e5e <memset+0x196>
    1d08:	00e50123          	sb	a4,2(a0)
    1d0c:	468d                	li	a3,3
    1d0e:	00350593          	addi	a1,a0,3
    1d12:	12d78b63          	beq	a5,a3,1e48 <memset+0x180>
    1d16:	00e501a3          	sb	a4,3(a0)
    1d1a:	4691                	li	a3,4
    1d1c:	00450593          	addi	a1,a0,4
    1d20:	14d78163          	beq	a5,a3,1e62 <memset+0x19a>
    1d24:	00e50223          	sb	a4,4(a0)
    1d28:	4695                	li	a3,5
    1d2a:	00550593          	addi	a1,a0,5
    1d2e:	12d78c63          	beq	a5,a3,1e66 <memset+0x19e>
    1d32:	00e502a3          	sb	a4,5(a0)
    1d36:	469d                	li	a3,7
    1d38:	00650593          	addi	a1,a0,6
    1d3c:	12d79763          	bne	a5,a3,1e6a <memset+0x1a2>
    1d40:	00750593          	addi	a1,a0,7
    1d44:	00e50323          	sb	a4,6(a0)
    1d48:	481d                	li	a6,7
    1d4a:	00871693          	slli	a3,a4,0x8
    1d4e:	01071893          	slli	a7,a4,0x10
    1d52:	8ed9                	or	a3,a3,a4
    1d54:	01871313          	slli	t1,a4,0x18
    1d58:	0116e6b3          	or	a3,a3,a7
    1d5c:	0066e6b3          	or	a3,a3,t1
    1d60:	02071893          	slli	a7,a4,0x20
    1d64:	02871e13          	slli	t3,a4,0x28
    1d68:	0116e6b3          	or	a3,a3,a7
    1d6c:	40f60333          	sub	t1,a2,a5
    1d70:	03071893          	slli	a7,a4,0x30
    1d74:	01c6e6b3          	or	a3,a3,t3
    1d78:	0116e6b3          	or	a3,a3,a7
    1d7c:	03871e13          	slli	t3,a4,0x38
    1d80:	97aa                	add	a5,a5,a0
    1d82:	ff837893          	andi	a7,t1,-8
    1d86:	01c6e6b3          	or	a3,a3,t3
    1d8a:	98be                	add	a7,a7,a5
    1d8c:	e394                	sd	a3,0(a5)
    1d8e:	07a1                	addi	a5,a5,8
    1d90:	ff179ee3          	bne	a5,a7,1d8c <memset+0xc4>
    1d94:	ff837893          	andi	a7,t1,-8
    1d98:	011587b3          	add	a5,a1,a7
    1d9c:	010886bb          	addw	a3,a7,a6
    1da0:	0b130663          	beq	t1,a7,1e4c <memset+0x184>
    1da4:	00e78023          	sb	a4,0(a5)
    1da8:	0016859b          	addiw	a1,a3,1
    1dac:	08c5fb63          	bgeu	a1,a2,1e42 <memset+0x17a>
    1db0:	00e780a3          	sb	a4,1(a5)
    1db4:	0026859b          	addiw	a1,a3,2
    1db8:	08c5f563          	bgeu	a1,a2,1e42 <memset+0x17a>
    1dbc:	00e78123          	sb	a4,2(a5)
    1dc0:	0036859b          	addiw	a1,a3,3
    1dc4:	06c5ff63          	bgeu	a1,a2,1e42 <memset+0x17a>
    1dc8:	00e781a3          	sb	a4,3(a5)
    1dcc:	0046859b          	addiw	a1,a3,4
    1dd0:	06c5f963          	bgeu	a1,a2,1e42 <memset+0x17a>
    1dd4:	00e78223          	sb	a4,4(a5)
    1dd8:	0056859b          	addiw	a1,a3,5
    1ddc:	06c5f363          	bgeu	a1,a2,1e42 <memset+0x17a>
    1de0:	00e782a3          	sb	a4,5(a5)
    1de4:	0066859b          	addiw	a1,a3,6
    1de8:	04c5fd63          	bgeu	a1,a2,1e42 <memset+0x17a>
    1dec:	00e78323          	sb	a4,6(a5)
    1df0:	0076859b          	addiw	a1,a3,7
    1df4:	04c5f763          	bgeu	a1,a2,1e42 <memset+0x17a>
    1df8:	00e783a3          	sb	a4,7(a5)
    1dfc:	0086859b          	addiw	a1,a3,8
    1e00:	04c5f163          	bgeu	a1,a2,1e42 <memset+0x17a>
    1e04:	00e78423          	sb	a4,8(a5)
    1e08:	0096859b          	addiw	a1,a3,9
    1e0c:	02c5fb63          	bgeu	a1,a2,1e42 <memset+0x17a>
    1e10:	00e784a3          	sb	a4,9(a5)
    1e14:	00a6859b          	addiw	a1,a3,10
    1e18:	02c5f563          	bgeu	a1,a2,1e42 <memset+0x17a>
    1e1c:	00e78523          	sb	a4,10(a5)
    1e20:	00b6859b          	addiw	a1,a3,11
    1e24:	00c5ff63          	bgeu	a1,a2,1e42 <memset+0x17a>
    1e28:	00e785a3          	sb	a4,11(a5)
    1e2c:	00c6859b          	addiw	a1,a3,12
    1e30:	00c5f963          	bgeu	a1,a2,1e42 <memset+0x17a>
    1e34:	00e78623          	sb	a4,12(a5)
    1e38:	26b5                	addiw	a3,a3,13
    1e3a:	00c6f463          	bgeu	a3,a2,1e42 <memset+0x17a>
    1e3e:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e42:	8082                	ret
    1e44:	46ad                	li	a3,11
    1e46:	bd79                	j	1ce4 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e48:	480d                	li	a6,3
    1e4a:	b701                	j	1d4a <memset+0x82>
    1e4c:	8082                	ret
    1e4e:	4805                	li	a6,1
    1e50:	bded                	j	1d4a <memset+0x82>
    1e52:	85aa                	mv	a1,a0
    1e54:	4801                	li	a6,0
    1e56:	bdd5                	j	1d4a <memset+0x82>
    1e58:	87aa                	mv	a5,a0
    1e5a:	4681                	li	a3,0
    1e5c:	b7a1                	j	1da4 <memset+0xdc>
    1e5e:	4809                	li	a6,2
    1e60:	b5ed                	j	1d4a <memset+0x82>
    1e62:	4811                	li	a6,4
    1e64:	b5dd                	j	1d4a <memset+0x82>
    1e66:	4815                	li	a6,5
    1e68:	b5cd                	j	1d4a <memset+0x82>
    1e6a:	4819                	li	a6,6
    1e6c:	bdf9                	j	1d4a <memset+0x82>

0000000000001e6e <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1e6e:	00054783          	lbu	a5,0(a0)
    1e72:	0005c703          	lbu	a4,0(a1)
    1e76:	00e79863          	bne	a5,a4,1e86 <strcmp+0x18>
    1e7a:	0505                	addi	a0,a0,1
    1e7c:	0585                	addi	a1,a1,1
    1e7e:	fbe5                	bnez	a5,1e6e <strcmp>
    1e80:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1e82:	9d19                	subw	a0,a0,a4
    1e84:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1e86:	0007851b          	sext.w	a0,a5
    1e8a:	bfe5                	j	1e82 <strcmp+0x14>

0000000000001e8c <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1e8c:	ca15                	beqz	a2,1ec0 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1e8e:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1e92:	167d                	addi	a2,a2,-1
    1e94:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1e98:	eb99                	bnez	a5,1eae <strncmp+0x22>
    1e9a:	a815                	j	1ece <strncmp+0x42>
    1e9c:	00a68e63          	beq	a3,a0,1eb8 <strncmp+0x2c>
    1ea0:	0505                	addi	a0,a0,1
    1ea2:	00f71b63          	bne	a4,a5,1eb8 <strncmp+0x2c>
    1ea6:	00054783          	lbu	a5,0(a0)
    1eaa:	cf89                	beqz	a5,1ec4 <strncmp+0x38>
    1eac:	85b2                	mv	a1,a2
    1eae:	0005c703          	lbu	a4,0(a1)
    1eb2:	00158613          	addi	a2,a1,1
    1eb6:	f37d                	bnez	a4,1e9c <strncmp+0x10>
		;
	return *l - *r;
    1eb8:	0007851b          	sext.w	a0,a5
    1ebc:	9d19                	subw	a0,a0,a4
    1ebe:	8082                	ret
		return 0;
    1ec0:	4501                	li	a0,0
}
    1ec2:	8082                	ret
	return *l - *r;
    1ec4:	0015c703          	lbu	a4,1(a1)
    1ec8:	4501                	li	a0,0
    1eca:	9d19                	subw	a0,a0,a4
    1ecc:	8082                	ret
    1ece:	0005c703          	lbu	a4,0(a1)
    1ed2:	4501                	li	a0,0
    1ed4:	b7e5                	j	1ebc <strncmp+0x30>

0000000000001ed6 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1ed6:	00757793          	andi	a5,a0,7
    1eda:	cf89                	beqz	a5,1ef4 <strlen+0x1e>
    1edc:	87aa                	mv	a5,a0
    1ede:	a029                	j	1ee8 <strlen+0x12>
    1ee0:	0785                	addi	a5,a5,1
    1ee2:	0077f713          	andi	a4,a5,7
    1ee6:	cb01                	beqz	a4,1ef6 <strlen+0x20>
		if (!*s)
    1ee8:	0007c703          	lbu	a4,0(a5)
    1eec:	fb75                	bnez	a4,1ee0 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1eee:	40a78533          	sub	a0,a5,a0
}
    1ef2:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1ef4:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1ef6:	6394                	ld	a3,0(a5)
    1ef8:	00001597          	auipc	a1,0x1
    1efc:	8b05b583          	ld	a1,-1872(a1) # 27a8 <enable_deadlock_detect+0x134>
    1f00:	00001617          	auipc	a2,0x1
    1f04:	8b063603          	ld	a2,-1872(a2) # 27b0 <enable_deadlock_detect+0x13c>
    1f08:	a019                	j	1f0e <strlen+0x38>
    1f0a:	6794                	ld	a3,8(a5)
    1f0c:	07a1                	addi	a5,a5,8
    1f0e:	00b68733          	add	a4,a3,a1
    1f12:	fff6c693          	not	a3,a3
    1f16:	8f75                	and	a4,a4,a3
    1f18:	8f71                	and	a4,a4,a2
    1f1a:	db65                	beqz	a4,1f0a <strlen+0x34>
	for (; *s; s++)
    1f1c:	0007c703          	lbu	a4,0(a5)
    1f20:	d779                	beqz	a4,1eee <strlen+0x18>
    1f22:	0017c703          	lbu	a4,1(a5)
    1f26:	0785                	addi	a5,a5,1
    1f28:	d379                	beqz	a4,1eee <strlen+0x18>
    1f2a:	0017c703          	lbu	a4,1(a5)
    1f2e:	0785                	addi	a5,a5,1
    1f30:	fb6d                	bnez	a4,1f22 <strlen+0x4c>
    1f32:	bf75                	j	1eee <strlen+0x18>

0000000000001f34 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f34:	00757713          	andi	a4,a0,7
{
    1f38:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f3a:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f3e:	cb19                	beqz	a4,1f54 <memchr+0x20>
    1f40:	ce25                	beqz	a2,1fb8 <memchr+0x84>
    1f42:	0007c703          	lbu	a4,0(a5)
    1f46:	04b70e63          	beq	a4,a1,1fa2 <memchr+0x6e>
    1f4a:	0785                	addi	a5,a5,1
    1f4c:	0077f713          	andi	a4,a5,7
    1f50:	167d                	addi	a2,a2,-1
    1f52:	f77d                	bnez	a4,1f40 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f54:	4501                	li	a0,0
	if (n && *s != c) {
    1f56:	c235                	beqz	a2,1fba <memchr+0x86>
    1f58:	0007c703          	lbu	a4,0(a5)
    1f5c:	04b70363          	beq	a4,a1,1fa2 <memchr+0x6e>
		size_t k = ONES * c;
    1f60:	00001517          	auipc	a0,0x1
    1f64:	85853503          	ld	a0,-1960(a0) # 27b8 <enable_deadlock_detect+0x144>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f68:	471d                	li	a4,7
		size_t k = ONES * c;
    1f6a:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f6e:	02c77a63          	bgeu	a4,a2,1fa2 <memchr+0x6e>
    1f72:	00001897          	auipc	a7,0x1
    1f76:	8368b883          	ld	a7,-1994(a7) # 27a8 <enable_deadlock_detect+0x134>
    1f7a:	00001817          	auipc	a6,0x1
    1f7e:	83683803          	ld	a6,-1994(a6) # 27b0 <enable_deadlock_detect+0x13c>
    1f82:	431d                	li	t1,7
    1f84:	a029                	j	1f8e <memchr+0x5a>
		     w++, n -= SS)
    1f86:	1661                	addi	a2,a2,-8
    1f88:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f8a:	02c37963          	bgeu	t1,a2,1fbc <memchr+0x88>
    1f8e:	6398                	ld	a4,0(a5)
    1f90:	8f29                	xor	a4,a4,a0
    1f92:	011706b3          	add	a3,a4,a7
    1f96:	fff74713          	not	a4,a4
    1f9a:	8f75                	and	a4,a4,a3
    1f9c:	01077733          	and	a4,a4,a6
    1fa0:	d37d                	beqz	a4,1f86 <memchr+0x52>
{
    1fa2:	853e                	mv	a0,a5
    1fa4:	97b2                	add	a5,a5,a2
    1fa6:	a021                	j	1fae <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fa8:	0505                	addi	a0,a0,1
    1faa:	00f50763          	beq	a0,a5,1fb8 <memchr+0x84>
    1fae:	00054703          	lbu	a4,0(a0)
    1fb2:	feb71be3          	bne	a4,a1,1fa8 <memchr+0x74>
    1fb6:	8082                	ret
	return n ? (void *)s : 0;
    1fb8:	4501                	li	a0,0
}
    1fba:	8082                	ret
	return n ? (void *)s : 0;
    1fbc:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1fbe:	f275                	bnez	a2,1fa2 <memchr+0x6e>
}
    1fc0:	8082                	ret

0000000000001fc2 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1fc2:	1101                	addi	sp,sp,-32
    1fc4:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1fc6:	862e                	mv	a2,a1
{
    1fc8:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    1fca:	4581                	li	a1,0
{
    1fcc:	e426                	sd	s1,8(sp)
    1fce:	ec06                	sd	ra,24(sp)
    1fd0:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    1fd2:	f63ff0ef          	jal	ra,1f34 <memchr>
	return p ? p - s : n;
    1fd6:	c519                	beqz	a0,1fe4 <strnlen+0x22>
}
    1fd8:	60e2                	ld	ra,24(sp)
    1fda:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    1fdc:	8d05                	sub	a0,a0,s1
}
    1fde:	64a2                	ld	s1,8(sp)
    1fe0:	6105                	addi	sp,sp,32
    1fe2:	8082                	ret
    1fe4:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    1fe6:	8522                	mv	a0,s0
}
    1fe8:	6442                	ld	s0,16(sp)
    1fea:	64a2                	ld	s1,8(sp)
    1fec:	6105                	addi	sp,sp,32
    1fee:	8082                	ret

0000000000001ff0 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    1ff0:	00a5c7b3          	xor	a5,a1,a0
    1ff4:	8b9d                	andi	a5,a5,7
    1ff6:	eb95                	bnez	a5,202a <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    1ff8:	0075f793          	andi	a5,a1,7
    1ffc:	e7b1                	bnez	a5,2048 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    1ffe:	6198                	ld	a4,0(a1)
    2000:	00000617          	auipc	a2,0x0
    2004:	7a863603          	ld	a2,1960(a2) # 27a8 <enable_deadlock_detect+0x134>
    2008:	00000817          	auipc	a6,0x0
    200c:	7a883803          	ld	a6,1960(a6) # 27b0 <enable_deadlock_detect+0x13c>
    2010:	a029                	j	201a <stpcpy+0x2a>
    2012:	05a1                	addi	a1,a1,8
    2014:	e118                	sd	a4,0(a0)
    2016:	6198                	ld	a4,0(a1)
    2018:	0521                	addi	a0,a0,8
    201a:	00c707b3          	add	a5,a4,a2
    201e:	fff74693          	not	a3,a4
    2022:	8ff5                	and	a5,a5,a3
    2024:	0107f7b3          	and	a5,a5,a6
    2028:	d7ed                	beqz	a5,2012 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    202a:	0005c783          	lbu	a5,0(a1)
    202e:	00f50023          	sb	a5,0(a0)
    2032:	c785                	beqz	a5,205a <stpcpy+0x6a>
    2034:	0015c783          	lbu	a5,1(a1)
    2038:	0505                	addi	a0,a0,1
    203a:	0585                	addi	a1,a1,1
    203c:	00f50023          	sb	a5,0(a0)
    2040:	fbf5                	bnez	a5,2034 <stpcpy+0x44>
		;
	return d;
}
    2042:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2044:	0505                	addi	a0,a0,1
    2046:	df45                	beqz	a4,1ffe <stpcpy+0xe>
			if (!(*d = *s))
    2048:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    204c:	0585                	addi	a1,a1,1
    204e:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2052:	00f50023          	sb	a5,0(a0)
    2056:	f7fd                	bnez	a5,2044 <stpcpy+0x54>
}
    2058:	8082                	ret
    205a:	8082                	ret

000000000000205c <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    205c:	00a5c7b3          	xor	a5,a1,a0
    2060:	8b9d                	andi	a5,a5,7
    2062:	1a079863          	bnez	a5,2212 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2066:	0075f793          	andi	a5,a1,7
    206a:	16078463          	beqz	a5,21d2 <stpncpy+0x176>
    206e:	ea01                	bnez	a2,207e <stpncpy+0x22>
    2070:	a421                	j	2278 <stpncpy+0x21c>
    2072:	167d                	addi	a2,a2,-1
    2074:	0505                	addi	a0,a0,1
    2076:	14070e63          	beqz	a4,21d2 <stpncpy+0x176>
    207a:	1a060863          	beqz	a2,222a <stpncpy+0x1ce>
    207e:	0005c783          	lbu	a5,0(a1)
    2082:	0585                	addi	a1,a1,1
    2084:	0075f713          	andi	a4,a1,7
    2088:	00f50023          	sb	a5,0(a0)
    208c:	f3fd                	bnez	a5,2072 <stpncpy+0x16>
    208e:	4805                	li	a6,1
    2090:	1a061863          	bnez	a2,2240 <stpncpy+0x1e4>
    2094:	40a007b3          	neg	a5,a0
    2098:	8b9d                	andi	a5,a5,7
    209a:	4681                	li	a3,0
    209c:	18061a63          	bnez	a2,2230 <stpncpy+0x1d4>
    20a0:	00778713          	addi	a4,a5,7
    20a4:	45ad                	li	a1,11
    20a6:	18b76363          	bltu	a4,a1,222c <stpncpy+0x1d0>
    20aa:	1ae6eb63          	bltu	a3,a4,2260 <stpncpy+0x204>
    20ae:	1a078363          	beqz	a5,2254 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20b2:	00050023          	sb	zero,0(a0)
    20b6:	4685                	li	a3,1
    20b8:	00150713          	addi	a4,a0,1
    20bc:	18d78f63          	beq	a5,a3,225a <stpncpy+0x1fe>
    20c0:	000500a3          	sb	zero,1(a0)
    20c4:	4689                	li	a3,2
    20c6:	00250713          	addi	a4,a0,2
    20ca:	18d78e63          	beq	a5,a3,2266 <stpncpy+0x20a>
    20ce:	00050123          	sb	zero,2(a0)
    20d2:	468d                	li	a3,3
    20d4:	00350713          	addi	a4,a0,3
    20d8:	16d78c63          	beq	a5,a3,2250 <stpncpy+0x1f4>
    20dc:	000501a3          	sb	zero,3(a0)
    20e0:	4691                	li	a3,4
    20e2:	00450713          	addi	a4,a0,4
    20e6:	18d78263          	beq	a5,a3,226a <stpncpy+0x20e>
    20ea:	00050223          	sb	zero,4(a0)
    20ee:	4695                	li	a3,5
    20f0:	00550713          	addi	a4,a0,5
    20f4:	16d78d63          	beq	a5,a3,226e <stpncpy+0x212>
    20f8:	000502a3          	sb	zero,5(a0)
    20fc:	469d                	li	a3,7
    20fe:	00650713          	addi	a4,a0,6
    2102:	16d79863          	bne	a5,a3,2272 <stpncpy+0x216>
    2106:	00750713          	addi	a4,a0,7
    210a:	00050323          	sb	zero,6(a0)
    210e:	40f80833          	sub	a6,a6,a5
    2112:	ff887593          	andi	a1,a6,-8
    2116:	97aa                	add	a5,a5,a0
    2118:	95be                	add	a1,a1,a5
    211a:	0007b023          	sd	zero,0(a5)
    211e:	07a1                	addi	a5,a5,8
    2120:	feb79de3          	bne	a5,a1,211a <stpncpy+0xbe>
    2124:	ff887593          	andi	a1,a6,-8
    2128:	9ead                	addw	a3,a3,a1
    212a:	00b707b3          	add	a5,a4,a1
    212e:	12b80863          	beq	a6,a1,225e <stpncpy+0x202>
    2132:	00078023          	sb	zero,0(a5)
    2136:	0016871b          	addiw	a4,a3,1
    213a:	0ec77863          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    213e:	000780a3          	sb	zero,1(a5)
    2142:	0026871b          	addiw	a4,a3,2
    2146:	0ec77263          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    214a:	00078123          	sb	zero,2(a5)
    214e:	0036871b          	addiw	a4,a3,3
    2152:	0cc77c63          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    2156:	000781a3          	sb	zero,3(a5)
    215a:	0046871b          	addiw	a4,a3,4
    215e:	0cc77663          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    2162:	00078223          	sb	zero,4(a5)
    2166:	0056871b          	addiw	a4,a3,5
    216a:	0cc77063          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    216e:	000782a3          	sb	zero,5(a5)
    2172:	0066871b          	addiw	a4,a3,6
    2176:	0ac77a63          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    217a:	00078323          	sb	zero,6(a5)
    217e:	0076871b          	addiw	a4,a3,7
    2182:	0ac77463          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    2186:	000783a3          	sb	zero,7(a5)
    218a:	0086871b          	addiw	a4,a3,8
    218e:	08c77e63          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    2192:	00078423          	sb	zero,8(a5)
    2196:	0096871b          	addiw	a4,a3,9
    219a:	08c77863          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    219e:	000784a3          	sb	zero,9(a5)
    21a2:	00a6871b          	addiw	a4,a3,10
    21a6:	08c77263          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    21aa:	00078523          	sb	zero,10(a5)
    21ae:	00b6871b          	addiw	a4,a3,11
    21b2:	06c77c63          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    21b6:	000785a3          	sb	zero,11(a5)
    21ba:	00c6871b          	addiw	a4,a3,12
    21be:	06c77663          	bgeu	a4,a2,222a <stpncpy+0x1ce>
    21c2:	00078623          	sb	zero,12(a5)
    21c6:	26b5                	addiw	a3,a3,13
    21c8:	06c6f163          	bgeu	a3,a2,222a <stpncpy+0x1ce>
    21cc:	000786a3          	sb	zero,13(a5)
    21d0:	8082                	ret
			;
		if (!n || !*s)
    21d2:	c645                	beqz	a2,227a <stpncpy+0x21e>
    21d4:	0005c783          	lbu	a5,0(a1)
    21d8:	ea078be3          	beqz	a5,208e <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    21dc:	479d                	li	a5,7
    21de:	02c7ff63          	bgeu	a5,a2,221c <stpncpy+0x1c0>
    21e2:	00000897          	auipc	a7,0x0
    21e6:	5c68b883          	ld	a7,1478(a7) # 27a8 <enable_deadlock_detect+0x134>
    21ea:	00000817          	auipc	a6,0x0
    21ee:	5c683803          	ld	a6,1478(a6) # 27b0 <enable_deadlock_detect+0x13c>
    21f2:	431d                	li	t1,7
    21f4:	6198                	ld	a4,0(a1)
    21f6:	011707b3          	add	a5,a4,a7
    21fa:	fff74693          	not	a3,a4
    21fe:	8ff5                	and	a5,a5,a3
    2200:	0107f7b3          	and	a5,a5,a6
    2204:	ef81                	bnez	a5,221c <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2206:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2208:	1661                	addi	a2,a2,-8
    220a:	05a1                	addi	a1,a1,8
    220c:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    220e:	fec363e3          	bltu	t1,a2,21f4 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2212:	e609                	bnez	a2,221c <stpncpy+0x1c0>
    2214:	a08d                	j	2276 <stpncpy+0x21a>
    2216:	167d                	addi	a2,a2,-1
    2218:	0505                	addi	a0,a0,1
    221a:	ca01                	beqz	a2,222a <stpncpy+0x1ce>
    221c:	0005c783          	lbu	a5,0(a1)
    2220:	0585                	addi	a1,a1,1
    2222:	00f50023          	sb	a5,0(a0)
    2226:	fbe5                	bnez	a5,2216 <stpncpy+0x1ba>
		;
tail:
    2228:	b59d                	j	208e <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    222a:	8082                	ret
    222c:	472d                	li	a4,11
    222e:	bdb5                	j	20aa <stpncpy+0x4e>
    2230:	00778713          	addi	a4,a5,7
    2234:	45ad                	li	a1,11
    2236:	fff60693          	addi	a3,a2,-1
    223a:	e6b778e3          	bgeu	a4,a1,20aa <stpncpy+0x4e>
    223e:	b7fd                	j	222c <stpncpy+0x1d0>
    2240:	40a007b3          	neg	a5,a0
    2244:	8832                	mv	a6,a2
    2246:	8b9d                	andi	a5,a5,7
    2248:	4681                	li	a3,0
    224a:	e4060be3          	beqz	a2,20a0 <stpncpy+0x44>
    224e:	b7cd                	j	2230 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2250:	468d                	li	a3,3
    2252:	bd75                	j	210e <stpncpy+0xb2>
    2254:	872a                	mv	a4,a0
    2256:	4681                	li	a3,0
    2258:	bd5d                	j	210e <stpncpy+0xb2>
    225a:	4685                	li	a3,1
    225c:	bd4d                	j	210e <stpncpy+0xb2>
    225e:	8082                	ret
    2260:	87aa                	mv	a5,a0
    2262:	4681                	li	a3,0
    2264:	b5f9                	j	2132 <stpncpy+0xd6>
    2266:	4689                	li	a3,2
    2268:	b55d                	j	210e <stpncpy+0xb2>
    226a:	4691                	li	a3,4
    226c:	b54d                	j	210e <stpncpy+0xb2>
    226e:	4695                	li	a3,5
    2270:	bd79                	j	210e <stpncpy+0xb2>
    2272:	4699                	li	a3,6
    2274:	bd69                	j	210e <stpncpy+0xb2>
    2276:	8082                	ret
    2278:	8082                	ret
    227a:	8082                	ret

000000000000227c <basename>:

char *basename(char *s)
{
    227c:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    227e:	c54d                	beqz	a0,2328 <basename+0xac>
    2280:	00054783          	lbu	a5,0(a0)
		return ".";
    2284:	00000517          	auipc	a0,0x0
    2288:	51c50513          	addi	a0,a0,1308 # 27a0 <enable_deadlock_detect+0x12c>
	if (!s || !*s)
    228c:	e391                	bnez	a5,2290 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    228e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2290:	0076f713          	andi	a4,a3,7
    2294:	87b6                	mv	a5,a3
    2296:	cf51                	beqz	a4,2332 <basename+0xb6>
    2298:	0785                	addi	a5,a5,1
    229a:	0077f713          	andi	a4,a5,7
    229e:	c729                	beqz	a4,22e8 <basename+0x6c>
		if (!*s)
    22a0:	0007c703          	lbu	a4,0(a5)
    22a4:	fb75                	bnez	a4,2298 <basename+0x1c>
	return s - a;
    22a6:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22a8:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22aa:	cf8d                	beqz	a5,22e4 <basename+0x68>
    22ac:	00f68733          	add	a4,a3,a5
    22b0:	02f00593          	li	a1,47
    22b4:	a031                	j	22c0 <basename+0x44>
		s[i] = 0;
    22b6:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22ba:	17fd                	addi	a5,a5,-1
    22bc:	177d                	addi	a4,a4,-1
    22be:	c39d                	beqz	a5,22e4 <basename+0x68>
    22c0:	00074603          	lbu	a2,0(a4)
    22c4:	feb609e3          	beq	a2,a1,22b6 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22c8:	02f00613          	li	a2,47
    22cc:	a011                	j	22d0 <basename+0x54>
    22ce:	cb99                	beqz	a5,22e4 <basename+0x68>
    22d0:	853e                	mv	a0,a5
    22d2:	17fd                	addi	a5,a5,-1
    22d4:	00f68733          	add	a4,a3,a5
    22d8:	00074703          	lbu	a4,0(a4)
    22dc:	fec719e3          	bne	a4,a2,22ce <basename+0x52>
	return s + i;
    22e0:	9536                	add	a0,a0,a3
    22e2:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    22e4:	8536                	mv	a0,a3
    22e6:	8082                	ret
    22e8:	6390                	ld	a2,0(a5)
    22ea:	00000517          	auipc	a0,0x0
    22ee:	4be53503          	ld	a0,1214(a0) # 27a8 <enable_deadlock_detect+0x134>
    22f2:	00000597          	auipc	a1,0x0
    22f6:	4be5b583          	ld	a1,1214(a1) # 27b0 <enable_deadlock_detect+0x13c>
    22fa:	fff64713          	not	a4,a2
    22fe:	962a                	add	a2,a2,a0
    2300:	8f71                	and	a4,a4,a2
    2302:	8f6d                	and	a4,a4,a1
    2304:	eb11                	bnez	a4,2318 <basename+0x9c>
    2306:	6790                	ld	a2,8(a5)
    2308:	07a1                	addi	a5,a5,8
    230a:	00a60733          	add	a4,a2,a0
    230e:	fff64613          	not	a2,a2
    2312:	8f71                	and	a4,a4,a2
    2314:	8f6d                	and	a4,a4,a1
    2316:	db65                	beqz	a4,2306 <basename+0x8a>
	for (; *s; s++)
    2318:	0007c703          	lbu	a4,0(a5)
    231c:	d749                	beqz	a4,22a6 <basename+0x2a>
    231e:	0017c703          	lbu	a4,1(a5)
    2322:	0785                	addi	a5,a5,1
    2324:	ff6d                	bnez	a4,231e <basename+0xa2>
    2326:	b741                	j	22a6 <basename+0x2a>
		return ".";
    2328:	00000517          	auipc	a0,0x0
    232c:	47850513          	addi	a0,a0,1144 # 27a0 <enable_deadlock_detect+0x12c>
    2330:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2332:	6290                	ld	a2,0(a3)
    2334:	00000517          	auipc	a0,0x0
    2338:	47453503          	ld	a0,1140(a0) # 27a8 <enable_deadlock_detect+0x134>
    233c:	00000597          	auipc	a1,0x0
    2340:	4745b583          	ld	a1,1140(a1) # 27b0 <enable_deadlock_detect+0x13c>
    2344:	fff64713          	not	a4,a2
    2348:	962a                	add	a2,a2,a0
    234a:	8f71                	and	a4,a4,a2
    234c:	8f6d                	and	a4,a4,a1
    234e:	df45                	beqz	a4,2306 <basename+0x8a>
    2350:	b7f9                	j	231e <basename+0xa2>

0000000000002352 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2352:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2356:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2358:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    235c:	2501                	sext.w	a0,a0
    235e:	8082                	ret

0000000000002360 <close>:

int close(int fd)
{
	if (fd == 1) {
    2360:	4785                	li	a5,1
    2362:	00f50863          	beq	a0,a5,2372 <close+0x12>
	register long a7 __asm__("a7") = n;
    2366:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    236a:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    236e:	2501                	sext.w	a0,a0
    2370:	8082                	ret
{
    2372:	1101                	addi	sp,sp,-32
    2374:	ec06                	sd	ra,24(sp)
    2376:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2378:	cdffe0ef          	jal	ra,1056 <__write_buffer>
		__clear_buffer();
    237c:	d03fe0ef          	jal	ra,107e <__clear_buffer>
    2380:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2382:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2386:	00000073          	ecall
}
    238a:	60e2                	ld	ra,24(sp)
    238c:	2501                	sext.w	a0,a0
    238e:	6105                	addi	sp,sp,32
    2390:	8082                	ret

0000000000002392 <read>:
	register long a7 __asm__("a7") = n;
    2392:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2396:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    239a:	8082                	ret

000000000000239c <write>:
	register long a7 __asm__("a7") = n;
    239c:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23a0:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23a4:	8082                	ret

00000000000023a6 <getpid>:
	register long a7 __asm__("a7") = n;
    23a6:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23aa:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23ae:	2501                	sext.w	a0,a0
    23b0:	8082                	ret

00000000000023b2 <getppid>:
	register long a7 __asm__("a7") = n;
    23b2:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23b6:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23ba:	2501                	sext.w	a0,a0
    23bc:	8082                	ret

00000000000023be <sched_yield>:
	register long a7 __asm__("a7") = n;
    23be:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23c2:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23c6:	2501                	sext.w	a0,a0
    23c8:	8082                	ret

00000000000023ca <fork>:
	register long a7 __asm__("a7") = n;
    23ca:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    23ce:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    23d2:	2501                	sext.w	a0,a0
    23d4:	8082                	ret

00000000000023d6 <exit>:

void exit(int code)
{
    23d6:	1141                	addi	sp,sp,-16
    23d8:	e406                	sd	ra,8(sp)
    23da:	e022                	sd	s0,0(sp)
    23dc:	842a                	mv	s0,a0
	__write_buffer();
    23de:	c79fe0ef          	jal	ra,1056 <__write_buffer>
	__clear_buffer();
    23e2:	c9dfe0ef          	jal	ra,107e <__clear_buffer>
	register long a7 __asm__("a7") = n;
    23e6:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    23ea:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    23ec:	00000073          	ecall
	syscall(SYS_exit, code);
}
    23f0:	60a2                	ld	ra,8(sp)
    23f2:	6402                	ld	s0,0(sp)
    23f4:	0141                	addi	sp,sp,16
    23f6:	8082                	ret

00000000000023f8 <waitpid>:
	register long a7 __asm__("a7") = n;
    23f8:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    23fc:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2400:	2501                	sext.w	a0,a0
    2402:	8082                	ret

0000000000002404 <exec>:
	register long a7 __asm__("a7") = n;
    2404:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2408:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    240c:	2501                	sext.w	a0,a0
    240e:	8082                	ret

0000000000002410 <get_mtime>:

int64 get_mtime()
{
    2410:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2412:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2416:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2418:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    241a:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    241e:	2501                	sext.w	a0,a0
    2420:	ed01                	bnez	a0,2438 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2422:	6722                	ld	a4,8(sp)
    2424:	3e800793          	li	a5,1000
    2428:	6682                	ld	a3,0(sp)
    242a:	02f75733          	divu	a4,a4,a5
    242e:	02d78533          	mul	a0,a5,a3
    2432:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2434:	0141                	addi	sp,sp,16
    2436:	8082                	ret
	return -1;
    2438:	557d                	li	a0,-1
    243a:	bfed                	j	2434 <get_mtime+0x24>

000000000000243c <sys_get_time>:
	register long a7 __asm__("a7") = n;
    243c:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2440:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2444:	2501                	sext.w	a0,a0
    2446:	8082                	ret

0000000000002448 <sleep>:

int sleep(unsigned long long time)
{
    2448:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    244a:	880a                	mv	a6,sp
{
    244c:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    244e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2452:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2454:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2456:	00000073          	ecall
	if (err == 0) {
    245a:	2501                	sext.w	a0,a0
    245c:	ed31                	bnez	a0,24b8 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    245e:	6722                	ld	a4,8(sp)
    2460:	3e800793          	li	a5,1000
    2464:	6682                	ld	a3,0(sp)
    2466:	02f75733          	divu	a4,a4,a5
    246a:	02d787b3          	mul	a5,a5,a3
    246e:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2470:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2474:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2476:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2478:	00000073          	ecall
	if (err == 0) {
    247c:	2501                	sext.w	a0,a0
    247e:	e915                	bnez	a0,24b2 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2480:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2482:	3e800693          	li	a3,1000
    2486:	a819                	j	249c <sleep+0x54>
	__asm_syscall("r"(a7))
    2488:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    248c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2490:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2492:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2494:	00000073          	ecall
	if (err == 0) {
    2498:	2501                	sext.w	a0,a0
    249a:	ed01                	bnez	a0,24b2 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    249c:	6722                	ld	a4,8(sp)
    249e:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24a0:	07c00893          	li	a7,124
    24a4:	02d75733          	divu	a4,a4,a3
    24a8:	02f687b3          	mul	a5,a3,a5
    24ac:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24ae:	fcc7ede3          	bltu	a5,a2,2488 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24b2:	4501                	li	a0,0
    24b4:	0141                	addi	sp,sp,16
    24b6:	8082                	ret
    24b8:	57fd                	li	a5,-1
    24ba:	bf5d                	j	2470 <sleep+0x28>

00000000000024bc <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24bc:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24c0:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24c4:	2501                	sext.w	a0,a0
    24c6:	8082                	ret

00000000000024c8 <set_priority>:
	register long a7 __asm__("a7") = n;
    24c8:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    24cc:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    24d0:	2501                	sext.w	a0,a0
    24d2:	8082                	ret

00000000000024d4 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    24d4:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    24d8:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    24dc:	2501                	sext.w	a0,a0
    24de:	8082                	ret

00000000000024e0 <munmap>:
	register long a7 __asm__("a7") = n;
    24e0:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e4:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    24e8:	2501                	sext.w	a0,a0
    24ea:	8082                	ret

00000000000024ec <wait>:

int wait(int *code)
{
    24ec:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    24ee:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    24f2:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24f4:	00000073          	ecall
	return waitpid(-1, code);
}
    24f8:	2501                	sext.w	a0,a0
    24fa:	8082                	ret

00000000000024fc <spawn>:
	register long a7 __asm__("a7") = n;
    24fc:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2500:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2504:	2501                	sext.w	a0,a0
    2506:	8082                	ret

0000000000002508 <pipe>:
	register long a7 __asm__("a7") = n;
    2508:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    250c:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2510:	2501                	sext.w	a0,a0
    2512:	8082                	ret

0000000000002514 <mailread>:
	register long a7 __asm__("a7") = n;
    2514:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2518:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    251c:	2501                	sext.w	a0,a0
    251e:	8082                	ret

0000000000002520 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2520:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2524:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2528:	2501                	sext.w	a0,a0
    252a:	8082                	ret

000000000000252c <fstat>:
	register long a7 __asm__("a7") = n;
    252c:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2530:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2534:	2501                	sext.w	a0,a0
    2536:	8082                	ret

0000000000002538 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2538:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    253a:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    253e:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2540:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2544:	2501                	sext.w	a0,a0
    2546:	8082                	ret

0000000000002548 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2548:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    254a:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    254e:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2550:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2554:	2501                	sext.w	a0,a0
    2556:	8082                	ret

0000000000002558 <link>:

int link(char *old_path, char *new_path)
{
    2558:	87aa                	mv	a5,a0
    255a:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    255c:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2560:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2564:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2566:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    256a:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    256c:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2570:	2501                	sext.w	a0,a0
    2572:	8082                	ret

0000000000002574 <unlink>:

int unlink(char *path)
{
    2574:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2576:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    257a:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    257e:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2580:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2584:	2501                	sext.w	a0,a0
    2586:	8082                	ret

0000000000002588 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2588:	00000797          	auipc	a5,0x0
    258c:	3687b783          	ld	a5,872(a5) # 28f0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2590:	439c                	lw	a5,0(a5)
    2592:	c799                	beqz	a5,25a0 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2594:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2598:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    259c:	2501                	sext.w	a0,a0
    259e:	8082                	ret
{
    25a0:	1101                	addi	sp,sp,-32
    25a2:	ec06                	sd	ra,24(sp)
    25a4:	e42e                	sd	a1,8(sp)
    25a6:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25a8:	fe7fe0ef          	jal	ra,158e <enable_thread_io_buffer>
    25ac:	65a2                	ld	a1,8(sp)
    25ae:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25b0:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25b4:	00000073          	ecall
}
    25b8:	60e2                	ld	ra,24(sp)
    25ba:	2501                	sext.w	a0,a0
    25bc:	6105                	addi	sp,sp,32
    25be:	8082                	ret

00000000000025c0 <gettid>:
	register long a7 __asm__("a7") = n;
    25c0:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25c4:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret

00000000000025cc <waittid>:

int waittid(int tid)
{
    25cc:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    25ce:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    25d2:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    25d6:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    25d8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    25da:	00e51e63          	bne	a0,a4,25f6 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    25de:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25e2:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25e6:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    25ea:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    25ec:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    25f0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    25f2:	fee506e3          	beq	a0,a4,25de <waittid+0x12>
	}
	return ret;
}
    25f6:	8082                	ret

00000000000025f8 <mutex_create>:
	register long a7 __asm__("a7") = n;
    25f8:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    25fc:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    25fe:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2602:	2501                	sext.w	a0,a0
    2604:	8082                	ret

0000000000002606 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2606:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    260a:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    260c:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2610:	2501                	sext.w	a0,a0
    2612:	8082                	ret

0000000000002614 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2614:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2618:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    261c:	2501                	sext.w	a0,a0
    261e:	8082                	ret

0000000000002620 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2620:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2624:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2628:	2501                	sext.w	a0,a0
    262a:	8082                	ret

000000000000262c <semaphore_create>:
	register long a7 __asm__("a7") = n;
    262c:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2630:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2634:	2501                	sext.w	a0,a0
    2636:	8082                	ret

0000000000002638 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2638:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    263c:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2640:	2501                	sext.w	a0,a0
    2642:	8082                	ret

0000000000002644 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2644:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2648:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    264c:	2501                	sext.w	a0,a0
    264e:	8082                	ret

0000000000002650 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2650:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2654:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2658:	2501                	sext.w	a0,a0
    265a:	8082                	ret

000000000000265c <condvar_signal>:
	register long a7 __asm__("a7") = n;
    265c:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2660:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2664:	2501                	sext.w	a0,a0
    2666:	8082                	ret

0000000000002668 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2668:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266c:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2674:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2678:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret
