
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch2b_exit:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a819                	j	1016 <__start_main>

0000000000001002 <main>:
const int MAGIC = 1234;

/// 正确输出： 不输出 FAIL，以 1234 退出

int main()
{
    1002:	1141                	addi	sp,sp,-16
	exit(MAGIC);
    1004:	4d200513          	li	a0,1234
{
    1008:	e406                	sd	ra,8(sp)
	exit(MAGIC);
    100a:	0a4000ef          	jal	ra,10ae <exit>
	return 0;
}
    100e:	60a2                	ld	ra,8(sp)
    1010:	4501                	li	a0,0
    1012:	0141                	addi	sp,sp,16
    1014:	8082                	ret

0000000000001016 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1016:	1141                	addi	sp,sp,-16
    1018:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    101a:	fe9ff0ef          	jal	ra,1002 <main>
    101e:	090000ef          	jal	ra,10ae <exit>
	return 0;
    1022:	60a2                	ld	ra,8(sp)
    1024:	4501                	li	a0,0
    1026:	0141                	addi	sp,sp,16
    1028:	8082                	ret

000000000000102a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    102a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    102e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1030:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    1034:	2501                	sext.w	a0,a0
    1036:	8082                	ret

0000000000001038 <close>:

int close(int fd)
{
	if (fd == 1) {
    1038:	4785                	li	a5,1
    103a:	00f50863          	beq	a0,a5,104a <close+0x12>
	register long a7 __asm__("a7") = n;
    103e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1042:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    1046:	2501                	sext.w	a0,a0
    1048:	8082                	ret
{
    104a:	1101                	addi	sp,sp,-32
    104c:	ec06                	sd	ra,24(sp)
    104e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    1050:	330000ef          	jal	ra,1380 <__write_buffer>
		__clear_buffer();
    1054:	354000ef          	jal	ra,13a8 <__clear_buffer>
    1058:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    105a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    105e:	00000073          	ecall
}
    1062:	60e2                	ld	ra,24(sp)
    1064:	2501                	sext.w	a0,a0
    1066:	6105                	addi	sp,sp,32
    1068:	8082                	ret

000000000000106a <read>:
	register long a7 __asm__("a7") = n;
    106a:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    106e:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    1072:	8082                	ret

0000000000001074 <write>:
	register long a7 __asm__("a7") = n;
    1074:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1078:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    107c:	8082                	ret

000000000000107e <getpid>:
	register long a7 __asm__("a7") = n;
    107e:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    1082:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    1086:	2501                	sext.w	a0,a0
    1088:	8082                	ret

000000000000108a <getppid>:
	register long a7 __asm__("a7") = n;
    108a:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    108e:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    1092:	2501                	sext.w	a0,a0
    1094:	8082                	ret

0000000000001096 <sched_yield>:
	register long a7 __asm__("a7") = n;
    1096:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    109a:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    109e:	2501                	sext.w	a0,a0
    10a0:	8082                	ret

00000000000010a2 <fork>:
	register long a7 __asm__("a7") = n;
    10a2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    10a6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    10aa:	2501                	sext.w	a0,a0
    10ac:	8082                	ret

00000000000010ae <exit>:

void exit(int code)
{
    10ae:	1141                	addi	sp,sp,-16
    10b0:	e406                	sd	ra,8(sp)
    10b2:	e022                	sd	s0,0(sp)
    10b4:	842a                	mv	s0,a0
	__write_buffer();
    10b6:	2ca000ef          	jal	ra,1380 <__write_buffer>
	__clear_buffer();
    10ba:	2ee000ef          	jal	ra,13a8 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    10be:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    10c2:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    10c4:	00000073          	ecall
	syscall(SYS_exit, code);
}
    10c8:	60a2                	ld	ra,8(sp)
    10ca:	6402                	ld	s0,0(sp)
    10cc:	0141                	addi	sp,sp,16
    10ce:	8082                	ret

00000000000010d0 <waitpid>:
	register long a7 __asm__("a7") = n;
    10d0:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10d4:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    10d8:	2501                	sext.w	a0,a0
    10da:	8082                	ret

00000000000010dc <exec>:
	register long a7 __asm__("a7") = n;
    10dc:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10e0:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    10e4:	2501                	sext.w	a0,a0
    10e6:	8082                	ret

00000000000010e8 <get_mtime>:

int64 get_mtime()
{
    10e8:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    10ea:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    10ee:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    10f0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10f2:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    10f6:	2501                	sext.w	a0,a0
    10f8:	ed01                	bnez	a0,1110 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    10fa:	6722                	ld	a4,8(sp)
    10fc:	3e800793          	li	a5,1000
    1100:	6682                	ld	a3,0(sp)
    1102:	02f75733          	divu	a4,a4,a5
    1106:	02d78533          	mul	a0,a5,a3
    110a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    110c:	0141                	addi	sp,sp,16
    110e:	8082                	ret
	return -1;
    1110:	557d                	li	a0,-1
    1112:	bfed                	j	110c <get_mtime+0x24>

0000000000001114 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    1114:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1118:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    111c:	2501                	sext.w	a0,a0
    111e:	8082                	ret

0000000000001120 <sleep>:

int sleep(unsigned long long time)
{
    1120:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    1122:	880a                	mv	a6,sp
{
    1124:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    1126:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    112a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    112c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    112e:	00000073          	ecall
	if (err == 0) {
    1132:	2501                	sext.w	a0,a0
    1134:	ed31                	bnez	a0,1190 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    1136:	6722                	ld	a4,8(sp)
    1138:	3e800793          	li	a5,1000
    113c:	6682                	ld	a3,0(sp)
    113e:	02f75733          	divu	a4,a4,a5
    1142:	02d787b3          	mul	a5,a5,a3
    1146:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    1148:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    114c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    114e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1150:	00000073          	ecall
	if (err == 0) {
    1154:	2501                	sext.w	a0,a0
    1156:	e915                	bnez	a0,118a <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    1158:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    115a:	3e800693          	li	a3,1000
    115e:	a819                	j	1174 <sleep+0x54>
	__asm_syscall("r"(a7))
    1160:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    1164:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1168:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    116a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    116c:	00000073          	ecall
	if (err == 0) {
    1170:	2501                	sext.w	a0,a0
    1172:	ed01                	bnez	a0,118a <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    1174:	6722                	ld	a4,8(sp)
    1176:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    1178:	07c00893          	li	a7,124
    117c:	02d75733          	divu	a4,a4,a3
    1180:	02f687b3          	mul	a5,a3,a5
    1184:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    1186:	fcc7ede3          	bltu	a5,a2,1160 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    118a:	4501                	li	a0,0
    118c:	0141                	addi	sp,sp,16
    118e:	8082                	ret
    1190:	57fd                	li	a5,-1
    1192:	bf5d                	j	1148 <sleep+0x28>

0000000000001194 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    1194:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    1198:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    119c:	2501                	sext.w	a0,a0
    119e:	8082                	ret

00000000000011a0 <set_priority>:
	register long a7 __asm__("a7") = n;
    11a0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    11a4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    11a8:	2501                	sext.w	a0,a0
    11aa:	8082                	ret

00000000000011ac <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    11ac:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    11b0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    11b4:	2501                	sext.w	a0,a0
    11b6:	8082                	ret

00000000000011b8 <munmap>:
	register long a7 __asm__("a7") = n;
    11b8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11bc:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    11c0:	2501                	sext.w	a0,a0
    11c2:	8082                	ret

00000000000011c4 <wait>:

int wait(int *code)
{
    11c4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    11c6:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    11ca:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11cc:	00000073          	ecall
	return waitpid(-1, code);
}
    11d0:	2501                	sext.w	a0,a0
    11d2:	8082                	ret

00000000000011d4 <spawn>:
	register long a7 __asm__("a7") = n;
    11d4:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    11d8:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    11dc:	2501                	sext.w	a0,a0
    11de:	8082                	ret

00000000000011e0 <pipe>:
	register long a7 __asm__("a7") = n;
    11e0:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    11e4:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    11e8:	2501                	sext.w	a0,a0
    11ea:	8082                	ret

00000000000011ec <mailread>:
	register long a7 __asm__("a7") = n;
    11ec:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11f0:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    11f4:	2501                	sext.w	a0,a0
    11f6:	8082                	ret

00000000000011f8 <mailwrite>:
	register long a7 __asm__("a7") = n;
    11f8:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    11fc:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    1200:	2501                	sext.w	a0,a0
    1202:	8082                	ret

0000000000001204 <fstat>:
	register long a7 __asm__("a7") = n;
    1204:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1208:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    120c:	2501                	sext.w	a0,a0
    120e:	8082                	ret

0000000000001210 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    1210:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    1212:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    1216:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1218:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    121c:	2501                	sext.w	a0,a0
    121e:	8082                	ret

0000000000001220 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    1220:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    1222:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    1226:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1228:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    122c:	2501                	sext.w	a0,a0
    122e:	8082                	ret

0000000000001230 <link>:

int link(char *old_path, char *new_path)
{
    1230:	87aa                	mv	a5,a0
    1232:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    1234:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    1238:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    123c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    123e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    1242:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1244:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    1248:	2501                	sext.w	a0,a0
    124a:	8082                	ret

000000000000124c <unlink>:

int unlink(char *path)
{
    124c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    124e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    1252:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    1256:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1258:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    125c:	2501                	sext.w	a0,a0
    125e:	8082                	ret

0000000000001260 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    1260:	00001797          	auipc	a5,0x1
    1264:	6587b783          	ld	a5,1624(a5) # 28b8 <_GLOBAL_OFFSET_TABLE_+0x8>
    1268:	439c                	lw	a5,0(a5)
    126a:	c799                	beqz	a5,1278 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    126c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1270:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    1274:	2501                	sext.w	a0,a0
    1276:	8082                	ret
{
    1278:	1101                	addi	sp,sp,-32
    127a:	ec06                	sd	ra,24(sp)
    127c:	e42e                	sd	a1,8(sp)
    127e:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    1280:	638000ef          	jal	ra,18b8 <enable_thread_io_buffer>
    1284:	65a2                	ld	a1,8(sp)
    1286:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    1288:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    128c:	00000073          	ecall
}
    1290:	60e2                	ld	ra,24(sp)
    1292:	2501                	sext.w	a0,a0
    1294:	6105                	addi	sp,sp,32
    1296:	8082                	ret

0000000000001298 <gettid>:
	register long a7 __asm__("a7") = n;
    1298:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    129c:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    12a0:	2501                	sext.w	a0,a0
    12a2:	8082                	ret

00000000000012a4 <waittid>:

int waittid(int tid)
{
    12a4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    12a6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    12aa:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    12ae:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    12b0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12b2:	00e51e63          	bne	a0,a4,12ce <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    12b6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    12ba:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    12be:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    12c2:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    12c4:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    12c8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12ca:	fee506e3          	beq	a0,a4,12b6 <waittid+0x12>
	}
	return ret;
}
    12ce:	8082                	ret

00000000000012d0 <mutex_create>:
	register long a7 __asm__("a7") = n;
    12d0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12d4:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    12d6:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    12da:	2501                	sext.w	a0,a0
    12dc:	8082                	ret

00000000000012de <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    12de:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12e2:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    12e4:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    12e8:	2501                	sext.w	a0,a0
    12ea:	8082                	ret

00000000000012ec <mutex_lock>:
	register long a7 __asm__("a7") = n;
    12ec:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    12f0:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    12f4:	2501                	sext.w	a0,a0
    12f6:	8082                	ret

00000000000012f8 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    12f8:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    12fc:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    1300:	2501                	sext.w	a0,a0
    1302:	8082                	ret

0000000000001304 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    1304:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    1308:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    130c:	2501                	sext.w	a0,a0
    130e:	8082                	ret

0000000000001310 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    1310:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    1314:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    1318:	2501                	sext.w	a0,a0
    131a:	8082                	ret

000000000000131c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    131c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    1320:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    1324:	2501                	sext.w	a0,a0
    1326:	8082                	ret

0000000000001328 <condvar_create>:
	register long a7 __asm__("a7") = n;
    1328:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    132c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    1330:	2501                	sext.w	a0,a0
    1332:	8082                	ret

0000000000001334 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    1334:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    1338:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    133c:	2501                	sext.w	a0,a0
    133e:	8082                	ret

0000000000001340 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    1340:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1344:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    1348:	2501                	sext.w	a0,a0
    134a:	8082                	ret

000000000000134c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    134c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    1350:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    1354:	2501                	sext.w	a0,a0
    1356:	8082                	ret

0000000000001358 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1358:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    135a:	4605                	li	a2,1
    135c:	00f10593          	addi	a1,sp,15
    1360:	4501                	li	a0,0
{
    1362:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1364:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1368:	d03ff0ef          	jal	ra,106a <read>
    136c:	4785                	li	a5,1
    136e:	00f51763          	bne	a0,a5,137c <getchar+0x24>
		return byte;
    1372:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1376:	60e2                	ld	ra,24(sp)
    1378:	6105                	addi	sp,sp,32
    137a:	8082                	ret
		return EOF;
    137c:	557d                	li	a0,-1
    137e:	bfe5                	j	1376 <getchar+0x1e>

0000000000001380 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1380:	00001517          	auipc	a0,0x1
    1384:	40052503          	lw	a0,1024(a0) # 2780 <buffer_len>
    1388:	e111                	bnez	a0,138c <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    138a:	8082                	ret
{
    138c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    138e:	862a                	mv	a2,a0
    1390:	00001597          	auipc	a1,0x1
    1394:	3f858593          	addi	a1,a1,1016 # 2788 <buffer>
    1398:	4505                	li	a0,1
{
    139a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    139c:	cd9ff0ef          	jal	ra,1074 <write>
}
    13a0:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13a2:	2501                	sext.w	a0,a0
}
    13a4:	0141                	addi	sp,sp,16
    13a6:	8082                	ret

00000000000013a8 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    13a8:	00001797          	auipc	a5,0x1
    13ac:	3c07ac23          	sw	zero,984(a5) # 2780 <buffer_len>
}
    13b0:	8082                	ret

00000000000013b2 <__fflush>:
	if (buffer_len == 0)
    13b2:	00001517          	auipc	a0,0x1
    13b6:	3ce52503          	lw	a0,974(a0) # 2780 <buffer_len>
    13ba:	e511                	bnez	a0,13c6 <__fflush+0x14>
	buffer_len = 0;
    13bc:	00001797          	auipc	a5,0x1
    13c0:	3c07a223          	sw	zero,964(a5) # 2780 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13c4:	8082                	ret
{
    13c6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13c8:	862a                	mv	a2,a0
    13ca:	00001597          	auipc	a1,0x1
    13ce:	3be58593          	addi	a1,a1,958 # 2788 <buffer>
    13d2:	4505                	li	a0,1
{
    13d4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13d6:	c9fff0ef          	jal	ra,1074 <write>
	return r >= 0 ? 0 : r;
    13da:	0005079b          	sext.w	a5,a0
}
    13de:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13e0:	0017a793          	slti	a5,a5,1
    13e4:	40f007bb          	negw	a5,a5
    13e8:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13ea:	00001797          	auipc	a5,0x1
    13ee:	3807ab23          	sw	zero,918(a5) # 2780 <buffer_len>
	return r >= 0 ? 0 : r;
    13f2:	2501                	sext.w	a0,a0
}
    13f4:	0141                	addi	sp,sp,16
    13f6:	8082                	ret

00000000000013f8 <fflush>:

int fflush(int fd)
{
    13f8:	1101                	addi	sp,sp,-32
    13fa:	e822                	sd	s0,16(sp)
    13fc:	ec06                	sd	ra,24(sp)
    13fe:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1400:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1402:	4401                	li	s0,0
	if (fd == 1) {
    1404:	00e50863          	beq	a0,a4,1414 <fflush+0x1c>
}
    1408:	60e2                	ld	ra,24(sp)
    140a:	8522                	mv	a0,s0
    140c:	6442                	ld	s0,16(sp)
    140e:	64a2                	ld	s1,8(sp)
    1410:	6105                	addi	sp,sp,32
    1412:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1414:	00001497          	auipc	s1,0x1
    1418:	36c48493          	addi	s1,s1,876 # 2780 <buffer_len>
    141c:	1084a703          	lw	a4,264(s1)
    1420:	02a70e63          	beq	a4,a0,145c <fflush+0x64>
	if (buffer_len == 0)
    1424:	4080                	lw	s0,0(s1)
    1426:	c00d                	beqz	s0,1448 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1428:	8622                	mv	a2,s0
    142a:	00001597          	auipc	a1,0x1
    142e:	35e58593          	addi	a1,a1,862 # 2788 <buffer>
    1432:	c43ff0ef          	jal	ra,1074 <write>
	return r >= 0 ? 0 : r;
    1436:	0005079b          	sext.w	a5,a0
    143a:	0017a793          	slti	a5,a5,1
    143e:	40f007bb          	negw	a5,a5
    1442:	8d7d                	and	a0,a0,a5
    1444:	0005041b          	sext.w	s0,a0
}
    1448:	60e2                	ld	ra,24(sp)
    144a:	8522                	mv	a0,s0
    144c:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    144e:	00001797          	auipc	a5,0x1
    1452:	3207a923          	sw	zero,818(a5) # 2780 <buffer_len>
}
    1456:	64a2                	ld	s1,8(sp)
    1458:	6105                	addi	sp,sp,32
    145a:	8082                	ret
			mutex_lock(buffer_lock);
    145c:	10c4a503          	lw	a0,268(s1)
    1460:	e8dff0ef          	jal	ra,12ec <mutex_lock>
	if (buffer_len == 0)
    1464:	4080                	lw	s0,0(s1)
    1466:	e811                	bnez	s0,147a <fflush+0x82>
			mutex_unlock(buffer_lock);
    1468:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    146c:	00001797          	auipc	a5,0x1
    1470:	3007aa23          	sw	zero,788(a5) # 2780 <buffer_len>
			mutex_unlock(buffer_lock);
    1474:	e85ff0ef          	jal	ra,12f8 <mutex_unlock>
    1478:	bf41                	j	1408 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    147a:	8622                	mv	a2,s0
    147c:	00001597          	auipc	a1,0x1
    1480:	30c58593          	addi	a1,a1,780 # 2788 <buffer>
    1484:	4505                	li	a0,1
    1486:	befff0ef          	jal	ra,1074 <write>
	return r >= 0 ? 0 : r;
    148a:	0005079b          	sext.w	a5,a0
    148e:	0017a793          	slti	a5,a5,1
    1492:	40f007bb          	negw	a5,a5
    1496:	8d7d                	and	a0,a0,a5
    1498:	0005041b          	sext.w	s0,a0
	return r;
    149c:	b7f1                	j	1468 <fflush+0x70>

000000000000149e <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    149e:	7131                	addi	sp,sp,-192
    14a0:	e0da                	sd	s6,64(sp)
    14a2:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    14a4:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    14a6:	013c                	addi	a5,sp,136
{
    14a8:	f0ca                	sd	s2,96(sp)
    14aa:	ecce                	sd	s3,88(sp)
    14ac:	e8d2                	sd	s4,80(sp)
    14ae:	e4d6                	sd	s5,72(sp)
    14b0:	fc86                	sd	ra,120(sp)
    14b2:	f8a2                	sd	s0,112(sp)
    14b4:	f4a6                	sd	s1,104(sp)
    14b6:	89aa                	mv	s3,a0
    14b8:	e52e                	sd	a1,136(sp)
    14ba:	e932                	sd	a2,144(sp)
    14bc:	ed36                	sd	a3,152(sp)
    14be:	f13a                	sd	a4,160(sp)
    14c0:	f942                	sd	a6,176(sp)
    14c2:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14c4:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14c6:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14ca:	00001a17          	auipc	s4,0x1
    14ce:	2b6a0a13          	addi	s4,s4,694 # 2780 <buffer_len>
    14d2:	4a85                	li	s5,1
	buf[i++] = '0';
    14d4:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14d8:	0009c783          	lbu	a5,0(s3)
    14dc:	18078663          	beqz	a5,1668 <printf+0x1ca>
    14e0:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14e2:	19278d63          	beq	a5,s2,167c <printf+0x1de>
    14e6:	0015c783          	lbu	a5,1(a1)
    14ea:	0585                	addi	a1,a1,1
    14ec:	fbfd                	bnez	a5,14e2 <printf+0x44>
    14ee:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14f0:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14f4:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14f8:	1b578863          	beq	a5,s5,16a8 <printf+0x20a>
		len = out_unlocked(s, l);
    14fc:	85a2                	mv	a1,s0
    14fe:	854e                	mv	a0,s3
    1500:	42a000ef          	jal	ra,192a <out_unlocked>
		out(f, a, l);
		if (l)
    1504:	1c041063          	bnez	s0,16c4 <printf+0x226>
			continue;
		if (s[1] == 0)
    1508:	0014c783          	lbu	a5,1(s1)
    150c:	14078e63          	beqz	a5,1668 <printf+0x1ca>
			break;
		switch (s[1]) {
    1510:	07300713          	li	a4,115
    1514:	1ce78863          	beq	a5,a4,16e4 <printf+0x246>
    1518:	1af76863          	bltu	a4,a5,16c8 <printf+0x22a>
    151c:	06400713          	li	a4,100
    1520:	22e78063          	beq	a5,a4,1740 <printf+0x2a2>
    1524:	07000713          	li	a4,112
    1528:	1ee79563          	bne	a5,a4,1712 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    152c:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    152e:	00001797          	auipc	a5,0x1
    1532:	36a78793          	addi	a5,a5,874 # 2898 <digits>
	buf[i++] = '0';
    1536:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    153a:	6298                	ld	a4,0(a3)
    153c:	06a1                	addi	a3,a3,8
    153e:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1540:	00471393          	slli	t2,a4,0x4
    1544:	00871293          	slli	t0,a4,0x8
    1548:	00c71f93          	slli	t6,a4,0xc
    154c:	01071f13          	slli	t5,a4,0x10
    1550:	01471e93          	slli	t4,a4,0x14
    1554:	01871e13          	slli	t3,a4,0x18
    1558:	01c71893          	slli	a7,a4,0x1c
    155c:	02471813          	slli	a6,a4,0x24
    1560:	02871513          	slli	a0,a4,0x28
    1564:	02c71593          	slli	a1,a4,0x2c
    1568:	03071613          	slli	a2,a4,0x30
    156c:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1570:	03c75413          	srli	s0,a4,0x3c
    1574:	01c7531b          	srliw	t1,a4,0x1c
    1578:	03c3d393          	srli	t2,t2,0x3c
    157c:	03c2d293          	srli	t0,t0,0x3c
    1580:	03cfdf93          	srli	t6,t6,0x3c
    1584:	03cf5f13          	srli	t5,t5,0x3c
    1588:	03cede93          	srli	t4,t4,0x3c
    158c:	03ce5e13          	srli	t3,t3,0x3c
    1590:	03c8d893          	srli	a7,a7,0x3c
    1594:	03c85813          	srli	a6,a6,0x3c
    1598:	9171                	srli	a0,a0,0x3c
    159a:	91f1                	srli	a1,a1,0x3c
    159c:	9271                	srli	a2,a2,0x3c
    159e:	92f1                	srli	a3,a3,0x3c
    15a0:	95be                	add	a1,a1,a5
    15a2:	963e                	add	a2,a2,a5
    15a4:	96be                	add	a3,a3,a5
    15a6:	943e                	add	s0,s0,a5
    15a8:	93be                	add	t2,t2,a5
    15aa:	92be                	add	t0,t0,a5
    15ac:	9fbe                	add	t6,t6,a5
    15ae:	9f3e                	add	t5,t5,a5
    15b0:	9ebe                	add	t4,t4,a5
    15b2:	9e3e                	add	t3,t3,a5
    15b4:	98be                	add	a7,a7,a5
    15b6:	933e                	add	t1,t1,a5
    15b8:	983e                	add	a6,a6,a5
    15ba:	953e                	add	a0,a0,a5
    15bc:	0005c983          	lbu	s3,0(a1)
    15c0:	00044403          	lbu	s0,0(s0)
    15c4:	00064583          	lbu	a1,0(a2)
    15c8:	0003c383          	lbu	t2,0(t2)
    15cc:	0006c603          	lbu	a2,0(a3)
    15d0:	0002c283          	lbu	t0,0(t0)
    15d4:	000fcf83          	lbu	t6,0(t6)
    15d8:	000f4f03          	lbu	t5,0(t5)
    15dc:	000ece83          	lbu	t4,0(t4)
    15e0:	000e4e03          	lbu	t3,0(t3)
    15e4:	0008c883          	lbu	a7,0(a7)
    15e8:	00034303          	lbu	t1,0(t1)
    15ec:	00084803          	lbu	a6,0(a6)
    15f0:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15f4:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15f8:	92f1                	srli	a3,a3,0x3c
    15fa:	8b3d                	andi	a4,a4,15
    15fc:	96be                	add	a3,a3,a5
    15fe:	97ba                	add	a5,a5,a4
    1600:	00810d23          	sb	s0,26(sp)
    1604:	00710da3          	sb	t2,27(sp)
    1608:	00510e23          	sb	t0,28(sp)
    160c:	01f10ea3          	sb	t6,29(sp)
    1610:	01e10f23          	sb	t5,30(sp)
    1614:	01d10fa3          	sb	t4,31(sp)
    1618:	03c10023          	sb	t3,32(sp)
    161c:	031100a3          	sb	a7,33(sp)
    1620:	02610123          	sb	t1,34(sp)
    1624:	030101a3          	sb	a6,35(sp)
    1628:	02a10223          	sb	a0,36(sp)
    162c:	033102a3          	sb	s3,37(sp)
    1630:	02b10323          	sb	a1,38(sp)
    1634:	02c103a3          	sb	a2,39(sp)
    1638:	0006c683          	lbu	a3,0(a3)
    163c:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1640:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1644:	02d10423          	sb	a3,40(sp)
    1648:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    164c:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1650:	11578263          	beq	a5,s5,1754 <printf+0x2b6>
		len = out_unlocked(s, l);
    1654:	45c9                	li	a1,18
    1656:	0828                	addi	a0,sp,24
    1658:	2d2000ef          	jal	ra,192a <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    165c:	00248993          	addi	s3,s1,2
		if (!*s)
    1660:	0009c783          	lbu	a5,0(s3)
    1664:	e6079ee3          	bnez	a5,14e0 <printf+0x42>
	}
	va_end(ap);
    1668:	70e6                	ld	ra,120(sp)
    166a:	7446                	ld	s0,112(sp)
    166c:	74a6                	ld	s1,104(sp)
    166e:	7906                	ld	s2,96(sp)
    1670:	69e6                	ld	s3,88(sp)
    1672:	6a46                	ld	s4,80(sp)
    1674:	6aa6                	ld	s5,72(sp)
    1676:	6b06                	ld	s6,64(sp)
    1678:	6129                	addi	sp,sp,192
    167a:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    167c:	0005c783          	lbu	a5,0(a1)
    1680:	84ae                	mv	s1,a1
    1682:	01278963          	beq	a5,s2,1694 <printf+0x1f6>
    1686:	b5ad                	j	14f0 <printf+0x52>
    1688:	0024c783          	lbu	a5,2(s1)
    168c:	0585                	addi	a1,a1,1
    168e:	0489                	addi	s1,s1,2
    1690:	e72790e3          	bne	a5,s2,14f0 <printf+0x52>
    1694:	0014c783          	lbu	a5,1(s1)
    1698:	ff2788e3          	beq	a5,s2,1688 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    169c:	108a2783          	lw	a5,264(s4)
		l = z - a;
    16a0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    16a4:	e5579ce3          	bne	a5,s5,14fc <printf+0x5e>
		mutex_lock(buffer_lock);
    16a8:	10ca2503          	lw	a0,268(s4)
    16ac:	c41ff0ef          	jal	ra,12ec <mutex_lock>
		len = out_unlocked(s, l);
    16b0:	85a2                	mv	a1,s0
    16b2:	854e                	mv	a0,s3
    16b4:	276000ef          	jal	ra,192a <out_unlocked>
		mutex_unlock(buffer_lock);
    16b8:	10ca2503          	lw	a0,268(s4)
    16bc:	c3dff0ef          	jal	ra,12f8 <mutex_unlock>
		if (l)
    16c0:	e40404e3          	beqz	s0,1508 <printf+0x6a>
    16c4:	89a6                	mv	s3,s1
    16c6:	bd09                	j	14d8 <printf+0x3a>
		switch (s[1]) {
    16c8:	07800713          	li	a4,120
    16cc:	04e79363          	bne	a5,a4,1712 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16d0:	67c2                	ld	a5,16(sp)
    16d2:	45c1                	li	a1,16
		s += 2;
    16d4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16d8:	4388                	lw	a0,0(a5)
    16da:	07a1                	addi	a5,a5,8
    16dc:	e83e                	sd	a5,16(sp)
    16de:	5f8000ef          	jal	ra,1cd6 <printint.constprop.0>
		s += 2;
    16e2:	bfbd                	j	1660 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16e4:	67c2                	ld	a5,16(sp)
    16e6:	6380                	ld	s0,0(a5)
    16e8:	07a1                	addi	a5,a5,8
    16ea:	e83e                	sd	a5,16(sp)
    16ec:	1c040163          	beqz	s0,18ae <printf+0x410>
			l = strnlen(a, 200);
    16f0:	0c800593          	li	a1,200
    16f4:	8522                	mv	a0,s0
    16f6:	3f7000ef          	jal	ra,22ec <strnlen>
	if (buffer_lock_enabled == 1) {
    16fa:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16fe:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1702:	19578663          	beq	a5,s5,188e <printf+0x3f0>
		len = out_unlocked(s, l);
    1706:	8522                	mv	a0,s0
    1708:	222000ef          	jal	ra,192a <out_unlocked>
		s += 2;
    170c:	00248993          	addi	s3,s1,2
    1710:	bf81                	j	1660 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1712:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1716:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    171a:	0f578663          	beq	a5,s5,1806 <printf+0x368>
		len = out_unlocked(s, l);
    171e:	0828                	addi	a0,sp,24
    1720:	316000ef          	jal	ra,1a36 <out_unlocked.constprop.0>
			putchar(s[1]);
    1724:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1728:	108a2783          	lw	a5,264(s4)
	char byte = c;
    172c:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1730:	05578163          	beq	a5,s5,1772 <printf+0x2d4>
		len = out_unlocked(s, l);
    1734:	0828                	addi	a0,sp,24
    1736:	300000ef          	jal	ra,1a36 <out_unlocked.constprop.0>
		s += 2;
    173a:	00248993          	addi	s3,s1,2
    173e:	b70d                	j	1660 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1740:	67c2                	ld	a5,16(sp)
    1742:	45a9                	li	a1,10
		s += 2;
    1744:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1748:	4388                	lw	a0,0(a5)
    174a:	07a1                	addi	a5,a5,8
    174c:	e83e                	sd	a5,16(sp)
    174e:	588000ef          	jal	ra,1cd6 <printint.constprop.0>
		s += 2;
    1752:	b739                	j	1660 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1754:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1758:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    175c:	b91ff0ef          	jal	ra,12ec <mutex_lock>
		len = out_unlocked(s, l);
    1760:	45c9                	li	a1,18
    1762:	0828                	addi	a0,sp,24
    1764:	1c6000ef          	jal	ra,192a <out_unlocked>
		mutex_unlock(buffer_lock);
    1768:	10ca2503          	lw	a0,268(s4)
    176c:	b8dff0ef          	jal	ra,12f8 <mutex_unlock>
		s += 2;
    1770:	bdc5                	j	1660 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1772:	10ca2503          	lw	a0,268(s4)
    1776:	b77ff0ef          	jal	ra,12ec <mutex_lock>
		buffer[buffer_len++] = c;
    177a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    177e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1782:	0017861b          	addiw	a2,a5,1
    1786:	97d2                	add	a5,a5,s4
    1788:	00ca2023          	sw	a2,0(s4)
    178c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1790:	00c6cc63          	blt	a3,a2,17a8 <printf+0x30a>
    1794:	47a9                	li	a5,10
    1796:	06f40663          	beq	s0,a5,1802 <printf+0x364>
		mutex_unlock(buffer_lock);
    179a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    179e:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    17a2:	b57ff0ef          	jal	ra,12f8 <mutex_unlock>
		s += 2;
    17a6:	bd6d                	j	1660 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    17a8:	10000793          	li	a5,256
    17ac:	00f61e63          	bne	a2,a5,17c8 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    17b0:	00001597          	auipc	a1,0x1
    17b4:	fd858593          	addi	a1,a1,-40 # 2788 <buffer>
    17b8:	4505                	li	a0,1
    17ba:	8bbff0ef          	jal	ra,1074 <write>
	buffer_len = 0;
    17be:	00001797          	auipc	a5,0x1
    17c2:	fc07a123          	sw	zero,-62(a5) # 2780 <buffer_len>
			if (r < 0) {
    17c6:	bfd1                	j	179a <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17c8:	8b7ff0ef          	jal	ra,107e <getpid>
    17cc:	842a                	mv	s0,a0
    17ce:	00001517          	auipc	a0,0x1
    17d2:	eba50513          	addi	a0,a0,-326 # 2688 <basename+0xe2>
    17d6:	5d1000ef          	jal	ra,25a6 <basename>
    17da:	872a                	mv	a4,a0
    17dc:	00001617          	auipc	a2,0x1
    17e0:	eec60613          	addi	a2,a2,-276 # 26c8 <basename+0x122>
    17e4:	05400793          	li	a5,84
    17e8:	86a2                	mv	a3,s0
    17ea:	45fd                	li	a1,31
    17ec:	00001517          	auipc	a0,0x1
    17f0:	ee450513          	addi	a0,a0,-284 # 26d0 <basename+0x12a>
    17f4:	cabff0ef          	jal	ra,149e <printf>
    17f8:	557d                	li	a0,-1
    17fa:	8b5ff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    17fe:	000a2603          	lw	a2,0(s4)
    1802:	de41                	beqz	a2,179a <printf+0x2fc>
    1804:	b775                	j	17b0 <printf+0x312>
		mutex_lock(buffer_lock);
    1806:	10ca2503          	lw	a0,268(s4)
    180a:	ae3ff0ef          	jal	ra,12ec <mutex_lock>
		buffer[buffer_len++] = c;
    180e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1812:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1816:	0017861b          	addiw	a2,a5,1
    181a:	97d2                	add	a5,a5,s4
    181c:	00ca2023          	sw	a2,0(s4)
    1820:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1824:	02c6d163          	bge	a3,a2,1846 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1828:	10000793          	li	a5,256
    182c:	02f61263          	bne	a2,a5,1850 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1830:	00001597          	auipc	a1,0x1
    1834:	f5858593          	addi	a1,a1,-168 # 2788 <buffer>
    1838:	4505                	li	a0,1
    183a:	83bff0ef          	jal	ra,1074 <write>
	buffer_len = 0;
    183e:	00001797          	auipc	a5,0x1
    1842:	f407a123          	sw	zero,-190(a5) # 2780 <buffer_len>
		mutex_unlock(buffer_lock);
    1846:	10ca2503          	lw	a0,268(s4)
    184a:	aafff0ef          	jal	ra,12f8 <mutex_unlock>
    184e:	bdd9                	j	1724 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1850:	82fff0ef          	jal	ra,107e <getpid>
    1854:	842a                	mv	s0,a0
    1856:	00001517          	auipc	a0,0x1
    185a:	e3250513          	addi	a0,a0,-462 # 2688 <basename+0xe2>
    185e:	549000ef          	jal	ra,25a6 <basename>
    1862:	872a                	mv	a4,a0
    1864:	00001617          	auipc	a2,0x1
    1868:	e6460613          	addi	a2,a2,-412 # 26c8 <basename+0x122>
    186c:	05400793          	li	a5,84
    1870:	86a2                	mv	a3,s0
    1872:	45fd                	li	a1,31
    1874:	00001517          	auipc	a0,0x1
    1878:	e5c50513          	addi	a0,a0,-420 # 26d0 <basename+0x12a>
    187c:	c23ff0ef          	jal	ra,149e <printf>
    1880:	557d                	li	a0,-1
    1882:	82dff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    1886:	000a2603          	lw	a2,0(s4)
    188a:	de55                	beqz	a2,1846 <printf+0x3a8>
    188c:	b755                	j	1830 <printf+0x392>
		mutex_lock(buffer_lock);
    188e:	10ca2503          	lw	a0,268(s4)
    1892:	e42e                	sd	a1,8(sp)
		s += 2;
    1894:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1898:	a55ff0ef          	jal	ra,12ec <mutex_lock>
		len = out_unlocked(s, l);
    189c:	65a2                	ld	a1,8(sp)
    189e:	8522                	mv	a0,s0
    18a0:	08a000ef          	jal	ra,192a <out_unlocked>
		mutex_unlock(buffer_lock);
    18a4:	10ca2503          	lw	a0,268(s4)
    18a8:	a51ff0ef          	jal	ra,12f8 <mutex_unlock>
		s += 2;
    18ac:	bb55                	j	1660 <printf+0x1c2>
				a = "(null)";
    18ae:	00001417          	auipc	s0,0x1
    18b2:	dd240413          	addi	s0,s0,-558 # 2680 <basename+0xda>
    18b6:	bd2d                	j	16f0 <printf+0x252>

00000000000018b8 <enable_thread_io_buffer>:
{
    18b8:	1101                	addi	sp,sp,-32
    18ba:	e822                	sd	s0,16(sp)
    18bc:	ec06                	sd	ra,24(sp)
    18be:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18c0:	00001417          	auipc	s0,0x1
    18c4:	ec040413          	addi	s0,s0,-320 # 2780 <buffer_len>
    18c8:	a09ff0ef          	jal	ra,12d0 <mutex_create>
    18cc:	10a42623          	sw	a0,268(s0)
    18d0:	00054a63          	bltz	a0,18e4 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18d4:	4785                	li	a5,1
}
    18d6:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18d8:	10f42423          	sw	a5,264(s0)
}
    18dc:	6442                	ld	s0,16(sp)
    18de:	64a2                	ld	s1,8(sp)
    18e0:	6105                	addi	sp,sp,32
    18e2:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18e4:	f9aff0ef          	jal	ra,107e <getpid>
    18e8:	84aa                	mv	s1,a0
    18ea:	00001517          	auipc	a0,0x1
    18ee:	d9e50513          	addi	a0,a0,-610 # 2688 <basename+0xe2>
    18f2:	4b5000ef          	jal	ra,25a6 <basename>
    18f6:	872a                	mv	a4,a0
    18f8:	04800793          	li	a5,72
    18fc:	86a6                	mv	a3,s1
    18fe:	00001517          	auipc	a0,0x1
    1902:	e1250513          	addi	a0,a0,-494 # 2710 <basename+0x16a>
    1906:	00001617          	auipc	a2,0x1
    190a:	dc260613          	addi	a2,a2,-574 # 26c8 <basename+0x122>
    190e:	45fd                	li	a1,31
    1910:	b8fff0ef          	jal	ra,149e <printf>
    1914:	557d                	li	a0,-1
    1916:	f98ff0ef          	jal	ra,10ae <exit>
	buffer_lock_enabled = 1;
    191a:	4785                	li	a5,1
}
    191c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    191e:	10f42423          	sw	a5,264(s0)
}
    1922:	6442                	ld	s0,16(sp)
    1924:	64a2                	ld	s1,8(sp)
    1926:	6105                	addi	sp,sp,32
    1928:	8082                	ret

000000000000192a <out_unlocked>:
{
    192a:	7159                	addi	sp,sp,-112
    192c:	f486                	sd	ra,104(sp)
    192e:	f0a2                	sd	s0,96(sp)
    1930:	eca6                	sd	s1,88(sp)
    1932:	e8ca                	sd	s2,80(sp)
    1934:	e4ce                	sd	s3,72(sp)
    1936:	e0d2                	sd	s4,64(sp)
    1938:	fc56                	sd	s5,56(sp)
    193a:	f85a                	sd	s6,48(sp)
    193c:	f45e                	sd	s7,40(sp)
    193e:	f062                	sd	s8,32(sp)
    1940:	ec66                	sd	s9,24(sp)
    1942:	e86a                	sd	s10,16(sp)
    1944:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1946:	0e058663          	beqz	a1,1a32 <out_unlocked+0x108>
    194a:	842a                	mv	s0,a0
    194c:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1950:	4981                	li	s3,0
    1952:	00001d17          	auipc	s10,0x1
    1956:	e2ed0d13          	addi	s10,s10,-466 # 2780 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    195a:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    195e:	00001b17          	auipc	s6,0x1
    1962:	e2ab0b13          	addi	s6,s6,-470 # 2788 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1966:	10000a93          	li	s5,256
    196a:	00001c97          	auipc	s9,0x1
    196e:	d1ec8c93          	addi	s9,s9,-738 # 2688 <basename+0xe2>
    1972:	00001c17          	auipc	s8,0x1
    1976:	d56c0c13          	addi	s8,s8,-682 # 26c8 <basename+0x122>
    197a:	00001b97          	auipc	s7,0x1
    197e:	d56b8b93          	addi	s7,s7,-682 # 26d0 <basename+0x12a>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1982:	4a29                	li	s4,10
    1984:	a031                	j	1990 <out_unlocked+0x66>
    1986:	09468863          	beq	a3,s4,1a16 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    198a:	0405                	addi	s0,s0,1
    198c:	04848163          	beq	s1,s0,19ce <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1990:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1994:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1998:	0017861b          	addiw	a2,a5,1
    199c:	97ea                	add	a5,a5,s10
    199e:	00cd2023          	sw	a2,0(s10)
    19a2:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19a6:	fec950e3          	bge	s2,a2,1986 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    19aa:	05561263          	bne	a2,s5,19ee <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    19ae:	85da                	mv	a1,s6
    19b0:	4505                	li	a0,1
    19b2:	ec2ff0ef          	jal	ra,1074 <write>
    19b6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19b8:	00001797          	auipc	a5,0x1
    19bc:	dc07a423          	sw	zero,-568(a5) # 2780 <buffer_len>
			if (r < 0) {
    19c0:	06054763          	bltz	a0,1a2e <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19c4:	0405                	addi	s0,s0,1
			ret += r;
    19c6:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19ca:	fc8493e3          	bne	s1,s0,1990 <out_unlocked+0x66>
}
    19ce:	70a6                	ld	ra,104(sp)
    19d0:	7406                	ld	s0,96(sp)
    19d2:	64e6                	ld	s1,88(sp)
    19d4:	6946                	ld	s2,80(sp)
    19d6:	6a06                	ld	s4,64(sp)
    19d8:	7ae2                	ld	s5,56(sp)
    19da:	7b42                	ld	s6,48(sp)
    19dc:	7ba2                	ld	s7,40(sp)
    19de:	7c02                	ld	s8,32(sp)
    19e0:	6ce2                	ld	s9,24(sp)
    19e2:	6d42                	ld	s10,16(sp)
    19e4:	6da2                	ld	s11,8(sp)
    19e6:	854e                	mv	a0,s3
    19e8:	69a6                	ld	s3,72(sp)
    19ea:	6165                	addi	sp,sp,112
    19ec:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19ee:	e90ff0ef          	jal	ra,107e <getpid>
    19f2:	8daa                	mv	s11,a0
    19f4:	8566                	mv	a0,s9
    19f6:	3b1000ef          	jal	ra,25a6 <basename>
    19fa:	872a                	mv	a4,a0
    19fc:	8662                	mv	a2,s8
    19fe:	05400793          	li	a5,84
    1a02:	86ee                	mv	a3,s11
    1a04:	45fd                	li	a1,31
    1a06:	855e                	mv	a0,s7
    1a08:	a97ff0ef          	jal	ra,149e <printf>
    1a0c:	557d                	li	a0,-1
    1a0e:	ea0ff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    1a12:	000d2603          	lw	a2,0(s10)
    1a16:	da35                	beqz	a2,198a <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a18:	85da                	mv	a1,s6
    1a1a:	4505                	li	a0,1
    1a1c:	e58ff0ef          	jal	ra,1074 <write>
    1a20:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a22:	00001797          	auipc	a5,0x1
    1a26:	d407af23          	sw	zero,-674(a5) # 2780 <buffer_len>
			if (r < 0) {
    1a2a:	f8055de3          	bgez	a0,19c4 <out_unlocked+0x9a>
    1a2e:	89aa                	mv	s3,a0
    1a30:	bf79                	j	19ce <out_unlocked+0xa4>
	int ret = 0;
    1a32:	4981                	li	s3,0
    1a34:	bf69                	j	19ce <out_unlocked+0xa4>

0000000000001a36 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a36:	1101                	addi	sp,sp,-32
    1a38:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a3a:	00001497          	auipc	s1,0x1
    1a3e:	d4648493          	addi	s1,s1,-698 # 2780 <buffer_len>
    1a42:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a44:	ec06                	sd	ra,24(sp)
    1a46:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a48:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a4c:	0017861b          	addiw	a2,a5,1
    1a50:	97a6                	add	a5,a5,s1
    1a52:	00e78423          	sb	a4,8(a5)
    1a56:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a58:	0ff00793          	li	a5,255
    1a5c:	00c7cc63          	blt	a5,a2,1a74 <out_unlocked.constprop.0+0x3e>
    1a60:	47a9                	li	a5,10
    1a62:	06f70c63          	beq	a4,a5,1ada <out_unlocked.constprop.0+0xa4>
    1a66:	4601                	li	a2,0
}
    1a68:	60e2                	ld	ra,24(sp)
    1a6a:	6442                	ld	s0,16(sp)
    1a6c:	64a2                	ld	s1,8(sp)
    1a6e:	8532                	mv	a0,a2
    1a70:	6105                	addi	sp,sp,32
    1a72:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a74:	10000793          	li	a5,256
    1a78:	02f61563          	bne	a2,a5,1aa2 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a7c:	00001597          	auipc	a1,0x1
    1a80:	d0c58593          	addi	a1,a1,-756 # 2788 <buffer>
    1a84:	4505                	li	a0,1
    1a86:	deeff0ef          	jal	ra,1074 <write>
}
    1a8a:	60e2                	ld	ra,24(sp)
    1a8c:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a8e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a92:	00001797          	auipc	a5,0x1
    1a96:	ce07a723          	sw	zero,-786(a5) # 2780 <buffer_len>
}
    1a9a:	64a2                	ld	s1,8(sp)
    1a9c:	8532                	mv	a0,a2
    1a9e:	6105                	addi	sp,sp,32
    1aa0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1aa2:	ddcff0ef          	jal	ra,107e <getpid>
    1aa6:	842a                	mv	s0,a0
    1aa8:	00001517          	auipc	a0,0x1
    1aac:	be050513          	addi	a0,a0,-1056 # 2688 <basename+0xe2>
    1ab0:	2f7000ef          	jal	ra,25a6 <basename>
    1ab4:	872a                	mv	a4,a0
    1ab6:	00001617          	auipc	a2,0x1
    1aba:	c1260613          	addi	a2,a2,-1006 # 26c8 <basename+0x122>
    1abe:	05400793          	li	a5,84
    1ac2:	86a2                	mv	a3,s0
    1ac4:	45fd                	li	a1,31
    1ac6:	00001517          	auipc	a0,0x1
    1aca:	c0a50513          	addi	a0,a0,-1014 # 26d0 <basename+0x12a>
    1ace:	9d1ff0ef          	jal	ra,149e <printf>
    1ad2:	557d                	li	a0,-1
    1ad4:	ddaff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    1ad8:	4090                	lw	a2,0(s1)
    1ada:	d659                	beqz	a2,1a68 <out_unlocked.constprop.0+0x32>
    1adc:	b745                	j	1a7c <out_unlocked.constprop.0+0x46>

0000000000001ade <putchar>:
{
    1ade:	7139                	addi	sp,sp,-64
    1ae0:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ae2:	00001497          	auipc	s1,0x1
    1ae6:	c9e48493          	addi	s1,s1,-866 # 2780 <buffer_len>
    1aea:	1084a703          	lw	a4,264(s1)
{
    1aee:	f822                	sd	s0,48(sp)
	char byte = c;
    1af0:	0ff57413          	zext.b	s0,a0
{
    1af4:	fc06                	sd	ra,56(sp)
	char byte = c;
    1af6:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1afa:	4785                	li	a5,1
    1afc:	00f70d63          	beq	a4,a5,1b16 <putchar+0x38>
		len = out_unlocked(s, l);
    1b00:	01f10513          	addi	a0,sp,31
    1b04:	f33ff0ef          	jal	ra,1a36 <out_unlocked.constprop.0>
}
    1b08:	70e2                	ld	ra,56(sp)
    1b0a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1b0c:	862a                	mv	a2,a0
}
    1b0e:	74a2                	ld	s1,40(sp)
    1b10:	8532                	mv	a0,a2
    1b12:	6121                	addi	sp,sp,64
    1b14:	8082                	ret
		mutex_lock(buffer_lock);
    1b16:	10c4a503          	lw	a0,268(s1)
    1b1a:	fd2ff0ef          	jal	ra,12ec <mutex_lock>
		buffer[buffer_len++] = c;
    1b1e:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b20:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b24:	0017861b          	addiw	a2,a5,1
    1b28:	97a6                	add	a5,a5,s1
    1b2a:	c090                	sw	a2,0(s1)
    1b2c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b30:	02c6c263          	blt	a3,a2,1b54 <putchar+0x76>
    1b34:	47a9                	li	a5,10
    1b36:	06f40d63          	beq	s0,a5,1bb0 <putchar+0xd2>
    1b3a:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b3c:	10c4a503          	lw	a0,268(s1)
    1b40:	e432                	sd	a2,8(sp)
    1b42:	fb6ff0ef          	jal	ra,12f8 <mutex_unlock>
    1b46:	6622                	ld	a2,8(sp)
}
    1b48:	70e2                	ld	ra,56(sp)
    1b4a:	7442                	ld	s0,48(sp)
    1b4c:	74a2                	ld	s1,40(sp)
    1b4e:	8532                	mv	a0,a2
    1b50:	6121                	addi	sp,sp,64
    1b52:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b54:	10000793          	li	a5,256
    1b58:	02f61063          	bne	a2,a5,1b78 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b5c:	00001597          	auipc	a1,0x1
    1b60:	c2c58593          	addi	a1,a1,-980 # 2788 <buffer>
    1b64:	4505                	li	a0,1
    1b66:	d0eff0ef          	jal	ra,1074 <write>
    1b6a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b6e:	00001797          	auipc	a5,0x1
    1b72:	c007a923          	sw	zero,-1006(a5) # 2780 <buffer_len>
			if (r < 0) {
    1b76:	b7d9                	j	1b3c <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b78:	d06ff0ef          	jal	ra,107e <getpid>
    1b7c:	842a                	mv	s0,a0
    1b7e:	00001517          	auipc	a0,0x1
    1b82:	b0a50513          	addi	a0,a0,-1270 # 2688 <basename+0xe2>
    1b86:	221000ef          	jal	ra,25a6 <basename>
    1b8a:	872a                	mv	a4,a0
    1b8c:	00001617          	auipc	a2,0x1
    1b90:	b3c60613          	addi	a2,a2,-1220 # 26c8 <basename+0x122>
    1b94:	05400793          	li	a5,84
    1b98:	86a2                	mv	a3,s0
    1b9a:	45fd                	li	a1,31
    1b9c:	00001517          	auipc	a0,0x1
    1ba0:	b3450513          	addi	a0,a0,-1228 # 26d0 <basename+0x12a>
    1ba4:	8fbff0ef          	jal	ra,149e <printf>
    1ba8:	557d                	li	a0,-1
    1baa:	d04ff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    1bae:	4090                	lw	a2,0(s1)
    1bb0:	d651                	beqz	a2,1b3c <putchar+0x5e>
    1bb2:	b76d                	j	1b5c <putchar+0x7e>

0000000000001bb4 <puts>:
{
    1bb4:	7139                	addi	sp,sp,-64
    1bb6:	f822                	sd	s0,48(sp)
    1bb8:	f426                	sd	s1,40(sp)
    1bba:	fc06                	sd	ra,56(sp)
    1bbc:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1bbe:	00001417          	auipc	s0,0x1
    1bc2:	bc240413          	addi	s0,s0,-1086 # 2780 <buffer_len>
{
    1bc6:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bc8:	638000ef          	jal	ra,2200 <strlen>
	if (buffer_lock_enabled == 1) {
    1bcc:	10842703          	lw	a4,264(s0)
    1bd0:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bd2:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bd4:	04f70563          	beq	a4,a5,1c1e <puts+0x6a>
		len = out_unlocked(s, l);
    1bd8:	8526                	mv	a0,s1
    1bda:	d51ff0ef          	jal	ra,192a <out_unlocked>
    1bde:	892a                	mv	s2,a0
    1be0:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1be2:	00095963          	bgez	s2,1bf4 <puts+0x40>
}
    1be6:	70e2                	ld	ra,56(sp)
    1be8:	7442                	ld	s0,48(sp)
    1bea:	7902                	ld	s2,32(sp)
    1bec:	8526                	mv	a0,s1
    1bee:	74a2                	ld	s1,40(sp)
    1bf0:	6121                	addi	sp,sp,64
    1bf2:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1bf4:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bf8:	44a9                	li	s1,10
    1bfa:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bfe:	4785                	li	a5,1
    1c00:	02f70e63          	beq	a4,a5,1c3c <puts+0x88>
		len = out_unlocked(s, l);
    1c04:	01f10513          	addi	a0,sp,31
    1c08:	e2fff0ef          	jal	ra,1a36 <out_unlocked.constprop.0>
}
    1c0c:	70e2                	ld	ra,56(sp)
    1c0e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c10:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c14:	7902                	ld	s2,32(sp)
    1c16:	8526                	mv	a0,s1
    1c18:	74a2                	ld	s1,40(sp)
    1c1a:	6121                	addi	sp,sp,64
    1c1c:	8082                	ret
		mutex_lock(buffer_lock);
    1c1e:	e42a                	sd	a0,8(sp)
    1c20:	10c42503          	lw	a0,268(s0)
    1c24:	ec8ff0ef          	jal	ra,12ec <mutex_lock>
		len = out_unlocked(s, l);
    1c28:	65a2                	ld	a1,8(sp)
    1c2a:	8526                	mv	a0,s1
    1c2c:	cffff0ef          	jal	ra,192a <out_unlocked>
    1c30:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c32:	10c42503          	lw	a0,268(s0)
    1c36:	ec2ff0ef          	jal	ra,12f8 <mutex_unlock>
    1c3a:	b75d                	j	1be0 <puts+0x2c>
		mutex_lock(buffer_lock);
    1c3c:	10c42503          	lw	a0,268(s0)
    1c40:	eacff0ef          	jal	ra,12ec <mutex_lock>
		buffer[buffer_len++] = c;
    1c44:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c46:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c4a:	0017861b          	addiw	a2,a5,1
    1c4e:	97a2                	add	a5,a5,s0
    1c50:	c010                	sw	a2,0(s0)
    1c52:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c56:	06c6dc63          	bge	a3,a2,1cce <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c5a:	10000793          	li	a5,256
    1c5e:	02f61c63          	bne	a2,a5,1c96 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c62:	00001597          	auipc	a1,0x1
    1c66:	b2658593          	addi	a1,a1,-1242 # 2788 <buffer>
    1c6a:	4505                	li	a0,1
    1c6c:	c08ff0ef          	jal	ra,1074 <write>
			if (r < 0) {
    1c70:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c72:	00001797          	auipc	a5,0x1
    1c76:	b007a723          	sw	zero,-1266(a5) # 2780 <buffer_len>
			if (r < 0) {
    1c7a:	04054c63          	bltz	a0,1cd2 <puts+0x11e>
			if (r < buffer_len) {
    1c7e:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c80:	10c42503          	lw	a0,268(s0)
    1c84:	e74ff0ef          	jal	ra,12f8 <mutex_unlock>
}
    1c88:	70e2                	ld	ra,56(sp)
    1c8a:	7442                	ld	s0,48(sp)
    1c8c:	7902                	ld	s2,32(sp)
    1c8e:	8526                	mv	a0,s1
    1c90:	74a2                	ld	s1,40(sp)
    1c92:	6121                	addi	sp,sp,64
    1c94:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c96:	be8ff0ef          	jal	ra,107e <getpid>
    1c9a:	84aa                	mv	s1,a0
    1c9c:	00001517          	auipc	a0,0x1
    1ca0:	9ec50513          	addi	a0,a0,-1556 # 2688 <basename+0xe2>
    1ca4:	103000ef          	jal	ra,25a6 <basename>
    1ca8:	872a                	mv	a4,a0
    1caa:	00001617          	auipc	a2,0x1
    1cae:	a1e60613          	addi	a2,a2,-1506 # 26c8 <basename+0x122>
    1cb2:	05400793          	li	a5,84
    1cb6:	86a6                	mv	a3,s1
    1cb8:	45fd                	li	a1,31
    1cba:	00001517          	auipc	a0,0x1
    1cbe:	a1650513          	addi	a0,a0,-1514 # 26d0 <basename+0x12a>
    1cc2:	fdcff0ef          	jal	ra,149e <printf>
    1cc6:	557d                	li	a0,-1
    1cc8:	be6ff0ef          	jal	ra,10ae <exit>
	if (buffer_len == 0)
    1ccc:	4010                	lw	a2,0(s0)
    1cce:	da45                	beqz	a2,1c7e <puts+0xca>
    1cd0:	bf49                	j	1c62 <puts+0xae>
    1cd2:	54fd                	li	s1,-1
    1cd4:	b775                	j	1c80 <puts+0xcc>

0000000000001cd6 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cd6:	715d                	addi	sp,sp,-80
    1cd8:	e486                	sd	ra,72(sp)
    1cda:	e0a2                	sd	s0,64(sp)
    1cdc:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1cde:	14054363          	bltz	a0,1e24 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ce2:	02b577bb          	remuw	a5,a0,a1
    1ce6:	00001617          	auipc	a2,0x1
    1cea:	bb260613          	addi	a2,a2,-1102 # 2898 <digits>
	buf[16] = 0;
    1cee:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1cf2:	0005871b          	sext.w	a4,a1
    1cf6:	1782                	slli	a5,a5,0x20
    1cf8:	9381                	srli	a5,a5,0x20
    1cfa:	97b2                	add	a5,a5,a2
    1cfc:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d00:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1d04:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1d08:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1d0a:	0eb56763          	bltu	a0,a1,1df8 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d0e:	02e877bb          	remuw	a5,a6,a4
    1d12:	1782                	slli	a5,a5,0x20
    1d14:	9381                	srli	a5,a5,0x20
    1d16:	97b2                	add	a5,a5,a2
    1d18:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d1c:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d20:	02f10323          	sb	a5,38(sp)
    1d24:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d26:	0ce86963          	bltu	a6,a4,1df8 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d2a:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d2e:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d32:	1582                	slli	a1,a1,0x20
    1d34:	9181                	srli	a1,a1,0x20
    1d36:	95b2                	add	a1,a1,a2
    1d38:	0005c583          	lbu	a1,0(a1)
    1d3c:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d40:	0007859b          	sext.w	a1,a5
    1d44:	16e6e563          	bltu	a3,a4,1eae <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d48:	02e7f6bb          	remuw	a3,a5,a4
    1d4c:	1682                	slli	a3,a3,0x20
    1d4e:	9281                	srli	a3,a3,0x20
    1d50:	96b2                	add	a3,a3,a2
    1d52:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d56:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d5a:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d5e:	16e5e163          	bltu	a1,a4,1ec0 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d62:	02e876bb          	remuw	a3,a6,a4
    1d66:	1682                	slli	a3,a3,0x20
    1d68:	9281                	srli	a3,a3,0x20
    1d6a:	96b2                	add	a3,a3,a2
    1d6c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d70:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d74:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d78:	14e86d63          	bltu	a6,a4,1ed2 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d7c:	02e5f6bb          	remuw	a3,a1,a4
    1d80:	1682                	slli	a3,a3,0x20
    1d82:	9281                	srli	a3,a3,0x20
    1d84:	96b2                	add	a3,a3,a2
    1d86:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d8a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d8e:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d92:	10e5e563          	bltu	a1,a4,1e9c <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d96:	02e876bb          	remuw	a3,a6,a4
    1d9a:	1682                	slli	a3,a3,0x20
    1d9c:	9281                	srli	a3,a3,0x20
    1d9e:	96b2                	add	a3,a3,a2
    1da0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1da4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1da8:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1dac:	14e86263          	bltu	a6,a4,1ef0 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1db0:	02e5f6bb          	remuw	a3,a1,a4
    1db4:	1682                	slli	a3,a3,0x20
    1db6:	9281                	srli	a3,a3,0x20
    1db8:	96b2                	add	a3,a3,a2
    1dba:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dbe:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1dc2:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1dc6:	14e5e463          	bltu	a1,a4,1f0e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1dca:	02e876bb          	remuw	a3,a6,a4
    1dce:	1682                	slli	a3,a3,0x20
    1dd0:	9281                	srli	a3,a3,0x20
    1dd2:	96b2                	add	a3,a3,a2
    1dd4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dd8:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ddc:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1de0:	14e86063          	bltu	a6,a4,1f20 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1de4:	1782                	slli	a5,a5,0x20
    1de6:	9381                	srli	a5,a5,0x20
    1de8:	97b2                	add	a5,a5,a2
    1dea:	0007c703          	lbu	a4,0(a5)
    1dee:	4799                	li	a5,6
    1df0:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1df4:	10054763          	bltz	a0,1f02 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1df8:	00001497          	auipc	s1,0x1
    1dfc:	98848493          	addi	s1,s1,-1656 # 2780 <buffer_len>
    1e00:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1e04:	0828                	addi	a0,sp,24
    1e06:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1e08:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1e0a:	00f50433          	add	s0,a0,a5
    1e0e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1e10:	06e68463          	beq	a3,a4,1e78 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e14:	8522                	mv	a0,s0
    1e16:	b15ff0ef          	jal	ra,192a <out_unlocked>
}
    1e1a:	60a6                	ld	ra,72(sp)
    1e1c:	6406                	ld	s0,64(sp)
    1e1e:	74e2                	ld	s1,56(sp)
    1e20:	6161                	addi	sp,sp,80
    1e22:	8082                	ret
		x = -xx;
    1e24:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e28:	02b877bb          	remuw	a5,a6,a1
    1e2c:	00001617          	auipc	a2,0x1
    1e30:	a6c60613          	addi	a2,a2,-1428 # 2898 <digits>
	buf[16] = 0;
    1e34:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e38:	0005871b          	sext.w	a4,a1
    1e3c:	1782                	slli	a5,a5,0x20
    1e3e:	9381                	srli	a5,a5,0x20
    1e40:	97b2                	add	a5,a5,a2
    1e42:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e46:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e4a:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e4e:	08b86b63          	bltu	a6,a1,1ee4 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e52:	02e8f7bb          	remuw	a5,a7,a4
    1e56:	1782                	slli	a5,a5,0x20
    1e58:	9381                	srli	a5,a5,0x20
    1e5a:	97b2                	add	a5,a5,a2
    1e5c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e60:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e64:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e68:	ece8f1e3          	bgeu	a7,a4,1d2a <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e6c:	02d00793          	li	a5,45
    1e70:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e74:	47b5                	li	a5,13
    1e76:	b749                	j	1df8 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e78:	10c4a503          	lw	a0,268(s1)
    1e7c:	e42e                	sd	a1,8(sp)
    1e7e:	c6eff0ef          	jal	ra,12ec <mutex_lock>
		len = out_unlocked(s, l);
    1e82:	65a2                	ld	a1,8(sp)
    1e84:	8522                	mv	a0,s0
    1e86:	aa5ff0ef          	jal	ra,192a <out_unlocked>
		mutex_unlock(buffer_lock);
    1e8a:	10c4a503          	lw	a0,268(s1)
    1e8e:	c6aff0ef          	jal	ra,12f8 <mutex_unlock>
}
    1e92:	60a6                	ld	ra,72(sp)
    1e94:	6406                	ld	s0,64(sp)
    1e96:	74e2                	ld	s1,56(sp)
    1e98:	6161                	addi	sp,sp,80
    1e9a:	8082                	ret
		buf[i--] = digits[x % base];
    1e9c:	47a9                	li	a5,10
	if (sign)
    1e9e:	f4055de3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea2:	02d00793          	li	a5,45
    1ea6:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1eaa:	47a5                	li	a5,9
    1eac:	b7b1                	j	1df8 <printint.constprop.0+0x122>
    1eae:	47b5                	li	a5,13
	if (sign)
    1eb0:	f40554e3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb4:	02d00793          	li	a5,45
    1eb8:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1ebc:	47b1                	li	a5,12
    1ebe:	bf2d                	j	1df8 <printint.constprop.0+0x122>
    1ec0:	47b1                	li	a5,12
	if (sign)
    1ec2:	f2055be3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ec6:	02d00793          	li	a5,45
    1eca:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ece:	47ad                	li	a5,11
    1ed0:	b725                	j	1df8 <printint.constprop.0+0x122>
    1ed2:	47ad                	li	a5,11
	if (sign)
    1ed4:	f20552e3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed8:	02d00793          	li	a5,45
    1edc:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ee0:	47a9                	li	a5,10
    1ee2:	bf19                	j	1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee4:	02d00793          	li	a5,45
    1ee8:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1eec:	47b9                	li	a5,14
    1eee:	b729                	j	1df8 <printint.constprop.0+0x122>
    1ef0:	47a5                	li	a5,9
	if (sign)
    1ef2:	f00553e3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef6:	02d00793          	li	a5,45
    1efa:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1efe:	47a1                	li	a5,8
    1f00:	bde5                	j	1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f02:	02d00793          	li	a5,45
    1f06:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1f0a:	4795                	li	a5,5
    1f0c:	b5f5                	j	1df8 <printint.constprop.0+0x122>
    1f0e:	47a1                	li	a5,8
	if (sign)
    1f10:	ee0554e3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f14:	02d00793          	li	a5,45
    1f18:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f1c:	479d                	li	a5,7
    1f1e:	bde9                	j	1df8 <printint.constprop.0+0x122>
    1f20:	479d                	li	a5,7
	if (sign)
    1f22:	ec055be3          	bgez	a0,1df8 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f26:	02d00793          	li	a5,45
    1f2a:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f2e:	4799                	li	a5,6
    1f30:	b5e1                	j	1df8 <printint.constprop.0+0x122>

0000000000001f32 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f32:	02000793          	li	a5,32
    1f36:	00f50663          	beq	a0,a5,1f42 <isspace+0x10>
    1f3a:	355d                	addiw	a0,a0,-9
    1f3c:	00553513          	sltiu	a0,a0,5
    1f40:	8082                	ret
    1f42:	4505                	li	a0,1
}
    1f44:	8082                	ret

0000000000001f46 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f46:	fd05051b          	addiw	a0,a0,-48
}
    1f4a:	00a53513          	sltiu	a0,a0,10
    1f4e:	8082                	ret

0000000000001f50 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f50:	02000613          	li	a2,32
    1f54:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f56:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f5a:	ff77869b          	addiw	a3,a5,-9
    1f5e:	04c78c63          	beq	a5,a2,1fb6 <atoi+0x66>
    1f62:	0007871b          	sext.w	a4,a5
    1f66:	04d5f863          	bgeu	a1,a3,1fb6 <atoi+0x66>
		s++;
	switch (*s) {
    1f6a:	02b00693          	li	a3,43
    1f6e:	04d78963          	beq	a5,a3,1fc0 <atoi+0x70>
    1f72:	02d00693          	li	a3,45
    1f76:	06d78263          	beq	a5,a3,1fda <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f7a:	fd07061b          	addiw	a2,a4,-48
    1f7e:	47a5                	li	a5,9
    1f80:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f82:	4e01                	li	t3,0
	while (isdigit(*s))
    1f84:	04c7e963          	bltu	a5,a2,1fd6 <atoi+0x86>
	int n = 0, neg = 0;
    1f88:	4501                	li	a0,0
	while (isdigit(*s))
    1f8a:	4825                	li	a6,9
    1f8c:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f90:	0025179b          	slliw	a5,a0,0x2
    1f94:	9fa9                	addw	a5,a5,a0
    1f96:	fd07031b          	addiw	t1,a4,-48
    1f9a:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f9e:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1fa2:	0685                	addi	a3,a3,1
    1fa4:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1fa8:	0006071b          	sext.w	a4,a2
    1fac:	feb870e3          	bgeu	a6,a1,1f8c <atoi+0x3c>
	return neg ? n : -n;
    1fb0:	000e0563          	beqz	t3,1fba <atoi+0x6a>
}
    1fb4:	8082                	ret
		s++;
    1fb6:	0505                	addi	a0,a0,1
    1fb8:	bf79                	j	1f56 <atoi+0x6>
	return neg ? n : -n;
    1fba:	4113053b          	subw	a0,t1,a7
    1fbe:	8082                	ret
	while (isdigit(*s))
    1fc0:	00154703          	lbu	a4,1(a0)
    1fc4:	47a5                	li	a5,9
		s++;
    1fc6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fca:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fce:	4e01                	li	t3,0
	while (isdigit(*s))
    1fd0:	2701                	sext.w	a4,a4
    1fd2:	fac7fbe3          	bgeu	a5,a2,1f88 <atoi+0x38>
    1fd6:	4501                	li	a0,0
}
    1fd8:	8082                	ret
	while (isdigit(*s))
    1fda:	00154703          	lbu	a4,1(a0)
    1fde:	47a5                	li	a5,9
		s++;
    1fe0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fe4:	fd07061b          	addiw	a2,a4,-48
    1fe8:	2701                	sext.w	a4,a4
    1fea:	fec7e6e3          	bltu	a5,a2,1fd6 <atoi+0x86>
		neg = 1;
    1fee:	4e05                	li	t3,1
    1ff0:	bf61                	j	1f88 <atoi+0x38>

0000000000001ff2 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ff2:	16060d63          	beqz	a2,216c <memset+0x17a>
    1ff6:	40a007b3          	neg	a5,a0
    1ffa:	8b9d                	andi	a5,a5,7
    1ffc:	00778693          	addi	a3,a5,7
    2000:	482d                	li	a6,11
    2002:	0ff5f713          	zext.b	a4,a1
    2006:	fff60593          	addi	a1,a2,-1
    200a:	1706e263          	bltu	a3,a6,216e <memset+0x17c>
    200e:	16d5ea63          	bltu	a1,a3,2182 <memset+0x190>
    2012:	16078563          	beqz	a5,217c <memset+0x18a>
    2016:	00e50023          	sb	a4,0(a0)
    201a:	4685                	li	a3,1
    201c:	00150593          	addi	a1,a0,1
    2020:	14d78c63          	beq	a5,a3,2178 <memset+0x186>
    2024:	00e500a3          	sb	a4,1(a0)
    2028:	4689                	li	a3,2
    202a:	00250593          	addi	a1,a0,2
    202e:	14d78d63          	beq	a5,a3,2188 <memset+0x196>
    2032:	00e50123          	sb	a4,2(a0)
    2036:	468d                	li	a3,3
    2038:	00350593          	addi	a1,a0,3
    203c:	12d78b63          	beq	a5,a3,2172 <memset+0x180>
    2040:	00e501a3          	sb	a4,3(a0)
    2044:	4691                	li	a3,4
    2046:	00450593          	addi	a1,a0,4
    204a:	14d78163          	beq	a5,a3,218c <memset+0x19a>
    204e:	00e50223          	sb	a4,4(a0)
    2052:	4695                	li	a3,5
    2054:	00550593          	addi	a1,a0,5
    2058:	12d78c63          	beq	a5,a3,2190 <memset+0x19e>
    205c:	00e502a3          	sb	a4,5(a0)
    2060:	469d                	li	a3,7
    2062:	00650593          	addi	a1,a0,6
    2066:	12d79763          	bne	a5,a3,2194 <memset+0x1a2>
    206a:	00750593          	addi	a1,a0,7
    206e:	00e50323          	sb	a4,6(a0)
    2072:	481d                	li	a6,7
    2074:	00871693          	slli	a3,a4,0x8
    2078:	01071893          	slli	a7,a4,0x10
    207c:	8ed9                	or	a3,a3,a4
    207e:	01871313          	slli	t1,a4,0x18
    2082:	0116e6b3          	or	a3,a3,a7
    2086:	0066e6b3          	or	a3,a3,t1
    208a:	02071893          	slli	a7,a4,0x20
    208e:	02871e13          	slli	t3,a4,0x28
    2092:	0116e6b3          	or	a3,a3,a7
    2096:	40f60333          	sub	t1,a2,a5
    209a:	03071893          	slli	a7,a4,0x30
    209e:	01c6e6b3          	or	a3,a3,t3
    20a2:	0116e6b3          	or	a3,a3,a7
    20a6:	03871e13          	slli	t3,a4,0x38
    20aa:	97aa                	add	a5,a5,a0
    20ac:	ff837893          	andi	a7,t1,-8
    20b0:	01c6e6b3          	or	a3,a3,t3
    20b4:	98be                	add	a7,a7,a5
    20b6:	e394                	sd	a3,0(a5)
    20b8:	07a1                	addi	a5,a5,8
    20ba:	ff179ee3          	bne	a5,a7,20b6 <memset+0xc4>
    20be:	ff837893          	andi	a7,t1,-8
    20c2:	011587b3          	add	a5,a1,a7
    20c6:	010886bb          	addw	a3,a7,a6
    20ca:	0b130663          	beq	t1,a7,2176 <memset+0x184>
    20ce:	00e78023          	sb	a4,0(a5)
    20d2:	0016859b          	addiw	a1,a3,1
    20d6:	08c5fb63          	bgeu	a1,a2,216c <memset+0x17a>
    20da:	00e780a3          	sb	a4,1(a5)
    20de:	0026859b          	addiw	a1,a3,2
    20e2:	08c5f563          	bgeu	a1,a2,216c <memset+0x17a>
    20e6:	00e78123          	sb	a4,2(a5)
    20ea:	0036859b          	addiw	a1,a3,3
    20ee:	06c5ff63          	bgeu	a1,a2,216c <memset+0x17a>
    20f2:	00e781a3          	sb	a4,3(a5)
    20f6:	0046859b          	addiw	a1,a3,4
    20fa:	06c5f963          	bgeu	a1,a2,216c <memset+0x17a>
    20fe:	00e78223          	sb	a4,4(a5)
    2102:	0056859b          	addiw	a1,a3,5
    2106:	06c5f363          	bgeu	a1,a2,216c <memset+0x17a>
    210a:	00e782a3          	sb	a4,5(a5)
    210e:	0066859b          	addiw	a1,a3,6
    2112:	04c5fd63          	bgeu	a1,a2,216c <memset+0x17a>
    2116:	00e78323          	sb	a4,6(a5)
    211a:	0076859b          	addiw	a1,a3,7
    211e:	04c5f763          	bgeu	a1,a2,216c <memset+0x17a>
    2122:	00e783a3          	sb	a4,7(a5)
    2126:	0086859b          	addiw	a1,a3,8
    212a:	04c5f163          	bgeu	a1,a2,216c <memset+0x17a>
    212e:	00e78423          	sb	a4,8(a5)
    2132:	0096859b          	addiw	a1,a3,9
    2136:	02c5fb63          	bgeu	a1,a2,216c <memset+0x17a>
    213a:	00e784a3          	sb	a4,9(a5)
    213e:	00a6859b          	addiw	a1,a3,10
    2142:	02c5f563          	bgeu	a1,a2,216c <memset+0x17a>
    2146:	00e78523          	sb	a4,10(a5)
    214a:	00b6859b          	addiw	a1,a3,11
    214e:	00c5ff63          	bgeu	a1,a2,216c <memset+0x17a>
    2152:	00e785a3          	sb	a4,11(a5)
    2156:	00c6859b          	addiw	a1,a3,12
    215a:	00c5f963          	bgeu	a1,a2,216c <memset+0x17a>
    215e:	00e78623          	sb	a4,12(a5)
    2162:	26b5                	addiw	a3,a3,13
    2164:	00c6f463          	bgeu	a3,a2,216c <memset+0x17a>
    2168:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    216c:	8082                	ret
    216e:	46ad                	li	a3,11
    2170:	bd79                	j	200e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2172:	480d                	li	a6,3
    2174:	b701                	j	2074 <memset+0x82>
    2176:	8082                	ret
    2178:	4805                	li	a6,1
    217a:	bded                	j	2074 <memset+0x82>
    217c:	85aa                	mv	a1,a0
    217e:	4801                	li	a6,0
    2180:	bdd5                	j	2074 <memset+0x82>
    2182:	87aa                	mv	a5,a0
    2184:	4681                	li	a3,0
    2186:	b7a1                	j	20ce <memset+0xdc>
    2188:	4809                	li	a6,2
    218a:	b5ed                	j	2074 <memset+0x82>
    218c:	4811                	li	a6,4
    218e:	b5dd                	j	2074 <memset+0x82>
    2190:	4815                	li	a6,5
    2192:	b5cd                	j	2074 <memset+0x82>
    2194:	4819                	li	a6,6
    2196:	bdf9                	j	2074 <memset+0x82>

0000000000002198 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2198:	00054783          	lbu	a5,0(a0)
    219c:	0005c703          	lbu	a4,0(a1)
    21a0:	00e79863          	bne	a5,a4,21b0 <strcmp+0x18>
    21a4:	0505                	addi	a0,a0,1
    21a6:	0585                	addi	a1,a1,1
    21a8:	fbe5                	bnez	a5,2198 <strcmp>
    21aa:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    21ac:	9d19                	subw	a0,a0,a4
    21ae:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    21b0:	0007851b          	sext.w	a0,a5
    21b4:	bfe5                	j	21ac <strcmp+0x14>

00000000000021b6 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21b6:	ca15                	beqz	a2,21ea <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21b8:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21bc:	167d                	addi	a2,a2,-1
    21be:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21c2:	eb99                	bnez	a5,21d8 <strncmp+0x22>
    21c4:	a815                	j	21f8 <strncmp+0x42>
    21c6:	00a68e63          	beq	a3,a0,21e2 <strncmp+0x2c>
    21ca:	0505                	addi	a0,a0,1
    21cc:	00f71b63          	bne	a4,a5,21e2 <strncmp+0x2c>
    21d0:	00054783          	lbu	a5,0(a0)
    21d4:	cf89                	beqz	a5,21ee <strncmp+0x38>
    21d6:	85b2                	mv	a1,a2
    21d8:	0005c703          	lbu	a4,0(a1)
    21dc:	00158613          	addi	a2,a1,1
    21e0:	f37d                	bnez	a4,21c6 <strncmp+0x10>
		;
	return *l - *r;
    21e2:	0007851b          	sext.w	a0,a5
    21e6:	9d19                	subw	a0,a0,a4
    21e8:	8082                	ret
		return 0;
    21ea:	4501                	li	a0,0
}
    21ec:	8082                	ret
	return *l - *r;
    21ee:	0015c703          	lbu	a4,1(a1)
    21f2:	4501                	li	a0,0
    21f4:	9d19                	subw	a0,a0,a4
    21f6:	8082                	ret
    21f8:	0005c703          	lbu	a4,0(a1)
    21fc:	4501                	li	a0,0
    21fe:	b7e5                	j	21e6 <strncmp+0x30>

0000000000002200 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2200:	00757793          	andi	a5,a0,7
    2204:	cf89                	beqz	a5,221e <strlen+0x1e>
    2206:	87aa                	mv	a5,a0
    2208:	a029                	j	2212 <strlen+0x12>
    220a:	0785                	addi	a5,a5,1
    220c:	0077f713          	andi	a4,a5,7
    2210:	cb01                	beqz	a4,2220 <strlen+0x20>
		if (!*s)
    2212:	0007c703          	lbu	a4,0(a5)
    2216:	fb75                	bnez	a4,220a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2218:	40a78533          	sub	a0,a5,a0
}
    221c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    221e:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2220:	6394                	ld	a3,0(a5)
    2222:	00000597          	auipc	a1,0x0
    2226:	5465b583          	ld	a1,1350(a1) # 2768 <basename+0x1c2>
    222a:	00000617          	auipc	a2,0x0
    222e:	54663603          	ld	a2,1350(a2) # 2770 <basename+0x1ca>
    2232:	a019                	j	2238 <strlen+0x38>
    2234:	6794                	ld	a3,8(a5)
    2236:	07a1                	addi	a5,a5,8
    2238:	00b68733          	add	a4,a3,a1
    223c:	fff6c693          	not	a3,a3
    2240:	8f75                	and	a4,a4,a3
    2242:	8f71                	and	a4,a4,a2
    2244:	db65                	beqz	a4,2234 <strlen+0x34>
	for (; *s; s++)
    2246:	0007c703          	lbu	a4,0(a5)
    224a:	d779                	beqz	a4,2218 <strlen+0x18>
    224c:	0017c703          	lbu	a4,1(a5)
    2250:	0785                	addi	a5,a5,1
    2252:	d379                	beqz	a4,2218 <strlen+0x18>
    2254:	0017c703          	lbu	a4,1(a5)
    2258:	0785                	addi	a5,a5,1
    225a:	fb6d                	bnez	a4,224c <strlen+0x4c>
    225c:	bf75                	j	2218 <strlen+0x18>

000000000000225e <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    225e:	00757713          	andi	a4,a0,7
{
    2262:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2264:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2268:	cb19                	beqz	a4,227e <memchr+0x20>
    226a:	ce25                	beqz	a2,22e2 <memchr+0x84>
    226c:	0007c703          	lbu	a4,0(a5)
    2270:	04b70e63          	beq	a4,a1,22cc <memchr+0x6e>
    2274:	0785                	addi	a5,a5,1
    2276:	0077f713          	andi	a4,a5,7
    227a:	167d                	addi	a2,a2,-1
    227c:	f77d                	bnez	a4,226a <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    227e:	4501                	li	a0,0
	if (n && *s != c) {
    2280:	c235                	beqz	a2,22e4 <memchr+0x86>
    2282:	0007c703          	lbu	a4,0(a5)
    2286:	04b70363          	beq	a4,a1,22cc <memchr+0x6e>
		size_t k = ONES * c;
    228a:	00000517          	auipc	a0,0x0
    228e:	4ee53503          	ld	a0,1262(a0) # 2778 <basename+0x1d2>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2292:	471d                	li	a4,7
		size_t k = ONES * c;
    2294:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2298:	02c77a63          	bgeu	a4,a2,22cc <memchr+0x6e>
    229c:	00000897          	auipc	a7,0x0
    22a0:	4cc8b883          	ld	a7,1228(a7) # 2768 <basename+0x1c2>
    22a4:	00000817          	auipc	a6,0x0
    22a8:	4cc83803          	ld	a6,1228(a6) # 2770 <basename+0x1ca>
    22ac:	431d                	li	t1,7
    22ae:	a029                	j	22b8 <memchr+0x5a>
		     w++, n -= SS)
    22b0:	1661                	addi	a2,a2,-8
    22b2:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22b4:	02c37963          	bgeu	t1,a2,22e6 <memchr+0x88>
    22b8:	6398                	ld	a4,0(a5)
    22ba:	8f29                	xor	a4,a4,a0
    22bc:	011706b3          	add	a3,a4,a7
    22c0:	fff74713          	not	a4,a4
    22c4:	8f75                	and	a4,a4,a3
    22c6:	01077733          	and	a4,a4,a6
    22ca:	d37d                	beqz	a4,22b0 <memchr+0x52>
{
    22cc:	853e                	mv	a0,a5
    22ce:	97b2                	add	a5,a5,a2
    22d0:	a021                	j	22d8 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22d2:	0505                	addi	a0,a0,1
    22d4:	00f50763          	beq	a0,a5,22e2 <memchr+0x84>
    22d8:	00054703          	lbu	a4,0(a0)
    22dc:	feb71be3          	bne	a4,a1,22d2 <memchr+0x74>
    22e0:	8082                	ret
	return n ? (void *)s : 0;
    22e2:	4501                	li	a0,0
}
    22e4:	8082                	ret
	return n ? (void *)s : 0;
    22e6:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22e8:	f275                	bnez	a2,22cc <memchr+0x6e>
}
    22ea:	8082                	ret

00000000000022ec <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22ec:	1101                	addi	sp,sp,-32
    22ee:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22f0:	862e                	mv	a2,a1
{
    22f2:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22f4:	4581                	li	a1,0
{
    22f6:	e426                	sd	s1,8(sp)
    22f8:	ec06                	sd	ra,24(sp)
    22fa:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22fc:	f63ff0ef          	jal	ra,225e <memchr>
	return p ? p - s : n;
    2300:	c519                	beqz	a0,230e <strnlen+0x22>
}
    2302:	60e2                	ld	ra,24(sp)
    2304:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2306:	8d05                	sub	a0,a0,s1
}
    2308:	64a2                	ld	s1,8(sp)
    230a:	6105                	addi	sp,sp,32
    230c:	8082                	ret
    230e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2310:	8522                	mv	a0,s0
}
    2312:	6442                	ld	s0,16(sp)
    2314:	64a2                	ld	s1,8(sp)
    2316:	6105                	addi	sp,sp,32
    2318:	8082                	ret

000000000000231a <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    231a:	00a5c7b3          	xor	a5,a1,a0
    231e:	8b9d                	andi	a5,a5,7
    2320:	eb95                	bnez	a5,2354 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2322:	0075f793          	andi	a5,a1,7
    2326:	e7b1                	bnez	a5,2372 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2328:	6198                	ld	a4,0(a1)
    232a:	00000617          	auipc	a2,0x0
    232e:	43e63603          	ld	a2,1086(a2) # 2768 <basename+0x1c2>
    2332:	00000817          	auipc	a6,0x0
    2336:	43e83803          	ld	a6,1086(a6) # 2770 <basename+0x1ca>
    233a:	a029                	j	2344 <stpcpy+0x2a>
    233c:	05a1                	addi	a1,a1,8
    233e:	e118                	sd	a4,0(a0)
    2340:	6198                	ld	a4,0(a1)
    2342:	0521                	addi	a0,a0,8
    2344:	00c707b3          	add	a5,a4,a2
    2348:	fff74693          	not	a3,a4
    234c:	8ff5                	and	a5,a5,a3
    234e:	0107f7b3          	and	a5,a5,a6
    2352:	d7ed                	beqz	a5,233c <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2354:	0005c783          	lbu	a5,0(a1)
    2358:	00f50023          	sb	a5,0(a0)
    235c:	c785                	beqz	a5,2384 <stpcpy+0x6a>
    235e:	0015c783          	lbu	a5,1(a1)
    2362:	0505                	addi	a0,a0,1
    2364:	0585                	addi	a1,a1,1
    2366:	00f50023          	sb	a5,0(a0)
    236a:	fbf5                	bnez	a5,235e <stpcpy+0x44>
		;
	return d;
}
    236c:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    236e:	0505                	addi	a0,a0,1
    2370:	df45                	beqz	a4,2328 <stpcpy+0xe>
			if (!(*d = *s))
    2372:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2376:	0585                	addi	a1,a1,1
    2378:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    237c:	00f50023          	sb	a5,0(a0)
    2380:	f7fd                	bnez	a5,236e <stpcpy+0x54>
}
    2382:	8082                	ret
    2384:	8082                	ret

0000000000002386 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2386:	00a5c7b3          	xor	a5,a1,a0
    238a:	8b9d                	andi	a5,a5,7
    238c:	1a079863          	bnez	a5,253c <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2390:	0075f793          	andi	a5,a1,7
    2394:	16078463          	beqz	a5,24fc <stpncpy+0x176>
    2398:	ea01                	bnez	a2,23a8 <stpncpy+0x22>
    239a:	a421                	j	25a2 <stpncpy+0x21c>
    239c:	167d                	addi	a2,a2,-1
    239e:	0505                	addi	a0,a0,1
    23a0:	14070e63          	beqz	a4,24fc <stpncpy+0x176>
    23a4:	1a060863          	beqz	a2,2554 <stpncpy+0x1ce>
    23a8:	0005c783          	lbu	a5,0(a1)
    23ac:	0585                	addi	a1,a1,1
    23ae:	0075f713          	andi	a4,a1,7
    23b2:	00f50023          	sb	a5,0(a0)
    23b6:	f3fd                	bnez	a5,239c <stpncpy+0x16>
    23b8:	4805                	li	a6,1
    23ba:	1a061863          	bnez	a2,256a <stpncpy+0x1e4>
    23be:	40a007b3          	neg	a5,a0
    23c2:	8b9d                	andi	a5,a5,7
    23c4:	4681                	li	a3,0
    23c6:	18061a63          	bnez	a2,255a <stpncpy+0x1d4>
    23ca:	00778713          	addi	a4,a5,7
    23ce:	45ad                	li	a1,11
    23d0:	18b76363          	bltu	a4,a1,2556 <stpncpy+0x1d0>
    23d4:	1ae6eb63          	bltu	a3,a4,258a <stpncpy+0x204>
    23d8:	1a078363          	beqz	a5,257e <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23dc:	00050023          	sb	zero,0(a0)
    23e0:	4685                	li	a3,1
    23e2:	00150713          	addi	a4,a0,1
    23e6:	18d78f63          	beq	a5,a3,2584 <stpncpy+0x1fe>
    23ea:	000500a3          	sb	zero,1(a0)
    23ee:	4689                	li	a3,2
    23f0:	00250713          	addi	a4,a0,2
    23f4:	18d78e63          	beq	a5,a3,2590 <stpncpy+0x20a>
    23f8:	00050123          	sb	zero,2(a0)
    23fc:	468d                	li	a3,3
    23fe:	00350713          	addi	a4,a0,3
    2402:	16d78c63          	beq	a5,a3,257a <stpncpy+0x1f4>
    2406:	000501a3          	sb	zero,3(a0)
    240a:	4691                	li	a3,4
    240c:	00450713          	addi	a4,a0,4
    2410:	18d78263          	beq	a5,a3,2594 <stpncpy+0x20e>
    2414:	00050223          	sb	zero,4(a0)
    2418:	4695                	li	a3,5
    241a:	00550713          	addi	a4,a0,5
    241e:	16d78d63          	beq	a5,a3,2598 <stpncpy+0x212>
    2422:	000502a3          	sb	zero,5(a0)
    2426:	469d                	li	a3,7
    2428:	00650713          	addi	a4,a0,6
    242c:	16d79863          	bne	a5,a3,259c <stpncpy+0x216>
    2430:	00750713          	addi	a4,a0,7
    2434:	00050323          	sb	zero,6(a0)
    2438:	40f80833          	sub	a6,a6,a5
    243c:	ff887593          	andi	a1,a6,-8
    2440:	97aa                	add	a5,a5,a0
    2442:	95be                	add	a1,a1,a5
    2444:	0007b023          	sd	zero,0(a5)
    2448:	07a1                	addi	a5,a5,8
    244a:	feb79de3          	bne	a5,a1,2444 <stpncpy+0xbe>
    244e:	ff887593          	andi	a1,a6,-8
    2452:	9ead                	addw	a3,a3,a1
    2454:	00b707b3          	add	a5,a4,a1
    2458:	12b80863          	beq	a6,a1,2588 <stpncpy+0x202>
    245c:	00078023          	sb	zero,0(a5)
    2460:	0016871b          	addiw	a4,a3,1
    2464:	0ec77863          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    2468:	000780a3          	sb	zero,1(a5)
    246c:	0026871b          	addiw	a4,a3,2
    2470:	0ec77263          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    2474:	00078123          	sb	zero,2(a5)
    2478:	0036871b          	addiw	a4,a3,3
    247c:	0cc77c63          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    2480:	000781a3          	sb	zero,3(a5)
    2484:	0046871b          	addiw	a4,a3,4
    2488:	0cc77663          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    248c:	00078223          	sb	zero,4(a5)
    2490:	0056871b          	addiw	a4,a3,5
    2494:	0cc77063          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    2498:	000782a3          	sb	zero,5(a5)
    249c:	0066871b          	addiw	a4,a3,6
    24a0:	0ac77a63          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24a4:	00078323          	sb	zero,6(a5)
    24a8:	0076871b          	addiw	a4,a3,7
    24ac:	0ac77463          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24b0:	000783a3          	sb	zero,7(a5)
    24b4:	0086871b          	addiw	a4,a3,8
    24b8:	08c77e63          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24bc:	00078423          	sb	zero,8(a5)
    24c0:	0096871b          	addiw	a4,a3,9
    24c4:	08c77863          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24c8:	000784a3          	sb	zero,9(a5)
    24cc:	00a6871b          	addiw	a4,a3,10
    24d0:	08c77263          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24d4:	00078523          	sb	zero,10(a5)
    24d8:	00b6871b          	addiw	a4,a3,11
    24dc:	06c77c63          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24e0:	000785a3          	sb	zero,11(a5)
    24e4:	00c6871b          	addiw	a4,a3,12
    24e8:	06c77663          	bgeu	a4,a2,2554 <stpncpy+0x1ce>
    24ec:	00078623          	sb	zero,12(a5)
    24f0:	26b5                	addiw	a3,a3,13
    24f2:	06c6f163          	bgeu	a3,a2,2554 <stpncpy+0x1ce>
    24f6:	000786a3          	sb	zero,13(a5)
    24fa:	8082                	ret
			;
		if (!n || !*s)
    24fc:	c645                	beqz	a2,25a4 <stpncpy+0x21e>
    24fe:	0005c783          	lbu	a5,0(a1)
    2502:	ea078be3          	beqz	a5,23b8 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2506:	479d                	li	a5,7
    2508:	02c7ff63          	bgeu	a5,a2,2546 <stpncpy+0x1c0>
    250c:	00000897          	auipc	a7,0x0
    2510:	25c8b883          	ld	a7,604(a7) # 2768 <basename+0x1c2>
    2514:	00000817          	auipc	a6,0x0
    2518:	25c83803          	ld	a6,604(a6) # 2770 <basename+0x1ca>
    251c:	431d                	li	t1,7
    251e:	6198                	ld	a4,0(a1)
    2520:	011707b3          	add	a5,a4,a7
    2524:	fff74693          	not	a3,a4
    2528:	8ff5                	and	a5,a5,a3
    252a:	0107f7b3          	and	a5,a5,a6
    252e:	ef81                	bnez	a5,2546 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2530:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2532:	1661                	addi	a2,a2,-8
    2534:	05a1                	addi	a1,a1,8
    2536:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2538:	fec363e3          	bltu	t1,a2,251e <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    253c:	e609                	bnez	a2,2546 <stpncpy+0x1c0>
    253e:	a08d                	j	25a0 <stpncpy+0x21a>
    2540:	167d                	addi	a2,a2,-1
    2542:	0505                	addi	a0,a0,1
    2544:	ca01                	beqz	a2,2554 <stpncpy+0x1ce>
    2546:	0005c783          	lbu	a5,0(a1)
    254a:	0585                	addi	a1,a1,1
    254c:	00f50023          	sb	a5,0(a0)
    2550:	fbe5                	bnez	a5,2540 <stpncpy+0x1ba>
		;
tail:
    2552:	b59d                	j	23b8 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2554:	8082                	ret
    2556:	472d                	li	a4,11
    2558:	bdb5                	j	23d4 <stpncpy+0x4e>
    255a:	00778713          	addi	a4,a5,7
    255e:	45ad                	li	a1,11
    2560:	fff60693          	addi	a3,a2,-1
    2564:	e6b778e3          	bgeu	a4,a1,23d4 <stpncpy+0x4e>
    2568:	b7fd                	j	2556 <stpncpy+0x1d0>
    256a:	40a007b3          	neg	a5,a0
    256e:	8832                	mv	a6,a2
    2570:	8b9d                	andi	a5,a5,7
    2572:	4681                	li	a3,0
    2574:	e4060be3          	beqz	a2,23ca <stpncpy+0x44>
    2578:	b7cd                	j	255a <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    257a:	468d                	li	a3,3
    257c:	bd75                	j	2438 <stpncpy+0xb2>
    257e:	872a                	mv	a4,a0
    2580:	4681                	li	a3,0
    2582:	bd5d                	j	2438 <stpncpy+0xb2>
    2584:	4685                	li	a3,1
    2586:	bd4d                	j	2438 <stpncpy+0xb2>
    2588:	8082                	ret
    258a:	87aa                	mv	a5,a0
    258c:	4681                	li	a3,0
    258e:	b5f9                	j	245c <stpncpy+0xd6>
    2590:	4689                	li	a3,2
    2592:	b55d                	j	2438 <stpncpy+0xb2>
    2594:	4691                	li	a3,4
    2596:	b54d                	j	2438 <stpncpy+0xb2>
    2598:	4695                	li	a3,5
    259a:	bd79                	j	2438 <stpncpy+0xb2>
    259c:	4699                	li	a3,6
    259e:	bd69                	j	2438 <stpncpy+0xb2>
    25a0:	8082                	ret
    25a2:	8082                	ret
    25a4:	8082                	ret

00000000000025a6 <basename>:

char *basename(char *s)
{
    25a6:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    25a8:	c54d                	beqz	a0,2652 <basename+0xac>
    25aa:	00054783          	lbu	a5,0(a0)
		return ".";
    25ae:	00000517          	auipc	a0,0x0
    25b2:	1b250513          	addi	a0,a0,434 # 2760 <basename+0x1ba>
	if (!s || !*s)
    25b6:	e391                	bnez	a5,25ba <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25b8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25ba:	0076f713          	andi	a4,a3,7
    25be:	87b6                	mv	a5,a3
    25c0:	cf51                	beqz	a4,265c <basename+0xb6>
    25c2:	0785                	addi	a5,a5,1
    25c4:	0077f713          	andi	a4,a5,7
    25c8:	c729                	beqz	a4,2612 <basename+0x6c>
		if (!*s)
    25ca:	0007c703          	lbu	a4,0(a5)
    25ce:	fb75                	bnez	a4,25c2 <basename+0x1c>
	return s - a;
    25d0:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25d2:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25d4:	cf8d                	beqz	a5,260e <basename+0x68>
    25d6:	00f68733          	add	a4,a3,a5
    25da:	02f00593          	li	a1,47
    25de:	a031                	j	25ea <basename+0x44>
		s[i] = 0;
    25e0:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25e4:	17fd                	addi	a5,a5,-1
    25e6:	177d                	addi	a4,a4,-1
    25e8:	c39d                	beqz	a5,260e <basename+0x68>
    25ea:	00074603          	lbu	a2,0(a4)
    25ee:	feb609e3          	beq	a2,a1,25e0 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25f2:	02f00613          	li	a2,47
    25f6:	a011                	j	25fa <basename+0x54>
    25f8:	cb99                	beqz	a5,260e <basename+0x68>
    25fa:	853e                	mv	a0,a5
    25fc:	17fd                	addi	a5,a5,-1
    25fe:	00f68733          	add	a4,a3,a5
    2602:	00074703          	lbu	a4,0(a4)
    2606:	fec719e3          	bne	a4,a2,25f8 <basename+0x52>
	return s + i;
    260a:	9536                	add	a0,a0,a3
    260c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    260e:	8536                	mv	a0,a3
    2610:	8082                	ret
    2612:	6390                	ld	a2,0(a5)
    2614:	00000517          	auipc	a0,0x0
    2618:	15453503          	ld	a0,340(a0) # 2768 <basename+0x1c2>
    261c:	00000597          	auipc	a1,0x0
    2620:	1545b583          	ld	a1,340(a1) # 2770 <basename+0x1ca>
    2624:	fff64713          	not	a4,a2
    2628:	962a                	add	a2,a2,a0
    262a:	8f71                	and	a4,a4,a2
    262c:	8f6d                	and	a4,a4,a1
    262e:	eb11                	bnez	a4,2642 <basename+0x9c>
    2630:	6790                	ld	a2,8(a5)
    2632:	07a1                	addi	a5,a5,8
    2634:	00a60733          	add	a4,a2,a0
    2638:	fff64613          	not	a2,a2
    263c:	8f71                	and	a4,a4,a2
    263e:	8f6d                	and	a4,a4,a1
    2640:	db65                	beqz	a4,2630 <basename+0x8a>
	for (; *s; s++)
    2642:	0007c703          	lbu	a4,0(a5)
    2646:	d749                	beqz	a4,25d0 <basename+0x2a>
    2648:	0017c703          	lbu	a4,1(a5)
    264c:	0785                	addi	a5,a5,1
    264e:	ff6d                	bnez	a4,2648 <basename+0xa2>
    2650:	b741                	j	25d0 <basename+0x2a>
		return ".";
    2652:	00000517          	auipc	a0,0x0
    2656:	10e50513          	addi	a0,a0,270 # 2760 <basename+0x1ba>
    265a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    265c:	6290                	ld	a2,0(a3)
    265e:	00000517          	auipc	a0,0x0
    2662:	10a53503          	ld	a0,266(a0) # 2768 <basename+0x1c2>
    2666:	00000597          	auipc	a1,0x0
    266a:	10a5b583          	ld	a1,266(a1) # 2770 <basename+0x1ca>
    266e:	fff64713          	not	a4,a2
    2672:	962a                	add	a2,a2,a0
    2674:	8f71                	and	a4,a4,a2
    2676:	8f6d                	and	a4,a4,a1
    2678:	df45                	beqz	a4,2630 <basename+0x8a>
    267a:	b7f9                	j	2648 <basename+0xa2>
