
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_mut_race:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a469                	j	128a <__start_main>

0000000000001002 <fun>:
int a;

int threads[thread_count];

void fun(long i)
{
    1002:	715d                	addi	sp,sp,-80
    1004:	fc26                	sd	s1,56(sp)
	int t = i + 1;
	for (int i = 0; i < per_thread; i++) {
		assert_eq(mutex_lock(mutex_id), 0);
		int old_a = a;
		for (int i = 0; i < 500; i++) {
			t = t * t % 10007;
    1006:	6489                	lui	s1,0x2
{
    1008:	e0a2                	sd	s0,64(sp)
    100a:	f84a                	sd	s2,48(sp)
    100c:	f44e                	sd	s3,40(sp)
    100e:	f052                	sd	s4,32(sp)
    1010:	ec56                	sd	s5,24(sp)
    1012:	e85a                	sd	s6,16(sp)
    1014:	e486                	sd	ra,72(sp)
    1016:	e45e                	sd	s7,8(sp)
    1018:	e062                	sd	s8,0(sp)
	int t = i + 1;
    101a:	0015041b          	addiw	s0,a0,1
    101e:	06400993          	li	s3,100
    1022:	00002917          	auipc	s2,0x2
    1026:	b3e90913          	addi	s2,s2,-1218 # 2b60 <mutex_id>
		assert_eq(mutex_lock(mutex_id), 0);
    102a:	00002b17          	auipc	s6,0x2
    102e:	8c6b0b13          	addi	s6,s6,-1850 # 28f0 <enable_deadlock_detect+0xc>
    1032:	00002a97          	auipc	s5,0x2
    1036:	906a8a93          	addi	s5,s5,-1786 # 2938 <enable_deadlock_detect+0x54>
    103a:	00002a17          	auipc	s4,0x2
    103e:	906a0a13          	addi	s4,s4,-1786 # 2940 <enable_deadlock_detect+0x5c>
			t = t * t % 10007;
    1042:	7174849b          	addiw	s1,s1,1815
		assert_eq(mutex_lock(mutex_id), 0);
    1046:	00092503          	lw	a0,0(s2)
    104a:	03b010ef          	jal	ra,2884 <mutex_lock>
    104e:	ed35                	bnez	a0,10ca <fun+0xc8>
		int old_a = a;
    1050:	00492703          	lw	a4,4(s2)
    1054:	1f400793          	li	a5,500
			t = t * t % 10007;
    1058:	0284043b          	mulw	s0,s0,s0
		for (int i = 0; i < 500; i++) {
    105c:	37fd                	addiw	a5,a5,-1
			t = t * t % 10007;
    105e:	0294643b          	remw	s0,s0,s1
		for (int i = 0; i < 500; i++) {
    1062:	fbfd                	bnez	a5,1058 <fun+0x56>
		}
		a = old_a + 1;
		assert_eq(mutex_unlock(mutex_id), 0);
    1064:	00092503          	lw	a0,0(s2)
		a = old_a + 1;
    1068:	0017079b          	addiw	a5,a4,1
    106c:	00f92223          	sw	a5,4(s2)
		assert_eq(mutex_unlock(mutex_id), 0);
    1070:	021010ef          	jal	ra,2890 <mutex_unlock>
    1074:	e115                	bnez	a0,1098 <fun+0x96>
	for (int i = 0; i < per_thread; i++) {
    1076:	39fd                	addiw	s3,s3,-1
    1078:	fc0997e3          	bnez	s3,1046 <fun+0x44>
	}
	exit(t);
    107c:	8522                	mv	a0,s0
}
    107e:	6406                	ld	s0,64(sp)
    1080:	60a6                	ld	ra,72(sp)
    1082:	74e2                	ld	s1,56(sp)
    1084:	7942                	ld	s2,48(sp)
    1086:	79a2                	ld	s3,40(sp)
    1088:	7a02                	ld	s4,32(sp)
    108a:	6ae2                	ld	s5,24(sp)
    108c:	6b42                	ld	s6,16(sp)
    108e:	6ba2                	ld	s7,8(sp)
    1090:	6c02                	ld	s8,0(sp)
    1092:	6161                	addi	sp,sp,80
	exit(t);
    1094:	5b20106f          	j	2646 <exit>
		assert_eq(mutex_unlock(mutex_id), 0);
    1098:	57e010ef          	jal	ra,2616 <getpid>
    109c:	8baa                	mv	s7,a0
    109e:	855a                	mv	a0,s6
    10a0:	44c010ef          	jal	ra,24ec <basename>
    10a4:	8c2a                	mv	s8,a0
    10a6:	00092503          	lw	a0,0(s2)
    10aa:	7e6010ef          	jal	ra,2890 <mutex_unlock>
    10ae:	882a                	mv	a6,a0
    10b0:	4881                	li	a7,0
    10b2:	8552                	mv	a0,s4
    10b4:	47ed                	li	a5,27
    10b6:	8762                	mv	a4,s8
    10b8:	86de                	mv	a3,s7
    10ba:	8656                	mv	a2,s5
    10bc:	45fd                	li	a1,31
    10be:	326000ef          	jal	ra,13e4 <printf>
    10c2:	557d                	li	a0,-1
    10c4:	582010ef          	jal	ra,2646 <exit>
    10c8:	b77d                	j	1076 <fun+0x74>
		assert_eq(mutex_lock(mutex_id), 0);
    10ca:	54c010ef          	jal	ra,2616 <getpid>
    10ce:	8baa                	mv	s7,a0
    10d0:	855a                	mv	a0,s6
    10d2:	41a010ef          	jal	ra,24ec <basename>
    10d6:	8c2a                	mv	s8,a0
    10d8:	00092503          	lw	a0,0(s2)
    10dc:	7a8010ef          	jal	ra,2884 <mutex_lock>
    10e0:	882a                	mv	a6,a0
    10e2:	4881                	li	a7,0
    10e4:	8552                	mv	a0,s4
    10e6:	47d5                	li	a5,21
    10e8:	8762                	mv	a4,s8
    10ea:	86de                	mv	a3,s7
    10ec:	8656                	mv	a2,s5
    10ee:	45fd                	li	a1,31
    10f0:	2f4000ef          	jal	ra,13e4 <printf>
    10f4:	557d                	li	a0,-1
    10f6:	550010ef          	jal	ra,2646 <exit>
    10fa:	bf99                	j	1050 <fun+0x4e>

00000000000010fc <main>:

int main()
{
    10fc:	711d                	addi	sp,sp,-96
    10fe:	ec86                	sd	ra,88(sp)
    1100:	f456                	sd	s5,40(sp)
    1102:	f05a                	sd	s6,32(sp)
    1104:	e8a2                	sd	s0,80(sp)
    1106:	e4a6                	sd	s1,72(sp)
    1108:	e0ca                	sd	s2,64(sp)
    110a:	fc4e                	sd	s3,56(sp)
    110c:	f852                	sd	s4,48(sp)
    110e:	ec5e                	sd	s7,24(sp)
    1110:	e862                	sd	s8,16(sp)
    1112:	e466                	sd	s9,8(sp)
    1114:	e06a                	sd	s10,0(sp)
	int64 start = get_mtime();
    1116:	56a010ef          	jal	ra,2680 <get_mtime>
    111a:	8aaa                	mv	s5,a0
	assert((mutex_id = mutex_blocking_create()) >= 0);
    111c:	00002b17          	auipc	s6,0x2
    1120:	a44b0b13          	addi	s6,s6,-1468 # 2b60 <mutex_id>
    1124:	752010ef          	jal	ra,2876 <mutex_blocking_create>
    1128:	00ab2023          	sw	a0,0(s6)
    112c:	12054363          	bltz	a0,1252 <main+0x156>
    1130:	00002417          	auipc	s0,0x2
    1134:	a3840413          	addi	s0,s0,-1480 # 2b68 <threads>
{
    1138:	8922                	mv	s2,s0
    113a:	4481                	li	s1,0
	for (int i = 0; i < thread_count; i++) {
		threads[i] = thread_create(fun, (void *)i);
    113c:	00000a17          	auipc	s4,0x0
    1140:	ec6a0a13          	addi	s4,s4,-314 # 1002 <fun>
		assert(threads[i] > 0);
    1144:	00001c97          	auipc	s9,0x1
    1148:	7acc8c93          	addi	s9,s9,1964 # 28f0 <enable_deadlock_detect+0xc>
    114c:	00001c17          	auipc	s8,0x1
    1150:	7ecc0c13          	addi	s8,s8,2028 # 2938 <enable_deadlock_detect+0x54>
    1154:	00002b97          	auipc	s7,0x2
    1158:	87cb8b93          	addi	s7,s7,-1924 # 29d0 <enable_deadlock_detect+0xec>
	for (int i = 0; i < thread_count; i++) {
    115c:	49bd                	li	s3,15
    115e:	a021                	j	1166 <main+0x6a>
    1160:	0911                	addi	s2,s2,4
    1162:	05348063          	beq	s1,s3,11a2 <main+0xa6>
		threads[i] = thread_create(fun, (void *)i);
    1166:	85a6                	mv	a1,s1
    1168:	8552                	mv	a0,s4
    116a:	68e010ef          	jal	ra,27f8 <thread_create>
    116e:	00a92023          	sw	a0,0(s2)
	for (int i = 0; i < thread_count; i++) {
    1172:	0485                	addi	s1,s1,1
		assert(threads[i] > 0);
    1174:	fea046e3          	bgtz	a0,1160 <main+0x64>
    1178:	49e010ef          	jal	ra,2616 <getpid>
    117c:	8d2a                	mv	s10,a0
    117e:	8566                	mv	a0,s9
    1180:	36c010ef          	jal	ra,24ec <basename>
    1184:	872a                	mv	a4,a0
    1186:	02600793          	li	a5,38
    118a:	855e                	mv	a0,s7
    118c:	86ea                	mv	a3,s10
    118e:	8662                	mv	a2,s8
    1190:	45fd                	li	a1,31
    1192:	252000ef          	jal	ra,13e4 <printf>
    1196:	557d                	li	a0,-1
    1198:	4ae010ef          	jal	ra,2646 <exit>
	for (int i = 0; i < thread_count; i++) {
    119c:	0911                	addi	s2,s2,4
    119e:	fd3494e3          	bne	s1,s3,1166 <main+0x6a>
    11a2:	00002917          	auipc	s2,0x2
    11a6:	a0290913          	addi	s2,s2,-1534 # 2ba4 <threads+0x3c>
	}
	for (int i = 0; i < thread_count; i++) {
		int rc = waittid(threads[i]);
		printf("thread %d return with code %d\n", threads[i], rc);
    11aa:	00002497          	auipc	s1,0x2
    11ae:	85e48493          	addi	s1,s1,-1954 # 2a08 <enable_deadlock_detect+0x124>
		int rc = waittid(threads[i]);
    11b2:	4008                	lw	a0,0(s0)
	for (int i = 0; i < thread_count; i++) {
    11b4:	0411                	addi	s0,s0,4
		int rc = waittid(threads[i]);
    11b6:	686010ef          	jal	ra,283c <waittid>
		printf("thread %d return with code %d\n", threads[i], rc);
    11ba:	ffc42583          	lw	a1,-4(s0)
		int rc = waittid(threads[i]);
    11be:	862a                	mv	a2,a0
		printf("thread %d return with code %d\n", threads[i], rc);
    11c0:	8526                	mv	a0,s1
    11c2:	222000ef          	jal	ra,13e4 <printf>
	for (int i = 0; i < thread_count; i++) {
    11c6:	fe8916e3          	bne	s2,s0,11b2 <main+0xb6>
	}
	int64 stop = get_mtime();
    11ca:	4b6010ef          	jal	ra,2680 <get_mtime>
	printf("time cost is %d ms\n", (int)(stop - start));
    11ce:	415505bb          	subw	a1,a0,s5
    11d2:	00002517          	auipc	a0,0x2
    11d6:	85650513          	addi	a0,a0,-1962 # 2a28 <enable_deadlock_detect+0x144>
    11da:	20a000ef          	jal	ra,13e4 <printf>
	assert_eq(a, per_thread * thread_count);
    11de:	004b2703          	lw	a4,4(s6)
    11e2:	5dc00793          	li	a5,1500
    11e6:	04f70163          	beq	a4,a5,1228 <main+0x12c>
    11ea:	42c010ef          	jal	ra,2616 <getpid>
    11ee:	842a                	mv	s0,a0
    11f0:	00001517          	auipc	a0,0x1
    11f4:	70050513          	addi	a0,a0,1792 # 28f0 <enable_deadlock_detect+0xc>
    11f8:	2f4010ef          	jal	ra,24ec <basename>
    11fc:	004b2803          	lw	a6,4(s6)
    1200:	872a                	mv	a4,a0
    1202:	5dc00893          	li	a7,1500
    1206:	00001517          	auipc	a0,0x1
    120a:	73a50513          	addi	a0,a0,1850 # 2940 <enable_deadlock_detect+0x5c>
    120e:	02e00793          	li	a5,46
    1212:	86a2                	mv	a3,s0
    1214:	00001617          	auipc	a2,0x1
    1218:	72460613          	addi	a2,a2,1828 # 2938 <enable_deadlock_detect+0x54>
    121c:	45fd                	li	a1,31
    121e:	1c6000ef          	jal	ra,13e4 <printf>
    1222:	557d                	li	a0,-1
    1224:	422010ef          	jal	ra,2646 <exit>
	puts("race adder blocking mutex passed!");
    1228:	00002517          	auipc	a0,0x2
    122c:	81850513          	addi	a0,a0,-2024 # 2a40 <enable_deadlock_detect+0x15c>
    1230:	0cb000ef          	jal	ra,1afa <puts>
	return 0;
}
    1234:	60e6                	ld	ra,88(sp)
    1236:	6446                	ld	s0,80(sp)
    1238:	64a6                	ld	s1,72(sp)
    123a:	6906                	ld	s2,64(sp)
    123c:	79e2                	ld	s3,56(sp)
    123e:	7a42                	ld	s4,48(sp)
    1240:	7aa2                	ld	s5,40(sp)
    1242:	7b02                	ld	s6,32(sp)
    1244:	6be2                	ld	s7,24(sp)
    1246:	6c42                	ld	s8,16(sp)
    1248:	6ca2                	ld	s9,8(sp)
    124a:	6d02                	ld	s10,0(sp)
    124c:	4501                	li	a0,0
    124e:	6125                	addi	sp,sp,96
    1250:	8082                	ret
	assert((mutex_id = mutex_blocking_create()) >= 0);
    1252:	3c4010ef          	jal	ra,2616 <getpid>
    1256:	842a                	mv	s0,a0
    1258:	00001517          	auipc	a0,0x1
    125c:	69850513          	addi	a0,a0,1688 # 28f0 <enable_deadlock_detect+0xc>
    1260:	28c010ef          	jal	ra,24ec <basename>
    1264:	872a                	mv	a4,a0
    1266:	02300793          	li	a5,35
    126a:	00001517          	auipc	a0,0x1
    126e:	70e50513          	addi	a0,a0,1806 # 2978 <enable_deadlock_detect+0x94>
    1272:	86a2                	mv	a3,s0
    1274:	00001617          	auipc	a2,0x1
    1278:	6c460613          	addi	a2,a2,1732 # 2938 <enable_deadlock_detect+0x54>
    127c:	45fd                	li	a1,31
    127e:	166000ef          	jal	ra,13e4 <printf>
    1282:	557d                	li	a0,-1
    1284:	3c2010ef          	jal	ra,2646 <exit>
    1288:	b565                	j	1130 <main+0x34>

000000000000128a <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    128a:	1141                	addi	sp,sp,-16
    128c:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    128e:	e6fff0ef          	jal	ra,10fc <main>
    1292:	3b4010ef          	jal	ra,2646 <exit>
	return 0;
    1296:	60a2                	ld	ra,8(sp)
    1298:	4501                	li	a0,0
    129a:	0141                	addi	sp,sp,16
    129c:	8082                	ret

000000000000129e <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    129e:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    12a0:	4605                	li	a2,1
    12a2:	00f10593          	addi	a1,sp,15
    12a6:	4501                	li	a0,0
{
    12a8:	ec06                	sd	ra,24(sp)
	char byte = 0;
    12aa:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    12ae:	354010ef          	jal	ra,2602 <read>
    12b2:	4785                	li	a5,1
    12b4:	00f51763          	bne	a0,a5,12c2 <getchar+0x24>
		return byte;
    12b8:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    12bc:	60e2                	ld	ra,24(sp)
    12be:	6105                	addi	sp,sp,32
    12c0:	8082                	ret
		return EOF;
    12c2:	557d                	li	a0,-1
    12c4:	bfe5                	j	12bc <getchar+0x1e>

00000000000012c6 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    12c6:	00002517          	auipc	a0,0x2
    12ca:	8e252503          	lw	a0,-1822(a0) # 2ba8 <buffer_len>
    12ce:	e111                	bnez	a0,12d2 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    12d0:	8082                	ret
{
    12d2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12d4:	862a                	mv	a2,a0
    12d6:	00002597          	auipc	a1,0x2
    12da:	8da58593          	addi	a1,a1,-1830 # 2bb0 <buffer>
    12de:	4505                	li	a0,1
{
    12e0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12e2:	32a010ef          	jal	ra,260c <write>
}
    12e6:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12e8:	2501                	sext.w	a0,a0
}
    12ea:	0141                	addi	sp,sp,16
    12ec:	8082                	ret

00000000000012ee <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    12ee:	00002797          	auipc	a5,0x2
    12f2:	8a07ad23          	sw	zero,-1862(a5) # 2ba8 <buffer_len>
}
    12f6:	8082                	ret

00000000000012f8 <__fflush>:
	if (buffer_len == 0)
    12f8:	00002517          	auipc	a0,0x2
    12fc:	8b052503          	lw	a0,-1872(a0) # 2ba8 <buffer_len>
    1300:	e511                	bnez	a0,130c <__fflush+0x14>
	buffer_len = 0;
    1302:	00002797          	auipc	a5,0x2
    1306:	8a07a323          	sw	zero,-1882(a5) # 2ba8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    130a:	8082                	ret
{
    130c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    130e:	862a                	mv	a2,a0
    1310:	00002597          	auipc	a1,0x2
    1314:	8a058593          	addi	a1,a1,-1888 # 2bb0 <buffer>
    1318:	4505                	li	a0,1
{
    131a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    131c:	2f0010ef          	jal	ra,260c <write>
	return r >= 0 ? 0 : r;
    1320:	0005079b          	sext.w	a5,a0
}
    1324:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1326:	0017a793          	slti	a5,a5,1
    132a:	40f007bb          	negw	a5,a5
    132e:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1330:	00002797          	auipc	a5,0x2
    1334:	8607ac23          	sw	zero,-1928(a5) # 2ba8 <buffer_len>
	return r >= 0 ? 0 : r;
    1338:	2501                	sext.w	a0,a0
}
    133a:	0141                	addi	sp,sp,16
    133c:	8082                	ret

000000000000133e <fflush>:

int fflush(int fd)
{
    133e:	1101                	addi	sp,sp,-32
    1340:	e822                	sd	s0,16(sp)
    1342:	ec06                	sd	ra,24(sp)
    1344:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1346:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1348:	4401                	li	s0,0
	if (fd == 1) {
    134a:	00e50863          	beq	a0,a4,135a <fflush+0x1c>
}
    134e:	60e2                	ld	ra,24(sp)
    1350:	8522                	mv	a0,s0
    1352:	6442                	ld	s0,16(sp)
    1354:	64a2                	ld	s1,8(sp)
    1356:	6105                	addi	sp,sp,32
    1358:	8082                	ret
		if (buffer_lock_enabled == 1) {
    135a:	00002497          	auipc	s1,0x2
    135e:	84e48493          	addi	s1,s1,-1970 # 2ba8 <buffer_len>
    1362:	1084a703          	lw	a4,264(s1)
    1366:	02a70e63          	beq	a4,a0,13a2 <fflush+0x64>
	if (buffer_len == 0)
    136a:	4080                	lw	s0,0(s1)
    136c:	c00d                	beqz	s0,138e <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    136e:	8622                	mv	a2,s0
    1370:	00002597          	auipc	a1,0x2
    1374:	84058593          	addi	a1,a1,-1984 # 2bb0 <buffer>
    1378:	294010ef          	jal	ra,260c <write>
	return r >= 0 ? 0 : r;
    137c:	0005079b          	sext.w	a5,a0
    1380:	0017a793          	slti	a5,a5,1
    1384:	40f007bb          	negw	a5,a5
    1388:	8d7d                	and	a0,a0,a5
    138a:	0005041b          	sext.w	s0,a0
}
    138e:	60e2                	ld	ra,24(sp)
    1390:	8522                	mv	a0,s0
    1392:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1394:	00002797          	auipc	a5,0x2
    1398:	8007aa23          	sw	zero,-2028(a5) # 2ba8 <buffer_len>
}
    139c:	64a2                	ld	s1,8(sp)
    139e:	6105                	addi	sp,sp,32
    13a0:	8082                	ret
			mutex_lock(buffer_lock);
    13a2:	10c4a503          	lw	a0,268(s1)
    13a6:	4de010ef          	jal	ra,2884 <mutex_lock>
	if (buffer_len == 0)
    13aa:	4080                	lw	s0,0(s1)
    13ac:	e811                	bnez	s0,13c0 <fflush+0x82>
			mutex_unlock(buffer_lock);
    13ae:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    13b2:	00001797          	auipc	a5,0x1
    13b6:	7e07ab23          	sw	zero,2038(a5) # 2ba8 <buffer_len>
			mutex_unlock(buffer_lock);
    13ba:	4d6010ef          	jal	ra,2890 <mutex_unlock>
    13be:	bf41                	j	134e <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    13c0:	8622                	mv	a2,s0
    13c2:	00001597          	auipc	a1,0x1
    13c6:	7ee58593          	addi	a1,a1,2030 # 2bb0 <buffer>
    13ca:	4505                	li	a0,1
    13cc:	240010ef          	jal	ra,260c <write>
	return r >= 0 ? 0 : r;
    13d0:	0005079b          	sext.w	a5,a0
    13d4:	0017a793          	slti	a5,a5,1
    13d8:	40f007bb          	negw	a5,a5
    13dc:	8d7d                	and	a0,a0,a5
    13de:	0005041b          	sext.w	s0,a0
	return r;
    13e2:	b7f1                	j	13ae <fflush+0x70>

00000000000013e4 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    13e4:	7131                	addi	sp,sp,-192
    13e6:	e0da                	sd	s6,64(sp)
    13e8:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    13ea:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    13ec:	013c                	addi	a5,sp,136
{
    13ee:	f0ca                	sd	s2,96(sp)
    13f0:	ecce                	sd	s3,88(sp)
    13f2:	e8d2                	sd	s4,80(sp)
    13f4:	e4d6                	sd	s5,72(sp)
    13f6:	fc86                	sd	ra,120(sp)
    13f8:	f8a2                	sd	s0,112(sp)
    13fa:	f4a6                	sd	s1,104(sp)
    13fc:	89aa                	mv	s3,a0
    13fe:	e52e                	sd	a1,136(sp)
    1400:	e932                	sd	a2,144(sp)
    1402:	ed36                	sd	a3,152(sp)
    1404:	f13a                	sd	a4,160(sp)
    1406:	f942                	sd	a6,176(sp)
    1408:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    140a:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    140c:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1410:	00001a17          	auipc	s4,0x1
    1414:	798a0a13          	addi	s4,s4,1944 # 2ba8 <buffer_len>
    1418:	4a85                	li	s5,1
	buf[i++] = '0';
    141a:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    141e:	0009c783          	lbu	a5,0(s3)
    1422:	18078663          	beqz	a5,15ae <printf+0x1ca>
    1426:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1428:	19278d63          	beq	a5,s2,15c2 <printf+0x1de>
    142c:	0015c783          	lbu	a5,1(a1)
    1430:	0585                	addi	a1,a1,1
    1432:	fbfd                	bnez	a5,1428 <printf+0x44>
    1434:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1436:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    143a:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    143e:	1b578863          	beq	a5,s5,15ee <printf+0x20a>
		len = out_unlocked(s, l);
    1442:	85a2                	mv	a1,s0
    1444:	854e                	mv	a0,s3
    1446:	42a000ef          	jal	ra,1870 <out_unlocked>
		out(f, a, l);
		if (l)
    144a:	1c041063          	bnez	s0,160a <printf+0x226>
			continue;
		if (s[1] == 0)
    144e:	0014c783          	lbu	a5,1(s1)
    1452:	14078e63          	beqz	a5,15ae <printf+0x1ca>
			break;
		switch (s[1]) {
    1456:	07300713          	li	a4,115
    145a:	1ce78863          	beq	a5,a4,162a <printf+0x246>
    145e:	1af76863          	bltu	a4,a5,160e <printf+0x22a>
    1462:	06400713          	li	a4,100
    1466:	22e78063          	beq	a5,a4,1686 <printf+0x2a2>
    146a:	07000713          	li	a4,112
    146e:	1ee79563          	bne	a5,a4,1658 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1472:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1474:	00002797          	auipc	a5,0x2
    1478:	84478793          	addi	a5,a5,-1980 # 2cb8 <digits>
	buf[i++] = '0';
    147c:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1480:	6298                	ld	a4,0(a3)
    1482:	06a1                	addi	a3,a3,8
    1484:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1486:	00471393          	slli	t2,a4,0x4
    148a:	00871293          	slli	t0,a4,0x8
    148e:	00c71f93          	slli	t6,a4,0xc
    1492:	01071f13          	slli	t5,a4,0x10
    1496:	01471e93          	slli	t4,a4,0x14
    149a:	01871e13          	slli	t3,a4,0x18
    149e:	01c71893          	slli	a7,a4,0x1c
    14a2:	02471813          	slli	a6,a4,0x24
    14a6:	02871513          	slli	a0,a4,0x28
    14aa:	02c71593          	slli	a1,a4,0x2c
    14ae:	03071613          	slli	a2,a4,0x30
    14b2:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14b6:	03c75413          	srli	s0,a4,0x3c
    14ba:	01c7531b          	srliw	t1,a4,0x1c
    14be:	03c3d393          	srli	t2,t2,0x3c
    14c2:	03c2d293          	srli	t0,t0,0x3c
    14c6:	03cfdf93          	srli	t6,t6,0x3c
    14ca:	03cf5f13          	srli	t5,t5,0x3c
    14ce:	03cede93          	srli	t4,t4,0x3c
    14d2:	03ce5e13          	srli	t3,t3,0x3c
    14d6:	03c8d893          	srli	a7,a7,0x3c
    14da:	03c85813          	srli	a6,a6,0x3c
    14de:	9171                	srli	a0,a0,0x3c
    14e0:	91f1                	srli	a1,a1,0x3c
    14e2:	9271                	srli	a2,a2,0x3c
    14e4:	92f1                	srli	a3,a3,0x3c
    14e6:	95be                	add	a1,a1,a5
    14e8:	963e                	add	a2,a2,a5
    14ea:	96be                	add	a3,a3,a5
    14ec:	943e                	add	s0,s0,a5
    14ee:	93be                	add	t2,t2,a5
    14f0:	92be                	add	t0,t0,a5
    14f2:	9fbe                	add	t6,t6,a5
    14f4:	9f3e                	add	t5,t5,a5
    14f6:	9ebe                	add	t4,t4,a5
    14f8:	9e3e                	add	t3,t3,a5
    14fa:	98be                	add	a7,a7,a5
    14fc:	933e                	add	t1,t1,a5
    14fe:	983e                	add	a6,a6,a5
    1500:	953e                	add	a0,a0,a5
    1502:	0005c983          	lbu	s3,0(a1)
    1506:	00044403          	lbu	s0,0(s0)
    150a:	00064583          	lbu	a1,0(a2)
    150e:	0003c383          	lbu	t2,0(t2)
    1512:	0006c603          	lbu	a2,0(a3)
    1516:	0002c283          	lbu	t0,0(t0)
    151a:	000fcf83          	lbu	t6,0(t6)
    151e:	000f4f03          	lbu	t5,0(t5)
    1522:	000ece83          	lbu	t4,0(t4)
    1526:	000e4e03          	lbu	t3,0(t3)
    152a:	0008c883          	lbu	a7,0(a7)
    152e:	00034303          	lbu	t1,0(t1)
    1532:	00084803          	lbu	a6,0(a6)
    1536:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    153a:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    153e:	92f1                	srli	a3,a3,0x3c
    1540:	8b3d                	andi	a4,a4,15
    1542:	96be                	add	a3,a3,a5
    1544:	97ba                	add	a5,a5,a4
    1546:	00810d23          	sb	s0,26(sp)
    154a:	00710da3          	sb	t2,27(sp)
    154e:	00510e23          	sb	t0,28(sp)
    1552:	01f10ea3          	sb	t6,29(sp)
    1556:	01e10f23          	sb	t5,30(sp)
    155a:	01d10fa3          	sb	t4,31(sp)
    155e:	03c10023          	sb	t3,32(sp)
    1562:	031100a3          	sb	a7,33(sp)
    1566:	02610123          	sb	t1,34(sp)
    156a:	030101a3          	sb	a6,35(sp)
    156e:	02a10223          	sb	a0,36(sp)
    1572:	033102a3          	sb	s3,37(sp)
    1576:	02b10323          	sb	a1,38(sp)
    157a:	02c103a3          	sb	a2,39(sp)
    157e:	0006c683          	lbu	a3,0(a3)
    1582:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1586:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    158a:	02d10423          	sb	a3,40(sp)
    158e:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1592:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1596:	11578263          	beq	a5,s5,169a <printf+0x2b6>
		len = out_unlocked(s, l);
    159a:	45c9                	li	a1,18
    159c:	0828                	addi	a0,sp,24
    159e:	2d2000ef          	jal	ra,1870 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    15a2:	00248993          	addi	s3,s1,2
		if (!*s)
    15a6:	0009c783          	lbu	a5,0(s3)
    15aa:	e6079ee3          	bnez	a5,1426 <printf+0x42>
	}
	va_end(ap);
    15ae:	70e6                	ld	ra,120(sp)
    15b0:	7446                	ld	s0,112(sp)
    15b2:	74a6                	ld	s1,104(sp)
    15b4:	7906                	ld	s2,96(sp)
    15b6:	69e6                	ld	s3,88(sp)
    15b8:	6a46                	ld	s4,80(sp)
    15ba:	6aa6                	ld	s5,72(sp)
    15bc:	6b06                	ld	s6,64(sp)
    15be:	6129                	addi	sp,sp,192
    15c0:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    15c2:	0005c783          	lbu	a5,0(a1)
    15c6:	84ae                	mv	s1,a1
    15c8:	01278963          	beq	a5,s2,15da <printf+0x1f6>
    15cc:	b5ad                	j	1436 <printf+0x52>
    15ce:	0024c783          	lbu	a5,2(s1)
    15d2:	0585                	addi	a1,a1,1
    15d4:	0489                	addi	s1,s1,2
    15d6:	e72790e3          	bne	a5,s2,1436 <printf+0x52>
    15da:	0014c783          	lbu	a5,1(s1)
    15de:	ff2788e3          	beq	a5,s2,15ce <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    15e2:	108a2783          	lw	a5,264(s4)
		l = z - a;
    15e6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    15ea:	e5579ce3          	bne	a5,s5,1442 <printf+0x5e>
		mutex_lock(buffer_lock);
    15ee:	10ca2503          	lw	a0,268(s4)
    15f2:	292010ef          	jal	ra,2884 <mutex_lock>
		len = out_unlocked(s, l);
    15f6:	85a2                	mv	a1,s0
    15f8:	854e                	mv	a0,s3
    15fa:	276000ef          	jal	ra,1870 <out_unlocked>
		mutex_unlock(buffer_lock);
    15fe:	10ca2503          	lw	a0,268(s4)
    1602:	28e010ef          	jal	ra,2890 <mutex_unlock>
		if (l)
    1606:	e40404e3          	beqz	s0,144e <printf+0x6a>
    160a:	89a6                	mv	s3,s1
    160c:	bd09                	j	141e <printf+0x3a>
		switch (s[1]) {
    160e:	07800713          	li	a4,120
    1612:	04e79363          	bne	a5,a4,1658 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1616:	67c2                	ld	a5,16(sp)
    1618:	45c1                	li	a1,16
		s += 2;
    161a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    161e:	4388                	lw	a0,0(a5)
    1620:	07a1                	addi	a5,a5,8
    1622:	e83e                	sd	a5,16(sp)
    1624:	5f8000ef          	jal	ra,1c1c <printint.constprop.0>
		s += 2;
    1628:	bfbd                	j	15a6 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    162a:	67c2                	ld	a5,16(sp)
    162c:	6380                	ld	s0,0(a5)
    162e:	07a1                	addi	a5,a5,8
    1630:	e83e                	sd	a5,16(sp)
    1632:	1c040163          	beqz	s0,17f4 <printf+0x410>
			l = strnlen(a, 200);
    1636:	0c800593          	li	a1,200
    163a:	8522                	mv	a0,s0
    163c:	3f7000ef          	jal	ra,2232 <strnlen>
	if (buffer_lock_enabled == 1) {
    1640:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1644:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1648:	19578663          	beq	a5,s5,17d4 <printf+0x3f0>
		len = out_unlocked(s, l);
    164c:	8522                	mv	a0,s0
    164e:	222000ef          	jal	ra,1870 <out_unlocked>
		s += 2;
    1652:	00248993          	addi	s3,s1,2
    1656:	bf81                	j	15a6 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1658:	108a2783          	lw	a5,264(s4)
	char byte = c;
    165c:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1660:	0f578663          	beq	a5,s5,174c <printf+0x368>
		len = out_unlocked(s, l);
    1664:	0828                	addi	a0,sp,24
    1666:	316000ef          	jal	ra,197c <out_unlocked.constprop.0>
			putchar(s[1]);
    166a:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    166e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1672:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1676:	05578163          	beq	a5,s5,16b8 <printf+0x2d4>
		len = out_unlocked(s, l);
    167a:	0828                	addi	a0,sp,24
    167c:	300000ef          	jal	ra,197c <out_unlocked.constprop.0>
		s += 2;
    1680:	00248993          	addi	s3,s1,2
    1684:	b70d                	j	15a6 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1686:	67c2                	ld	a5,16(sp)
    1688:	45a9                	li	a1,10
		s += 2;
    168a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    168e:	4388                	lw	a0,0(a5)
    1690:	07a1                	addi	a5,a5,8
    1692:	e83e                	sd	a5,16(sp)
    1694:	588000ef          	jal	ra,1c1c <printint.constprop.0>
		s += 2;
    1698:	b739                	j	15a6 <printf+0x1c2>
		mutex_lock(buffer_lock);
    169a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    169e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16a2:	1e2010ef          	jal	ra,2884 <mutex_lock>
		len = out_unlocked(s, l);
    16a6:	45c9                	li	a1,18
    16a8:	0828                	addi	a0,sp,24
    16aa:	1c6000ef          	jal	ra,1870 <out_unlocked>
		mutex_unlock(buffer_lock);
    16ae:	10ca2503          	lw	a0,268(s4)
    16b2:	1de010ef          	jal	ra,2890 <mutex_unlock>
		s += 2;
    16b6:	bdc5                	j	15a6 <printf+0x1c2>
		mutex_lock(buffer_lock);
    16b8:	10ca2503          	lw	a0,268(s4)
    16bc:	1c8010ef          	jal	ra,2884 <mutex_lock>
		buffer[buffer_len++] = c;
    16c0:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16c4:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16c8:	0017861b          	addiw	a2,a5,1
    16cc:	97d2                	add	a5,a5,s4
    16ce:	00ca2023          	sw	a2,0(s4)
    16d2:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16d6:	00c6cc63          	blt	a3,a2,16ee <printf+0x30a>
    16da:	47a9                	li	a5,10
    16dc:	06f40663          	beq	s0,a5,1748 <printf+0x364>
		mutex_unlock(buffer_lock);
    16e0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    16e4:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    16e8:	1a8010ef          	jal	ra,2890 <mutex_unlock>
		s += 2;
    16ec:	bd6d                	j	15a6 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    16ee:	10000793          	li	a5,256
    16f2:	00f61e63          	bne	a2,a5,170e <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    16f6:	00001597          	auipc	a1,0x1
    16fa:	4ba58593          	addi	a1,a1,1210 # 2bb0 <buffer>
    16fe:	4505                	li	a0,1
    1700:	70d000ef          	jal	ra,260c <write>
	buffer_len = 0;
    1704:	00001797          	auipc	a5,0x1
    1708:	4a07a223          	sw	zero,1188(a5) # 2ba8 <buffer_len>
			if (r < 0) {
    170c:	bfd1                	j	16e0 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    170e:	709000ef          	jal	ra,2616 <getpid>
    1712:	842a                	mv	s0,a0
    1714:	00001517          	auipc	a0,0x1
    1718:	35c50513          	addi	a0,a0,860 # 2a70 <enable_deadlock_detect+0x18c>
    171c:	5d1000ef          	jal	ra,24ec <basename>
    1720:	872a                	mv	a4,a0
    1722:	00001617          	auipc	a2,0x1
    1726:	21660613          	addi	a2,a2,534 # 2938 <enable_deadlock_detect+0x54>
    172a:	05400793          	li	a5,84
    172e:	86a2                	mv	a3,s0
    1730:	45fd                	li	a1,31
    1732:	00001517          	auipc	a0,0x1
    1736:	37e50513          	addi	a0,a0,894 # 2ab0 <enable_deadlock_detect+0x1cc>
    173a:	cabff0ef          	jal	ra,13e4 <printf>
    173e:	557d                	li	a0,-1
    1740:	707000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    1744:	000a2603          	lw	a2,0(s4)
    1748:	de41                	beqz	a2,16e0 <printf+0x2fc>
    174a:	b775                	j	16f6 <printf+0x312>
		mutex_lock(buffer_lock);
    174c:	10ca2503          	lw	a0,268(s4)
    1750:	134010ef          	jal	ra,2884 <mutex_lock>
		buffer[buffer_len++] = c;
    1754:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1758:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    175c:	0017861b          	addiw	a2,a5,1
    1760:	97d2                	add	a5,a5,s4
    1762:	00ca2023          	sw	a2,0(s4)
    1766:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    176a:	02c6d163          	bge	a3,a2,178c <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    176e:	10000793          	li	a5,256
    1772:	02f61263          	bne	a2,a5,1796 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1776:	00001597          	auipc	a1,0x1
    177a:	43a58593          	addi	a1,a1,1082 # 2bb0 <buffer>
    177e:	4505                	li	a0,1
    1780:	68d000ef          	jal	ra,260c <write>
	buffer_len = 0;
    1784:	00001797          	auipc	a5,0x1
    1788:	4207a223          	sw	zero,1060(a5) # 2ba8 <buffer_len>
		mutex_unlock(buffer_lock);
    178c:	10ca2503          	lw	a0,268(s4)
    1790:	100010ef          	jal	ra,2890 <mutex_unlock>
    1794:	bdd9                	j	166a <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1796:	681000ef          	jal	ra,2616 <getpid>
    179a:	842a                	mv	s0,a0
    179c:	00001517          	auipc	a0,0x1
    17a0:	2d450513          	addi	a0,a0,724 # 2a70 <enable_deadlock_detect+0x18c>
    17a4:	549000ef          	jal	ra,24ec <basename>
    17a8:	872a                	mv	a4,a0
    17aa:	00001617          	auipc	a2,0x1
    17ae:	18e60613          	addi	a2,a2,398 # 2938 <enable_deadlock_detect+0x54>
    17b2:	05400793          	li	a5,84
    17b6:	86a2                	mv	a3,s0
    17b8:	45fd                	li	a1,31
    17ba:	00001517          	auipc	a0,0x1
    17be:	2f650513          	addi	a0,a0,758 # 2ab0 <enable_deadlock_detect+0x1cc>
    17c2:	c23ff0ef          	jal	ra,13e4 <printf>
    17c6:	557d                	li	a0,-1
    17c8:	67f000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    17cc:	000a2603          	lw	a2,0(s4)
    17d0:	de55                	beqz	a2,178c <printf+0x3a8>
    17d2:	b755                	j	1776 <printf+0x392>
		mutex_lock(buffer_lock);
    17d4:	10ca2503          	lw	a0,268(s4)
    17d8:	e42e                	sd	a1,8(sp)
		s += 2;
    17da:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    17de:	0a6010ef          	jal	ra,2884 <mutex_lock>
		len = out_unlocked(s, l);
    17e2:	65a2                	ld	a1,8(sp)
    17e4:	8522                	mv	a0,s0
    17e6:	08a000ef          	jal	ra,1870 <out_unlocked>
		mutex_unlock(buffer_lock);
    17ea:	10ca2503          	lw	a0,268(s4)
    17ee:	0a2010ef          	jal	ra,2890 <mutex_unlock>
		s += 2;
    17f2:	bb55                	j	15a6 <printf+0x1c2>
				a = "(null)";
    17f4:	00001417          	auipc	s0,0x1
    17f8:	27440413          	addi	s0,s0,628 # 2a68 <enable_deadlock_detect+0x184>
    17fc:	bd2d                	j	1636 <printf+0x252>

00000000000017fe <enable_thread_io_buffer>:
{
    17fe:	1101                	addi	sp,sp,-32
    1800:	e822                	sd	s0,16(sp)
    1802:	ec06                	sd	ra,24(sp)
    1804:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1806:	00001417          	auipc	s0,0x1
    180a:	3a240413          	addi	s0,s0,930 # 2ba8 <buffer_len>
    180e:	05a010ef          	jal	ra,2868 <mutex_create>
    1812:	10a42623          	sw	a0,268(s0)
    1816:	00054a63          	bltz	a0,182a <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    181a:	4785                	li	a5,1
}
    181c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    181e:	10f42423          	sw	a5,264(s0)
}
    1822:	6442                	ld	s0,16(sp)
    1824:	64a2                	ld	s1,8(sp)
    1826:	6105                	addi	sp,sp,32
    1828:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    182a:	5ed000ef          	jal	ra,2616 <getpid>
    182e:	84aa                	mv	s1,a0
    1830:	00001517          	auipc	a0,0x1
    1834:	24050513          	addi	a0,a0,576 # 2a70 <enable_deadlock_detect+0x18c>
    1838:	4b5000ef          	jal	ra,24ec <basename>
    183c:	872a                	mv	a4,a0
    183e:	04800793          	li	a5,72
    1842:	86a6                	mv	a3,s1
    1844:	00001517          	auipc	a0,0x1
    1848:	2ac50513          	addi	a0,a0,684 # 2af0 <enable_deadlock_detect+0x20c>
    184c:	00001617          	auipc	a2,0x1
    1850:	0ec60613          	addi	a2,a2,236 # 2938 <enable_deadlock_detect+0x54>
    1854:	45fd                	li	a1,31
    1856:	b8fff0ef          	jal	ra,13e4 <printf>
    185a:	557d                	li	a0,-1
    185c:	5eb000ef          	jal	ra,2646 <exit>
	buffer_lock_enabled = 1;
    1860:	4785                	li	a5,1
}
    1862:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1864:	10f42423          	sw	a5,264(s0)
}
    1868:	6442                	ld	s0,16(sp)
    186a:	64a2                	ld	s1,8(sp)
    186c:	6105                	addi	sp,sp,32
    186e:	8082                	ret

0000000000001870 <out_unlocked>:
{
    1870:	7159                	addi	sp,sp,-112
    1872:	f486                	sd	ra,104(sp)
    1874:	f0a2                	sd	s0,96(sp)
    1876:	eca6                	sd	s1,88(sp)
    1878:	e8ca                	sd	s2,80(sp)
    187a:	e4ce                	sd	s3,72(sp)
    187c:	e0d2                	sd	s4,64(sp)
    187e:	fc56                	sd	s5,56(sp)
    1880:	f85a                	sd	s6,48(sp)
    1882:	f45e                	sd	s7,40(sp)
    1884:	f062                	sd	s8,32(sp)
    1886:	ec66                	sd	s9,24(sp)
    1888:	e86a                	sd	s10,16(sp)
    188a:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    188c:	0e058663          	beqz	a1,1978 <out_unlocked+0x108>
    1890:	842a                	mv	s0,a0
    1892:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1896:	4981                	li	s3,0
    1898:	00001d17          	auipc	s10,0x1
    189c:	310d0d13          	addi	s10,s10,784 # 2ba8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18a0:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    18a4:	00001b17          	auipc	s6,0x1
    18a8:	30cb0b13          	addi	s6,s6,780 # 2bb0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    18ac:	10000a93          	li	s5,256
    18b0:	00001c97          	auipc	s9,0x1
    18b4:	1c0c8c93          	addi	s9,s9,448 # 2a70 <enable_deadlock_detect+0x18c>
    18b8:	00001c17          	auipc	s8,0x1
    18bc:	080c0c13          	addi	s8,s8,128 # 2938 <enable_deadlock_detect+0x54>
    18c0:	00001b97          	auipc	s7,0x1
    18c4:	1f0b8b93          	addi	s7,s7,496 # 2ab0 <enable_deadlock_detect+0x1cc>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18c8:	4a29                	li	s4,10
    18ca:	a031                	j	18d6 <out_unlocked+0x66>
    18cc:	09468863          	beq	a3,s4,195c <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    18d0:	0405                	addi	s0,s0,1
    18d2:	04848163          	beq	s1,s0,1914 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    18d6:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    18da:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    18de:	0017861b          	addiw	a2,a5,1
    18e2:	97ea                	add	a5,a5,s10
    18e4:	00cd2023          	sw	a2,0(s10)
    18e8:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ec:	fec950e3          	bge	s2,a2,18cc <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    18f0:	05561263          	bne	a2,s5,1934 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    18f4:	85da                	mv	a1,s6
    18f6:	4505                	li	a0,1
    18f8:	515000ef          	jal	ra,260c <write>
    18fc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18fe:	00001797          	auipc	a5,0x1
    1902:	2a07a523          	sw	zero,682(a5) # 2ba8 <buffer_len>
			if (r < 0) {
    1906:	06054763          	bltz	a0,1974 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    190a:	0405                	addi	s0,s0,1
			ret += r;
    190c:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1910:	fc8493e3          	bne	s1,s0,18d6 <out_unlocked+0x66>
}
    1914:	70a6                	ld	ra,104(sp)
    1916:	7406                	ld	s0,96(sp)
    1918:	64e6                	ld	s1,88(sp)
    191a:	6946                	ld	s2,80(sp)
    191c:	6a06                	ld	s4,64(sp)
    191e:	7ae2                	ld	s5,56(sp)
    1920:	7b42                	ld	s6,48(sp)
    1922:	7ba2                	ld	s7,40(sp)
    1924:	7c02                	ld	s8,32(sp)
    1926:	6ce2                	ld	s9,24(sp)
    1928:	6d42                	ld	s10,16(sp)
    192a:	6da2                	ld	s11,8(sp)
    192c:	854e                	mv	a0,s3
    192e:	69a6                	ld	s3,72(sp)
    1930:	6165                	addi	sp,sp,112
    1932:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1934:	4e3000ef          	jal	ra,2616 <getpid>
    1938:	8daa                	mv	s11,a0
    193a:	8566                	mv	a0,s9
    193c:	3b1000ef          	jal	ra,24ec <basename>
    1940:	872a                	mv	a4,a0
    1942:	8662                	mv	a2,s8
    1944:	05400793          	li	a5,84
    1948:	86ee                	mv	a3,s11
    194a:	45fd                	li	a1,31
    194c:	855e                	mv	a0,s7
    194e:	a97ff0ef          	jal	ra,13e4 <printf>
    1952:	557d                	li	a0,-1
    1954:	4f3000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    1958:	000d2603          	lw	a2,0(s10)
    195c:	da35                	beqz	a2,18d0 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    195e:	85da                	mv	a1,s6
    1960:	4505                	li	a0,1
    1962:	4ab000ef          	jal	ra,260c <write>
    1966:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1968:	00001797          	auipc	a5,0x1
    196c:	2407a023          	sw	zero,576(a5) # 2ba8 <buffer_len>
			if (r < 0) {
    1970:	f8055de3          	bgez	a0,190a <out_unlocked+0x9a>
    1974:	89aa                	mv	s3,a0
    1976:	bf79                	j	1914 <out_unlocked+0xa4>
	int ret = 0;
    1978:	4981                	li	s3,0
    197a:	bf69                	j	1914 <out_unlocked+0xa4>

000000000000197c <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    197c:	1101                	addi	sp,sp,-32
    197e:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1980:	00001497          	auipc	s1,0x1
    1984:	22848493          	addi	s1,s1,552 # 2ba8 <buffer_len>
    1988:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    198a:	ec06                	sd	ra,24(sp)
    198c:	e822                	sd	s0,16(sp)
		char c = s[i];
    198e:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1992:	0017861b          	addiw	a2,a5,1
    1996:	97a6                	add	a5,a5,s1
    1998:	00e78423          	sb	a4,8(a5)
    199c:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    199e:	0ff00793          	li	a5,255
    19a2:	00c7cc63          	blt	a5,a2,19ba <out_unlocked.constprop.0+0x3e>
    19a6:	47a9                	li	a5,10
    19a8:	06f70c63          	beq	a4,a5,1a20 <out_unlocked.constprop.0+0xa4>
    19ac:	4601                	li	a2,0
}
    19ae:	60e2                	ld	ra,24(sp)
    19b0:	6442                	ld	s0,16(sp)
    19b2:	64a2                	ld	s1,8(sp)
    19b4:	8532                	mv	a0,a2
    19b6:	6105                	addi	sp,sp,32
    19b8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19ba:	10000793          	li	a5,256
    19be:	02f61563          	bne	a2,a5,19e8 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    19c2:	00001597          	auipc	a1,0x1
    19c6:	1ee58593          	addi	a1,a1,494 # 2bb0 <buffer>
    19ca:	4505                	li	a0,1
    19cc:	441000ef          	jal	ra,260c <write>
}
    19d0:	60e2                	ld	ra,24(sp)
    19d2:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    19d4:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19d8:	00001797          	auipc	a5,0x1
    19dc:	1c07a823          	sw	zero,464(a5) # 2ba8 <buffer_len>
}
    19e0:	64a2                	ld	s1,8(sp)
    19e2:	8532                	mv	a0,a2
    19e4:	6105                	addi	sp,sp,32
    19e6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19e8:	42f000ef          	jal	ra,2616 <getpid>
    19ec:	842a                	mv	s0,a0
    19ee:	00001517          	auipc	a0,0x1
    19f2:	08250513          	addi	a0,a0,130 # 2a70 <enable_deadlock_detect+0x18c>
    19f6:	2f7000ef          	jal	ra,24ec <basename>
    19fa:	872a                	mv	a4,a0
    19fc:	00001617          	auipc	a2,0x1
    1a00:	f3c60613          	addi	a2,a2,-196 # 2938 <enable_deadlock_detect+0x54>
    1a04:	05400793          	li	a5,84
    1a08:	86a2                	mv	a3,s0
    1a0a:	45fd                	li	a1,31
    1a0c:	00001517          	auipc	a0,0x1
    1a10:	0a450513          	addi	a0,a0,164 # 2ab0 <enable_deadlock_detect+0x1cc>
    1a14:	9d1ff0ef          	jal	ra,13e4 <printf>
    1a18:	557d                	li	a0,-1
    1a1a:	42d000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    1a1e:	4090                	lw	a2,0(s1)
    1a20:	d659                	beqz	a2,19ae <out_unlocked.constprop.0+0x32>
    1a22:	b745                	j	19c2 <out_unlocked.constprop.0+0x46>

0000000000001a24 <putchar>:
{
    1a24:	7139                	addi	sp,sp,-64
    1a26:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1a28:	00001497          	auipc	s1,0x1
    1a2c:	18048493          	addi	s1,s1,384 # 2ba8 <buffer_len>
    1a30:	1084a703          	lw	a4,264(s1)
{
    1a34:	f822                	sd	s0,48(sp)
	char byte = c;
    1a36:	0ff57413          	zext.b	s0,a0
{
    1a3a:	fc06                	sd	ra,56(sp)
	char byte = c;
    1a3c:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1a40:	4785                	li	a5,1
    1a42:	00f70d63          	beq	a4,a5,1a5c <putchar+0x38>
		len = out_unlocked(s, l);
    1a46:	01f10513          	addi	a0,sp,31
    1a4a:	f33ff0ef          	jal	ra,197c <out_unlocked.constprop.0>
}
    1a4e:	70e2                	ld	ra,56(sp)
    1a50:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1a52:	862a                	mv	a2,a0
}
    1a54:	74a2                	ld	s1,40(sp)
    1a56:	8532                	mv	a0,a2
    1a58:	6121                	addi	sp,sp,64
    1a5a:	8082                	ret
		mutex_lock(buffer_lock);
    1a5c:	10c4a503          	lw	a0,268(s1)
    1a60:	625000ef          	jal	ra,2884 <mutex_lock>
		buffer[buffer_len++] = c;
    1a64:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a66:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a6a:	0017861b          	addiw	a2,a5,1
    1a6e:	97a6                	add	a5,a5,s1
    1a70:	c090                	sw	a2,0(s1)
    1a72:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a76:	02c6c263          	blt	a3,a2,1a9a <putchar+0x76>
    1a7a:	47a9                	li	a5,10
    1a7c:	06f40d63          	beq	s0,a5,1af6 <putchar+0xd2>
    1a80:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a82:	10c4a503          	lw	a0,268(s1)
    1a86:	e432                	sd	a2,8(sp)
    1a88:	609000ef          	jal	ra,2890 <mutex_unlock>
    1a8c:	6622                	ld	a2,8(sp)
}
    1a8e:	70e2                	ld	ra,56(sp)
    1a90:	7442                	ld	s0,48(sp)
    1a92:	74a2                	ld	s1,40(sp)
    1a94:	8532                	mv	a0,a2
    1a96:	6121                	addi	sp,sp,64
    1a98:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a9a:	10000793          	li	a5,256
    1a9e:	02f61063          	bne	a2,a5,1abe <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1aa2:	00001597          	auipc	a1,0x1
    1aa6:	10e58593          	addi	a1,a1,270 # 2bb0 <buffer>
    1aaa:	4505                	li	a0,1
    1aac:	361000ef          	jal	ra,260c <write>
    1ab0:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1ab4:	00001797          	auipc	a5,0x1
    1ab8:	0e07aa23          	sw	zero,244(a5) # 2ba8 <buffer_len>
			if (r < 0) {
    1abc:	b7d9                	j	1a82 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1abe:	359000ef          	jal	ra,2616 <getpid>
    1ac2:	842a                	mv	s0,a0
    1ac4:	00001517          	auipc	a0,0x1
    1ac8:	fac50513          	addi	a0,a0,-84 # 2a70 <enable_deadlock_detect+0x18c>
    1acc:	221000ef          	jal	ra,24ec <basename>
    1ad0:	872a                	mv	a4,a0
    1ad2:	00001617          	auipc	a2,0x1
    1ad6:	e6660613          	addi	a2,a2,-410 # 2938 <enable_deadlock_detect+0x54>
    1ada:	05400793          	li	a5,84
    1ade:	86a2                	mv	a3,s0
    1ae0:	45fd                	li	a1,31
    1ae2:	00001517          	auipc	a0,0x1
    1ae6:	fce50513          	addi	a0,a0,-50 # 2ab0 <enable_deadlock_detect+0x1cc>
    1aea:	8fbff0ef          	jal	ra,13e4 <printf>
    1aee:	557d                	li	a0,-1
    1af0:	357000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    1af4:	4090                	lw	a2,0(s1)
    1af6:	d651                	beqz	a2,1a82 <putchar+0x5e>
    1af8:	b76d                	j	1aa2 <putchar+0x7e>

0000000000001afa <puts>:
{
    1afa:	7139                	addi	sp,sp,-64
    1afc:	f822                	sd	s0,48(sp)
    1afe:	f426                	sd	s1,40(sp)
    1b00:	fc06                	sd	ra,56(sp)
    1b02:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1b04:	00001417          	auipc	s0,0x1
    1b08:	0a440413          	addi	s0,s0,164 # 2ba8 <buffer_len>
{
    1b0c:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b0e:	638000ef          	jal	ra,2146 <strlen>
	if (buffer_lock_enabled == 1) {
    1b12:	10842703          	lw	a4,264(s0)
    1b16:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b18:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1b1a:	04f70563          	beq	a4,a5,1b64 <puts+0x6a>
		len = out_unlocked(s, l);
    1b1e:	8526                	mv	a0,s1
    1b20:	d51ff0ef          	jal	ra,1870 <out_unlocked>
    1b24:	892a                	mv	s2,a0
    1b26:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b28:	00095963          	bgez	s2,1b3a <puts+0x40>
}
    1b2c:	70e2                	ld	ra,56(sp)
    1b2e:	7442                	ld	s0,48(sp)
    1b30:	7902                	ld	s2,32(sp)
    1b32:	8526                	mv	a0,s1
    1b34:	74a2                	ld	s1,40(sp)
    1b36:	6121                	addi	sp,sp,64
    1b38:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1b3a:	10842703          	lw	a4,264(s0)
	char byte = c;
    1b3e:	44a9                	li	s1,10
    1b40:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1b44:	4785                	li	a5,1
    1b46:	02f70e63          	beq	a4,a5,1b82 <puts+0x88>
		len = out_unlocked(s, l);
    1b4a:	01f10513          	addi	a0,sp,31
    1b4e:	e2fff0ef          	jal	ra,197c <out_unlocked.constprop.0>
}
    1b52:	70e2                	ld	ra,56(sp)
    1b54:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b56:	41f5549b          	sraiw	s1,a0,0x1f
}
    1b5a:	7902                	ld	s2,32(sp)
    1b5c:	8526                	mv	a0,s1
    1b5e:	74a2                	ld	s1,40(sp)
    1b60:	6121                	addi	sp,sp,64
    1b62:	8082                	ret
		mutex_lock(buffer_lock);
    1b64:	e42a                	sd	a0,8(sp)
    1b66:	10c42503          	lw	a0,268(s0)
    1b6a:	51b000ef          	jal	ra,2884 <mutex_lock>
		len = out_unlocked(s, l);
    1b6e:	65a2                	ld	a1,8(sp)
    1b70:	8526                	mv	a0,s1
    1b72:	cffff0ef          	jal	ra,1870 <out_unlocked>
    1b76:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b78:	10c42503          	lw	a0,268(s0)
    1b7c:	515000ef          	jal	ra,2890 <mutex_unlock>
    1b80:	b75d                	j	1b26 <puts+0x2c>
		mutex_lock(buffer_lock);
    1b82:	10c42503          	lw	a0,268(s0)
    1b86:	4ff000ef          	jal	ra,2884 <mutex_lock>
		buffer[buffer_len++] = c;
    1b8a:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b8c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b90:	0017861b          	addiw	a2,a5,1
    1b94:	97a2                	add	a5,a5,s0
    1b96:	c010                	sw	a2,0(s0)
    1b98:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b9c:	06c6dc63          	bge	a3,a2,1c14 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1ba0:	10000793          	li	a5,256
    1ba4:	02f61c63          	bne	a2,a5,1bdc <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1ba8:	00001597          	auipc	a1,0x1
    1bac:	00858593          	addi	a1,a1,8 # 2bb0 <buffer>
    1bb0:	4505                	li	a0,1
    1bb2:	25b000ef          	jal	ra,260c <write>
			if (r < 0) {
    1bb6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1bb8:	00001797          	auipc	a5,0x1
    1bbc:	fe07a823          	sw	zero,-16(a5) # 2ba8 <buffer_len>
			if (r < 0) {
    1bc0:	04054c63          	bltz	a0,1c18 <puts+0x11e>
			if (r < buffer_len) {
    1bc4:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1bc6:	10c42503          	lw	a0,268(s0)
    1bca:	4c7000ef          	jal	ra,2890 <mutex_unlock>
}
    1bce:	70e2                	ld	ra,56(sp)
    1bd0:	7442                	ld	s0,48(sp)
    1bd2:	7902                	ld	s2,32(sp)
    1bd4:	8526                	mv	a0,s1
    1bd6:	74a2                	ld	s1,40(sp)
    1bd8:	6121                	addi	sp,sp,64
    1bda:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bdc:	23b000ef          	jal	ra,2616 <getpid>
    1be0:	84aa                	mv	s1,a0
    1be2:	00001517          	auipc	a0,0x1
    1be6:	e8e50513          	addi	a0,a0,-370 # 2a70 <enable_deadlock_detect+0x18c>
    1bea:	103000ef          	jal	ra,24ec <basename>
    1bee:	872a                	mv	a4,a0
    1bf0:	00001617          	auipc	a2,0x1
    1bf4:	d4860613          	addi	a2,a2,-696 # 2938 <enable_deadlock_detect+0x54>
    1bf8:	05400793          	li	a5,84
    1bfc:	86a6                	mv	a3,s1
    1bfe:	45fd                	li	a1,31
    1c00:	00001517          	auipc	a0,0x1
    1c04:	eb050513          	addi	a0,a0,-336 # 2ab0 <enable_deadlock_detect+0x1cc>
    1c08:	fdcff0ef          	jal	ra,13e4 <printf>
    1c0c:	557d                	li	a0,-1
    1c0e:	239000ef          	jal	ra,2646 <exit>
	if (buffer_len == 0)
    1c12:	4010                	lw	a2,0(s0)
    1c14:	da45                	beqz	a2,1bc4 <puts+0xca>
    1c16:	bf49                	j	1ba8 <puts+0xae>
    1c18:	54fd                	li	s1,-1
    1c1a:	b775                	j	1bc6 <puts+0xcc>

0000000000001c1c <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1c1c:	715d                	addi	sp,sp,-80
    1c1e:	e486                	sd	ra,72(sp)
    1c20:	e0a2                	sd	s0,64(sp)
    1c22:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1c24:	14054363          	bltz	a0,1d6a <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1c28:	02b577bb          	remuw	a5,a0,a1
    1c2c:	00001617          	auipc	a2,0x1
    1c30:	08c60613          	addi	a2,a2,140 # 2cb8 <digits>
	buf[16] = 0;
    1c34:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c38:	0005871b          	sext.w	a4,a1
    1c3c:	1782                	slli	a5,a5,0x20
    1c3e:	9381                	srli	a5,a5,0x20
    1c40:	97b2                	add	a5,a5,a2
    1c42:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c46:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1c4a:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1c4e:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1c50:	0eb56763          	bltu	a0,a1,1d3e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c54:	02e877bb          	remuw	a5,a6,a4
    1c58:	1782                	slli	a5,a5,0x20
    1c5a:	9381                	srli	a5,a5,0x20
    1c5c:	97b2                	add	a5,a5,a2
    1c5e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c62:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1c66:	02f10323          	sb	a5,38(sp)
    1c6a:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1c6c:	0ce86963          	bltu	a6,a4,1d3e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c70:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c74:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c78:	1582                	slli	a1,a1,0x20
    1c7a:	9181                	srli	a1,a1,0x20
    1c7c:	95b2                	add	a1,a1,a2
    1c7e:	0005c583          	lbu	a1,0(a1)
    1c82:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c86:	0007859b          	sext.w	a1,a5
    1c8a:	16e6e563          	bltu	a3,a4,1df4 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c8e:	02e7f6bb          	remuw	a3,a5,a4
    1c92:	1682                	slli	a3,a3,0x20
    1c94:	9281                	srli	a3,a3,0x20
    1c96:	96b2                	add	a3,a3,a2
    1c98:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c9c:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ca0:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1ca4:	16e5e163          	bltu	a1,a4,1e06 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1ca8:	02e876bb          	remuw	a3,a6,a4
    1cac:	1682                	slli	a3,a3,0x20
    1cae:	9281                	srli	a3,a3,0x20
    1cb0:	96b2                	add	a3,a3,a2
    1cb2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cb6:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cba:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1cbe:	14e86d63          	bltu	a6,a4,1e18 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1cc2:	02e5f6bb          	remuw	a3,a1,a4
    1cc6:	1682                	slli	a3,a3,0x20
    1cc8:	9281                	srli	a3,a3,0x20
    1cca:	96b2                	add	a3,a3,a2
    1ccc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cd0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1cd4:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1cd8:	10e5e563          	bltu	a1,a4,1de2 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1cdc:	02e876bb          	remuw	a3,a6,a4
    1ce0:	1682                	slli	a3,a3,0x20
    1ce2:	9281                	srli	a3,a3,0x20
    1ce4:	96b2                	add	a3,a3,a2
    1ce6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cea:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cee:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1cf2:	14e86263          	bltu	a6,a4,1e36 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1cf6:	02e5f6bb          	remuw	a3,a1,a4
    1cfa:	1682                	slli	a3,a3,0x20
    1cfc:	9281                	srli	a3,a3,0x20
    1cfe:	96b2                	add	a3,a3,a2
    1d00:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d04:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d08:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1d0c:	14e5e463          	bltu	a1,a4,1e54 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1d10:	02e876bb          	remuw	a3,a6,a4
    1d14:	1682                	slli	a3,a3,0x20
    1d16:	9281                	srli	a3,a3,0x20
    1d18:	96b2                	add	a3,a3,a2
    1d1a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d1e:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1d22:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1d26:	14e86063          	bltu	a6,a4,1e66 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1d2a:	1782                	slli	a5,a5,0x20
    1d2c:	9381                	srli	a5,a5,0x20
    1d2e:	97b2                	add	a5,a5,a2
    1d30:	0007c703          	lbu	a4,0(a5)
    1d34:	4799                	li	a5,6
    1d36:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1d3a:	10054763          	bltz	a0,1e48 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1d3e:	00001497          	auipc	s1,0x1
    1d42:	e6a48493          	addi	s1,s1,-406 # 2ba8 <buffer_len>
    1d46:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1d4a:	0828                	addi	a0,sp,24
    1d4c:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1d4e:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1d50:	00f50433          	add	s0,a0,a5
    1d54:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1d56:	06e68463          	beq	a3,a4,1dbe <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1d5a:	8522                	mv	a0,s0
    1d5c:	b15ff0ef          	jal	ra,1870 <out_unlocked>
}
    1d60:	60a6                	ld	ra,72(sp)
    1d62:	6406                	ld	s0,64(sp)
    1d64:	74e2                	ld	s1,56(sp)
    1d66:	6161                	addi	sp,sp,80
    1d68:	8082                	ret
		x = -xx;
    1d6a:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d6e:	02b877bb          	remuw	a5,a6,a1
    1d72:	00001617          	auipc	a2,0x1
    1d76:	f4660613          	addi	a2,a2,-186 # 2cb8 <digits>
	buf[16] = 0;
    1d7a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d7e:	0005871b          	sext.w	a4,a1
    1d82:	1782                	slli	a5,a5,0x20
    1d84:	9381                	srli	a5,a5,0x20
    1d86:	97b2                	add	a5,a5,a2
    1d88:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d8c:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d90:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d94:	08b86b63          	bltu	a6,a1,1e2a <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d98:	02e8f7bb          	remuw	a5,a7,a4
    1d9c:	1782                	slli	a5,a5,0x20
    1d9e:	9381                	srli	a5,a5,0x20
    1da0:	97b2                	add	a5,a5,a2
    1da2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1da6:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1daa:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1dae:	ece8f1e3          	bgeu	a7,a4,1c70 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1db2:	02d00793          	li	a5,45
    1db6:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1dba:	47b5                	li	a5,13
    1dbc:	b749                	j	1d3e <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1dbe:	10c4a503          	lw	a0,268(s1)
    1dc2:	e42e                	sd	a1,8(sp)
    1dc4:	2c1000ef          	jal	ra,2884 <mutex_lock>
		len = out_unlocked(s, l);
    1dc8:	65a2                	ld	a1,8(sp)
    1dca:	8522                	mv	a0,s0
    1dcc:	aa5ff0ef          	jal	ra,1870 <out_unlocked>
		mutex_unlock(buffer_lock);
    1dd0:	10c4a503          	lw	a0,268(s1)
    1dd4:	2bd000ef          	jal	ra,2890 <mutex_unlock>
}
    1dd8:	60a6                	ld	ra,72(sp)
    1dda:	6406                	ld	s0,64(sp)
    1ddc:	74e2                	ld	s1,56(sp)
    1dde:	6161                	addi	sp,sp,80
    1de0:	8082                	ret
		buf[i--] = digits[x % base];
    1de2:	47a9                	li	a5,10
	if (sign)
    1de4:	f4055de3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de8:	02d00793          	li	a5,45
    1dec:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1df0:	47a5                	li	a5,9
    1df2:	b7b1                	j	1d3e <printint.constprop.0+0x122>
    1df4:	47b5                	li	a5,13
	if (sign)
    1df6:	f40554e3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dfa:	02d00793          	li	a5,45
    1dfe:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1e02:	47b1                	li	a5,12
    1e04:	bf2d                	j	1d3e <printint.constprop.0+0x122>
    1e06:	47b1                	li	a5,12
	if (sign)
    1e08:	f2055be3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e0c:	02d00793          	li	a5,45
    1e10:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1e14:	47ad                	li	a5,11
    1e16:	b725                	j	1d3e <printint.constprop.0+0x122>
    1e18:	47ad                	li	a5,11
	if (sign)
    1e1a:	f20552e3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e1e:	02d00793          	li	a5,45
    1e22:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1e26:	47a9                	li	a5,10
    1e28:	bf19                	j	1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e2a:	02d00793          	li	a5,45
    1e2e:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1e32:	47b9                	li	a5,14
    1e34:	b729                	j	1d3e <printint.constprop.0+0x122>
    1e36:	47a5                	li	a5,9
	if (sign)
    1e38:	f00553e3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e3c:	02d00793          	li	a5,45
    1e40:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1e44:	47a1                	li	a5,8
    1e46:	bde5                	j	1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e48:	02d00793          	li	a5,45
    1e4c:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1e50:	4795                	li	a5,5
    1e52:	b5f5                	j	1d3e <printint.constprop.0+0x122>
    1e54:	47a1                	li	a5,8
	if (sign)
    1e56:	ee0554e3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e5a:	02d00793          	li	a5,45
    1e5e:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1e62:	479d                	li	a5,7
    1e64:	bde9                	j	1d3e <printint.constprop.0+0x122>
    1e66:	479d                	li	a5,7
	if (sign)
    1e68:	ec055be3          	bgez	a0,1d3e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e6c:	02d00793          	li	a5,45
    1e70:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e74:	4799                	li	a5,6
    1e76:	b5e1                	j	1d3e <printint.constprop.0+0x122>

0000000000001e78 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e78:	02000793          	li	a5,32
    1e7c:	00f50663          	beq	a0,a5,1e88 <isspace+0x10>
    1e80:	355d                	addiw	a0,a0,-9
    1e82:	00553513          	sltiu	a0,a0,5
    1e86:	8082                	ret
    1e88:	4505                	li	a0,1
}
    1e8a:	8082                	ret

0000000000001e8c <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e8c:	fd05051b          	addiw	a0,a0,-48
}
    1e90:	00a53513          	sltiu	a0,a0,10
    1e94:	8082                	ret

0000000000001e96 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e96:	02000613          	li	a2,32
    1e9a:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e9c:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1ea0:	ff77869b          	addiw	a3,a5,-9
    1ea4:	04c78c63          	beq	a5,a2,1efc <atoi+0x66>
    1ea8:	0007871b          	sext.w	a4,a5
    1eac:	04d5f863          	bgeu	a1,a3,1efc <atoi+0x66>
		s++;
	switch (*s) {
    1eb0:	02b00693          	li	a3,43
    1eb4:	04d78963          	beq	a5,a3,1f06 <atoi+0x70>
    1eb8:	02d00693          	li	a3,45
    1ebc:	06d78263          	beq	a5,a3,1f20 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1ec0:	fd07061b          	addiw	a2,a4,-48
    1ec4:	47a5                	li	a5,9
    1ec6:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1ec8:	4e01                	li	t3,0
	while (isdigit(*s))
    1eca:	04c7e963          	bltu	a5,a2,1f1c <atoi+0x86>
	int n = 0, neg = 0;
    1ece:	4501                	li	a0,0
	while (isdigit(*s))
    1ed0:	4825                	li	a6,9
    1ed2:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1ed6:	0025179b          	slliw	a5,a0,0x2
    1eda:	9fa9                	addw	a5,a5,a0
    1edc:	fd07031b          	addiw	t1,a4,-48
    1ee0:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ee4:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ee8:	0685                	addi	a3,a3,1
    1eea:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1eee:	0006071b          	sext.w	a4,a2
    1ef2:	feb870e3          	bgeu	a6,a1,1ed2 <atoi+0x3c>
	return neg ? n : -n;
    1ef6:	000e0563          	beqz	t3,1f00 <atoi+0x6a>
}
    1efa:	8082                	ret
		s++;
    1efc:	0505                	addi	a0,a0,1
    1efe:	bf79                	j	1e9c <atoi+0x6>
	return neg ? n : -n;
    1f00:	4113053b          	subw	a0,t1,a7
    1f04:	8082                	ret
	while (isdigit(*s))
    1f06:	00154703          	lbu	a4,1(a0)
    1f0a:	47a5                	li	a5,9
		s++;
    1f0c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1f10:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1f14:	4e01                	li	t3,0
	while (isdigit(*s))
    1f16:	2701                	sext.w	a4,a4
    1f18:	fac7fbe3          	bgeu	a5,a2,1ece <atoi+0x38>
    1f1c:	4501                	li	a0,0
}
    1f1e:	8082                	ret
	while (isdigit(*s))
    1f20:	00154703          	lbu	a4,1(a0)
    1f24:	47a5                	li	a5,9
		s++;
    1f26:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1f2a:	fd07061b          	addiw	a2,a4,-48
    1f2e:	2701                	sext.w	a4,a4
    1f30:	fec7e6e3          	bltu	a5,a2,1f1c <atoi+0x86>
		neg = 1;
    1f34:	4e05                	li	t3,1
    1f36:	bf61                	j	1ece <atoi+0x38>

0000000000001f38 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f38:	16060d63          	beqz	a2,20b2 <memset+0x17a>
    1f3c:	40a007b3          	neg	a5,a0
    1f40:	8b9d                	andi	a5,a5,7
    1f42:	00778693          	addi	a3,a5,7
    1f46:	482d                	li	a6,11
    1f48:	0ff5f713          	zext.b	a4,a1
    1f4c:	fff60593          	addi	a1,a2,-1
    1f50:	1706e263          	bltu	a3,a6,20b4 <memset+0x17c>
    1f54:	16d5ea63          	bltu	a1,a3,20c8 <memset+0x190>
    1f58:	16078563          	beqz	a5,20c2 <memset+0x18a>
    1f5c:	00e50023          	sb	a4,0(a0)
    1f60:	4685                	li	a3,1
    1f62:	00150593          	addi	a1,a0,1
    1f66:	14d78c63          	beq	a5,a3,20be <memset+0x186>
    1f6a:	00e500a3          	sb	a4,1(a0)
    1f6e:	4689                	li	a3,2
    1f70:	00250593          	addi	a1,a0,2
    1f74:	14d78d63          	beq	a5,a3,20ce <memset+0x196>
    1f78:	00e50123          	sb	a4,2(a0)
    1f7c:	468d                	li	a3,3
    1f7e:	00350593          	addi	a1,a0,3
    1f82:	12d78b63          	beq	a5,a3,20b8 <memset+0x180>
    1f86:	00e501a3          	sb	a4,3(a0)
    1f8a:	4691                	li	a3,4
    1f8c:	00450593          	addi	a1,a0,4
    1f90:	14d78163          	beq	a5,a3,20d2 <memset+0x19a>
    1f94:	00e50223          	sb	a4,4(a0)
    1f98:	4695                	li	a3,5
    1f9a:	00550593          	addi	a1,a0,5
    1f9e:	12d78c63          	beq	a5,a3,20d6 <memset+0x19e>
    1fa2:	00e502a3          	sb	a4,5(a0)
    1fa6:	469d                	li	a3,7
    1fa8:	00650593          	addi	a1,a0,6
    1fac:	12d79763          	bne	a5,a3,20da <memset+0x1a2>
    1fb0:	00750593          	addi	a1,a0,7
    1fb4:	00e50323          	sb	a4,6(a0)
    1fb8:	481d                	li	a6,7
    1fba:	00871693          	slli	a3,a4,0x8
    1fbe:	01071893          	slli	a7,a4,0x10
    1fc2:	8ed9                	or	a3,a3,a4
    1fc4:	01871313          	slli	t1,a4,0x18
    1fc8:	0116e6b3          	or	a3,a3,a7
    1fcc:	0066e6b3          	or	a3,a3,t1
    1fd0:	02071893          	slli	a7,a4,0x20
    1fd4:	02871e13          	slli	t3,a4,0x28
    1fd8:	0116e6b3          	or	a3,a3,a7
    1fdc:	40f60333          	sub	t1,a2,a5
    1fe0:	03071893          	slli	a7,a4,0x30
    1fe4:	01c6e6b3          	or	a3,a3,t3
    1fe8:	0116e6b3          	or	a3,a3,a7
    1fec:	03871e13          	slli	t3,a4,0x38
    1ff0:	97aa                	add	a5,a5,a0
    1ff2:	ff837893          	andi	a7,t1,-8
    1ff6:	01c6e6b3          	or	a3,a3,t3
    1ffa:	98be                	add	a7,a7,a5
    1ffc:	e394                	sd	a3,0(a5)
    1ffe:	07a1                	addi	a5,a5,8
    2000:	ff179ee3          	bne	a5,a7,1ffc <memset+0xc4>
    2004:	ff837893          	andi	a7,t1,-8
    2008:	011587b3          	add	a5,a1,a7
    200c:	010886bb          	addw	a3,a7,a6
    2010:	0b130663          	beq	t1,a7,20bc <memset+0x184>
    2014:	00e78023          	sb	a4,0(a5)
    2018:	0016859b          	addiw	a1,a3,1
    201c:	08c5fb63          	bgeu	a1,a2,20b2 <memset+0x17a>
    2020:	00e780a3          	sb	a4,1(a5)
    2024:	0026859b          	addiw	a1,a3,2
    2028:	08c5f563          	bgeu	a1,a2,20b2 <memset+0x17a>
    202c:	00e78123          	sb	a4,2(a5)
    2030:	0036859b          	addiw	a1,a3,3
    2034:	06c5ff63          	bgeu	a1,a2,20b2 <memset+0x17a>
    2038:	00e781a3          	sb	a4,3(a5)
    203c:	0046859b          	addiw	a1,a3,4
    2040:	06c5f963          	bgeu	a1,a2,20b2 <memset+0x17a>
    2044:	00e78223          	sb	a4,4(a5)
    2048:	0056859b          	addiw	a1,a3,5
    204c:	06c5f363          	bgeu	a1,a2,20b2 <memset+0x17a>
    2050:	00e782a3          	sb	a4,5(a5)
    2054:	0066859b          	addiw	a1,a3,6
    2058:	04c5fd63          	bgeu	a1,a2,20b2 <memset+0x17a>
    205c:	00e78323          	sb	a4,6(a5)
    2060:	0076859b          	addiw	a1,a3,7
    2064:	04c5f763          	bgeu	a1,a2,20b2 <memset+0x17a>
    2068:	00e783a3          	sb	a4,7(a5)
    206c:	0086859b          	addiw	a1,a3,8
    2070:	04c5f163          	bgeu	a1,a2,20b2 <memset+0x17a>
    2074:	00e78423          	sb	a4,8(a5)
    2078:	0096859b          	addiw	a1,a3,9
    207c:	02c5fb63          	bgeu	a1,a2,20b2 <memset+0x17a>
    2080:	00e784a3          	sb	a4,9(a5)
    2084:	00a6859b          	addiw	a1,a3,10
    2088:	02c5f563          	bgeu	a1,a2,20b2 <memset+0x17a>
    208c:	00e78523          	sb	a4,10(a5)
    2090:	00b6859b          	addiw	a1,a3,11
    2094:	00c5ff63          	bgeu	a1,a2,20b2 <memset+0x17a>
    2098:	00e785a3          	sb	a4,11(a5)
    209c:	00c6859b          	addiw	a1,a3,12
    20a0:	00c5f963          	bgeu	a1,a2,20b2 <memset+0x17a>
    20a4:	00e78623          	sb	a4,12(a5)
    20a8:	26b5                	addiw	a3,a3,13
    20aa:	00c6f463          	bgeu	a3,a2,20b2 <memset+0x17a>
    20ae:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    20b2:	8082                	ret
    20b4:	46ad                	li	a3,11
    20b6:	bd79                	j	1f54 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20b8:	480d                	li	a6,3
    20ba:	b701                	j	1fba <memset+0x82>
    20bc:	8082                	ret
    20be:	4805                	li	a6,1
    20c0:	bded                	j	1fba <memset+0x82>
    20c2:	85aa                	mv	a1,a0
    20c4:	4801                	li	a6,0
    20c6:	bdd5                	j	1fba <memset+0x82>
    20c8:	87aa                	mv	a5,a0
    20ca:	4681                	li	a3,0
    20cc:	b7a1                	j	2014 <memset+0xdc>
    20ce:	4809                	li	a6,2
    20d0:	b5ed                	j	1fba <memset+0x82>
    20d2:	4811                	li	a6,4
    20d4:	b5dd                	j	1fba <memset+0x82>
    20d6:	4815                	li	a6,5
    20d8:	b5cd                	j	1fba <memset+0x82>
    20da:	4819                	li	a6,6
    20dc:	bdf9                	j	1fba <memset+0x82>

00000000000020de <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    20de:	00054783          	lbu	a5,0(a0)
    20e2:	0005c703          	lbu	a4,0(a1)
    20e6:	00e79863          	bne	a5,a4,20f6 <strcmp+0x18>
    20ea:	0505                	addi	a0,a0,1
    20ec:	0585                	addi	a1,a1,1
    20ee:	fbe5                	bnez	a5,20de <strcmp>
    20f0:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    20f2:	9d19                	subw	a0,a0,a4
    20f4:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    20f6:	0007851b          	sext.w	a0,a5
    20fa:	bfe5                	j	20f2 <strcmp+0x14>

00000000000020fc <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    20fc:	ca15                	beqz	a2,2130 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20fe:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2102:	167d                	addi	a2,a2,-1
    2104:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2108:	eb99                	bnez	a5,211e <strncmp+0x22>
    210a:	a815                	j	213e <strncmp+0x42>
    210c:	00a68e63          	beq	a3,a0,2128 <strncmp+0x2c>
    2110:	0505                	addi	a0,a0,1
    2112:	00f71b63          	bne	a4,a5,2128 <strncmp+0x2c>
    2116:	00054783          	lbu	a5,0(a0)
    211a:	cf89                	beqz	a5,2134 <strncmp+0x38>
    211c:	85b2                	mv	a1,a2
    211e:	0005c703          	lbu	a4,0(a1)
    2122:	00158613          	addi	a2,a1,1
    2126:	f37d                	bnez	a4,210c <strncmp+0x10>
		;
	return *l - *r;
    2128:	0007851b          	sext.w	a0,a5
    212c:	9d19                	subw	a0,a0,a4
    212e:	8082                	ret
		return 0;
    2130:	4501                	li	a0,0
}
    2132:	8082                	ret
	return *l - *r;
    2134:	0015c703          	lbu	a4,1(a1)
    2138:	4501                	li	a0,0
    213a:	9d19                	subw	a0,a0,a4
    213c:	8082                	ret
    213e:	0005c703          	lbu	a4,0(a1)
    2142:	4501                	li	a0,0
    2144:	b7e5                	j	212c <strncmp+0x30>

0000000000002146 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2146:	00757793          	andi	a5,a0,7
    214a:	cf89                	beqz	a5,2164 <strlen+0x1e>
    214c:	87aa                	mv	a5,a0
    214e:	a029                	j	2158 <strlen+0x12>
    2150:	0785                	addi	a5,a5,1
    2152:	0077f713          	andi	a4,a5,7
    2156:	cb01                	beqz	a4,2166 <strlen+0x20>
		if (!*s)
    2158:	0007c703          	lbu	a4,0(a5)
    215c:	fb75                	bnez	a4,2150 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    215e:	40a78533          	sub	a0,a5,a0
}
    2162:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2164:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2166:	6394                	ld	a3,0(a5)
    2168:	00001597          	auipc	a1,0x1
    216c:	9e05b583          	ld	a1,-1568(a1) # 2b48 <enable_deadlock_detect+0x264>
    2170:	00001617          	auipc	a2,0x1
    2174:	9e063603          	ld	a2,-1568(a2) # 2b50 <enable_deadlock_detect+0x26c>
    2178:	a019                	j	217e <strlen+0x38>
    217a:	6794                	ld	a3,8(a5)
    217c:	07a1                	addi	a5,a5,8
    217e:	00b68733          	add	a4,a3,a1
    2182:	fff6c693          	not	a3,a3
    2186:	8f75                	and	a4,a4,a3
    2188:	8f71                	and	a4,a4,a2
    218a:	db65                	beqz	a4,217a <strlen+0x34>
	for (; *s; s++)
    218c:	0007c703          	lbu	a4,0(a5)
    2190:	d779                	beqz	a4,215e <strlen+0x18>
    2192:	0017c703          	lbu	a4,1(a5)
    2196:	0785                	addi	a5,a5,1
    2198:	d379                	beqz	a4,215e <strlen+0x18>
    219a:	0017c703          	lbu	a4,1(a5)
    219e:	0785                	addi	a5,a5,1
    21a0:	fb6d                	bnez	a4,2192 <strlen+0x4c>
    21a2:	bf75                	j	215e <strlen+0x18>

00000000000021a4 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    21a4:	00757713          	andi	a4,a0,7
{
    21a8:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    21aa:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    21ae:	cb19                	beqz	a4,21c4 <memchr+0x20>
    21b0:	ce25                	beqz	a2,2228 <memchr+0x84>
    21b2:	0007c703          	lbu	a4,0(a5)
    21b6:	04b70e63          	beq	a4,a1,2212 <memchr+0x6e>
    21ba:	0785                	addi	a5,a5,1
    21bc:	0077f713          	andi	a4,a5,7
    21c0:	167d                	addi	a2,a2,-1
    21c2:	f77d                	bnez	a4,21b0 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    21c4:	4501                	li	a0,0
	if (n && *s != c) {
    21c6:	c235                	beqz	a2,222a <memchr+0x86>
    21c8:	0007c703          	lbu	a4,0(a5)
    21cc:	04b70363          	beq	a4,a1,2212 <memchr+0x6e>
		size_t k = ONES * c;
    21d0:	00001517          	auipc	a0,0x1
    21d4:	98853503          	ld	a0,-1656(a0) # 2b58 <enable_deadlock_detect+0x274>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21d8:	471d                	li	a4,7
		size_t k = ONES * c;
    21da:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21de:	02c77a63          	bgeu	a4,a2,2212 <memchr+0x6e>
    21e2:	00001897          	auipc	a7,0x1
    21e6:	9668b883          	ld	a7,-1690(a7) # 2b48 <enable_deadlock_detect+0x264>
    21ea:	00001817          	auipc	a6,0x1
    21ee:	96683803          	ld	a6,-1690(a6) # 2b50 <enable_deadlock_detect+0x26c>
    21f2:	431d                	li	t1,7
    21f4:	a029                	j	21fe <memchr+0x5a>
		     w++, n -= SS)
    21f6:	1661                	addi	a2,a2,-8
    21f8:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21fa:	02c37963          	bgeu	t1,a2,222c <memchr+0x88>
    21fe:	6398                	ld	a4,0(a5)
    2200:	8f29                	xor	a4,a4,a0
    2202:	011706b3          	add	a3,a4,a7
    2206:	fff74713          	not	a4,a4
    220a:	8f75                	and	a4,a4,a3
    220c:	01077733          	and	a4,a4,a6
    2210:	d37d                	beqz	a4,21f6 <memchr+0x52>
{
    2212:	853e                	mv	a0,a5
    2214:	97b2                	add	a5,a5,a2
    2216:	a021                	j	221e <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2218:	0505                	addi	a0,a0,1
    221a:	00f50763          	beq	a0,a5,2228 <memchr+0x84>
    221e:	00054703          	lbu	a4,0(a0)
    2222:	feb71be3          	bne	a4,a1,2218 <memchr+0x74>
    2226:	8082                	ret
	return n ? (void *)s : 0;
    2228:	4501                	li	a0,0
}
    222a:	8082                	ret
	return n ? (void *)s : 0;
    222c:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    222e:	f275                	bnez	a2,2212 <memchr+0x6e>
}
    2230:	8082                	ret

0000000000002232 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2232:	1101                	addi	sp,sp,-32
    2234:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2236:	862e                	mv	a2,a1
{
    2238:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    223a:	4581                	li	a1,0
{
    223c:	e426                	sd	s1,8(sp)
    223e:	ec06                	sd	ra,24(sp)
    2240:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2242:	f63ff0ef          	jal	ra,21a4 <memchr>
	return p ? p - s : n;
    2246:	c519                	beqz	a0,2254 <strnlen+0x22>
}
    2248:	60e2                	ld	ra,24(sp)
    224a:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    224c:	8d05                	sub	a0,a0,s1
}
    224e:	64a2                	ld	s1,8(sp)
    2250:	6105                	addi	sp,sp,32
    2252:	8082                	ret
    2254:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2256:	8522                	mv	a0,s0
}
    2258:	6442                	ld	s0,16(sp)
    225a:	64a2                	ld	s1,8(sp)
    225c:	6105                	addi	sp,sp,32
    225e:	8082                	ret

0000000000002260 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2260:	00a5c7b3          	xor	a5,a1,a0
    2264:	8b9d                	andi	a5,a5,7
    2266:	eb95                	bnez	a5,229a <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2268:	0075f793          	andi	a5,a1,7
    226c:	e7b1                	bnez	a5,22b8 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    226e:	6198                	ld	a4,0(a1)
    2270:	00001617          	auipc	a2,0x1
    2274:	8d863603          	ld	a2,-1832(a2) # 2b48 <enable_deadlock_detect+0x264>
    2278:	00001817          	auipc	a6,0x1
    227c:	8d883803          	ld	a6,-1832(a6) # 2b50 <enable_deadlock_detect+0x26c>
    2280:	a029                	j	228a <stpcpy+0x2a>
    2282:	05a1                	addi	a1,a1,8
    2284:	e118                	sd	a4,0(a0)
    2286:	6198                	ld	a4,0(a1)
    2288:	0521                	addi	a0,a0,8
    228a:	00c707b3          	add	a5,a4,a2
    228e:	fff74693          	not	a3,a4
    2292:	8ff5                	and	a5,a5,a3
    2294:	0107f7b3          	and	a5,a5,a6
    2298:	d7ed                	beqz	a5,2282 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    229a:	0005c783          	lbu	a5,0(a1)
    229e:	00f50023          	sb	a5,0(a0)
    22a2:	c785                	beqz	a5,22ca <stpcpy+0x6a>
    22a4:	0015c783          	lbu	a5,1(a1)
    22a8:	0505                	addi	a0,a0,1
    22aa:	0585                	addi	a1,a1,1
    22ac:	00f50023          	sb	a5,0(a0)
    22b0:	fbf5                	bnez	a5,22a4 <stpcpy+0x44>
		;
	return d;
}
    22b2:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    22b4:	0505                	addi	a0,a0,1
    22b6:	df45                	beqz	a4,226e <stpcpy+0xe>
			if (!(*d = *s))
    22b8:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    22bc:	0585                	addi	a1,a1,1
    22be:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    22c2:	00f50023          	sb	a5,0(a0)
    22c6:	f7fd                	bnez	a5,22b4 <stpcpy+0x54>
}
    22c8:	8082                	ret
    22ca:	8082                	ret

00000000000022cc <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    22cc:	00a5c7b3          	xor	a5,a1,a0
    22d0:	8b9d                	andi	a5,a5,7
    22d2:	1a079863          	bnez	a5,2482 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    22d6:	0075f793          	andi	a5,a1,7
    22da:	16078463          	beqz	a5,2442 <stpncpy+0x176>
    22de:	ea01                	bnez	a2,22ee <stpncpy+0x22>
    22e0:	a421                	j	24e8 <stpncpy+0x21c>
    22e2:	167d                	addi	a2,a2,-1
    22e4:	0505                	addi	a0,a0,1
    22e6:	14070e63          	beqz	a4,2442 <stpncpy+0x176>
    22ea:	1a060863          	beqz	a2,249a <stpncpy+0x1ce>
    22ee:	0005c783          	lbu	a5,0(a1)
    22f2:	0585                	addi	a1,a1,1
    22f4:	0075f713          	andi	a4,a1,7
    22f8:	00f50023          	sb	a5,0(a0)
    22fc:	f3fd                	bnez	a5,22e2 <stpncpy+0x16>
    22fe:	4805                	li	a6,1
    2300:	1a061863          	bnez	a2,24b0 <stpncpy+0x1e4>
    2304:	40a007b3          	neg	a5,a0
    2308:	8b9d                	andi	a5,a5,7
    230a:	4681                	li	a3,0
    230c:	18061a63          	bnez	a2,24a0 <stpncpy+0x1d4>
    2310:	00778713          	addi	a4,a5,7
    2314:	45ad                	li	a1,11
    2316:	18b76363          	bltu	a4,a1,249c <stpncpy+0x1d0>
    231a:	1ae6eb63          	bltu	a3,a4,24d0 <stpncpy+0x204>
    231e:	1a078363          	beqz	a5,24c4 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2322:	00050023          	sb	zero,0(a0)
    2326:	4685                	li	a3,1
    2328:	00150713          	addi	a4,a0,1
    232c:	18d78f63          	beq	a5,a3,24ca <stpncpy+0x1fe>
    2330:	000500a3          	sb	zero,1(a0)
    2334:	4689                	li	a3,2
    2336:	00250713          	addi	a4,a0,2
    233a:	18d78e63          	beq	a5,a3,24d6 <stpncpy+0x20a>
    233e:	00050123          	sb	zero,2(a0)
    2342:	468d                	li	a3,3
    2344:	00350713          	addi	a4,a0,3
    2348:	16d78c63          	beq	a5,a3,24c0 <stpncpy+0x1f4>
    234c:	000501a3          	sb	zero,3(a0)
    2350:	4691                	li	a3,4
    2352:	00450713          	addi	a4,a0,4
    2356:	18d78263          	beq	a5,a3,24da <stpncpy+0x20e>
    235a:	00050223          	sb	zero,4(a0)
    235e:	4695                	li	a3,5
    2360:	00550713          	addi	a4,a0,5
    2364:	16d78d63          	beq	a5,a3,24de <stpncpy+0x212>
    2368:	000502a3          	sb	zero,5(a0)
    236c:	469d                	li	a3,7
    236e:	00650713          	addi	a4,a0,6
    2372:	16d79863          	bne	a5,a3,24e2 <stpncpy+0x216>
    2376:	00750713          	addi	a4,a0,7
    237a:	00050323          	sb	zero,6(a0)
    237e:	40f80833          	sub	a6,a6,a5
    2382:	ff887593          	andi	a1,a6,-8
    2386:	97aa                	add	a5,a5,a0
    2388:	95be                	add	a1,a1,a5
    238a:	0007b023          	sd	zero,0(a5)
    238e:	07a1                	addi	a5,a5,8
    2390:	feb79de3          	bne	a5,a1,238a <stpncpy+0xbe>
    2394:	ff887593          	andi	a1,a6,-8
    2398:	9ead                	addw	a3,a3,a1
    239a:	00b707b3          	add	a5,a4,a1
    239e:	12b80863          	beq	a6,a1,24ce <stpncpy+0x202>
    23a2:	00078023          	sb	zero,0(a5)
    23a6:	0016871b          	addiw	a4,a3,1
    23aa:	0ec77863          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23ae:	000780a3          	sb	zero,1(a5)
    23b2:	0026871b          	addiw	a4,a3,2
    23b6:	0ec77263          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23ba:	00078123          	sb	zero,2(a5)
    23be:	0036871b          	addiw	a4,a3,3
    23c2:	0cc77c63          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23c6:	000781a3          	sb	zero,3(a5)
    23ca:	0046871b          	addiw	a4,a3,4
    23ce:	0cc77663          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23d2:	00078223          	sb	zero,4(a5)
    23d6:	0056871b          	addiw	a4,a3,5
    23da:	0cc77063          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23de:	000782a3          	sb	zero,5(a5)
    23e2:	0066871b          	addiw	a4,a3,6
    23e6:	0ac77a63          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23ea:	00078323          	sb	zero,6(a5)
    23ee:	0076871b          	addiw	a4,a3,7
    23f2:	0ac77463          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    23f6:	000783a3          	sb	zero,7(a5)
    23fa:	0086871b          	addiw	a4,a3,8
    23fe:	08c77e63          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    2402:	00078423          	sb	zero,8(a5)
    2406:	0096871b          	addiw	a4,a3,9
    240a:	08c77863          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    240e:	000784a3          	sb	zero,9(a5)
    2412:	00a6871b          	addiw	a4,a3,10
    2416:	08c77263          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    241a:	00078523          	sb	zero,10(a5)
    241e:	00b6871b          	addiw	a4,a3,11
    2422:	06c77c63          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    2426:	000785a3          	sb	zero,11(a5)
    242a:	00c6871b          	addiw	a4,a3,12
    242e:	06c77663          	bgeu	a4,a2,249a <stpncpy+0x1ce>
    2432:	00078623          	sb	zero,12(a5)
    2436:	26b5                	addiw	a3,a3,13
    2438:	06c6f163          	bgeu	a3,a2,249a <stpncpy+0x1ce>
    243c:	000786a3          	sb	zero,13(a5)
    2440:	8082                	ret
			;
		if (!n || !*s)
    2442:	c645                	beqz	a2,24ea <stpncpy+0x21e>
    2444:	0005c783          	lbu	a5,0(a1)
    2448:	ea078be3          	beqz	a5,22fe <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    244c:	479d                	li	a5,7
    244e:	02c7ff63          	bgeu	a5,a2,248c <stpncpy+0x1c0>
    2452:	00000897          	auipc	a7,0x0
    2456:	6f68b883          	ld	a7,1782(a7) # 2b48 <enable_deadlock_detect+0x264>
    245a:	00000817          	auipc	a6,0x0
    245e:	6f683803          	ld	a6,1782(a6) # 2b50 <enable_deadlock_detect+0x26c>
    2462:	431d                	li	t1,7
    2464:	6198                	ld	a4,0(a1)
    2466:	011707b3          	add	a5,a4,a7
    246a:	fff74693          	not	a3,a4
    246e:	8ff5                	and	a5,a5,a3
    2470:	0107f7b3          	and	a5,a5,a6
    2474:	ef81                	bnez	a5,248c <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2476:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2478:	1661                	addi	a2,a2,-8
    247a:	05a1                	addi	a1,a1,8
    247c:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    247e:	fec363e3          	bltu	t1,a2,2464 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2482:	e609                	bnez	a2,248c <stpncpy+0x1c0>
    2484:	a08d                	j	24e6 <stpncpy+0x21a>
    2486:	167d                	addi	a2,a2,-1
    2488:	0505                	addi	a0,a0,1
    248a:	ca01                	beqz	a2,249a <stpncpy+0x1ce>
    248c:	0005c783          	lbu	a5,0(a1)
    2490:	0585                	addi	a1,a1,1
    2492:	00f50023          	sb	a5,0(a0)
    2496:	fbe5                	bnez	a5,2486 <stpncpy+0x1ba>
		;
tail:
    2498:	b59d                	j	22fe <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    249a:	8082                	ret
    249c:	472d                	li	a4,11
    249e:	bdb5                	j	231a <stpncpy+0x4e>
    24a0:	00778713          	addi	a4,a5,7
    24a4:	45ad                	li	a1,11
    24a6:	fff60693          	addi	a3,a2,-1
    24aa:	e6b778e3          	bgeu	a4,a1,231a <stpncpy+0x4e>
    24ae:	b7fd                	j	249c <stpncpy+0x1d0>
    24b0:	40a007b3          	neg	a5,a0
    24b4:	8832                	mv	a6,a2
    24b6:	8b9d                	andi	a5,a5,7
    24b8:	4681                	li	a3,0
    24ba:	e4060be3          	beqz	a2,2310 <stpncpy+0x44>
    24be:	b7cd                	j	24a0 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    24c0:	468d                	li	a3,3
    24c2:	bd75                	j	237e <stpncpy+0xb2>
    24c4:	872a                	mv	a4,a0
    24c6:	4681                	li	a3,0
    24c8:	bd5d                	j	237e <stpncpy+0xb2>
    24ca:	4685                	li	a3,1
    24cc:	bd4d                	j	237e <stpncpy+0xb2>
    24ce:	8082                	ret
    24d0:	87aa                	mv	a5,a0
    24d2:	4681                	li	a3,0
    24d4:	b5f9                	j	23a2 <stpncpy+0xd6>
    24d6:	4689                	li	a3,2
    24d8:	b55d                	j	237e <stpncpy+0xb2>
    24da:	4691                	li	a3,4
    24dc:	b54d                	j	237e <stpncpy+0xb2>
    24de:	4695                	li	a3,5
    24e0:	bd79                	j	237e <stpncpy+0xb2>
    24e2:	4699                	li	a3,6
    24e4:	bd69                	j	237e <stpncpy+0xb2>
    24e6:	8082                	ret
    24e8:	8082                	ret
    24ea:	8082                	ret

00000000000024ec <basename>:

char *basename(char *s)
{
    24ec:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    24ee:	c54d                	beqz	a0,2598 <basename+0xac>
    24f0:	00054783          	lbu	a5,0(a0)
		return ".";
    24f4:	00000517          	auipc	a0,0x0
    24f8:	64c50513          	addi	a0,a0,1612 # 2b40 <enable_deadlock_detect+0x25c>
	if (!s || !*s)
    24fc:	e391                	bnez	a5,2500 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    24fe:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2500:	0076f713          	andi	a4,a3,7
    2504:	87b6                	mv	a5,a3
    2506:	cf51                	beqz	a4,25a2 <basename+0xb6>
    2508:	0785                	addi	a5,a5,1
    250a:	0077f713          	andi	a4,a5,7
    250e:	c729                	beqz	a4,2558 <basename+0x6c>
		if (!*s)
    2510:	0007c703          	lbu	a4,0(a5)
    2514:	fb75                	bnez	a4,2508 <basename+0x1c>
	return s - a;
    2516:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2518:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    251a:	cf8d                	beqz	a5,2554 <basename+0x68>
    251c:	00f68733          	add	a4,a3,a5
    2520:	02f00593          	li	a1,47
    2524:	a031                	j	2530 <basename+0x44>
		s[i] = 0;
    2526:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    252a:	17fd                	addi	a5,a5,-1
    252c:	177d                	addi	a4,a4,-1
    252e:	c39d                	beqz	a5,2554 <basename+0x68>
    2530:	00074603          	lbu	a2,0(a4)
    2534:	feb609e3          	beq	a2,a1,2526 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2538:	02f00613          	li	a2,47
    253c:	a011                	j	2540 <basename+0x54>
    253e:	cb99                	beqz	a5,2554 <basename+0x68>
    2540:	853e                	mv	a0,a5
    2542:	17fd                	addi	a5,a5,-1
    2544:	00f68733          	add	a4,a3,a5
    2548:	00074703          	lbu	a4,0(a4)
    254c:	fec719e3          	bne	a4,a2,253e <basename+0x52>
	return s + i;
    2550:	9536                	add	a0,a0,a3
    2552:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2554:	8536                	mv	a0,a3
    2556:	8082                	ret
    2558:	6390                	ld	a2,0(a5)
    255a:	00000517          	auipc	a0,0x0
    255e:	5ee53503          	ld	a0,1518(a0) # 2b48 <enable_deadlock_detect+0x264>
    2562:	00000597          	auipc	a1,0x0
    2566:	5ee5b583          	ld	a1,1518(a1) # 2b50 <enable_deadlock_detect+0x26c>
    256a:	fff64713          	not	a4,a2
    256e:	962a                	add	a2,a2,a0
    2570:	8f71                	and	a4,a4,a2
    2572:	8f6d                	and	a4,a4,a1
    2574:	eb11                	bnez	a4,2588 <basename+0x9c>
    2576:	6790                	ld	a2,8(a5)
    2578:	07a1                	addi	a5,a5,8
    257a:	00a60733          	add	a4,a2,a0
    257e:	fff64613          	not	a2,a2
    2582:	8f71                	and	a4,a4,a2
    2584:	8f6d                	and	a4,a4,a1
    2586:	db65                	beqz	a4,2576 <basename+0x8a>
	for (; *s; s++)
    2588:	0007c703          	lbu	a4,0(a5)
    258c:	d749                	beqz	a4,2516 <basename+0x2a>
    258e:	0017c703          	lbu	a4,1(a5)
    2592:	0785                	addi	a5,a5,1
    2594:	ff6d                	bnez	a4,258e <basename+0xa2>
    2596:	b741                	j	2516 <basename+0x2a>
		return ".";
    2598:	00000517          	auipc	a0,0x0
    259c:	5a850513          	addi	a0,a0,1448 # 2b40 <enable_deadlock_detect+0x25c>
    25a0:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    25a2:	6290                	ld	a2,0(a3)
    25a4:	00000517          	auipc	a0,0x0
    25a8:	5a453503          	ld	a0,1444(a0) # 2b48 <enable_deadlock_detect+0x264>
    25ac:	00000597          	auipc	a1,0x0
    25b0:	5a45b583          	ld	a1,1444(a1) # 2b50 <enable_deadlock_detect+0x26c>
    25b4:	fff64713          	not	a4,a2
    25b8:	962a                	add	a2,a2,a0
    25ba:	8f71                	and	a4,a4,a2
    25bc:	8f6d                	and	a4,a4,a1
    25be:	df45                	beqz	a4,2576 <basename+0x8a>
    25c0:	b7f9                	j	258e <basename+0xa2>

00000000000025c2 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    25c2:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    25c6:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25c8:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    25cc:	2501                	sext.w	a0,a0
    25ce:	8082                	ret

00000000000025d0 <close>:

int close(int fd)
{
	if (fd == 1) {
    25d0:	4785                	li	a5,1
    25d2:	00f50863          	beq	a0,a5,25e2 <close+0x12>
	register long a7 __asm__("a7") = n;
    25d6:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25da:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret
{
    25e2:	1101                	addi	sp,sp,-32
    25e4:	ec06                	sd	ra,24(sp)
    25e6:	e42a                	sd	a0,8(sp)
		__write_buffer();
    25e8:	cdffe0ef          	jal	ra,12c6 <__write_buffer>
		__clear_buffer();
    25ec:	d03fe0ef          	jal	ra,12ee <__clear_buffer>
    25f0:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    25f2:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25f6:	00000073          	ecall
}
    25fa:	60e2                	ld	ra,24(sp)
    25fc:	2501                	sext.w	a0,a0
    25fe:	6105                	addi	sp,sp,32
    2600:	8082                	ret

0000000000002602 <read>:
	register long a7 __asm__("a7") = n;
    2602:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2606:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    260a:	8082                	ret

000000000000260c <write>:
	register long a7 __asm__("a7") = n;
    260c:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2610:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2614:	8082                	ret

0000000000002616 <getpid>:
	register long a7 __asm__("a7") = n;
    2616:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    261a:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    261e:	2501                	sext.w	a0,a0
    2620:	8082                	ret

0000000000002622 <getppid>:
	register long a7 __asm__("a7") = n;
    2622:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2626:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    262a:	2501                	sext.w	a0,a0
    262c:	8082                	ret

000000000000262e <sched_yield>:
	register long a7 __asm__("a7") = n;
    262e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2632:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2636:	2501                	sext.w	a0,a0
    2638:	8082                	ret

000000000000263a <fork>:
	register long a7 __asm__("a7") = n;
    263a:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    263e:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2642:	2501                	sext.w	a0,a0
    2644:	8082                	ret

0000000000002646 <exit>:

void exit(int code)
{
    2646:	1141                	addi	sp,sp,-16
    2648:	e406                	sd	ra,8(sp)
    264a:	e022                	sd	s0,0(sp)
    264c:	842a                	mv	s0,a0
	__write_buffer();
    264e:	c79fe0ef          	jal	ra,12c6 <__write_buffer>
	__clear_buffer();
    2652:	c9dfe0ef          	jal	ra,12ee <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2656:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    265a:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    265c:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2660:	60a2                	ld	ra,8(sp)
    2662:	6402                	ld	s0,0(sp)
    2664:	0141                	addi	sp,sp,16
    2666:	8082                	ret

0000000000002668 <waitpid>:
	register long a7 __asm__("a7") = n;
    2668:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266c:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <exec>:
	register long a7 __asm__("a7") = n;
    2674:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2678:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <get_mtime>:

int64 get_mtime()
{
    2680:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2682:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2686:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2688:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268a:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    268e:	2501                	sext.w	a0,a0
    2690:	ed01                	bnez	a0,26a8 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2692:	6722                	ld	a4,8(sp)
    2694:	3e800793          	li	a5,1000
    2698:	6682                	ld	a3,0(sp)
    269a:	02f75733          	divu	a4,a4,a5
    269e:	02d78533          	mul	a0,a5,a3
    26a2:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    26a4:	0141                	addi	sp,sp,16
    26a6:	8082                	ret
	return -1;
    26a8:	557d                	li	a0,-1
    26aa:	bfed                	j	26a4 <get_mtime+0x24>

00000000000026ac <sys_get_time>:
	register long a7 __asm__("a7") = n;
    26ac:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b0:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    26b4:	2501                	sext.w	a0,a0
    26b6:	8082                	ret

00000000000026b8 <sleep>:

int sleep(unsigned long long time)
{
    26b8:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    26ba:	880a                	mv	a6,sp
{
    26bc:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    26be:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26c2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26c4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c6:	00000073          	ecall
	if (err == 0) {
    26ca:	2501                	sext.w	a0,a0
    26cc:	ed31                	bnez	a0,2728 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    26ce:	6722                	ld	a4,8(sp)
    26d0:	3e800793          	li	a5,1000
    26d4:	6682                	ld	a3,0(sp)
    26d6:	02f75733          	divu	a4,a4,a5
    26da:	02d787b3          	mul	a5,a5,a3
    26de:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    26e0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26e4:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26e6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26e8:	00000073          	ecall
	if (err == 0) {
    26ec:	2501                	sext.w	a0,a0
    26ee:	e915                	bnez	a0,2722 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    26f0:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    26f2:	3e800693          	li	a3,1000
    26f6:	a819                	j	270c <sleep+0x54>
	__asm_syscall("r"(a7))
    26f8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26fc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2700:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2702:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2704:	00000073          	ecall
	if (err == 0) {
    2708:	2501                	sext.w	a0,a0
    270a:	ed01                	bnez	a0,2722 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    270c:	6722                	ld	a4,8(sp)
    270e:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2710:	07c00893          	li	a7,124
    2714:	02d75733          	divu	a4,a4,a3
    2718:	02f687b3          	mul	a5,a3,a5
    271c:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    271e:	fcc7ede3          	bltu	a5,a2,26f8 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2722:	4501                	li	a0,0
    2724:	0141                	addi	sp,sp,16
    2726:	8082                	ret
    2728:	57fd                	li	a5,-1
    272a:	bf5d                	j	26e0 <sleep+0x28>

000000000000272c <sys_task_info>:
	register long a7 __asm__("a7") = n;
    272c:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2730:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2734:	2501                	sext.w	a0,a0
    2736:	8082                	ret

0000000000002738 <set_priority>:
	register long a7 __asm__("a7") = n;
    2738:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    273c:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2740:	2501                	sext.w	a0,a0
    2742:	8082                	ret

0000000000002744 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2744:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2748:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    274c:	2501                	sext.w	a0,a0
    274e:	8082                	ret

0000000000002750 <munmap>:
	register long a7 __asm__("a7") = n;
    2750:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2754:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2758:	2501                	sext.w	a0,a0
    275a:	8082                	ret

000000000000275c <wait>:

int wait(int *code)
{
    275c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    275e:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2762:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2764:	00000073          	ecall
	return waitpid(-1, code);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret

000000000000276c <spawn>:
	register long a7 __asm__("a7") = n;
    276c:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2770:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2774:	2501                	sext.w	a0,a0
    2776:	8082                	ret

0000000000002778 <pipe>:
	register long a7 __asm__("a7") = n;
    2778:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    277c:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2780:	2501                	sext.w	a0,a0
    2782:	8082                	ret

0000000000002784 <mailread>:
	register long a7 __asm__("a7") = n;
    2784:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2788:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    278c:	2501                	sext.w	a0,a0
    278e:	8082                	ret

0000000000002790 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2790:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2794:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2798:	2501                	sext.w	a0,a0
    279a:	8082                	ret

000000000000279c <fstat>:
	register long a7 __asm__("a7") = n;
    279c:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27a0:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    27a4:	2501                	sext.w	a0,a0
    27a6:	8082                	ret

00000000000027a8 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    27a8:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    27aa:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    27ae:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27b0:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    27b4:	2501                	sext.w	a0,a0
    27b6:	8082                	ret

00000000000027b8 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    27b8:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    27ba:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    27be:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27c0:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    27c4:	2501                	sext.w	a0,a0
    27c6:	8082                	ret

00000000000027c8 <link>:

int link(char *old_path, char *new_path)
{
    27c8:	87aa                	mv	a5,a0
    27ca:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    27cc:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    27d0:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    27d4:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    27d6:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    27da:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27dc:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    27e0:	2501                	sext.w	a0,a0
    27e2:	8082                	ret

00000000000027e4 <unlink>:

int unlink(char *path)
{
    27e4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27e6:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    27ea:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    27ee:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27f0:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    27f4:	2501                	sext.w	a0,a0
    27f6:	8082                	ret

00000000000027f8 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    27f8:	00000797          	auipc	a5,0x0
    27fc:	4e07b783          	ld	a5,1248(a5) # 2cd8 <_GLOBAL_OFFSET_TABLE_+0x8>
    2800:	439c                	lw	a5,0(a5)
    2802:	c799                	beqz	a5,2810 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2804:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2808:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    280c:	2501                	sext.w	a0,a0
    280e:	8082                	ret
{
    2810:	1101                	addi	sp,sp,-32
    2812:	ec06                	sd	ra,24(sp)
    2814:	e42e                	sd	a1,8(sp)
    2816:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2818:	fe7fe0ef          	jal	ra,17fe <enable_thread_io_buffer>
    281c:	65a2                	ld	a1,8(sp)
    281e:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2820:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2824:	00000073          	ecall
}
    2828:	60e2                	ld	ra,24(sp)
    282a:	2501                	sext.w	a0,a0
    282c:	6105                	addi	sp,sp,32
    282e:	8082                	ret

0000000000002830 <gettid>:
	register long a7 __asm__("a7") = n;
    2830:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2834:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2838:	2501                	sext.w	a0,a0
    283a:	8082                	ret

000000000000283c <waittid>:

int waittid(int tid)
{
    283c:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    283e:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2842:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2846:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2848:	2501                	sext.w	a0,a0
	while (ret == -2) {
    284a:	00e51e63          	bne	a0,a4,2866 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    284e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2852:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2856:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    285a:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    285c:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2860:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2862:	fee506e3          	beq	a0,a4,284e <waittid+0x12>
	}
	return ret;
}
    2866:	8082                	ret

0000000000002868 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2868:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    286c:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    286e:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2872:	2501                	sext.w	a0,a0
    2874:	8082                	ret

0000000000002876 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2876:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    287a:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    287c:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2880:	2501                	sext.w	a0,a0
    2882:	8082                	ret

0000000000002884 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2884:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2888:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    288c:	2501                	sext.w	a0,a0
    288e:	8082                	ret

0000000000002890 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2890:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2894:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2898:	2501                	sext.w	a0,a0
    289a:	8082                	ret

000000000000289c <semaphore_create>:
	register long a7 __asm__("a7") = n;
    289c:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    28a0:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    28a4:	2501                	sext.w	a0,a0
    28a6:	8082                	ret

00000000000028a8 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    28a8:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    28ac:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    28b0:	2501                	sext.w	a0,a0
    28b2:	8082                	ret

00000000000028b4 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    28b4:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    28b8:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    28bc:	2501                	sext.w	a0,a0
    28be:	8082                	ret

00000000000028c0 <condvar_create>:
	register long a7 __asm__("a7") = n;
    28c0:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    28c4:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    28c8:	2501                	sext.w	a0,a0
    28ca:	8082                	ret

00000000000028cc <condvar_signal>:
	register long a7 __asm__("a7") = n;
    28cc:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    28d0:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    28d4:	2501                	sext.w	a0,a0
    28d6:	8082                	ret

00000000000028d8 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    28d8:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28dc:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    28e0:	2501                	sext.w	a0,a0
    28e2:	8082                	ret

00000000000028e4 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    28e4:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    28e8:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    28ec:	2501                	sext.w	a0,a0
    28ee:	8082                	ret
