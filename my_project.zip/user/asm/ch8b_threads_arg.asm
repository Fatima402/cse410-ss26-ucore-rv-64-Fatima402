
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_threads_arg:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	aa09                	j	1112 <__start_main>

0000000000001002 <thread>:
	{ 'b', 2 },
	{ 'c', 3 },
};

void thread(struct thread_arg *arg)
{
    1002:	1101                	addi	sp,sp,-32
    1004:	ec06                	sd	ra,24(sp)
    1006:	e822                	sd	s0,16(sp)
    1008:	e426                	sd	s1,8(sp)
    100a:	84aa                	mv	s1,a0
	printf("thread %d arg: %p\n", gettid(), (uint64)arg);
    100c:	6ac010ef          	jal	ra,26b8 <gettid>
    1010:	85aa                	mv	a1,a0
    1012:	8626                	mv	a2,s1
    1014:	00001517          	auipc	a0,0x1
    1018:	76450513          	addi	a0,a0,1892 # 2778 <enable_deadlock_detect+0xc>
    101c:	250000ef          	jal	ra,126c <printf>
    1020:	3e800413          	li	s0,1000
	for (int i = 0; i < LOOP; ++i) {
		putchar(arg->c);
    1024:	0004c503          	lbu	a0,0(s1)
	for (int i = 0; i < LOOP; ++i) {
    1028:	347d                	addiw	s0,s0,-1
		putchar(arg->c);
    102a:	083000ef          	jal	ra,18ac <putchar>
	for (int i = 0; i < LOOP; ++i) {
    102e:	f87d                	bnez	s0,1024 <thread+0x22>
	}
	exit(arg->ret_code);
}
    1030:	6442                	ld	s0,16(sp)
	exit(arg->ret_code);
    1032:	40c8                	lw	a0,4(s1)
}
    1034:	60e2                	ld	ra,24(sp)
    1036:	64a2                	ld	s1,8(sp)
    1038:	6105                	addi	sp,sp,32
	exit(arg->ret_code);
    103a:	4940106f          	j	24ce <exit>

000000000000103e <main>:

int main(void)
{
    103e:	711d                	addi	sp,sp,-96
    1040:	e4a6                	sd	s1,72(sp)
    1042:	848a                	mv	s1,sp
    1044:	e8a2                	sd	s0,80(sp)
    1046:	e0ca                	sd	s2,64(sp)
    1048:	fc4e                	sd	s3,56(sp)
    104a:	f852                	sd	s4,48(sp)
    104c:	ec86                	sd	ra,88(sp)
    104e:	f456                	sd	s5,40(sp)
    1050:	f05a                	sd	s6,32(sp)
    1052:	ec5e                	sd	s7,24(sp)
    1054:	00002417          	auipc	s0,0x2
    1058:	a1440413          	addi	s0,s0,-1516 # 2a68 <args>
    105c:	00002a17          	auipc	s4,0x2
    1060:	a24a0a13          	addi	s4,s4,-1500 # 2a80 <digits>
    1064:	8926                	mv	s2,s1
	int tids[NTHREAD];
	for (int i = 0; i < NTHREAD; ++i) {
		tids[i] = thread_create(thread, &args[i]);
    1066:	00000997          	auipc	s3,0x0
    106a:	f9c98993          	addi	s3,s3,-100 # 1002 <thread>
    106e:	85a2                	mv	a1,s0
    1070:	854e                	mv	a0,s3
    1072:	60e010ef          	jal	ra,2680 <thread_create>
    1076:	00a92023          	sw	a0,0(s2)
	for (int i = 0; i < NTHREAD; ++i) {
    107a:	0421                	addi	s0,s0,8
    107c:	0911                	addi	s2,s2,4
    107e:	ff4418e3          	bne	s0,s4,106e <main+0x30>
    1082:	00c48a13          	addi	s4,s1,12
	}
	for (int i = 0; i < NTHREAD; ++i) {
		int tid = tids[i];
		int exit_code = waittid(tid);
		printf("thread %d exited with code %d\n", tid, exit_code);
    1086:	00001997          	auipc	s3,0x1
    108a:	70a98993          	addi	s3,s3,1802 # 2790 <enable_deadlock_detect+0x24>
		assert_eq(tid, exit_code);
    108e:	00001b97          	auipc	s7,0x1
    1092:	722b8b93          	addi	s7,s7,1826 # 27b0 <enable_deadlock_detect+0x44>
    1096:	00001b17          	auipc	s6,0x1
    109a:	76ab0b13          	addi	s6,s6,1898 # 2800 <enable_deadlock_detect+0x94>
    109e:	00001a97          	auipc	s5,0x1
    10a2:	76aa8a93          	addi	s5,s5,1898 # 2808 <enable_deadlock_detect+0x9c>
		int tid = tids[i];
    10a6:	0004a903          	lw	s2,0(s1)
	for (int i = 0; i < NTHREAD; ++i) {
    10aa:	0491                	addi	s1,s1,4
		int exit_code = waittid(tid);
    10ac:	854a                	mv	a0,s2
    10ae:	616010ef          	jal	ra,26c4 <waittid>
    10b2:	842a                	mv	s0,a0
		printf("thread %d exited with code %d\n", tid, exit_code);
    10b4:	862a                	mv	a2,a0
    10b6:	85ca                	mv	a1,s2
    10b8:	854e                	mv	a0,s3
    10ba:	1b2000ef          	jal	ra,126c <printf>
		assert_eq(tid, exit_code);
    10be:	02890663          	beq	s2,s0,10ea <main+0xac>
    10c2:	3dc010ef          	jal	ra,249e <getpid>
    10c6:	892a                	mv	s2,a0
    10c8:	855e                	mv	a0,s7
    10ca:	2aa010ef          	jal	ra,2374 <basename>
    10ce:	872a                	mv	a4,a0
    10d0:	88a2                	mv	a7,s0
    10d2:	8556                	mv	a0,s5
    10d4:	884a                	mv	a6,s2
    10d6:	02400793          	li	a5,36
    10da:	86ca                	mv	a3,s2
    10dc:	865a                	mv	a2,s6
    10de:	45fd                	li	a1,31
    10e0:	18c000ef          	jal	ra,126c <printf>
    10e4:	557d                	li	a0,-1
    10e6:	3e8010ef          	jal	ra,24ce <exit>
	for (int i = 0; i < NTHREAD; ++i) {
    10ea:	fb449ee3          	bne	s1,s4,10a6 <main+0x68>
	}
	puts("threads with arg test passed!");
    10ee:	00001517          	auipc	a0,0x1
    10f2:	75250513          	addi	a0,a0,1874 # 2840 <enable_deadlock_detect+0xd4>
    10f6:	08d000ef          	jal	ra,1982 <puts>
	return 0;
    10fa:	60e6                	ld	ra,88(sp)
    10fc:	6446                	ld	s0,80(sp)
    10fe:	64a6                	ld	s1,72(sp)
    1100:	6906                	ld	s2,64(sp)
    1102:	79e2                	ld	s3,56(sp)
    1104:	7a42                	ld	s4,48(sp)
    1106:	7aa2                	ld	s5,40(sp)
    1108:	7b02                	ld	s6,32(sp)
    110a:	6be2                	ld	s7,24(sp)
    110c:	4501                	li	a0,0
    110e:	6125                	addi	sp,sp,96
    1110:	8082                	ret

0000000000001112 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1112:	1141                	addi	sp,sp,-16
    1114:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1116:	f29ff0ef          	jal	ra,103e <main>
    111a:	3b4010ef          	jal	ra,24ce <exit>
	return 0;
    111e:	60a2                	ld	ra,8(sp)
    1120:	4501                	li	a0,0
    1122:	0141                	addi	sp,sp,16
    1124:	8082                	ret

0000000000001126 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1126:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1128:	4605                	li	a2,1
    112a:	00f10593          	addi	a1,sp,15
    112e:	4501                	li	a0,0
{
    1130:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1132:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1136:	354010ef          	jal	ra,248a <read>
    113a:	4785                	li	a5,1
    113c:	00f51763          	bne	a0,a5,114a <getchar+0x24>
		return byte;
    1140:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1144:	60e2                	ld	ra,24(sp)
    1146:	6105                	addi	sp,sp,32
    1148:	8082                	ret
		return EOF;
    114a:	557d                	li	a0,-1
    114c:	bfe5                	j	1144 <getchar+0x1e>

000000000000114e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    114e:	00002517          	auipc	a0,0x2
    1152:	80a52503          	lw	a0,-2038(a0) # 2958 <buffer_len>
    1156:	e111                	bnez	a0,115a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1158:	8082                	ret
{
    115a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    115c:	862a                	mv	a2,a0
    115e:	00002597          	auipc	a1,0x2
    1162:	80258593          	addi	a1,a1,-2046 # 2960 <buffer>
    1166:	4505                	li	a0,1
{
    1168:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    116a:	32a010ef          	jal	ra,2494 <write>
}
    116e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1170:	2501                	sext.w	a0,a0
}
    1172:	0141                	addi	sp,sp,16
    1174:	8082                	ret

0000000000001176 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1176:	00001797          	auipc	a5,0x1
    117a:	7e07a123          	sw	zero,2018(a5) # 2958 <buffer_len>
}
    117e:	8082                	ret

0000000000001180 <__fflush>:
	if (buffer_len == 0)
    1180:	00001517          	auipc	a0,0x1
    1184:	7d852503          	lw	a0,2008(a0) # 2958 <buffer_len>
    1188:	e511                	bnez	a0,1194 <__fflush+0x14>
	buffer_len = 0;
    118a:	00001797          	auipc	a5,0x1
    118e:	7c07a723          	sw	zero,1998(a5) # 2958 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1192:	8082                	ret
{
    1194:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1196:	862a                	mv	a2,a0
    1198:	00001597          	auipc	a1,0x1
    119c:	7c858593          	addi	a1,a1,1992 # 2960 <buffer>
    11a0:	4505                	li	a0,1
{
    11a2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11a4:	2f0010ef          	jal	ra,2494 <write>
	return r >= 0 ? 0 : r;
    11a8:	0005079b          	sext.w	a5,a0
}
    11ac:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11ae:	0017a793          	slti	a5,a5,1
    11b2:	40f007bb          	negw	a5,a5
    11b6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11b8:	00001797          	auipc	a5,0x1
    11bc:	7a07a023          	sw	zero,1952(a5) # 2958 <buffer_len>
	return r >= 0 ? 0 : r;
    11c0:	2501                	sext.w	a0,a0
}
    11c2:	0141                	addi	sp,sp,16
    11c4:	8082                	ret

00000000000011c6 <fflush>:

int fflush(int fd)
{
    11c6:	1101                	addi	sp,sp,-32
    11c8:	e822                	sd	s0,16(sp)
    11ca:	ec06                	sd	ra,24(sp)
    11cc:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11ce:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    11d0:	4401                	li	s0,0
	if (fd == 1) {
    11d2:	00e50863          	beq	a0,a4,11e2 <fflush+0x1c>
}
    11d6:	60e2                	ld	ra,24(sp)
    11d8:	8522                	mv	a0,s0
    11da:	6442                	ld	s0,16(sp)
    11dc:	64a2                	ld	s1,8(sp)
    11de:	6105                	addi	sp,sp,32
    11e0:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11e2:	00001497          	auipc	s1,0x1
    11e6:	77648493          	addi	s1,s1,1910 # 2958 <buffer_len>
    11ea:	1084a703          	lw	a4,264(s1)
    11ee:	02a70e63          	beq	a4,a0,122a <fflush+0x64>
	if (buffer_len == 0)
    11f2:	4080                	lw	s0,0(s1)
    11f4:	c00d                	beqz	s0,1216 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11f6:	8622                	mv	a2,s0
    11f8:	00001597          	auipc	a1,0x1
    11fc:	76858593          	addi	a1,a1,1896 # 2960 <buffer>
    1200:	294010ef          	jal	ra,2494 <write>
	return r >= 0 ? 0 : r;
    1204:	0005079b          	sext.w	a5,a0
    1208:	0017a793          	slti	a5,a5,1
    120c:	40f007bb          	negw	a5,a5
    1210:	8d7d                	and	a0,a0,a5
    1212:	0005041b          	sext.w	s0,a0
}
    1216:	60e2                	ld	ra,24(sp)
    1218:	8522                	mv	a0,s0
    121a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    121c:	00001797          	auipc	a5,0x1
    1220:	7207ae23          	sw	zero,1852(a5) # 2958 <buffer_len>
}
    1224:	64a2                	ld	s1,8(sp)
    1226:	6105                	addi	sp,sp,32
    1228:	8082                	ret
			mutex_lock(buffer_lock);
    122a:	10c4a503          	lw	a0,268(s1)
    122e:	4de010ef          	jal	ra,270c <mutex_lock>
	if (buffer_len == 0)
    1232:	4080                	lw	s0,0(s1)
    1234:	e811                	bnez	s0,1248 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1236:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    123a:	00001797          	auipc	a5,0x1
    123e:	7007af23          	sw	zero,1822(a5) # 2958 <buffer_len>
			mutex_unlock(buffer_lock);
    1242:	4d6010ef          	jal	ra,2718 <mutex_unlock>
    1246:	bf41                	j	11d6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1248:	8622                	mv	a2,s0
    124a:	00001597          	auipc	a1,0x1
    124e:	71658593          	addi	a1,a1,1814 # 2960 <buffer>
    1252:	4505                	li	a0,1
    1254:	240010ef          	jal	ra,2494 <write>
	return r >= 0 ? 0 : r;
    1258:	0005079b          	sext.w	a5,a0
    125c:	0017a793          	slti	a5,a5,1
    1260:	40f007bb          	negw	a5,a5
    1264:	8d7d                	and	a0,a0,a5
    1266:	0005041b          	sext.w	s0,a0
	return r;
    126a:	b7f1                	j	1236 <fflush+0x70>

000000000000126c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    126c:	7131                	addi	sp,sp,-192
    126e:	e0da                	sd	s6,64(sp)
    1270:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1272:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1274:	013c                	addi	a5,sp,136
{
    1276:	f0ca                	sd	s2,96(sp)
    1278:	ecce                	sd	s3,88(sp)
    127a:	e8d2                	sd	s4,80(sp)
    127c:	e4d6                	sd	s5,72(sp)
    127e:	fc86                	sd	ra,120(sp)
    1280:	f8a2                	sd	s0,112(sp)
    1282:	f4a6                	sd	s1,104(sp)
    1284:	89aa                	mv	s3,a0
    1286:	e52e                	sd	a1,136(sp)
    1288:	e932                	sd	a2,144(sp)
    128a:	ed36                	sd	a3,152(sp)
    128c:	f13a                	sd	a4,160(sp)
    128e:	f942                	sd	a6,176(sp)
    1290:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1292:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1294:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1298:	00001a17          	auipc	s4,0x1
    129c:	6c0a0a13          	addi	s4,s4,1728 # 2958 <buffer_len>
    12a0:	4a85                	li	s5,1
	buf[i++] = '0';
    12a2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12a6:	0009c783          	lbu	a5,0(s3)
    12aa:	18078663          	beqz	a5,1436 <printf+0x1ca>
    12ae:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12b0:	19278d63          	beq	a5,s2,144a <printf+0x1de>
    12b4:	0015c783          	lbu	a5,1(a1)
    12b8:	0585                	addi	a1,a1,1
    12ba:	fbfd                	bnez	a5,12b0 <printf+0x44>
    12bc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12be:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12c2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12c6:	1b578863          	beq	a5,s5,1476 <printf+0x20a>
		len = out_unlocked(s, l);
    12ca:	85a2                	mv	a1,s0
    12cc:	854e                	mv	a0,s3
    12ce:	42a000ef          	jal	ra,16f8 <out_unlocked>
		out(f, a, l);
		if (l)
    12d2:	1c041063          	bnez	s0,1492 <printf+0x226>
			continue;
		if (s[1] == 0)
    12d6:	0014c783          	lbu	a5,1(s1)
    12da:	14078e63          	beqz	a5,1436 <printf+0x1ca>
			break;
		switch (s[1]) {
    12de:	07300713          	li	a4,115
    12e2:	1ce78863          	beq	a5,a4,14b2 <printf+0x246>
    12e6:	1af76863          	bltu	a4,a5,1496 <printf+0x22a>
    12ea:	06400713          	li	a4,100
    12ee:	22e78063          	beq	a5,a4,150e <printf+0x2a2>
    12f2:	07000713          	li	a4,112
    12f6:	1ee79563          	bne	a5,a4,14e0 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12fa:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12fc:	00001797          	auipc	a5,0x1
    1300:	78478793          	addi	a5,a5,1924 # 2a80 <digits>
	buf[i++] = '0';
    1304:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1308:	6298                	ld	a4,0(a3)
    130a:	06a1                	addi	a3,a3,8
    130c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    130e:	00471393          	slli	t2,a4,0x4
    1312:	00871293          	slli	t0,a4,0x8
    1316:	00c71f93          	slli	t6,a4,0xc
    131a:	01071f13          	slli	t5,a4,0x10
    131e:	01471e93          	slli	t4,a4,0x14
    1322:	01871e13          	slli	t3,a4,0x18
    1326:	01c71893          	slli	a7,a4,0x1c
    132a:	02471813          	slli	a6,a4,0x24
    132e:	02871513          	slli	a0,a4,0x28
    1332:	02c71593          	slli	a1,a4,0x2c
    1336:	03071613          	slli	a2,a4,0x30
    133a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    133e:	03c75413          	srli	s0,a4,0x3c
    1342:	01c7531b          	srliw	t1,a4,0x1c
    1346:	03c3d393          	srli	t2,t2,0x3c
    134a:	03c2d293          	srli	t0,t0,0x3c
    134e:	03cfdf93          	srli	t6,t6,0x3c
    1352:	03cf5f13          	srli	t5,t5,0x3c
    1356:	03cede93          	srli	t4,t4,0x3c
    135a:	03ce5e13          	srli	t3,t3,0x3c
    135e:	03c8d893          	srli	a7,a7,0x3c
    1362:	03c85813          	srli	a6,a6,0x3c
    1366:	9171                	srli	a0,a0,0x3c
    1368:	91f1                	srli	a1,a1,0x3c
    136a:	9271                	srli	a2,a2,0x3c
    136c:	92f1                	srli	a3,a3,0x3c
    136e:	95be                	add	a1,a1,a5
    1370:	963e                	add	a2,a2,a5
    1372:	96be                	add	a3,a3,a5
    1374:	943e                	add	s0,s0,a5
    1376:	93be                	add	t2,t2,a5
    1378:	92be                	add	t0,t0,a5
    137a:	9fbe                	add	t6,t6,a5
    137c:	9f3e                	add	t5,t5,a5
    137e:	9ebe                	add	t4,t4,a5
    1380:	9e3e                	add	t3,t3,a5
    1382:	98be                	add	a7,a7,a5
    1384:	933e                	add	t1,t1,a5
    1386:	983e                	add	a6,a6,a5
    1388:	953e                	add	a0,a0,a5
    138a:	0005c983          	lbu	s3,0(a1)
    138e:	00044403          	lbu	s0,0(s0)
    1392:	00064583          	lbu	a1,0(a2)
    1396:	0003c383          	lbu	t2,0(t2)
    139a:	0006c603          	lbu	a2,0(a3)
    139e:	0002c283          	lbu	t0,0(t0)
    13a2:	000fcf83          	lbu	t6,0(t6)
    13a6:	000f4f03          	lbu	t5,0(t5)
    13aa:	000ece83          	lbu	t4,0(t4)
    13ae:	000e4e03          	lbu	t3,0(t3)
    13b2:	0008c883          	lbu	a7,0(a7)
    13b6:	00034303          	lbu	t1,0(t1)
    13ba:	00084803          	lbu	a6,0(a6)
    13be:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13c2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13c6:	92f1                	srli	a3,a3,0x3c
    13c8:	8b3d                	andi	a4,a4,15
    13ca:	96be                	add	a3,a3,a5
    13cc:	97ba                	add	a5,a5,a4
    13ce:	00810d23          	sb	s0,26(sp)
    13d2:	00710da3          	sb	t2,27(sp)
    13d6:	00510e23          	sb	t0,28(sp)
    13da:	01f10ea3          	sb	t6,29(sp)
    13de:	01e10f23          	sb	t5,30(sp)
    13e2:	01d10fa3          	sb	t4,31(sp)
    13e6:	03c10023          	sb	t3,32(sp)
    13ea:	031100a3          	sb	a7,33(sp)
    13ee:	02610123          	sb	t1,34(sp)
    13f2:	030101a3          	sb	a6,35(sp)
    13f6:	02a10223          	sb	a0,36(sp)
    13fa:	033102a3          	sb	s3,37(sp)
    13fe:	02b10323          	sb	a1,38(sp)
    1402:	02c103a3          	sb	a2,39(sp)
    1406:	0006c683          	lbu	a3,0(a3)
    140a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    140e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1412:	02d10423          	sb	a3,40(sp)
    1416:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    141a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    141e:	11578263          	beq	a5,s5,1522 <printf+0x2b6>
		len = out_unlocked(s, l);
    1422:	45c9                	li	a1,18
    1424:	0828                	addi	a0,sp,24
    1426:	2d2000ef          	jal	ra,16f8 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    142a:	00248993          	addi	s3,s1,2
		if (!*s)
    142e:	0009c783          	lbu	a5,0(s3)
    1432:	e6079ee3          	bnez	a5,12ae <printf+0x42>
	}
	va_end(ap);
    1436:	70e6                	ld	ra,120(sp)
    1438:	7446                	ld	s0,112(sp)
    143a:	74a6                	ld	s1,104(sp)
    143c:	7906                	ld	s2,96(sp)
    143e:	69e6                	ld	s3,88(sp)
    1440:	6a46                	ld	s4,80(sp)
    1442:	6aa6                	ld	s5,72(sp)
    1444:	6b06                	ld	s6,64(sp)
    1446:	6129                	addi	sp,sp,192
    1448:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    144a:	0005c783          	lbu	a5,0(a1)
    144e:	84ae                	mv	s1,a1
    1450:	01278963          	beq	a5,s2,1462 <printf+0x1f6>
    1454:	b5ad                	j	12be <printf+0x52>
    1456:	0024c783          	lbu	a5,2(s1)
    145a:	0585                	addi	a1,a1,1
    145c:	0489                	addi	s1,s1,2
    145e:	e72790e3          	bne	a5,s2,12be <printf+0x52>
    1462:	0014c783          	lbu	a5,1(s1)
    1466:	ff2788e3          	beq	a5,s2,1456 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    146a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    146e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1472:	e5579ce3          	bne	a5,s5,12ca <printf+0x5e>
		mutex_lock(buffer_lock);
    1476:	10ca2503          	lw	a0,268(s4)
    147a:	292010ef          	jal	ra,270c <mutex_lock>
		len = out_unlocked(s, l);
    147e:	85a2                	mv	a1,s0
    1480:	854e                	mv	a0,s3
    1482:	276000ef          	jal	ra,16f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1486:	10ca2503          	lw	a0,268(s4)
    148a:	28e010ef          	jal	ra,2718 <mutex_unlock>
		if (l)
    148e:	e40404e3          	beqz	s0,12d6 <printf+0x6a>
    1492:	89a6                	mv	s3,s1
    1494:	bd09                	j	12a6 <printf+0x3a>
		switch (s[1]) {
    1496:	07800713          	li	a4,120
    149a:	04e79363          	bne	a5,a4,14e0 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    149e:	67c2                	ld	a5,16(sp)
    14a0:	45c1                	li	a1,16
		s += 2;
    14a2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14a6:	4388                	lw	a0,0(a5)
    14a8:	07a1                	addi	a5,a5,8
    14aa:	e83e                	sd	a5,16(sp)
    14ac:	5f8000ef          	jal	ra,1aa4 <printint.constprop.0>
		s += 2;
    14b0:	bfbd                	j	142e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14b2:	67c2                	ld	a5,16(sp)
    14b4:	6380                	ld	s0,0(a5)
    14b6:	07a1                	addi	a5,a5,8
    14b8:	e83e                	sd	a5,16(sp)
    14ba:	1c040163          	beqz	s0,167c <printf+0x410>
			l = strnlen(a, 200);
    14be:	0c800593          	li	a1,200
    14c2:	8522                	mv	a0,s0
    14c4:	3f7000ef          	jal	ra,20ba <strnlen>
	if (buffer_lock_enabled == 1) {
    14c8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14cc:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    14d0:	19578663          	beq	a5,s5,165c <printf+0x3f0>
		len = out_unlocked(s, l);
    14d4:	8522                	mv	a0,s0
    14d6:	222000ef          	jal	ra,16f8 <out_unlocked>
		s += 2;
    14da:	00248993          	addi	s3,s1,2
    14de:	bf81                	j	142e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    14e0:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14e4:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14e8:	0f578663          	beq	a5,s5,15d4 <printf+0x368>
		len = out_unlocked(s, l);
    14ec:	0828                	addi	a0,sp,24
    14ee:	316000ef          	jal	ra,1804 <out_unlocked.constprop.0>
			putchar(s[1]);
    14f2:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14f6:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14fa:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14fe:	05578163          	beq	a5,s5,1540 <printf+0x2d4>
		len = out_unlocked(s, l);
    1502:	0828                	addi	a0,sp,24
    1504:	300000ef          	jal	ra,1804 <out_unlocked.constprop.0>
		s += 2;
    1508:	00248993          	addi	s3,s1,2
    150c:	b70d                	j	142e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    150e:	67c2                	ld	a5,16(sp)
    1510:	45a9                	li	a1,10
		s += 2;
    1512:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1516:	4388                	lw	a0,0(a5)
    1518:	07a1                	addi	a5,a5,8
    151a:	e83e                	sd	a5,16(sp)
    151c:	588000ef          	jal	ra,1aa4 <printint.constprop.0>
		s += 2;
    1520:	b739                	j	142e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1522:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1526:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    152a:	1e2010ef          	jal	ra,270c <mutex_lock>
		len = out_unlocked(s, l);
    152e:	45c9                	li	a1,18
    1530:	0828                	addi	a0,sp,24
    1532:	1c6000ef          	jal	ra,16f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1536:	10ca2503          	lw	a0,268(s4)
    153a:	1de010ef          	jal	ra,2718 <mutex_unlock>
		s += 2;
    153e:	bdc5                	j	142e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1540:	10ca2503          	lw	a0,268(s4)
    1544:	1c8010ef          	jal	ra,270c <mutex_lock>
		buffer[buffer_len++] = c;
    1548:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    154c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1550:	0017861b          	addiw	a2,a5,1
    1554:	97d2                	add	a5,a5,s4
    1556:	00ca2023          	sw	a2,0(s4)
    155a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    155e:	00c6cc63          	blt	a3,a2,1576 <printf+0x30a>
    1562:	47a9                	li	a5,10
    1564:	06f40663          	beq	s0,a5,15d0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1568:	10ca2503          	lw	a0,268(s4)
		s += 2;
    156c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1570:	1a8010ef          	jal	ra,2718 <mutex_unlock>
		s += 2;
    1574:	bd6d                	j	142e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1576:	10000793          	li	a5,256
    157a:	00f61e63          	bne	a2,a5,1596 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    157e:	00001597          	auipc	a1,0x1
    1582:	3e258593          	addi	a1,a1,994 # 2960 <buffer>
    1586:	4505                	li	a0,1
    1588:	70d000ef          	jal	ra,2494 <write>
	buffer_len = 0;
    158c:	00001797          	auipc	a5,0x1
    1590:	3c07a623          	sw	zero,972(a5) # 2958 <buffer_len>
			if (r < 0) {
    1594:	bfd1                	j	1568 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1596:	709000ef          	jal	ra,249e <getpid>
    159a:	842a                	mv	s0,a0
    159c:	00001517          	auipc	a0,0x1
    15a0:	2cc50513          	addi	a0,a0,716 # 2868 <enable_deadlock_detect+0xfc>
    15a4:	5d1000ef          	jal	ra,2374 <basename>
    15a8:	872a                	mv	a4,a0
    15aa:	00001617          	auipc	a2,0x1
    15ae:	25660613          	addi	a2,a2,598 # 2800 <enable_deadlock_detect+0x94>
    15b2:	05400793          	li	a5,84
    15b6:	86a2                	mv	a3,s0
    15b8:	45fd                	li	a1,31
    15ba:	00001517          	auipc	a0,0x1
    15be:	2ee50513          	addi	a0,a0,750 # 28a8 <enable_deadlock_detect+0x13c>
    15c2:	cabff0ef          	jal	ra,126c <printf>
    15c6:	557d                	li	a0,-1
    15c8:	707000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    15cc:	000a2603          	lw	a2,0(s4)
    15d0:	de41                	beqz	a2,1568 <printf+0x2fc>
    15d2:	b775                	j	157e <printf+0x312>
		mutex_lock(buffer_lock);
    15d4:	10ca2503          	lw	a0,268(s4)
    15d8:	134010ef          	jal	ra,270c <mutex_lock>
		buffer[buffer_len++] = c;
    15dc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15e0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15e4:	0017861b          	addiw	a2,a5,1
    15e8:	97d2                	add	a5,a5,s4
    15ea:	00ca2023          	sw	a2,0(s4)
    15ee:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15f2:	02c6d163          	bge	a3,a2,1614 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15f6:	10000793          	li	a5,256
    15fa:	02f61263          	bne	a2,a5,161e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15fe:	00001597          	auipc	a1,0x1
    1602:	36258593          	addi	a1,a1,866 # 2960 <buffer>
    1606:	4505                	li	a0,1
    1608:	68d000ef          	jal	ra,2494 <write>
	buffer_len = 0;
    160c:	00001797          	auipc	a5,0x1
    1610:	3407a623          	sw	zero,844(a5) # 2958 <buffer_len>
		mutex_unlock(buffer_lock);
    1614:	10ca2503          	lw	a0,268(s4)
    1618:	100010ef          	jal	ra,2718 <mutex_unlock>
    161c:	bdd9                	j	14f2 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    161e:	681000ef          	jal	ra,249e <getpid>
    1622:	842a                	mv	s0,a0
    1624:	00001517          	auipc	a0,0x1
    1628:	24450513          	addi	a0,a0,580 # 2868 <enable_deadlock_detect+0xfc>
    162c:	549000ef          	jal	ra,2374 <basename>
    1630:	872a                	mv	a4,a0
    1632:	00001617          	auipc	a2,0x1
    1636:	1ce60613          	addi	a2,a2,462 # 2800 <enable_deadlock_detect+0x94>
    163a:	05400793          	li	a5,84
    163e:	86a2                	mv	a3,s0
    1640:	45fd                	li	a1,31
    1642:	00001517          	auipc	a0,0x1
    1646:	26650513          	addi	a0,a0,614 # 28a8 <enable_deadlock_detect+0x13c>
    164a:	c23ff0ef          	jal	ra,126c <printf>
    164e:	557d                	li	a0,-1
    1650:	67f000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    1654:	000a2603          	lw	a2,0(s4)
    1658:	de55                	beqz	a2,1614 <printf+0x3a8>
    165a:	b755                	j	15fe <printf+0x392>
		mutex_lock(buffer_lock);
    165c:	10ca2503          	lw	a0,268(s4)
    1660:	e42e                	sd	a1,8(sp)
		s += 2;
    1662:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1666:	0a6010ef          	jal	ra,270c <mutex_lock>
		len = out_unlocked(s, l);
    166a:	65a2                	ld	a1,8(sp)
    166c:	8522                	mv	a0,s0
    166e:	08a000ef          	jal	ra,16f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1672:	10ca2503          	lw	a0,268(s4)
    1676:	0a2010ef          	jal	ra,2718 <mutex_unlock>
		s += 2;
    167a:	bb55                	j	142e <printf+0x1c2>
				a = "(null)";
    167c:	00001417          	auipc	s0,0x1
    1680:	1e440413          	addi	s0,s0,484 # 2860 <enable_deadlock_detect+0xf4>
    1684:	bd2d                	j	14be <printf+0x252>

0000000000001686 <enable_thread_io_buffer>:
{
    1686:	1101                	addi	sp,sp,-32
    1688:	e822                	sd	s0,16(sp)
    168a:	ec06                	sd	ra,24(sp)
    168c:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    168e:	00001417          	auipc	s0,0x1
    1692:	2ca40413          	addi	s0,s0,714 # 2958 <buffer_len>
    1696:	05a010ef          	jal	ra,26f0 <mutex_create>
    169a:	10a42623          	sw	a0,268(s0)
    169e:	00054a63          	bltz	a0,16b2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16a2:	4785                	li	a5,1
}
    16a4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16a6:	10f42423          	sw	a5,264(s0)
}
    16aa:	6442                	ld	s0,16(sp)
    16ac:	64a2                	ld	s1,8(sp)
    16ae:	6105                	addi	sp,sp,32
    16b0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16b2:	5ed000ef          	jal	ra,249e <getpid>
    16b6:	84aa                	mv	s1,a0
    16b8:	00001517          	auipc	a0,0x1
    16bc:	1b050513          	addi	a0,a0,432 # 2868 <enable_deadlock_detect+0xfc>
    16c0:	4b5000ef          	jal	ra,2374 <basename>
    16c4:	872a                	mv	a4,a0
    16c6:	04800793          	li	a5,72
    16ca:	86a6                	mv	a3,s1
    16cc:	00001517          	auipc	a0,0x1
    16d0:	21c50513          	addi	a0,a0,540 # 28e8 <enable_deadlock_detect+0x17c>
    16d4:	00001617          	auipc	a2,0x1
    16d8:	12c60613          	addi	a2,a2,300 # 2800 <enable_deadlock_detect+0x94>
    16dc:	45fd                	li	a1,31
    16de:	b8fff0ef          	jal	ra,126c <printf>
    16e2:	557d                	li	a0,-1
    16e4:	5eb000ef          	jal	ra,24ce <exit>
	buffer_lock_enabled = 1;
    16e8:	4785                	li	a5,1
}
    16ea:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16ec:	10f42423          	sw	a5,264(s0)
}
    16f0:	6442                	ld	s0,16(sp)
    16f2:	64a2                	ld	s1,8(sp)
    16f4:	6105                	addi	sp,sp,32
    16f6:	8082                	ret

00000000000016f8 <out_unlocked>:
{
    16f8:	7159                	addi	sp,sp,-112
    16fa:	f486                	sd	ra,104(sp)
    16fc:	f0a2                	sd	s0,96(sp)
    16fe:	eca6                	sd	s1,88(sp)
    1700:	e8ca                	sd	s2,80(sp)
    1702:	e4ce                	sd	s3,72(sp)
    1704:	e0d2                	sd	s4,64(sp)
    1706:	fc56                	sd	s5,56(sp)
    1708:	f85a                	sd	s6,48(sp)
    170a:	f45e                	sd	s7,40(sp)
    170c:	f062                	sd	s8,32(sp)
    170e:	ec66                	sd	s9,24(sp)
    1710:	e86a                	sd	s10,16(sp)
    1712:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1714:	0e058663          	beqz	a1,1800 <out_unlocked+0x108>
    1718:	842a                	mv	s0,a0
    171a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    171e:	4981                	li	s3,0
    1720:	00001d17          	auipc	s10,0x1
    1724:	238d0d13          	addi	s10,s10,568 # 2958 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1728:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    172c:	00001b17          	auipc	s6,0x1
    1730:	234b0b13          	addi	s6,s6,564 # 2960 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1734:	10000a93          	li	s5,256
    1738:	00001c97          	auipc	s9,0x1
    173c:	130c8c93          	addi	s9,s9,304 # 2868 <enable_deadlock_detect+0xfc>
    1740:	00001c17          	auipc	s8,0x1
    1744:	0c0c0c13          	addi	s8,s8,192 # 2800 <enable_deadlock_detect+0x94>
    1748:	00001b97          	auipc	s7,0x1
    174c:	160b8b93          	addi	s7,s7,352 # 28a8 <enable_deadlock_detect+0x13c>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1750:	4a29                	li	s4,10
    1752:	a031                	j	175e <out_unlocked+0x66>
    1754:	09468863          	beq	a3,s4,17e4 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1758:	0405                	addi	s0,s0,1
    175a:	04848163          	beq	s1,s0,179c <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    175e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1762:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1766:	0017861b          	addiw	a2,a5,1
    176a:	97ea                	add	a5,a5,s10
    176c:	00cd2023          	sw	a2,0(s10)
    1770:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1774:	fec950e3          	bge	s2,a2,1754 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1778:	05561263          	bne	a2,s5,17bc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    177c:	85da                	mv	a1,s6
    177e:	4505                	li	a0,1
    1780:	515000ef          	jal	ra,2494 <write>
    1784:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1786:	00001797          	auipc	a5,0x1
    178a:	1c07a923          	sw	zero,466(a5) # 2958 <buffer_len>
			if (r < 0) {
    178e:	06054763          	bltz	a0,17fc <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1792:	0405                	addi	s0,s0,1
			ret += r;
    1794:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1798:	fc8493e3          	bne	s1,s0,175e <out_unlocked+0x66>
}
    179c:	70a6                	ld	ra,104(sp)
    179e:	7406                	ld	s0,96(sp)
    17a0:	64e6                	ld	s1,88(sp)
    17a2:	6946                	ld	s2,80(sp)
    17a4:	6a06                	ld	s4,64(sp)
    17a6:	7ae2                	ld	s5,56(sp)
    17a8:	7b42                	ld	s6,48(sp)
    17aa:	7ba2                	ld	s7,40(sp)
    17ac:	7c02                	ld	s8,32(sp)
    17ae:	6ce2                	ld	s9,24(sp)
    17b0:	6d42                	ld	s10,16(sp)
    17b2:	6da2                	ld	s11,8(sp)
    17b4:	854e                	mv	a0,s3
    17b6:	69a6                	ld	s3,72(sp)
    17b8:	6165                	addi	sp,sp,112
    17ba:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17bc:	4e3000ef          	jal	ra,249e <getpid>
    17c0:	8daa                	mv	s11,a0
    17c2:	8566                	mv	a0,s9
    17c4:	3b1000ef          	jal	ra,2374 <basename>
    17c8:	872a                	mv	a4,a0
    17ca:	8662                	mv	a2,s8
    17cc:	05400793          	li	a5,84
    17d0:	86ee                	mv	a3,s11
    17d2:	45fd                	li	a1,31
    17d4:	855e                	mv	a0,s7
    17d6:	a97ff0ef          	jal	ra,126c <printf>
    17da:	557d                	li	a0,-1
    17dc:	4f3000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    17e0:	000d2603          	lw	a2,0(s10)
    17e4:	da35                	beqz	a2,1758 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17e6:	85da                	mv	a1,s6
    17e8:	4505                	li	a0,1
    17ea:	4ab000ef          	jal	ra,2494 <write>
    17ee:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17f0:	00001797          	auipc	a5,0x1
    17f4:	1607a423          	sw	zero,360(a5) # 2958 <buffer_len>
			if (r < 0) {
    17f8:	f8055de3          	bgez	a0,1792 <out_unlocked+0x9a>
    17fc:	89aa                	mv	s3,a0
    17fe:	bf79                	j	179c <out_unlocked+0xa4>
	int ret = 0;
    1800:	4981                	li	s3,0
    1802:	bf69                	j	179c <out_unlocked+0xa4>

0000000000001804 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1804:	1101                	addi	sp,sp,-32
    1806:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1808:	00001497          	auipc	s1,0x1
    180c:	15048493          	addi	s1,s1,336 # 2958 <buffer_len>
    1810:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1812:	ec06                	sd	ra,24(sp)
    1814:	e822                	sd	s0,16(sp)
		char c = s[i];
    1816:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    181a:	0017861b          	addiw	a2,a5,1
    181e:	97a6                	add	a5,a5,s1
    1820:	00e78423          	sb	a4,8(a5)
    1824:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1826:	0ff00793          	li	a5,255
    182a:	00c7cc63          	blt	a5,a2,1842 <out_unlocked.constprop.0+0x3e>
    182e:	47a9                	li	a5,10
    1830:	06f70c63          	beq	a4,a5,18a8 <out_unlocked.constprop.0+0xa4>
    1834:	4601                	li	a2,0
}
    1836:	60e2                	ld	ra,24(sp)
    1838:	6442                	ld	s0,16(sp)
    183a:	64a2                	ld	s1,8(sp)
    183c:	8532                	mv	a0,a2
    183e:	6105                	addi	sp,sp,32
    1840:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1842:	10000793          	li	a5,256
    1846:	02f61563          	bne	a2,a5,1870 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    184a:	00001597          	auipc	a1,0x1
    184e:	11658593          	addi	a1,a1,278 # 2960 <buffer>
    1852:	4505                	li	a0,1
    1854:	441000ef          	jal	ra,2494 <write>
}
    1858:	60e2                	ld	ra,24(sp)
    185a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    185c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1860:	00001797          	auipc	a5,0x1
    1864:	0e07ac23          	sw	zero,248(a5) # 2958 <buffer_len>
}
    1868:	64a2                	ld	s1,8(sp)
    186a:	8532                	mv	a0,a2
    186c:	6105                	addi	sp,sp,32
    186e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1870:	42f000ef          	jal	ra,249e <getpid>
    1874:	842a                	mv	s0,a0
    1876:	00001517          	auipc	a0,0x1
    187a:	ff250513          	addi	a0,a0,-14 # 2868 <enable_deadlock_detect+0xfc>
    187e:	2f7000ef          	jal	ra,2374 <basename>
    1882:	872a                	mv	a4,a0
    1884:	00001617          	auipc	a2,0x1
    1888:	f7c60613          	addi	a2,a2,-132 # 2800 <enable_deadlock_detect+0x94>
    188c:	05400793          	li	a5,84
    1890:	86a2                	mv	a3,s0
    1892:	45fd                	li	a1,31
    1894:	00001517          	auipc	a0,0x1
    1898:	01450513          	addi	a0,a0,20 # 28a8 <enable_deadlock_detect+0x13c>
    189c:	9d1ff0ef          	jal	ra,126c <printf>
    18a0:	557d                	li	a0,-1
    18a2:	42d000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    18a6:	4090                	lw	a2,0(s1)
    18a8:	d659                	beqz	a2,1836 <out_unlocked.constprop.0+0x32>
    18aa:	b745                	j	184a <out_unlocked.constprop.0+0x46>

00000000000018ac <putchar>:
{
    18ac:	7139                	addi	sp,sp,-64
    18ae:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18b0:	00001497          	auipc	s1,0x1
    18b4:	0a848493          	addi	s1,s1,168 # 2958 <buffer_len>
    18b8:	1084a703          	lw	a4,264(s1)
{
    18bc:	f822                	sd	s0,48(sp)
	char byte = c;
    18be:	0ff57413          	zext.b	s0,a0
{
    18c2:	fc06                	sd	ra,56(sp)
	char byte = c;
    18c4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18c8:	4785                	li	a5,1
    18ca:	00f70d63          	beq	a4,a5,18e4 <putchar+0x38>
		len = out_unlocked(s, l);
    18ce:	01f10513          	addi	a0,sp,31
    18d2:	f33ff0ef          	jal	ra,1804 <out_unlocked.constprop.0>
}
    18d6:	70e2                	ld	ra,56(sp)
    18d8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    18da:	862a                	mv	a2,a0
}
    18dc:	74a2                	ld	s1,40(sp)
    18de:	8532                	mv	a0,a2
    18e0:	6121                	addi	sp,sp,64
    18e2:	8082                	ret
		mutex_lock(buffer_lock);
    18e4:	10c4a503          	lw	a0,268(s1)
    18e8:	625000ef          	jal	ra,270c <mutex_lock>
		buffer[buffer_len++] = c;
    18ec:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ee:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18f2:	0017861b          	addiw	a2,a5,1
    18f6:	97a6                	add	a5,a5,s1
    18f8:	c090                	sw	a2,0(s1)
    18fa:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18fe:	02c6c263          	blt	a3,a2,1922 <putchar+0x76>
    1902:	47a9                	li	a5,10
    1904:	06f40d63          	beq	s0,a5,197e <putchar+0xd2>
    1908:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    190a:	10c4a503          	lw	a0,268(s1)
    190e:	e432                	sd	a2,8(sp)
    1910:	609000ef          	jal	ra,2718 <mutex_unlock>
    1914:	6622                	ld	a2,8(sp)
}
    1916:	70e2                	ld	ra,56(sp)
    1918:	7442                	ld	s0,48(sp)
    191a:	74a2                	ld	s1,40(sp)
    191c:	8532                	mv	a0,a2
    191e:	6121                	addi	sp,sp,64
    1920:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1922:	10000793          	li	a5,256
    1926:	02f61063          	bne	a2,a5,1946 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    192a:	00001597          	auipc	a1,0x1
    192e:	03658593          	addi	a1,a1,54 # 2960 <buffer>
    1932:	4505                	li	a0,1
    1934:	361000ef          	jal	ra,2494 <write>
    1938:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    193c:	00001797          	auipc	a5,0x1
    1940:	0007ae23          	sw	zero,28(a5) # 2958 <buffer_len>
			if (r < 0) {
    1944:	b7d9                	j	190a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1946:	359000ef          	jal	ra,249e <getpid>
    194a:	842a                	mv	s0,a0
    194c:	00001517          	auipc	a0,0x1
    1950:	f1c50513          	addi	a0,a0,-228 # 2868 <enable_deadlock_detect+0xfc>
    1954:	221000ef          	jal	ra,2374 <basename>
    1958:	872a                	mv	a4,a0
    195a:	00001617          	auipc	a2,0x1
    195e:	ea660613          	addi	a2,a2,-346 # 2800 <enable_deadlock_detect+0x94>
    1962:	05400793          	li	a5,84
    1966:	86a2                	mv	a3,s0
    1968:	45fd                	li	a1,31
    196a:	00001517          	auipc	a0,0x1
    196e:	f3e50513          	addi	a0,a0,-194 # 28a8 <enable_deadlock_detect+0x13c>
    1972:	8fbff0ef          	jal	ra,126c <printf>
    1976:	557d                	li	a0,-1
    1978:	357000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    197c:	4090                	lw	a2,0(s1)
    197e:	d651                	beqz	a2,190a <putchar+0x5e>
    1980:	b76d                	j	192a <putchar+0x7e>

0000000000001982 <puts>:
{
    1982:	7139                	addi	sp,sp,-64
    1984:	f822                	sd	s0,48(sp)
    1986:	f426                	sd	s1,40(sp)
    1988:	fc06                	sd	ra,56(sp)
    198a:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    198c:	00001417          	auipc	s0,0x1
    1990:	fcc40413          	addi	s0,s0,-52 # 2958 <buffer_len>
{
    1994:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1996:	638000ef          	jal	ra,1fce <strlen>
	if (buffer_lock_enabled == 1) {
    199a:	10842703          	lw	a4,264(s0)
    199e:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19a0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19a2:	04f70563          	beq	a4,a5,19ec <puts+0x6a>
		len = out_unlocked(s, l);
    19a6:	8526                	mv	a0,s1
    19a8:	d51ff0ef          	jal	ra,16f8 <out_unlocked>
    19ac:	892a                	mv	s2,a0
    19ae:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19b0:	00095963          	bgez	s2,19c2 <puts+0x40>
}
    19b4:	70e2                	ld	ra,56(sp)
    19b6:	7442                	ld	s0,48(sp)
    19b8:	7902                	ld	s2,32(sp)
    19ba:	8526                	mv	a0,s1
    19bc:	74a2                	ld	s1,40(sp)
    19be:	6121                	addi	sp,sp,64
    19c0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19c2:	10842703          	lw	a4,264(s0)
	char byte = c;
    19c6:	44a9                	li	s1,10
    19c8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19cc:	4785                	li	a5,1
    19ce:	02f70e63          	beq	a4,a5,1a0a <puts+0x88>
		len = out_unlocked(s, l);
    19d2:	01f10513          	addi	a0,sp,31
    19d6:	e2fff0ef          	jal	ra,1804 <out_unlocked.constprop.0>
}
    19da:	70e2                	ld	ra,56(sp)
    19dc:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19de:	41f5549b          	sraiw	s1,a0,0x1f
}
    19e2:	7902                	ld	s2,32(sp)
    19e4:	8526                	mv	a0,s1
    19e6:	74a2                	ld	s1,40(sp)
    19e8:	6121                	addi	sp,sp,64
    19ea:	8082                	ret
		mutex_lock(buffer_lock);
    19ec:	e42a                	sd	a0,8(sp)
    19ee:	10c42503          	lw	a0,268(s0)
    19f2:	51b000ef          	jal	ra,270c <mutex_lock>
		len = out_unlocked(s, l);
    19f6:	65a2                	ld	a1,8(sp)
    19f8:	8526                	mv	a0,s1
    19fa:	cffff0ef          	jal	ra,16f8 <out_unlocked>
    19fe:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a00:	10c42503          	lw	a0,268(s0)
    1a04:	515000ef          	jal	ra,2718 <mutex_unlock>
    1a08:	b75d                	j	19ae <puts+0x2c>
		mutex_lock(buffer_lock);
    1a0a:	10c42503          	lw	a0,268(s0)
    1a0e:	4ff000ef          	jal	ra,270c <mutex_lock>
		buffer[buffer_len++] = c;
    1a12:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a14:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a18:	0017861b          	addiw	a2,a5,1
    1a1c:	97a2                	add	a5,a5,s0
    1a1e:	c010                	sw	a2,0(s0)
    1a20:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a24:	06c6dc63          	bge	a3,a2,1a9c <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a28:	10000793          	li	a5,256
    1a2c:	02f61c63          	bne	a2,a5,1a64 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a30:	00001597          	auipc	a1,0x1
    1a34:	f3058593          	addi	a1,a1,-208 # 2960 <buffer>
    1a38:	4505                	li	a0,1
    1a3a:	25b000ef          	jal	ra,2494 <write>
			if (r < 0) {
    1a3e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a40:	00001797          	auipc	a5,0x1
    1a44:	f007ac23          	sw	zero,-232(a5) # 2958 <buffer_len>
			if (r < 0) {
    1a48:	04054c63          	bltz	a0,1aa0 <puts+0x11e>
			if (r < buffer_len) {
    1a4c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a4e:	10c42503          	lw	a0,268(s0)
    1a52:	4c7000ef          	jal	ra,2718 <mutex_unlock>
}
    1a56:	70e2                	ld	ra,56(sp)
    1a58:	7442                	ld	s0,48(sp)
    1a5a:	7902                	ld	s2,32(sp)
    1a5c:	8526                	mv	a0,s1
    1a5e:	74a2                	ld	s1,40(sp)
    1a60:	6121                	addi	sp,sp,64
    1a62:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a64:	23b000ef          	jal	ra,249e <getpid>
    1a68:	84aa                	mv	s1,a0
    1a6a:	00001517          	auipc	a0,0x1
    1a6e:	dfe50513          	addi	a0,a0,-514 # 2868 <enable_deadlock_detect+0xfc>
    1a72:	103000ef          	jal	ra,2374 <basename>
    1a76:	872a                	mv	a4,a0
    1a78:	00001617          	auipc	a2,0x1
    1a7c:	d8860613          	addi	a2,a2,-632 # 2800 <enable_deadlock_detect+0x94>
    1a80:	05400793          	li	a5,84
    1a84:	86a6                	mv	a3,s1
    1a86:	45fd                	li	a1,31
    1a88:	00001517          	auipc	a0,0x1
    1a8c:	e2050513          	addi	a0,a0,-480 # 28a8 <enable_deadlock_detect+0x13c>
    1a90:	fdcff0ef          	jal	ra,126c <printf>
    1a94:	557d                	li	a0,-1
    1a96:	239000ef          	jal	ra,24ce <exit>
	if (buffer_len == 0)
    1a9a:	4010                	lw	a2,0(s0)
    1a9c:	da45                	beqz	a2,1a4c <puts+0xca>
    1a9e:	bf49                	j	1a30 <puts+0xae>
    1aa0:	54fd                	li	s1,-1
    1aa2:	b775                	j	1a4e <puts+0xcc>

0000000000001aa4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1aa4:	715d                	addi	sp,sp,-80
    1aa6:	e486                	sd	ra,72(sp)
    1aa8:	e0a2                	sd	s0,64(sp)
    1aaa:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1aac:	14054363          	bltz	a0,1bf2 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ab0:	02b577bb          	remuw	a5,a0,a1
    1ab4:	00001617          	auipc	a2,0x1
    1ab8:	fcc60613          	addi	a2,a2,-52 # 2a80 <digits>
	buf[16] = 0;
    1abc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ac0:	0005871b          	sext.w	a4,a1
    1ac4:	1782                	slli	a5,a5,0x20
    1ac6:	9381                	srli	a5,a5,0x20
    1ac8:	97b2                	add	a5,a5,a2
    1aca:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ace:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ad2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ad6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ad8:	0eb56763          	bltu	a0,a1,1bc6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1adc:	02e877bb          	remuw	a5,a6,a4
    1ae0:	1782                	slli	a5,a5,0x20
    1ae2:	9381                	srli	a5,a5,0x20
    1ae4:	97b2                	add	a5,a5,a2
    1ae6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1aea:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1aee:	02f10323          	sb	a5,38(sp)
    1af2:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1af4:	0ce86963          	bltu	a6,a4,1bc6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1af8:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1afc:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b00:	1582                	slli	a1,a1,0x20
    1b02:	9181                	srli	a1,a1,0x20
    1b04:	95b2                	add	a1,a1,a2
    1b06:	0005c583          	lbu	a1,0(a1)
    1b0a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b0e:	0007859b          	sext.w	a1,a5
    1b12:	16e6e563          	bltu	a3,a4,1c7c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b16:	02e7f6bb          	remuw	a3,a5,a4
    1b1a:	1682                	slli	a3,a3,0x20
    1b1c:	9281                	srli	a3,a3,0x20
    1b1e:	96b2                	add	a3,a3,a2
    1b20:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b24:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b28:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b2c:	16e5e163          	bltu	a1,a4,1c8e <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b30:	02e876bb          	remuw	a3,a6,a4
    1b34:	1682                	slli	a3,a3,0x20
    1b36:	9281                	srli	a3,a3,0x20
    1b38:	96b2                	add	a3,a3,a2
    1b3a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b3e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b42:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b46:	14e86d63          	bltu	a6,a4,1ca0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b4a:	02e5f6bb          	remuw	a3,a1,a4
    1b4e:	1682                	slli	a3,a3,0x20
    1b50:	9281                	srli	a3,a3,0x20
    1b52:	96b2                	add	a3,a3,a2
    1b54:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b58:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b5c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b60:	10e5e563          	bltu	a1,a4,1c6a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b64:	02e876bb          	remuw	a3,a6,a4
    1b68:	1682                	slli	a3,a3,0x20
    1b6a:	9281                	srli	a3,a3,0x20
    1b6c:	96b2                	add	a3,a3,a2
    1b6e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b72:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b76:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b7a:	14e86263          	bltu	a6,a4,1cbe <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b7e:	02e5f6bb          	remuw	a3,a1,a4
    1b82:	1682                	slli	a3,a3,0x20
    1b84:	9281                	srli	a3,a3,0x20
    1b86:	96b2                	add	a3,a3,a2
    1b88:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b8c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b90:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b94:	14e5e463          	bltu	a1,a4,1cdc <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b98:	02e876bb          	remuw	a3,a6,a4
    1b9c:	1682                	slli	a3,a3,0x20
    1b9e:	9281                	srli	a3,a3,0x20
    1ba0:	96b2                	add	a3,a3,a2
    1ba2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ba6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1baa:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1bae:	14e86063          	bltu	a6,a4,1cee <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1bb2:	1782                	slli	a5,a5,0x20
    1bb4:	9381                	srli	a5,a5,0x20
    1bb6:	97b2                	add	a5,a5,a2
    1bb8:	0007c703          	lbu	a4,0(a5)
    1bbc:	4799                	li	a5,6
    1bbe:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1bc2:	10054763          	bltz	a0,1cd0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1bc6:	00001497          	auipc	s1,0x1
    1bca:	d9248493          	addi	s1,s1,-622 # 2958 <buffer_len>
    1bce:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1bd2:	0828                	addi	a0,sp,24
    1bd4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1bd6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1bd8:	00f50433          	add	s0,a0,a5
    1bdc:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1bde:	06e68463          	beq	a3,a4,1c46 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1be2:	8522                	mv	a0,s0
    1be4:	b15ff0ef          	jal	ra,16f8 <out_unlocked>
}
    1be8:	60a6                	ld	ra,72(sp)
    1bea:	6406                	ld	s0,64(sp)
    1bec:	74e2                	ld	s1,56(sp)
    1bee:	6161                	addi	sp,sp,80
    1bf0:	8082                	ret
		x = -xx;
    1bf2:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1bf6:	02b877bb          	remuw	a5,a6,a1
    1bfa:	00001617          	auipc	a2,0x1
    1bfe:	e8660613          	addi	a2,a2,-378 # 2a80 <digits>
	buf[16] = 0;
    1c02:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c06:	0005871b          	sext.w	a4,a1
    1c0a:	1782                	slli	a5,a5,0x20
    1c0c:	9381                	srli	a5,a5,0x20
    1c0e:	97b2                	add	a5,a5,a2
    1c10:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c14:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c18:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c1c:	08b86b63          	bltu	a6,a1,1cb2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c20:	02e8f7bb          	remuw	a5,a7,a4
    1c24:	1782                	slli	a5,a5,0x20
    1c26:	9381                	srli	a5,a5,0x20
    1c28:	97b2                	add	a5,a5,a2
    1c2a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c2e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c32:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c36:	ece8f1e3          	bgeu	a7,a4,1af8 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c3a:	02d00793          	li	a5,45
    1c3e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c42:	47b5                	li	a5,13
    1c44:	b749                	j	1bc6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c46:	10c4a503          	lw	a0,268(s1)
    1c4a:	e42e                	sd	a1,8(sp)
    1c4c:	2c1000ef          	jal	ra,270c <mutex_lock>
		len = out_unlocked(s, l);
    1c50:	65a2                	ld	a1,8(sp)
    1c52:	8522                	mv	a0,s0
    1c54:	aa5ff0ef          	jal	ra,16f8 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c58:	10c4a503          	lw	a0,268(s1)
    1c5c:	2bd000ef          	jal	ra,2718 <mutex_unlock>
}
    1c60:	60a6                	ld	ra,72(sp)
    1c62:	6406                	ld	s0,64(sp)
    1c64:	74e2                	ld	s1,56(sp)
    1c66:	6161                	addi	sp,sp,80
    1c68:	8082                	ret
		buf[i--] = digits[x % base];
    1c6a:	47a9                	li	a5,10
	if (sign)
    1c6c:	f4055de3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c70:	02d00793          	li	a5,45
    1c74:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c78:	47a5                	li	a5,9
    1c7a:	b7b1                	j	1bc6 <printint.constprop.0+0x122>
    1c7c:	47b5                	li	a5,13
	if (sign)
    1c7e:	f40554e3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c82:	02d00793          	li	a5,45
    1c86:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c8a:	47b1                	li	a5,12
    1c8c:	bf2d                	j	1bc6 <printint.constprop.0+0x122>
    1c8e:	47b1                	li	a5,12
	if (sign)
    1c90:	f2055be3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c94:	02d00793          	li	a5,45
    1c98:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c9c:	47ad                	li	a5,11
    1c9e:	b725                	j	1bc6 <printint.constprop.0+0x122>
    1ca0:	47ad                	li	a5,11
	if (sign)
    1ca2:	f20552e3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca6:	02d00793          	li	a5,45
    1caa:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1cae:	47a9                	li	a5,10
    1cb0:	bf19                	j	1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb2:	02d00793          	li	a5,45
    1cb6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cba:	47b9                	li	a5,14
    1cbc:	b729                	j	1bc6 <printint.constprop.0+0x122>
    1cbe:	47a5                	li	a5,9
	if (sign)
    1cc0:	f00553e3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc4:	02d00793          	li	a5,45
    1cc8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1ccc:	47a1                	li	a5,8
    1cce:	bde5                	j	1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd0:	02d00793          	li	a5,45
    1cd4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1cd8:	4795                	li	a5,5
    1cda:	b5f5                	j	1bc6 <printint.constprop.0+0x122>
    1cdc:	47a1                	li	a5,8
	if (sign)
    1cde:	ee0554e3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce2:	02d00793          	li	a5,45
    1ce6:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1cea:	479d                	li	a5,7
    1cec:	bde9                	j	1bc6 <printint.constprop.0+0x122>
    1cee:	479d                	li	a5,7
	if (sign)
    1cf0:	ec055be3          	bgez	a0,1bc6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf4:	02d00793          	li	a5,45
    1cf8:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cfc:	4799                	li	a5,6
    1cfe:	b5e1                	j	1bc6 <printint.constprop.0+0x122>

0000000000001d00 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d00:	02000793          	li	a5,32
    1d04:	00f50663          	beq	a0,a5,1d10 <isspace+0x10>
    1d08:	355d                	addiw	a0,a0,-9
    1d0a:	00553513          	sltiu	a0,a0,5
    1d0e:	8082                	ret
    1d10:	4505                	li	a0,1
}
    1d12:	8082                	ret

0000000000001d14 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d14:	fd05051b          	addiw	a0,a0,-48
}
    1d18:	00a53513          	sltiu	a0,a0,10
    1d1c:	8082                	ret

0000000000001d1e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d1e:	02000613          	li	a2,32
    1d22:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d24:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d28:	ff77869b          	addiw	a3,a5,-9
    1d2c:	04c78c63          	beq	a5,a2,1d84 <atoi+0x66>
    1d30:	0007871b          	sext.w	a4,a5
    1d34:	04d5f863          	bgeu	a1,a3,1d84 <atoi+0x66>
		s++;
	switch (*s) {
    1d38:	02b00693          	li	a3,43
    1d3c:	04d78963          	beq	a5,a3,1d8e <atoi+0x70>
    1d40:	02d00693          	li	a3,45
    1d44:	06d78263          	beq	a5,a3,1da8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d48:	fd07061b          	addiw	a2,a4,-48
    1d4c:	47a5                	li	a5,9
    1d4e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d50:	4e01                	li	t3,0
	while (isdigit(*s))
    1d52:	04c7e963          	bltu	a5,a2,1da4 <atoi+0x86>
	int n = 0, neg = 0;
    1d56:	4501                	li	a0,0
	while (isdigit(*s))
    1d58:	4825                	li	a6,9
    1d5a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d5e:	0025179b          	slliw	a5,a0,0x2
    1d62:	9fa9                	addw	a5,a5,a0
    1d64:	fd07031b          	addiw	t1,a4,-48
    1d68:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d6c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d70:	0685                	addi	a3,a3,1
    1d72:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d76:	0006071b          	sext.w	a4,a2
    1d7a:	feb870e3          	bgeu	a6,a1,1d5a <atoi+0x3c>
	return neg ? n : -n;
    1d7e:	000e0563          	beqz	t3,1d88 <atoi+0x6a>
}
    1d82:	8082                	ret
		s++;
    1d84:	0505                	addi	a0,a0,1
    1d86:	bf79                	j	1d24 <atoi+0x6>
	return neg ? n : -n;
    1d88:	4113053b          	subw	a0,t1,a7
    1d8c:	8082                	ret
	while (isdigit(*s))
    1d8e:	00154703          	lbu	a4,1(a0)
    1d92:	47a5                	li	a5,9
		s++;
    1d94:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d98:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d9c:	4e01                	li	t3,0
	while (isdigit(*s))
    1d9e:	2701                	sext.w	a4,a4
    1da0:	fac7fbe3          	bgeu	a5,a2,1d56 <atoi+0x38>
    1da4:	4501                	li	a0,0
}
    1da6:	8082                	ret
	while (isdigit(*s))
    1da8:	00154703          	lbu	a4,1(a0)
    1dac:	47a5                	li	a5,9
		s++;
    1dae:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1db2:	fd07061b          	addiw	a2,a4,-48
    1db6:	2701                	sext.w	a4,a4
    1db8:	fec7e6e3          	bltu	a5,a2,1da4 <atoi+0x86>
		neg = 1;
    1dbc:	4e05                	li	t3,1
    1dbe:	bf61                	j	1d56 <atoi+0x38>

0000000000001dc0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1dc0:	16060d63          	beqz	a2,1f3a <memset+0x17a>
    1dc4:	40a007b3          	neg	a5,a0
    1dc8:	8b9d                	andi	a5,a5,7
    1dca:	00778693          	addi	a3,a5,7
    1dce:	482d                	li	a6,11
    1dd0:	0ff5f713          	zext.b	a4,a1
    1dd4:	fff60593          	addi	a1,a2,-1
    1dd8:	1706e263          	bltu	a3,a6,1f3c <memset+0x17c>
    1ddc:	16d5ea63          	bltu	a1,a3,1f50 <memset+0x190>
    1de0:	16078563          	beqz	a5,1f4a <memset+0x18a>
    1de4:	00e50023          	sb	a4,0(a0)
    1de8:	4685                	li	a3,1
    1dea:	00150593          	addi	a1,a0,1
    1dee:	14d78c63          	beq	a5,a3,1f46 <memset+0x186>
    1df2:	00e500a3          	sb	a4,1(a0)
    1df6:	4689                	li	a3,2
    1df8:	00250593          	addi	a1,a0,2
    1dfc:	14d78d63          	beq	a5,a3,1f56 <memset+0x196>
    1e00:	00e50123          	sb	a4,2(a0)
    1e04:	468d                	li	a3,3
    1e06:	00350593          	addi	a1,a0,3
    1e0a:	12d78b63          	beq	a5,a3,1f40 <memset+0x180>
    1e0e:	00e501a3          	sb	a4,3(a0)
    1e12:	4691                	li	a3,4
    1e14:	00450593          	addi	a1,a0,4
    1e18:	14d78163          	beq	a5,a3,1f5a <memset+0x19a>
    1e1c:	00e50223          	sb	a4,4(a0)
    1e20:	4695                	li	a3,5
    1e22:	00550593          	addi	a1,a0,5
    1e26:	12d78c63          	beq	a5,a3,1f5e <memset+0x19e>
    1e2a:	00e502a3          	sb	a4,5(a0)
    1e2e:	469d                	li	a3,7
    1e30:	00650593          	addi	a1,a0,6
    1e34:	12d79763          	bne	a5,a3,1f62 <memset+0x1a2>
    1e38:	00750593          	addi	a1,a0,7
    1e3c:	00e50323          	sb	a4,6(a0)
    1e40:	481d                	li	a6,7
    1e42:	00871693          	slli	a3,a4,0x8
    1e46:	01071893          	slli	a7,a4,0x10
    1e4a:	8ed9                	or	a3,a3,a4
    1e4c:	01871313          	slli	t1,a4,0x18
    1e50:	0116e6b3          	or	a3,a3,a7
    1e54:	0066e6b3          	or	a3,a3,t1
    1e58:	02071893          	slli	a7,a4,0x20
    1e5c:	02871e13          	slli	t3,a4,0x28
    1e60:	0116e6b3          	or	a3,a3,a7
    1e64:	40f60333          	sub	t1,a2,a5
    1e68:	03071893          	slli	a7,a4,0x30
    1e6c:	01c6e6b3          	or	a3,a3,t3
    1e70:	0116e6b3          	or	a3,a3,a7
    1e74:	03871e13          	slli	t3,a4,0x38
    1e78:	97aa                	add	a5,a5,a0
    1e7a:	ff837893          	andi	a7,t1,-8
    1e7e:	01c6e6b3          	or	a3,a3,t3
    1e82:	98be                	add	a7,a7,a5
    1e84:	e394                	sd	a3,0(a5)
    1e86:	07a1                	addi	a5,a5,8
    1e88:	ff179ee3          	bne	a5,a7,1e84 <memset+0xc4>
    1e8c:	ff837893          	andi	a7,t1,-8
    1e90:	011587b3          	add	a5,a1,a7
    1e94:	010886bb          	addw	a3,a7,a6
    1e98:	0b130663          	beq	t1,a7,1f44 <memset+0x184>
    1e9c:	00e78023          	sb	a4,0(a5)
    1ea0:	0016859b          	addiw	a1,a3,1
    1ea4:	08c5fb63          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ea8:	00e780a3          	sb	a4,1(a5)
    1eac:	0026859b          	addiw	a1,a3,2
    1eb0:	08c5f563          	bgeu	a1,a2,1f3a <memset+0x17a>
    1eb4:	00e78123          	sb	a4,2(a5)
    1eb8:	0036859b          	addiw	a1,a3,3
    1ebc:	06c5ff63          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ec0:	00e781a3          	sb	a4,3(a5)
    1ec4:	0046859b          	addiw	a1,a3,4
    1ec8:	06c5f963          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ecc:	00e78223          	sb	a4,4(a5)
    1ed0:	0056859b          	addiw	a1,a3,5
    1ed4:	06c5f363          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ed8:	00e782a3          	sb	a4,5(a5)
    1edc:	0066859b          	addiw	a1,a3,6
    1ee0:	04c5fd63          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ee4:	00e78323          	sb	a4,6(a5)
    1ee8:	0076859b          	addiw	a1,a3,7
    1eec:	04c5f763          	bgeu	a1,a2,1f3a <memset+0x17a>
    1ef0:	00e783a3          	sb	a4,7(a5)
    1ef4:	0086859b          	addiw	a1,a3,8
    1ef8:	04c5f163          	bgeu	a1,a2,1f3a <memset+0x17a>
    1efc:	00e78423          	sb	a4,8(a5)
    1f00:	0096859b          	addiw	a1,a3,9
    1f04:	02c5fb63          	bgeu	a1,a2,1f3a <memset+0x17a>
    1f08:	00e784a3          	sb	a4,9(a5)
    1f0c:	00a6859b          	addiw	a1,a3,10
    1f10:	02c5f563          	bgeu	a1,a2,1f3a <memset+0x17a>
    1f14:	00e78523          	sb	a4,10(a5)
    1f18:	00b6859b          	addiw	a1,a3,11
    1f1c:	00c5ff63          	bgeu	a1,a2,1f3a <memset+0x17a>
    1f20:	00e785a3          	sb	a4,11(a5)
    1f24:	00c6859b          	addiw	a1,a3,12
    1f28:	00c5f963          	bgeu	a1,a2,1f3a <memset+0x17a>
    1f2c:	00e78623          	sb	a4,12(a5)
    1f30:	26b5                	addiw	a3,a3,13
    1f32:	00c6f463          	bgeu	a3,a2,1f3a <memset+0x17a>
    1f36:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f3a:	8082                	ret
    1f3c:	46ad                	li	a3,11
    1f3e:	bd79                	j	1ddc <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f40:	480d                	li	a6,3
    1f42:	b701                	j	1e42 <memset+0x82>
    1f44:	8082                	ret
    1f46:	4805                	li	a6,1
    1f48:	bded                	j	1e42 <memset+0x82>
    1f4a:	85aa                	mv	a1,a0
    1f4c:	4801                	li	a6,0
    1f4e:	bdd5                	j	1e42 <memset+0x82>
    1f50:	87aa                	mv	a5,a0
    1f52:	4681                	li	a3,0
    1f54:	b7a1                	j	1e9c <memset+0xdc>
    1f56:	4809                	li	a6,2
    1f58:	b5ed                	j	1e42 <memset+0x82>
    1f5a:	4811                	li	a6,4
    1f5c:	b5dd                	j	1e42 <memset+0x82>
    1f5e:	4815                	li	a6,5
    1f60:	b5cd                	j	1e42 <memset+0x82>
    1f62:	4819                	li	a6,6
    1f64:	bdf9                	j	1e42 <memset+0x82>

0000000000001f66 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f66:	00054783          	lbu	a5,0(a0)
    1f6a:	0005c703          	lbu	a4,0(a1)
    1f6e:	00e79863          	bne	a5,a4,1f7e <strcmp+0x18>
    1f72:	0505                	addi	a0,a0,1
    1f74:	0585                	addi	a1,a1,1
    1f76:	fbe5                	bnez	a5,1f66 <strcmp>
    1f78:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f7a:	9d19                	subw	a0,a0,a4
    1f7c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f7e:	0007851b          	sext.w	a0,a5
    1f82:	bfe5                	j	1f7a <strcmp+0x14>

0000000000001f84 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f84:	ca15                	beqz	a2,1fb8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f86:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f8a:	167d                	addi	a2,a2,-1
    1f8c:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f90:	eb99                	bnez	a5,1fa6 <strncmp+0x22>
    1f92:	a815                	j	1fc6 <strncmp+0x42>
    1f94:	00a68e63          	beq	a3,a0,1fb0 <strncmp+0x2c>
    1f98:	0505                	addi	a0,a0,1
    1f9a:	00f71b63          	bne	a4,a5,1fb0 <strncmp+0x2c>
    1f9e:	00054783          	lbu	a5,0(a0)
    1fa2:	cf89                	beqz	a5,1fbc <strncmp+0x38>
    1fa4:	85b2                	mv	a1,a2
    1fa6:	0005c703          	lbu	a4,0(a1)
    1faa:	00158613          	addi	a2,a1,1
    1fae:	f37d                	bnez	a4,1f94 <strncmp+0x10>
		;
	return *l - *r;
    1fb0:	0007851b          	sext.w	a0,a5
    1fb4:	9d19                	subw	a0,a0,a4
    1fb6:	8082                	ret
		return 0;
    1fb8:	4501                	li	a0,0
}
    1fba:	8082                	ret
	return *l - *r;
    1fbc:	0015c703          	lbu	a4,1(a1)
    1fc0:	4501                	li	a0,0
    1fc2:	9d19                	subw	a0,a0,a4
    1fc4:	8082                	ret
    1fc6:	0005c703          	lbu	a4,0(a1)
    1fca:	4501                	li	a0,0
    1fcc:	b7e5                	j	1fb4 <strncmp+0x30>

0000000000001fce <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1fce:	00757793          	andi	a5,a0,7
    1fd2:	cf89                	beqz	a5,1fec <strlen+0x1e>
    1fd4:	87aa                	mv	a5,a0
    1fd6:	a029                	j	1fe0 <strlen+0x12>
    1fd8:	0785                	addi	a5,a5,1
    1fda:	0077f713          	andi	a4,a5,7
    1fde:	cb01                	beqz	a4,1fee <strlen+0x20>
		if (!*s)
    1fe0:	0007c703          	lbu	a4,0(a5)
    1fe4:	fb75                	bnez	a4,1fd8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1fe6:	40a78533          	sub	a0,a5,a0
}
    1fea:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1fec:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fee:	6394                	ld	a3,0(a5)
    1ff0:	00001597          	auipc	a1,0x1
    1ff4:	9505b583          	ld	a1,-1712(a1) # 2940 <enable_deadlock_detect+0x1d4>
    1ff8:	00001617          	auipc	a2,0x1
    1ffc:	95063603          	ld	a2,-1712(a2) # 2948 <enable_deadlock_detect+0x1dc>
    2000:	a019                	j	2006 <strlen+0x38>
    2002:	6794                	ld	a3,8(a5)
    2004:	07a1                	addi	a5,a5,8
    2006:	00b68733          	add	a4,a3,a1
    200a:	fff6c693          	not	a3,a3
    200e:	8f75                	and	a4,a4,a3
    2010:	8f71                	and	a4,a4,a2
    2012:	db65                	beqz	a4,2002 <strlen+0x34>
	for (; *s; s++)
    2014:	0007c703          	lbu	a4,0(a5)
    2018:	d779                	beqz	a4,1fe6 <strlen+0x18>
    201a:	0017c703          	lbu	a4,1(a5)
    201e:	0785                	addi	a5,a5,1
    2020:	d379                	beqz	a4,1fe6 <strlen+0x18>
    2022:	0017c703          	lbu	a4,1(a5)
    2026:	0785                	addi	a5,a5,1
    2028:	fb6d                	bnez	a4,201a <strlen+0x4c>
    202a:	bf75                	j	1fe6 <strlen+0x18>

000000000000202c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    202c:	00757713          	andi	a4,a0,7
{
    2030:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2032:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2036:	cb19                	beqz	a4,204c <memchr+0x20>
    2038:	ce25                	beqz	a2,20b0 <memchr+0x84>
    203a:	0007c703          	lbu	a4,0(a5)
    203e:	04b70e63          	beq	a4,a1,209a <memchr+0x6e>
    2042:	0785                	addi	a5,a5,1
    2044:	0077f713          	andi	a4,a5,7
    2048:	167d                	addi	a2,a2,-1
    204a:	f77d                	bnez	a4,2038 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    204c:	4501                	li	a0,0
	if (n && *s != c) {
    204e:	c235                	beqz	a2,20b2 <memchr+0x86>
    2050:	0007c703          	lbu	a4,0(a5)
    2054:	04b70363          	beq	a4,a1,209a <memchr+0x6e>
		size_t k = ONES * c;
    2058:	00001517          	auipc	a0,0x1
    205c:	8f853503          	ld	a0,-1800(a0) # 2950 <enable_deadlock_detect+0x1e4>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2060:	471d                	li	a4,7
		size_t k = ONES * c;
    2062:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2066:	02c77a63          	bgeu	a4,a2,209a <memchr+0x6e>
    206a:	00001897          	auipc	a7,0x1
    206e:	8d68b883          	ld	a7,-1834(a7) # 2940 <enable_deadlock_detect+0x1d4>
    2072:	00001817          	auipc	a6,0x1
    2076:	8d683803          	ld	a6,-1834(a6) # 2948 <enable_deadlock_detect+0x1dc>
    207a:	431d                	li	t1,7
    207c:	a029                	j	2086 <memchr+0x5a>
		     w++, n -= SS)
    207e:	1661                	addi	a2,a2,-8
    2080:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2082:	02c37963          	bgeu	t1,a2,20b4 <memchr+0x88>
    2086:	6398                	ld	a4,0(a5)
    2088:	8f29                	xor	a4,a4,a0
    208a:	011706b3          	add	a3,a4,a7
    208e:	fff74713          	not	a4,a4
    2092:	8f75                	and	a4,a4,a3
    2094:	01077733          	and	a4,a4,a6
    2098:	d37d                	beqz	a4,207e <memchr+0x52>
{
    209a:	853e                	mv	a0,a5
    209c:	97b2                	add	a5,a5,a2
    209e:	a021                	j	20a6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20a0:	0505                	addi	a0,a0,1
    20a2:	00f50763          	beq	a0,a5,20b0 <memchr+0x84>
    20a6:	00054703          	lbu	a4,0(a0)
    20aa:	feb71be3          	bne	a4,a1,20a0 <memchr+0x74>
    20ae:	8082                	ret
	return n ? (void *)s : 0;
    20b0:	4501                	li	a0,0
}
    20b2:	8082                	ret
	return n ? (void *)s : 0;
    20b4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20b6:	f275                	bnez	a2,209a <memchr+0x6e>
}
    20b8:	8082                	ret

00000000000020ba <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20ba:	1101                	addi	sp,sp,-32
    20bc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20be:	862e                	mv	a2,a1
{
    20c0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20c2:	4581                	li	a1,0
{
    20c4:	e426                	sd	s1,8(sp)
    20c6:	ec06                	sd	ra,24(sp)
    20c8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20ca:	f63ff0ef          	jal	ra,202c <memchr>
	return p ? p - s : n;
    20ce:	c519                	beqz	a0,20dc <strnlen+0x22>
}
    20d0:	60e2                	ld	ra,24(sp)
    20d2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    20d4:	8d05                	sub	a0,a0,s1
}
    20d6:	64a2                	ld	s1,8(sp)
    20d8:	6105                	addi	sp,sp,32
    20da:	8082                	ret
    20dc:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20de:	8522                	mv	a0,s0
}
    20e0:	6442                	ld	s0,16(sp)
    20e2:	64a2                	ld	s1,8(sp)
    20e4:	6105                	addi	sp,sp,32
    20e6:	8082                	ret

00000000000020e8 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20e8:	00a5c7b3          	xor	a5,a1,a0
    20ec:	8b9d                	andi	a5,a5,7
    20ee:	eb95                	bnez	a5,2122 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20f0:	0075f793          	andi	a5,a1,7
    20f4:	e7b1                	bnez	a5,2140 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20f6:	6198                	ld	a4,0(a1)
    20f8:	00001617          	auipc	a2,0x1
    20fc:	84863603          	ld	a2,-1976(a2) # 2940 <enable_deadlock_detect+0x1d4>
    2100:	00001817          	auipc	a6,0x1
    2104:	84883803          	ld	a6,-1976(a6) # 2948 <enable_deadlock_detect+0x1dc>
    2108:	a029                	j	2112 <stpcpy+0x2a>
    210a:	05a1                	addi	a1,a1,8
    210c:	e118                	sd	a4,0(a0)
    210e:	6198                	ld	a4,0(a1)
    2110:	0521                	addi	a0,a0,8
    2112:	00c707b3          	add	a5,a4,a2
    2116:	fff74693          	not	a3,a4
    211a:	8ff5                	and	a5,a5,a3
    211c:	0107f7b3          	and	a5,a5,a6
    2120:	d7ed                	beqz	a5,210a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2122:	0005c783          	lbu	a5,0(a1)
    2126:	00f50023          	sb	a5,0(a0)
    212a:	c785                	beqz	a5,2152 <stpcpy+0x6a>
    212c:	0015c783          	lbu	a5,1(a1)
    2130:	0505                	addi	a0,a0,1
    2132:	0585                	addi	a1,a1,1
    2134:	00f50023          	sb	a5,0(a0)
    2138:	fbf5                	bnez	a5,212c <stpcpy+0x44>
		;
	return d;
}
    213a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    213c:	0505                	addi	a0,a0,1
    213e:	df45                	beqz	a4,20f6 <stpcpy+0xe>
			if (!(*d = *s))
    2140:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2144:	0585                	addi	a1,a1,1
    2146:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    214a:	00f50023          	sb	a5,0(a0)
    214e:	f7fd                	bnez	a5,213c <stpcpy+0x54>
}
    2150:	8082                	ret
    2152:	8082                	ret

0000000000002154 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2154:	00a5c7b3          	xor	a5,a1,a0
    2158:	8b9d                	andi	a5,a5,7
    215a:	1a079863          	bnez	a5,230a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    215e:	0075f793          	andi	a5,a1,7
    2162:	16078463          	beqz	a5,22ca <stpncpy+0x176>
    2166:	ea01                	bnez	a2,2176 <stpncpy+0x22>
    2168:	a421                	j	2370 <stpncpy+0x21c>
    216a:	167d                	addi	a2,a2,-1
    216c:	0505                	addi	a0,a0,1
    216e:	14070e63          	beqz	a4,22ca <stpncpy+0x176>
    2172:	1a060863          	beqz	a2,2322 <stpncpy+0x1ce>
    2176:	0005c783          	lbu	a5,0(a1)
    217a:	0585                	addi	a1,a1,1
    217c:	0075f713          	andi	a4,a1,7
    2180:	00f50023          	sb	a5,0(a0)
    2184:	f3fd                	bnez	a5,216a <stpncpy+0x16>
    2186:	4805                	li	a6,1
    2188:	1a061863          	bnez	a2,2338 <stpncpy+0x1e4>
    218c:	40a007b3          	neg	a5,a0
    2190:	8b9d                	andi	a5,a5,7
    2192:	4681                	li	a3,0
    2194:	18061a63          	bnez	a2,2328 <stpncpy+0x1d4>
    2198:	00778713          	addi	a4,a5,7
    219c:	45ad                	li	a1,11
    219e:	18b76363          	bltu	a4,a1,2324 <stpncpy+0x1d0>
    21a2:	1ae6eb63          	bltu	a3,a4,2358 <stpncpy+0x204>
    21a6:	1a078363          	beqz	a5,234c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21aa:	00050023          	sb	zero,0(a0)
    21ae:	4685                	li	a3,1
    21b0:	00150713          	addi	a4,a0,1
    21b4:	18d78f63          	beq	a5,a3,2352 <stpncpy+0x1fe>
    21b8:	000500a3          	sb	zero,1(a0)
    21bc:	4689                	li	a3,2
    21be:	00250713          	addi	a4,a0,2
    21c2:	18d78e63          	beq	a5,a3,235e <stpncpy+0x20a>
    21c6:	00050123          	sb	zero,2(a0)
    21ca:	468d                	li	a3,3
    21cc:	00350713          	addi	a4,a0,3
    21d0:	16d78c63          	beq	a5,a3,2348 <stpncpy+0x1f4>
    21d4:	000501a3          	sb	zero,3(a0)
    21d8:	4691                	li	a3,4
    21da:	00450713          	addi	a4,a0,4
    21de:	18d78263          	beq	a5,a3,2362 <stpncpy+0x20e>
    21e2:	00050223          	sb	zero,4(a0)
    21e6:	4695                	li	a3,5
    21e8:	00550713          	addi	a4,a0,5
    21ec:	16d78d63          	beq	a5,a3,2366 <stpncpy+0x212>
    21f0:	000502a3          	sb	zero,5(a0)
    21f4:	469d                	li	a3,7
    21f6:	00650713          	addi	a4,a0,6
    21fa:	16d79863          	bne	a5,a3,236a <stpncpy+0x216>
    21fe:	00750713          	addi	a4,a0,7
    2202:	00050323          	sb	zero,6(a0)
    2206:	40f80833          	sub	a6,a6,a5
    220a:	ff887593          	andi	a1,a6,-8
    220e:	97aa                	add	a5,a5,a0
    2210:	95be                	add	a1,a1,a5
    2212:	0007b023          	sd	zero,0(a5)
    2216:	07a1                	addi	a5,a5,8
    2218:	feb79de3          	bne	a5,a1,2212 <stpncpy+0xbe>
    221c:	ff887593          	andi	a1,a6,-8
    2220:	9ead                	addw	a3,a3,a1
    2222:	00b707b3          	add	a5,a4,a1
    2226:	12b80863          	beq	a6,a1,2356 <stpncpy+0x202>
    222a:	00078023          	sb	zero,0(a5)
    222e:	0016871b          	addiw	a4,a3,1
    2232:	0ec77863          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    2236:	000780a3          	sb	zero,1(a5)
    223a:	0026871b          	addiw	a4,a3,2
    223e:	0ec77263          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    2242:	00078123          	sb	zero,2(a5)
    2246:	0036871b          	addiw	a4,a3,3
    224a:	0cc77c63          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    224e:	000781a3          	sb	zero,3(a5)
    2252:	0046871b          	addiw	a4,a3,4
    2256:	0cc77663          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    225a:	00078223          	sb	zero,4(a5)
    225e:	0056871b          	addiw	a4,a3,5
    2262:	0cc77063          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    2266:	000782a3          	sb	zero,5(a5)
    226a:	0066871b          	addiw	a4,a3,6
    226e:	0ac77a63          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    2272:	00078323          	sb	zero,6(a5)
    2276:	0076871b          	addiw	a4,a3,7
    227a:	0ac77463          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    227e:	000783a3          	sb	zero,7(a5)
    2282:	0086871b          	addiw	a4,a3,8
    2286:	08c77e63          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    228a:	00078423          	sb	zero,8(a5)
    228e:	0096871b          	addiw	a4,a3,9
    2292:	08c77863          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    2296:	000784a3          	sb	zero,9(a5)
    229a:	00a6871b          	addiw	a4,a3,10
    229e:	08c77263          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    22a2:	00078523          	sb	zero,10(a5)
    22a6:	00b6871b          	addiw	a4,a3,11
    22aa:	06c77c63          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    22ae:	000785a3          	sb	zero,11(a5)
    22b2:	00c6871b          	addiw	a4,a3,12
    22b6:	06c77663          	bgeu	a4,a2,2322 <stpncpy+0x1ce>
    22ba:	00078623          	sb	zero,12(a5)
    22be:	26b5                	addiw	a3,a3,13
    22c0:	06c6f163          	bgeu	a3,a2,2322 <stpncpy+0x1ce>
    22c4:	000786a3          	sb	zero,13(a5)
    22c8:	8082                	ret
			;
		if (!n || !*s)
    22ca:	c645                	beqz	a2,2372 <stpncpy+0x21e>
    22cc:	0005c783          	lbu	a5,0(a1)
    22d0:	ea078be3          	beqz	a5,2186 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22d4:	479d                	li	a5,7
    22d6:	02c7ff63          	bgeu	a5,a2,2314 <stpncpy+0x1c0>
    22da:	00000897          	auipc	a7,0x0
    22de:	6668b883          	ld	a7,1638(a7) # 2940 <enable_deadlock_detect+0x1d4>
    22e2:	00000817          	auipc	a6,0x0
    22e6:	66683803          	ld	a6,1638(a6) # 2948 <enable_deadlock_detect+0x1dc>
    22ea:	431d                	li	t1,7
    22ec:	6198                	ld	a4,0(a1)
    22ee:	011707b3          	add	a5,a4,a7
    22f2:	fff74693          	not	a3,a4
    22f6:	8ff5                	and	a5,a5,a3
    22f8:	0107f7b3          	and	a5,a5,a6
    22fc:	ef81                	bnez	a5,2314 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22fe:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2300:	1661                	addi	a2,a2,-8
    2302:	05a1                	addi	a1,a1,8
    2304:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2306:	fec363e3          	bltu	t1,a2,22ec <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    230a:	e609                	bnez	a2,2314 <stpncpy+0x1c0>
    230c:	a08d                	j	236e <stpncpy+0x21a>
    230e:	167d                	addi	a2,a2,-1
    2310:	0505                	addi	a0,a0,1
    2312:	ca01                	beqz	a2,2322 <stpncpy+0x1ce>
    2314:	0005c783          	lbu	a5,0(a1)
    2318:	0585                	addi	a1,a1,1
    231a:	00f50023          	sb	a5,0(a0)
    231e:	fbe5                	bnez	a5,230e <stpncpy+0x1ba>
		;
tail:
    2320:	b59d                	j	2186 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2322:	8082                	ret
    2324:	472d                	li	a4,11
    2326:	bdb5                	j	21a2 <stpncpy+0x4e>
    2328:	00778713          	addi	a4,a5,7
    232c:	45ad                	li	a1,11
    232e:	fff60693          	addi	a3,a2,-1
    2332:	e6b778e3          	bgeu	a4,a1,21a2 <stpncpy+0x4e>
    2336:	b7fd                	j	2324 <stpncpy+0x1d0>
    2338:	40a007b3          	neg	a5,a0
    233c:	8832                	mv	a6,a2
    233e:	8b9d                	andi	a5,a5,7
    2340:	4681                	li	a3,0
    2342:	e4060be3          	beqz	a2,2198 <stpncpy+0x44>
    2346:	b7cd                	j	2328 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2348:	468d                	li	a3,3
    234a:	bd75                	j	2206 <stpncpy+0xb2>
    234c:	872a                	mv	a4,a0
    234e:	4681                	li	a3,0
    2350:	bd5d                	j	2206 <stpncpy+0xb2>
    2352:	4685                	li	a3,1
    2354:	bd4d                	j	2206 <stpncpy+0xb2>
    2356:	8082                	ret
    2358:	87aa                	mv	a5,a0
    235a:	4681                	li	a3,0
    235c:	b5f9                	j	222a <stpncpy+0xd6>
    235e:	4689                	li	a3,2
    2360:	b55d                	j	2206 <stpncpy+0xb2>
    2362:	4691                	li	a3,4
    2364:	b54d                	j	2206 <stpncpy+0xb2>
    2366:	4695                	li	a3,5
    2368:	bd79                	j	2206 <stpncpy+0xb2>
    236a:	4699                	li	a3,6
    236c:	bd69                	j	2206 <stpncpy+0xb2>
    236e:	8082                	ret
    2370:	8082                	ret
    2372:	8082                	ret

0000000000002374 <basename>:

char *basename(char *s)
{
    2374:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2376:	c54d                	beqz	a0,2420 <basename+0xac>
    2378:	00054783          	lbu	a5,0(a0)
		return ".";
    237c:	00000517          	auipc	a0,0x0
    2380:	5bc50513          	addi	a0,a0,1468 # 2938 <enable_deadlock_detect+0x1cc>
	if (!s || !*s)
    2384:	e391                	bnez	a5,2388 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2386:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2388:	0076f713          	andi	a4,a3,7
    238c:	87b6                	mv	a5,a3
    238e:	cf51                	beqz	a4,242a <basename+0xb6>
    2390:	0785                	addi	a5,a5,1
    2392:	0077f713          	andi	a4,a5,7
    2396:	c729                	beqz	a4,23e0 <basename+0x6c>
		if (!*s)
    2398:	0007c703          	lbu	a4,0(a5)
    239c:	fb75                	bnez	a4,2390 <basename+0x1c>
	return s - a;
    239e:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23a0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23a2:	cf8d                	beqz	a5,23dc <basename+0x68>
    23a4:	00f68733          	add	a4,a3,a5
    23a8:	02f00593          	li	a1,47
    23ac:	a031                	j	23b8 <basename+0x44>
		s[i] = 0;
    23ae:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23b2:	17fd                	addi	a5,a5,-1
    23b4:	177d                	addi	a4,a4,-1
    23b6:	c39d                	beqz	a5,23dc <basename+0x68>
    23b8:	00074603          	lbu	a2,0(a4)
    23bc:	feb609e3          	beq	a2,a1,23ae <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23c0:	02f00613          	li	a2,47
    23c4:	a011                	j	23c8 <basename+0x54>
    23c6:	cb99                	beqz	a5,23dc <basename+0x68>
    23c8:	853e                	mv	a0,a5
    23ca:	17fd                	addi	a5,a5,-1
    23cc:	00f68733          	add	a4,a3,a5
    23d0:	00074703          	lbu	a4,0(a4)
    23d4:	fec719e3          	bne	a4,a2,23c6 <basename+0x52>
	return s + i;
    23d8:	9536                	add	a0,a0,a3
    23da:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23dc:	8536                	mv	a0,a3
    23de:	8082                	ret
    23e0:	6390                	ld	a2,0(a5)
    23e2:	00000517          	auipc	a0,0x0
    23e6:	55e53503          	ld	a0,1374(a0) # 2940 <enable_deadlock_detect+0x1d4>
    23ea:	00000597          	auipc	a1,0x0
    23ee:	55e5b583          	ld	a1,1374(a1) # 2948 <enable_deadlock_detect+0x1dc>
    23f2:	fff64713          	not	a4,a2
    23f6:	962a                	add	a2,a2,a0
    23f8:	8f71                	and	a4,a4,a2
    23fa:	8f6d                	and	a4,a4,a1
    23fc:	eb11                	bnez	a4,2410 <basename+0x9c>
    23fe:	6790                	ld	a2,8(a5)
    2400:	07a1                	addi	a5,a5,8
    2402:	00a60733          	add	a4,a2,a0
    2406:	fff64613          	not	a2,a2
    240a:	8f71                	and	a4,a4,a2
    240c:	8f6d                	and	a4,a4,a1
    240e:	db65                	beqz	a4,23fe <basename+0x8a>
	for (; *s; s++)
    2410:	0007c703          	lbu	a4,0(a5)
    2414:	d749                	beqz	a4,239e <basename+0x2a>
    2416:	0017c703          	lbu	a4,1(a5)
    241a:	0785                	addi	a5,a5,1
    241c:	ff6d                	bnez	a4,2416 <basename+0xa2>
    241e:	b741                	j	239e <basename+0x2a>
		return ".";
    2420:	00000517          	auipc	a0,0x0
    2424:	51850513          	addi	a0,a0,1304 # 2938 <enable_deadlock_detect+0x1cc>
    2428:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    242a:	6290                	ld	a2,0(a3)
    242c:	00000517          	auipc	a0,0x0
    2430:	51453503          	ld	a0,1300(a0) # 2940 <enable_deadlock_detect+0x1d4>
    2434:	00000597          	auipc	a1,0x0
    2438:	5145b583          	ld	a1,1300(a1) # 2948 <enable_deadlock_detect+0x1dc>
    243c:	fff64713          	not	a4,a2
    2440:	962a                	add	a2,a2,a0
    2442:	8f71                	and	a4,a4,a2
    2444:	8f6d                	and	a4,a4,a1
    2446:	df45                	beqz	a4,23fe <basename+0x8a>
    2448:	b7f9                	j	2416 <basename+0xa2>

000000000000244a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    244a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    244e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2450:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2454:	2501                	sext.w	a0,a0
    2456:	8082                	ret

0000000000002458 <close>:

int close(int fd)
{
	if (fd == 1) {
    2458:	4785                	li	a5,1
    245a:	00f50863          	beq	a0,a5,246a <close+0x12>
	register long a7 __asm__("a7") = n;
    245e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2462:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2466:	2501                	sext.w	a0,a0
    2468:	8082                	ret
{
    246a:	1101                	addi	sp,sp,-32
    246c:	ec06                	sd	ra,24(sp)
    246e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2470:	cdffe0ef          	jal	ra,114e <__write_buffer>
		__clear_buffer();
    2474:	d03fe0ef          	jal	ra,1176 <__clear_buffer>
    2478:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    247a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    247e:	00000073          	ecall
}
    2482:	60e2                	ld	ra,24(sp)
    2484:	2501                	sext.w	a0,a0
    2486:	6105                	addi	sp,sp,32
    2488:	8082                	ret

000000000000248a <read>:
	register long a7 __asm__("a7") = n;
    248a:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    248e:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2492:	8082                	ret

0000000000002494 <write>:
	register long a7 __asm__("a7") = n;
    2494:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2498:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    249c:	8082                	ret

000000000000249e <getpid>:
	register long a7 __asm__("a7") = n;
    249e:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24a2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24a6:	2501                	sext.w	a0,a0
    24a8:	8082                	ret

00000000000024aa <getppid>:
	register long a7 __asm__("a7") = n;
    24aa:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24ae:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24b2:	2501                	sext.w	a0,a0
    24b4:	8082                	ret

00000000000024b6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24b6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24ba:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24be:	2501                	sext.w	a0,a0
    24c0:	8082                	ret

00000000000024c2 <fork>:
	register long a7 __asm__("a7") = n;
    24c2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24c6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24ca:	2501                	sext.w	a0,a0
    24cc:	8082                	ret

00000000000024ce <exit>:

void exit(int code)
{
    24ce:	1141                	addi	sp,sp,-16
    24d0:	e406                	sd	ra,8(sp)
    24d2:	e022                	sd	s0,0(sp)
    24d4:	842a                	mv	s0,a0
	__write_buffer();
    24d6:	c79fe0ef          	jal	ra,114e <__write_buffer>
	__clear_buffer();
    24da:	c9dfe0ef          	jal	ra,1176 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24de:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24e2:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24e4:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24e8:	60a2                	ld	ra,8(sp)
    24ea:	6402                	ld	s0,0(sp)
    24ec:	0141                	addi	sp,sp,16
    24ee:	8082                	ret

00000000000024f0 <waitpid>:
	register long a7 __asm__("a7") = n;
    24f0:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24f4:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24f8:	2501                	sext.w	a0,a0
    24fa:	8082                	ret

00000000000024fc <exec>:
	register long a7 __asm__("a7") = n;
    24fc:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2500:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2504:	2501                	sext.w	a0,a0
    2506:	8082                	ret

0000000000002508 <get_mtime>:

int64 get_mtime()
{
    2508:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    250a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    250e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2510:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2512:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2516:	2501                	sext.w	a0,a0
    2518:	ed01                	bnez	a0,2530 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    251a:	6722                	ld	a4,8(sp)
    251c:	3e800793          	li	a5,1000
    2520:	6682                	ld	a3,0(sp)
    2522:	02f75733          	divu	a4,a4,a5
    2526:	02d78533          	mul	a0,a5,a3
    252a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    252c:	0141                	addi	sp,sp,16
    252e:	8082                	ret
	return -1;
    2530:	557d                	li	a0,-1
    2532:	bfed                	j	252c <get_mtime+0x24>

0000000000002534 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2534:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2538:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    253c:	2501                	sext.w	a0,a0
    253e:	8082                	ret

0000000000002540 <sleep>:

int sleep(unsigned long long time)
{
    2540:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2542:	880a                	mv	a6,sp
{
    2544:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2546:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    254a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    254c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254e:	00000073          	ecall
	if (err == 0) {
    2552:	2501                	sext.w	a0,a0
    2554:	ed31                	bnez	a0,25b0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2556:	6722                	ld	a4,8(sp)
    2558:	3e800793          	li	a5,1000
    255c:	6682                	ld	a3,0(sp)
    255e:	02f75733          	divu	a4,a4,a5
    2562:	02d787b3          	mul	a5,a5,a3
    2566:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2568:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    256c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    256e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2570:	00000073          	ecall
	if (err == 0) {
    2574:	2501                	sext.w	a0,a0
    2576:	e915                	bnez	a0,25aa <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2578:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    257a:	3e800693          	li	a3,1000
    257e:	a819                	j	2594 <sleep+0x54>
	__asm_syscall("r"(a7))
    2580:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2584:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2588:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    258a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258c:	00000073          	ecall
	if (err == 0) {
    2590:	2501                	sext.w	a0,a0
    2592:	ed01                	bnez	a0,25aa <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2594:	6722                	ld	a4,8(sp)
    2596:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2598:	07c00893          	li	a7,124
    259c:	02d75733          	divu	a4,a4,a3
    25a0:	02f687b3          	mul	a5,a3,a5
    25a4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25a6:	fcc7ede3          	bltu	a5,a2,2580 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25aa:	4501                	li	a0,0
    25ac:	0141                	addi	sp,sp,16
    25ae:	8082                	ret
    25b0:	57fd                	li	a5,-1
    25b2:	bf5d                	j	2568 <sleep+0x28>

00000000000025b4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25b4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25b8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25bc:	2501                	sext.w	a0,a0
    25be:	8082                	ret

00000000000025c0 <set_priority>:
	register long a7 __asm__("a7") = n;
    25c0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25c4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret

00000000000025cc <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25cc:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25d0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    25d4:	2501                	sext.w	a0,a0
    25d6:	8082                	ret

00000000000025d8 <munmap>:
	register long a7 __asm__("a7") = n;
    25d8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25dc:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    25e0:	2501                	sext.w	a0,a0
    25e2:	8082                	ret

00000000000025e4 <wait>:

int wait(int *code)
{
    25e4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25e6:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25ea:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ec:	00000073          	ecall
	return waitpid(-1, code);
}
    25f0:	2501                	sext.w	a0,a0
    25f2:	8082                	ret

00000000000025f4 <spawn>:
	register long a7 __asm__("a7") = n;
    25f4:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25f8:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25fc:	2501                	sext.w	a0,a0
    25fe:	8082                	ret

0000000000002600 <pipe>:
	register long a7 __asm__("a7") = n;
    2600:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2604:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2608:	2501                	sext.w	a0,a0
    260a:	8082                	ret

000000000000260c <mailread>:
	register long a7 __asm__("a7") = n;
    260c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2610:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2614:	2501                	sext.w	a0,a0
    2616:	8082                	ret

0000000000002618 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2618:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    261c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2620:	2501                	sext.w	a0,a0
    2622:	8082                	ret

0000000000002624 <fstat>:
	register long a7 __asm__("a7") = n;
    2624:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2628:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    262c:	2501                	sext.w	a0,a0
    262e:	8082                	ret

0000000000002630 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2630:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2632:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2636:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2638:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    263c:	2501                	sext.w	a0,a0
    263e:	8082                	ret

0000000000002640 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2640:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2642:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2646:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2648:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    264c:	2501                	sext.w	a0,a0
    264e:	8082                	ret

0000000000002650 <link>:

int link(char *old_path, char *new_path)
{
    2650:	87aa                	mv	a5,a0
    2652:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2654:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2658:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    265c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    265e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2662:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2664:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2668:	2501                	sext.w	a0,a0
    266a:	8082                	ret

000000000000266c <unlink>:

int unlink(char *path)
{
    266c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    266e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2672:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2676:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2678:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2680:	00000797          	auipc	a5,0x0
    2684:	4207b783          	ld	a5,1056(a5) # 2aa0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2688:	439c                	lw	a5,0(a5)
    268a:	c799                	beqz	a5,2698 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    268c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2690:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret
{
    2698:	1101                	addi	sp,sp,-32
    269a:	ec06                	sd	ra,24(sp)
    269c:	e42e                	sd	a1,8(sp)
    269e:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26a0:	fe7fe0ef          	jal	ra,1686 <enable_thread_io_buffer>
    26a4:	65a2                	ld	a1,8(sp)
    26a6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26a8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ac:	00000073          	ecall
}
    26b0:	60e2                	ld	ra,24(sp)
    26b2:	2501                	sext.w	a0,a0
    26b4:	6105                	addi	sp,sp,32
    26b6:	8082                	ret

00000000000026b8 <gettid>:
	register long a7 __asm__("a7") = n;
    26b8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26bc:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26c0:	2501                	sext.w	a0,a0
    26c2:	8082                	ret

00000000000026c4 <waittid>:

int waittid(int tid)
{
    26c4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26c6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26ca:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26ce:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    26d0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26d2:	00e51e63          	bne	a0,a4,26ee <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    26d6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26da:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26de:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26e2:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26e4:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26e8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26ea:	fee506e3          	beq	a0,a4,26d6 <waittid+0x12>
	}
	return ret;
}
    26ee:	8082                	ret

00000000000026f0 <mutex_create>:
	register long a7 __asm__("a7") = n;
    26f0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26f4:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26f6:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret

00000000000026fe <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26fe:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2702:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    270c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2710:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2718:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    271c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2720:	2501                	sext.w	a0,a0
    2722:	8082                	ret

0000000000002724 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2724:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2728:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    272c:	2501                	sext.w	a0,a0
    272e:	8082                	ret

0000000000002730 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2730:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2734:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2738:	2501                	sext.w	a0,a0
    273a:	8082                	ret

000000000000273c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    273c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2740:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2744:	2501                	sext.w	a0,a0
    2746:	8082                	ret

0000000000002748 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2748:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    274c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2750:	2501                	sext.w	a0,a0
    2752:	8082                	ret

0000000000002754 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2754:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2758:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    275c:	2501                	sext.w	a0,a0
    275e:	8082                	ret

0000000000002760 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2760:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2764:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret

000000000000276c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    276c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2770:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2774:	2501                	sext.w	a0,a0
    2776:	8082                	ret
