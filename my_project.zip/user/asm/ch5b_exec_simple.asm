
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_exec_simple:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a025                	j	1028 <__start_main>

0000000000001002 <main>:
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    1002:	1141                	addi	sp,sp,-16
	puts("execute hello");
    1004:	00001517          	auipc	a0,0x1
    1008:	68c50513          	addi	a0,a0,1676 # 2690 <enable_deadlock_detect+0xe>
{
    100c:	e406                	sd	ra,8(sp)
	puts("execute hello");
    100e:	08b000ef          	jal	ra,1898 <puts>
	exec("ch2b_hello_world", NULL);
    1012:	4581                	li	a1,0
    1014:	00001517          	auipc	a0,0x1
    1018:	68c50513          	addi	a0,a0,1676 # 26a0 <enable_deadlock_detect+0x1e>
    101c:	3f6010ef          	jal	ra,2412 <exec>
	return 0;
    1020:	60a2                	ld	ra,8(sp)
    1022:	4501                	li	a0,0
    1024:	0141                	addi	sp,sp,16
    1026:	8082                	ret

0000000000001028 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1028:	1141                	addi	sp,sp,-16
    102a:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    102c:	fd7ff0ef          	jal	ra,1002 <main>
    1030:	3b4010ef          	jal	ra,23e4 <exit>
	return 0;
    1034:	60a2                	ld	ra,8(sp)
    1036:	4501                	li	a0,0
    1038:	0141                	addi	sp,sp,16
    103a:	8082                	ret

000000000000103c <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    103c:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    103e:	4605                	li	a2,1
    1040:	00f10593          	addi	a1,sp,15
    1044:	4501                	li	a0,0
{
    1046:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1048:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    104c:	354010ef          	jal	ra,23a0 <read>
    1050:	4785                	li	a5,1
    1052:	00f51763          	bne	a0,a5,1060 <getchar+0x24>
		return byte;
    1056:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    105a:	60e2                	ld	ra,24(sp)
    105c:	6105                	addi	sp,sp,32
    105e:	8082                	ret
		return EOF;
    1060:	557d                	li	a0,-1
    1062:	bfe5                	j	105a <getchar+0x1e>

0000000000001064 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1064:	00001517          	auipc	a0,0x1
    1068:	75452503          	lw	a0,1876(a0) # 27b8 <buffer_len>
    106c:	e111                	bnez	a0,1070 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    106e:	8082                	ret
{
    1070:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1072:	862a                	mv	a2,a0
    1074:	00001597          	auipc	a1,0x1
    1078:	74c58593          	addi	a1,a1,1868 # 27c0 <buffer>
    107c:	4505                	li	a0,1
{
    107e:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1080:	32a010ef          	jal	ra,23aa <write>
}
    1084:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1086:	2501                	sext.w	a0,a0
}
    1088:	0141                	addi	sp,sp,16
    108a:	8082                	ret

000000000000108c <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    108c:	00001797          	auipc	a5,0x1
    1090:	7207a623          	sw	zero,1836(a5) # 27b8 <buffer_len>
}
    1094:	8082                	ret

0000000000001096 <__fflush>:
	if (buffer_len == 0)
    1096:	00001517          	auipc	a0,0x1
    109a:	72252503          	lw	a0,1826(a0) # 27b8 <buffer_len>
    109e:	e511                	bnez	a0,10aa <__fflush+0x14>
	buffer_len = 0;
    10a0:	00001797          	auipc	a5,0x1
    10a4:	7007ac23          	sw	zero,1816(a5) # 27b8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10a8:	8082                	ret
{
    10aa:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ac:	862a                	mv	a2,a0
    10ae:	00001597          	auipc	a1,0x1
    10b2:	71258593          	addi	a1,a1,1810 # 27c0 <buffer>
    10b6:	4505                	li	a0,1
{
    10b8:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10ba:	2f0010ef          	jal	ra,23aa <write>
	return r >= 0 ? 0 : r;
    10be:	0005079b          	sext.w	a5,a0
}
    10c2:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10c4:	0017a793          	slti	a5,a5,1
    10c8:	40f007bb          	negw	a5,a5
    10cc:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10ce:	00001797          	auipc	a5,0x1
    10d2:	6e07a523          	sw	zero,1770(a5) # 27b8 <buffer_len>
	return r >= 0 ? 0 : r;
    10d6:	2501                	sext.w	a0,a0
}
    10d8:	0141                	addi	sp,sp,16
    10da:	8082                	ret

00000000000010dc <fflush>:

int fflush(int fd)
{
    10dc:	1101                	addi	sp,sp,-32
    10de:	e822                	sd	s0,16(sp)
    10e0:	ec06                	sd	ra,24(sp)
    10e2:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    10e4:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    10e6:	4401                	li	s0,0
	if (fd == 1) {
    10e8:	00e50863          	beq	a0,a4,10f8 <fflush+0x1c>
}
    10ec:	60e2                	ld	ra,24(sp)
    10ee:	8522                	mv	a0,s0
    10f0:	6442                	ld	s0,16(sp)
    10f2:	64a2                	ld	s1,8(sp)
    10f4:	6105                	addi	sp,sp,32
    10f6:	8082                	ret
		if (buffer_lock_enabled == 1) {
    10f8:	00001497          	auipc	s1,0x1
    10fc:	6c048493          	addi	s1,s1,1728 # 27b8 <buffer_len>
    1100:	1084a703          	lw	a4,264(s1)
    1104:	02a70e63          	beq	a4,a0,1140 <fflush+0x64>
	if (buffer_len == 0)
    1108:	4080                	lw	s0,0(s1)
    110a:	c00d                	beqz	s0,112c <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    110c:	8622                	mv	a2,s0
    110e:	00001597          	auipc	a1,0x1
    1112:	6b258593          	addi	a1,a1,1714 # 27c0 <buffer>
    1116:	294010ef          	jal	ra,23aa <write>
	return r >= 0 ? 0 : r;
    111a:	0005079b          	sext.w	a5,a0
    111e:	0017a793          	slti	a5,a5,1
    1122:	40f007bb          	negw	a5,a5
    1126:	8d7d                	and	a0,a0,a5
    1128:	0005041b          	sext.w	s0,a0
}
    112c:	60e2                	ld	ra,24(sp)
    112e:	8522                	mv	a0,s0
    1130:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1132:	00001797          	auipc	a5,0x1
    1136:	6807a323          	sw	zero,1670(a5) # 27b8 <buffer_len>
}
    113a:	64a2                	ld	s1,8(sp)
    113c:	6105                	addi	sp,sp,32
    113e:	8082                	ret
			mutex_lock(buffer_lock);
    1140:	10c4a503          	lw	a0,268(s1)
    1144:	4de010ef          	jal	ra,2622 <mutex_lock>
	if (buffer_len == 0)
    1148:	4080                	lw	s0,0(s1)
    114a:	e811                	bnez	s0,115e <fflush+0x82>
			mutex_unlock(buffer_lock);
    114c:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1150:	00001797          	auipc	a5,0x1
    1154:	6607a423          	sw	zero,1640(a5) # 27b8 <buffer_len>
			mutex_unlock(buffer_lock);
    1158:	4d6010ef          	jal	ra,262e <mutex_unlock>
    115c:	bf41                	j	10ec <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    115e:	8622                	mv	a2,s0
    1160:	00001597          	auipc	a1,0x1
    1164:	66058593          	addi	a1,a1,1632 # 27c0 <buffer>
    1168:	4505                	li	a0,1
    116a:	240010ef          	jal	ra,23aa <write>
	return r >= 0 ? 0 : r;
    116e:	0005079b          	sext.w	a5,a0
    1172:	0017a793          	slti	a5,a5,1
    1176:	40f007bb          	negw	a5,a5
    117a:	8d7d                	and	a0,a0,a5
    117c:	0005041b          	sext.w	s0,a0
	return r;
    1180:	b7f1                	j	114c <fflush+0x70>

0000000000001182 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1182:	7131                	addi	sp,sp,-192
    1184:	e0da                	sd	s6,64(sp)
    1186:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1188:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    118a:	013c                	addi	a5,sp,136
{
    118c:	f0ca                	sd	s2,96(sp)
    118e:	ecce                	sd	s3,88(sp)
    1190:	e8d2                	sd	s4,80(sp)
    1192:	e4d6                	sd	s5,72(sp)
    1194:	fc86                	sd	ra,120(sp)
    1196:	f8a2                	sd	s0,112(sp)
    1198:	f4a6                	sd	s1,104(sp)
    119a:	89aa                	mv	s3,a0
    119c:	e52e                	sd	a1,136(sp)
    119e:	e932                	sd	a2,144(sp)
    11a0:	ed36                	sd	a3,152(sp)
    11a2:	f13a                	sd	a4,160(sp)
    11a4:	f942                	sd	a6,176(sp)
    11a6:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11a8:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11aa:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11ae:	00001a17          	auipc	s4,0x1
    11b2:	60aa0a13          	addi	s4,s4,1546 # 27b8 <buffer_len>
    11b6:	4a85                	li	s5,1
	buf[i++] = '0';
    11b8:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11bc:	0009c783          	lbu	a5,0(s3)
    11c0:	18078663          	beqz	a5,134c <printf+0x1ca>
    11c4:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11c6:	19278d63          	beq	a5,s2,1360 <printf+0x1de>
    11ca:	0015c783          	lbu	a5,1(a1)
    11ce:	0585                	addi	a1,a1,1
    11d0:	fbfd                	bnez	a5,11c6 <printf+0x44>
    11d2:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11d4:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    11d8:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    11dc:	1b578863          	beq	a5,s5,138c <printf+0x20a>
		len = out_unlocked(s, l);
    11e0:	85a2                	mv	a1,s0
    11e2:	854e                	mv	a0,s3
    11e4:	42a000ef          	jal	ra,160e <out_unlocked>
		out(f, a, l);
		if (l)
    11e8:	1c041063          	bnez	s0,13a8 <printf+0x226>
			continue;
		if (s[1] == 0)
    11ec:	0014c783          	lbu	a5,1(s1)
    11f0:	14078e63          	beqz	a5,134c <printf+0x1ca>
			break;
		switch (s[1]) {
    11f4:	07300713          	li	a4,115
    11f8:	1ce78863          	beq	a5,a4,13c8 <printf+0x246>
    11fc:	1af76863          	bltu	a4,a5,13ac <printf+0x22a>
    1200:	06400713          	li	a4,100
    1204:	22e78063          	beq	a5,a4,1424 <printf+0x2a2>
    1208:	07000713          	li	a4,112
    120c:	1ee79563          	bne	a5,a4,13f6 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1210:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1212:	00001797          	auipc	a5,0x1
    1216:	6b678793          	addi	a5,a5,1718 # 28c8 <digits>
	buf[i++] = '0';
    121a:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    121e:	6298                	ld	a4,0(a3)
    1220:	06a1                	addi	a3,a3,8
    1222:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1224:	00471393          	slli	t2,a4,0x4
    1228:	00871293          	slli	t0,a4,0x8
    122c:	00c71f93          	slli	t6,a4,0xc
    1230:	01071f13          	slli	t5,a4,0x10
    1234:	01471e93          	slli	t4,a4,0x14
    1238:	01871e13          	slli	t3,a4,0x18
    123c:	01c71893          	slli	a7,a4,0x1c
    1240:	02471813          	slli	a6,a4,0x24
    1244:	02871513          	slli	a0,a4,0x28
    1248:	02c71593          	slli	a1,a4,0x2c
    124c:	03071613          	slli	a2,a4,0x30
    1250:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1254:	03c75413          	srli	s0,a4,0x3c
    1258:	01c7531b          	srliw	t1,a4,0x1c
    125c:	03c3d393          	srli	t2,t2,0x3c
    1260:	03c2d293          	srli	t0,t0,0x3c
    1264:	03cfdf93          	srli	t6,t6,0x3c
    1268:	03cf5f13          	srli	t5,t5,0x3c
    126c:	03cede93          	srli	t4,t4,0x3c
    1270:	03ce5e13          	srli	t3,t3,0x3c
    1274:	03c8d893          	srli	a7,a7,0x3c
    1278:	03c85813          	srli	a6,a6,0x3c
    127c:	9171                	srli	a0,a0,0x3c
    127e:	91f1                	srli	a1,a1,0x3c
    1280:	9271                	srli	a2,a2,0x3c
    1282:	92f1                	srli	a3,a3,0x3c
    1284:	95be                	add	a1,a1,a5
    1286:	963e                	add	a2,a2,a5
    1288:	96be                	add	a3,a3,a5
    128a:	943e                	add	s0,s0,a5
    128c:	93be                	add	t2,t2,a5
    128e:	92be                	add	t0,t0,a5
    1290:	9fbe                	add	t6,t6,a5
    1292:	9f3e                	add	t5,t5,a5
    1294:	9ebe                	add	t4,t4,a5
    1296:	9e3e                	add	t3,t3,a5
    1298:	98be                	add	a7,a7,a5
    129a:	933e                	add	t1,t1,a5
    129c:	983e                	add	a6,a6,a5
    129e:	953e                	add	a0,a0,a5
    12a0:	0005c983          	lbu	s3,0(a1)
    12a4:	00044403          	lbu	s0,0(s0)
    12a8:	00064583          	lbu	a1,0(a2)
    12ac:	0003c383          	lbu	t2,0(t2)
    12b0:	0006c603          	lbu	a2,0(a3)
    12b4:	0002c283          	lbu	t0,0(t0)
    12b8:	000fcf83          	lbu	t6,0(t6)
    12bc:	000f4f03          	lbu	t5,0(t5)
    12c0:	000ece83          	lbu	t4,0(t4)
    12c4:	000e4e03          	lbu	t3,0(t3)
    12c8:	0008c883          	lbu	a7,0(a7)
    12cc:	00034303          	lbu	t1,0(t1)
    12d0:	00084803          	lbu	a6,0(a6)
    12d4:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12d8:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12dc:	92f1                	srli	a3,a3,0x3c
    12de:	8b3d                	andi	a4,a4,15
    12e0:	96be                	add	a3,a3,a5
    12e2:	97ba                	add	a5,a5,a4
    12e4:	00810d23          	sb	s0,26(sp)
    12e8:	00710da3          	sb	t2,27(sp)
    12ec:	00510e23          	sb	t0,28(sp)
    12f0:	01f10ea3          	sb	t6,29(sp)
    12f4:	01e10f23          	sb	t5,30(sp)
    12f8:	01d10fa3          	sb	t4,31(sp)
    12fc:	03c10023          	sb	t3,32(sp)
    1300:	031100a3          	sb	a7,33(sp)
    1304:	02610123          	sb	t1,34(sp)
    1308:	030101a3          	sb	a6,35(sp)
    130c:	02a10223          	sb	a0,36(sp)
    1310:	033102a3          	sb	s3,37(sp)
    1314:	02b10323          	sb	a1,38(sp)
    1318:	02c103a3          	sb	a2,39(sp)
    131c:	0006c683          	lbu	a3,0(a3)
    1320:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1324:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1328:	02d10423          	sb	a3,40(sp)
    132c:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1330:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1334:	11578263          	beq	a5,s5,1438 <printf+0x2b6>
		len = out_unlocked(s, l);
    1338:	45c9                	li	a1,18
    133a:	0828                	addi	a0,sp,24
    133c:	2d2000ef          	jal	ra,160e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1340:	00248993          	addi	s3,s1,2
		if (!*s)
    1344:	0009c783          	lbu	a5,0(s3)
    1348:	e6079ee3          	bnez	a5,11c4 <printf+0x42>
	}
	va_end(ap);
    134c:	70e6                	ld	ra,120(sp)
    134e:	7446                	ld	s0,112(sp)
    1350:	74a6                	ld	s1,104(sp)
    1352:	7906                	ld	s2,96(sp)
    1354:	69e6                	ld	s3,88(sp)
    1356:	6a46                	ld	s4,80(sp)
    1358:	6aa6                	ld	s5,72(sp)
    135a:	6b06                	ld	s6,64(sp)
    135c:	6129                	addi	sp,sp,192
    135e:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1360:	0005c783          	lbu	a5,0(a1)
    1364:	84ae                	mv	s1,a1
    1366:	01278963          	beq	a5,s2,1378 <printf+0x1f6>
    136a:	b5ad                	j	11d4 <printf+0x52>
    136c:	0024c783          	lbu	a5,2(s1)
    1370:	0585                	addi	a1,a1,1
    1372:	0489                	addi	s1,s1,2
    1374:	e72790e3          	bne	a5,s2,11d4 <printf+0x52>
    1378:	0014c783          	lbu	a5,1(s1)
    137c:	ff2788e3          	beq	a5,s2,136c <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1380:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1384:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1388:	e5579ce3          	bne	a5,s5,11e0 <printf+0x5e>
		mutex_lock(buffer_lock);
    138c:	10ca2503          	lw	a0,268(s4)
    1390:	292010ef          	jal	ra,2622 <mutex_lock>
		len = out_unlocked(s, l);
    1394:	85a2                	mv	a1,s0
    1396:	854e                	mv	a0,s3
    1398:	276000ef          	jal	ra,160e <out_unlocked>
		mutex_unlock(buffer_lock);
    139c:	10ca2503          	lw	a0,268(s4)
    13a0:	28e010ef          	jal	ra,262e <mutex_unlock>
		if (l)
    13a4:	e40404e3          	beqz	s0,11ec <printf+0x6a>
    13a8:	89a6                	mv	s3,s1
    13aa:	bd09                	j	11bc <printf+0x3a>
		switch (s[1]) {
    13ac:	07800713          	li	a4,120
    13b0:	04e79363          	bne	a5,a4,13f6 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13b4:	67c2                	ld	a5,16(sp)
    13b6:	45c1                	li	a1,16
		s += 2;
    13b8:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13bc:	4388                	lw	a0,0(a5)
    13be:	07a1                	addi	a5,a5,8
    13c0:	e83e                	sd	a5,16(sp)
    13c2:	5f8000ef          	jal	ra,19ba <printint.constprop.0>
		s += 2;
    13c6:	bfbd                	j	1344 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13c8:	67c2                	ld	a5,16(sp)
    13ca:	6380                	ld	s0,0(a5)
    13cc:	07a1                	addi	a5,a5,8
    13ce:	e83e                	sd	a5,16(sp)
    13d0:	1c040163          	beqz	s0,1592 <printf+0x410>
			l = strnlen(a, 200);
    13d4:	0c800593          	li	a1,200
    13d8:	8522                	mv	a0,s0
    13da:	3f7000ef          	jal	ra,1fd0 <strnlen>
	if (buffer_lock_enabled == 1) {
    13de:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    13e2:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    13e6:	19578663          	beq	a5,s5,1572 <printf+0x3f0>
		len = out_unlocked(s, l);
    13ea:	8522                	mv	a0,s0
    13ec:	222000ef          	jal	ra,160e <out_unlocked>
		s += 2;
    13f0:	00248993          	addi	s3,s1,2
    13f4:	bf81                	j	1344 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    13f6:	108a2783          	lw	a5,264(s4)
	char byte = c;
    13fa:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    13fe:	0f578663          	beq	a5,s5,14ea <printf+0x368>
		len = out_unlocked(s, l);
    1402:	0828                	addi	a0,sp,24
    1404:	316000ef          	jal	ra,171a <out_unlocked.constprop.0>
			putchar(s[1]);
    1408:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    140c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1410:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1414:	05578163          	beq	a5,s5,1456 <printf+0x2d4>
		len = out_unlocked(s, l);
    1418:	0828                	addi	a0,sp,24
    141a:	300000ef          	jal	ra,171a <out_unlocked.constprop.0>
		s += 2;
    141e:	00248993          	addi	s3,s1,2
    1422:	b70d                	j	1344 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1424:	67c2                	ld	a5,16(sp)
    1426:	45a9                	li	a1,10
		s += 2;
    1428:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    142c:	4388                	lw	a0,0(a5)
    142e:	07a1                	addi	a5,a5,8
    1430:	e83e                	sd	a5,16(sp)
    1432:	588000ef          	jal	ra,19ba <printint.constprop.0>
		s += 2;
    1436:	b739                	j	1344 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1438:	10ca2503          	lw	a0,268(s4)
		s += 2;
    143c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1440:	1e2010ef          	jal	ra,2622 <mutex_lock>
		len = out_unlocked(s, l);
    1444:	45c9                	li	a1,18
    1446:	0828                	addi	a0,sp,24
    1448:	1c6000ef          	jal	ra,160e <out_unlocked>
		mutex_unlock(buffer_lock);
    144c:	10ca2503          	lw	a0,268(s4)
    1450:	1de010ef          	jal	ra,262e <mutex_unlock>
		s += 2;
    1454:	bdc5                	j	1344 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1456:	10ca2503          	lw	a0,268(s4)
    145a:	1c8010ef          	jal	ra,2622 <mutex_lock>
		buffer[buffer_len++] = c;
    145e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1462:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1466:	0017861b          	addiw	a2,a5,1
    146a:	97d2                	add	a5,a5,s4
    146c:	00ca2023          	sw	a2,0(s4)
    1470:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1474:	00c6cc63          	blt	a3,a2,148c <printf+0x30a>
    1478:	47a9                	li	a5,10
    147a:	06f40663          	beq	s0,a5,14e6 <printf+0x364>
		mutex_unlock(buffer_lock);
    147e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1482:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1486:	1a8010ef          	jal	ra,262e <mutex_unlock>
		s += 2;
    148a:	bd6d                	j	1344 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    148c:	10000793          	li	a5,256
    1490:	00f61e63          	bne	a2,a5,14ac <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1494:	00001597          	auipc	a1,0x1
    1498:	32c58593          	addi	a1,a1,812 # 27c0 <buffer>
    149c:	4505                	li	a0,1
    149e:	70d000ef          	jal	ra,23aa <write>
	buffer_len = 0;
    14a2:	00001797          	auipc	a5,0x1
    14a6:	3007ab23          	sw	zero,790(a5) # 27b8 <buffer_len>
			if (r < 0) {
    14aa:	bfd1                	j	147e <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14ac:	709000ef          	jal	ra,23b4 <getpid>
    14b0:	842a                	mv	s0,a0
    14b2:	00001517          	auipc	a0,0x1
    14b6:	20e50513          	addi	a0,a0,526 # 26c0 <enable_deadlock_detect+0x3e>
    14ba:	5d1000ef          	jal	ra,228a <basename>
    14be:	872a                	mv	a4,a0
    14c0:	00001617          	auipc	a2,0x1
    14c4:	24060613          	addi	a2,a2,576 # 2700 <enable_deadlock_detect+0x7e>
    14c8:	05400793          	li	a5,84
    14cc:	86a2                	mv	a3,s0
    14ce:	45fd                	li	a1,31
    14d0:	00001517          	auipc	a0,0x1
    14d4:	23850513          	addi	a0,a0,568 # 2708 <enable_deadlock_detect+0x86>
    14d8:	cabff0ef          	jal	ra,1182 <printf>
    14dc:	557d                	li	a0,-1
    14de:	707000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    14e2:	000a2603          	lw	a2,0(s4)
    14e6:	de41                	beqz	a2,147e <printf+0x2fc>
    14e8:	b775                	j	1494 <printf+0x312>
		mutex_lock(buffer_lock);
    14ea:	10ca2503          	lw	a0,268(s4)
    14ee:	134010ef          	jal	ra,2622 <mutex_lock>
		buffer[buffer_len++] = c;
    14f2:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14f6:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14fa:	0017861b          	addiw	a2,a5,1
    14fe:	97d2                	add	a5,a5,s4
    1500:	00ca2023          	sw	a2,0(s4)
    1504:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1508:	02c6d163          	bge	a3,a2,152a <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    150c:	10000793          	li	a5,256
    1510:	02f61263          	bne	a2,a5,1534 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1514:	00001597          	auipc	a1,0x1
    1518:	2ac58593          	addi	a1,a1,684 # 27c0 <buffer>
    151c:	4505                	li	a0,1
    151e:	68d000ef          	jal	ra,23aa <write>
	buffer_len = 0;
    1522:	00001797          	auipc	a5,0x1
    1526:	2807ab23          	sw	zero,662(a5) # 27b8 <buffer_len>
		mutex_unlock(buffer_lock);
    152a:	10ca2503          	lw	a0,268(s4)
    152e:	100010ef          	jal	ra,262e <mutex_unlock>
    1532:	bdd9                	j	1408 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1534:	681000ef          	jal	ra,23b4 <getpid>
    1538:	842a                	mv	s0,a0
    153a:	00001517          	auipc	a0,0x1
    153e:	18650513          	addi	a0,a0,390 # 26c0 <enable_deadlock_detect+0x3e>
    1542:	549000ef          	jal	ra,228a <basename>
    1546:	872a                	mv	a4,a0
    1548:	00001617          	auipc	a2,0x1
    154c:	1b860613          	addi	a2,a2,440 # 2700 <enable_deadlock_detect+0x7e>
    1550:	05400793          	li	a5,84
    1554:	86a2                	mv	a3,s0
    1556:	45fd                	li	a1,31
    1558:	00001517          	auipc	a0,0x1
    155c:	1b050513          	addi	a0,a0,432 # 2708 <enable_deadlock_detect+0x86>
    1560:	c23ff0ef          	jal	ra,1182 <printf>
    1564:	557d                	li	a0,-1
    1566:	67f000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    156a:	000a2603          	lw	a2,0(s4)
    156e:	de55                	beqz	a2,152a <printf+0x3a8>
    1570:	b755                	j	1514 <printf+0x392>
		mutex_lock(buffer_lock);
    1572:	10ca2503          	lw	a0,268(s4)
    1576:	e42e                	sd	a1,8(sp)
		s += 2;
    1578:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    157c:	0a6010ef          	jal	ra,2622 <mutex_lock>
		len = out_unlocked(s, l);
    1580:	65a2                	ld	a1,8(sp)
    1582:	8522                	mv	a0,s0
    1584:	08a000ef          	jal	ra,160e <out_unlocked>
		mutex_unlock(buffer_lock);
    1588:	10ca2503          	lw	a0,268(s4)
    158c:	0a2010ef          	jal	ra,262e <mutex_unlock>
		s += 2;
    1590:	bb55                	j	1344 <printf+0x1c2>
				a = "(null)";
    1592:	00001417          	auipc	s0,0x1
    1596:	12640413          	addi	s0,s0,294 # 26b8 <enable_deadlock_detect+0x36>
    159a:	bd2d                	j	13d4 <printf+0x252>

000000000000159c <enable_thread_io_buffer>:
{
    159c:	1101                	addi	sp,sp,-32
    159e:	e822                	sd	s0,16(sp)
    15a0:	ec06                	sd	ra,24(sp)
    15a2:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15a4:	00001417          	auipc	s0,0x1
    15a8:	21440413          	addi	s0,s0,532 # 27b8 <buffer_len>
    15ac:	05a010ef          	jal	ra,2606 <mutex_create>
    15b0:	10a42623          	sw	a0,268(s0)
    15b4:	00054a63          	bltz	a0,15c8 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15b8:	4785                	li	a5,1
}
    15ba:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15bc:	10f42423          	sw	a5,264(s0)
}
    15c0:	6442                	ld	s0,16(sp)
    15c2:	64a2                	ld	s1,8(sp)
    15c4:	6105                	addi	sp,sp,32
    15c6:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15c8:	5ed000ef          	jal	ra,23b4 <getpid>
    15cc:	84aa                	mv	s1,a0
    15ce:	00001517          	auipc	a0,0x1
    15d2:	0f250513          	addi	a0,a0,242 # 26c0 <enable_deadlock_detect+0x3e>
    15d6:	4b5000ef          	jal	ra,228a <basename>
    15da:	872a                	mv	a4,a0
    15dc:	04800793          	li	a5,72
    15e0:	86a6                	mv	a3,s1
    15e2:	00001517          	auipc	a0,0x1
    15e6:	16650513          	addi	a0,a0,358 # 2748 <enable_deadlock_detect+0xc6>
    15ea:	00001617          	auipc	a2,0x1
    15ee:	11660613          	addi	a2,a2,278 # 2700 <enable_deadlock_detect+0x7e>
    15f2:	45fd                	li	a1,31
    15f4:	b8fff0ef          	jal	ra,1182 <printf>
    15f8:	557d                	li	a0,-1
    15fa:	5eb000ef          	jal	ra,23e4 <exit>
	buffer_lock_enabled = 1;
    15fe:	4785                	li	a5,1
}
    1600:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1602:	10f42423          	sw	a5,264(s0)
}
    1606:	6442                	ld	s0,16(sp)
    1608:	64a2                	ld	s1,8(sp)
    160a:	6105                	addi	sp,sp,32
    160c:	8082                	ret

000000000000160e <out_unlocked>:
{
    160e:	7159                	addi	sp,sp,-112
    1610:	f486                	sd	ra,104(sp)
    1612:	f0a2                	sd	s0,96(sp)
    1614:	eca6                	sd	s1,88(sp)
    1616:	e8ca                	sd	s2,80(sp)
    1618:	e4ce                	sd	s3,72(sp)
    161a:	e0d2                	sd	s4,64(sp)
    161c:	fc56                	sd	s5,56(sp)
    161e:	f85a                	sd	s6,48(sp)
    1620:	f45e                	sd	s7,40(sp)
    1622:	f062                	sd	s8,32(sp)
    1624:	ec66                	sd	s9,24(sp)
    1626:	e86a                	sd	s10,16(sp)
    1628:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    162a:	0e058663          	beqz	a1,1716 <out_unlocked+0x108>
    162e:	842a                	mv	s0,a0
    1630:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1634:	4981                	li	s3,0
    1636:	00001d17          	auipc	s10,0x1
    163a:	182d0d13          	addi	s10,s10,386 # 27b8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    163e:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1642:	00001b17          	auipc	s6,0x1
    1646:	17eb0b13          	addi	s6,s6,382 # 27c0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    164a:	10000a93          	li	s5,256
    164e:	00001c97          	auipc	s9,0x1
    1652:	072c8c93          	addi	s9,s9,114 # 26c0 <enable_deadlock_detect+0x3e>
    1656:	00001c17          	auipc	s8,0x1
    165a:	0aac0c13          	addi	s8,s8,170 # 2700 <enable_deadlock_detect+0x7e>
    165e:	00001b97          	auipc	s7,0x1
    1662:	0aab8b93          	addi	s7,s7,170 # 2708 <enable_deadlock_detect+0x86>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1666:	4a29                	li	s4,10
    1668:	a031                	j	1674 <out_unlocked+0x66>
    166a:	09468863          	beq	a3,s4,16fa <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    166e:	0405                	addi	s0,s0,1
    1670:	04848163          	beq	s1,s0,16b2 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1674:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1678:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    167c:	0017861b          	addiw	a2,a5,1
    1680:	97ea                	add	a5,a5,s10
    1682:	00cd2023          	sw	a2,0(s10)
    1686:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168a:	fec950e3          	bge	s2,a2,166a <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    168e:	05561263          	bne	a2,s5,16d2 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1692:	85da                	mv	a1,s6
    1694:	4505                	li	a0,1
    1696:	515000ef          	jal	ra,23aa <write>
    169a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    169c:	00001797          	auipc	a5,0x1
    16a0:	1007ae23          	sw	zero,284(a5) # 27b8 <buffer_len>
			if (r < 0) {
    16a4:	06054763          	bltz	a0,1712 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16a8:	0405                	addi	s0,s0,1
			ret += r;
    16aa:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16ae:	fc8493e3          	bne	s1,s0,1674 <out_unlocked+0x66>
}
    16b2:	70a6                	ld	ra,104(sp)
    16b4:	7406                	ld	s0,96(sp)
    16b6:	64e6                	ld	s1,88(sp)
    16b8:	6946                	ld	s2,80(sp)
    16ba:	6a06                	ld	s4,64(sp)
    16bc:	7ae2                	ld	s5,56(sp)
    16be:	7b42                	ld	s6,48(sp)
    16c0:	7ba2                	ld	s7,40(sp)
    16c2:	7c02                	ld	s8,32(sp)
    16c4:	6ce2                	ld	s9,24(sp)
    16c6:	6d42                	ld	s10,16(sp)
    16c8:	6da2                	ld	s11,8(sp)
    16ca:	854e                	mv	a0,s3
    16cc:	69a6                	ld	s3,72(sp)
    16ce:	6165                	addi	sp,sp,112
    16d0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16d2:	4e3000ef          	jal	ra,23b4 <getpid>
    16d6:	8daa                	mv	s11,a0
    16d8:	8566                	mv	a0,s9
    16da:	3b1000ef          	jal	ra,228a <basename>
    16de:	872a                	mv	a4,a0
    16e0:	8662                	mv	a2,s8
    16e2:	05400793          	li	a5,84
    16e6:	86ee                	mv	a3,s11
    16e8:	45fd                	li	a1,31
    16ea:	855e                	mv	a0,s7
    16ec:	a97ff0ef          	jal	ra,1182 <printf>
    16f0:	557d                	li	a0,-1
    16f2:	4f3000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    16f6:	000d2603          	lw	a2,0(s10)
    16fa:	da35                	beqz	a2,166e <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    16fc:	85da                	mv	a1,s6
    16fe:	4505                	li	a0,1
    1700:	4ab000ef          	jal	ra,23aa <write>
    1704:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1706:	00001797          	auipc	a5,0x1
    170a:	0a07a923          	sw	zero,178(a5) # 27b8 <buffer_len>
			if (r < 0) {
    170e:	f8055de3          	bgez	a0,16a8 <out_unlocked+0x9a>
    1712:	89aa                	mv	s3,a0
    1714:	bf79                	j	16b2 <out_unlocked+0xa4>
	int ret = 0;
    1716:	4981                	li	s3,0
    1718:	bf69                	j	16b2 <out_unlocked+0xa4>

000000000000171a <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    171a:	1101                	addi	sp,sp,-32
    171c:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    171e:	00001497          	auipc	s1,0x1
    1722:	09a48493          	addi	s1,s1,154 # 27b8 <buffer_len>
    1726:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1728:	ec06                	sd	ra,24(sp)
    172a:	e822                	sd	s0,16(sp)
		char c = s[i];
    172c:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1730:	0017861b          	addiw	a2,a5,1
    1734:	97a6                	add	a5,a5,s1
    1736:	00e78423          	sb	a4,8(a5)
    173a:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    173c:	0ff00793          	li	a5,255
    1740:	00c7cc63          	blt	a5,a2,1758 <out_unlocked.constprop.0+0x3e>
    1744:	47a9                	li	a5,10
    1746:	06f70c63          	beq	a4,a5,17be <out_unlocked.constprop.0+0xa4>
    174a:	4601                	li	a2,0
}
    174c:	60e2                	ld	ra,24(sp)
    174e:	6442                	ld	s0,16(sp)
    1750:	64a2                	ld	s1,8(sp)
    1752:	8532                	mv	a0,a2
    1754:	6105                	addi	sp,sp,32
    1756:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1758:	10000793          	li	a5,256
    175c:	02f61563          	bne	a2,a5,1786 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1760:	00001597          	auipc	a1,0x1
    1764:	06058593          	addi	a1,a1,96 # 27c0 <buffer>
    1768:	4505                	li	a0,1
    176a:	441000ef          	jal	ra,23aa <write>
}
    176e:	60e2                	ld	ra,24(sp)
    1770:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1772:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1776:	00001797          	auipc	a5,0x1
    177a:	0407a123          	sw	zero,66(a5) # 27b8 <buffer_len>
}
    177e:	64a2                	ld	s1,8(sp)
    1780:	8532                	mv	a0,a2
    1782:	6105                	addi	sp,sp,32
    1784:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1786:	42f000ef          	jal	ra,23b4 <getpid>
    178a:	842a                	mv	s0,a0
    178c:	00001517          	auipc	a0,0x1
    1790:	f3450513          	addi	a0,a0,-204 # 26c0 <enable_deadlock_detect+0x3e>
    1794:	2f7000ef          	jal	ra,228a <basename>
    1798:	872a                	mv	a4,a0
    179a:	00001617          	auipc	a2,0x1
    179e:	f6660613          	addi	a2,a2,-154 # 2700 <enable_deadlock_detect+0x7e>
    17a2:	05400793          	li	a5,84
    17a6:	86a2                	mv	a3,s0
    17a8:	45fd                	li	a1,31
    17aa:	00001517          	auipc	a0,0x1
    17ae:	f5e50513          	addi	a0,a0,-162 # 2708 <enable_deadlock_detect+0x86>
    17b2:	9d1ff0ef          	jal	ra,1182 <printf>
    17b6:	557d                	li	a0,-1
    17b8:	42d000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    17bc:	4090                	lw	a2,0(s1)
    17be:	d659                	beqz	a2,174c <out_unlocked.constprop.0+0x32>
    17c0:	b745                	j	1760 <out_unlocked.constprop.0+0x46>

00000000000017c2 <putchar>:
{
    17c2:	7139                	addi	sp,sp,-64
    17c4:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17c6:	00001497          	auipc	s1,0x1
    17ca:	ff248493          	addi	s1,s1,-14 # 27b8 <buffer_len>
    17ce:	1084a703          	lw	a4,264(s1)
{
    17d2:	f822                	sd	s0,48(sp)
	char byte = c;
    17d4:	0ff57413          	zext.b	s0,a0
{
    17d8:	fc06                	sd	ra,56(sp)
	char byte = c;
    17da:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    17de:	4785                	li	a5,1
    17e0:	00f70d63          	beq	a4,a5,17fa <putchar+0x38>
		len = out_unlocked(s, l);
    17e4:	01f10513          	addi	a0,sp,31
    17e8:	f33ff0ef          	jal	ra,171a <out_unlocked.constprop.0>
}
    17ec:	70e2                	ld	ra,56(sp)
    17ee:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    17f0:	862a                	mv	a2,a0
}
    17f2:	74a2                	ld	s1,40(sp)
    17f4:	8532                	mv	a0,a2
    17f6:	6121                	addi	sp,sp,64
    17f8:	8082                	ret
		mutex_lock(buffer_lock);
    17fa:	10c4a503          	lw	a0,268(s1)
    17fe:	625000ef          	jal	ra,2622 <mutex_lock>
		buffer[buffer_len++] = c;
    1802:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1804:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1808:	0017861b          	addiw	a2,a5,1
    180c:	97a6                	add	a5,a5,s1
    180e:	c090                	sw	a2,0(s1)
    1810:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1814:	02c6c263          	blt	a3,a2,1838 <putchar+0x76>
    1818:	47a9                	li	a5,10
    181a:	06f40d63          	beq	s0,a5,1894 <putchar+0xd2>
    181e:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1820:	10c4a503          	lw	a0,268(s1)
    1824:	e432                	sd	a2,8(sp)
    1826:	609000ef          	jal	ra,262e <mutex_unlock>
    182a:	6622                	ld	a2,8(sp)
}
    182c:	70e2                	ld	ra,56(sp)
    182e:	7442                	ld	s0,48(sp)
    1830:	74a2                	ld	s1,40(sp)
    1832:	8532                	mv	a0,a2
    1834:	6121                	addi	sp,sp,64
    1836:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1838:	10000793          	li	a5,256
    183c:	02f61063          	bne	a2,a5,185c <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1840:	00001597          	auipc	a1,0x1
    1844:	f8058593          	addi	a1,a1,-128 # 27c0 <buffer>
    1848:	4505                	li	a0,1
    184a:	361000ef          	jal	ra,23aa <write>
    184e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1852:	00001797          	auipc	a5,0x1
    1856:	f607a323          	sw	zero,-154(a5) # 27b8 <buffer_len>
			if (r < 0) {
    185a:	b7d9                	j	1820 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    185c:	359000ef          	jal	ra,23b4 <getpid>
    1860:	842a                	mv	s0,a0
    1862:	00001517          	auipc	a0,0x1
    1866:	e5e50513          	addi	a0,a0,-418 # 26c0 <enable_deadlock_detect+0x3e>
    186a:	221000ef          	jal	ra,228a <basename>
    186e:	872a                	mv	a4,a0
    1870:	00001617          	auipc	a2,0x1
    1874:	e9060613          	addi	a2,a2,-368 # 2700 <enable_deadlock_detect+0x7e>
    1878:	05400793          	li	a5,84
    187c:	86a2                	mv	a3,s0
    187e:	45fd                	li	a1,31
    1880:	00001517          	auipc	a0,0x1
    1884:	e8850513          	addi	a0,a0,-376 # 2708 <enable_deadlock_detect+0x86>
    1888:	8fbff0ef          	jal	ra,1182 <printf>
    188c:	557d                	li	a0,-1
    188e:	357000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    1892:	4090                	lw	a2,0(s1)
    1894:	d651                	beqz	a2,1820 <putchar+0x5e>
    1896:	b76d                	j	1840 <putchar+0x7e>

0000000000001898 <puts>:
{
    1898:	7139                	addi	sp,sp,-64
    189a:	f822                	sd	s0,48(sp)
    189c:	f426                	sd	s1,40(sp)
    189e:	fc06                	sd	ra,56(sp)
    18a0:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18a2:	00001417          	auipc	s0,0x1
    18a6:	f1640413          	addi	s0,s0,-234 # 27b8 <buffer_len>
{
    18aa:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ac:	638000ef          	jal	ra,1ee4 <strlen>
	if (buffer_lock_enabled == 1) {
    18b0:	10842703          	lw	a4,264(s0)
    18b4:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18b6:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18b8:	04f70563          	beq	a4,a5,1902 <puts+0x6a>
		len = out_unlocked(s, l);
    18bc:	8526                	mv	a0,s1
    18be:	d51ff0ef          	jal	ra,160e <out_unlocked>
    18c2:	892a                	mv	s2,a0
    18c4:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18c6:	00095963          	bgez	s2,18d8 <puts+0x40>
}
    18ca:	70e2                	ld	ra,56(sp)
    18cc:	7442                	ld	s0,48(sp)
    18ce:	7902                	ld	s2,32(sp)
    18d0:	8526                	mv	a0,s1
    18d2:	74a2                	ld	s1,40(sp)
    18d4:	6121                	addi	sp,sp,64
    18d6:	8082                	ret
	if (buffer_lock_enabled == 1) {
    18d8:	10842703          	lw	a4,264(s0)
	char byte = c;
    18dc:	44a9                	li	s1,10
    18de:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    18e2:	4785                	li	a5,1
    18e4:	02f70e63          	beq	a4,a5,1920 <puts+0x88>
		len = out_unlocked(s, l);
    18e8:	01f10513          	addi	a0,sp,31
    18ec:	e2fff0ef          	jal	ra,171a <out_unlocked.constprop.0>
}
    18f0:	70e2                	ld	ra,56(sp)
    18f2:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18f4:	41f5549b          	sraiw	s1,a0,0x1f
}
    18f8:	7902                	ld	s2,32(sp)
    18fa:	8526                	mv	a0,s1
    18fc:	74a2                	ld	s1,40(sp)
    18fe:	6121                	addi	sp,sp,64
    1900:	8082                	ret
		mutex_lock(buffer_lock);
    1902:	e42a                	sd	a0,8(sp)
    1904:	10c42503          	lw	a0,268(s0)
    1908:	51b000ef          	jal	ra,2622 <mutex_lock>
		len = out_unlocked(s, l);
    190c:	65a2                	ld	a1,8(sp)
    190e:	8526                	mv	a0,s1
    1910:	cffff0ef          	jal	ra,160e <out_unlocked>
    1914:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1916:	10c42503          	lw	a0,268(s0)
    191a:	515000ef          	jal	ra,262e <mutex_unlock>
    191e:	b75d                	j	18c4 <puts+0x2c>
		mutex_lock(buffer_lock);
    1920:	10c42503          	lw	a0,268(s0)
    1924:	4ff000ef          	jal	ra,2622 <mutex_lock>
		buffer[buffer_len++] = c;
    1928:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    192a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    192e:	0017861b          	addiw	a2,a5,1
    1932:	97a2                	add	a5,a5,s0
    1934:	c010                	sw	a2,0(s0)
    1936:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    193a:	06c6dc63          	bge	a3,a2,19b2 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    193e:	10000793          	li	a5,256
    1942:	02f61c63          	bne	a2,a5,197a <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1946:	00001597          	auipc	a1,0x1
    194a:	e7a58593          	addi	a1,a1,-390 # 27c0 <buffer>
    194e:	4505                	li	a0,1
    1950:	25b000ef          	jal	ra,23aa <write>
			if (r < 0) {
    1954:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1956:	00001797          	auipc	a5,0x1
    195a:	e607a123          	sw	zero,-414(a5) # 27b8 <buffer_len>
			if (r < 0) {
    195e:	04054c63          	bltz	a0,19b6 <puts+0x11e>
			if (r < buffer_len) {
    1962:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1964:	10c42503          	lw	a0,268(s0)
    1968:	4c7000ef          	jal	ra,262e <mutex_unlock>
}
    196c:	70e2                	ld	ra,56(sp)
    196e:	7442                	ld	s0,48(sp)
    1970:	7902                	ld	s2,32(sp)
    1972:	8526                	mv	a0,s1
    1974:	74a2                	ld	s1,40(sp)
    1976:	6121                	addi	sp,sp,64
    1978:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    197a:	23b000ef          	jal	ra,23b4 <getpid>
    197e:	84aa                	mv	s1,a0
    1980:	00001517          	auipc	a0,0x1
    1984:	d4050513          	addi	a0,a0,-704 # 26c0 <enable_deadlock_detect+0x3e>
    1988:	103000ef          	jal	ra,228a <basename>
    198c:	872a                	mv	a4,a0
    198e:	00001617          	auipc	a2,0x1
    1992:	d7260613          	addi	a2,a2,-654 # 2700 <enable_deadlock_detect+0x7e>
    1996:	05400793          	li	a5,84
    199a:	86a6                	mv	a3,s1
    199c:	45fd                	li	a1,31
    199e:	00001517          	auipc	a0,0x1
    19a2:	d6a50513          	addi	a0,a0,-662 # 2708 <enable_deadlock_detect+0x86>
    19a6:	fdcff0ef          	jal	ra,1182 <printf>
    19aa:	557d                	li	a0,-1
    19ac:	239000ef          	jal	ra,23e4 <exit>
	if (buffer_len == 0)
    19b0:	4010                	lw	a2,0(s0)
    19b2:	da45                	beqz	a2,1962 <puts+0xca>
    19b4:	bf49                	j	1946 <puts+0xae>
    19b6:	54fd                	li	s1,-1
    19b8:	b775                	j	1964 <puts+0xcc>

00000000000019ba <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19ba:	715d                	addi	sp,sp,-80
    19bc:	e486                	sd	ra,72(sp)
    19be:	e0a2                	sd	s0,64(sp)
    19c0:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19c2:	14054363          	bltz	a0,1b08 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19c6:	02b577bb          	remuw	a5,a0,a1
    19ca:	00001617          	auipc	a2,0x1
    19ce:	efe60613          	addi	a2,a2,-258 # 28c8 <digits>
	buf[16] = 0;
    19d2:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19d6:	0005871b          	sext.w	a4,a1
    19da:	1782                	slli	a5,a5,0x20
    19dc:	9381                	srli	a5,a5,0x20
    19de:	97b2                	add	a5,a5,a2
    19e0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    19e4:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    19e8:	02f103a3          	sb	a5,39(sp)
	i = 15;
    19ec:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    19ee:	0eb56763          	bltu	a0,a1,1adc <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    19f2:	02e877bb          	remuw	a5,a6,a4
    19f6:	1782                	slli	a5,a5,0x20
    19f8:	9381                	srli	a5,a5,0x20
    19fa:	97b2                	add	a5,a5,a2
    19fc:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a00:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a04:	02f10323          	sb	a5,38(sp)
    1a08:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a0a:	0ce86963          	bltu	a6,a4,1adc <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a0e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a12:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a16:	1582                	slli	a1,a1,0x20
    1a18:	9181                	srli	a1,a1,0x20
    1a1a:	95b2                	add	a1,a1,a2
    1a1c:	0005c583          	lbu	a1,0(a1)
    1a20:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a24:	0007859b          	sext.w	a1,a5
    1a28:	16e6e563          	bltu	a3,a4,1b92 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a2c:	02e7f6bb          	remuw	a3,a5,a4
    1a30:	1682                	slli	a3,a3,0x20
    1a32:	9281                	srli	a3,a3,0x20
    1a34:	96b2                	add	a3,a3,a2
    1a36:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a3a:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a3e:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a42:	16e5e163          	bltu	a1,a4,1ba4 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a46:	02e876bb          	remuw	a3,a6,a4
    1a4a:	1682                	slli	a3,a3,0x20
    1a4c:	9281                	srli	a3,a3,0x20
    1a4e:	96b2                	add	a3,a3,a2
    1a50:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a54:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a58:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a5c:	14e86d63          	bltu	a6,a4,1bb6 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a60:	02e5f6bb          	remuw	a3,a1,a4
    1a64:	1682                	slli	a3,a3,0x20
    1a66:	9281                	srli	a3,a3,0x20
    1a68:	96b2                	add	a3,a3,a2
    1a6a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a6e:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a72:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a76:	10e5e563          	bltu	a1,a4,1b80 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1a7a:	02e876bb          	remuw	a3,a6,a4
    1a7e:	1682                	slli	a3,a3,0x20
    1a80:	9281                	srli	a3,a3,0x20
    1a82:	96b2                	add	a3,a3,a2
    1a84:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a88:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a8c:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1a90:	14e86263          	bltu	a6,a4,1bd4 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1a94:	02e5f6bb          	remuw	a3,a1,a4
    1a98:	1682                	slli	a3,a3,0x20
    1a9a:	9281                	srli	a3,a3,0x20
    1a9c:	96b2                	add	a3,a3,a2
    1a9e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aa2:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1aa6:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1aaa:	14e5e463          	bltu	a1,a4,1bf2 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1aae:	02e876bb          	remuw	a3,a6,a4
    1ab2:	1682                	slli	a3,a3,0x20
    1ab4:	9281                	srli	a3,a3,0x20
    1ab6:	96b2                	add	a3,a3,a2
    1ab8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1abc:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ac0:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1ac4:	14e86063          	bltu	a6,a4,1c04 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1ac8:	1782                	slli	a5,a5,0x20
    1aca:	9381                	srli	a5,a5,0x20
    1acc:	97b2                	add	a5,a5,a2
    1ace:	0007c703          	lbu	a4,0(a5)
    1ad2:	4799                	li	a5,6
    1ad4:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1ad8:	10054763          	bltz	a0,1be6 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1adc:	00001497          	auipc	s1,0x1
    1ae0:	cdc48493          	addi	s1,s1,-804 # 27b8 <buffer_len>
    1ae4:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1ae8:	0828                	addi	a0,sp,24
    1aea:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1aec:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1aee:	00f50433          	add	s0,a0,a5
    1af2:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1af4:	06e68463          	beq	a3,a4,1b5c <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1af8:	8522                	mv	a0,s0
    1afa:	b15ff0ef          	jal	ra,160e <out_unlocked>
}
    1afe:	60a6                	ld	ra,72(sp)
    1b00:	6406                	ld	s0,64(sp)
    1b02:	74e2                	ld	s1,56(sp)
    1b04:	6161                	addi	sp,sp,80
    1b06:	8082                	ret
		x = -xx;
    1b08:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b0c:	02b877bb          	remuw	a5,a6,a1
    1b10:	00001617          	auipc	a2,0x1
    1b14:	db860613          	addi	a2,a2,-584 # 28c8 <digits>
	buf[16] = 0;
    1b18:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b1c:	0005871b          	sext.w	a4,a1
    1b20:	1782                	slli	a5,a5,0x20
    1b22:	9381                	srli	a5,a5,0x20
    1b24:	97b2                	add	a5,a5,a2
    1b26:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b2a:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b2e:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b32:	08b86b63          	bltu	a6,a1,1bc8 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b36:	02e8f7bb          	remuw	a5,a7,a4
    1b3a:	1782                	slli	a5,a5,0x20
    1b3c:	9381                	srli	a5,a5,0x20
    1b3e:	97b2                	add	a5,a5,a2
    1b40:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b44:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b48:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b4c:	ece8f1e3          	bgeu	a7,a4,1a0e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b50:	02d00793          	li	a5,45
    1b54:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b58:	47b5                	li	a5,13
    1b5a:	b749                	j	1adc <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b5c:	10c4a503          	lw	a0,268(s1)
    1b60:	e42e                	sd	a1,8(sp)
    1b62:	2c1000ef          	jal	ra,2622 <mutex_lock>
		len = out_unlocked(s, l);
    1b66:	65a2                	ld	a1,8(sp)
    1b68:	8522                	mv	a0,s0
    1b6a:	aa5ff0ef          	jal	ra,160e <out_unlocked>
		mutex_unlock(buffer_lock);
    1b6e:	10c4a503          	lw	a0,268(s1)
    1b72:	2bd000ef          	jal	ra,262e <mutex_unlock>
}
    1b76:	60a6                	ld	ra,72(sp)
    1b78:	6406                	ld	s0,64(sp)
    1b7a:	74e2                	ld	s1,56(sp)
    1b7c:	6161                	addi	sp,sp,80
    1b7e:	8082                	ret
		buf[i--] = digits[x % base];
    1b80:	47a9                	li	a5,10
	if (sign)
    1b82:	f4055de3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1b86:	02d00793          	li	a5,45
    1b8a:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1b8e:	47a5                	li	a5,9
    1b90:	b7b1                	j	1adc <printint.constprop.0+0x122>
    1b92:	47b5                	li	a5,13
	if (sign)
    1b94:	f40554e3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1b98:	02d00793          	li	a5,45
    1b9c:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1ba0:	47b1                	li	a5,12
    1ba2:	bf2d                	j	1adc <printint.constprop.0+0x122>
    1ba4:	47b1                	li	a5,12
	if (sign)
    1ba6:	f2055be3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1baa:	02d00793          	li	a5,45
    1bae:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bb2:	47ad                	li	a5,11
    1bb4:	b725                	j	1adc <printint.constprop.0+0x122>
    1bb6:	47ad                	li	a5,11
	if (sign)
    1bb8:	f20552e3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bbc:	02d00793          	li	a5,45
    1bc0:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1bc4:	47a9                	li	a5,10
    1bc6:	bf19                	j	1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bc8:	02d00793          	li	a5,45
    1bcc:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bd0:	47b9                	li	a5,14
    1bd2:	b729                	j	1adc <printint.constprop.0+0x122>
    1bd4:	47a5                	li	a5,9
	if (sign)
    1bd6:	f00553e3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bda:	02d00793          	li	a5,45
    1bde:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1be2:	47a1                	li	a5,8
    1be4:	bde5                	j	1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be6:	02d00793          	li	a5,45
    1bea:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1bee:	4795                	li	a5,5
    1bf0:	b5f5                	j	1adc <printint.constprop.0+0x122>
    1bf2:	47a1                	li	a5,8
	if (sign)
    1bf4:	ee0554e3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf8:	02d00793          	li	a5,45
    1bfc:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c00:	479d                	li	a5,7
    1c02:	bde9                	j	1adc <printint.constprop.0+0x122>
    1c04:	479d                	li	a5,7
	if (sign)
    1c06:	ec055be3          	bgez	a0,1adc <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0a:	02d00793          	li	a5,45
    1c0e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c12:	4799                	li	a5,6
    1c14:	b5e1                	j	1adc <printint.constprop.0+0x122>

0000000000001c16 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c16:	02000793          	li	a5,32
    1c1a:	00f50663          	beq	a0,a5,1c26 <isspace+0x10>
    1c1e:	355d                	addiw	a0,a0,-9
    1c20:	00553513          	sltiu	a0,a0,5
    1c24:	8082                	ret
    1c26:	4505                	li	a0,1
}
    1c28:	8082                	ret

0000000000001c2a <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c2a:	fd05051b          	addiw	a0,a0,-48
}
    1c2e:	00a53513          	sltiu	a0,a0,10
    1c32:	8082                	ret

0000000000001c34 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c34:	02000613          	li	a2,32
    1c38:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c3a:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c3e:	ff77869b          	addiw	a3,a5,-9
    1c42:	04c78c63          	beq	a5,a2,1c9a <atoi+0x66>
    1c46:	0007871b          	sext.w	a4,a5
    1c4a:	04d5f863          	bgeu	a1,a3,1c9a <atoi+0x66>
		s++;
	switch (*s) {
    1c4e:	02b00693          	li	a3,43
    1c52:	04d78963          	beq	a5,a3,1ca4 <atoi+0x70>
    1c56:	02d00693          	li	a3,45
    1c5a:	06d78263          	beq	a5,a3,1cbe <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c5e:	fd07061b          	addiw	a2,a4,-48
    1c62:	47a5                	li	a5,9
    1c64:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c66:	4e01                	li	t3,0
	while (isdigit(*s))
    1c68:	04c7e963          	bltu	a5,a2,1cba <atoi+0x86>
	int n = 0, neg = 0;
    1c6c:	4501                	li	a0,0
	while (isdigit(*s))
    1c6e:	4825                	li	a6,9
    1c70:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c74:	0025179b          	slliw	a5,a0,0x2
    1c78:	9fa9                	addw	a5,a5,a0
    1c7a:	fd07031b          	addiw	t1,a4,-48
    1c7e:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1c82:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1c86:	0685                	addi	a3,a3,1
    1c88:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1c8c:	0006071b          	sext.w	a4,a2
    1c90:	feb870e3          	bgeu	a6,a1,1c70 <atoi+0x3c>
	return neg ? n : -n;
    1c94:	000e0563          	beqz	t3,1c9e <atoi+0x6a>
}
    1c98:	8082                	ret
		s++;
    1c9a:	0505                	addi	a0,a0,1
    1c9c:	bf79                	j	1c3a <atoi+0x6>
	return neg ? n : -n;
    1c9e:	4113053b          	subw	a0,t1,a7
    1ca2:	8082                	ret
	while (isdigit(*s))
    1ca4:	00154703          	lbu	a4,1(a0)
    1ca8:	47a5                	li	a5,9
		s++;
    1caa:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cae:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cb2:	4e01                	li	t3,0
	while (isdigit(*s))
    1cb4:	2701                	sext.w	a4,a4
    1cb6:	fac7fbe3          	bgeu	a5,a2,1c6c <atoi+0x38>
    1cba:	4501                	li	a0,0
}
    1cbc:	8082                	ret
	while (isdigit(*s))
    1cbe:	00154703          	lbu	a4,1(a0)
    1cc2:	47a5                	li	a5,9
		s++;
    1cc4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cc8:	fd07061b          	addiw	a2,a4,-48
    1ccc:	2701                	sext.w	a4,a4
    1cce:	fec7e6e3          	bltu	a5,a2,1cba <atoi+0x86>
		neg = 1;
    1cd2:	4e05                	li	t3,1
    1cd4:	bf61                	j	1c6c <atoi+0x38>

0000000000001cd6 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cd6:	16060d63          	beqz	a2,1e50 <memset+0x17a>
    1cda:	40a007b3          	neg	a5,a0
    1cde:	8b9d                	andi	a5,a5,7
    1ce0:	00778693          	addi	a3,a5,7
    1ce4:	482d                	li	a6,11
    1ce6:	0ff5f713          	zext.b	a4,a1
    1cea:	fff60593          	addi	a1,a2,-1
    1cee:	1706e263          	bltu	a3,a6,1e52 <memset+0x17c>
    1cf2:	16d5ea63          	bltu	a1,a3,1e66 <memset+0x190>
    1cf6:	16078563          	beqz	a5,1e60 <memset+0x18a>
    1cfa:	00e50023          	sb	a4,0(a0)
    1cfe:	4685                	li	a3,1
    1d00:	00150593          	addi	a1,a0,1
    1d04:	14d78c63          	beq	a5,a3,1e5c <memset+0x186>
    1d08:	00e500a3          	sb	a4,1(a0)
    1d0c:	4689                	li	a3,2
    1d0e:	00250593          	addi	a1,a0,2
    1d12:	14d78d63          	beq	a5,a3,1e6c <memset+0x196>
    1d16:	00e50123          	sb	a4,2(a0)
    1d1a:	468d                	li	a3,3
    1d1c:	00350593          	addi	a1,a0,3
    1d20:	12d78b63          	beq	a5,a3,1e56 <memset+0x180>
    1d24:	00e501a3          	sb	a4,3(a0)
    1d28:	4691                	li	a3,4
    1d2a:	00450593          	addi	a1,a0,4
    1d2e:	14d78163          	beq	a5,a3,1e70 <memset+0x19a>
    1d32:	00e50223          	sb	a4,4(a0)
    1d36:	4695                	li	a3,5
    1d38:	00550593          	addi	a1,a0,5
    1d3c:	12d78c63          	beq	a5,a3,1e74 <memset+0x19e>
    1d40:	00e502a3          	sb	a4,5(a0)
    1d44:	469d                	li	a3,7
    1d46:	00650593          	addi	a1,a0,6
    1d4a:	12d79763          	bne	a5,a3,1e78 <memset+0x1a2>
    1d4e:	00750593          	addi	a1,a0,7
    1d52:	00e50323          	sb	a4,6(a0)
    1d56:	481d                	li	a6,7
    1d58:	00871693          	slli	a3,a4,0x8
    1d5c:	01071893          	slli	a7,a4,0x10
    1d60:	8ed9                	or	a3,a3,a4
    1d62:	01871313          	slli	t1,a4,0x18
    1d66:	0116e6b3          	or	a3,a3,a7
    1d6a:	0066e6b3          	or	a3,a3,t1
    1d6e:	02071893          	slli	a7,a4,0x20
    1d72:	02871e13          	slli	t3,a4,0x28
    1d76:	0116e6b3          	or	a3,a3,a7
    1d7a:	40f60333          	sub	t1,a2,a5
    1d7e:	03071893          	slli	a7,a4,0x30
    1d82:	01c6e6b3          	or	a3,a3,t3
    1d86:	0116e6b3          	or	a3,a3,a7
    1d8a:	03871e13          	slli	t3,a4,0x38
    1d8e:	97aa                	add	a5,a5,a0
    1d90:	ff837893          	andi	a7,t1,-8
    1d94:	01c6e6b3          	or	a3,a3,t3
    1d98:	98be                	add	a7,a7,a5
    1d9a:	e394                	sd	a3,0(a5)
    1d9c:	07a1                	addi	a5,a5,8
    1d9e:	ff179ee3          	bne	a5,a7,1d9a <memset+0xc4>
    1da2:	ff837893          	andi	a7,t1,-8
    1da6:	011587b3          	add	a5,a1,a7
    1daa:	010886bb          	addw	a3,a7,a6
    1dae:	0b130663          	beq	t1,a7,1e5a <memset+0x184>
    1db2:	00e78023          	sb	a4,0(a5)
    1db6:	0016859b          	addiw	a1,a3,1
    1dba:	08c5fb63          	bgeu	a1,a2,1e50 <memset+0x17a>
    1dbe:	00e780a3          	sb	a4,1(a5)
    1dc2:	0026859b          	addiw	a1,a3,2
    1dc6:	08c5f563          	bgeu	a1,a2,1e50 <memset+0x17a>
    1dca:	00e78123          	sb	a4,2(a5)
    1dce:	0036859b          	addiw	a1,a3,3
    1dd2:	06c5ff63          	bgeu	a1,a2,1e50 <memset+0x17a>
    1dd6:	00e781a3          	sb	a4,3(a5)
    1dda:	0046859b          	addiw	a1,a3,4
    1dde:	06c5f963          	bgeu	a1,a2,1e50 <memset+0x17a>
    1de2:	00e78223          	sb	a4,4(a5)
    1de6:	0056859b          	addiw	a1,a3,5
    1dea:	06c5f363          	bgeu	a1,a2,1e50 <memset+0x17a>
    1dee:	00e782a3          	sb	a4,5(a5)
    1df2:	0066859b          	addiw	a1,a3,6
    1df6:	04c5fd63          	bgeu	a1,a2,1e50 <memset+0x17a>
    1dfa:	00e78323          	sb	a4,6(a5)
    1dfe:	0076859b          	addiw	a1,a3,7
    1e02:	04c5f763          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e06:	00e783a3          	sb	a4,7(a5)
    1e0a:	0086859b          	addiw	a1,a3,8
    1e0e:	04c5f163          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e12:	00e78423          	sb	a4,8(a5)
    1e16:	0096859b          	addiw	a1,a3,9
    1e1a:	02c5fb63          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e1e:	00e784a3          	sb	a4,9(a5)
    1e22:	00a6859b          	addiw	a1,a3,10
    1e26:	02c5f563          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e2a:	00e78523          	sb	a4,10(a5)
    1e2e:	00b6859b          	addiw	a1,a3,11
    1e32:	00c5ff63          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e36:	00e785a3          	sb	a4,11(a5)
    1e3a:	00c6859b          	addiw	a1,a3,12
    1e3e:	00c5f963          	bgeu	a1,a2,1e50 <memset+0x17a>
    1e42:	00e78623          	sb	a4,12(a5)
    1e46:	26b5                	addiw	a3,a3,13
    1e48:	00c6f463          	bgeu	a3,a2,1e50 <memset+0x17a>
    1e4c:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e50:	8082                	ret
    1e52:	46ad                	li	a3,11
    1e54:	bd79                	j	1cf2 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e56:	480d                	li	a6,3
    1e58:	b701                	j	1d58 <memset+0x82>
    1e5a:	8082                	ret
    1e5c:	4805                	li	a6,1
    1e5e:	bded                	j	1d58 <memset+0x82>
    1e60:	85aa                	mv	a1,a0
    1e62:	4801                	li	a6,0
    1e64:	bdd5                	j	1d58 <memset+0x82>
    1e66:	87aa                	mv	a5,a0
    1e68:	4681                	li	a3,0
    1e6a:	b7a1                	j	1db2 <memset+0xdc>
    1e6c:	4809                	li	a6,2
    1e6e:	b5ed                	j	1d58 <memset+0x82>
    1e70:	4811                	li	a6,4
    1e72:	b5dd                	j	1d58 <memset+0x82>
    1e74:	4815                	li	a6,5
    1e76:	b5cd                	j	1d58 <memset+0x82>
    1e78:	4819                	li	a6,6
    1e7a:	bdf9                	j	1d58 <memset+0x82>

0000000000001e7c <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1e7c:	00054783          	lbu	a5,0(a0)
    1e80:	0005c703          	lbu	a4,0(a1)
    1e84:	00e79863          	bne	a5,a4,1e94 <strcmp+0x18>
    1e88:	0505                	addi	a0,a0,1
    1e8a:	0585                	addi	a1,a1,1
    1e8c:	fbe5                	bnez	a5,1e7c <strcmp>
    1e8e:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1e90:	9d19                	subw	a0,a0,a4
    1e92:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1e94:	0007851b          	sext.w	a0,a5
    1e98:	bfe5                	j	1e90 <strcmp+0x14>

0000000000001e9a <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1e9a:	ca15                	beqz	a2,1ece <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1e9c:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ea0:	167d                	addi	a2,a2,-1
    1ea2:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ea6:	eb99                	bnez	a5,1ebc <strncmp+0x22>
    1ea8:	a815                	j	1edc <strncmp+0x42>
    1eaa:	00a68e63          	beq	a3,a0,1ec6 <strncmp+0x2c>
    1eae:	0505                	addi	a0,a0,1
    1eb0:	00f71b63          	bne	a4,a5,1ec6 <strncmp+0x2c>
    1eb4:	00054783          	lbu	a5,0(a0)
    1eb8:	cf89                	beqz	a5,1ed2 <strncmp+0x38>
    1eba:	85b2                	mv	a1,a2
    1ebc:	0005c703          	lbu	a4,0(a1)
    1ec0:	00158613          	addi	a2,a1,1
    1ec4:	f37d                	bnez	a4,1eaa <strncmp+0x10>
		;
	return *l - *r;
    1ec6:	0007851b          	sext.w	a0,a5
    1eca:	9d19                	subw	a0,a0,a4
    1ecc:	8082                	ret
		return 0;
    1ece:	4501                	li	a0,0
}
    1ed0:	8082                	ret
	return *l - *r;
    1ed2:	0015c703          	lbu	a4,1(a1)
    1ed6:	4501                	li	a0,0
    1ed8:	9d19                	subw	a0,a0,a4
    1eda:	8082                	ret
    1edc:	0005c703          	lbu	a4,0(a1)
    1ee0:	4501                	li	a0,0
    1ee2:	b7e5                	j	1eca <strncmp+0x30>

0000000000001ee4 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1ee4:	00757793          	andi	a5,a0,7
    1ee8:	cf89                	beqz	a5,1f02 <strlen+0x1e>
    1eea:	87aa                	mv	a5,a0
    1eec:	a029                	j	1ef6 <strlen+0x12>
    1eee:	0785                	addi	a5,a5,1
    1ef0:	0077f713          	andi	a4,a5,7
    1ef4:	cb01                	beqz	a4,1f04 <strlen+0x20>
		if (!*s)
    1ef6:	0007c703          	lbu	a4,0(a5)
    1efa:	fb75                	bnez	a4,1eee <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1efc:	40a78533          	sub	a0,a5,a0
}
    1f00:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f02:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f04:	6394                	ld	a3,0(a5)
    1f06:	00001597          	auipc	a1,0x1
    1f0a:	89a5b583          	ld	a1,-1894(a1) # 27a0 <enable_deadlock_detect+0x11e>
    1f0e:	00001617          	auipc	a2,0x1
    1f12:	89a63603          	ld	a2,-1894(a2) # 27a8 <enable_deadlock_detect+0x126>
    1f16:	a019                	j	1f1c <strlen+0x38>
    1f18:	6794                	ld	a3,8(a5)
    1f1a:	07a1                	addi	a5,a5,8
    1f1c:	00b68733          	add	a4,a3,a1
    1f20:	fff6c693          	not	a3,a3
    1f24:	8f75                	and	a4,a4,a3
    1f26:	8f71                	and	a4,a4,a2
    1f28:	db65                	beqz	a4,1f18 <strlen+0x34>
	for (; *s; s++)
    1f2a:	0007c703          	lbu	a4,0(a5)
    1f2e:	d779                	beqz	a4,1efc <strlen+0x18>
    1f30:	0017c703          	lbu	a4,1(a5)
    1f34:	0785                	addi	a5,a5,1
    1f36:	d379                	beqz	a4,1efc <strlen+0x18>
    1f38:	0017c703          	lbu	a4,1(a5)
    1f3c:	0785                	addi	a5,a5,1
    1f3e:	fb6d                	bnez	a4,1f30 <strlen+0x4c>
    1f40:	bf75                	j	1efc <strlen+0x18>

0000000000001f42 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f42:	00757713          	andi	a4,a0,7
{
    1f46:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f48:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f4c:	cb19                	beqz	a4,1f62 <memchr+0x20>
    1f4e:	ce25                	beqz	a2,1fc6 <memchr+0x84>
    1f50:	0007c703          	lbu	a4,0(a5)
    1f54:	04b70e63          	beq	a4,a1,1fb0 <memchr+0x6e>
    1f58:	0785                	addi	a5,a5,1
    1f5a:	0077f713          	andi	a4,a5,7
    1f5e:	167d                	addi	a2,a2,-1
    1f60:	f77d                	bnez	a4,1f4e <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f62:	4501                	li	a0,0
	if (n && *s != c) {
    1f64:	c235                	beqz	a2,1fc8 <memchr+0x86>
    1f66:	0007c703          	lbu	a4,0(a5)
    1f6a:	04b70363          	beq	a4,a1,1fb0 <memchr+0x6e>
		size_t k = ONES * c;
    1f6e:	00001517          	auipc	a0,0x1
    1f72:	84253503          	ld	a0,-1982(a0) # 27b0 <enable_deadlock_detect+0x12e>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f76:	471d                	li	a4,7
		size_t k = ONES * c;
    1f78:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f7c:	02c77a63          	bgeu	a4,a2,1fb0 <memchr+0x6e>
    1f80:	00001897          	auipc	a7,0x1
    1f84:	8208b883          	ld	a7,-2016(a7) # 27a0 <enable_deadlock_detect+0x11e>
    1f88:	00001817          	auipc	a6,0x1
    1f8c:	82083803          	ld	a6,-2016(a6) # 27a8 <enable_deadlock_detect+0x126>
    1f90:	431d                	li	t1,7
    1f92:	a029                	j	1f9c <memchr+0x5a>
		     w++, n -= SS)
    1f94:	1661                	addi	a2,a2,-8
    1f96:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f98:	02c37963          	bgeu	t1,a2,1fca <memchr+0x88>
    1f9c:	6398                	ld	a4,0(a5)
    1f9e:	8f29                	xor	a4,a4,a0
    1fa0:	011706b3          	add	a3,a4,a7
    1fa4:	fff74713          	not	a4,a4
    1fa8:	8f75                	and	a4,a4,a3
    1faa:	01077733          	and	a4,a4,a6
    1fae:	d37d                	beqz	a4,1f94 <memchr+0x52>
{
    1fb0:	853e                	mv	a0,a5
    1fb2:	97b2                	add	a5,a5,a2
    1fb4:	a021                	j	1fbc <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fb6:	0505                	addi	a0,a0,1
    1fb8:	00f50763          	beq	a0,a5,1fc6 <memchr+0x84>
    1fbc:	00054703          	lbu	a4,0(a0)
    1fc0:	feb71be3          	bne	a4,a1,1fb6 <memchr+0x74>
    1fc4:	8082                	ret
	return n ? (void *)s : 0;
    1fc6:	4501                	li	a0,0
}
    1fc8:	8082                	ret
	return n ? (void *)s : 0;
    1fca:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1fcc:	f275                	bnez	a2,1fb0 <memchr+0x6e>
}
    1fce:	8082                	ret

0000000000001fd0 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1fd0:	1101                	addi	sp,sp,-32
    1fd2:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1fd4:	862e                	mv	a2,a1
{
    1fd6:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    1fd8:	4581                	li	a1,0
{
    1fda:	e426                	sd	s1,8(sp)
    1fdc:	ec06                	sd	ra,24(sp)
    1fde:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    1fe0:	f63ff0ef          	jal	ra,1f42 <memchr>
	return p ? p - s : n;
    1fe4:	c519                	beqz	a0,1ff2 <strnlen+0x22>
}
    1fe6:	60e2                	ld	ra,24(sp)
    1fe8:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    1fea:	8d05                	sub	a0,a0,s1
}
    1fec:	64a2                	ld	s1,8(sp)
    1fee:	6105                	addi	sp,sp,32
    1ff0:	8082                	ret
    1ff2:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    1ff4:	8522                	mv	a0,s0
}
    1ff6:	6442                	ld	s0,16(sp)
    1ff8:	64a2                	ld	s1,8(sp)
    1ffa:	6105                	addi	sp,sp,32
    1ffc:	8082                	ret

0000000000001ffe <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    1ffe:	00a5c7b3          	xor	a5,a1,a0
    2002:	8b9d                	andi	a5,a5,7
    2004:	eb95                	bnez	a5,2038 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2006:	0075f793          	andi	a5,a1,7
    200a:	e7b1                	bnez	a5,2056 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    200c:	6198                	ld	a4,0(a1)
    200e:	00000617          	auipc	a2,0x0
    2012:	79263603          	ld	a2,1938(a2) # 27a0 <enable_deadlock_detect+0x11e>
    2016:	00000817          	auipc	a6,0x0
    201a:	79283803          	ld	a6,1938(a6) # 27a8 <enable_deadlock_detect+0x126>
    201e:	a029                	j	2028 <stpcpy+0x2a>
    2020:	05a1                	addi	a1,a1,8
    2022:	e118                	sd	a4,0(a0)
    2024:	6198                	ld	a4,0(a1)
    2026:	0521                	addi	a0,a0,8
    2028:	00c707b3          	add	a5,a4,a2
    202c:	fff74693          	not	a3,a4
    2030:	8ff5                	and	a5,a5,a3
    2032:	0107f7b3          	and	a5,a5,a6
    2036:	d7ed                	beqz	a5,2020 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2038:	0005c783          	lbu	a5,0(a1)
    203c:	00f50023          	sb	a5,0(a0)
    2040:	c785                	beqz	a5,2068 <stpcpy+0x6a>
    2042:	0015c783          	lbu	a5,1(a1)
    2046:	0505                	addi	a0,a0,1
    2048:	0585                	addi	a1,a1,1
    204a:	00f50023          	sb	a5,0(a0)
    204e:	fbf5                	bnez	a5,2042 <stpcpy+0x44>
		;
	return d;
}
    2050:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2052:	0505                	addi	a0,a0,1
    2054:	df45                	beqz	a4,200c <stpcpy+0xe>
			if (!(*d = *s))
    2056:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    205a:	0585                	addi	a1,a1,1
    205c:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2060:	00f50023          	sb	a5,0(a0)
    2064:	f7fd                	bnez	a5,2052 <stpcpy+0x54>
}
    2066:	8082                	ret
    2068:	8082                	ret

000000000000206a <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    206a:	00a5c7b3          	xor	a5,a1,a0
    206e:	8b9d                	andi	a5,a5,7
    2070:	1a079863          	bnez	a5,2220 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2074:	0075f793          	andi	a5,a1,7
    2078:	16078463          	beqz	a5,21e0 <stpncpy+0x176>
    207c:	ea01                	bnez	a2,208c <stpncpy+0x22>
    207e:	a421                	j	2286 <stpncpy+0x21c>
    2080:	167d                	addi	a2,a2,-1
    2082:	0505                	addi	a0,a0,1
    2084:	14070e63          	beqz	a4,21e0 <stpncpy+0x176>
    2088:	1a060863          	beqz	a2,2238 <stpncpy+0x1ce>
    208c:	0005c783          	lbu	a5,0(a1)
    2090:	0585                	addi	a1,a1,1
    2092:	0075f713          	andi	a4,a1,7
    2096:	00f50023          	sb	a5,0(a0)
    209a:	f3fd                	bnez	a5,2080 <stpncpy+0x16>
    209c:	4805                	li	a6,1
    209e:	1a061863          	bnez	a2,224e <stpncpy+0x1e4>
    20a2:	40a007b3          	neg	a5,a0
    20a6:	8b9d                	andi	a5,a5,7
    20a8:	4681                	li	a3,0
    20aa:	18061a63          	bnez	a2,223e <stpncpy+0x1d4>
    20ae:	00778713          	addi	a4,a5,7
    20b2:	45ad                	li	a1,11
    20b4:	18b76363          	bltu	a4,a1,223a <stpncpy+0x1d0>
    20b8:	1ae6eb63          	bltu	a3,a4,226e <stpncpy+0x204>
    20bc:	1a078363          	beqz	a5,2262 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20c0:	00050023          	sb	zero,0(a0)
    20c4:	4685                	li	a3,1
    20c6:	00150713          	addi	a4,a0,1
    20ca:	18d78f63          	beq	a5,a3,2268 <stpncpy+0x1fe>
    20ce:	000500a3          	sb	zero,1(a0)
    20d2:	4689                	li	a3,2
    20d4:	00250713          	addi	a4,a0,2
    20d8:	18d78e63          	beq	a5,a3,2274 <stpncpy+0x20a>
    20dc:	00050123          	sb	zero,2(a0)
    20e0:	468d                	li	a3,3
    20e2:	00350713          	addi	a4,a0,3
    20e6:	16d78c63          	beq	a5,a3,225e <stpncpy+0x1f4>
    20ea:	000501a3          	sb	zero,3(a0)
    20ee:	4691                	li	a3,4
    20f0:	00450713          	addi	a4,a0,4
    20f4:	18d78263          	beq	a5,a3,2278 <stpncpy+0x20e>
    20f8:	00050223          	sb	zero,4(a0)
    20fc:	4695                	li	a3,5
    20fe:	00550713          	addi	a4,a0,5
    2102:	16d78d63          	beq	a5,a3,227c <stpncpy+0x212>
    2106:	000502a3          	sb	zero,5(a0)
    210a:	469d                	li	a3,7
    210c:	00650713          	addi	a4,a0,6
    2110:	16d79863          	bne	a5,a3,2280 <stpncpy+0x216>
    2114:	00750713          	addi	a4,a0,7
    2118:	00050323          	sb	zero,6(a0)
    211c:	40f80833          	sub	a6,a6,a5
    2120:	ff887593          	andi	a1,a6,-8
    2124:	97aa                	add	a5,a5,a0
    2126:	95be                	add	a1,a1,a5
    2128:	0007b023          	sd	zero,0(a5)
    212c:	07a1                	addi	a5,a5,8
    212e:	feb79de3          	bne	a5,a1,2128 <stpncpy+0xbe>
    2132:	ff887593          	andi	a1,a6,-8
    2136:	9ead                	addw	a3,a3,a1
    2138:	00b707b3          	add	a5,a4,a1
    213c:	12b80863          	beq	a6,a1,226c <stpncpy+0x202>
    2140:	00078023          	sb	zero,0(a5)
    2144:	0016871b          	addiw	a4,a3,1
    2148:	0ec77863          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    214c:	000780a3          	sb	zero,1(a5)
    2150:	0026871b          	addiw	a4,a3,2
    2154:	0ec77263          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    2158:	00078123          	sb	zero,2(a5)
    215c:	0036871b          	addiw	a4,a3,3
    2160:	0cc77c63          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    2164:	000781a3          	sb	zero,3(a5)
    2168:	0046871b          	addiw	a4,a3,4
    216c:	0cc77663          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    2170:	00078223          	sb	zero,4(a5)
    2174:	0056871b          	addiw	a4,a3,5
    2178:	0cc77063          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    217c:	000782a3          	sb	zero,5(a5)
    2180:	0066871b          	addiw	a4,a3,6
    2184:	0ac77a63          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    2188:	00078323          	sb	zero,6(a5)
    218c:	0076871b          	addiw	a4,a3,7
    2190:	0ac77463          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    2194:	000783a3          	sb	zero,7(a5)
    2198:	0086871b          	addiw	a4,a3,8
    219c:	08c77e63          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    21a0:	00078423          	sb	zero,8(a5)
    21a4:	0096871b          	addiw	a4,a3,9
    21a8:	08c77863          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    21ac:	000784a3          	sb	zero,9(a5)
    21b0:	00a6871b          	addiw	a4,a3,10
    21b4:	08c77263          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    21b8:	00078523          	sb	zero,10(a5)
    21bc:	00b6871b          	addiw	a4,a3,11
    21c0:	06c77c63          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    21c4:	000785a3          	sb	zero,11(a5)
    21c8:	00c6871b          	addiw	a4,a3,12
    21cc:	06c77663          	bgeu	a4,a2,2238 <stpncpy+0x1ce>
    21d0:	00078623          	sb	zero,12(a5)
    21d4:	26b5                	addiw	a3,a3,13
    21d6:	06c6f163          	bgeu	a3,a2,2238 <stpncpy+0x1ce>
    21da:	000786a3          	sb	zero,13(a5)
    21de:	8082                	ret
			;
		if (!n || !*s)
    21e0:	c645                	beqz	a2,2288 <stpncpy+0x21e>
    21e2:	0005c783          	lbu	a5,0(a1)
    21e6:	ea078be3          	beqz	a5,209c <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    21ea:	479d                	li	a5,7
    21ec:	02c7ff63          	bgeu	a5,a2,222a <stpncpy+0x1c0>
    21f0:	00000897          	auipc	a7,0x0
    21f4:	5b08b883          	ld	a7,1456(a7) # 27a0 <enable_deadlock_detect+0x11e>
    21f8:	00000817          	auipc	a6,0x0
    21fc:	5b083803          	ld	a6,1456(a6) # 27a8 <enable_deadlock_detect+0x126>
    2200:	431d                	li	t1,7
    2202:	6198                	ld	a4,0(a1)
    2204:	011707b3          	add	a5,a4,a7
    2208:	fff74693          	not	a3,a4
    220c:	8ff5                	and	a5,a5,a3
    220e:	0107f7b3          	and	a5,a5,a6
    2212:	ef81                	bnez	a5,222a <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2214:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2216:	1661                	addi	a2,a2,-8
    2218:	05a1                	addi	a1,a1,8
    221a:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    221c:	fec363e3          	bltu	t1,a2,2202 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2220:	e609                	bnez	a2,222a <stpncpy+0x1c0>
    2222:	a08d                	j	2284 <stpncpy+0x21a>
    2224:	167d                	addi	a2,a2,-1
    2226:	0505                	addi	a0,a0,1
    2228:	ca01                	beqz	a2,2238 <stpncpy+0x1ce>
    222a:	0005c783          	lbu	a5,0(a1)
    222e:	0585                	addi	a1,a1,1
    2230:	00f50023          	sb	a5,0(a0)
    2234:	fbe5                	bnez	a5,2224 <stpncpy+0x1ba>
		;
tail:
    2236:	b59d                	j	209c <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2238:	8082                	ret
    223a:	472d                	li	a4,11
    223c:	bdb5                	j	20b8 <stpncpy+0x4e>
    223e:	00778713          	addi	a4,a5,7
    2242:	45ad                	li	a1,11
    2244:	fff60693          	addi	a3,a2,-1
    2248:	e6b778e3          	bgeu	a4,a1,20b8 <stpncpy+0x4e>
    224c:	b7fd                	j	223a <stpncpy+0x1d0>
    224e:	40a007b3          	neg	a5,a0
    2252:	8832                	mv	a6,a2
    2254:	8b9d                	andi	a5,a5,7
    2256:	4681                	li	a3,0
    2258:	e4060be3          	beqz	a2,20ae <stpncpy+0x44>
    225c:	b7cd                	j	223e <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    225e:	468d                	li	a3,3
    2260:	bd75                	j	211c <stpncpy+0xb2>
    2262:	872a                	mv	a4,a0
    2264:	4681                	li	a3,0
    2266:	bd5d                	j	211c <stpncpy+0xb2>
    2268:	4685                	li	a3,1
    226a:	bd4d                	j	211c <stpncpy+0xb2>
    226c:	8082                	ret
    226e:	87aa                	mv	a5,a0
    2270:	4681                	li	a3,0
    2272:	b5f9                	j	2140 <stpncpy+0xd6>
    2274:	4689                	li	a3,2
    2276:	b55d                	j	211c <stpncpy+0xb2>
    2278:	4691                	li	a3,4
    227a:	b54d                	j	211c <stpncpy+0xb2>
    227c:	4695                	li	a3,5
    227e:	bd79                	j	211c <stpncpy+0xb2>
    2280:	4699                	li	a3,6
    2282:	bd69                	j	211c <stpncpy+0xb2>
    2284:	8082                	ret
    2286:	8082                	ret
    2288:	8082                	ret

000000000000228a <basename>:

char *basename(char *s)
{
    228a:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    228c:	c54d                	beqz	a0,2336 <basename+0xac>
    228e:	00054783          	lbu	a5,0(a0)
		return ".";
    2292:	00000517          	auipc	a0,0x0
    2296:	50650513          	addi	a0,a0,1286 # 2798 <enable_deadlock_detect+0x116>
	if (!s || !*s)
    229a:	e391                	bnez	a5,229e <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    229c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    229e:	0076f713          	andi	a4,a3,7
    22a2:	87b6                	mv	a5,a3
    22a4:	cf51                	beqz	a4,2340 <basename+0xb6>
    22a6:	0785                	addi	a5,a5,1
    22a8:	0077f713          	andi	a4,a5,7
    22ac:	c729                	beqz	a4,22f6 <basename+0x6c>
		if (!*s)
    22ae:	0007c703          	lbu	a4,0(a5)
    22b2:	fb75                	bnez	a4,22a6 <basename+0x1c>
	return s - a;
    22b4:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22b6:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22b8:	cf8d                	beqz	a5,22f2 <basename+0x68>
    22ba:	00f68733          	add	a4,a3,a5
    22be:	02f00593          	li	a1,47
    22c2:	a031                	j	22ce <basename+0x44>
		s[i] = 0;
    22c4:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22c8:	17fd                	addi	a5,a5,-1
    22ca:	177d                	addi	a4,a4,-1
    22cc:	c39d                	beqz	a5,22f2 <basename+0x68>
    22ce:	00074603          	lbu	a2,0(a4)
    22d2:	feb609e3          	beq	a2,a1,22c4 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22d6:	02f00613          	li	a2,47
    22da:	a011                	j	22de <basename+0x54>
    22dc:	cb99                	beqz	a5,22f2 <basename+0x68>
    22de:	853e                	mv	a0,a5
    22e0:	17fd                	addi	a5,a5,-1
    22e2:	00f68733          	add	a4,a3,a5
    22e6:	00074703          	lbu	a4,0(a4)
    22ea:	fec719e3          	bne	a4,a2,22dc <basename+0x52>
	return s + i;
    22ee:	9536                	add	a0,a0,a3
    22f0:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    22f2:	8536                	mv	a0,a3
    22f4:	8082                	ret
    22f6:	6390                	ld	a2,0(a5)
    22f8:	00000517          	auipc	a0,0x0
    22fc:	4a853503          	ld	a0,1192(a0) # 27a0 <enable_deadlock_detect+0x11e>
    2300:	00000597          	auipc	a1,0x0
    2304:	4a85b583          	ld	a1,1192(a1) # 27a8 <enable_deadlock_detect+0x126>
    2308:	fff64713          	not	a4,a2
    230c:	962a                	add	a2,a2,a0
    230e:	8f71                	and	a4,a4,a2
    2310:	8f6d                	and	a4,a4,a1
    2312:	eb11                	bnez	a4,2326 <basename+0x9c>
    2314:	6790                	ld	a2,8(a5)
    2316:	07a1                	addi	a5,a5,8
    2318:	00a60733          	add	a4,a2,a0
    231c:	fff64613          	not	a2,a2
    2320:	8f71                	and	a4,a4,a2
    2322:	8f6d                	and	a4,a4,a1
    2324:	db65                	beqz	a4,2314 <basename+0x8a>
	for (; *s; s++)
    2326:	0007c703          	lbu	a4,0(a5)
    232a:	d749                	beqz	a4,22b4 <basename+0x2a>
    232c:	0017c703          	lbu	a4,1(a5)
    2330:	0785                	addi	a5,a5,1
    2332:	ff6d                	bnez	a4,232c <basename+0xa2>
    2334:	b741                	j	22b4 <basename+0x2a>
		return ".";
    2336:	00000517          	auipc	a0,0x0
    233a:	46250513          	addi	a0,a0,1122 # 2798 <enable_deadlock_detect+0x116>
    233e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2340:	6290                	ld	a2,0(a3)
    2342:	00000517          	auipc	a0,0x0
    2346:	45e53503          	ld	a0,1118(a0) # 27a0 <enable_deadlock_detect+0x11e>
    234a:	00000597          	auipc	a1,0x0
    234e:	45e5b583          	ld	a1,1118(a1) # 27a8 <enable_deadlock_detect+0x126>
    2352:	fff64713          	not	a4,a2
    2356:	962a                	add	a2,a2,a0
    2358:	8f71                	and	a4,a4,a2
    235a:	8f6d                	and	a4,a4,a1
    235c:	df45                	beqz	a4,2314 <basename+0x8a>
    235e:	b7f9                	j	232c <basename+0xa2>

0000000000002360 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2360:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2364:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2366:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    236a:	2501                	sext.w	a0,a0
    236c:	8082                	ret

000000000000236e <close>:

int close(int fd)
{
	if (fd == 1) {
    236e:	4785                	li	a5,1
    2370:	00f50863          	beq	a0,a5,2380 <close+0x12>
	register long a7 __asm__("a7") = n;
    2374:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2378:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    237c:	2501                	sext.w	a0,a0
    237e:	8082                	ret
{
    2380:	1101                	addi	sp,sp,-32
    2382:	ec06                	sd	ra,24(sp)
    2384:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2386:	cdffe0ef          	jal	ra,1064 <__write_buffer>
		__clear_buffer();
    238a:	d03fe0ef          	jal	ra,108c <__clear_buffer>
    238e:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2390:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2394:	00000073          	ecall
}
    2398:	60e2                	ld	ra,24(sp)
    239a:	2501                	sext.w	a0,a0
    239c:	6105                	addi	sp,sp,32
    239e:	8082                	ret

00000000000023a0 <read>:
	register long a7 __asm__("a7") = n;
    23a0:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23a4:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23a8:	8082                	ret

00000000000023aa <write>:
	register long a7 __asm__("a7") = n;
    23aa:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ae:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23b2:	8082                	ret

00000000000023b4 <getpid>:
	register long a7 __asm__("a7") = n;
    23b4:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23b8:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23bc:	2501                	sext.w	a0,a0
    23be:	8082                	ret

00000000000023c0 <getppid>:
	register long a7 __asm__("a7") = n;
    23c0:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23c4:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23c8:	2501                	sext.w	a0,a0
    23ca:	8082                	ret

00000000000023cc <sched_yield>:
	register long a7 __asm__("a7") = n;
    23cc:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23d0:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23d4:	2501                	sext.w	a0,a0
    23d6:	8082                	ret

00000000000023d8 <fork>:
	register long a7 __asm__("a7") = n;
    23d8:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    23dc:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    23e0:	2501                	sext.w	a0,a0
    23e2:	8082                	ret

00000000000023e4 <exit>:

void exit(int code)
{
    23e4:	1141                	addi	sp,sp,-16
    23e6:	e406                	sd	ra,8(sp)
    23e8:	e022                	sd	s0,0(sp)
    23ea:	842a                	mv	s0,a0
	__write_buffer();
    23ec:	c79fe0ef          	jal	ra,1064 <__write_buffer>
	__clear_buffer();
    23f0:	c9dfe0ef          	jal	ra,108c <__clear_buffer>
	register long a7 __asm__("a7") = n;
    23f4:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    23f8:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    23fa:	00000073          	ecall
	syscall(SYS_exit, code);
}
    23fe:	60a2                	ld	ra,8(sp)
    2400:	6402                	ld	s0,0(sp)
    2402:	0141                	addi	sp,sp,16
    2404:	8082                	ret

0000000000002406 <waitpid>:
	register long a7 __asm__("a7") = n;
    2406:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    240a:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    240e:	2501                	sext.w	a0,a0
    2410:	8082                	ret

0000000000002412 <exec>:
	register long a7 __asm__("a7") = n;
    2412:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2416:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    241a:	2501                	sext.w	a0,a0
    241c:	8082                	ret

000000000000241e <get_mtime>:

int64 get_mtime()
{
    241e:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2420:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2424:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2426:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2428:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    242c:	2501                	sext.w	a0,a0
    242e:	ed01                	bnez	a0,2446 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2430:	6722                	ld	a4,8(sp)
    2432:	3e800793          	li	a5,1000
    2436:	6682                	ld	a3,0(sp)
    2438:	02f75733          	divu	a4,a4,a5
    243c:	02d78533          	mul	a0,a5,a3
    2440:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2442:	0141                	addi	sp,sp,16
    2444:	8082                	ret
	return -1;
    2446:	557d                	li	a0,-1
    2448:	bfed                	j	2442 <get_mtime+0x24>

000000000000244a <sys_get_time>:
	register long a7 __asm__("a7") = n;
    244a:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    244e:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2452:	2501                	sext.w	a0,a0
    2454:	8082                	ret

0000000000002456 <sleep>:

int sleep(unsigned long long time)
{
    2456:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2458:	880a                	mv	a6,sp
{
    245a:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    245c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2460:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2462:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2464:	00000073          	ecall
	if (err == 0) {
    2468:	2501                	sext.w	a0,a0
    246a:	ed31                	bnez	a0,24c6 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    246c:	6722                	ld	a4,8(sp)
    246e:	3e800793          	li	a5,1000
    2472:	6682                	ld	a3,0(sp)
    2474:	02f75733          	divu	a4,a4,a5
    2478:	02d787b3          	mul	a5,a5,a3
    247c:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    247e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2482:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2484:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2486:	00000073          	ecall
	if (err == 0) {
    248a:	2501                	sext.w	a0,a0
    248c:	e915                	bnez	a0,24c0 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    248e:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2490:	3e800693          	li	a3,1000
    2494:	a819                	j	24aa <sleep+0x54>
	__asm_syscall("r"(a7))
    2496:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    249a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    249e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24a0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a2:	00000073          	ecall
	if (err == 0) {
    24a6:	2501                	sext.w	a0,a0
    24a8:	ed01                	bnez	a0,24c0 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24aa:	6722                	ld	a4,8(sp)
    24ac:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24ae:	07c00893          	li	a7,124
    24b2:	02d75733          	divu	a4,a4,a3
    24b6:	02f687b3          	mul	a5,a3,a5
    24ba:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24bc:	fcc7ede3          	bltu	a5,a2,2496 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24c0:	4501                	li	a0,0
    24c2:	0141                	addi	sp,sp,16
    24c4:	8082                	ret
    24c6:	57fd                	li	a5,-1
    24c8:	bf5d                	j	247e <sleep+0x28>

00000000000024ca <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24ca:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24ce:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24d2:	2501                	sext.w	a0,a0
    24d4:	8082                	ret

00000000000024d6 <set_priority>:
	register long a7 __asm__("a7") = n;
    24d6:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    24da:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    24de:	2501                	sext.w	a0,a0
    24e0:	8082                	ret

00000000000024e2 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    24e2:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    24e6:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    24ea:	2501                	sext.w	a0,a0
    24ec:	8082                	ret

00000000000024ee <munmap>:
	register long a7 __asm__("a7") = n;
    24ee:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24f2:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    24f6:	2501                	sext.w	a0,a0
    24f8:	8082                	ret

00000000000024fa <wait>:

int wait(int *code)
{
    24fa:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    24fc:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2500:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2502:	00000073          	ecall
	return waitpid(-1, code);
}
    2506:	2501                	sext.w	a0,a0
    2508:	8082                	ret

000000000000250a <spawn>:
	register long a7 __asm__("a7") = n;
    250a:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    250e:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2512:	2501                	sext.w	a0,a0
    2514:	8082                	ret

0000000000002516 <pipe>:
	register long a7 __asm__("a7") = n;
    2516:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    251a:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    251e:	2501                	sext.w	a0,a0
    2520:	8082                	ret

0000000000002522 <mailread>:
	register long a7 __asm__("a7") = n;
    2522:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2526:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    252a:	2501                	sext.w	a0,a0
    252c:	8082                	ret

000000000000252e <mailwrite>:
	register long a7 __asm__("a7") = n;
    252e:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2532:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2536:	2501                	sext.w	a0,a0
    2538:	8082                	ret

000000000000253a <fstat>:
	register long a7 __asm__("a7") = n;
    253a:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    253e:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2542:	2501                	sext.w	a0,a0
    2544:	8082                	ret

0000000000002546 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2546:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2548:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    254c:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    254e:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2552:	2501                	sext.w	a0,a0
    2554:	8082                	ret

0000000000002556 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2556:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2558:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    255c:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    255e:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2562:	2501                	sext.w	a0,a0
    2564:	8082                	ret

0000000000002566 <link>:

int link(char *old_path, char *new_path)
{
    2566:	87aa                	mv	a5,a0
    2568:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    256a:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    256e:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2572:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2574:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2578:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    257a:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <unlink>:

int unlink(char *path)
{
    2582:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2584:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2588:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    258c:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    258e:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2592:	2501                	sext.w	a0,a0
    2594:	8082                	ret

0000000000002596 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2596:	00000797          	auipc	a5,0x0
    259a:	3527b783          	ld	a5,850(a5) # 28e8 <_GLOBAL_OFFSET_TABLE_+0x8>
    259e:	439c                	lw	a5,0(a5)
    25a0:	c799                	beqz	a5,25ae <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25a2:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25a6:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25aa:	2501                	sext.w	a0,a0
    25ac:	8082                	ret
{
    25ae:	1101                	addi	sp,sp,-32
    25b0:	ec06                	sd	ra,24(sp)
    25b2:	e42e                	sd	a1,8(sp)
    25b4:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25b6:	fe7fe0ef          	jal	ra,159c <enable_thread_io_buffer>
    25ba:	65a2                	ld	a1,8(sp)
    25bc:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25be:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c2:	00000073          	ecall
}
    25c6:	60e2                	ld	ra,24(sp)
    25c8:	2501                	sext.w	a0,a0
    25ca:	6105                	addi	sp,sp,32
    25cc:	8082                	ret

00000000000025ce <gettid>:
	register long a7 __asm__("a7") = n;
    25ce:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25d2:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25d6:	2501                	sext.w	a0,a0
    25d8:	8082                	ret

00000000000025da <waittid>:

int waittid(int tid)
{
    25da:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    25dc:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    25e0:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    25e4:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    25e6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    25e8:	00e51e63          	bne	a0,a4,2604 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    25ec:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25f0:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25f4:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    25f8:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    25fa:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    25fe:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2600:	fee506e3          	beq	a0,a4,25ec <waittid+0x12>
	}
	return ret;
}
    2604:	8082                	ret

0000000000002606 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2606:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    260a:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    260c:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2610:	2501                	sext.w	a0,a0
    2612:	8082                	ret

0000000000002614 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2614:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2618:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    261a:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    261e:	2501                	sext.w	a0,a0
    2620:	8082                	ret

0000000000002622 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2622:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2626:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    262a:	2501                	sext.w	a0,a0
    262c:	8082                	ret

000000000000262e <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    262e:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2632:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2636:	2501                	sext.w	a0,a0
    2638:	8082                	ret

000000000000263a <semaphore_create>:
	register long a7 __asm__("a7") = n;
    263a:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    263e:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2642:	2501                	sext.w	a0,a0
    2644:	8082                	ret

0000000000002646 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2646:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    264a:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    264e:	2501                	sext.w	a0,a0
    2650:	8082                	ret

0000000000002652 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2652:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2656:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    265a:	2501                	sext.w	a0,a0
    265c:	8082                	ret

000000000000265e <condvar_create>:
	register long a7 __asm__("a7") = n;
    265e:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2662:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2666:	2501                	sext.w	a0,a0
    2668:	8082                	ret

000000000000266a <condvar_signal>:
	register long a7 __asm__("a7") = n;
    266a:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    266e:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2672:	2501                	sext.w	a0,a0
    2674:	8082                	ret

0000000000002676 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2676:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267a:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2682:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2686:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret
