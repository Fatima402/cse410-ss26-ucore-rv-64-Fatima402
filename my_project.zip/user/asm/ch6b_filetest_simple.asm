
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_filetest_simple:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	aa0d                	j	1132 <__start_main>

0000000000001002 <main>:
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main()
{
    1002:	7179                	addi	sp,sp,-48
	char *s = "Hello, world!\n";
	char *filea = "filea\0";
	int fd = open(filea, O_CREATE | O_WRONLY);
    1004:	20100593          	li	a1,513
    1008:	00002517          	auipc	a0,0x2
    100c:	a8850513          	addi	a0,a0,-1400 # 2a90 <buffer_lock+0x4>
{
    1010:	f022                	sd	s0,32(sp)
    1012:	f406                	sd	ra,40(sp)
    1014:	ec26                	sd	s1,24(sp)
	int fd = open(filea, O_CREATE | O_WRONLY);
    1016:	454010ef          	jal	ra,246a <open>
    101a:	842a                	mv	s0,a0
	assert(fd > 0);
    101c:	0ea05063          	blez	a0,10fc <main+0xfa>
	write(fd, s, strlen(s));
    1020:	00002517          	auipc	a0,0x2
    1024:	80050513          	addi	a0,a0,-2048 # 2820 <enable_deadlock_detect+0x94>
    1028:	7c7000ef          	jal	ra,1fee <strlen>
    102c:	862a                	mv	a2,a0
    102e:	00001597          	auipc	a1,0x1
    1032:	7f258593          	addi	a1,a1,2034 # 2820 <enable_deadlock_detect+0x94>
    1036:	8522                	mv	a0,s0
    1038:	47c010ef          	jal	ra,24b4 <write>
	close(fd);
    103c:	8522                	mv	a0,s0
    103e:	43a010ef          	jal	ra,2478 <close>
	fd = open(filea, O_RDONLY);
    1042:	4581                	li	a1,0
    1044:	00002517          	auipc	a0,0x2
    1048:	a4c50513          	addi	a0,a0,-1460 # 2a90 <buffer_lock+0x4>
    104c:	41e010ef          	jal	ra,246a <open>
    1050:	842a                	mv	s0,a0
	assert(fd > 0);
    1052:	06a05a63          	blez	a0,10c6 <main+0xc4>
	char buf[16];
	int read_len = read(fd, buf, 16);
    1056:	848a                	mv	s1,sp
    1058:	85a6                	mv	a1,s1
    105a:	4641                	li	a2,16
    105c:	8522                	mv	a0,s0
    105e:	44c010ef          	jal	ra,24aa <read>
	close(fd);
    1062:	8522                	mv	a0,s0
    1064:	414010ef          	jal	ra,2478 <close>
	assert(strcmp(s, buf) == 0);
    1068:	85a6                	mv	a1,s1
    106a:	00001517          	auipc	a0,0x1
    106e:	7b650513          	addi	a0,a0,1974 # 2820 <enable_deadlock_detect+0x94>
    1072:	715000ef          	jal	ra,1f86 <strcmp>
    1076:	ed09                	bnez	a0,1090 <main+0x8e>
	puts("file_test passed!");
    1078:	00001517          	auipc	a0,0x1
    107c:	7f850513          	addi	a0,a0,2040 # 2870 <enable_deadlock_detect+0xe4>
    1080:	123000ef          	jal	ra,19a2 <puts>
	return 0;
    1084:	70a2                	ld	ra,40(sp)
    1086:	7402                	ld	s0,32(sp)
    1088:	64e2                	ld	s1,24(sp)
    108a:	4501                	li	a0,0
    108c:	6145                	addi	sp,sp,48
    108e:	8082                	ret
	assert(strcmp(s, buf) == 0);
    1090:	42e010ef          	jal	ra,24be <getpid>
    1094:	842a                	mv	s0,a0
    1096:	00001517          	auipc	a0,0x1
    109a:	70250513          	addi	a0,a0,1794 # 2798 <enable_deadlock_detect+0xc>
    109e:	2f6010ef          	jal	ra,2394 <basename>
    10a2:	872a                	mv	a4,a0
    10a4:	47d1                	li	a5,20
    10a6:	00001517          	auipc	a0,0x1
    10aa:	78a50513          	addi	a0,a0,1930 # 2830 <enable_deadlock_detect+0xa4>
    10ae:	86a2                	mv	a3,s0
    10b0:	00001617          	auipc	a2,0x1
    10b4:	73860613          	addi	a2,a2,1848 # 27e8 <enable_deadlock_detect+0x5c>
    10b8:	45fd                	li	a1,31
    10ba:	1d2000ef          	jal	ra,128c <printf>
    10be:	557d                	li	a0,-1
    10c0:	42e010ef          	jal	ra,24ee <exit>
    10c4:	bf55                	j	1078 <main+0x76>
	assert(fd > 0);
    10c6:	3f8010ef          	jal	ra,24be <getpid>
    10ca:	84aa                	mv	s1,a0
    10cc:	00001517          	auipc	a0,0x1
    10d0:	6cc50513          	addi	a0,a0,1740 # 2798 <enable_deadlock_detect+0xc>
    10d4:	2c0010ef          	jal	ra,2394 <basename>
    10d8:	872a                	mv	a4,a0
    10da:	47c1                	li	a5,16
    10dc:	00001517          	auipc	a0,0x1
    10e0:	71450513          	addi	a0,a0,1812 # 27f0 <enable_deadlock_detect+0x64>
    10e4:	86a6                	mv	a3,s1
    10e6:	00001617          	auipc	a2,0x1
    10ea:	70260613          	addi	a2,a2,1794 # 27e8 <enable_deadlock_detect+0x5c>
    10ee:	45fd                	li	a1,31
    10f0:	19c000ef          	jal	ra,128c <printf>
    10f4:	557d                	li	a0,-1
    10f6:	3f8010ef          	jal	ra,24ee <exit>
    10fa:	bfb1                	j	1056 <main+0x54>
	assert(fd > 0);
    10fc:	3c2010ef          	jal	ra,24be <getpid>
    1100:	84aa                	mv	s1,a0
    1102:	00001517          	auipc	a0,0x1
    1106:	69650513          	addi	a0,a0,1686 # 2798 <enable_deadlock_detect+0xc>
    110a:	28a010ef          	jal	ra,2394 <basename>
    110e:	872a                	mv	a4,a0
    1110:	47b1                	li	a5,12
    1112:	00001517          	auipc	a0,0x1
    1116:	6de50513          	addi	a0,a0,1758 # 27f0 <enable_deadlock_detect+0x64>
    111a:	86a6                	mv	a3,s1
    111c:	00001617          	auipc	a2,0x1
    1120:	6cc60613          	addi	a2,a2,1740 # 27e8 <enable_deadlock_detect+0x5c>
    1124:	45fd                	li	a1,31
    1126:	166000ef          	jal	ra,128c <printf>
    112a:	557d                	li	a0,-1
    112c:	3c2010ef          	jal	ra,24ee <exit>
    1130:	bdc5                	j	1020 <main+0x1e>

0000000000001132 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1132:	1141                	addi	sp,sp,-16
    1134:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1136:	ecdff0ef          	jal	ra,1002 <main>
    113a:	3b4010ef          	jal	ra,24ee <exit>
	return 0;
    113e:	60a2                	ld	ra,8(sp)
    1140:	4501                	li	a0,0
    1142:	0141                	addi	sp,sp,16
    1144:	8082                	ret

0000000000001146 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1146:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1148:	4605                	li	a2,1
    114a:	00f10593          	addi	a1,sp,15
    114e:	4501                	li	a0,0
{
    1150:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1152:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1156:	354010ef          	jal	ra,24aa <read>
    115a:	4785                	li	a5,1
    115c:	00f51763          	bne	a0,a5,116a <getchar+0x24>
		return byte;
    1160:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1164:	60e2                	ld	ra,24(sp)
    1166:	6105                	addi	sp,sp,32
    1168:	8082                	ret
		return EOF;
    116a:	557d                	li	a0,-1
    116c:	bfe5                	j	1164 <getchar+0x1e>

000000000000116e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    116e:	00002517          	auipc	a0,0x2
    1172:	81252503          	lw	a0,-2030(a0) # 2980 <buffer_len>
    1176:	e111                	bnez	a0,117a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1178:	8082                	ret
{
    117a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    117c:	862a                	mv	a2,a0
    117e:	00002597          	auipc	a1,0x2
    1182:	80a58593          	addi	a1,a1,-2038 # 2988 <buffer>
    1186:	4505                	li	a0,1
{
    1188:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    118a:	32a010ef          	jal	ra,24b4 <write>
}
    118e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1190:	2501                	sext.w	a0,a0
}
    1192:	0141                	addi	sp,sp,16
    1194:	8082                	ret

0000000000001196 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1196:	00001797          	auipc	a5,0x1
    119a:	7e07a523          	sw	zero,2026(a5) # 2980 <buffer_len>
}
    119e:	8082                	ret

00000000000011a0 <__fflush>:
	if (buffer_len == 0)
    11a0:	00001517          	auipc	a0,0x1
    11a4:	7e052503          	lw	a0,2016(a0) # 2980 <buffer_len>
    11a8:	e511                	bnez	a0,11b4 <__fflush+0x14>
	buffer_len = 0;
    11aa:	00001797          	auipc	a5,0x1
    11ae:	7c07ab23          	sw	zero,2006(a5) # 2980 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11b2:	8082                	ret
{
    11b4:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11b6:	862a                	mv	a2,a0
    11b8:	00001597          	auipc	a1,0x1
    11bc:	7d058593          	addi	a1,a1,2000 # 2988 <buffer>
    11c0:	4505                	li	a0,1
{
    11c2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11c4:	2f0010ef          	jal	ra,24b4 <write>
	return r >= 0 ? 0 : r;
    11c8:	0005079b          	sext.w	a5,a0
}
    11cc:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11ce:	0017a793          	slti	a5,a5,1
    11d2:	40f007bb          	negw	a5,a5
    11d6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11d8:	00001797          	auipc	a5,0x1
    11dc:	7a07a423          	sw	zero,1960(a5) # 2980 <buffer_len>
	return r >= 0 ? 0 : r;
    11e0:	2501                	sext.w	a0,a0
}
    11e2:	0141                	addi	sp,sp,16
    11e4:	8082                	ret

00000000000011e6 <fflush>:

int fflush(int fd)
{
    11e6:	1101                	addi	sp,sp,-32
    11e8:	e822                	sd	s0,16(sp)
    11ea:	ec06                	sd	ra,24(sp)
    11ec:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11ee:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    11f0:	4401                	li	s0,0
	if (fd == 1) {
    11f2:	00e50863          	beq	a0,a4,1202 <fflush+0x1c>
}
    11f6:	60e2                	ld	ra,24(sp)
    11f8:	8522                	mv	a0,s0
    11fa:	6442                	ld	s0,16(sp)
    11fc:	64a2                	ld	s1,8(sp)
    11fe:	6105                	addi	sp,sp,32
    1200:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1202:	00001497          	auipc	s1,0x1
    1206:	77e48493          	addi	s1,s1,1918 # 2980 <buffer_len>
    120a:	1084a703          	lw	a4,264(s1)
    120e:	02a70e63          	beq	a4,a0,124a <fflush+0x64>
	if (buffer_len == 0)
    1212:	4080                	lw	s0,0(s1)
    1214:	c00d                	beqz	s0,1236 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1216:	8622                	mv	a2,s0
    1218:	00001597          	auipc	a1,0x1
    121c:	77058593          	addi	a1,a1,1904 # 2988 <buffer>
    1220:	294010ef          	jal	ra,24b4 <write>
	return r >= 0 ? 0 : r;
    1224:	0005079b          	sext.w	a5,a0
    1228:	0017a793          	slti	a5,a5,1
    122c:	40f007bb          	negw	a5,a5
    1230:	8d7d                	and	a0,a0,a5
    1232:	0005041b          	sext.w	s0,a0
}
    1236:	60e2                	ld	ra,24(sp)
    1238:	8522                	mv	a0,s0
    123a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    123c:	00001797          	auipc	a5,0x1
    1240:	7407a223          	sw	zero,1860(a5) # 2980 <buffer_len>
}
    1244:	64a2                	ld	s1,8(sp)
    1246:	6105                	addi	sp,sp,32
    1248:	8082                	ret
			mutex_lock(buffer_lock);
    124a:	10c4a503          	lw	a0,268(s1)
    124e:	4de010ef          	jal	ra,272c <mutex_lock>
	if (buffer_len == 0)
    1252:	4080                	lw	s0,0(s1)
    1254:	e811                	bnez	s0,1268 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1256:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    125a:	00001797          	auipc	a5,0x1
    125e:	7207a323          	sw	zero,1830(a5) # 2980 <buffer_len>
			mutex_unlock(buffer_lock);
    1262:	4d6010ef          	jal	ra,2738 <mutex_unlock>
    1266:	bf41                	j	11f6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1268:	8622                	mv	a2,s0
    126a:	00001597          	auipc	a1,0x1
    126e:	71e58593          	addi	a1,a1,1822 # 2988 <buffer>
    1272:	4505                	li	a0,1
    1274:	240010ef          	jal	ra,24b4 <write>
	return r >= 0 ? 0 : r;
    1278:	0005079b          	sext.w	a5,a0
    127c:	0017a793          	slti	a5,a5,1
    1280:	40f007bb          	negw	a5,a5
    1284:	8d7d                	and	a0,a0,a5
    1286:	0005041b          	sext.w	s0,a0
	return r;
    128a:	b7f1                	j	1256 <fflush+0x70>

000000000000128c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    128c:	7131                	addi	sp,sp,-192
    128e:	e0da                	sd	s6,64(sp)
    1290:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1292:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1294:	013c                	addi	a5,sp,136
{
    1296:	f0ca                	sd	s2,96(sp)
    1298:	ecce                	sd	s3,88(sp)
    129a:	e8d2                	sd	s4,80(sp)
    129c:	e4d6                	sd	s5,72(sp)
    129e:	fc86                	sd	ra,120(sp)
    12a0:	f8a2                	sd	s0,112(sp)
    12a2:	f4a6                	sd	s1,104(sp)
    12a4:	89aa                	mv	s3,a0
    12a6:	e52e                	sd	a1,136(sp)
    12a8:	e932                	sd	a2,144(sp)
    12aa:	ed36                	sd	a3,152(sp)
    12ac:	f13a                	sd	a4,160(sp)
    12ae:	f942                	sd	a6,176(sp)
    12b0:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12b2:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12b4:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12b8:	00001a17          	auipc	s4,0x1
    12bc:	6c8a0a13          	addi	s4,s4,1736 # 2980 <buffer_len>
    12c0:	4a85                	li	s5,1
	buf[i++] = '0';
    12c2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12c6:	0009c783          	lbu	a5,0(s3)
    12ca:	18078663          	beqz	a5,1456 <printf+0x1ca>
    12ce:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12d0:	19278d63          	beq	a5,s2,146a <printf+0x1de>
    12d4:	0015c783          	lbu	a5,1(a1)
    12d8:	0585                	addi	a1,a1,1
    12da:	fbfd                	bnez	a5,12d0 <printf+0x44>
    12dc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12de:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12e2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12e6:	1b578863          	beq	a5,s5,1496 <printf+0x20a>
		len = out_unlocked(s, l);
    12ea:	85a2                	mv	a1,s0
    12ec:	854e                	mv	a0,s3
    12ee:	42a000ef          	jal	ra,1718 <out_unlocked>
		out(f, a, l);
		if (l)
    12f2:	1c041063          	bnez	s0,14b2 <printf+0x226>
			continue;
		if (s[1] == 0)
    12f6:	0014c783          	lbu	a5,1(s1)
    12fa:	14078e63          	beqz	a5,1456 <printf+0x1ca>
			break;
		switch (s[1]) {
    12fe:	07300713          	li	a4,115
    1302:	1ce78863          	beq	a5,a4,14d2 <printf+0x246>
    1306:	1af76863          	bltu	a4,a5,14b6 <printf+0x22a>
    130a:	06400713          	li	a4,100
    130e:	22e78063          	beq	a5,a4,152e <printf+0x2a2>
    1312:	07000713          	li	a4,112
    1316:	1ee79563          	bne	a5,a4,1500 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    131a:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    131c:	00001797          	auipc	a5,0x1
    1320:	77c78793          	addi	a5,a5,1916 # 2a98 <digits>
	buf[i++] = '0';
    1324:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1328:	6298                	ld	a4,0(a3)
    132a:	06a1                	addi	a3,a3,8
    132c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    132e:	00471393          	slli	t2,a4,0x4
    1332:	00871293          	slli	t0,a4,0x8
    1336:	00c71f93          	slli	t6,a4,0xc
    133a:	01071f13          	slli	t5,a4,0x10
    133e:	01471e93          	slli	t4,a4,0x14
    1342:	01871e13          	slli	t3,a4,0x18
    1346:	01c71893          	slli	a7,a4,0x1c
    134a:	02471813          	slli	a6,a4,0x24
    134e:	02871513          	slli	a0,a4,0x28
    1352:	02c71593          	slli	a1,a4,0x2c
    1356:	03071613          	slli	a2,a4,0x30
    135a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    135e:	03c75413          	srli	s0,a4,0x3c
    1362:	01c7531b          	srliw	t1,a4,0x1c
    1366:	03c3d393          	srli	t2,t2,0x3c
    136a:	03c2d293          	srli	t0,t0,0x3c
    136e:	03cfdf93          	srli	t6,t6,0x3c
    1372:	03cf5f13          	srli	t5,t5,0x3c
    1376:	03cede93          	srli	t4,t4,0x3c
    137a:	03ce5e13          	srli	t3,t3,0x3c
    137e:	03c8d893          	srli	a7,a7,0x3c
    1382:	03c85813          	srli	a6,a6,0x3c
    1386:	9171                	srli	a0,a0,0x3c
    1388:	91f1                	srli	a1,a1,0x3c
    138a:	9271                	srli	a2,a2,0x3c
    138c:	92f1                	srli	a3,a3,0x3c
    138e:	95be                	add	a1,a1,a5
    1390:	963e                	add	a2,a2,a5
    1392:	96be                	add	a3,a3,a5
    1394:	943e                	add	s0,s0,a5
    1396:	93be                	add	t2,t2,a5
    1398:	92be                	add	t0,t0,a5
    139a:	9fbe                	add	t6,t6,a5
    139c:	9f3e                	add	t5,t5,a5
    139e:	9ebe                	add	t4,t4,a5
    13a0:	9e3e                	add	t3,t3,a5
    13a2:	98be                	add	a7,a7,a5
    13a4:	933e                	add	t1,t1,a5
    13a6:	983e                	add	a6,a6,a5
    13a8:	953e                	add	a0,a0,a5
    13aa:	0005c983          	lbu	s3,0(a1)
    13ae:	00044403          	lbu	s0,0(s0)
    13b2:	00064583          	lbu	a1,0(a2)
    13b6:	0003c383          	lbu	t2,0(t2)
    13ba:	0006c603          	lbu	a2,0(a3)
    13be:	0002c283          	lbu	t0,0(t0)
    13c2:	000fcf83          	lbu	t6,0(t6)
    13c6:	000f4f03          	lbu	t5,0(t5)
    13ca:	000ece83          	lbu	t4,0(t4)
    13ce:	000e4e03          	lbu	t3,0(t3)
    13d2:	0008c883          	lbu	a7,0(a7)
    13d6:	00034303          	lbu	t1,0(t1)
    13da:	00084803          	lbu	a6,0(a6)
    13de:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13e2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13e6:	92f1                	srli	a3,a3,0x3c
    13e8:	8b3d                	andi	a4,a4,15
    13ea:	96be                	add	a3,a3,a5
    13ec:	97ba                	add	a5,a5,a4
    13ee:	00810d23          	sb	s0,26(sp)
    13f2:	00710da3          	sb	t2,27(sp)
    13f6:	00510e23          	sb	t0,28(sp)
    13fa:	01f10ea3          	sb	t6,29(sp)
    13fe:	01e10f23          	sb	t5,30(sp)
    1402:	01d10fa3          	sb	t4,31(sp)
    1406:	03c10023          	sb	t3,32(sp)
    140a:	031100a3          	sb	a7,33(sp)
    140e:	02610123          	sb	t1,34(sp)
    1412:	030101a3          	sb	a6,35(sp)
    1416:	02a10223          	sb	a0,36(sp)
    141a:	033102a3          	sb	s3,37(sp)
    141e:	02b10323          	sb	a1,38(sp)
    1422:	02c103a3          	sb	a2,39(sp)
    1426:	0006c683          	lbu	a3,0(a3)
    142a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    142e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1432:	02d10423          	sb	a3,40(sp)
    1436:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    143a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    143e:	11578263          	beq	a5,s5,1542 <printf+0x2b6>
		len = out_unlocked(s, l);
    1442:	45c9                	li	a1,18
    1444:	0828                	addi	a0,sp,24
    1446:	2d2000ef          	jal	ra,1718 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    144a:	00248993          	addi	s3,s1,2
		if (!*s)
    144e:	0009c783          	lbu	a5,0(s3)
    1452:	e6079ee3          	bnez	a5,12ce <printf+0x42>
	}
	va_end(ap);
    1456:	70e6                	ld	ra,120(sp)
    1458:	7446                	ld	s0,112(sp)
    145a:	74a6                	ld	s1,104(sp)
    145c:	7906                	ld	s2,96(sp)
    145e:	69e6                	ld	s3,88(sp)
    1460:	6a46                	ld	s4,80(sp)
    1462:	6aa6                	ld	s5,72(sp)
    1464:	6b06                	ld	s6,64(sp)
    1466:	6129                	addi	sp,sp,192
    1468:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    146a:	0005c783          	lbu	a5,0(a1)
    146e:	84ae                	mv	s1,a1
    1470:	01278963          	beq	a5,s2,1482 <printf+0x1f6>
    1474:	b5ad                	j	12de <printf+0x52>
    1476:	0024c783          	lbu	a5,2(s1)
    147a:	0585                	addi	a1,a1,1
    147c:	0489                	addi	s1,s1,2
    147e:	e72790e3          	bne	a5,s2,12de <printf+0x52>
    1482:	0014c783          	lbu	a5,1(s1)
    1486:	ff2788e3          	beq	a5,s2,1476 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    148a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    148e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1492:	e5579ce3          	bne	a5,s5,12ea <printf+0x5e>
		mutex_lock(buffer_lock);
    1496:	10ca2503          	lw	a0,268(s4)
    149a:	292010ef          	jal	ra,272c <mutex_lock>
		len = out_unlocked(s, l);
    149e:	85a2                	mv	a1,s0
    14a0:	854e                	mv	a0,s3
    14a2:	276000ef          	jal	ra,1718 <out_unlocked>
		mutex_unlock(buffer_lock);
    14a6:	10ca2503          	lw	a0,268(s4)
    14aa:	28e010ef          	jal	ra,2738 <mutex_unlock>
		if (l)
    14ae:	e40404e3          	beqz	s0,12f6 <printf+0x6a>
    14b2:	89a6                	mv	s3,s1
    14b4:	bd09                	j	12c6 <printf+0x3a>
		switch (s[1]) {
    14b6:	07800713          	li	a4,120
    14ba:	04e79363          	bne	a5,a4,1500 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    14be:	67c2                	ld	a5,16(sp)
    14c0:	45c1                	li	a1,16
		s += 2;
    14c2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14c6:	4388                	lw	a0,0(a5)
    14c8:	07a1                	addi	a5,a5,8
    14ca:	e83e                	sd	a5,16(sp)
    14cc:	5f8000ef          	jal	ra,1ac4 <printint.constprop.0>
		s += 2;
    14d0:	bfbd                	j	144e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14d2:	67c2                	ld	a5,16(sp)
    14d4:	6380                	ld	s0,0(a5)
    14d6:	07a1                	addi	a5,a5,8
    14d8:	e83e                	sd	a5,16(sp)
    14da:	1c040163          	beqz	s0,169c <printf+0x410>
			l = strnlen(a, 200);
    14de:	0c800593          	li	a1,200
    14e2:	8522                	mv	a0,s0
    14e4:	3f7000ef          	jal	ra,20da <strnlen>
	if (buffer_lock_enabled == 1) {
    14e8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14ec:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    14f0:	19578663          	beq	a5,s5,167c <printf+0x3f0>
		len = out_unlocked(s, l);
    14f4:	8522                	mv	a0,s0
    14f6:	222000ef          	jal	ra,1718 <out_unlocked>
		s += 2;
    14fa:	00248993          	addi	s3,s1,2
    14fe:	bf81                	j	144e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1500:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1504:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1508:	0f578663          	beq	a5,s5,15f4 <printf+0x368>
		len = out_unlocked(s, l);
    150c:	0828                	addi	a0,sp,24
    150e:	316000ef          	jal	ra,1824 <out_unlocked.constprop.0>
			putchar(s[1]);
    1512:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1516:	108a2783          	lw	a5,264(s4)
	char byte = c;
    151a:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    151e:	05578163          	beq	a5,s5,1560 <printf+0x2d4>
		len = out_unlocked(s, l);
    1522:	0828                	addi	a0,sp,24
    1524:	300000ef          	jal	ra,1824 <out_unlocked.constprop.0>
		s += 2;
    1528:	00248993          	addi	s3,s1,2
    152c:	b70d                	j	144e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    152e:	67c2                	ld	a5,16(sp)
    1530:	45a9                	li	a1,10
		s += 2;
    1532:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1536:	4388                	lw	a0,0(a5)
    1538:	07a1                	addi	a5,a5,8
    153a:	e83e                	sd	a5,16(sp)
    153c:	588000ef          	jal	ra,1ac4 <printint.constprop.0>
		s += 2;
    1540:	b739                	j	144e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1542:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1546:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    154a:	1e2010ef          	jal	ra,272c <mutex_lock>
		len = out_unlocked(s, l);
    154e:	45c9                	li	a1,18
    1550:	0828                	addi	a0,sp,24
    1552:	1c6000ef          	jal	ra,1718 <out_unlocked>
		mutex_unlock(buffer_lock);
    1556:	10ca2503          	lw	a0,268(s4)
    155a:	1de010ef          	jal	ra,2738 <mutex_unlock>
		s += 2;
    155e:	bdc5                	j	144e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1560:	10ca2503          	lw	a0,268(s4)
    1564:	1c8010ef          	jal	ra,272c <mutex_lock>
		buffer[buffer_len++] = c;
    1568:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    156c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1570:	0017861b          	addiw	a2,a5,1
    1574:	97d2                	add	a5,a5,s4
    1576:	00ca2023          	sw	a2,0(s4)
    157a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    157e:	00c6cc63          	blt	a3,a2,1596 <printf+0x30a>
    1582:	47a9                	li	a5,10
    1584:	06f40663          	beq	s0,a5,15f0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1588:	10ca2503          	lw	a0,268(s4)
		s += 2;
    158c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1590:	1a8010ef          	jal	ra,2738 <mutex_unlock>
		s += 2;
    1594:	bd6d                	j	144e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1596:	10000793          	li	a5,256
    159a:	00f61e63          	bne	a2,a5,15b6 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    159e:	00001597          	auipc	a1,0x1
    15a2:	3ea58593          	addi	a1,a1,1002 # 2988 <buffer>
    15a6:	4505                	li	a0,1
    15a8:	70d000ef          	jal	ra,24b4 <write>
	buffer_len = 0;
    15ac:	00001797          	auipc	a5,0x1
    15b0:	3c07aa23          	sw	zero,980(a5) # 2980 <buffer_len>
			if (r < 0) {
    15b4:	bfd1                	j	1588 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15b6:	709000ef          	jal	ra,24be <getpid>
    15ba:	842a                	mv	s0,a0
    15bc:	00001517          	auipc	a0,0x1
    15c0:	2d450513          	addi	a0,a0,724 # 2890 <enable_deadlock_detect+0x104>
    15c4:	5d1000ef          	jal	ra,2394 <basename>
    15c8:	872a                	mv	a4,a0
    15ca:	00001617          	auipc	a2,0x1
    15ce:	21e60613          	addi	a2,a2,542 # 27e8 <enable_deadlock_detect+0x5c>
    15d2:	05400793          	li	a5,84
    15d6:	86a2                	mv	a3,s0
    15d8:	45fd                	li	a1,31
    15da:	00001517          	auipc	a0,0x1
    15de:	2f650513          	addi	a0,a0,758 # 28d0 <enable_deadlock_detect+0x144>
    15e2:	cabff0ef          	jal	ra,128c <printf>
    15e6:	557d                	li	a0,-1
    15e8:	707000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    15ec:	000a2603          	lw	a2,0(s4)
    15f0:	de41                	beqz	a2,1588 <printf+0x2fc>
    15f2:	b775                	j	159e <printf+0x312>
		mutex_lock(buffer_lock);
    15f4:	10ca2503          	lw	a0,268(s4)
    15f8:	134010ef          	jal	ra,272c <mutex_lock>
		buffer[buffer_len++] = c;
    15fc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1600:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1604:	0017861b          	addiw	a2,a5,1
    1608:	97d2                	add	a5,a5,s4
    160a:	00ca2023          	sw	a2,0(s4)
    160e:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1612:	02c6d163          	bge	a3,a2,1634 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1616:	10000793          	li	a5,256
    161a:	02f61263          	bne	a2,a5,163e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    161e:	00001597          	auipc	a1,0x1
    1622:	36a58593          	addi	a1,a1,874 # 2988 <buffer>
    1626:	4505                	li	a0,1
    1628:	68d000ef          	jal	ra,24b4 <write>
	buffer_len = 0;
    162c:	00001797          	auipc	a5,0x1
    1630:	3407aa23          	sw	zero,852(a5) # 2980 <buffer_len>
		mutex_unlock(buffer_lock);
    1634:	10ca2503          	lw	a0,268(s4)
    1638:	100010ef          	jal	ra,2738 <mutex_unlock>
    163c:	bdd9                	j	1512 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    163e:	681000ef          	jal	ra,24be <getpid>
    1642:	842a                	mv	s0,a0
    1644:	00001517          	auipc	a0,0x1
    1648:	24c50513          	addi	a0,a0,588 # 2890 <enable_deadlock_detect+0x104>
    164c:	549000ef          	jal	ra,2394 <basename>
    1650:	872a                	mv	a4,a0
    1652:	00001617          	auipc	a2,0x1
    1656:	19660613          	addi	a2,a2,406 # 27e8 <enable_deadlock_detect+0x5c>
    165a:	05400793          	li	a5,84
    165e:	86a2                	mv	a3,s0
    1660:	45fd                	li	a1,31
    1662:	00001517          	auipc	a0,0x1
    1666:	26e50513          	addi	a0,a0,622 # 28d0 <enable_deadlock_detect+0x144>
    166a:	c23ff0ef          	jal	ra,128c <printf>
    166e:	557d                	li	a0,-1
    1670:	67f000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    1674:	000a2603          	lw	a2,0(s4)
    1678:	de55                	beqz	a2,1634 <printf+0x3a8>
    167a:	b755                	j	161e <printf+0x392>
		mutex_lock(buffer_lock);
    167c:	10ca2503          	lw	a0,268(s4)
    1680:	e42e                	sd	a1,8(sp)
		s += 2;
    1682:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1686:	0a6010ef          	jal	ra,272c <mutex_lock>
		len = out_unlocked(s, l);
    168a:	65a2                	ld	a1,8(sp)
    168c:	8522                	mv	a0,s0
    168e:	08a000ef          	jal	ra,1718 <out_unlocked>
		mutex_unlock(buffer_lock);
    1692:	10ca2503          	lw	a0,268(s4)
    1696:	0a2010ef          	jal	ra,2738 <mutex_unlock>
		s += 2;
    169a:	bb55                	j	144e <printf+0x1c2>
				a = "(null)";
    169c:	00001417          	auipc	s0,0x1
    16a0:	1ec40413          	addi	s0,s0,492 # 2888 <enable_deadlock_detect+0xfc>
    16a4:	bd2d                	j	14de <printf+0x252>

00000000000016a6 <enable_thread_io_buffer>:
{
    16a6:	1101                	addi	sp,sp,-32
    16a8:	e822                	sd	s0,16(sp)
    16aa:	ec06                	sd	ra,24(sp)
    16ac:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    16ae:	00001417          	auipc	s0,0x1
    16b2:	2d240413          	addi	s0,s0,722 # 2980 <buffer_len>
    16b6:	05a010ef          	jal	ra,2710 <mutex_create>
    16ba:	10a42623          	sw	a0,268(s0)
    16be:	00054a63          	bltz	a0,16d2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16c2:	4785                	li	a5,1
}
    16c4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16c6:	10f42423          	sw	a5,264(s0)
}
    16ca:	6442                	ld	s0,16(sp)
    16cc:	64a2                	ld	s1,8(sp)
    16ce:	6105                	addi	sp,sp,32
    16d0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16d2:	5ed000ef          	jal	ra,24be <getpid>
    16d6:	84aa                	mv	s1,a0
    16d8:	00001517          	auipc	a0,0x1
    16dc:	1b850513          	addi	a0,a0,440 # 2890 <enable_deadlock_detect+0x104>
    16e0:	4b5000ef          	jal	ra,2394 <basename>
    16e4:	872a                	mv	a4,a0
    16e6:	04800793          	li	a5,72
    16ea:	86a6                	mv	a3,s1
    16ec:	00001517          	auipc	a0,0x1
    16f0:	22450513          	addi	a0,a0,548 # 2910 <enable_deadlock_detect+0x184>
    16f4:	00001617          	auipc	a2,0x1
    16f8:	0f460613          	addi	a2,a2,244 # 27e8 <enable_deadlock_detect+0x5c>
    16fc:	45fd                	li	a1,31
    16fe:	b8fff0ef          	jal	ra,128c <printf>
    1702:	557d                	li	a0,-1
    1704:	5eb000ef          	jal	ra,24ee <exit>
	buffer_lock_enabled = 1;
    1708:	4785                	li	a5,1
}
    170a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    170c:	10f42423          	sw	a5,264(s0)
}
    1710:	6442                	ld	s0,16(sp)
    1712:	64a2                	ld	s1,8(sp)
    1714:	6105                	addi	sp,sp,32
    1716:	8082                	ret

0000000000001718 <out_unlocked>:
{
    1718:	7159                	addi	sp,sp,-112
    171a:	f486                	sd	ra,104(sp)
    171c:	f0a2                	sd	s0,96(sp)
    171e:	eca6                	sd	s1,88(sp)
    1720:	e8ca                	sd	s2,80(sp)
    1722:	e4ce                	sd	s3,72(sp)
    1724:	e0d2                	sd	s4,64(sp)
    1726:	fc56                	sd	s5,56(sp)
    1728:	f85a                	sd	s6,48(sp)
    172a:	f45e                	sd	s7,40(sp)
    172c:	f062                	sd	s8,32(sp)
    172e:	ec66                	sd	s9,24(sp)
    1730:	e86a                	sd	s10,16(sp)
    1732:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1734:	0e058663          	beqz	a1,1820 <out_unlocked+0x108>
    1738:	842a                	mv	s0,a0
    173a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    173e:	4981                	li	s3,0
    1740:	00001d17          	auipc	s10,0x1
    1744:	240d0d13          	addi	s10,s10,576 # 2980 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1748:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    174c:	00001b17          	auipc	s6,0x1
    1750:	23cb0b13          	addi	s6,s6,572 # 2988 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1754:	10000a93          	li	s5,256
    1758:	00001c97          	auipc	s9,0x1
    175c:	138c8c93          	addi	s9,s9,312 # 2890 <enable_deadlock_detect+0x104>
    1760:	00001c17          	auipc	s8,0x1
    1764:	088c0c13          	addi	s8,s8,136 # 27e8 <enable_deadlock_detect+0x5c>
    1768:	00001b97          	auipc	s7,0x1
    176c:	168b8b93          	addi	s7,s7,360 # 28d0 <enable_deadlock_detect+0x144>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1770:	4a29                	li	s4,10
    1772:	a031                	j	177e <out_unlocked+0x66>
    1774:	09468863          	beq	a3,s4,1804 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1778:	0405                	addi	s0,s0,1
    177a:	04848163          	beq	s1,s0,17bc <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    177e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1782:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1786:	0017861b          	addiw	a2,a5,1
    178a:	97ea                	add	a5,a5,s10
    178c:	00cd2023          	sw	a2,0(s10)
    1790:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1794:	fec950e3          	bge	s2,a2,1774 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1798:	05561263          	bne	a2,s5,17dc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    179c:	85da                	mv	a1,s6
    179e:	4505                	li	a0,1
    17a0:	515000ef          	jal	ra,24b4 <write>
    17a4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17a6:	00001797          	auipc	a5,0x1
    17aa:	1c07ad23          	sw	zero,474(a5) # 2980 <buffer_len>
			if (r < 0) {
    17ae:	06054763          	bltz	a0,181c <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17b2:	0405                	addi	s0,s0,1
			ret += r;
    17b4:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17b8:	fc8493e3          	bne	s1,s0,177e <out_unlocked+0x66>
}
    17bc:	70a6                	ld	ra,104(sp)
    17be:	7406                	ld	s0,96(sp)
    17c0:	64e6                	ld	s1,88(sp)
    17c2:	6946                	ld	s2,80(sp)
    17c4:	6a06                	ld	s4,64(sp)
    17c6:	7ae2                	ld	s5,56(sp)
    17c8:	7b42                	ld	s6,48(sp)
    17ca:	7ba2                	ld	s7,40(sp)
    17cc:	7c02                	ld	s8,32(sp)
    17ce:	6ce2                	ld	s9,24(sp)
    17d0:	6d42                	ld	s10,16(sp)
    17d2:	6da2                	ld	s11,8(sp)
    17d4:	854e                	mv	a0,s3
    17d6:	69a6                	ld	s3,72(sp)
    17d8:	6165                	addi	sp,sp,112
    17da:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17dc:	4e3000ef          	jal	ra,24be <getpid>
    17e0:	8daa                	mv	s11,a0
    17e2:	8566                	mv	a0,s9
    17e4:	3b1000ef          	jal	ra,2394 <basename>
    17e8:	872a                	mv	a4,a0
    17ea:	8662                	mv	a2,s8
    17ec:	05400793          	li	a5,84
    17f0:	86ee                	mv	a3,s11
    17f2:	45fd                	li	a1,31
    17f4:	855e                	mv	a0,s7
    17f6:	a97ff0ef          	jal	ra,128c <printf>
    17fa:	557d                	li	a0,-1
    17fc:	4f3000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    1800:	000d2603          	lw	a2,0(s10)
    1804:	da35                	beqz	a2,1778 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1806:	85da                	mv	a1,s6
    1808:	4505                	li	a0,1
    180a:	4ab000ef          	jal	ra,24b4 <write>
    180e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1810:	00001797          	auipc	a5,0x1
    1814:	1607a823          	sw	zero,368(a5) # 2980 <buffer_len>
			if (r < 0) {
    1818:	f8055de3          	bgez	a0,17b2 <out_unlocked+0x9a>
    181c:	89aa                	mv	s3,a0
    181e:	bf79                	j	17bc <out_unlocked+0xa4>
	int ret = 0;
    1820:	4981                	li	s3,0
    1822:	bf69                	j	17bc <out_unlocked+0xa4>

0000000000001824 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1824:	1101                	addi	sp,sp,-32
    1826:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1828:	00001497          	auipc	s1,0x1
    182c:	15848493          	addi	s1,s1,344 # 2980 <buffer_len>
    1830:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1832:	ec06                	sd	ra,24(sp)
    1834:	e822                	sd	s0,16(sp)
		char c = s[i];
    1836:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    183a:	0017861b          	addiw	a2,a5,1
    183e:	97a6                	add	a5,a5,s1
    1840:	00e78423          	sb	a4,8(a5)
    1844:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1846:	0ff00793          	li	a5,255
    184a:	00c7cc63          	blt	a5,a2,1862 <out_unlocked.constprop.0+0x3e>
    184e:	47a9                	li	a5,10
    1850:	06f70c63          	beq	a4,a5,18c8 <out_unlocked.constprop.0+0xa4>
    1854:	4601                	li	a2,0
}
    1856:	60e2                	ld	ra,24(sp)
    1858:	6442                	ld	s0,16(sp)
    185a:	64a2                	ld	s1,8(sp)
    185c:	8532                	mv	a0,a2
    185e:	6105                	addi	sp,sp,32
    1860:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1862:	10000793          	li	a5,256
    1866:	02f61563          	bne	a2,a5,1890 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    186a:	00001597          	auipc	a1,0x1
    186e:	11e58593          	addi	a1,a1,286 # 2988 <buffer>
    1872:	4505                	li	a0,1
    1874:	441000ef          	jal	ra,24b4 <write>
}
    1878:	60e2                	ld	ra,24(sp)
    187a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    187c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1880:	00001797          	auipc	a5,0x1
    1884:	1007a023          	sw	zero,256(a5) # 2980 <buffer_len>
}
    1888:	64a2                	ld	s1,8(sp)
    188a:	8532                	mv	a0,a2
    188c:	6105                	addi	sp,sp,32
    188e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1890:	42f000ef          	jal	ra,24be <getpid>
    1894:	842a                	mv	s0,a0
    1896:	00001517          	auipc	a0,0x1
    189a:	ffa50513          	addi	a0,a0,-6 # 2890 <enable_deadlock_detect+0x104>
    189e:	2f7000ef          	jal	ra,2394 <basename>
    18a2:	872a                	mv	a4,a0
    18a4:	00001617          	auipc	a2,0x1
    18a8:	f4460613          	addi	a2,a2,-188 # 27e8 <enable_deadlock_detect+0x5c>
    18ac:	05400793          	li	a5,84
    18b0:	86a2                	mv	a3,s0
    18b2:	45fd                	li	a1,31
    18b4:	00001517          	auipc	a0,0x1
    18b8:	01c50513          	addi	a0,a0,28 # 28d0 <enable_deadlock_detect+0x144>
    18bc:	9d1ff0ef          	jal	ra,128c <printf>
    18c0:	557d                	li	a0,-1
    18c2:	42d000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    18c6:	4090                	lw	a2,0(s1)
    18c8:	d659                	beqz	a2,1856 <out_unlocked.constprop.0+0x32>
    18ca:	b745                	j	186a <out_unlocked.constprop.0+0x46>

00000000000018cc <putchar>:
{
    18cc:	7139                	addi	sp,sp,-64
    18ce:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18d0:	00001497          	auipc	s1,0x1
    18d4:	0b048493          	addi	s1,s1,176 # 2980 <buffer_len>
    18d8:	1084a703          	lw	a4,264(s1)
{
    18dc:	f822                	sd	s0,48(sp)
	char byte = c;
    18de:	0ff57413          	zext.b	s0,a0
{
    18e2:	fc06                	sd	ra,56(sp)
	char byte = c;
    18e4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18e8:	4785                	li	a5,1
    18ea:	00f70d63          	beq	a4,a5,1904 <putchar+0x38>
		len = out_unlocked(s, l);
    18ee:	01f10513          	addi	a0,sp,31
    18f2:	f33ff0ef          	jal	ra,1824 <out_unlocked.constprop.0>
}
    18f6:	70e2                	ld	ra,56(sp)
    18f8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    18fa:	862a                	mv	a2,a0
}
    18fc:	74a2                	ld	s1,40(sp)
    18fe:	8532                	mv	a0,a2
    1900:	6121                	addi	sp,sp,64
    1902:	8082                	ret
		mutex_lock(buffer_lock);
    1904:	10c4a503          	lw	a0,268(s1)
    1908:	625000ef          	jal	ra,272c <mutex_lock>
		buffer[buffer_len++] = c;
    190c:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    190e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1912:	0017861b          	addiw	a2,a5,1
    1916:	97a6                	add	a5,a5,s1
    1918:	c090                	sw	a2,0(s1)
    191a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    191e:	02c6c263          	blt	a3,a2,1942 <putchar+0x76>
    1922:	47a9                	li	a5,10
    1924:	06f40d63          	beq	s0,a5,199e <putchar+0xd2>
    1928:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    192a:	10c4a503          	lw	a0,268(s1)
    192e:	e432                	sd	a2,8(sp)
    1930:	609000ef          	jal	ra,2738 <mutex_unlock>
    1934:	6622                	ld	a2,8(sp)
}
    1936:	70e2                	ld	ra,56(sp)
    1938:	7442                	ld	s0,48(sp)
    193a:	74a2                	ld	s1,40(sp)
    193c:	8532                	mv	a0,a2
    193e:	6121                	addi	sp,sp,64
    1940:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1942:	10000793          	li	a5,256
    1946:	02f61063          	bne	a2,a5,1966 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    194a:	00001597          	auipc	a1,0x1
    194e:	03e58593          	addi	a1,a1,62 # 2988 <buffer>
    1952:	4505                	li	a0,1
    1954:	361000ef          	jal	ra,24b4 <write>
    1958:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    195c:	00001797          	auipc	a5,0x1
    1960:	0207a223          	sw	zero,36(a5) # 2980 <buffer_len>
			if (r < 0) {
    1964:	b7d9                	j	192a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1966:	359000ef          	jal	ra,24be <getpid>
    196a:	842a                	mv	s0,a0
    196c:	00001517          	auipc	a0,0x1
    1970:	f2450513          	addi	a0,a0,-220 # 2890 <enable_deadlock_detect+0x104>
    1974:	221000ef          	jal	ra,2394 <basename>
    1978:	872a                	mv	a4,a0
    197a:	00001617          	auipc	a2,0x1
    197e:	e6e60613          	addi	a2,a2,-402 # 27e8 <enable_deadlock_detect+0x5c>
    1982:	05400793          	li	a5,84
    1986:	86a2                	mv	a3,s0
    1988:	45fd                	li	a1,31
    198a:	00001517          	auipc	a0,0x1
    198e:	f4650513          	addi	a0,a0,-186 # 28d0 <enable_deadlock_detect+0x144>
    1992:	8fbff0ef          	jal	ra,128c <printf>
    1996:	557d                	li	a0,-1
    1998:	357000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    199c:	4090                	lw	a2,0(s1)
    199e:	d651                	beqz	a2,192a <putchar+0x5e>
    19a0:	b76d                	j	194a <putchar+0x7e>

00000000000019a2 <puts>:
{
    19a2:	7139                	addi	sp,sp,-64
    19a4:	f822                	sd	s0,48(sp)
    19a6:	f426                	sd	s1,40(sp)
    19a8:	fc06                	sd	ra,56(sp)
    19aa:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    19ac:	00001417          	auipc	s0,0x1
    19b0:	fd440413          	addi	s0,s0,-44 # 2980 <buffer_len>
{
    19b4:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19b6:	638000ef          	jal	ra,1fee <strlen>
	if (buffer_lock_enabled == 1) {
    19ba:	10842703          	lw	a4,264(s0)
    19be:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19c0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19c2:	04f70563          	beq	a4,a5,1a0c <puts+0x6a>
		len = out_unlocked(s, l);
    19c6:	8526                	mv	a0,s1
    19c8:	d51ff0ef          	jal	ra,1718 <out_unlocked>
    19cc:	892a                	mv	s2,a0
    19ce:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19d0:	00095963          	bgez	s2,19e2 <puts+0x40>
}
    19d4:	70e2                	ld	ra,56(sp)
    19d6:	7442                	ld	s0,48(sp)
    19d8:	7902                	ld	s2,32(sp)
    19da:	8526                	mv	a0,s1
    19dc:	74a2                	ld	s1,40(sp)
    19de:	6121                	addi	sp,sp,64
    19e0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19e2:	10842703          	lw	a4,264(s0)
	char byte = c;
    19e6:	44a9                	li	s1,10
    19e8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19ec:	4785                	li	a5,1
    19ee:	02f70e63          	beq	a4,a5,1a2a <puts+0x88>
		len = out_unlocked(s, l);
    19f2:	01f10513          	addi	a0,sp,31
    19f6:	e2fff0ef          	jal	ra,1824 <out_unlocked.constprop.0>
}
    19fa:	70e2                	ld	ra,56(sp)
    19fc:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19fe:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a02:	7902                	ld	s2,32(sp)
    1a04:	8526                	mv	a0,s1
    1a06:	74a2                	ld	s1,40(sp)
    1a08:	6121                	addi	sp,sp,64
    1a0a:	8082                	ret
		mutex_lock(buffer_lock);
    1a0c:	e42a                	sd	a0,8(sp)
    1a0e:	10c42503          	lw	a0,268(s0)
    1a12:	51b000ef          	jal	ra,272c <mutex_lock>
		len = out_unlocked(s, l);
    1a16:	65a2                	ld	a1,8(sp)
    1a18:	8526                	mv	a0,s1
    1a1a:	cffff0ef          	jal	ra,1718 <out_unlocked>
    1a1e:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a20:	10c42503          	lw	a0,268(s0)
    1a24:	515000ef          	jal	ra,2738 <mutex_unlock>
    1a28:	b75d                	j	19ce <puts+0x2c>
		mutex_lock(buffer_lock);
    1a2a:	10c42503          	lw	a0,268(s0)
    1a2e:	4ff000ef          	jal	ra,272c <mutex_lock>
		buffer[buffer_len++] = c;
    1a32:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a34:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a38:	0017861b          	addiw	a2,a5,1
    1a3c:	97a2                	add	a5,a5,s0
    1a3e:	c010                	sw	a2,0(s0)
    1a40:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a44:	06c6dc63          	bge	a3,a2,1abc <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a48:	10000793          	li	a5,256
    1a4c:	02f61c63          	bne	a2,a5,1a84 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a50:	00001597          	auipc	a1,0x1
    1a54:	f3858593          	addi	a1,a1,-200 # 2988 <buffer>
    1a58:	4505                	li	a0,1
    1a5a:	25b000ef          	jal	ra,24b4 <write>
			if (r < 0) {
    1a5e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a60:	00001797          	auipc	a5,0x1
    1a64:	f207a023          	sw	zero,-224(a5) # 2980 <buffer_len>
			if (r < 0) {
    1a68:	04054c63          	bltz	a0,1ac0 <puts+0x11e>
			if (r < buffer_len) {
    1a6c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a6e:	10c42503          	lw	a0,268(s0)
    1a72:	4c7000ef          	jal	ra,2738 <mutex_unlock>
}
    1a76:	70e2                	ld	ra,56(sp)
    1a78:	7442                	ld	s0,48(sp)
    1a7a:	7902                	ld	s2,32(sp)
    1a7c:	8526                	mv	a0,s1
    1a7e:	74a2                	ld	s1,40(sp)
    1a80:	6121                	addi	sp,sp,64
    1a82:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a84:	23b000ef          	jal	ra,24be <getpid>
    1a88:	84aa                	mv	s1,a0
    1a8a:	00001517          	auipc	a0,0x1
    1a8e:	e0650513          	addi	a0,a0,-506 # 2890 <enable_deadlock_detect+0x104>
    1a92:	103000ef          	jal	ra,2394 <basename>
    1a96:	872a                	mv	a4,a0
    1a98:	00001617          	auipc	a2,0x1
    1a9c:	d5060613          	addi	a2,a2,-688 # 27e8 <enable_deadlock_detect+0x5c>
    1aa0:	05400793          	li	a5,84
    1aa4:	86a6                	mv	a3,s1
    1aa6:	45fd                	li	a1,31
    1aa8:	00001517          	auipc	a0,0x1
    1aac:	e2850513          	addi	a0,a0,-472 # 28d0 <enable_deadlock_detect+0x144>
    1ab0:	fdcff0ef          	jal	ra,128c <printf>
    1ab4:	557d                	li	a0,-1
    1ab6:	239000ef          	jal	ra,24ee <exit>
	if (buffer_len == 0)
    1aba:	4010                	lw	a2,0(s0)
    1abc:	da45                	beqz	a2,1a6c <puts+0xca>
    1abe:	bf49                	j	1a50 <puts+0xae>
    1ac0:	54fd                	li	s1,-1
    1ac2:	b775                	j	1a6e <puts+0xcc>

0000000000001ac4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ac4:	715d                	addi	sp,sp,-80
    1ac6:	e486                	sd	ra,72(sp)
    1ac8:	e0a2                	sd	s0,64(sp)
    1aca:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1acc:	14054363          	bltz	a0,1c12 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ad0:	02b577bb          	remuw	a5,a0,a1
    1ad4:	00001617          	auipc	a2,0x1
    1ad8:	fc460613          	addi	a2,a2,-60 # 2a98 <digits>
	buf[16] = 0;
    1adc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ae0:	0005871b          	sext.w	a4,a1
    1ae4:	1782                	slli	a5,a5,0x20
    1ae6:	9381                	srli	a5,a5,0x20
    1ae8:	97b2                	add	a5,a5,a2
    1aea:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1aee:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1af2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1af6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1af8:	0eb56763          	bltu	a0,a1,1be6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1afc:	02e877bb          	remuw	a5,a6,a4
    1b00:	1782                	slli	a5,a5,0x20
    1b02:	9381                	srli	a5,a5,0x20
    1b04:	97b2                	add	a5,a5,a2
    1b06:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b0a:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b0e:	02f10323          	sb	a5,38(sp)
    1b12:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b14:	0ce86963          	bltu	a6,a4,1be6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b18:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b1c:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b20:	1582                	slli	a1,a1,0x20
    1b22:	9181                	srli	a1,a1,0x20
    1b24:	95b2                	add	a1,a1,a2
    1b26:	0005c583          	lbu	a1,0(a1)
    1b2a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b2e:	0007859b          	sext.w	a1,a5
    1b32:	16e6e563          	bltu	a3,a4,1c9c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b36:	02e7f6bb          	remuw	a3,a5,a4
    1b3a:	1682                	slli	a3,a3,0x20
    1b3c:	9281                	srli	a3,a3,0x20
    1b3e:	96b2                	add	a3,a3,a2
    1b40:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b44:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b48:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b4c:	16e5e163          	bltu	a1,a4,1cae <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b50:	02e876bb          	remuw	a3,a6,a4
    1b54:	1682                	slli	a3,a3,0x20
    1b56:	9281                	srli	a3,a3,0x20
    1b58:	96b2                	add	a3,a3,a2
    1b5a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b5e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b62:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b66:	14e86d63          	bltu	a6,a4,1cc0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b6a:	02e5f6bb          	remuw	a3,a1,a4
    1b6e:	1682                	slli	a3,a3,0x20
    1b70:	9281                	srli	a3,a3,0x20
    1b72:	96b2                	add	a3,a3,a2
    1b74:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b78:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b7c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b80:	10e5e563          	bltu	a1,a4,1c8a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b84:	02e876bb          	remuw	a3,a6,a4
    1b88:	1682                	slli	a3,a3,0x20
    1b8a:	9281                	srli	a3,a3,0x20
    1b8c:	96b2                	add	a3,a3,a2
    1b8e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b92:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b96:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b9a:	14e86263          	bltu	a6,a4,1cde <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b9e:	02e5f6bb          	remuw	a3,a1,a4
    1ba2:	1682                	slli	a3,a3,0x20
    1ba4:	9281                	srli	a3,a3,0x20
    1ba6:	96b2                	add	a3,a3,a2
    1ba8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bac:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bb0:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1bb4:	14e5e463          	bltu	a1,a4,1cfc <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1bb8:	02e876bb          	remuw	a3,a6,a4
    1bbc:	1682                	slli	a3,a3,0x20
    1bbe:	9281                	srli	a3,a3,0x20
    1bc0:	96b2                	add	a3,a3,a2
    1bc2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bc6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1bca:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1bce:	14e86063          	bltu	a6,a4,1d0e <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1bd2:	1782                	slli	a5,a5,0x20
    1bd4:	9381                	srli	a5,a5,0x20
    1bd6:	97b2                	add	a5,a5,a2
    1bd8:	0007c703          	lbu	a4,0(a5)
    1bdc:	4799                	li	a5,6
    1bde:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1be2:	10054763          	bltz	a0,1cf0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1be6:	00001497          	auipc	s1,0x1
    1bea:	d9a48493          	addi	s1,s1,-614 # 2980 <buffer_len>
    1bee:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1bf2:	0828                	addi	a0,sp,24
    1bf4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1bf6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1bf8:	00f50433          	add	s0,a0,a5
    1bfc:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1bfe:	06e68463          	beq	a3,a4,1c66 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c02:	8522                	mv	a0,s0
    1c04:	b15ff0ef          	jal	ra,1718 <out_unlocked>
}
    1c08:	60a6                	ld	ra,72(sp)
    1c0a:	6406                	ld	s0,64(sp)
    1c0c:	74e2                	ld	s1,56(sp)
    1c0e:	6161                	addi	sp,sp,80
    1c10:	8082                	ret
		x = -xx;
    1c12:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c16:	02b877bb          	remuw	a5,a6,a1
    1c1a:	00001617          	auipc	a2,0x1
    1c1e:	e7e60613          	addi	a2,a2,-386 # 2a98 <digits>
	buf[16] = 0;
    1c22:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c26:	0005871b          	sext.w	a4,a1
    1c2a:	1782                	slli	a5,a5,0x20
    1c2c:	9381                	srli	a5,a5,0x20
    1c2e:	97b2                	add	a5,a5,a2
    1c30:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c34:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c38:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c3c:	08b86b63          	bltu	a6,a1,1cd2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c40:	02e8f7bb          	remuw	a5,a7,a4
    1c44:	1782                	slli	a5,a5,0x20
    1c46:	9381                	srli	a5,a5,0x20
    1c48:	97b2                	add	a5,a5,a2
    1c4a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c4e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c52:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c56:	ece8f1e3          	bgeu	a7,a4,1b18 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c5a:	02d00793          	li	a5,45
    1c5e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c62:	47b5                	li	a5,13
    1c64:	b749                	j	1be6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c66:	10c4a503          	lw	a0,268(s1)
    1c6a:	e42e                	sd	a1,8(sp)
    1c6c:	2c1000ef          	jal	ra,272c <mutex_lock>
		len = out_unlocked(s, l);
    1c70:	65a2                	ld	a1,8(sp)
    1c72:	8522                	mv	a0,s0
    1c74:	aa5ff0ef          	jal	ra,1718 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c78:	10c4a503          	lw	a0,268(s1)
    1c7c:	2bd000ef          	jal	ra,2738 <mutex_unlock>
}
    1c80:	60a6                	ld	ra,72(sp)
    1c82:	6406                	ld	s0,64(sp)
    1c84:	74e2                	ld	s1,56(sp)
    1c86:	6161                	addi	sp,sp,80
    1c88:	8082                	ret
		buf[i--] = digits[x % base];
    1c8a:	47a9                	li	a5,10
	if (sign)
    1c8c:	f4055de3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c90:	02d00793          	li	a5,45
    1c94:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c98:	47a5                	li	a5,9
    1c9a:	b7b1                	j	1be6 <printint.constprop.0+0x122>
    1c9c:	47b5                	li	a5,13
	if (sign)
    1c9e:	f40554e3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca2:	02d00793          	li	a5,45
    1ca6:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1caa:	47b1                	li	a5,12
    1cac:	bf2d                	j	1be6 <printint.constprop.0+0x122>
    1cae:	47b1                	li	a5,12
	if (sign)
    1cb0:	f2055be3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb4:	02d00793          	li	a5,45
    1cb8:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1cbc:	47ad                	li	a5,11
    1cbe:	b725                	j	1be6 <printint.constprop.0+0x122>
    1cc0:	47ad                	li	a5,11
	if (sign)
    1cc2:	f20552e3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc6:	02d00793          	li	a5,45
    1cca:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1cce:	47a9                	li	a5,10
    1cd0:	bf19                	j	1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd2:	02d00793          	li	a5,45
    1cd6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cda:	47b9                	li	a5,14
    1cdc:	b729                	j	1be6 <printint.constprop.0+0x122>
    1cde:	47a5                	li	a5,9
	if (sign)
    1ce0:	f00553e3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce4:	02d00793          	li	a5,45
    1ce8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1cec:	47a1                	li	a5,8
    1cee:	bde5                	j	1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf0:	02d00793          	li	a5,45
    1cf4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1cf8:	4795                	li	a5,5
    1cfa:	b5f5                	j	1be6 <printint.constprop.0+0x122>
    1cfc:	47a1                	li	a5,8
	if (sign)
    1cfe:	ee0554e3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d02:	02d00793          	li	a5,45
    1d06:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d0a:	479d                	li	a5,7
    1d0c:	bde9                	j	1be6 <printint.constprop.0+0x122>
    1d0e:	479d                	li	a5,7
	if (sign)
    1d10:	ec055be3          	bgez	a0,1be6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d14:	02d00793          	li	a5,45
    1d18:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d1c:	4799                	li	a5,6
    1d1e:	b5e1                	j	1be6 <printint.constprop.0+0x122>

0000000000001d20 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d20:	02000793          	li	a5,32
    1d24:	00f50663          	beq	a0,a5,1d30 <isspace+0x10>
    1d28:	355d                	addiw	a0,a0,-9
    1d2a:	00553513          	sltiu	a0,a0,5
    1d2e:	8082                	ret
    1d30:	4505                	li	a0,1
}
    1d32:	8082                	ret

0000000000001d34 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d34:	fd05051b          	addiw	a0,a0,-48
}
    1d38:	00a53513          	sltiu	a0,a0,10
    1d3c:	8082                	ret

0000000000001d3e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d3e:	02000613          	li	a2,32
    1d42:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d44:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d48:	ff77869b          	addiw	a3,a5,-9
    1d4c:	04c78c63          	beq	a5,a2,1da4 <atoi+0x66>
    1d50:	0007871b          	sext.w	a4,a5
    1d54:	04d5f863          	bgeu	a1,a3,1da4 <atoi+0x66>
		s++;
	switch (*s) {
    1d58:	02b00693          	li	a3,43
    1d5c:	04d78963          	beq	a5,a3,1dae <atoi+0x70>
    1d60:	02d00693          	li	a3,45
    1d64:	06d78263          	beq	a5,a3,1dc8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d68:	fd07061b          	addiw	a2,a4,-48
    1d6c:	47a5                	li	a5,9
    1d6e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d70:	4e01                	li	t3,0
	while (isdigit(*s))
    1d72:	04c7e963          	bltu	a5,a2,1dc4 <atoi+0x86>
	int n = 0, neg = 0;
    1d76:	4501                	li	a0,0
	while (isdigit(*s))
    1d78:	4825                	li	a6,9
    1d7a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d7e:	0025179b          	slliw	a5,a0,0x2
    1d82:	9fa9                	addw	a5,a5,a0
    1d84:	fd07031b          	addiw	t1,a4,-48
    1d88:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d8c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d90:	0685                	addi	a3,a3,1
    1d92:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d96:	0006071b          	sext.w	a4,a2
    1d9a:	feb870e3          	bgeu	a6,a1,1d7a <atoi+0x3c>
	return neg ? n : -n;
    1d9e:	000e0563          	beqz	t3,1da8 <atoi+0x6a>
}
    1da2:	8082                	ret
		s++;
    1da4:	0505                	addi	a0,a0,1
    1da6:	bf79                	j	1d44 <atoi+0x6>
	return neg ? n : -n;
    1da8:	4113053b          	subw	a0,t1,a7
    1dac:	8082                	ret
	while (isdigit(*s))
    1dae:	00154703          	lbu	a4,1(a0)
    1db2:	47a5                	li	a5,9
		s++;
    1db4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1db8:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1dbc:	4e01                	li	t3,0
	while (isdigit(*s))
    1dbe:	2701                	sext.w	a4,a4
    1dc0:	fac7fbe3          	bgeu	a5,a2,1d76 <atoi+0x38>
    1dc4:	4501                	li	a0,0
}
    1dc6:	8082                	ret
	while (isdigit(*s))
    1dc8:	00154703          	lbu	a4,1(a0)
    1dcc:	47a5                	li	a5,9
		s++;
    1dce:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dd2:	fd07061b          	addiw	a2,a4,-48
    1dd6:	2701                	sext.w	a4,a4
    1dd8:	fec7e6e3          	bltu	a5,a2,1dc4 <atoi+0x86>
		neg = 1;
    1ddc:	4e05                	li	t3,1
    1dde:	bf61                	j	1d76 <atoi+0x38>

0000000000001de0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1de0:	16060d63          	beqz	a2,1f5a <memset+0x17a>
    1de4:	40a007b3          	neg	a5,a0
    1de8:	8b9d                	andi	a5,a5,7
    1dea:	00778693          	addi	a3,a5,7
    1dee:	482d                	li	a6,11
    1df0:	0ff5f713          	zext.b	a4,a1
    1df4:	fff60593          	addi	a1,a2,-1
    1df8:	1706e263          	bltu	a3,a6,1f5c <memset+0x17c>
    1dfc:	16d5ea63          	bltu	a1,a3,1f70 <memset+0x190>
    1e00:	16078563          	beqz	a5,1f6a <memset+0x18a>
    1e04:	00e50023          	sb	a4,0(a0)
    1e08:	4685                	li	a3,1
    1e0a:	00150593          	addi	a1,a0,1
    1e0e:	14d78c63          	beq	a5,a3,1f66 <memset+0x186>
    1e12:	00e500a3          	sb	a4,1(a0)
    1e16:	4689                	li	a3,2
    1e18:	00250593          	addi	a1,a0,2
    1e1c:	14d78d63          	beq	a5,a3,1f76 <memset+0x196>
    1e20:	00e50123          	sb	a4,2(a0)
    1e24:	468d                	li	a3,3
    1e26:	00350593          	addi	a1,a0,3
    1e2a:	12d78b63          	beq	a5,a3,1f60 <memset+0x180>
    1e2e:	00e501a3          	sb	a4,3(a0)
    1e32:	4691                	li	a3,4
    1e34:	00450593          	addi	a1,a0,4
    1e38:	14d78163          	beq	a5,a3,1f7a <memset+0x19a>
    1e3c:	00e50223          	sb	a4,4(a0)
    1e40:	4695                	li	a3,5
    1e42:	00550593          	addi	a1,a0,5
    1e46:	12d78c63          	beq	a5,a3,1f7e <memset+0x19e>
    1e4a:	00e502a3          	sb	a4,5(a0)
    1e4e:	469d                	li	a3,7
    1e50:	00650593          	addi	a1,a0,6
    1e54:	12d79763          	bne	a5,a3,1f82 <memset+0x1a2>
    1e58:	00750593          	addi	a1,a0,7
    1e5c:	00e50323          	sb	a4,6(a0)
    1e60:	481d                	li	a6,7
    1e62:	00871693          	slli	a3,a4,0x8
    1e66:	01071893          	slli	a7,a4,0x10
    1e6a:	8ed9                	or	a3,a3,a4
    1e6c:	01871313          	slli	t1,a4,0x18
    1e70:	0116e6b3          	or	a3,a3,a7
    1e74:	0066e6b3          	or	a3,a3,t1
    1e78:	02071893          	slli	a7,a4,0x20
    1e7c:	02871e13          	slli	t3,a4,0x28
    1e80:	0116e6b3          	or	a3,a3,a7
    1e84:	40f60333          	sub	t1,a2,a5
    1e88:	03071893          	slli	a7,a4,0x30
    1e8c:	01c6e6b3          	or	a3,a3,t3
    1e90:	0116e6b3          	or	a3,a3,a7
    1e94:	03871e13          	slli	t3,a4,0x38
    1e98:	97aa                	add	a5,a5,a0
    1e9a:	ff837893          	andi	a7,t1,-8
    1e9e:	01c6e6b3          	or	a3,a3,t3
    1ea2:	98be                	add	a7,a7,a5
    1ea4:	e394                	sd	a3,0(a5)
    1ea6:	07a1                	addi	a5,a5,8
    1ea8:	ff179ee3          	bne	a5,a7,1ea4 <memset+0xc4>
    1eac:	ff837893          	andi	a7,t1,-8
    1eb0:	011587b3          	add	a5,a1,a7
    1eb4:	010886bb          	addw	a3,a7,a6
    1eb8:	0b130663          	beq	t1,a7,1f64 <memset+0x184>
    1ebc:	00e78023          	sb	a4,0(a5)
    1ec0:	0016859b          	addiw	a1,a3,1
    1ec4:	08c5fb63          	bgeu	a1,a2,1f5a <memset+0x17a>
    1ec8:	00e780a3          	sb	a4,1(a5)
    1ecc:	0026859b          	addiw	a1,a3,2
    1ed0:	08c5f563          	bgeu	a1,a2,1f5a <memset+0x17a>
    1ed4:	00e78123          	sb	a4,2(a5)
    1ed8:	0036859b          	addiw	a1,a3,3
    1edc:	06c5ff63          	bgeu	a1,a2,1f5a <memset+0x17a>
    1ee0:	00e781a3          	sb	a4,3(a5)
    1ee4:	0046859b          	addiw	a1,a3,4
    1ee8:	06c5f963          	bgeu	a1,a2,1f5a <memset+0x17a>
    1eec:	00e78223          	sb	a4,4(a5)
    1ef0:	0056859b          	addiw	a1,a3,5
    1ef4:	06c5f363          	bgeu	a1,a2,1f5a <memset+0x17a>
    1ef8:	00e782a3          	sb	a4,5(a5)
    1efc:	0066859b          	addiw	a1,a3,6
    1f00:	04c5fd63          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f04:	00e78323          	sb	a4,6(a5)
    1f08:	0076859b          	addiw	a1,a3,7
    1f0c:	04c5f763          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f10:	00e783a3          	sb	a4,7(a5)
    1f14:	0086859b          	addiw	a1,a3,8
    1f18:	04c5f163          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f1c:	00e78423          	sb	a4,8(a5)
    1f20:	0096859b          	addiw	a1,a3,9
    1f24:	02c5fb63          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f28:	00e784a3          	sb	a4,9(a5)
    1f2c:	00a6859b          	addiw	a1,a3,10
    1f30:	02c5f563          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f34:	00e78523          	sb	a4,10(a5)
    1f38:	00b6859b          	addiw	a1,a3,11
    1f3c:	00c5ff63          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f40:	00e785a3          	sb	a4,11(a5)
    1f44:	00c6859b          	addiw	a1,a3,12
    1f48:	00c5f963          	bgeu	a1,a2,1f5a <memset+0x17a>
    1f4c:	00e78623          	sb	a4,12(a5)
    1f50:	26b5                	addiw	a3,a3,13
    1f52:	00c6f463          	bgeu	a3,a2,1f5a <memset+0x17a>
    1f56:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f5a:	8082                	ret
    1f5c:	46ad                	li	a3,11
    1f5e:	bd79                	j	1dfc <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f60:	480d                	li	a6,3
    1f62:	b701                	j	1e62 <memset+0x82>
    1f64:	8082                	ret
    1f66:	4805                	li	a6,1
    1f68:	bded                	j	1e62 <memset+0x82>
    1f6a:	85aa                	mv	a1,a0
    1f6c:	4801                	li	a6,0
    1f6e:	bdd5                	j	1e62 <memset+0x82>
    1f70:	87aa                	mv	a5,a0
    1f72:	4681                	li	a3,0
    1f74:	b7a1                	j	1ebc <memset+0xdc>
    1f76:	4809                	li	a6,2
    1f78:	b5ed                	j	1e62 <memset+0x82>
    1f7a:	4811                	li	a6,4
    1f7c:	b5dd                	j	1e62 <memset+0x82>
    1f7e:	4815                	li	a6,5
    1f80:	b5cd                	j	1e62 <memset+0x82>
    1f82:	4819                	li	a6,6
    1f84:	bdf9                	j	1e62 <memset+0x82>

0000000000001f86 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f86:	00054783          	lbu	a5,0(a0)
    1f8a:	0005c703          	lbu	a4,0(a1)
    1f8e:	00e79863          	bne	a5,a4,1f9e <strcmp+0x18>
    1f92:	0505                	addi	a0,a0,1
    1f94:	0585                	addi	a1,a1,1
    1f96:	fbe5                	bnez	a5,1f86 <strcmp>
    1f98:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f9a:	9d19                	subw	a0,a0,a4
    1f9c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f9e:	0007851b          	sext.w	a0,a5
    1fa2:	bfe5                	j	1f9a <strcmp+0x14>

0000000000001fa4 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1fa4:	ca15                	beqz	a2,1fd8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fa6:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1faa:	167d                	addi	a2,a2,-1
    1fac:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fb0:	eb99                	bnez	a5,1fc6 <strncmp+0x22>
    1fb2:	a815                	j	1fe6 <strncmp+0x42>
    1fb4:	00a68e63          	beq	a3,a0,1fd0 <strncmp+0x2c>
    1fb8:	0505                	addi	a0,a0,1
    1fba:	00f71b63          	bne	a4,a5,1fd0 <strncmp+0x2c>
    1fbe:	00054783          	lbu	a5,0(a0)
    1fc2:	cf89                	beqz	a5,1fdc <strncmp+0x38>
    1fc4:	85b2                	mv	a1,a2
    1fc6:	0005c703          	lbu	a4,0(a1)
    1fca:	00158613          	addi	a2,a1,1
    1fce:	f37d                	bnez	a4,1fb4 <strncmp+0x10>
		;
	return *l - *r;
    1fd0:	0007851b          	sext.w	a0,a5
    1fd4:	9d19                	subw	a0,a0,a4
    1fd6:	8082                	ret
		return 0;
    1fd8:	4501                	li	a0,0
}
    1fda:	8082                	ret
	return *l - *r;
    1fdc:	0015c703          	lbu	a4,1(a1)
    1fe0:	4501                	li	a0,0
    1fe2:	9d19                	subw	a0,a0,a4
    1fe4:	8082                	ret
    1fe6:	0005c703          	lbu	a4,0(a1)
    1fea:	4501                	li	a0,0
    1fec:	b7e5                	j	1fd4 <strncmp+0x30>

0000000000001fee <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1fee:	00757793          	andi	a5,a0,7
    1ff2:	cf89                	beqz	a5,200c <strlen+0x1e>
    1ff4:	87aa                	mv	a5,a0
    1ff6:	a029                	j	2000 <strlen+0x12>
    1ff8:	0785                	addi	a5,a5,1
    1ffa:	0077f713          	andi	a4,a5,7
    1ffe:	cb01                	beqz	a4,200e <strlen+0x20>
		if (!*s)
    2000:	0007c703          	lbu	a4,0(a5)
    2004:	fb75                	bnez	a4,1ff8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2006:	40a78533          	sub	a0,a5,a0
}
    200a:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    200c:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    200e:	6394                	ld	a3,0(a5)
    2010:	00001597          	auipc	a1,0x1
    2014:	9585b583          	ld	a1,-1704(a1) # 2968 <enable_deadlock_detect+0x1dc>
    2018:	00001617          	auipc	a2,0x1
    201c:	95863603          	ld	a2,-1704(a2) # 2970 <enable_deadlock_detect+0x1e4>
    2020:	a019                	j	2026 <strlen+0x38>
    2022:	6794                	ld	a3,8(a5)
    2024:	07a1                	addi	a5,a5,8
    2026:	00b68733          	add	a4,a3,a1
    202a:	fff6c693          	not	a3,a3
    202e:	8f75                	and	a4,a4,a3
    2030:	8f71                	and	a4,a4,a2
    2032:	db65                	beqz	a4,2022 <strlen+0x34>
	for (; *s; s++)
    2034:	0007c703          	lbu	a4,0(a5)
    2038:	d779                	beqz	a4,2006 <strlen+0x18>
    203a:	0017c703          	lbu	a4,1(a5)
    203e:	0785                	addi	a5,a5,1
    2040:	d379                	beqz	a4,2006 <strlen+0x18>
    2042:	0017c703          	lbu	a4,1(a5)
    2046:	0785                	addi	a5,a5,1
    2048:	fb6d                	bnez	a4,203a <strlen+0x4c>
    204a:	bf75                	j	2006 <strlen+0x18>

000000000000204c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    204c:	00757713          	andi	a4,a0,7
{
    2050:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2052:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2056:	cb19                	beqz	a4,206c <memchr+0x20>
    2058:	ce25                	beqz	a2,20d0 <memchr+0x84>
    205a:	0007c703          	lbu	a4,0(a5)
    205e:	04b70e63          	beq	a4,a1,20ba <memchr+0x6e>
    2062:	0785                	addi	a5,a5,1
    2064:	0077f713          	andi	a4,a5,7
    2068:	167d                	addi	a2,a2,-1
    206a:	f77d                	bnez	a4,2058 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    206c:	4501                	li	a0,0
	if (n && *s != c) {
    206e:	c235                	beqz	a2,20d2 <memchr+0x86>
    2070:	0007c703          	lbu	a4,0(a5)
    2074:	04b70363          	beq	a4,a1,20ba <memchr+0x6e>
		size_t k = ONES * c;
    2078:	00001517          	auipc	a0,0x1
    207c:	90053503          	ld	a0,-1792(a0) # 2978 <enable_deadlock_detect+0x1ec>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2080:	471d                	li	a4,7
		size_t k = ONES * c;
    2082:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2086:	02c77a63          	bgeu	a4,a2,20ba <memchr+0x6e>
    208a:	00001897          	auipc	a7,0x1
    208e:	8de8b883          	ld	a7,-1826(a7) # 2968 <enable_deadlock_detect+0x1dc>
    2092:	00001817          	auipc	a6,0x1
    2096:	8de83803          	ld	a6,-1826(a6) # 2970 <enable_deadlock_detect+0x1e4>
    209a:	431d                	li	t1,7
    209c:	a029                	j	20a6 <memchr+0x5a>
		     w++, n -= SS)
    209e:	1661                	addi	a2,a2,-8
    20a0:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20a2:	02c37963          	bgeu	t1,a2,20d4 <memchr+0x88>
    20a6:	6398                	ld	a4,0(a5)
    20a8:	8f29                	xor	a4,a4,a0
    20aa:	011706b3          	add	a3,a4,a7
    20ae:	fff74713          	not	a4,a4
    20b2:	8f75                	and	a4,a4,a3
    20b4:	01077733          	and	a4,a4,a6
    20b8:	d37d                	beqz	a4,209e <memchr+0x52>
{
    20ba:	853e                	mv	a0,a5
    20bc:	97b2                	add	a5,a5,a2
    20be:	a021                	j	20c6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20c0:	0505                	addi	a0,a0,1
    20c2:	00f50763          	beq	a0,a5,20d0 <memchr+0x84>
    20c6:	00054703          	lbu	a4,0(a0)
    20ca:	feb71be3          	bne	a4,a1,20c0 <memchr+0x74>
    20ce:	8082                	ret
	return n ? (void *)s : 0;
    20d0:	4501                	li	a0,0
}
    20d2:	8082                	ret
	return n ? (void *)s : 0;
    20d4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20d6:	f275                	bnez	a2,20ba <memchr+0x6e>
}
    20d8:	8082                	ret

00000000000020da <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20da:	1101                	addi	sp,sp,-32
    20dc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20de:	862e                	mv	a2,a1
{
    20e0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20e2:	4581                	li	a1,0
{
    20e4:	e426                	sd	s1,8(sp)
    20e6:	ec06                	sd	ra,24(sp)
    20e8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20ea:	f63ff0ef          	jal	ra,204c <memchr>
	return p ? p - s : n;
    20ee:	c519                	beqz	a0,20fc <strnlen+0x22>
}
    20f0:	60e2                	ld	ra,24(sp)
    20f2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    20f4:	8d05                	sub	a0,a0,s1
}
    20f6:	64a2                	ld	s1,8(sp)
    20f8:	6105                	addi	sp,sp,32
    20fa:	8082                	ret
    20fc:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20fe:	8522                	mv	a0,s0
}
    2100:	6442                	ld	s0,16(sp)
    2102:	64a2                	ld	s1,8(sp)
    2104:	6105                	addi	sp,sp,32
    2106:	8082                	ret

0000000000002108 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2108:	00a5c7b3          	xor	a5,a1,a0
    210c:	8b9d                	andi	a5,a5,7
    210e:	eb95                	bnez	a5,2142 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2110:	0075f793          	andi	a5,a1,7
    2114:	e7b1                	bnez	a5,2160 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2116:	6198                	ld	a4,0(a1)
    2118:	00001617          	auipc	a2,0x1
    211c:	85063603          	ld	a2,-1968(a2) # 2968 <enable_deadlock_detect+0x1dc>
    2120:	00001817          	auipc	a6,0x1
    2124:	85083803          	ld	a6,-1968(a6) # 2970 <enable_deadlock_detect+0x1e4>
    2128:	a029                	j	2132 <stpcpy+0x2a>
    212a:	05a1                	addi	a1,a1,8
    212c:	e118                	sd	a4,0(a0)
    212e:	6198                	ld	a4,0(a1)
    2130:	0521                	addi	a0,a0,8
    2132:	00c707b3          	add	a5,a4,a2
    2136:	fff74693          	not	a3,a4
    213a:	8ff5                	and	a5,a5,a3
    213c:	0107f7b3          	and	a5,a5,a6
    2140:	d7ed                	beqz	a5,212a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2142:	0005c783          	lbu	a5,0(a1)
    2146:	00f50023          	sb	a5,0(a0)
    214a:	c785                	beqz	a5,2172 <stpcpy+0x6a>
    214c:	0015c783          	lbu	a5,1(a1)
    2150:	0505                	addi	a0,a0,1
    2152:	0585                	addi	a1,a1,1
    2154:	00f50023          	sb	a5,0(a0)
    2158:	fbf5                	bnez	a5,214c <stpcpy+0x44>
		;
	return d;
}
    215a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    215c:	0505                	addi	a0,a0,1
    215e:	df45                	beqz	a4,2116 <stpcpy+0xe>
			if (!(*d = *s))
    2160:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2164:	0585                	addi	a1,a1,1
    2166:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    216a:	00f50023          	sb	a5,0(a0)
    216e:	f7fd                	bnez	a5,215c <stpcpy+0x54>
}
    2170:	8082                	ret
    2172:	8082                	ret

0000000000002174 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2174:	00a5c7b3          	xor	a5,a1,a0
    2178:	8b9d                	andi	a5,a5,7
    217a:	1a079863          	bnez	a5,232a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    217e:	0075f793          	andi	a5,a1,7
    2182:	16078463          	beqz	a5,22ea <stpncpy+0x176>
    2186:	ea01                	bnez	a2,2196 <stpncpy+0x22>
    2188:	a421                	j	2390 <stpncpy+0x21c>
    218a:	167d                	addi	a2,a2,-1
    218c:	0505                	addi	a0,a0,1
    218e:	14070e63          	beqz	a4,22ea <stpncpy+0x176>
    2192:	1a060863          	beqz	a2,2342 <stpncpy+0x1ce>
    2196:	0005c783          	lbu	a5,0(a1)
    219a:	0585                	addi	a1,a1,1
    219c:	0075f713          	andi	a4,a1,7
    21a0:	00f50023          	sb	a5,0(a0)
    21a4:	f3fd                	bnez	a5,218a <stpncpy+0x16>
    21a6:	4805                	li	a6,1
    21a8:	1a061863          	bnez	a2,2358 <stpncpy+0x1e4>
    21ac:	40a007b3          	neg	a5,a0
    21b0:	8b9d                	andi	a5,a5,7
    21b2:	4681                	li	a3,0
    21b4:	18061a63          	bnez	a2,2348 <stpncpy+0x1d4>
    21b8:	00778713          	addi	a4,a5,7
    21bc:	45ad                	li	a1,11
    21be:	18b76363          	bltu	a4,a1,2344 <stpncpy+0x1d0>
    21c2:	1ae6eb63          	bltu	a3,a4,2378 <stpncpy+0x204>
    21c6:	1a078363          	beqz	a5,236c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21ca:	00050023          	sb	zero,0(a0)
    21ce:	4685                	li	a3,1
    21d0:	00150713          	addi	a4,a0,1
    21d4:	18d78f63          	beq	a5,a3,2372 <stpncpy+0x1fe>
    21d8:	000500a3          	sb	zero,1(a0)
    21dc:	4689                	li	a3,2
    21de:	00250713          	addi	a4,a0,2
    21e2:	18d78e63          	beq	a5,a3,237e <stpncpy+0x20a>
    21e6:	00050123          	sb	zero,2(a0)
    21ea:	468d                	li	a3,3
    21ec:	00350713          	addi	a4,a0,3
    21f0:	16d78c63          	beq	a5,a3,2368 <stpncpy+0x1f4>
    21f4:	000501a3          	sb	zero,3(a0)
    21f8:	4691                	li	a3,4
    21fa:	00450713          	addi	a4,a0,4
    21fe:	18d78263          	beq	a5,a3,2382 <stpncpy+0x20e>
    2202:	00050223          	sb	zero,4(a0)
    2206:	4695                	li	a3,5
    2208:	00550713          	addi	a4,a0,5
    220c:	16d78d63          	beq	a5,a3,2386 <stpncpy+0x212>
    2210:	000502a3          	sb	zero,5(a0)
    2214:	469d                	li	a3,7
    2216:	00650713          	addi	a4,a0,6
    221a:	16d79863          	bne	a5,a3,238a <stpncpy+0x216>
    221e:	00750713          	addi	a4,a0,7
    2222:	00050323          	sb	zero,6(a0)
    2226:	40f80833          	sub	a6,a6,a5
    222a:	ff887593          	andi	a1,a6,-8
    222e:	97aa                	add	a5,a5,a0
    2230:	95be                	add	a1,a1,a5
    2232:	0007b023          	sd	zero,0(a5)
    2236:	07a1                	addi	a5,a5,8
    2238:	feb79de3          	bne	a5,a1,2232 <stpncpy+0xbe>
    223c:	ff887593          	andi	a1,a6,-8
    2240:	9ead                	addw	a3,a3,a1
    2242:	00b707b3          	add	a5,a4,a1
    2246:	12b80863          	beq	a6,a1,2376 <stpncpy+0x202>
    224a:	00078023          	sb	zero,0(a5)
    224e:	0016871b          	addiw	a4,a3,1
    2252:	0ec77863          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    2256:	000780a3          	sb	zero,1(a5)
    225a:	0026871b          	addiw	a4,a3,2
    225e:	0ec77263          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    2262:	00078123          	sb	zero,2(a5)
    2266:	0036871b          	addiw	a4,a3,3
    226a:	0cc77c63          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    226e:	000781a3          	sb	zero,3(a5)
    2272:	0046871b          	addiw	a4,a3,4
    2276:	0cc77663          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    227a:	00078223          	sb	zero,4(a5)
    227e:	0056871b          	addiw	a4,a3,5
    2282:	0cc77063          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    2286:	000782a3          	sb	zero,5(a5)
    228a:	0066871b          	addiw	a4,a3,6
    228e:	0ac77a63          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    2292:	00078323          	sb	zero,6(a5)
    2296:	0076871b          	addiw	a4,a3,7
    229a:	0ac77463          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    229e:	000783a3          	sb	zero,7(a5)
    22a2:	0086871b          	addiw	a4,a3,8
    22a6:	08c77e63          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    22aa:	00078423          	sb	zero,8(a5)
    22ae:	0096871b          	addiw	a4,a3,9
    22b2:	08c77863          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    22b6:	000784a3          	sb	zero,9(a5)
    22ba:	00a6871b          	addiw	a4,a3,10
    22be:	08c77263          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    22c2:	00078523          	sb	zero,10(a5)
    22c6:	00b6871b          	addiw	a4,a3,11
    22ca:	06c77c63          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    22ce:	000785a3          	sb	zero,11(a5)
    22d2:	00c6871b          	addiw	a4,a3,12
    22d6:	06c77663          	bgeu	a4,a2,2342 <stpncpy+0x1ce>
    22da:	00078623          	sb	zero,12(a5)
    22de:	26b5                	addiw	a3,a3,13
    22e0:	06c6f163          	bgeu	a3,a2,2342 <stpncpy+0x1ce>
    22e4:	000786a3          	sb	zero,13(a5)
    22e8:	8082                	ret
			;
		if (!n || !*s)
    22ea:	c645                	beqz	a2,2392 <stpncpy+0x21e>
    22ec:	0005c783          	lbu	a5,0(a1)
    22f0:	ea078be3          	beqz	a5,21a6 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22f4:	479d                	li	a5,7
    22f6:	02c7ff63          	bgeu	a5,a2,2334 <stpncpy+0x1c0>
    22fa:	00000897          	auipc	a7,0x0
    22fe:	66e8b883          	ld	a7,1646(a7) # 2968 <enable_deadlock_detect+0x1dc>
    2302:	00000817          	auipc	a6,0x0
    2306:	66e83803          	ld	a6,1646(a6) # 2970 <enable_deadlock_detect+0x1e4>
    230a:	431d                	li	t1,7
    230c:	6198                	ld	a4,0(a1)
    230e:	011707b3          	add	a5,a4,a7
    2312:	fff74693          	not	a3,a4
    2316:	8ff5                	and	a5,a5,a3
    2318:	0107f7b3          	and	a5,a5,a6
    231c:	ef81                	bnez	a5,2334 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    231e:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2320:	1661                	addi	a2,a2,-8
    2322:	05a1                	addi	a1,a1,8
    2324:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2326:	fec363e3          	bltu	t1,a2,230c <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    232a:	e609                	bnez	a2,2334 <stpncpy+0x1c0>
    232c:	a08d                	j	238e <stpncpy+0x21a>
    232e:	167d                	addi	a2,a2,-1
    2330:	0505                	addi	a0,a0,1
    2332:	ca01                	beqz	a2,2342 <stpncpy+0x1ce>
    2334:	0005c783          	lbu	a5,0(a1)
    2338:	0585                	addi	a1,a1,1
    233a:	00f50023          	sb	a5,0(a0)
    233e:	fbe5                	bnez	a5,232e <stpncpy+0x1ba>
		;
tail:
    2340:	b59d                	j	21a6 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2342:	8082                	ret
    2344:	472d                	li	a4,11
    2346:	bdb5                	j	21c2 <stpncpy+0x4e>
    2348:	00778713          	addi	a4,a5,7
    234c:	45ad                	li	a1,11
    234e:	fff60693          	addi	a3,a2,-1
    2352:	e6b778e3          	bgeu	a4,a1,21c2 <stpncpy+0x4e>
    2356:	b7fd                	j	2344 <stpncpy+0x1d0>
    2358:	40a007b3          	neg	a5,a0
    235c:	8832                	mv	a6,a2
    235e:	8b9d                	andi	a5,a5,7
    2360:	4681                	li	a3,0
    2362:	e4060be3          	beqz	a2,21b8 <stpncpy+0x44>
    2366:	b7cd                	j	2348 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2368:	468d                	li	a3,3
    236a:	bd75                	j	2226 <stpncpy+0xb2>
    236c:	872a                	mv	a4,a0
    236e:	4681                	li	a3,0
    2370:	bd5d                	j	2226 <stpncpy+0xb2>
    2372:	4685                	li	a3,1
    2374:	bd4d                	j	2226 <stpncpy+0xb2>
    2376:	8082                	ret
    2378:	87aa                	mv	a5,a0
    237a:	4681                	li	a3,0
    237c:	b5f9                	j	224a <stpncpy+0xd6>
    237e:	4689                	li	a3,2
    2380:	b55d                	j	2226 <stpncpy+0xb2>
    2382:	4691                	li	a3,4
    2384:	b54d                	j	2226 <stpncpy+0xb2>
    2386:	4695                	li	a3,5
    2388:	bd79                	j	2226 <stpncpy+0xb2>
    238a:	4699                	li	a3,6
    238c:	bd69                	j	2226 <stpncpy+0xb2>
    238e:	8082                	ret
    2390:	8082                	ret
    2392:	8082                	ret

0000000000002394 <basename>:

char *basename(char *s)
{
    2394:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2396:	c54d                	beqz	a0,2440 <basename+0xac>
    2398:	00054783          	lbu	a5,0(a0)
		return ".";
    239c:	00000517          	auipc	a0,0x0
    23a0:	5c450513          	addi	a0,a0,1476 # 2960 <enable_deadlock_detect+0x1d4>
	if (!s || !*s)
    23a4:	e391                	bnez	a5,23a8 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    23a6:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23a8:	0076f713          	andi	a4,a3,7
    23ac:	87b6                	mv	a5,a3
    23ae:	cf51                	beqz	a4,244a <basename+0xb6>
    23b0:	0785                	addi	a5,a5,1
    23b2:	0077f713          	andi	a4,a5,7
    23b6:	c729                	beqz	a4,2400 <basename+0x6c>
		if (!*s)
    23b8:	0007c703          	lbu	a4,0(a5)
    23bc:	fb75                	bnez	a4,23b0 <basename+0x1c>
	return s - a;
    23be:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23c0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23c2:	cf8d                	beqz	a5,23fc <basename+0x68>
    23c4:	00f68733          	add	a4,a3,a5
    23c8:	02f00593          	li	a1,47
    23cc:	a031                	j	23d8 <basename+0x44>
		s[i] = 0;
    23ce:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23d2:	17fd                	addi	a5,a5,-1
    23d4:	177d                	addi	a4,a4,-1
    23d6:	c39d                	beqz	a5,23fc <basename+0x68>
    23d8:	00074603          	lbu	a2,0(a4)
    23dc:	feb609e3          	beq	a2,a1,23ce <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23e0:	02f00613          	li	a2,47
    23e4:	a011                	j	23e8 <basename+0x54>
    23e6:	cb99                	beqz	a5,23fc <basename+0x68>
    23e8:	853e                	mv	a0,a5
    23ea:	17fd                	addi	a5,a5,-1
    23ec:	00f68733          	add	a4,a3,a5
    23f0:	00074703          	lbu	a4,0(a4)
    23f4:	fec719e3          	bne	a4,a2,23e6 <basename+0x52>
	return s + i;
    23f8:	9536                	add	a0,a0,a3
    23fa:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23fc:	8536                	mv	a0,a3
    23fe:	8082                	ret
    2400:	6390                	ld	a2,0(a5)
    2402:	00000517          	auipc	a0,0x0
    2406:	56653503          	ld	a0,1382(a0) # 2968 <enable_deadlock_detect+0x1dc>
    240a:	00000597          	auipc	a1,0x0
    240e:	5665b583          	ld	a1,1382(a1) # 2970 <enable_deadlock_detect+0x1e4>
    2412:	fff64713          	not	a4,a2
    2416:	962a                	add	a2,a2,a0
    2418:	8f71                	and	a4,a4,a2
    241a:	8f6d                	and	a4,a4,a1
    241c:	eb11                	bnez	a4,2430 <basename+0x9c>
    241e:	6790                	ld	a2,8(a5)
    2420:	07a1                	addi	a5,a5,8
    2422:	00a60733          	add	a4,a2,a0
    2426:	fff64613          	not	a2,a2
    242a:	8f71                	and	a4,a4,a2
    242c:	8f6d                	and	a4,a4,a1
    242e:	db65                	beqz	a4,241e <basename+0x8a>
	for (; *s; s++)
    2430:	0007c703          	lbu	a4,0(a5)
    2434:	d749                	beqz	a4,23be <basename+0x2a>
    2436:	0017c703          	lbu	a4,1(a5)
    243a:	0785                	addi	a5,a5,1
    243c:	ff6d                	bnez	a4,2436 <basename+0xa2>
    243e:	b741                	j	23be <basename+0x2a>
		return ".";
    2440:	00000517          	auipc	a0,0x0
    2444:	52050513          	addi	a0,a0,1312 # 2960 <enable_deadlock_detect+0x1d4>
    2448:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    244a:	6290                	ld	a2,0(a3)
    244c:	00000517          	auipc	a0,0x0
    2450:	51c53503          	ld	a0,1308(a0) # 2968 <enable_deadlock_detect+0x1dc>
    2454:	00000597          	auipc	a1,0x0
    2458:	51c5b583          	ld	a1,1308(a1) # 2970 <enable_deadlock_detect+0x1e4>
    245c:	fff64713          	not	a4,a2
    2460:	962a                	add	a2,a2,a0
    2462:	8f71                	and	a4,a4,a2
    2464:	8f6d                	and	a4,a4,a1
    2466:	df45                	beqz	a4,241e <basename+0x8a>
    2468:	b7f9                	j	2436 <basename+0xa2>

000000000000246a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    246a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    246e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2470:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2474:	2501                	sext.w	a0,a0
    2476:	8082                	ret

0000000000002478 <close>:

int close(int fd)
{
	if (fd == 1) {
    2478:	4785                	li	a5,1
    247a:	00f50863          	beq	a0,a5,248a <close+0x12>
	register long a7 __asm__("a7") = n;
    247e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2482:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2486:	2501                	sext.w	a0,a0
    2488:	8082                	ret
{
    248a:	1101                	addi	sp,sp,-32
    248c:	ec06                	sd	ra,24(sp)
    248e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2490:	cdffe0ef          	jal	ra,116e <__write_buffer>
		__clear_buffer();
    2494:	d03fe0ef          	jal	ra,1196 <__clear_buffer>
    2498:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    249a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    249e:	00000073          	ecall
}
    24a2:	60e2                	ld	ra,24(sp)
    24a4:	2501                	sext.w	a0,a0
    24a6:	6105                	addi	sp,sp,32
    24a8:	8082                	ret

00000000000024aa <read>:
	register long a7 __asm__("a7") = n;
    24aa:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24ae:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24b2:	8082                	ret

00000000000024b4 <write>:
	register long a7 __asm__("a7") = n;
    24b4:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24b8:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    24bc:	8082                	ret

00000000000024be <getpid>:
	register long a7 __asm__("a7") = n;
    24be:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24c2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24c6:	2501                	sext.w	a0,a0
    24c8:	8082                	ret

00000000000024ca <getppid>:
	register long a7 __asm__("a7") = n;
    24ca:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24ce:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24d2:	2501                	sext.w	a0,a0
    24d4:	8082                	ret

00000000000024d6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24d6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24da:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24de:	2501                	sext.w	a0,a0
    24e0:	8082                	ret

00000000000024e2 <fork>:
	register long a7 __asm__("a7") = n;
    24e2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24e6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24ea:	2501                	sext.w	a0,a0
    24ec:	8082                	ret

00000000000024ee <exit>:

void exit(int code)
{
    24ee:	1141                	addi	sp,sp,-16
    24f0:	e406                	sd	ra,8(sp)
    24f2:	e022                	sd	s0,0(sp)
    24f4:	842a                	mv	s0,a0
	__write_buffer();
    24f6:	c79fe0ef          	jal	ra,116e <__write_buffer>
	__clear_buffer();
    24fa:	c9dfe0ef          	jal	ra,1196 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24fe:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2502:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2504:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2508:	60a2                	ld	ra,8(sp)
    250a:	6402                	ld	s0,0(sp)
    250c:	0141                	addi	sp,sp,16
    250e:	8082                	ret

0000000000002510 <waitpid>:
	register long a7 __asm__("a7") = n;
    2510:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2514:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2518:	2501                	sext.w	a0,a0
    251a:	8082                	ret

000000000000251c <exec>:
	register long a7 __asm__("a7") = n;
    251c:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2520:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2524:	2501                	sext.w	a0,a0
    2526:	8082                	ret

0000000000002528 <get_mtime>:

int64 get_mtime()
{
    2528:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    252a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    252e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2530:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2532:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2536:	2501                	sext.w	a0,a0
    2538:	ed01                	bnez	a0,2550 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    253a:	6722                	ld	a4,8(sp)
    253c:	3e800793          	li	a5,1000
    2540:	6682                	ld	a3,0(sp)
    2542:	02f75733          	divu	a4,a4,a5
    2546:	02d78533          	mul	a0,a5,a3
    254a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    254c:	0141                	addi	sp,sp,16
    254e:	8082                	ret
	return -1;
    2550:	557d                	li	a0,-1
    2552:	bfed                	j	254c <get_mtime+0x24>

0000000000002554 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2554:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2558:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    255c:	2501                	sext.w	a0,a0
    255e:	8082                	ret

0000000000002560 <sleep>:

int sleep(unsigned long long time)
{
    2560:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2562:	880a                	mv	a6,sp
{
    2564:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2566:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    256a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    256c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    256e:	00000073          	ecall
	if (err == 0) {
    2572:	2501                	sext.w	a0,a0
    2574:	ed31                	bnez	a0,25d0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2576:	6722                	ld	a4,8(sp)
    2578:	3e800793          	li	a5,1000
    257c:	6682                	ld	a3,0(sp)
    257e:	02f75733          	divu	a4,a4,a5
    2582:	02d787b3          	mul	a5,a5,a3
    2586:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2588:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    258c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    258e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2590:	00000073          	ecall
	if (err == 0) {
    2594:	2501                	sext.w	a0,a0
    2596:	e915                	bnez	a0,25ca <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2598:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    259a:	3e800693          	li	a3,1000
    259e:	a819                	j	25b4 <sleep+0x54>
	__asm_syscall("r"(a7))
    25a0:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25a4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25a8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25aa:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ac:	00000073          	ecall
	if (err == 0) {
    25b0:	2501                	sext.w	a0,a0
    25b2:	ed01                	bnez	a0,25ca <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25b4:	6722                	ld	a4,8(sp)
    25b6:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25b8:	07c00893          	li	a7,124
    25bc:	02d75733          	divu	a4,a4,a3
    25c0:	02f687b3          	mul	a5,a3,a5
    25c4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25c6:	fcc7ede3          	bltu	a5,a2,25a0 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25ca:	4501                	li	a0,0
    25cc:	0141                	addi	sp,sp,16
    25ce:	8082                	ret
    25d0:	57fd                	li	a5,-1
    25d2:	bf5d                	j	2588 <sleep+0x28>

00000000000025d4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25d4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25d8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25dc:	2501                	sext.w	a0,a0
    25de:	8082                	ret

00000000000025e0 <set_priority>:
	register long a7 __asm__("a7") = n;
    25e0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25e4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25e8:	2501                	sext.w	a0,a0
    25ea:	8082                	ret

00000000000025ec <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25ec:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25f0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    25f4:	2501                	sext.w	a0,a0
    25f6:	8082                	ret

00000000000025f8 <munmap>:
	register long a7 __asm__("a7") = n;
    25f8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fc:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2600:	2501                	sext.w	a0,a0
    2602:	8082                	ret

0000000000002604 <wait>:

int wait(int *code)
{
    2604:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2606:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    260a:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    260c:	00000073          	ecall
	return waitpid(-1, code);
}
    2610:	2501                	sext.w	a0,a0
    2612:	8082                	ret

0000000000002614 <spawn>:
	register long a7 __asm__("a7") = n;
    2614:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2618:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    261c:	2501                	sext.w	a0,a0
    261e:	8082                	ret

0000000000002620 <pipe>:
	register long a7 __asm__("a7") = n;
    2620:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2624:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2628:	2501                	sext.w	a0,a0
    262a:	8082                	ret

000000000000262c <mailread>:
	register long a7 __asm__("a7") = n;
    262c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2630:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2634:	2501                	sext.w	a0,a0
    2636:	8082                	ret

0000000000002638 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2638:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    263c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2640:	2501                	sext.w	a0,a0
    2642:	8082                	ret

0000000000002644 <fstat>:
	register long a7 __asm__("a7") = n;
    2644:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2648:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    264c:	2501                	sext.w	a0,a0
    264e:	8082                	ret

0000000000002650 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2650:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2652:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2656:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2658:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    265c:	2501                	sext.w	a0,a0
    265e:	8082                	ret

0000000000002660 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2660:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2662:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2666:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2668:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    266c:	2501                	sext.w	a0,a0
    266e:	8082                	ret

0000000000002670 <link>:

int link(char *old_path, char *new_path)
{
    2670:	87aa                	mv	a5,a0
    2672:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2674:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2678:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    267c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    267e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2682:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2684:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <unlink>:

int unlink(char *path)
{
    268c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    268e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2692:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2696:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2698:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    269c:	2501                	sext.w	a0,a0
    269e:	8082                	ret

00000000000026a0 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    26a0:	00000797          	auipc	a5,0x0
    26a4:	4187b783          	ld	a5,1048(a5) # 2ab8 <_GLOBAL_OFFSET_TABLE_+0x8>
    26a8:	439c                	lw	a5,0(a5)
    26aa:	c799                	beqz	a5,26b8 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    26ac:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b0:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26b4:	2501                	sext.w	a0,a0
    26b6:	8082                	ret
{
    26b8:	1101                	addi	sp,sp,-32
    26ba:	ec06                	sd	ra,24(sp)
    26bc:	e42e                	sd	a1,8(sp)
    26be:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26c0:	fe7fe0ef          	jal	ra,16a6 <enable_thread_io_buffer>
    26c4:	65a2                	ld	a1,8(sp)
    26c6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26c8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26cc:	00000073          	ecall
}
    26d0:	60e2                	ld	ra,24(sp)
    26d2:	2501                	sext.w	a0,a0
    26d4:	6105                	addi	sp,sp,32
    26d6:	8082                	ret

00000000000026d8 <gettid>:
	register long a7 __asm__("a7") = n;
    26d8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26dc:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26e0:	2501                	sext.w	a0,a0
    26e2:	8082                	ret

00000000000026e4 <waittid>:

int waittid(int tid)
{
    26e4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26e6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26ea:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26ee:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    26f0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26f2:	00e51e63          	bne	a0,a4,270e <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    26f6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26fa:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26fe:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2702:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2708:	2501                	sext.w	a0,a0
	while (ret == -2) {
    270a:	fee506e3          	beq	a0,a4,26f6 <waittid+0x12>
	}
	return ret;
}
    270e:	8082                	ret

0000000000002710 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2710:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2714:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2716:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    271a:	2501                	sext.w	a0,a0
    271c:	8082                	ret

000000000000271e <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    271e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2722:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2724:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2728:	2501                	sext.w	a0,a0
    272a:	8082                	ret

000000000000272c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    272c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2730:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2734:	2501                	sext.w	a0,a0
    2736:	8082                	ret

0000000000002738 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2738:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    273c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2740:	2501                	sext.w	a0,a0
    2742:	8082                	ret

0000000000002744 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2744:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2748:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    274c:	2501                	sext.w	a0,a0
    274e:	8082                	ret

0000000000002750 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2750:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2754:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2758:	2501                	sext.w	a0,a0
    275a:	8082                	ret

000000000000275c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    275c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2760:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2764:	2501                	sext.w	a0,a0
    2766:	8082                	ret

0000000000002768 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2768:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    276c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2770:	2501                	sext.w	a0,a0
    2772:	8082                	ret

0000000000002774 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2774:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2778:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    277c:	2501                	sext.w	a0,a0
    277e:	8082                	ret

0000000000002780 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2780:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2784:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2788:	2501                	sext.w	a0,a0
    278a:	8082                	ret

000000000000278c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    278c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2790:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2794:	2501                	sext.w	a0,a0
    2796:	8082                	ret
