
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_mpsc_sem:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a965                	j	14b8 <__start_main>

0000000000001002 <producer>:
int front = 0;
int tail = 0;
int threads[producers + 1];

void producer(int id)
{
    1002:	715d                	addi	sp,sp,-80
    1004:	ec56                	sd	s5,24(sp)
	printf("producer %d started task\n", id);
    1006:	85aa                	mv	a1,a0
{
    1008:	8aaa                	mv	s5,a0
	printf("producer %d started task\n", id);
    100a:	00002517          	auipc	a0,0x2
    100e:	b1650513          	addi	a0,a0,-1258 # 2b20 <enable_deadlock_detect+0xe>
{
    1012:	e0a2                	sd	s0,64(sp)
    1014:	fc26                	sd	s1,56(sp)
    1016:	f84a                	sd	s2,48(sp)
    1018:	f44e                	sd	s3,40(sp)
    101a:	f052                	sd	s4,32(sp)
    101c:	e486                	sd	ra,72(sp)
    101e:	e85a                	sd	s6,16(sp)
    1020:	e45e                	sd	s7,8(sp)
	printf("producer %d started task\n", id);
    1022:	06400493          	li	s1,100
    1026:	5ec000ef          	jal	ra,1612 <printf>
	for (int i = 0; i < number_per_producer; i++) {
    102a:	00002417          	auipc	s0,0x2
    102e:	e4640413          	addi	s0,s0,-442 # 2e70 <sem_empty_id>
		assert_eq(semaphore_down(sem_empty_id), 0);
    1032:	00002a17          	auipc	s4,0x2
    1036:	b0ea0a13          	addi	s4,s4,-1266 # 2b40 <enable_deadlock_detect+0x2e>
    103a:	00002997          	auipc	s3,0x2
    103e:	b4e98993          	addi	s3,s3,-1202 # 2b88 <enable_deadlock_detect+0x76>
    1042:	00002917          	auipc	s2,0x2
    1046:	b4e90913          	addi	s2,s2,-1202 # 2b90 <enable_deadlock_detect+0x7e>
    104a:	a83d                	j	1088 <producer+0x86>
		assert_eq(semaphore_down(sem_mutex_id), 0);
    104c:	4048                	lw	a0,4(s0)
    104e:	295010ef          	jal	ra,2ae2 <semaphore_down>
    1052:	e935                	bnez	a0,10c6 <producer+0xc4>
		buffer[front] = id;
    1054:	4418                	lw	a4,8(s0)
		front = (front + 1) % buffer_size;
		assert_eq(semaphore_up(sem_mutex_id), 0);
    1056:	4048                	lw	a0,4(s0)
		front = (front + 1) % buffer_size;
    1058:	0017079b          	addiw	a5,a4,1
    105c:	41f7d69b          	sraiw	a3,a5,0x1f
    1060:	01d6d69b          	srliw	a3,a3,0x1d
    1064:	9fb5                	addw	a5,a5,a3
		buffer[front] = id;
    1066:	070a                	slli	a4,a4,0x2
		front = (front + 1) % buffer_size;
    1068:	8b9d                	andi	a5,a5,7
		buffer[front] = id;
    106a:	9722                	add	a4,a4,s0
		front = (front + 1) % buffer_size;
    106c:	9f95                	subw	a5,a5,a3
		buffer[front] = id;
    106e:	01572823          	sw	s5,16(a4)
		front = (front + 1) % buffer_size;
    1072:	c41c                	sw	a5,8(s0)
		assert_eq(semaphore_up(sem_mutex_id), 0);
    1074:	263010ef          	jal	ra,2ad6 <semaphore_up>
    1078:	0c051c63          	bnez	a0,1150 <producer+0x14e>
		assert_eq(semaphore_up(sem_existed_id), 0);
    107c:	5808                	lw	a0,48(s0)
    107e:	259010ef          	jal	ra,2ad6 <semaphore_up>
    1082:	e935                	bnez	a0,10f6 <producer+0xf4>
	for (int i = 0; i < number_per_producer; i++) {
    1084:	34fd                	addiw	s1,s1,-1
    1086:	c0cd                	beqz	s1,1128 <producer+0x126>
		assert_eq(semaphore_down(sem_empty_id), 0);
    1088:	4008                	lw	a0,0(s0)
    108a:	259010ef          	jal	ra,2ae2 <semaphore_down>
    108e:	dd5d                	beqz	a0,104c <producer+0x4a>
    1090:	7b4010ef          	jal	ra,2844 <getpid>
    1094:	8b2a                	mv	s6,a0
    1096:	8552                	mv	a0,s4
    1098:	682010ef          	jal	ra,271a <basename>
    109c:	8baa                	mv	s7,a0
    109e:	4008                	lw	a0,0(s0)
    10a0:	243010ef          	jal	ra,2ae2 <semaphore_down>
    10a4:	882a                	mv	a6,a0
    10a6:	4881                	li	a7,0
    10a8:	854a                	mv	a0,s2
    10aa:	47e1                	li	a5,24
    10ac:	875e                	mv	a4,s7
    10ae:	86da                	mv	a3,s6
    10b0:	864e                	mv	a2,s3
    10b2:	45fd                	li	a1,31
    10b4:	55e000ef          	jal	ra,1612 <printf>
    10b8:	557d                	li	a0,-1
    10ba:	7ba010ef          	jal	ra,2874 <exit>
		assert_eq(semaphore_down(sem_mutex_id), 0);
    10be:	4048                	lw	a0,4(s0)
    10c0:	223010ef          	jal	ra,2ae2 <semaphore_down>
    10c4:	d941                	beqz	a0,1054 <producer+0x52>
    10c6:	77e010ef          	jal	ra,2844 <getpid>
    10ca:	8b2a                	mv	s6,a0
    10cc:	8552                	mv	a0,s4
    10ce:	64c010ef          	jal	ra,271a <basename>
    10d2:	8baa                	mv	s7,a0
    10d4:	4048                	lw	a0,4(s0)
    10d6:	20d010ef          	jal	ra,2ae2 <semaphore_down>
    10da:	882a                	mv	a6,a0
    10dc:	4881                	li	a7,0
    10de:	854a                	mv	a0,s2
    10e0:	47e5                	li	a5,25
    10e2:	875e                	mv	a4,s7
    10e4:	86da                	mv	a3,s6
    10e6:	864e                	mv	a2,s3
    10e8:	45fd                	li	a1,31
    10ea:	528000ef          	jal	ra,1612 <printf>
    10ee:	557d                	li	a0,-1
    10f0:	784010ef          	jal	ra,2874 <exit>
    10f4:	b785                	j	1054 <producer+0x52>
		assert_eq(semaphore_up(sem_existed_id), 0);
    10f6:	74e010ef          	jal	ra,2844 <getpid>
    10fa:	8b2a                	mv	s6,a0
    10fc:	8552                	mv	a0,s4
    10fe:	61c010ef          	jal	ra,271a <basename>
    1102:	8baa                	mv	s7,a0
    1104:	5808                	lw	a0,48(s0)
	for (int i = 0; i < number_per_producer; i++) {
    1106:	34fd                	addiw	s1,s1,-1
		assert_eq(semaphore_up(sem_existed_id), 0);
    1108:	1cf010ef          	jal	ra,2ad6 <semaphore_up>
    110c:	882a                	mv	a6,a0
    110e:	4881                	li	a7,0
    1110:	854a                	mv	a0,s2
    1112:	47f5                	li	a5,29
    1114:	875e                	mv	a4,s7
    1116:	86da                	mv	a3,s6
    1118:	864e                	mv	a2,s3
    111a:	45fd                	li	a1,31
    111c:	4f6000ef          	jal	ra,1612 <printf>
    1120:	557d                	li	a0,-1
    1122:	752010ef          	jal	ra,2874 <exit>
	for (int i = 0; i < number_per_producer; i++) {
    1126:	f0ad                	bnez	s1,1088 <producer+0x86>
	}
	printf("producer %d finished task\n", id);
    1128:	00002517          	auipc	a0,0x2
    112c:	aa050513          	addi	a0,a0,-1376 # 2bc8 <enable_deadlock_detect+0xb6>
    1130:	85d6                	mv	a1,s5
    1132:	4e0000ef          	jal	ra,1612 <printf>
	exit(0);
}
    1136:	6406                	ld	s0,64(sp)
    1138:	60a6                	ld	ra,72(sp)
    113a:	74e2                	ld	s1,56(sp)
    113c:	7942                	ld	s2,48(sp)
    113e:	79a2                	ld	s3,40(sp)
    1140:	7a02                	ld	s4,32(sp)
    1142:	6ae2                	ld	s5,24(sp)
    1144:	6b42                	ld	s6,16(sp)
    1146:	6ba2                	ld	s7,8(sp)
	exit(0);
    1148:	4501                	li	a0,0
}
    114a:	6161                	addi	sp,sp,80
	exit(0);
    114c:	7280106f          	j	2874 <exit>
		assert_eq(semaphore_up(sem_mutex_id), 0);
    1150:	6f4010ef          	jal	ra,2844 <getpid>
    1154:	8b2a                	mv	s6,a0
    1156:	8552                	mv	a0,s4
    1158:	5c2010ef          	jal	ra,271a <basename>
    115c:	8baa                	mv	s7,a0
    115e:	4048                	lw	a0,4(s0)
    1160:	177010ef          	jal	ra,2ad6 <semaphore_up>
    1164:	882a                	mv	a6,a0
    1166:	4881                	li	a7,0
    1168:	854a                	mv	a0,s2
    116a:	47f1                	li	a5,28
    116c:	875e                	mv	a4,s7
    116e:	86da                	mv	a3,s6
    1170:	864e                	mv	a2,s3
    1172:	45fd                	li	a1,31
    1174:	49e000ef          	jal	ra,1612 <printf>
    1178:	557d                	li	a0,-1
    117a:	6fa010ef          	jal	ra,2874 <exit>
    117e:	bdfd                	j	107c <producer+0x7a>

0000000000001180 <consumer>:

void consumer()
{
    1180:	715d                	addi	sp,sp,-80
	puts("consumer started task");
    1182:	00002517          	auipc	a0,0x2
    1186:	a6650513          	addi	a0,a0,-1434 # 2be8 <enable_deadlock_detect+0xd6>
{
    118a:	e0a2                	sd	s0,64(sp)
    118c:	fc26                	sd	s1,56(sp)
    118e:	f84a                	sd	s2,48(sp)
    1190:	f44e                	sd	s3,40(sp)
    1192:	f052                	sd	s4,32(sp)
    1194:	ec56                	sd	s5,24(sp)
    1196:	e486                	sd	ra,72(sp)
    1198:	e85a                	sd	s6,16(sp)
    119a:	e45e                	sd	s7,8(sp)
	puts("consumer started task");
    119c:	19000493          	li	s1,400
    11a0:	389000ef          	jal	ra,1d28 <puts>
	for (int i = 0; i < number_per_producer * producers; i++) {
    11a4:	00002417          	auipc	s0,0x2
    11a8:	ccc40413          	addi	s0,s0,-820 # 2e70 <sem_empty_id>
		assert_eq(semaphore_down(sem_existed_id), 0);
    11ac:	00002a17          	auipc	s4,0x2
    11b0:	994a0a13          	addi	s4,s4,-1644 # 2b40 <enable_deadlock_detect+0x2e>
    11b4:	00002997          	auipc	s3,0x2
    11b8:	9d498993          	addi	s3,s3,-1580 # 2b88 <enable_deadlock_detect+0x76>
    11bc:	00002917          	auipc	s2,0x2
    11c0:	9d490913          	addi	s2,s2,-1580 # 2b90 <enable_deadlock_detect+0x7e>
		assert_eq(semaphore_down(sem_mutex_id), 0);
		printf("%d ", buffer[tail]);
    11c4:	00002a97          	auipc	s5,0x2
    11c8:	a3ca8a93          	addi	s5,s5,-1476 # 2c00 <enable_deadlock_detect+0xee>
    11cc:	a089                	j	120e <consumer+0x8e>
		assert_eq(semaphore_down(sem_mutex_id), 0);
    11ce:	4048                	lw	a0,4(s0)
    11d0:	113010ef          	jal	ra,2ae2 <semaphore_down>
    11d4:	ed2d                	bnez	a0,124e <consumer+0xce>
		printf("%d ", buffer[tail]);
    11d6:	585c                	lw	a5,52(s0)
    11d8:	8556                	mv	a0,s5
    11da:	078a                	slli	a5,a5,0x2
    11dc:	97a2                	add	a5,a5,s0
    11de:	4b8c                	lw	a1,16(a5)
    11e0:	432000ef          	jal	ra,1612 <printf>
		tail = (tail + 1) % buffer_size;
    11e4:	585c                	lw	a5,52(s0)
		assert_eq(semaphore_up(sem_mutex_id), 0);
    11e6:	4048                	lw	a0,4(s0)
		tail = (tail + 1) % buffer_size;
    11e8:	2785                	addiw	a5,a5,1
    11ea:	41f7d71b          	sraiw	a4,a5,0x1f
    11ee:	01d7571b          	srliw	a4,a4,0x1d
    11f2:	9fb9                	addw	a5,a5,a4
    11f4:	8b9d                	andi	a5,a5,7
    11f6:	9f99                	subw	a5,a5,a4
    11f8:	d85c                	sw	a5,52(s0)
		assert_eq(semaphore_up(sem_mutex_id), 0);
    11fa:	0dd010ef          	jal	ra,2ad6 <semaphore_up>
    11fe:	0c051e63          	bnez	a0,12da <consumer+0x15a>
		assert_eq(semaphore_up(sem_empty_id), 0);
    1202:	4008                	lw	a0,0(s0)
    1204:	0d3010ef          	jal	ra,2ad6 <semaphore_up>
    1208:	ed25                	bnez	a0,1280 <consumer+0x100>
	for (int i = 0; i < number_per_producer * producers; i++) {
    120a:	34fd                	addiw	s1,s1,-1
    120c:	c4c5                	beqz	s1,12b4 <consumer+0x134>
		assert_eq(semaphore_down(sem_existed_id), 0);
    120e:	5808                	lw	a0,48(s0)
    1210:	0d3010ef          	jal	ra,2ae2 <semaphore_down>
    1214:	dd4d                	beqz	a0,11ce <consumer+0x4e>
    1216:	62e010ef          	jal	ra,2844 <getpid>
    121a:	8b2a                	mv	s6,a0
    121c:	8552                	mv	a0,s4
    121e:	4fc010ef          	jal	ra,271a <basename>
    1222:	8baa                	mv	s7,a0
    1224:	5808                	lw	a0,48(s0)
    1226:	0bd010ef          	jal	ra,2ae2 <semaphore_down>
    122a:	882a                	mv	a6,a0
    122c:	4881                	li	a7,0
    122e:	854a                	mv	a0,s2
    1230:	02700793          	li	a5,39
    1234:	875e                	mv	a4,s7
    1236:	86da                	mv	a3,s6
    1238:	864e                	mv	a2,s3
    123a:	45fd                	li	a1,31
    123c:	3d6000ef          	jal	ra,1612 <printf>
    1240:	557d                	li	a0,-1
    1242:	632010ef          	jal	ra,2874 <exit>
		assert_eq(semaphore_down(sem_mutex_id), 0);
    1246:	4048                	lw	a0,4(s0)
    1248:	09b010ef          	jal	ra,2ae2 <semaphore_down>
    124c:	d549                	beqz	a0,11d6 <consumer+0x56>
    124e:	5f6010ef          	jal	ra,2844 <getpid>
    1252:	8b2a                	mv	s6,a0
    1254:	8552                	mv	a0,s4
    1256:	4c4010ef          	jal	ra,271a <basename>
    125a:	8baa                	mv	s7,a0
    125c:	4048                	lw	a0,4(s0)
    125e:	085010ef          	jal	ra,2ae2 <semaphore_down>
    1262:	882a                	mv	a6,a0
    1264:	4881                	li	a7,0
    1266:	854a                	mv	a0,s2
    1268:	02800793          	li	a5,40
    126c:	875e                	mv	a4,s7
    126e:	86da                	mv	a3,s6
    1270:	864e                	mv	a2,s3
    1272:	45fd                	li	a1,31
    1274:	39e000ef          	jal	ra,1612 <printf>
    1278:	557d                	li	a0,-1
    127a:	5fa010ef          	jal	ra,2874 <exit>
    127e:	bfa1                	j	11d6 <consumer+0x56>
		assert_eq(semaphore_up(sem_empty_id), 0);
    1280:	5c4010ef          	jal	ra,2844 <getpid>
    1284:	8b2a                	mv	s6,a0
    1286:	8552                	mv	a0,s4
    1288:	492010ef          	jal	ra,271a <basename>
    128c:	8baa                	mv	s7,a0
    128e:	4008                	lw	a0,0(s0)
	for (int i = 0; i < number_per_producer * producers; i++) {
    1290:	34fd                	addiw	s1,s1,-1
		assert_eq(semaphore_up(sem_empty_id), 0);
    1292:	045010ef          	jal	ra,2ad6 <semaphore_up>
    1296:	882a                	mv	a6,a0
    1298:	4881                	li	a7,0
    129a:	854a                	mv	a0,s2
    129c:	02c00793          	li	a5,44
    12a0:	875e                	mv	a4,s7
    12a2:	86da                	mv	a3,s6
    12a4:	864e                	mv	a2,s3
    12a6:	45fd                	li	a1,31
    12a8:	36a000ef          	jal	ra,1612 <printf>
    12ac:	557d                	li	a0,-1
    12ae:	5c6010ef          	jal	ra,2874 <exit>
	for (int i = 0; i < number_per_producer * producers; i++) {
    12b2:	fcb1                	bnez	s1,120e <consumer+0x8e>
	}
	puts("consumer finished task");
    12b4:	00002517          	auipc	a0,0x2
    12b8:	95450513          	addi	a0,a0,-1708 # 2c08 <enable_deadlock_detect+0xf6>
    12bc:	26d000ef          	jal	ra,1d28 <puts>
	exit(0);
}
    12c0:	6406                	ld	s0,64(sp)
    12c2:	60a6                	ld	ra,72(sp)
    12c4:	74e2                	ld	s1,56(sp)
    12c6:	7942                	ld	s2,48(sp)
    12c8:	79a2                	ld	s3,40(sp)
    12ca:	7a02                	ld	s4,32(sp)
    12cc:	6ae2                	ld	s5,24(sp)
    12ce:	6b42                	ld	s6,16(sp)
    12d0:	6ba2                	ld	s7,8(sp)
	exit(0);
    12d2:	4501                	li	a0,0
}
    12d4:	6161                	addi	sp,sp,80
	exit(0);
    12d6:	59e0106f          	j	2874 <exit>
		assert_eq(semaphore_up(sem_mutex_id), 0);
    12da:	56a010ef          	jal	ra,2844 <getpid>
    12de:	8b2a                	mv	s6,a0
    12e0:	8552                	mv	a0,s4
    12e2:	438010ef          	jal	ra,271a <basename>
    12e6:	8baa                	mv	s7,a0
    12e8:	4048                	lw	a0,4(s0)
    12ea:	7ec010ef          	jal	ra,2ad6 <semaphore_up>
    12ee:	882a                	mv	a6,a0
    12f0:	4881                	li	a7,0
    12f2:	854a                	mv	a0,s2
    12f4:	02b00793          	li	a5,43
    12f8:	875e                	mv	a4,s7
    12fa:	86da                	mv	a3,s6
    12fc:	864e                	mv	a2,s3
    12fe:	45fd                	li	a1,31
    1300:	312000ef          	jal	ra,1612 <printf>
    1304:	557d                	li	a0,-1
    1306:	56e010ef          	jal	ra,2874 <exit>
    130a:	bde5                	j	1202 <consumer+0x82>

000000000000130c <main>:

int main()
{
    130c:	711d                	addi	sp,sp,-96
	assert((sem_mutex_id = semaphore_create(1)) >= 0);
    130e:	4505                	li	a0,1
{
    1310:	f456                	sd	s5,40(sp)
    1312:	ec86                	sd	ra,88(sp)
    1314:	e8a2                	sd	s0,80(sp)
    1316:	e4a6                	sd	s1,72(sp)
    1318:	e0ca                	sd	s2,64(sp)
    131a:	fc4e                	sd	s3,56(sp)
    131c:	f852                	sd	s4,48(sp)
    131e:	f05a                	sd	s6,32(sp)
    1320:	ec5e                	sd	s7,24(sp)
    1322:	e862                	sd	s8,16(sp)
    1324:	e466                	sd	s9,8(sp)
	assert((sem_mutex_id = semaphore_create(1)) >= 0);
    1326:	00002a97          	auipc	s5,0x2
    132a:	b4aa8a93          	addi	s5,s5,-1206 # 2e70 <sem_empty_id>
    132e:	79c010ef          	jal	ra,2aca <semaphore_create>
    1332:	00aaa223          	sw	a0,4(s5)
    1336:	0c054d63          	bltz	a0,1410 <main+0x104>
	assert((sem_empty_id = semaphore_create(buffer_size)) >= 0);
    133a:	4521                	li	a0,8
    133c:	78e010ef          	jal	ra,2aca <semaphore_create>
    1340:	00aaa023          	sw	a0,0(s5)
    1344:	12054e63          	bltz	a0,1480 <main+0x174>
	assert((sem_existed_id = semaphore_create(0)) >= 0);
    1348:	4501                	li	a0,0
    134a:	780010ef          	jal	ra,2aca <semaphore_create>
    134e:	02aaa823          	sw	a0,48(s5)
    1352:	0e054b63          	bltz	a0,1448 <main+0x13c>
    1356:	00002417          	auipc	s0,0x2
    135a:	b5240413          	addi	s0,s0,-1198 # 2ea8 <threads>
{
    135e:	8922                	mv	s2,s0
    1360:	4481                	li	s1,0
	for (int i = 0; i < producers; i++) {
		threads[i] = thread_create(producer, (void *)i);
    1362:	00000a17          	auipc	s4,0x0
    1366:	ca0a0a13          	addi	s4,s4,-864 # 1002 <producer>
		assert(threads[i] > 0);
    136a:	00001c97          	auipc	s9,0x1
    136e:	7d6c8c93          	addi	s9,s9,2006 # 2b40 <enable_deadlock_detect+0x2e>
    1372:	00002c17          	auipc	s8,0x2
    1376:	816c0c13          	addi	s8,s8,-2026 # 2b88 <enable_deadlock_detect+0x76>
    137a:	00002b97          	auipc	s7,0x2
    137e:	9aeb8b93          	addi	s7,s7,-1618 # 2d28 <enable_deadlock_detect+0x216>
	for (int i = 0; i < producers; i++) {
    1382:	4991                	li	s3,4
		threads[i] = thread_create(producer, (void *)i);
    1384:	85a6                	mv	a1,s1
    1386:	8552                	mv	a0,s4
    1388:	69e010ef          	jal	ra,2a26 <thread_create>
    138c:	00a92023          	sw	a0,0(s2)
	for (int i = 0; i < producers; i++) {
    1390:	0485                	addi	s1,s1,1
		assert(threads[i] > 0);
    1392:	04a05c63          	blez	a0,13ea <main+0xde>
	for (int i = 0; i < producers; i++) {
    1396:	0911                	addi	s2,s2,4
    1398:	ff3496e3          	bne	s1,s3,1384 <main+0x78>
	}
	threads[producers] = thread_create(consumer, 0);
    139c:	4581                	li	a1,0
    139e:	00000517          	auipc	a0,0x0
    13a2:	de250513          	addi	a0,a0,-542 # 1180 <consumer>
    13a6:	680010ef          	jal	ra,2a26 <thread_create>
    13aa:	04aaa423          	sw	a0,72(s5)
	for (int i = 0; i <= producers; i++) {
    13ae:	00002497          	auipc	s1,0x2
    13b2:	b0e48493          	addi	s1,s1,-1266 # 2ebc <threads+0x14>
		waittid(threads[i]);
    13b6:	4008                	lw	a0,0(s0)
	for (int i = 0; i <= producers; i++) {
    13b8:	0411                	addi	s0,s0,4
		waittid(threads[i]);
    13ba:	6b0010ef          	jal	ra,2a6a <waittid>
	for (int i = 0; i <= producers; i++) {
    13be:	fe849ce3          	bne	s1,s0,13b6 <main+0xaa>
	}
	puts("mpsc_sem passed!");
    13c2:	00002517          	auipc	a0,0x2
    13c6:	99e50513          	addi	a0,a0,-1634 # 2d60 <enable_deadlock_detect+0x24e>
    13ca:	15f000ef          	jal	ra,1d28 <puts>
	return 0;
}
    13ce:	60e6                	ld	ra,88(sp)
    13d0:	6446                	ld	s0,80(sp)
    13d2:	64a6                	ld	s1,72(sp)
    13d4:	6906                	ld	s2,64(sp)
    13d6:	79e2                	ld	s3,56(sp)
    13d8:	7a42                	ld	s4,48(sp)
    13da:	7aa2                	ld	s5,40(sp)
    13dc:	7b02                	ld	s6,32(sp)
    13de:	6be2                	ld	s7,24(sp)
    13e0:	6c42                	ld	s8,16(sp)
    13e2:	6ca2                	ld	s9,8(sp)
    13e4:	4501                	li	a0,0
    13e6:	6125                	addi	sp,sp,96
    13e8:	8082                	ret
		assert(threads[i] > 0);
    13ea:	45a010ef          	jal	ra,2844 <getpid>
    13ee:	8b2a                	mv	s6,a0
    13f0:	8566                	mv	a0,s9
    13f2:	328010ef          	jal	ra,271a <basename>
    13f6:	872a                	mv	a4,a0
    13f8:	03900793          	li	a5,57
    13fc:	855e                	mv	a0,s7
    13fe:	86da                	mv	a3,s6
    1400:	8662                	mv	a2,s8
    1402:	45fd                	li	a1,31
    1404:	20e000ef          	jal	ra,1612 <printf>
    1408:	557d                	li	a0,-1
    140a:	46a010ef          	jal	ra,2874 <exit>
    140e:	b761                	j	1396 <main+0x8a>
	assert((sem_mutex_id = semaphore_create(1)) >= 0);
    1410:	434010ef          	jal	ra,2844 <getpid>
    1414:	842a                	mv	s0,a0
    1416:	00001517          	auipc	a0,0x1
    141a:	72a50513          	addi	a0,a0,1834 # 2b40 <enable_deadlock_detect+0x2e>
    141e:	2fc010ef          	jal	ra,271a <basename>
    1422:	872a                	mv	a4,a0
    1424:	03400793          	li	a5,52
    1428:	00001517          	auipc	a0,0x1
    142c:	7f850513          	addi	a0,a0,2040 # 2c20 <enable_deadlock_detect+0x10e>
    1430:	86a2                	mv	a3,s0
    1432:	00001617          	auipc	a2,0x1
    1436:	75660613          	addi	a2,a2,1878 # 2b88 <enable_deadlock_detect+0x76>
    143a:	45fd                	li	a1,31
    143c:	1d6000ef          	jal	ra,1612 <printf>
    1440:	557d                	li	a0,-1
    1442:	432010ef          	jal	ra,2874 <exit>
    1446:	bdd5                	j	133a <main+0x2e>
	assert((sem_existed_id = semaphore_create(0)) >= 0);
    1448:	3fc010ef          	jal	ra,2844 <getpid>
    144c:	842a                	mv	s0,a0
    144e:	00001517          	auipc	a0,0x1
    1452:	6f250513          	addi	a0,a0,1778 # 2b40 <enable_deadlock_detect+0x2e>
    1456:	2c4010ef          	jal	ra,271a <basename>
    145a:	872a                	mv	a4,a0
    145c:	03600793          	li	a5,54
    1460:	00002517          	auipc	a0,0x2
    1464:	87050513          	addi	a0,a0,-1936 # 2cd0 <enable_deadlock_detect+0x1be>
    1468:	86a2                	mv	a3,s0
    146a:	00001617          	auipc	a2,0x1
    146e:	71e60613          	addi	a2,a2,1822 # 2b88 <enable_deadlock_detect+0x76>
    1472:	45fd                	li	a1,31
    1474:	19e000ef          	jal	ra,1612 <printf>
    1478:	557d                	li	a0,-1
    147a:	3fa010ef          	jal	ra,2874 <exit>
    147e:	bde1                	j	1356 <main+0x4a>
	assert((sem_empty_id = semaphore_create(buffer_size)) >= 0);
    1480:	3c4010ef          	jal	ra,2844 <getpid>
    1484:	842a                	mv	s0,a0
    1486:	00001517          	auipc	a0,0x1
    148a:	6ba50513          	addi	a0,a0,1722 # 2b40 <enable_deadlock_detect+0x2e>
    148e:	28c010ef          	jal	ra,271a <basename>
    1492:	872a                	mv	a4,a0
    1494:	03500793          	li	a5,53
    1498:	00001517          	auipc	a0,0x1
    149c:	7e050513          	addi	a0,a0,2016 # 2c78 <enable_deadlock_detect+0x166>
    14a0:	86a2                	mv	a3,s0
    14a2:	00001617          	auipc	a2,0x1
    14a6:	6e660613          	addi	a2,a2,1766 # 2b88 <enable_deadlock_detect+0x76>
    14aa:	45fd                	li	a1,31
    14ac:	166000ef          	jal	ra,1612 <printf>
    14b0:	557d                	li	a0,-1
    14b2:	3c2010ef          	jal	ra,2874 <exit>
    14b6:	bd49                	j	1348 <main+0x3c>

00000000000014b8 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    14b8:	1141                	addi	sp,sp,-16
    14ba:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    14bc:	e51ff0ef          	jal	ra,130c <main>
    14c0:	3b4010ef          	jal	ra,2874 <exit>
	return 0;
    14c4:	60a2                	ld	ra,8(sp)
    14c6:	4501                	li	a0,0
    14c8:	0141                	addi	sp,sp,16
    14ca:	8082                	ret

00000000000014cc <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    14cc:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    14ce:	4605                	li	a2,1
    14d0:	00f10593          	addi	a1,sp,15
    14d4:	4501                	li	a0,0
{
    14d6:	ec06                	sd	ra,24(sp)
	char byte = 0;
    14d8:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    14dc:	354010ef          	jal	ra,2830 <read>
    14e0:	4785                	li	a5,1
    14e2:	00f51763          	bne	a0,a5,14f0 <getchar+0x24>
		return byte;
    14e6:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    14ea:	60e2                	ld	ra,24(sp)
    14ec:	6105                	addi	sp,sp,32
    14ee:	8082                	ret
		return EOF;
    14f0:	557d                	li	a0,-1
    14f2:	bfe5                	j	14ea <getchar+0x1e>

00000000000014f4 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    14f4:	00002517          	auipc	a0,0x2
    14f8:	9cc52503          	lw	a0,-1588(a0) # 2ec0 <buffer_len>
    14fc:	e111                	bnez	a0,1500 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    14fe:	8082                	ret
{
    1500:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1502:	862a                	mv	a2,a0
    1504:	00002597          	auipc	a1,0x2
    1508:	9c458593          	addi	a1,a1,-1596 # 2ec8 <buffer>
    150c:	4505                	li	a0,1
{
    150e:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1510:	32a010ef          	jal	ra,283a <write>
}
    1514:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1516:	2501                	sext.w	a0,a0
}
    1518:	0141                	addi	sp,sp,16
    151a:	8082                	ret

000000000000151c <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    151c:	00002797          	auipc	a5,0x2
    1520:	9a07a223          	sw	zero,-1628(a5) # 2ec0 <buffer_len>
}
    1524:	8082                	ret

0000000000001526 <__fflush>:
	if (buffer_len == 0)
    1526:	00002517          	auipc	a0,0x2
    152a:	99a52503          	lw	a0,-1638(a0) # 2ec0 <buffer_len>
    152e:	e511                	bnez	a0,153a <__fflush+0x14>
	buffer_len = 0;
    1530:	00002797          	auipc	a5,0x2
    1534:	9807a823          	sw	zero,-1648(a5) # 2ec0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1538:	8082                	ret
{
    153a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    153c:	862a                	mv	a2,a0
    153e:	00002597          	auipc	a1,0x2
    1542:	98a58593          	addi	a1,a1,-1654 # 2ec8 <buffer>
    1546:	4505                	li	a0,1
{
    1548:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    154a:	2f0010ef          	jal	ra,283a <write>
	return r >= 0 ? 0 : r;
    154e:	0005079b          	sext.w	a5,a0
}
    1552:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1554:	0017a793          	slti	a5,a5,1
    1558:	40f007bb          	negw	a5,a5
    155c:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    155e:	00002797          	auipc	a5,0x2
    1562:	9607a123          	sw	zero,-1694(a5) # 2ec0 <buffer_len>
	return r >= 0 ? 0 : r;
    1566:	2501                	sext.w	a0,a0
}
    1568:	0141                	addi	sp,sp,16
    156a:	8082                	ret

000000000000156c <fflush>:

int fflush(int fd)
{
    156c:	1101                	addi	sp,sp,-32
    156e:	e822                	sd	s0,16(sp)
    1570:	ec06                	sd	ra,24(sp)
    1572:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1574:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1576:	4401                	li	s0,0
	if (fd == 1) {
    1578:	00e50863          	beq	a0,a4,1588 <fflush+0x1c>
}
    157c:	60e2                	ld	ra,24(sp)
    157e:	8522                	mv	a0,s0
    1580:	6442                	ld	s0,16(sp)
    1582:	64a2                	ld	s1,8(sp)
    1584:	6105                	addi	sp,sp,32
    1586:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1588:	00002497          	auipc	s1,0x2
    158c:	93848493          	addi	s1,s1,-1736 # 2ec0 <buffer_len>
    1590:	1084a703          	lw	a4,264(s1)
    1594:	02a70e63          	beq	a4,a0,15d0 <fflush+0x64>
	if (buffer_len == 0)
    1598:	4080                	lw	s0,0(s1)
    159a:	c00d                	beqz	s0,15bc <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    159c:	8622                	mv	a2,s0
    159e:	00002597          	auipc	a1,0x2
    15a2:	92a58593          	addi	a1,a1,-1750 # 2ec8 <buffer>
    15a6:	294010ef          	jal	ra,283a <write>
	return r >= 0 ? 0 : r;
    15aa:	0005079b          	sext.w	a5,a0
    15ae:	0017a793          	slti	a5,a5,1
    15b2:	40f007bb          	negw	a5,a5
    15b6:	8d7d                	and	a0,a0,a5
    15b8:	0005041b          	sext.w	s0,a0
}
    15bc:	60e2                	ld	ra,24(sp)
    15be:	8522                	mv	a0,s0
    15c0:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    15c2:	00002797          	auipc	a5,0x2
    15c6:	8e07af23          	sw	zero,-1794(a5) # 2ec0 <buffer_len>
}
    15ca:	64a2                	ld	s1,8(sp)
    15cc:	6105                	addi	sp,sp,32
    15ce:	8082                	ret
			mutex_lock(buffer_lock);
    15d0:	10c4a503          	lw	a0,268(s1)
    15d4:	4de010ef          	jal	ra,2ab2 <mutex_lock>
	if (buffer_len == 0)
    15d8:	4080                	lw	s0,0(s1)
    15da:	e811                	bnez	s0,15ee <fflush+0x82>
			mutex_unlock(buffer_lock);
    15dc:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    15e0:	00002797          	auipc	a5,0x2
    15e4:	8e07a023          	sw	zero,-1824(a5) # 2ec0 <buffer_len>
			mutex_unlock(buffer_lock);
    15e8:	4d6010ef          	jal	ra,2abe <mutex_unlock>
    15ec:	bf41                	j	157c <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    15ee:	8622                	mv	a2,s0
    15f0:	00002597          	auipc	a1,0x2
    15f4:	8d858593          	addi	a1,a1,-1832 # 2ec8 <buffer>
    15f8:	4505                	li	a0,1
    15fa:	240010ef          	jal	ra,283a <write>
	return r >= 0 ? 0 : r;
    15fe:	0005079b          	sext.w	a5,a0
    1602:	0017a793          	slti	a5,a5,1
    1606:	40f007bb          	negw	a5,a5
    160a:	8d7d                	and	a0,a0,a5
    160c:	0005041b          	sext.w	s0,a0
	return r;
    1610:	b7f1                	j	15dc <fflush+0x70>

0000000000001612 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1612:	7131                	addi	sp,sp,-192
    1614:	e0da                	sd	s6,64(sp)
    1616:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1618:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    161a:	013c                	addi	a5,sp,136
{
    161c:	f0ca                	sd	s2,96(sp)
    161e:	ecce                	sd	s3,88(sp)
    1620:	e8d2                	sd	s4,80(sp)
    1622:	e4d6                	sd	s5,72(sp)
    1624:	fc86                	sd	ra,120(sp)
    1626:	f8a2                	sd	s0,112(sp)
    1628:	f4a6                	sd	s1,104(sp)
    162a:	89aa                	mv	s3,a0
    162c:	e52e                	sd	a1,136(sp)
    162e:	e932                	sd	a2,144(sp)
    1630:	ed36                	sd	a3,152(sp)
    1632:	f13a                	sd	a4,160(sp)
    1634:	f942                	sd	a6,176(sp)
    1636:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1638:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    163a:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    163e:	00002a17          	auipc	s4,0x2
    1642:	882a0a13          	addi	s4,s4,-1918 # 2ec0 <buffer_len>
    1646:	4a85                	li	s5,1
	buf[i++] = '0';
    1648:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    164c:	0009c783          	lbu	a5,0(s3)
    1650:	18078663          	beqz	a5,17dc <printf+0x1ca>
    1654:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1656:	19278d63          	beq	a5,s2,17f0 <printf+0x1de>
    165a:	0015c783          	lbu	a5,1(a1)
    165e:	0585                	addi	a1,a1,1
    1660:	fbfd                	bnez	a5,1656 <printf+0x44>
    1662:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1664:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1668:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    166c:	1b578863          	beq	a5,s5,181c <printf+0x20a>
		len = out_unlocked(s, l);
    1670:	85a2                	mv	a1,s0
    1672:	854e                	mv	a0,s3
    1674:	42a000ef          	jal	ra,1a9e <out_unlocked>
		out(f, a, l);
		if (l)
    1678:	1c041063          	bnez	s0,1838 <printf+0x226>
			continue;
		if (s[1] == 0)
    167c:	0014c783          	lbu	a5,1(s1)
    1680:	14078e63          	beqz	a5,17dc <printf+0x1ca>
			break;
		switch (s[1]) {
    1684:	07300713          	li	a4,115
    1688:	1ce78863          	beq	a5,a4,1858 <printf+0x246>
    168c:	1af76863          	bltu	a4,a5,183c <printf+0x22a>
    1690:	06400713          	li	a4,100
    1694:	22e78063          	beq	a5,a4,18b4 <printf+0x2a2>
    1698:	07000713          	li	a4,112
    169c:	1ee79563          	bne	a5,a4,1886 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    16a0:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16a2:	00002797          	auipc	a5,0x2
    16a6:	92e78793          	addi	a5,a5,-1746 # 2fd0 <digits>
	buf[i++] = '0';
    16aa:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    16ae:	6298                	ld	a4,0(a3)
    16b0:	06a1                	addi	a3,a3,8
    16b2:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    16b4:	00471393          	slli	t2,a4,0x4
    16b8:	00871293          	slli	t0,a4,0x8
    16bc:	00c71f93          	slli	t6,a4,0xc
    16c0:	01071f13          	slli	t5,a4,0x10
    16c4:	01471e93          	slli	t4,a4,0x14
    16c8:	01871e13          	slli	t3,a4,0x18
    16cc:	01c71893          	slli	a7,a4,0x1c
    16d0:	02471813          	slli	a6,a4,0x24
    16d4:	02871513          	slli	a0,a4,0x28
    16d8:	02c71593          	slli	a1,a4,0x2c
    16dc:	03071613          	slli	a2,a4,0x30
    16e0:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16e4:	03c75413          	srli	s0,a4,0x3c
    16e8:	01c7531b          	srliw	t1,a4,0x1c
    16ec:	03c3d393          	srli	t2,t2,0x3c
    16f0:	03c2d293          	srli	t0,t0,0x3c
    16f4:	03cfdf93          	srli	t6,t6,0x3c
    16f8:	03cf5f13          	srli	t5,t5,0x3c
    16fc:	03cede93          	srli	t4,t4,0x3c
    1700:	03ce5e13          	srli	t3,t3,0x3c
    1704:	03c8d893          	srli	a7,a7,0x3c
    1708:	03c85813          	srli	a6,a6,0x3c
    170c:	9171                	srli	a0,a0,0x3c
    170e:	91f1                	srli	a1,a1,0x3c
    1710:	9271                	srli	a2,a2,0x3c
    1712:	92f1                	srli	a3,a3,0x3c
    1714:	95be                	add	a1,a1,a5
    1716:	963e                	add	a2,a2,a5
    1718:	96be                	add	a3,a3,a5
    171a:	943e                	add	s0,s0,a5
    171c:	93be                	add	t2,t2,a5
    171e:	92be                	add	t0,t0,a5
    1720:	9fbe                	add	t6,t6,a5
    1722:	9f3e                	add	t5,t5,a5
    1724:	9ebe                	add	t4,t4,a5
    1726:	9e3e                	add	t3,t3,a5
    1728:	98be                	add	a7,a7,a5
    172a:	933e                	add	t1,t1,a5
    172c:	983e                	add	a6,a6,a5
    172e:	953e                	add	a0,a0,a5
    1730:	0005c983          	lbu	s3,0(a1)
    1734:	00044403          	lbu	s0,0(s0)
    1738:	00064583          	lbu	a1,0(a2)
    173c:	0003c383          	lbu	t2,0(t2)
    1740:	0006c603          	lbu	a2,0(a3)
    1744:	0002c283          	lbu	t0,0(t0)
    1748:	000fcf83          	lbu	t6,0(t6)
    174c:	000f4f03          	lbu	t5,0(t5)
    1750:	000ece83          	lbu	t4,0(t4)
    1754:	000e4e03          	lbu	t3,0(t3)
    1758:	0008c883          	lbu	a7,0(a7)
    175c:	00034303          	lbu	t1,0(t1)
    1760:	00084803          	lbu	a6,0(a6)
    1764:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1768:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    176c:	92f1                	srli	a3,a3,0x3c
    176e:	8b3d                	andi	a4,a4,15
    1770:	96be                	add	a3,a3,a5
    1772:	97ba                	add	a5,a5,a4
    1774:	00810d23          	sb	s0,26(sp)
    1778:	00710da3          	sb	t2,27(sp)
    177c:	00510e23          	sb	t0,28(sp)
    1780:	01f10ea3          	sb	t6,29(sp)
    1784:	01e10f23          	sb	t5,30(sp)
    1788:	01d10fa3          	sb	t4,31(sp)
    178c:	03c10023          	sb	t3,32(sp)
    1790:	031100a3          	sb	a7,33(sp)
    1794:	02610123          	sb	t1,34(sp)
    1798:	030101a3          	sb	a6,35(sp)
    179c:	02a10223          	sb	a0,36(sp)
    17a0:	033102a3          	sb	s3,37(sp)
    17a4:	02b10323          	sb	a1,38(sp)
    17a8:	02c103a3          	sb	a2,39(sp)
    17ac:	0006c683          	lbu	a3,0(a3)
    17b0:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    17b4:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    17b8:	02d10423          	sb	a3,40(sp)
    17bc:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    17c0:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    17c4:	11578263          	beq	a5,s5,18c8 <printf+0x2b6>
		len = out_unlocked(s, l);
    17c8:	45c9                	li	a1,18
    17ca:	0828                	addi	a0,sp,24
    17cc:	2d2000ef          	jal	ra,1a9e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    17d0:	00248993          	addi	s3,s1,2
		if (!*s)
    17d4:	0009c783          	lbu	a5,0(s3)
    17d8:	e6079ee3          	bnez	a5,1654 <printf+0x42>
	}
	va_end(ap);
    17dc:	70e6                	ld	ra,120(sp)
    17de:	7446                	ld	s0,112(sp)
    17e0:	74a6                	ld	s1,104(sp)
    17e2:	7906                	ld	s2,96(sp)
    17e4:	69e6                	ld	s3,88(sp)
    17e6:	6a46                	ld	s4,80(sp)
    17e8:	6aa6                	ld	s5,72(sp)
    17ea:	6b06                	ld	s6,64(sp)
    17ec:	6129                	addi	sp,sp,192
    17ee:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    17f0:	0005c783          	lbu	a5,0(a1)
    17f4:	84ae                	mv	s1,a1
    17f6:	01278963          	beq	a5,s2,1808 <printf+0x1f6>
    17fa:	b5ad                	j	1664 <printf+0x52>
    17fc:	0024c783          	lbu	a5,2(s1)
    1800:	0585                	addi	a1,a1,1
    1802:	0489                	addi	s1,s1,2
    1804:	e72790e3          	bne	a5,s2,1664 <printf+0x52>
    1808:	0014c783          	lbu	a5,1(s1)
    180c:	ff2788e3          	beq	a5,s2,17fc <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1810:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1814:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1818:	e5579ce3          	bne	a5,s5,1670 <printf+0x5e>
		mutex_lock(buffer_lock);
    181c:	10ca2503          	lw	a0,268(s4)
    1820:	292010ef          	jal	ra,2ab2 <mutex_lock>
		len = out_unlocked(s, l);
    1824:	85a2                	mv	a1,s0
    1826:	854e                	mv	a0,s3
    1828:	276000ef          	jal	ra,1a9e <out_unlocked>
		mutex_unlock(buffer_lock);
    182c:	10ca2503          	lw	a0,268(s4)
    1830:	28e010ef          	jal	ra,2abe <mutex_unlock>
		if (l)
    1834:	e40404e3          	beqz	s0,167c <printf+0x6a>
    1838:	89a6                	mv	s3,s1
    183a:	bd09                	j	164c <printf+0x3a>
		switch (s[1]) {
    183c:	07800713          	li	a4,120
    1840:	04e79363          	bne	a5,a4,1886 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1844:	67c2                	ld	a5,16(sp)
    1846:	45c1                	li	a1,16
		s += 2;
    1848:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    184c:	4388                	lw	a0,0(a5)
    184e:	07a1                	addi	a5,a5,8
    1850:	e83e                	sd	a5,16(sp)
    1852:	5f8000ef          	jal	ra,1e4a <printint.constprop.0>
		s += 2;
    1856:	bfbd                	j	17d4 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1858:	67c2                	ld	a5,16(sp)
    185a:	6380                	ld	s0,0(a5)
    185c:	07a1                	addi	a5,a5,8
    185e:	e83e                	sd	a5,16(sp)
    1860:	1c040163          	beqz	s0,1a22 <printf+0x410>
			l = strnlen(a, 200);
    1864:	0c800593          	li	a1,200
    1868:	8522                	mv	a0,s0
    186a:	3f7000ef          	jal	ra,2460 <strnlen>
	if (buffer_lock_enabled == 1) {
    186e:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1872:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1876:	19578663          	beq	a5,s5,1a02 <printf+0x3f0>
		len = out_unlocked(s, l);
    187a:	8522                	mv	a0,s0
    187c:	222000ef          	jal	ra,1a9e <out_unlocked>
		s += 2;
    1880:	00248993          	addi	s3,s1,2
    1884:	bf81                	j	17d4 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1886:	108a2783          	lw	a5,264(s4)
	char byte = c;
    188a:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    188e:	0f578663          	beq	a5,s5,197a <printf+0x368>
		len = out_unlocked(s, l);
    1892:	0828                	addi	a0,sp,24
    1894:	316000ef          	jal	ra,1baa <out_unlocked.constprop.0>
			putchar(s[1]);
    1898:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    189c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18a0:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    18a4:	05578163          	beq	a5,s5,18e6 <printf+0x2d4>
		len = out_unlocked(s, l);
    18a8:	0828                	addi	a0,sp,24
    18aa:	300000ef          	jal	ra,1baa <out_unlocked.constprop.0>
		s += 2;
    18ae:	00248993          	addi	s3,s1,2
    18b2:	b70d                	j	17d4 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    18b4:	67c2                	ld	a5,16(sp)
    18b6:	45a9                	li	a1,10
		s += 2;
    18b8:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    18bc:	4388                	lw	a0,0(a5)
    18be:	07a1                	addi	a5,a5,8
    18c0:	e83e                	sd	a5,16(sp)
    18c2:	588000ef          	jal	ra,1e4a <printint.constprop.0>
		s += 2;
    18c6:	b739                	j	17d4 <printf+0x1c2>
		mutex_lock(buffer_lock);
    18c8:	10ca2503          	lw	a0,268(s4)
		s += 2;
    18cc:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    18d0:	1e2010ef          	jal	ra,2ab2 <mutex_lock>
		len = out_unlocked(s, l);
    18d4:	45c9                	li	a1,18
    18d6:	0828                	addi	a0,sp,24
    18d8:	1c6000ef          	jal	ra,1a9e <out_unlocked>
		mutex_unlock(buffer_lock);
    18dc:	10ca2503          	lw	a0,268(s4)
    18e0:	1de010ef          	jal	ra,2abe <mutex_unlock>
		s += 2;
    18e4:	bdc5                	j	17d4 <printf+0x1c2>
		mutex_lock(buffer_lock);
    18e6:	10ca2503          	lw	a0,268(s4)
    18ea:	1c8010ef          	jal	ra,2ab2 <mutex_lock>
		buffer[buffer_len++] = c;
    18ee:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18f2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18f6:	0017861b          	addiw	a2,a5,1
    18fa:	97d2                	add	a5,a5,s4
    18fc:	00ca2023          	sw	a2,0(s4)
    1900:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1904:	00c6cc63          	blt	a3,a2,191c <printf+0x30a>
    1908:	47a9                	li	a5,10
    190a:	06f40663          	beq	s0,a5,1976 <printf+0x364>
		mutex_unlock(buffer_lock);
    190e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1912:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1916:	1a8010ef          	jal	ra,2abe <mutex_unlock>
		s += 2;
    191a:	bd6d                	j	17d4 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    191c:	10000793          	li	a5,256
    1920:	00f61e63          	bne	a2,a5,193c <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1924:	00001597          	auipc	a1,0x1
    1928:	5a458593          	addi	a1,a1,1444 # 2ec8 <buffer>
    192c:	4505                	li	a0,1
    192e:	70d000ef          	jal	ra,283a <write>
	buffer_len = 0;
    1932:	00001797          	auipc	a5,0x1
    1936:	5807a723          	sw	zero,1422(a5) # 2ec0 <buffer_len>
			if (r < 0) {
    193a:	bfd1                	j	190e <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    193c:	709000ef          	jal	ra,2844 <getpid>
    1940:	842a                	mv	s0,a0
    1942:	00001517          	auipc	a0,0x1
    1946:	43e50513          	addi	a0,a0,1086 # 2d80 <enable_deadlock_detect+0x26e>
    194a:	5d1000ef          	jal	ra,271a <basename>
    194e:	872a                	mv	a4,a0
    1950:	00001617          	auipc	a2,0x1
    1954:	23860613          	addi	a2,a2,568 # 2b88 <enable_deadlock_detect+0x76>
    1958:	05400793          	li	a5,84
    195c:	86a2                	mv	a3,s0
    195e:	45fd                	li	a1,31
    1960:	00001517          	auipc	a0,0x1
    1964:	46050513          	addi	a0,a0,1120 # 2dc0 <enable_deadlock_detect+0x2ae>
    1968:	cabff0ef          	jal	ra,1612 <printf>
    196c:	557d                	li	a0,-1
    196e:	707000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    1972:	000a2603          	lw	a2,0(s4)
    1976:	de41                	beqz	a2,190e <printf+0x2fc>
    1978:	b775                	j	1924 <printf+0x312>
		mutex_lock(buffer_lock);
    197a:	10ca2503          	lw	a0,268(s4)
    197e:	134010ef          	jal	ra,2ab2 <mutex_lock>
		buffer[buffer_len++] = c;
    1982:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1986:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    198a:	0017861b          	addiw	a2,a5,1
    198e:	97d2                	add	a5,a5,s4
    1990:	00ca2023          	sw	a2,0(s4)
    1994:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1998:	02c6d163          	bge	a3,a2,19ba <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    199c:	10000793          	li	a5,256
    19a0:	02f61263          	bne	a2,a5,19c4 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    19a4:	00001597          	auipc	a1,0x1
    19a8:	52458593          	addi	a1,a1,1316 # 2ec8 <buffer>
    19ac:	4505                	li	a0,1
    19ae:	68d000ef          	jal	ra,283a <write>
	buffer_len = 0;
    19b2:	00001797          	auipc	a5,0x1
    19b6:	5007a723          	sw	zero,1294(a5) # 2ec0 <buffer_len>
		mutex_unlock(buffer_lock);
    19ba:	10ca2503          	lw	a0,268(s4)
    19be:	100010ef          	jal	ra,2abe <mutex_unlock>
    19c2:	bdd9                	j	1898 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    19c4:	681000ef          	jal	ra,2844 <getpid>
    19c8:	842a                	mv	s0,a0
    19ca:	00001517          	auipc	a0,0x1
    19ce:	3b650513          	addi	a0,a0,950 # 2d80 <enable_deadlock_detect+0x26e>
    19d2:	549000ef          	jal	ra,271a <basename>
    19d6:	872a                	mv	a4,a0
    19d8:	00001617          	auipc	a2,0x1
    19dc:	1b060613          	addi	a2,a2,432 # 2b88 <enable_deadlock_detect+0x76>
    19e0:	05400793          	li	a5,84
    19e4:	86a2                	mv	a3,s0
    19e6:	45fd                	li	a1,31
    19e8:	00001517          	auipc	a0,0x1
    19ec:	3d850513          	addi	a0,a0,984 # 2dc0 <enable_deadlock_detect+0x2ae>
    19f0:	c23ff0ef          	jal	ra,1612 <printf>
    19f4:	557d                	li	a0,-1
    19f6:	67f000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    19fa:	000a2603          	lw	a2,0(s4)
    19fe:	de55                	beqz	a2,19ba <printf+0x3a8>
    1a00:	b755                	j	19a4 <printf+0x392>
		mutex_lock(buffer_lock);
    1a02:	10ca2503          	lw	a0,268(s4)
    1a06:	e42e                	sd	a1,8(sp)
		s += 2;
    1a08:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1a0c:	0a6010ef          	jal	ra,2ab2 <mutex_lock>
		len = out_unlocked(s, l);
    1a10:	65a2                	ld	a1,8(sp)
    1a12:	8522                	mv	a0,s0
    1a14:	08a000ef          	jal	ra,1a9e <out_unlocked>
		mutex_unlock(buffer_lock);
    1a18:	10ca2503          	lw	a0,268(s4)
    1a1c:	0a2010ef          	jal	ra,2abe <mutex_unlock>
		s += 2;
    1a20:	bb55                	j	17d4 <printf+0x1c2>
				a = "(null)";
    1a22:	00001417          	auipc	s0,0x1
    1a26:	35640413          	addi	s0,s0,854 # 2d78 <enable_deadlock_detect+0x266>
    1a2a:	bd2d                	j	1864 <printf+0x252>

0000000000001a2c <enable_thread_io_buffer>:
{
    1a2c:	1101                	addi	sp,sp,-32
    1a2e:	e822                	sd	s0,16(sp)
    1a30:	ec06                	sd	ra,24(sp)
    1a32:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1a34:	00001417          	auipc	s0,0x1
    1a38:	48c40413          	addi	s0,s0,1164 # 2ec0 <buffer_len>
    1a3c:	05a010ef          	jal	ra,2a96 <mutex_create>
    1a40:	10a42623          	sw	a0,268(s0)
    1a44:	00054a63          	bltz	a0,1a58 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1a48:	4785                	li	a5,1
}
    1a4a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1a4c:	10f42423          	sw	a5,264(s0)
}
    1a50:	6442                	ld	s0,16(sp)
    1a52:	64a2                	ld	s1,8(sp)
    1a54:	6105                	addi	sp,sp,32
    1a56:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1a58:	5ed000ef          	jal	ra,2844 <getpid>
    1a5c:	84aa                	mv	s1,a0
    1a5e:	00001517          	auipc	a0,0x1
    1a62:	32250513          	addi	a0,a0,802 # 2d80 <enable_deadlock_detect+0x26e>
    1a66:	4b5000ef          	jal	ra,271a <basename>
    1a6a:	872a                	mv	a4,a0
    1a6c:	04800793          	li	a5,72
    1a70:	86a6                	mv	a3,s1
    1a72:	00001517          	auipc	a0,0x1
    1a76:	38e50513          	addi	a0,a0,910 # 2e00 <enable_deadlock_detect+0x2ee>
    1a7a:	00001617          	auipc	a2,0x1
    1a7e:	10e60613          	addi	a2,a2,270 # 2b88 <enable_deadlock_detect+0x76>
    1a82:	45fd                	li	a1,31
    1a84:	b8fff0ef          	jal	ra,1612 <printf>
    1a88:	557d                	li	a0,-1
    1a8a:	5eb000ef          	jal	ra,2874 <exit>
	buffer_lock_enabled = 1;
    1a8e:	4785                	li	a5,1
}
    1a90:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1a92:	10f42423          	sw	a5,264(s0)
}
    1a96:	6442                	ld	s0,16(sp)
    1a98:	64a2                	ld	s1,8(sp)
    1a9a:	6105                	addi	sp,sp,32
    1a9c:	8082                	ret

0000000000001a9e <out_unlocked>:
{
    1a9e:	7159                	addi	sp,sp,-112
    1aa0:	f486                	sd	ra,104(sp)
    1aa2:	f0a2                	sd	s0,96(sp)
    1aa4:	eca6                	sd	s1,88(sp)
    1aa6:	e8ca                	sd	s2,80(sp)
    1aa8:	e4ce                	sd	s3,72(sp)
    1aaa:	e0d2                	sd	s4,64(sp)
    1aac:	fc56                	sd	s5,56(sp)
    1aae:	f85a                	sd	s6,48(sp)
    1ab0:	f45e                	sd	s7,40(sp)
    1ab2:	f062                	sd	s8,32(sp)
    1ab4:	ec66                	sd	s9,24(sp)
    1ab6:	e86a                	sd	s10,16(sp)
    1ab8:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1aba:	0e058663          	beqz	a1,1ba6 <out_unlocked+0x108>
    1abe:	842a                	mv	s0,a0
    1ac0:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1ac4:	4981                	li	s3,0
    1ac6:	00001d17          	auipc	s10,0x1
    1aca:	3fad0d13          	addi	s10,s10,1018 # 2ec0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1ace:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1ad2:	00001b17          	auipc	s6,0x1
    1ad6:	3f6b0b13          	addi	s6,s6,1014 # 2ec8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1ada:	10000a93          	li	s5,256
    1ade:	00001c97          	auipc	s9,0x1
    1ae2:	2a2c8c93          	addi	s9,s9,674 # 2d80 <enable_deadlock_detect+0x26e>
    1ae6:	00001c17          	auipc	s8,0x1
    1aea:	0a2c0c13          	addi	s8,s8,162 # 2b88 <enable_deadlock_detect+0x76>
    1aee:	00001b97          	auipc	s7,0x1
    1af2:	2d2b8b93          	addi	s7,s7,722 # 2dc0 <enable_deadlock_detect+0x2ae>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1af6:	4a29                	li	s4,10
    1af8:	a031                	j	1b04 <out_unlocked+0x66>
    1afa:	09468863          	beq	a3,s4,1b8a <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1afe:	0405                	addi	s0,s0,1
    1b00:	04848163          	beq	s1,s0,1b42 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1b04:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1b08:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1b0c:	0017861b          	addiw	a2,a5,1
    1b10:	97ea                	add	a5,a5,s10
    1b12:	00cd2023          	sw	a2,0(s10)
    1b16:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b1a:	fec950e3          	bge	s2,a2,1afa <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1b1e:	05561263          	bne	a2,s5,1b62 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1b22:	85da                	mv	a1,s6
    1b24:	4505                	li	a0,1
    1b26:	515000ef          	jal	ra,283a <write>
    1b2a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b2c:	00001797          	auipc	a5,0x1
    1b30:	3807aa23          	sw	zero,916(a5) # 2ec0 <buffer_len>
			if (r < 0) {
    1b34:	06054763          	bltz	a0,1ba2 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1b38:	0405                	addi	s0,s0,1
			ret += r;
    1b3a:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1b3e:	fc8493e3          	bne	s1,s0,1b04 <out_unlocked+0x66>
}
    1b42:	70a6                	ld	ra,104(sp)
    1b44:	7406                	ld	s0,96(sp)
    1b46:	64e6                	ld	s1,88(sp)
    1b48:	6946                	ld	s2,80(sp)
    1b4a:	6a06                	ld	s4,64(sp)
    1b4c:	7ae2                	ld	s5,56(sp)
    1b4e:	7b42                	ld	s6,48(sp)
    1b50:	7ba2                	ld	s7,40(sp)
    1b52:	7c02                	ld	s8,32(sp)
    1b54:	6ce2                	ld	s9,24(sp)
    1b56:	6d42                	ld	s10,16(sp)
    1b58:	6da2                	ld	s11,8(sp)
    1b5a:	854e                	mv	a0,s3
    1b5c:	69a6                	ld	s3,72(sp)
    1b5e:	6165                	addi	sp,sp,112
    1b60:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b62:	4e3000ef          	jal	ra,2844 <getpid>
    1b66:	8daa                	mv	s11,a0
    1b68:	8566                	mv	a0,s9
    1b6a:	3b1000ef          	jal	ra,271a <basename>
    1b6e:	872a                	mv	a4,a0
    1b70:	8662                	mv	a2,s8
    1b72:	05400793          	li	a5,84
    1b76:	86ee                	mv	a3,s11
    1b78:	45fd                	li	a1,31
    1b7a:	855e                	mv	a0,s7
    1b7c:	a97ff0ef          	jal	ra,1612 <printf>
    1b80:	557d                	li	a0,-1
    1b82:	4f3000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    1b86:	000d2603          	lw	a2,0(s10)
    1b8a:	da35                	beqz	a2,1afe <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1b8c:	85da                	mv	a1,s6
    1b8e:	4505                	li	a0,1
    1b90:	4ab000ef          	jal	ra,283a <write>
    1b94:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b96:	00001797          	auipc	a5,0x1
    1b9a:	3207a523          	sw	zero,810(a5) # 2ec0 <buffer_len>
			if (r < 0) {
    1b9e:	f8055de3          	bgez	a0,1b38 <out_unlocked+0x9a>
    1ba2:	89aa                	mv	s3,a0
    1ba4:	bf79                	j	1b42 <out_unlocked+0xa4>
	int ret = 0;
    1ba6:	4981                	li	s3,0
    1ba8:	bf69                	j	1b42 <out_unlocked+0xa4>

0000000000001baa <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1baa:	1101                	addi	sp,sp,-32
    1bac:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1bae:	00001497          	auipc	s1,0x1
    1bb2:	31248493          	addi	s1,s1,786 # 2ec0 <buffer_len>
    1bb6:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1bb8:	ec06                	sd	ra,24(sp)
    1bba:	e822                	sd	s0,16(sp)
		char c = s[i];
    1bbc:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1bc0:	0017861b          	addiw	a2,a5,1
    1bc4:	97a6                	add	a5,a5,s1
    1bc6:	00e78423          	sb	a4,8(a5)
    1bca:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1bcc:	0ff00793          	li	a5,255
    1bd0:	00c7cc63          	blt	a5,a2,1be8 <out_unlocked.constprop.0+0x3e>
    1bd4:	47a9                	li	a5,10
    1bd6:	06f70c63          	beq	a4,a5,1c4e <out_unlocked.constprop.0+0xa4>
    1bda:	4601                	li	a2,0
}
    1bdc:	60e2                	ld	ra,24(sp)
    1bde:	6442                	ld	s0,16(sp)
    1be0:	64a2                	ld	s1,8(sp)
    1be2:	8532                	mv	a0,a2
    1be4:	6105                	addi	sp,sp,32
    1be6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1be8:	10000793          	li	a5,256
    1bec:	02f61563          	bne	a2,a5,1c16 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1bf0:	00001597          	auipc	a1,0x1
    1bf4:	2d858593          	addi	a1,a1,728 # 2ec8 <buffer>
    1bf8:	4505                	li	a0,1
    1bfa:	441000ef          	jal	ra,283a <write>
}
    1bfe:	60e2                	ld	ra,24(sp)
    1c00:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1c02:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1c06:	00001797          	auipc	a5,0x1
    1c0a:	2a07ad23          	sw	zero,698(a5) # 2ec0 <buffer_len>
}
    1c0e:	64a2                	ld	s1,8(sp)
    1c10:	8532                	mv	a0,a2
    1c12:	6105                	addi	sp,sp,32
    1c14:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c16:	42f000ef          	jal	ra,2844 <getpid>
    1c1a:	842a                	mv	s0,a0
    1c1c:	00001517          	auipc	a0,0x1
    1c20:	16450513          	addi	a0,a0,356 # 2d80 <enable_deadlock_detect+0x26e>
    1c24:	2f7000ef          	jal	ra,271a <basename>
    1c28:	872a                	mv	a4,a0
    1c2a:	00001617          	auipc	a2,0x1
    1c2e:	f5e60613          	addi	a2,a2,-162 # 2b88 <enable_deadlock_detect+0x76>
    1c32:	05400793          	li	a5,84
    1c36:	86a2                	mv	a3,s0
    1c38:	45fd                	li	a1,31
    1c3a:	00001517          	auipc	a0,0x1
    1c3e:	18650513          	addi	a0,a0,390 # 2dc0 <enable_deadlock_detect+0x2ae>
    1c42:	9d1ff0ef          	jal	ra,1612 <printf>
    1c46:	557d                	li	a0,-1
    1c48:	42d000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    1c4c:	4090                	lw	a2,0(s1)
    1c4e:	d659                	beqz	a2,1bdc <out_unlocked.constprop.0+0x32>
    1c50:	b745                	j	1bf0 <out_unlocked.constprop.0+0x46>

0000000000001c52 <putchar>:
{
    1c52:	7139                	addi	sp,sp,-64
    1c54:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1c56:	00001497          	auipc	s1,0x1
    1c5a:	26a48493          	addi	s1,s1,618 # 2ec0 <buffer_len>
    1c5e:	1084a703          	lw	a4,264(s1)
{
    1c62:	f822                	sd	s0,48(sp)
	char byte = c;
    1c64:	0ff57413          	zext.b	s0,a0
{
    1c68:	fc06                	sd	ra,56(sp)
	char byte = c;
    1c6a:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1c6e:	4785                	li	a5,1
    1c70:	00f70d63          	beq	a4,a5,1c8a <putchar+0x38>
		len = out_unlocked(s, l);
    1c74:	01f10513          	addi	a0,sp,31
    1c78:	f33ff0ef          	jal	ra,1baa <out_unlocked.constprop.0>
}
    1c7c:	70e2                	ld	ra,56(sp)
    1c7e:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1c80:	862a                	mv	a2,a0
}
    1c82:	74a2                	ld	s1,40(sp)
    1c84:	8532                	mv	a0,a2
    1c86:	6121                	addi	sp,sp,64
    1c88:	8082                	ret
		mutex_lock(buffer_lock);
    1c8a:	10c4a503          	lw	a0,268(s1)
    1c8e:	625000ef          	jal	ra,2ab2 <mutex_lock>
		buffer[buffer_len++] = c;
    1c92:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c94:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c98:	0017861b          	addiw	a2,a5,1
    1c9c:	97a6                	add	a5,a5,s1
    1c9e:	c090                	sw	a2,0(s1)
    1ca0:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1ca4:	02c6c263          	blt	a3,a2,1cc8 <putchar+0x76>
    1ca8:	47a9                	li	a5,10
    1caa:	06f40d63          	beq	s0,a5,1d24 <putchar+0xd2>
    1cae:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1cb0:	10c4a503          	lw	a0,268(s1)
    1cb4:	e432                	sd	a2,8(sp)
    1cb6:	609000ef          	jal	ra,2abe <mutex_unlock>
    1cba:	6622                	ld	a2,8(sp)
}
    1cbc:	70e2                	ld	ra,56(sp)
    1cbe:	7442                	ld	s0,48(sp)
    1cc0:	74a2                	ld	s1,40(sp)
    1cc2:	8532                	mv	a0,a2
    1cc4:	6121                	addi	sp,sp,64
    1cc6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1cc8:	10000793          	li	a5,256
    1ccc:	02f61063          	bne	a2,a5,1cec <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1cd0:	00001597          	auipc	a1,0x1
    1cd4:	1f858593          	addi	a1,a1,504 # 2ec8 <buffer>
    1cd8:	4505                	li	a0,1
    1cda:	361000ef          	jal	ra,283a <write>
    1cde:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1ce2:	00001797          	auipc	a5,0x1
    1ce6:	1c07af23          	sw	zero,478(a5) # 2ec0 <buffer_len>
			if (r < 0) {
    1cea:	b7d9                	j	1cb0 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1cec:	359000ef          	jal	ra,2844 <getpid>
    1cf0:	842a                	mv	s0,a0
    1cf2:	00001517          	auipc	a0,0x1
    1cf6:	08e50513          	addi	a0,a0,142 # 2d80 <enable_deadlock_detect+0x26e>
    1cfa:	221000ef          	jal	ra,271a <basename>
    1cfe:	872a                	mv	a4,a0
    1d00:	00001617          	auipc	a2,0x1
    1d04:	e8860613          	addi	a2,a2,-376 # 2b88 <enable_deadlock_detect+0x76>
    1d08:	05400793          	li	a5,84
    1d0c:	86a2                	mv	a3,s0
    1d0e:	45fd                	li	a1,31
    1d10:	00001517          	auipc	a0,0x1
    1d14:	0b050513          	addi	a0,a0,176 # 2dc0 <enable_deadlock_detect+0x2ae>
    1d18:	8fbff0ef          	jal	ra,1612 <printf>
    1d1c:	557d                	li	a0,-1
    1d1e:	357000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    1d22:	4090                	lw	a2,0(s1)
    1d24:	d651                	beqz	a2,1cb0 <putchar+0x5e>
    1d26:	b76d                	j	1cd0 <putchar+0x7e>

0000000000001d28 <puts>:
{
    1d28:	7139                	addi	sp,sp,-64
    1d2a:	f822                	sd	s0,48(sp)
    1d2c:	f426                	sd	s1,40(sp)
    1d2e:	fc06                	sd	ra,56(sp)
    1d30:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1d32:	00001417          	auipc	s0,0x1
    1d36:	18e40413          	addi	s0,s0,398 # 2ec0 <buffer_len>
{
    1d3a:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d3c:	638000ef          	jal	ra,2374 <strlen>
	if (buffer_lock_enabled == 1) {
    1d40:	10842703          	lw	a4,264(s0)
    1d44:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d46:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1d48:	04f70563          	beq	a4,a5,1d92 <puts+0x6a>
		len = out_unlocked(s, l);
    1d4c:	8526                	mv	a0,s1
    1d4e:	d51ff0ef          	jal	ra,1a9e <out_unlocked>
    1d52:	892a                	mv	s2,a0
    1d54:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d56:	00095963          	bgez	s2,1d68 <puts+0x40>
}
    1d5a:	70e2                	ld	ra,56(sp)
    1d5c:	7442                	ld	s0,48(sp)
    1d5e:	7902                	ld	s2,32(sp)
    1d60:	8526                	mv	a0,s1
    1d62:	74a2                	ld	s1,40(sp)
    1d64:	6121                	addi	sp,sp,64
    1d66:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1d68:	10842703          	lw	a4,264(s0)
	char byte = c;
    1d6c:	44a9                	li	s1,10
    1d6e:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1d72:	4785                	li	a5,1
    1d74:	02f70e63          	beq	a4,a5,1db0 <puts+0x88>
		len = out_unlocked(s, l);
    1d78:	01f10513          	addi	a0,sp,31
    1d7c:	e2fff0ef          	jal	ra,1baa <out_unlocked.constprop.0>
}
    1d80:	70e2                	ld	ra,56(sp)
    1d82:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d84:	41f5549b          	sraiw	s1,a0,0x1f
}
    1d88:	7902                	ld	s2,32(sp)
    1d8a:	8526                	mv	a0,s1
    1d8c:	74a2                	ld	s1,40(sp)
    1d8e:	6121                	addi	sp,sp,64
    1d90:	8082                	ret
		mutex_lock(buffer_lock);
    1d92:	e42a                	sd	a0,8(sp)
    1d94:	10c42503          	lw	a0,268(s0)
    1d98:	51b000ef          	jal	ra,2ab2 <mutex_lock>
		len = out_unlocked(s, l);
    1d9c:	65a2                	ld	a1,8(sp)
    1d9e:	8526                	mv	a0,s1
    1da0:	cffff0ef          	jal	ra,1a9e <out_unlocked>
    1da4:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1da6:	10c42503          	lw	a0,268(s0)
    1daa:	515000ef          	jal	ra,2abe <mutex_unlock>
    1dae:	b75d                	j	1d54 <puts+0x2c>
		mutex_lock(buffer_lock);
    1db0:	10c42503          	lw	a0,268(s0)
    1db4:	4ff000ef          	jal	ra,2ab2 <mutex_lock>
		buffer[buffer_len++] = c;
    1db8:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1dba:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1dbe:	0017861b          	addiw	a2,a5,1
    1dc2:	97a2                	add	a5,a5,s0
    1dc4:	c010                	sw	a2,0(s0)
    1dc6:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1dca:	06c6dc63          	bge	a3,a2,1e42 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1dce:	10000793          	li	a5,256
    1dd2:	02f61c63          	bne	a2,a5,1e0a <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1dd6:	00001597          	auipc	a1,0x1
    1dda:	0f258593          	addi	a1,a1,242 # 2ec8 <buffer>
    1dde:	4505                	li	a0,1
    1de0:	25b000ef          	jal	ra,283a <write>
			if (r < 0) {
    1de4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1de6:	00001797          	auipc	a5,0x1
    1dea:	0c07ad23          	sw	zero,218(a5) # 2ec0 <buffer_len>
			if (r < 0) {
    1dee:	04054c63          	bltz	a0,1e46 <puts+0x11e>
			if (r < buffer_len) {
    1df2:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1df4:	10c42503          	lw	a0,268(s0)
    1df8:	4c7000ef          	jal	ra,2abe <mutex_unlock>
}
    1dfc:	70e2                	ld	ra,56(sp)
    1dfe:	7442                	ld	s0,48(sp)
    1e00:	7902                	ld	s2,32(sp)
    1e02:	8526                	mv	a0,s1
    1e04:	74a2                	ld	s1,40(sp)
    1e06:	6121                	addi	sp,sp,64
    1e08:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1e0a:	23b000ef          	jal	ra,2844 <getpid>
    1e0e:	84aa                	mv	s1,a0
    1e10:	00001517          	auipc	a0,0x1
    1e14:	f7050513          	addi	a0,a0,-144 # 2d80 <enable_deadlock_detect+0x26e>
    1e18:	103000ef          	jal	ra,271a <basename>
    1e1c:	872a                	mv	a4,a0
    1e1e:	00001617          	auipc	a2,0x1
    1e22:	d6a60613          	addi	a2,a2,-662 # 2b88 <enable_deadlock_detect+0x76>
    1e26:	05400793          	li	a5,84
    1e2a:	86a6                	mv	a3,s1
    1e2c:	45fd                	li	a1,31
    1e2e:	00001517          	auipc	a0,0x1
    1e32:	f9250513          	addi	a0,a0,-110 # 2dc0 <enable_deadlock_detect+0x2ae>
    1e36:	fdcff0ef          	jal	ra,1612 <printf>
    1e3a:	557d                	li	a0,-1
    1e3c:	239000ef          	jal	ra,2874 <exit>
	if (buffer_len == 0)
    1e40:	4010                	lw	a2,0(s0)
    1e42:	da45                	beqz	a2,1df2 <puts+0xca>
    1e44:	bf49                	j	1dd6 <puts+0xae>
    1e46:	54fd                	li	s1,-1
    1e48:	b775                	j	1df4 <puts+0xcc>

0000000000001e4a <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1e4a:	715d                	addi	sp,sp,-80
    1e4c:	e486                	sd	ra,72(sp)
    1e4e:	e0a2                	sd	s0,64(sp)
    1e50:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1e52:	14054363          	bltz	a0,1f98 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1e56:	02b577bb          	remuw	a5,a0,a1
    1e5a:	00001617          	auipc	a2,0x1
    1e5e:	17660613          	addi	a2,a2,374 # 2fd0 <digits>
	buf[16] = 0;
    1e62:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e66:	0005871b          	sext.w	a4,a1
    1e6a:	1782                	slli	a5,a5,0x20
    1e6c:	9381                	srli	a5,a5,0x20
    1e6e:	97b2                	add	a5,a5,a2
    1e70:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e74:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1e78:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1e7c:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1e7e:	0eb56763          	bltu	a0,a1,1f6c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1e82:	02e877bb          	remuw	a5,a6,a4
    1e86:	1782                	slli	a5,a5,0x20
    1e88:	9381                	srli	a5,a5,0x20
    1e8a:	97b2                	add	a5,a5,a2
    1e8c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e90:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1e94:	02f10323          	sb	a5,38(sp)
    1e98:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1e9a:	0ce86963          	bltu	a6,a4,1f6c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1e9e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1ea2:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1ea6:	1582                	slli	a1,a1,0x20
    1ea8:	9181                	srli	a1,a1,0x20
    1eaa:	95b2                	add	a1,a1,a2
    1eac:	0005c583          	lbu	a1,0(a1)
    1eb0:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1eb4:	0007859b          	sext.w	a1,a5
    1eb8:	16e6e563          	bltu	a3,a4,2022 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ebc:	02e7f6bb          	remuw	a3,a5,a4
    1ec0:	1682                	slli	a3,a3,0x20
    1ec2:	9281                	srli	a3,a3,0x20
    1ec4:	96b2                	add	a3,a3,a2
    1ec6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1eca:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ece:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1ed2:	16e5e163          	bltu	a1,a4,2034 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1ed6:	02e876bb          	remuw	a3,a6,a4
    1eda:	1682                	slli	a3,a3,0x20
    1edc:	9281                	srli	a3,a3,0x20
    1ede:	96b2                	add	a3,a3,a2
    1ee0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ee4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ee8:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1eec:	14e86d63          	bltu	a6,a4,2046 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1ef0:	02e5f6bb          	remuw	a3,a1,a4
    1ef4:	1682                	slli	a3,a3,0x20
    1ef6:	9281                	srli	a3,a3,0x20
    1ef8:	96b2                	add	a3,a3,a2
    1efa:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1efe:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f02:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1f06:	10e5e563          	bltu	a1,a4,2010 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1f0a:	02e876bb          	remuw	a3,a6,a4
    1f0e:	1682                	slli	a3,a3,0x20
    1f10:	9281                	srli	a3,a3,0x20
    1f12:	96b2                	add	a3,a3,a2
    1f14:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f18:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f1c:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1f20:	14e86263          	bltu	a6,a4,2064 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1f24:	02e5f6bb          	remuw	a3,a1,a4
    1f28:	1682                	slli	a3,a3,0x20
    1f2a:	9281                	srli	a3,a3,0x20
    1f2c:	96b2                	add	a3,a3,a2
    1f2e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f32:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f36:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1f3a:	14e5e463          	bltu	a1,a4,2082 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1f3e:	02e876bb          	remuw	a3,a6,a4
    1f42:	1682                	slli	a3,a3,0x20
    1f44:	9281                	srli	a3,a3,0x20
    1f46:	96b2                	add	a3,a3,a2
    1f48:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f4c:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1f50:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1f54:	14e86063          	bltu	a6,a4,2094 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1f58:	1782                	slli	a5,a5,0x20
    1f5a:	9381                	srli	a5,a5,0x20
    1f5c:	97b2                	add	a5,a5,a2
    1f5e:	0007c703          	lbu	a4,0(a5)
    1f62:	4799                	li	a5,6
    1f64:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1f68:	10054763          	bltz	a0,2076 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1f6c:	00001497          	auipc	s1,0x1
    1f70:	f5448493          	addi	s1,s1,-172 # 2ec0 <buffer_len>
    1f74:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1f78:	0828                	addi	a0,sp,24
    1f7a:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1f7c:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1f7e:	00f50433          	add	s0,a0,a5
    1f82:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1f84:	06e68463          	beq	a3,a4,1fec <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1f88:	8522                	mv	a0,s0
    1f8a:	b15ff0ef          	jal	ra,1a9e <out_unlocked>
}
    1f8e:	60a6                	ld	ra,72(sp)
    1f90:	6406                	ld	s0,64(sp)
    1f92:	74e2                	ld	s1,56(sp)
    1f94:	6161                	addi	sp,sp,80
    1f96:	8082                	ret
		x = -xx;
    1f98:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1f9c:	02b877bb          	remuw	a5,a6,a1
    1fa0:	00001617          	auipc	a2,0x1
    1fa4:	03060613          	addi	a2,a2,48 # 2fd0 <digits>
	buf[16] = 0;
    1fa8:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1fac:	0005871b          	sext.w	a4,a1
    1fb0:	1782                	slli	a5,a5,0x20
    1fb2:	9381                	srli	a5,a5,0x20
    1fb4:	97b2                	add	a5,a5,a2
    1fb6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1fba:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1fbe:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1fc2:	08b86b63          	bltu	a6,a1,2058 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1fc6:	02e8f7bb          	remuw	a5,a7,a4
    1fca:	1782                	slli	a5,a5,0x20
    1fcc:	9381                	srli	a5,a5,0x20
    1fce:	97b2                	add	a5,a5,a2
    1fd0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1fd4:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1fd8:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1fdc:	ece8f1e3          	bgeu	a7,a4,1e9e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1fe0:	02d00793          	li	a5,45
    1fe4:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1fe8:	47b5                	li	a5,13
    1fea:	b749                	j	1f6c <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1fec:	10c4a503          	lw	a0,268(s1)
    1ff0:	e42e                	sd	a1,8(sp)
    1ff2:	2c1000ef          	jal	ra,2ab2 <mutex_lock>
		len = out_unlocked(s, l);
    1ff6:	65a2                	ld	a1,8(sp)
    1ff8:	8522                	mv	a0,s0
    1ffa:	aa5ff0ef          	jal	ra,1a9e <out_unlocked>
		mutex_unlock(buffer_lock);
    1ffe:	10c4a503          	lw	a0,268(s1)
    2002:	2bd000ef          	jal	ra,2abe <mutex_unlock>
}
    2006:	60a6                	ld	ra,72(sp)
    2008:	6406                	ld	s0,64(sp)
    200a:	74e2                	ld	s1,56(sp)
    200c:	6161                	addi	sp,sp,80
    200e:	8082                	ret
		buf[i--] = digits[x % base];
    2010:	47a9                	li	a5,10
	if (sign)
    2012:	f4055de3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    2016:	02d00793          	li	a5,45
    201a:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    201e:	47a5                	li	a5,9
    2020:	b7b1                	j	1f6c <printint.constprop.0+0x122>
    2022:	47b5                	li	a5,13
	if (sign)
    2024:	f40554e3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    2028:	02d00793          	li	a5,45
    202c:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    2030:	47b1                	li	a5,12
    2032:	bf2d                	j	1f6c <printint.constprop.0+0x122>
    2034:	47b1                	li	a5,12
	if (sign)
    2036:	f2055be3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    203a:	02d00793          	li	a5,45
    203e:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    2042:	47ad                	li	a5,11
    2044:	b725                	j	1f6c <printint.constprop.0+0x122>
    2046:	47ad                	li	a5,11
	if (sign)
    2048:	f20552e3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    204c:	02d00793          	li	a5,45
    2050:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    2054:	47a9                	li	a5,10
    2056:	bf19                	j	1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    2058:	02d00793          	li	a5,45
    205c:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    2060:	47b9                	li	a5,14
    2062:	b729                	j	1f6c <printint.constprop.0+0x122>
    2064:	47a5                	li	a5,9
	if (sign)
    2066:	f00553e3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    206a:	02d00793          	li	a5,45
    206e:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    2072:	47a1                	li	a5,8
    2074:	bde5                	j	1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    2076:	02d00793          	li	a5,45
    207a:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    207e:	4795                	li	a5,5
    2080:	b5f5                	j	1f6c <printint.constprop.0+0x122>
    2082:	47a1                	li	a5,8
	if (sign)
    2084:	ee0554e3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    2088:	02d00793          	li	a5,45
    208c:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    2090:	479d                	li	a5,7
    2092:	bde9                	j	1f6c <printint.constprop.0+0x122>
    2094:	479d                	li	a5,7
	if (sign)
    2096:	ec055be3          	bgez	a0,1f6c <printint.constprop.0+0x122>
		buf[i--] = '-';
    209a:	02d00793          	li	a5,45
    209e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    20a2:	4799                	li	a5,6
    20a4:	b5e1                	j	1f6c <printint.constprop.0+0x122>

00000000000020a6 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    20a6:	02000793          	li	a5,32
    20aa:	00f50663          	beq	a0,a5,20b6 <isspace+0x10>
    20ae:	355d                	addiw	a0,a0,-9
    20b0:	00553513          	sltiu	a0,a0,5
    20b4:	8082                	ret
    20b6:	4505                	li	a0,1
}
    20b8:	8082                	ret

00000000000020ba <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    20ba:	fd05051b          	addiw	a0,a0,-48
}
    20be:	00a53513          	sltiu	a0,a0,10
    20c2:	8082                	ret

00000000000020c4 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    20c4:	02000613          	li	a2,32
    20c8:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    20ca:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    20ce:	ff77869b          	addiw	a3,a5,-9
    20d2:	04c78c63          	beq	a5,a2,212a <atoi+0x66>
    20d6:	0007871b          	sext.w	a4,a5
    20da:	04d5f863          	bgeu	a1,a3,212a <atoi+0x66>
		s++;
	switch (*s) {
    20de:	02b00693          	li	a3,43
    20e2:	04d78963          	beq	a5,a3,2134 <atoi+0x70>
    20e6:	02d00693          	li	a3,45
    20ea:	06d78263          	beq	a5,a3,214e <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    20ee:	fd07061b          	addiw	a2,a4,-48
    20f2:	47a5                	li	a5,9
    20f4:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    20f6:	4e01                	li	t3,0
	while (isdigit(*s))
    20f8:	04c7e963          	bltu	a5,a2,214a <atoi+0x86>
	int n = 0, neg = 0;
    20fc:	4501                	li	a0,0
	while (isdigit(*s))
    20fe:	4825                	li	a6,9
    2100:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    2104:	0025179b          	slliw	a5,a0,0x2
    2108:	9fa9                	addw	a5,a5,a0
    210a:	fd07031b          	addiw	t1,a4,-48
    210e:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    2112:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    2116:	0685                	addi	a3,a3,1
    2118:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    211c:	0006071b          	sext.w	a4,a2
    2120:	feb870e3          	bgeu	a6,a1,2100 <atoi+0x3c>
	return neg ? n : -n;
    2124:	000e0563          	beqz	t3,212e <atoi+0x6a>
}
    2128:	8082                	ret
		s++;
    212a:	0505                	addi	a0,a0,1
    212c:	bf79                	j	20ca <atoi+0x6>
	return neg ? n : -n;
    212e:	4113053b          	subw	a0,t1,a7
    2132:	8082                	ret
	while (isdigit(*s))
    2134:	00154703          	lbu	a4,1(a0)
    2138:	47a5                	li	a5,9
		s++;
    213a:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    213e:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    2142:	4e01                	li	t3,0
	while (isdigit(*s))
    2144:	2701                	sext.w	a4,a4
    2146:	fac7fbe3          	bgeu	a5,a2,20fc <atoi+0x38>
    214a:	4501                	li	a0,0
}
    214c:	8082                	ret
	while (isdigit(*s))
    214e:	00154703          	lbu	a4,1(a0)
    2152:	47a5                	li	a5,9
		s++;
    2154:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2158:	fd07061b          	addiw	a2,a4,-48
    215c:	2701                	sext.w	a4,a4
    215e:	fec7e6e3          	bltu	a5,a2,214a <atoi+0x86>
		neg = 1;
    2162:	4e05                	li	t3,1
    2164:	bf61                	j	20fc <atoi+0x38>

0000000000002166 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    2166:	16060d63          	beqz	a2,22e0 <memset+0x17a>
    216a:	40a007b3          	neg	a5,a0
    216e:	8b9d                	andi	a5,a5,7
    2170:	00778693          	addi	a3,a5,7
    2174:	482d                	li	a6,11
    2176:	0ff5f713          	zext.b	a4,a1
    217a:	fff60593          	addi	a1,a2,-1
    217e:	1706e263          	bltu	a3,a6,22e2 <memset+0x17c>
    2182:	16d5ea63          	bltu	a1,a3,22f6 <memset+0x190>
    2186:	16078563          	beqz	a5,22f0 <memset+0x18a>
    218a:	00e50023          	sb	a4,0(a0)
    218e:	4685                	li	a3,1
    2190:	00150593          	addi	a1,a0,1
    2194:	14d78c63          	beq	a5,a3,22ec <memset+0x186>
    2198:	00e500a3          	sb	a4,1(a0)
    219c:	4689                	li	a3,2
    219e:	00250593          	addi	a1,a0,2
    21a2:	14d78d63          	beq	a5,a3,22fc <memset+0x196>
    21a6:	00e50123          	sb	a4,2(a0)
    21aa:	468d                	li	a3,3
    21ac:	00350593          	addi	a1,a0,3
    21b0:	12d78b63          	beq	a5,a3,22e6 <memset+0x180>
    21b4:	00e501a3          	sb	a4,3(a0)
    21b8:	4691                	li	a3,4
    21ba:	00450593          	addi	a1,a0,4
    21be:	14d78163          	beq	a5,a3,2300 <memset+0x19a>
    21c2:	00e50223          	sb	a4,4(a0)
    21c6:	4695                	li	a3,5
    21c8:	00550593          	addi	a1,a0,5
    21cc:	12d78c63          	beq	a5,a3,2304 <memset+0x19e>
    21d0:	00e502a3          	sb	a4,5(a0)
    21d4:	469d                	li	a3,7
    21d6:	00650593          	addi	a1,a0,6
    21da:	12d79763          	bne	a5,a3,2308 <memset+0x1a2>
    21de:	00750593          	addi	a1,a0,7
    21e2:	00e50323          	sb	a4,6(a0)
    21e6:	481d                	li	a6,7
    21e8:	00871693          	slli	a3,a4,0x8
    21ec:	01071893          	slli	a7,a4,0x10
    21f0:	8ed9                	or	a3,a3,a4
    21f2:	01871313          	slli	t1,a4,0x18
    21f6:	0116e6b3          	or	a3,a3,a7
    21fa:	0066e6b3          	or	a3,a3,t1
    21fe:	02071893          	slli	a7,a4,0x20
    2202:	02871e13          	slli	t3,a4,0x28
    2206:	0116e6b3          	or	a3,a3,a7
    220a:	40f60333          	sub	t1,a2,a5
    220e:	03071893          	slli	a7,a4,0x30
    2212:	01c6e6b3          	or	a3,a3,t3
    2216:	0116e6b3          	or	a3,a3,a7
    221a:	03871e13          	slli	t3,a4,0x38
    221e:	97aa                	add	a5,a5,a0
    2220:	ff837893          	andi	a7,t1,-8
    2224:	01c6e6b3          	or	a3,a3,t3
    2228:	98be                	add	a7,a7,a5
    222a:	e394                	sd	a3,0(a5)
    222c:	07a1                	addi	a5,a5,8
    222e:	ff179ee3          	bne	a5,a7,222a <memset+0xc4>
    2232:	ff837893          	andi	a7,t1,-8
    2236:	011587b3          	add	a5,a1,a7
    223a:	010886bb          	addw	a3,a7,a6
    223e:	0b130663          	beq	t1,a7,22ea <memset+0x184>
    2242:	00e78023          	sb	a4,0(a5)
    2246:	0016859b          	addiw	a1,a3,1
    224a:	08c5fb63          	bgeu	a1,a2,22e0 <memset+0x17a>
    224e:	00e780a3          	sb	a4,1(a5)
    2252:	0026859b          	addiw	a1,a3,2
    2256:	08c5f563          	bgeu	a1,a2,22e0 <memset+0x17a>
    225a:	00e78123          	sb	a4,2(a5)
    225e:	0036859b          	addiw	a1,a3,3
    2262:	06c5ff63          	bgeu	a1,a2,22e0 <memset+0x17a>
    2266:	00e781a3          	sb	a4,3(a5)
    226a:	0046859b          	addiw	a1,a3,4
    226e:	06c5f963          	bgeu	a1,a2,22e0 <memset+0x17a>
    2272:	00e78223          	sb	a4,4(a5)
    2276:	0056859b          	addiw	a1,a3,5
    227a:	06c5f363          	bgeu	a1,a2,22e0 <memset+0x17a>
    227e:	00e782a3          	sb	a4,5(a5)
    2282:	0066859b          	addiw	a1,a3,6
    2286:	04c5fd63          	bgeu	a1,a2,22e0 <memset+0x17a>
    228a:	00e78323          	sb	a4,6(a5)
    228e:	0076859b          	addiw	a1,a3,7
    2292:	04c5f763          	bgeu	a1,a2,22e0 <memset+0x17a>
    2296:	00e783a3          	sb	a4,7(a5)
    229a:	0086859b          	addiw	a1,a3,8
    229e:	04c5f163          	bgeu	a1,a2,22e0 <memset+0x17a>
    22a2:	00e78423          	sb	a4,8(a5)
    22a6:	0096859b          	addiw	a1,a3,9
    22aa:	02c5fb63          	bgeu	a1,a2,22e0 <memset+0x17a>
    22ae:	00e784a3          	sb	a4,9(a5)
    22b2:	00a6859b          	addiw	a1,a3,10
    22b6:	02c5f563          	bgeu	a1,a2,22e0 <memset+0x17a>
    22ba:	00e78523          	sb	a4,10(a5)
    22be:	00b6859b          	addiw	a1,a3,11
    22c2:	00c5ff63          	bgeu	a1,a2,22e0 <memset+0x17a>
    22c6:	00e785a3          	sb	a4,11(a5)
    22ca:	00c6859b          	addiw	a1,a3,12
    22ce:	00c5f963          	bgeu	a1,a2,22e0 <memset+0x17a>
    22d2:	00e78623          	sb	a4,12(a5)
    22d6:	26b5                	addiw	a3,a3,13
    22d8:	00c6f463          	bgeu	a3,a2,22e0 <memset+0x17a>
    22dc:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    22e0:	8082                	ret
    22e2:	46ad                	li	a3,11
    22e4:	bd79                	j	2182 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22e6:	480d                	li	a6,3
    22e8:	b701                	j	21e8 <memset+0x82>
    22ea:	8082                	ret
    22ec:	4805                	li	a6,1
    22ee:	bded                	j	21e8 <memset+0x82>
    22f0:	85aa                	mv	a1,a0
    22f2:	4801                	li	a6,0
    22f4:	bdd5                	j	21e8 <memset+0x82>
    22f6:	87aa                	mv	a5,a0
    22f8:	4681                	li	a3,0
    22fa:	b7a1                	j	2242 <memset+0xdc>
    22fc:	4809                	li	a6,2
    22fe:	b5ed                	j	21e8 <memset+0x82>
    2300:	4811                	li	a6,4
    2302:	b5dd                	j	21e8 <memset+0x82>
    2304:	4815                	li	a6,5
    2306:	b5cd                	j	21e8 <memset+0x82>
    2308:	4819                	li	a6,6
    230a:	bdf9                	j	21e8 <memset+0x82>

000000000000230c <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    230c:	00054783          	lbu	a5,0(a0)
    2310:	0005c703          	lbu	a4,0(a1)
    2314:	00e79863          	bne	a5,a4,2324 <strcmp+0x18>
    2318:	0505                	addi	a0,a0,1
    231a:	0585                	addi	a1,a1,1
    231c:	fbe5                	bnez	a5,230c <strcmp>
    231e:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2320:	9d19                	subw	a0,a0,a4
    2322:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    2324:	0007851b          	sext.w	a0,a5
    2328:	bfe5                	j	2320 <strcmp+0x14>

000000000000232a <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    232a:	ca15                	beqz	a2,235e <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    232c:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2330:	167d                	addi	a2,a2,-1
    2332:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2336:	eb99                	bnez	a5,234c <strncmp+0x22>
    2338:	a815                	j	236c <strncmp+0x42>
    233a:	00a68e63          	beq	a3,a0,2356 <strncmp+0x2c>
    233e:	0505                	addi	a0,a0,1
    2340:	00f71b63          	bne	a4,a5,2356 <strncmp+0x2c>
    2344:	00054783          	lbu	a5,0(a0)
    2348:	cf89                	beqz	a5,2362 <strncmp+0x38>
    234a:	85b2                	mv	a1,a2
    234c:	0005c703          	lbu	a4,0(a1)
    2350:	00158613          	addi	a2,a1,1
    2354:	f37d                	bnez	a4,233a <strncmp+0x10>
		;
	return *l - *r;
    2356:	0007851b          	sext.w	a0,a5
    235a:	9d19                	subw	a0,a0,a4
    235c:	8082                	ret
		return 0;
    235e:	4501                	li	a0,0
}
    2360:	8082                	ret
	return *l - *r;
    2362:	0015c703          	lbu	a4,1(a1)
    2366:	4501                	li	a0,0
    2368:	9d19                	subw	a0,a0,a4
    236a:	8082                	ret
    236c:	0005c703          	lbu	a4,0(a1)
    2370:	4501                	li	a0,0
    2372:	b7e5                	j	235a <strncmp+0x30>

0000000000002374 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2374:	00757793          	andi	a5,a0,7
    2378:	cf89                	beqz	a5,2392 <strlen+0x1e>
    237a:	87aa                	mv	a5,a0
    237c:	a029                	j	2386 <strlen+0x12>
    237e:	0785                	addi	a5,a5,1
    2380:	0077f713          	andi	a4,a5,7
    2384:	cb01                	beqz	a4,2394 <strlen+0x20>
		if (!*s)
    2386:	0007c703          	lbu	a4,0(a5)
    238a:	fb75                	bnez	a4,237e <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    238c:	40a78533          	sub	a0,a5,a0
}
    2390:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2392:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2394:	6394                	ld	a3,0(a5)
    2396:	00001597          	auipc	a1,0x1
    239a:	ac25b583          	ld	a1,-1342(a1) # 2e58 <enable_deadlock_detect+0x346>
    239e:	00001617          	auipc	a2,0x1
    23a2:	ac263603          	ld	a2,-1342(a2) # 2e60 <enable_deadlock_detect+0x34e>
    23a6:	a019                	j	23ac <strlen+0x38>
    23a8:	6794                	ld	a3,8(a5)
    23aa:	07a1                	addi	a5,a5,8
    23ac:	00b68733          	add	a4,a3,a1
    23b0:	fff6c693          	not	a3,a3
    23b4:	8f75                	and	a4,a4,a3
    23b6:	8f71                	and	a4,a4,a2
    23b8:	db65                	beqz	a4,23a8 <strlen+0x34>
	for (; *s; s++)
    23ba:	0007c703          	lbu	a4,0(a5)
    23be:	d779                	beqz	a4,238c <strlen+0x18>
    23c0:	0017c703          	lbu	a4,1(a5)
    23c4:	0785                	addi	a5,a5,1
    23c6:	d379                	beqz	a4,238c <strlen+0x18>
    23c8:	0017c703          	lbu	a4,1(a5)
    23cc:	0785                	addi	a5,a5,1
    23ce:	fb6d                	bnez	a4,23c0 <strlen+0x4c>
    23d0:	bf75                	j	238c <strlen+0x18>

00000000000023d2 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    23d2:	00757713          	andi	a4,a0,7
{
    23d6:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    23d8:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    23dc:	cb19                	beqz	a4,23f2 <memchr+0x20>
    23de:	ce25                	beqz	a2,2456 <memchr+0x84>
    23e0:	0007c703          	lbu	a4,0(a5)
    23e4:	04b70e63          	beq	a4,a1,2440 <memchr+0x6e>
    23e8:	0785                	addi	a5,a5,1
    23ea:	0077f713          	andi	a4,a5,7
    23ee:	167d                	addi	a2,a2,-1
    23f0:	f77d                	bnez	a4,23de <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    23f2:	4501                	li	a0,0
	if (n && *s != c) {
    23f4:	c235                	beqz	a2,2458 <memchr+0x86>
    23f6:	0007c703          	lbu	a4,0(a5)
    23fa:	04b70363          	beq	a4,a1,2440 <memchr+0x6e>
		size_t k = ONES * c;
    23fe:	00001517          	auipc	a0,0x1
    2402:	a6a53503          	ld	a0,-1430(a0) # 2e68 <enable_deadlock_detect+0x356>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2406:	471d                	li	a4,7
		size_t k = ONES * c;
    2408:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    240c:	02c77a63          	bgeu	a4,a2,2440 <memchr+0x6e>
    2410:	00001897          	auipc	a7,0x1
    2414:	a488b883          	ld	a7,-1464(a7) # 2e58 <enable_deadlock_detect+0x346>
    2418:	00001817          	auipc	a6,0x1
    241c:	a4883803          	ld	a6,-1464(a6) # 2e60 <enable_deadlock_detect+0x34e>
    2420:	431d                	li	t1,7
    2422:	a029                	j	242c <memchr+0x5a>
		     w++, n -= SS)
    2424:	1661                	addi	a2,a2,-8
    2426:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2428:	02c37963          	bgeu	t1,a2,245a <memchr+0x88>
    242c:	6398                	ld	a4,0(a5)
    242e:	8f29                	xor	a4,a4,a0
    2430:	011706b3          	add	a3,a4,a7
    2434:	fff74713          	not	a4,a4
    2438:	8f75                	and	a4,a4,a3
    243a:	01077733          	and	a4,a4,a6
    243e:	d37d                	beqz	a4,2424 <memchr+0x52>
{
    2440:	853e                	mv	a0,a5
    2442:	97b2                	add	a5,a5,a2
    2444:	a021                	j	244c <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2446:	0505                	addi	a0,a0,1
    2448:	00f50763          	beq	a0,a5,2456 <memchr+0x84>
    244c:	00054703          	lbu	a4,0(a0)
    2450:	feb71be3          	bne	a4,a1,2446 <memchr+0x74>
    2454:	8082                	ret
	return n ? (void *)s : 0;
    2456:	4501                	li	a0,0
}
    2458:	8082                	ret
	return n ? (void *)s : 0;
    245a:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    245c:	f275                	bnez	a2,2440 <memchr+0x6e>
}
    245e:	8082                	ret

0000000000002460 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2460:	1101                	addi	sp,sp,-32
    2462:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2464:	862e                	mv	a2,a1
{
    2466:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2468:	4581                	li	a1,0
{
    246a:	e426                	sd	s1,8(sp)
    246c:	ec06                	sd	ra,24(sp)
    246e:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2470:	f63ff0ef          	jal	ra,23d2 <memchr>
	return p ? p - s : n;
    2474:	c519                	beqz	a0,2482 <strnlen+0x22>
}
    2476:	60e2                	ld	ra,24(sp)
    2478:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    247a:	8d05                	sub	a0,a0,s1
}
    247c:	64a2                	ld	s1,8(sp)
    247e:	6105                	addi	sp,sp,32
    2480:	8082                	ret
    2482:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2484:	8522                	mv	a0,s0
}
    2486:	6442                	ld	s0,16(sp)
    2488:	64a2                	ld	s1,8(sp)
    248a:	6105                	addi	sp,sp,32
    248c:	8082                	ret

000000000000248e <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    248e:	00a5c7b3          	xor	a5,a1,a0
    2492:	8b9d                	andi	a5,a5,7
    2494:	eb95                	bnez	a5,24c8 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2496:	0075f793          	andi	a5,a1,7
    249a:	e7b1                	bnez	a5,24e6 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    249c:	6198                	ld	a4,0(a1)
    249e:	00001617          	auipc	a2,0x1
    24a2:	9ba63603          	ld	a2,-1606(a2) # 2e58 <enable_deadlock_detect+0x346>
    24a6:	00001817          	auipc	a6,0x1
    24aa:	9ba83803          	ld	a6,-1606(a6) # 2e60 <enable_deadlock_detect+0x34e>
    24ae:	a029                	j	24b8 <stpcpy+0x2a>
    24b0:	05a1                	addi	a1,a1,8
    24b2:	e118                	sd	a4,0(a0)
    24b4:	6198                	ld	a4,0(a1)
    24b6:	0521                	addi	a0,a0,8
    24b8:	00c707b3          	add	a5,a4,a2
    24bc:	fff74693          	not	a3,a4
    24c0:	8ff5                	and	a5,a5,a3
    24c2:	0107f7b3          	and	a5,a5,a6
    24c6:	d7ed                	beqz	a5,24b0 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    24c8:	0005c783          	lbu	a5,0(a1)
    24cc:	00f50023          	sb	a5,0(a0)
    24d0:	c785                	beqz	a5,24f8 <stpcpy+0x6a>
    24d2:	0015c783          	lbu	a5,1(a1)
    24d6:	0505                	addi	a0,a0,1
    24d8:	0585                	addi	a1,a1,1
    24da:	00f50023          	sb	a5,0(a0)
    24de:	fbf5                	bnez	a5,24d2 <stpcpy+0x44>
		;
	return d;
}
    24e0:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    24e2:	0505                	addi	a0,a0,1
    24e4:	df45                	beqz	a4,249c <stpcpy+0xe>
			if (!(*d = *s))
    24e6:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    24ea:	0585                	addi	a1,a1,1
    24ec:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    24f0:	00f50023          	sb	a5,0(a0)
    24f4:	f7fd                	bnez	a5,24e2 <stpcpy+0x54>
}
    24f6:	8082                	ret
    24f8:	8082                	ret

00000000000024fa <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    24fa:	00a5c7b3          	xor	a5,a1,a0
    24fe:	8b9d                	andi	a5,a5,7
    2500:	1a079863          	bnez	a5,26b0 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2504:	0075f793          	andi	a5,a1,7
    2508:	16078463          	beqz	a5,2670 <stpncpy+0x176>
    250c:	ea01                	bnez	a2,251c <stpncpy+0x22>
    250e:	a421                	j	2716 <stpncpy+0x21c>
    2510:	167d                	addi	a2,a2,-1
    2512:	0505                	addi	a0,a0,1
    2514:	14070e63          	beqz	a4,2670 <stpncpy+0x176>
    2518:	1a060863          	beqz	a2,26c8 <stpncpy+0x1ce>
    251c:	0005c783          	lbu	a5,0(a1)
    2520:	0585                	addi	a1,a1,1
    2522:	0075f713          	andi	a4,a1,7
    2526:	00f50023          	sb	a5,0(a0)
    252a:	f3fd                	bnez	a5,2510 <stpncpy+0x16>
    252c:	4805                	li	a6,1
    252e:	1a061863          	bnez	a2,26de <stpncpy+0x1e4>
    2532:	40a007b3          	neg	a5,a0
    2536:	8b9d                	andi	a5,a5,7
    2538:	4681                	li	a3,0
    253a:	18061a63          	bnez	a2,26ce <stpncpy+0x1d4>
    253e:	00778713          	addi	a4,a5,7
    2542:	45ad                	li	a1,11
    2544:	18b76363          	bltu	a4,a1,26ca <stpncpy+0x1d0>
    2548:	1ae6eb63          	bltu	a3,a4,26fe <stpncpy+0x204>
    254c:	1a078363          	beqz	a5,26f2 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2550:	00050023          	sb	zero,0(a0)
    2554:	4685                	li	a3,1
    2556:	00150713          	addi	a4,a0,1
    255a:	18d78f63          	beq	a5,a3,26f8 <stpncpy+0x1fe>
    255e:	000500a3          	sb	zero,1(a0)
    2562:	4689                	li	a3,2
    2564:	00250713          	addi	a4,a0,2
    2568:	18d78e63          	beq	a5,a3,2704 <stpncpy+0x20a>
    256c:	00050123          	sb	zero,2(a0)
    2570:	468d                	li	a3,3
    2572:	00350713          	addi	a4,a0,3
    2576:	16d78c63          	beq	a5,a3,26ee <stpncpy+0x1f4>
    257a:	000501a3          	sb	zero,3(a0)
    257e:	4691                	li	a3,4
    2580:	00450713          	addi	a4,a0,4
    2584:	18d78263          	beq	a5,a3,2708 <stpncpy+0x20e>
    2588:	00050223          	sb	zero,4(a0)
    258c:	4695                	li	a3,5
    258e:	00550713          	addi	a4,a0,5
    2592:	16d78d63          	beq	a5,a3,270c <stpncpy+0x212>
    2596:	000502a3          	sb	zero,5(a0)
    259a:	469d                	li	a3,7
    259c:	00650713          	addi	a4,a0,6
    25a0:	16d79863          	bne	a5,a3,2710 <stpncpy+0x216>
    25a4:	00750713          	addi	a4,a0,7
    25a8:	00050323          	sb	zero,6(a0)
    25ac:	40f80833          	sub	a6,a6,a5
    25b0:	ff887593          	andi	a1,a6,-8
    25b4:	97aa                	add	a5,a5,a0
    25b6:	95be                	add	a1,a1,a5
    25b8:	0007b023          	sd	zero,0(a5)
    25bc:	07a1                	addi	a5,a5,8
    25be:	feb79de3          	bne	a5,a1,25b8 <stpncpy+0xbe>
    25c2:	ff887593          	andi	a1,a6,-8
    25c6:	9ead                	addw	a3,a3,a1
    25c8:	00b707b3          	add	a5,a4,a1
    25cc:	12b80863          	beq	a6,a1,26fc <stpncpy+0x202>
    25d0:	00078023          	sb	zero,0(a5)
    25d4:	0016871b          	addiw	a4,a3,1
    25d8:	0ec77863          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    25dc:	000780a3          	sb	zero,1(a5)
    25e0:	0026871b          	addiw	a4,a3,2
    25e4:	0ec77263          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    25e8:	00078123          	sb	zero,2(a5)
    25ec:	0036871b          	addiw	a4,a3,3
    25f0:	0cc77c63          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    25f4:	000781a3          	sb	zero,3(a5)
    25f8:	0046871b          	addiw	a4,a3,4
    25fc:	0cc77663          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2600:	00078223          	sb	zero,4(a5)
    2604:	0056871b          	addiw	a4,a3,5
    2608:	0cc77063          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    260c:	000782a3          	sb	zero,5(a5)
    2610:	0066871b          	addiw	a4,a3,6
    2614:	0ac77a63          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2618:	00078323          	sb	zero,6(a5)
    261c:	0076871b          	addiw	a4,a3,7
    2620:	0ac77463          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2624:	000783a3          	sb	zero,7(a5)
    2628:	0086871b          	addiw	a4,a3,8
    262c:	08c77e63          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2630:	00078423          	sb	zero,8(a5)
    2634:	0096871b          	addiw	a4,a3,9
    2638:	08c77863          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    263c:	000784a3          	sb	zero,9(a5)
    2640:	00a6871b          	addiw	a4,a3,10
    2644:	08c77263          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2648:	00078523          	sb	zero,10(a5)
    264c:	00b6871b          	addiw	a4,a3,11
    2650:	06c77c63          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2654:	000785a3          	sb	zero,11(a5)
    2658:	00c6871b          	addiw	a4,a3,12
    265c:	06c77663          	bgeu	a4,a2,26c8 <stpncpy+0x1ce>
    2660:	00078623          	sb	zero,12(a5)
    2664:	26b5                	addiw	a3,a3,13
    2666:	06c6f163          	bgeu	a3,a2,26c8 <stpncpy+0x1ce>
    266a:	000786a3          	sb	zero,13(a5)
    266e:	8082                	ret
			;
		if (!n || !*s)
    2670:	c645                	beqz	a2,2718 <stpncpy+0x21e>
    2672:	0005c783          	lbu	a5,0(a1)
    2676:	ea078be3          	beqz	a5,252c <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    267a:	479d                	li	a5,7
    267c:	02c7ff63          	bgeu	a5,a2,26ba <stpncpy+0x1c0>
    2680:	00000897          	auipc	a7,0x0
    2684:	7d88b883          	ld	a7,2008(a7) # 2e58 <enable_deadlock_detect+0x346>
    2688:	00000817          	auipc	a6,0x0
    268c:	7d883803          	ld	a6,2008(a6) # 2e60 <enable_deadlock_detect+0x34e>
    2690:	431d                	li	t1,7
    2692:	6198                	ld	a4,0(a1)
    2694:	011707b3          	add	a5,a4,a7
    2698:	fff74693          	not	a3,a4
    269c:	8ff5                	and	a5,a5,a3
    269e:	0107f7b3          	and	a5,a5,a6
    26a2:	ef81                	bnez	a5,26ba <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    26a4:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    26a6:	1661                	addi	a2,a2,-8
    26a8:	05a1                	addi	a1,a1,8
    26aa:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    26ac:	fec363e3          	bltu	t1,a2,2692 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    26b0:	e609                	bnez	a2,26ba <stpncpy+0x1c0>
    26b2:	a08d                	j	2714 <stpncpy+0x21a>
    26b4:	167d                	addi	a2,a2,-1
    26b6:	0505                	addi	a0,a0,1
    26b8:	ca01                	beqz	a2,26c8 <stpncpy+0x1ce>
    26ba:	0005c783          	lbu	a5,0(a1)
    26be:	0585                	addi	a1,a1,1
    26c0:	00f50023          	sb	a5,0(a0)
    26c4:	fbe5                	bnez	a5,26b4 <stpncpy+0x1ba>
		;
tail:
    26c6:	b59d                	j	252c <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    26c8:	8082                	ret
    26ca:	472d                	li	a4,11
    26cc:	bdb5                	j	2548 <stpncpy+0x4e>
    26ce:	00778713          	addi	a4,a5,7
    26d2:	45ad                	li	a1,11
    26d4:	fff60693          	addi	a3,a2,-1
    26d8:	e6b778e3          	bgeu	a4,a1,2548 <stpncpy+0x4e>
    26dc:	b7fd                	j	26ca <stpncpy+0x1d0>
    26de:	40a007b3          	neg	a5,a0
    26e2:	8832                	mv	a6,a2
    26e4:	8b9d                	andi	a5,a5,7
    26e6:	4681                	li	a3,0
    26e8:	e4060be3          	beqz	a2,253e <stpncpy+0x44>
    26ec:	b7cd                	j	26ce <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    26ee:	468d                	li	a3,3
    26f0:	bd75                	j	25ac <stpncpy+0xb2>
    26f2:	872a                	mv	a4,a0
    26f4:	4681                	li	a3,0
    26f6:	bd5d                	j	25ac <stpncpy+0xb2>
    26f8:	4685                	li	a3,1
    26fa:	bd4d                	j	25ac <stpncpy+0xb2>
    26fc:	8082                	ret
    26fe:	87aa                	mv	a5,a0
    2700:	4681                	li	a3,0
    2702:	b5f9                	j	25d0 <stpncpy+0xd6>
    2704:	4689                	li	a3,2
    2706:	b55d                	j	25ac <stpncpy+0xb2>
    2708:	4691                	li	a3,4
    270a:	b54d                	j	25ac <stpncpy+0xb2>
    270c:	4695                	li	a3,5
    270e:	bd79                	j	25ac <stpncpy+0xb2>
    2710:	4699                	li	a3,6
    2712:	bd69                	j	25ac <stpncpy+0xb2>
    2714:	8082                	ret
    2716:	8082                	ret
    2718:	8082                	ret

000000000000271a <basename>:

char *basename(char *s)
{
    271a:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    271c:	c54d                	beqz	a0,27c6 <basename+0xac>
    271e:	00054783          	lbu	a5,0(a0)
		return ".";
    2722:	00000517          	auipc	a0,0x0
    2726:	72e50513          	addi	a0,a0,1838 # 2e50 <enable_deadlock_detect+0x33e>
	if (!s || !*s)
    272a:	e391                	bnez	a5,272e <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    272c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    272e:	0076f713          	andi	a4,a3,7
    2732:	87b6                	mv	a5,a3
    2734:	cf51                	beqz	a4,27d0 <basename+0xb6>
    2736:	0785                	addi	a5,a5,1
    2738:	0077f713          	andi	a4,a5,7
    273c:	c729                	beqz	a4,2786 <basename+0x6c>
		if (!*s)
    273e:	0007c703          	lbu	a4,0(a5)
    2742:	fb75                	bnez	a4,2736 <basename+0x1c>
	return s - a;
    2744:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2746:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2748:	cf8d                	beqz	a5,2782 <basename+0x68>
    274a:	00f68733          	add	a4,a3,a5
    274e:	02f00593          	li	a1,47
    2752:	a031                	j	275e <basename+0x44>
		s[i] = 0;
    2754:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2758:	17fd                	addi	a5,a5,-1
    275a:	177d                	addi	a4,a4,-1
    275c:	c39d                	beqz	a5,2782 <basename+0x68>
    275e:	00074603          	lbu	a2,0(a4)
    2762:	feb609e3          	beq	a2,a1,2754 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2766:	02f00613          	li	a2,47
    276a:	a011                	j	276e <basename+0x54>
    276c:	cb99                	beqz	a5,2782 <basename+0x68>
    276e:	853e                	mv	a0,a5
    2770:	17fd                	addi	a5,a5,-1
    2772:	00f68733          	add	a4,a3,a5
    2776:	00074703          	lbu	a4,0(a4)
    277a:	fec719e3          	bne	a4,a2,276c <basename+0x52>
	return s + i;
    277e:	9536                	add	a0,a0,a3
    2780:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2782:	8536                	mv	a0,a3
    2784:	8082                	ret
    2786:	6390                	ld	a2,0(a5)
    2788:	00000517          	auipc	a0,0x0
    278c:	6d053503          	ld	a0,1744(a0) # 2e58 <enable_deadlock_detect+0x346>
    2790:	00000597          	auipc	a1,0x0
    2794:	6d05b583          	ld	a1,1744(a1) # 2e60 <enable_deadlock_detect+0x34e>
    2798:	fff64713          	not	a4,a2
    279c:	962a                	add	a2,a2,a0
    279e:	8f71                	and	a4,a4,a2
    27a0:	8f6d                	and	a4,a4,a1
    27a2:	eb11                	bnez	a4,27b6 <basename+0x9c>
    27a4:	6790                	ld	a2,8(a5)
    27a6:	07a1                	addi	a5,a5,8
    27a8:	00a60733          	add	a4,a2,a0
    27ac:	fff64613          	not	a2,a2
    27b0:	8f71                	and	a4,a4,a2
    27b2:	8f6d                	and	a4,a4,a1
    27b4:	db65                	beqz	a4,27a4 <basename+0x8a>
	for (; *s; s++)
    27b6:	0007c703          	lbu	a4,0(a5)
    27ba:	d749                	beqz	a4,2744 <basename+0x2a>
    27bc:	0017c703          	lbu	a4,1(a5)
    27c0:	0785                	addi	a5,a5,1
    27c2:	ff6d                	bnez	a4,27bc <basename+0xa2>
    27c4:	b741                	j	2744 <basename+0x2a>
		return ".";
    27c6:	00000517          	auipc	a0,0x0
    27ca:	68a50513          	addi	a0,a0,1674 # 2e50 <enable_deadlock_detect+0x33e>
    27ce:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    27d0:	6290                	ld	a2,0(a3)
    27d2:	00000517          	auipc	a0,0x0
    27d6:	68653503          	ld	a0,1670(a0) # 2e58 <enable_deadlock_detect+0x346>
    27da:	00000597          	auipc	a1,0x0
    27de:	6865b583          	ld	a1,1670(a1) # 2e60 <enable_deadlock_detect+0x34e>
    27e2:	fff64713          	not	a4,a2
    27e6:	962a                	add	a2,a2,a0
    27e8:	8f71                	and	a4,a4,a2
    27ea:	8f6d                	and	a4,a4,a1
    27ec:	df45                	beqz	a4,27a4 <basename+0x8a>
    27ee:	b7f9                	j	27bc <basename+0xa2>

00000000000027f0 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    27f0:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    27f4:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27f6:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    27fa:	2501                	sext.w	a0,a0
    27fc:	8082                	ret

00000000000027fe <close>:

int close(int fd)
{
	if (fd == 1) {
    27fe:	4785                	li	a5,1
    2800:	00f50863          	beq	a0,a5,2810 <close+0x12>
	register long a7 __asm__("a7") = n;
    2804:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2808:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    280c:	2501                	sext.w	a0,a0
    280e:	8082                	ret
{
    2810:	1101                	addi	sp,sp,-32
    2812:	ec06                	sd	ra,24(sp)
    2814:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2816:	cdffe0ef          	jal	ra,14f4 <__write_buffer>
		__clear_buffer();
    281a:	d03fe0ef          	jal	ra,151c <__clear_buffer>
    281e:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2820:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2824:	00000073          	ecall
}
    2828:	60e2                	ld	ra,24(sp)
    282a:	2501                	sext.w	a0,a0
    282c:	6105                	addi	sp,sp,32
    282e:	8082                	ret

0000000000002830 <read>:
	register long a7 __asm__("a7") = n;
    2830:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2834:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2838:	8082                	ret

000000000000283a <write>:
	register long a7 __asm__("a7") = n;
    283a:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    283e:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2842:	8082                	ret

0000000000002844 <getpid>:
	register long a7 __asm__("a7") = n;
    2844:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2848:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    284c:	2501                	sext.w	a0,a0
    284e:	8082                	ret

0000000000002850 <getppid>:
	register long a7 __asm__("a7") = n;
    2850:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2854:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2858:	2501                	sext.w	a0,a0
    285a:	8082                	ret

000000000000285c <sched_yield>:
	register long a7 __asm__("a7") = n;
    285c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2860:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2864:	2501                	sext.w	a0,a0
    2866:	8082                	ret

0000000000002868 <fork>:
	register long a7 __asm__("a7") = n;
    2868:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    286c:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2870:	2501                	sext.w	a0,a0
    2872:	8082                	ret

0000000000002874 <exit>:

void exit(int code)
{
    2874:	1141                	addi	sp,sp,-16
    2876:	e406                	sd	ra,8(sp)
    2878:	e022                	sd	s0,0(sp)
    287a:	842a                	mv	s0,a0
	__write_buffer();
    287c:	c79fe0ef          	jal	ra,14f4 <__write_buffer>
	__clear_buffer();
    2880:	c9dfe0ef          	jal	ra,151c <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2884:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2888:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    288a:	00000073          	ecall
	syscall(SYS_exit, code);
}
    288e:	60a2                	ld	ra,8(sp)
    2890:	6402                	ld	s0,0(sp)
    2892:	0141                	addi	sp,sp,16
    2894:	8082                	ret

0000000000002896 <waitpid>:
	register long a7 __asm__("a7") = n;
    2896:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    289a:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    289e:	2501                	sext.w	a0,a0
    28a0:	8082                	ret

00000000000028a2 <exec>:
	register long a7 __asm__("a7") = n;
    28a2:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28a6:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    28aa:	2501                	sext.w	a0,a0
    28ac:	8082                	ret

00000000000028ae <get_mtime>:

int64 get_mtime()
{
    28ae:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    28b0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    28b4:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    28b6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28b8:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    28bc:	2501                	sext.w	a0,a0
    28be:	ed01                	bnez	a0,28d6 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    28c0:	6722                	ld	a4,8(sp)
    28c2:	3e800793          	li	a5,1000
    28c6:	6682                	ld	a3,0(sp)
    28c8:	02f75733          	divu	a4,a4,a5
    28cc:	02d78533          	mul	a0,a5,a3
    28d0:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    28d2:	0141                	addi	sp,sp,16
    28d4:	8082                	ret
	return -1;
    28d6:	557d                	li	a0,-1
    28d8:	bfed                	j	28d2 <get_mtime+0x24>

00000000000028da <sys_get_time>:
	register long a7 __asm__("a7") = n;
    28da:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28de:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    28e2:	2501                	sext.w	a0,a0
    28e4:	8082                	ret

00000000000028e6 <sleep>:

int sleep(unsigned long long time)
{
    28e6:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    28e8:	880a                	mv	a6,sp
{
    28ea:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    28ec:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    28f0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    28f2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28f4:	00000073          	ecall
	if (err == 0) {
    28f8:	2501                	sext.w	a0,a0
    28fa:	ed31                	bnez	a0,2956 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    28fc:	6722                	ld	a4,8(sp)
    28fe:	3e800793          	li	a5,1000
    2902:	6682                	ld	a3,0(sp)
    2904:	02f75733          	divu	a4,a4,a5
    2908:	02d787b3          	mul	a5,a5,a3
    290c:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    290e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2912:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2914:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2916:	00000073          	ecall
	if (err == 0) {
    291a:	2501                	sext.w	a0,a0
    291c:	e915                	bnez	a0,2950 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    291e:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2920:	3e800693          	li	a3,1000
    2924:	a819                	j	293a <sleep+0x54>
	__asm_syscall("r"(a7))
    2926:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    292a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    292e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2930:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2932:	00000073          	ecall
	if (err == 0) {
    2936:	2501                	sext.w	a0,a0
    2938:	ed01                	bnez	a0,2950 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    293a:	6722                	ld	a4,8(sp)
    293c:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    293e:	07c00893          	li	a7,124
    2942:	02d75733          	divu	a4,a4,a3
    2946:	02f687b3          	mul	a5,a3,a5
    294a:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    294c:	fcc7ede3          	bltu	a5,a2,2926 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2950:	4501                	li	a0,0
    2952:	0141                	addi	sp,sp,16
    2954:	8082                	ret
    2956:	57fd                	li	a5,-1
    2958:	bf5d                	j	290e <sleep+0x28>

000000000000295a <sys_task_info>:
	register long a7 __asm__("a7") = n;
    295a:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    295e:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2962:	2501                	sext.w	a0,a0
    2964:	8082                	ret

0000000000002966 <set_priority>:
	register long a7 __asm__("a7") = n;
    2966:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    296a:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    296e:	2501                	sext.w	a0,a0
    2970:	8082                	ret

0000000000002972 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2972:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2976:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    297a:	2501                	sext.w	a0,a0
    297c:	8082                	ret

000000000000297e <munmap>:
	register long a7 __asm__("a7") = n;
    297e:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2982:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2986:	2501                	sext.w	a0,a0
    2988:	8082                	ret

000000000000298a <wait>:

int wait(int *code)
{
    298a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    298c:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2990:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2992:	00000073          	ecall
	return waitpid(-1, code);
}
    2996:	2501                	sext.w	a0,a0
    2998:	8082                	ret

000000000000299a <spawn>:
	register long a7 __asm__("a7") = n;
    299a:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    299e:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    29a2:	2501                	sext.w	a0,a0
    29a4:	8082                	ret

00000000000029a6 <pipe>:
	register long a7 __asm__("a7") = n;
    29a6:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    29aa:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    29ae:	2501                	sext.w	a0,a0
    29b0:	8082                	ret

00000000000029b2 <mailread>:
	register long a7 __asm__("a7") = n;
    29b2:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29b6:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    29ba:	2501                	sext.w	a0,a0
    29bc:	8082                	ret

00000000000029be <mailwrite>:
	register long a7 __asm__("a7") = n;
    29be:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    29c2:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    29c6:	2501                	sext.w	a0,a0
    29c8:	8082                	ret

00000000000029ca <fstat>:
	register long a7 __asm__("a7") = n;
    29ca:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29ce:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    29d2:	2501                	sext.w	a0,a0
    29d4:	8082                	ret

00000000000029d6 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    29d6:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    29d8:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    29dc:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    29de:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    29e2:	2501                	sext.w	a0,a0
    29e4:	8082                	ret

00000000000029e6 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    29e6:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    29e8:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    29ec:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    29ee:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    29f2:	2501                	sext.w	a0,a0
    29f4:	8082                	ret

00000000000029f6 <link>:

int link(char *old_path, char *new_path)
{
    29f6:	87aa                	mv	a5,a0
    29f8:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    29fa:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    29fe:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2a02:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2a04:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2a08:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a0a:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2a0e:	2501                	sext.w	a0,a0
    2a10:	8082                	ret

0000000000002a12 <unlink>:

int unlink(char *path)
{
    2a12:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2a14:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2a18:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2a1c:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a1e:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2a22:	2501                	sext.w	a0,a0
    2a24:	8082                	ret

0000000000002a26 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2a26:	00000797          	auipc	a5,0x0
    2a2a:	5ca7b783          	ld	a5,1482(a5) # 2ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2a2e:	439c                	lw	a5,0(a5)
    2a30:	c799                	beqz	a5,2a3e <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2a32:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a36:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2a3a:	2501                	sext.w	a0,a0
    2a3c:	8082                	ret
{
    2a3e:	1101                	addi	sp,sp,-32
    2a40:	ec06                	sd	ra,24(sp)
    2a42:	e42e                	sd	a1,8(sp)
    2a44:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2a46:	fe7fe0ef          	jal	ra,1a2c <enable_thread_io_buffer>
    2a4a:	65a2                	ld	a1,8(sp)
    2a4c:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2a4e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a52:	00000073          	ecall
}
    2a56:	60e2                	ld	ra,24(sp)
    2a58:	2501                	sext.w	a0,a0
    2a5a:	6105                	addi	sp,sp,32
    2a5c:	8082                	ret

0000000000002a5e <gettid>:
	register long a7 __asm__("a7") = n;
    2a5e:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2a62:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2a66:	2501                	sext.w	a0,a0
    2a68:	8082                	ret

0000000000002a6a <waittid>:

int waittid(int tid)
{
    2a6a:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2a6c:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2a70:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2a74:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2a76:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2a78:	00e51e63          	bne	a0,a4,2a94 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2a7c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2a80:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2a84:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2a88:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2a8a:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2a8e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2a90:	fee506e3          	beq	a0,a4,2a7c <waittid+0x12>
	}
	return ret;
}
    2a94:	8082                	ret

0000000000002a96 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2a96:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2a9a:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2a9c:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2aa0:	2501                	sext.w	a0,a0
    2aa2:	8082                	ret

0000000000002aa4 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2aa4:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2aa8:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2aaa:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2aae:	2501                	sext.w	a0,a0
    2ab0:	8082                	ret

0000000000002ab2 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2ab2:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2ab6:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2aba:	2501                	sext.w	a0,a0
    2abc:	8082                	ret

0000000000002abe <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2abe:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2ac2:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2ac6:	2501                	sext.w	a0,a0
    2ac8:	8082                	ret

0000000000002aca <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2aca:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2ace:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2ad2:	2501                	sext.w	a0,a0
    2ad4:	8082                	ret

0000000000002ad6 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2ad6:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2ada:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2ade:	2501                	sext.w	a0,a0
    2ae0:	8082                	ret

0000000000002ae2 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2ae2:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2ae6:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2aea:	2501                	sext.w	a0,a0
    2aec:	8082                	ret

0000000000002aee <condvar_create>:
	register long a7 __asm__("a7") = n;
    2aee:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2af2:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2af6:	2501                	sext.w	a0,a0
    2af8:	8082                	ret

0000000000002afa <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2afa:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2afe:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2b02:	2501                	sext.w	a0,a0
    2b04:	8082                	ret

0000000000002b06 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2b06:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2b0a:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2b0e:	2501                	sext.w	a0,a0
    2b10:	8082                	ret

0000000000002b12 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2b12:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2b16:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2b1a:	2501                	sext.w	a0,a0
    2b1c:	8082                	ret
