
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8_mut1_deadlock:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a8d1                	j	10d4 <__start_main>

0000000000001002 <main>:
/*
理想结果：检测出死锁，第二次 mutex_lock 失败，程序正常结束
*/

int main()
{
    1002:	7179                	addi	sp,sp,-48
	enable_deadlock_detect(1);
    1004:	4505                	li	a0,1
{
    1006:	f406                	sd	ra,40(sp)
    1008:	f022                	sd	s0,32(sp)
    100a:	ec26                	sd	s1,24(sp)
    100c:	e84a                	sd	s2,16(sp)
    100e:	e44e                	sd	s3,8(sp)
	enable_deadlock_detect(1);
    1010:	71e010ef          	jal	ra,272e <enable_deadlock_detect>
	int mutex_id = mutex_create();
    1014:	69e010ef          	jal	ra,26b2 <mutex_create>
    1018:	842a                	mv	s0,a0
	assert_eq(mutex_lock(mutex_id), 0);
    101a:	6b4010ef          	jal	ra,26ce <mutex_lock>
    101e:	e935                	bnez	a0,1092 <main+0x90>
	assert_eq(mutex_lock(mutex_id), -0xdead);
    1020:	8522                	mv	a0,s0
    1022:	74c9                	lui	s1,0xffff2
    1024:	6aa010ef          	jal	ra,26ce <mutex_lock>
    1028:	15348493          	addi	s1,s1,339 # ffffffffffff2153 <.got.plt+0xfffffffffffef733>
    102c:	04950263          	beq	a0,s1,1070 <main+0x6e>
    1030:	430010ef          	jal	ra,2460 <getpid>
    1034:	892a                	mv	s2,a0
    1036:	00001517          	auipc	a0,0x1
    103a:	70a50513          	addi	a0,a0,1802 # 2740 <enable_deadlock_detect+0x12>
    103e:	2f8010ef          	jal	ra,2336 <basename>
    1042:	89aa                	mv	s3,a0
    1044:	8522                	mv	a0,s0
    1046:	688010ef          	jal	ra,26ce <mutex_lock>
    104a:	882a                	mv	a6,a0
    104c:	88a6                	mv	a7,s1
    104e:	00001517          	auipc	a0,0x1
    1052:	74a50513          	addi	a0,a0,1866 # 2798 <enable_deadlock_detect+0x6a>
    1056:	47b9                	li	a5,14
    1058:	874e                	mv	a4,s3
    105a:	86ca                	mv	a3,s2
    105c:	00001617          	auipc	a2,0x1
    1060:	73460613          	addi	a2,a2,1844 # 2790 <enable_deadlock_detect+0x62>
    1064:	45fd                	li	a1,31
    1066:	1c8000ef          	jal	ra,122e <printf>
    106a:	557d                	li	a0,-1
    106c:	424010ef          	jal	ra,2490 <exit>
	mutex_unlock(mutex_id);
    1070:	8522                	mv	a0,s0
    1072:	668010ef          	jal	ra,26da <mutex_unlock>
	puts("deadlock test mutex 1 OK!");
    1076:	00001517          	auipc	a0,0x1
    107a:	75a50513          	addi	a0,a0,1882 # 27d0 <enable_deadlock_detect+0xa2>
    107e:	0c7000ef          	jal	ra,1944 <puts>
	return 0;
}
    1082:	70a2                	ld	ra,40(sp)
    1084:	7402                	ld	s0,32(sp)
    1086:	64e2                	ld	s1,24(sp)
    1088:	6942                	ld	s2,16(sp)
    108a:	69a2                	ld	s3,8(sp)
    108c:	4501                	li	a0,0
    108e:	6145                	addi	sp,sp,48
    1090:	8082                	ret
	assert_eq(mutex_lock(mutex_id), 0);
    1092:	3ce010ef          	jal	ra,2460 <getpid>
    1096:	84aa                	mv	s1,a0
    1098:	00001517          	auipc	a0,0x1
    109c:	6a850513          	addi	a0,a0,1704 # 2740 <enable_deadlock_detect+0x12>
    10a0:	296010ef          	jal	ra,2336 <basename>
    10a4:	892a                	mv	s2,a0
    10a6:	8522                	mv	a0,s0
    10a8:	626010ef          	jal	ra,26ce <mutex_lock>
    10ac:	882a                	mv	a6,a0
    10ae:	4881                	li	a7,0
    10b0:	00001517          	auipc	a0,0x1
    10b4:	6e850513          	addi	a0,a0,1768 # 2798 <enable_deadlock_detect+0x6a>
    10b8:	47b5                	li	a5,13
    10ba:	874a                	mv	a4,s2
    10bc:	86a6                	mv	a3,s1
    10be:	00001617          	auipc	a2,0x1
    10c2:	6d260613          	addi	a2,a2,1746 # 2790 <enable_deadlock_detect+0x62>
    10c6:	45fd                	li	a1,31
    10c8:	166000ef          	jal	ra,122e <printf>
    10cc:	557d                	li	a0,-1
    10ce:	3c2010ef          	jal	ra,2490 <exit>
    10d2:	b7b9                	j	1020 <main+0x1e>

00000000000010d4 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    10d4:	1141                	addi	sp,sp,-16
    10d6:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    10d8:	f2bff0ef          	jal	ra,1002 <main>
    10dc:	3b4010ef          	jal	ra,2490 <exit>
	return 0;
    10e0:	60a2                	ld	ra,8(sp)
    10e2:	4501                	li	a0,0
    10e4:	0141                	addi	sp,sp,16
    10e6:	8082                	ret

00000000000010e8 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    10e8:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    10ea:	4605                	li	a2,1
    10ec:	00f10593          	addi	a1,sp,15
    10f0:	4501                	li	a0,0
{
    10f2:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10f4:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10f8:	354010ef          	jal	ra,244c <read>
    10fc:	4785                	li	a5,1
    10fe:	00f51763          	bne	a0,a5,110c <getchar+0x24>
		return byte;
    1102:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1106:	60e2                	ld	ra,24(sp)
    1108:	6105                	addi	sp,sp,32
    110a:	8082                	ret
		return EOF;
    110c:	557d                	li	a0,-1
    110e:	bfe5                	j	1106 <getchar+0x1e>

0000000000001110 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1110:	00001517          	auipc	a0,0x1
    1114:	7d852503          	lw	a0,2008(a0) # 28e8 <buffer_len>
    1118:	e111                	bnez	a0,111c <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    111a:	8082                	ret
{
    111c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    111e:	862a                	mv	a2,a0
    1120:	00001597          	auipc	a1,0x1
    1124:	7d058593          	addi	a1,a1,2000 # 28f0 <buffer>
    1128:	4505                	li	a0,1
{
    112a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    112c:	32a010ef          	jal	ra,2456 <write>
}
    1130:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1132:	2501                	sext.w	a0,a0
}
    1134:	0141                	addi	sp,sp,16
    1136:	8082                	ret

0000000000001138 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1138:	00001797          	auipc	a5,0x1
    113c:	7a07a823          	sw	zero,1968(a5) # 28e8 <buffer_len>
}
    1140:	8082                	ret

0000000000001142 <__fflush>:
	if (buffer_len == 0)
    1142:	00001517          	auipc	a0,0x1
    1146:	7a652503          	lw	a0,1958(a0) # 28e8 <buffer_len>
    114a:	e511                	bnez	a0,1156 <__fflush+0x14>
	buffer_len = 0;
    114c:	00001797          	auipc	a5,0x1
    1150:	7807ae23          	sw	zero,1948(a5) # 28e8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1154:	8082                	ret
{
    1156:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1158:	862a                	mv	a2,a0
    115a:	00001597          	auipc	a1,0x1
    115e:	79658593          	addi	a1,a1,1942 # 28f0 <buffer>
    1162:	4505                	li	a0,1
{
    1164:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1166:	2f0010ef          	jal	ra,2456 <write>
	return r >= 0 ? 0 : r;
    116a:	0005079b          	sext.w	a5,a0
}
    116e:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1170:	0017a793          	slti	a5,a5,1
    1174:	40f007bb          	negw	a5,a5
    1178:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    117a:	00001797          	auipc	a5,0x1
    117e:	7607a723          	sw	zero,1902(a5) # 28e8 <buffer_len>
	return r >= 0 ? 0 : r;
    1182:	2501                	sext.w	a0,a0
}
    1184:	0141                	addi	sp,sp,16
    1186:	8082                	ret

0000000000001188 <fflush>:

int fflush(int fd)
{
    1188:	1101                	addi	sp,sp,-32
    118a:	e822                	sd	s0,16(sp)
    118c:	ec06                	sd	ra,24(sp)
    118e:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1190:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1192:	4401                	li	s0,0
	if (fd == 1) {
    1194:	00e50863          	beq	a0,a4,11a4 <fflush+0x1c>
}
    1198:	60e2                	ld	ra,24(sp)
    119a:	8522                	mv	a0,s0
    119c:	6442                	ld	s0,16(sp)
    119e:	64a2                	ld	s1,8(sp)
    11a0:	6105                	addi	sp,sp,32
    11a2:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11a4:	00001497          	auipc	s1,0x1
    11a8:	74448493          	addi	s1,s1,1860 # 28e8 <buffer_len>
    11ac:	1084a703          	lw	a4,264(s1)
    11b0:	02a70e63          	beq	a4,a0,11ec <fflush+0x64>
	if (buffer_len == 0)
    11b4:	4080                	lw	s0,0(s1)
    11b6:	c00d                	beqz	s0,11d8 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11b8:	8622                	mv	a2,s0
    11ba:	00001597          	auipc	a1,0x1
    11be:	73658593          	addi	a1,a1,1846 # 28f0 <buffer>
    11c2:	294010ef          	jal	ra,2456 <write>
	return r >= 0 ? 0 : r;
    11c6:	0005079b          	sext.w	a5,a0
    11ca:	0017a793          	slti	a5,a5,1
    11ce:	40f007bb          	negw	a5,a5
    11d2:	8d7d                	and	a0,a0,a5
    11d4:	0005041b          	sext.w	s0,a0
}
    11d8:	60e2                	ld	ra,24(sp)
    11da:	8522                	mv	a0,s0
    11dc:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    11de:	00001797          	auipc	a5,0x1
    11e2:	7007a523          	sw	zero,1802(a5) # 28e8 <buffer_len>
}
    11e6:	64a2                	ld	s1,8(sp)
    11e8:	6105                	addi	sp,sp,32
    11ea:	8082                	ret
			mutex_lock(buffer_lock);
    11ec:	10c4a503          	lw	a0,268(s1)
    11f0:	4de010ef          	jal	ra,26ce <mutex_lock>
	if (buffer_len == 0)
    11f4:	4080                	lw	s0,0(s1)
    11f6:	e811                	bnez	s0,120a <fflush+0x82>
			mutex_unlock(buffer_lock);
    11f8:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11fc:	00001797          	auipc	a5,0x1
    1200:	6e07a623          	sw	zero,1772(a5) # 28e8 <buffer_len>
			mutex_unlock(buffer_lock);
    1204:	4d6010ef          	jal	ra,26da <mutex_unlock>
    1208:	bf41                	j	1198 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    120a:	8622                	mv	a2,s0
    120c:	00001597          	auipc	a1,0x1
    1210:	6e458593          	addi	a1,a1,1764 # 28f0 <buffer>
    1214:	4505                	li	a0,1
    1216:	240010ef          	jal	ra,2456 <write>
	return r >= 0 ? 0 : r;
    121a:	0005079b          	sext.w	a5,a0
    121e:	0017a793          	slti	a5,a5,1
    1222:	40f007bb          	negw	a5,a5
    1226:	8d7d                	and	a0,a0,a5
    1228:	0005041b          	sext.w	s0,a0
	return r;
    122c:	b7f1                	j	11f8 <fflush+0x70>

000000000000122e <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    122e:	7131                	addi	sp,sp,-192
    1230:	e0da                	sd	s6,64(sp)
    1232:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1234:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1236:	013c                	addi	a5,sp,136
{
    1238:	f0ca                	sd	s2,96(sp)
    123a:	ecce                	sd	s3,88(sp)
    123c:	e8d2                	sd	s4,80(sp)
    123e:	e4d6                	sd	s5,72(sp)
    1240:	fc86                	sd	ra,120(sp)
    1242:	f8a2                	sd	s0,112(sp)
    1244:	f4a6                	sd	s1,104(sp)
    1246:	89aa                	mv	s3,a0
    1248:	e52e                	sd	a1,136(sp)
    124a:	e932                	sd	a2,144(sp)
    124c:	ed36                	sd	a3,152(sp)
    124e:	f13a                	sd	a4,160(sp)
    1250:	f942                	sd	a6,176(sp)
    1252:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1254:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1256:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    125a:	00001a17          	auipc	s4,0x1
    125e:	68ea0a13          	addi	s4,s4,1678 # 28e8 <buffer_len>
    1262:	4a85                	li	s5,1
	buf[i++] = '0';
    1264:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1268:	0009c783          	lbu	a5,0(s3)
    126c:	18078663          	beqz	a5,13f8 <printf+0x1ca>
    1270:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1272:	19278d63          	beq	a5,s2,140c <printf+0x1de>
    1276:	0015c783          	lbu	a5,1(a1)
    127a:	0585                	addi	a1,a1,1
    127c:	fbfd                	bnez	a5,1272 <printf+0x44>
    127e:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1280:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1284:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1288:	1b578863          	beq	a5,s5,1438 <printf+0x20a>
		len = out_unlocked(s, l);
    128c:	85a2                	mv	a1,s0
    128e:	854e                	mv	a0,s3
    1290:	42a000ef          	jal	ra,16ba <out_unlocked>
		out(f, a, l);
		if (l)
    1294:	1c041063          	bnez	s0,1454 <printf+0x226>
			continue;
		if (s[1] == 0)
    1298:	0014c783          	lbu	a5,1(s1)
    129c:	14078e63          	beqz	a5,13f8 <printf+0x1ca>
			break;
		switch (s[1]) {
    12a0:	07300713          	li	a4,115
    12a4:	1ce78863          	beq	a5,a4,1474 <printf+0x246>
    12a8:	1af76863          	bltu	a4,a5,1458 <printf+0x22a>
    12ac:	06400713          	li	a4,100
    12b0:	22e78063          	beq	a5,a4,14d0 <printf+0x2a2>
    12b4:	07000713          	li	a4,112
    12b8:	1ee79563          	bne	a5,a4,14a2 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12bc:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12be:	00001797          	auipc	a5,0x1
    12c2:	73a78793          	addi	a5,a5,1850 # 29f8 <digits>
	buf[i++] = '0';
    12c6:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12ca:	6298                	ld	a4,0(a3)
    12cc:	06a1                	addi	a3,a3,8
    12ce:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12d0:	00471393          	slli	t2,a4,0x4
    12d4:	00871293          	slli	t0,a4,0x8
    12d8:	00c71f93          	slli	t6,a4,0xc
    12dc:	01071f13          	slli	t5,a4,0x10
    12e0:	01471e93          	slli	t4,a4,0x14
    12e4:	01871e13          	slli	t3,a4,0x18
    12e8:	01c71893          	slli	a7,a4,0x1c
    12ec:	02471813          	slli	a6,a4,0x24
    12f0:	02871513          	slli	a0,a4,0x28
    12f4:	02c71593          	slli	a1,a4,0x2c
    12f8:	03071613          	slli	a2,a4,0x30
    12fc:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1300:	03c75413          	srli	s0,a4,0x3c
    1304:	01c7531b          	srliw	t1,a4,0x1c
    1308:	03c3d393          	srli	t2,t2,0x3c
    130c:	03c2d293          	srli	t0,t0,0x3c
    1310:	03cfdf93          	srli	t6,t6,0x3c
    1314:	03cf5f13          	srli	t5,t5,0x3c
    1318:	03cede93          	srli	t4,t4,0x3c
    131c:	03ce5e13          	srli	t3,t3,0x3c
    1320:	03c8d893          	srli	a7,a7,0x3c
    1324:	03c85813          	srli	a6,a6,0x3c
    1328:	9171                	srli	a0,a0,0x3c
    132a:	91f1                	srli	a1,a1,0x3c
    132c:	9271                	srli	a2,a2,0x3c
    132e:	92f1                	srli	a3,a3,0x3c
    1330:	95be                	add	a1,a1,a5
    1332:	963e                	add	a2,a2,a5
    1334:	96be                	add	a3,a3,a5
    1336:	943e                	add	s0,s0,a5
    1338:	93be                	add	t2,t2,a5
    133a:	92be                	add	t0,t0,a5
    133c:	9fbe                	add	t6,t6,a5
    133e:	9f3e                	add	t5,t5,a5
    1340:	9ebe                	add	t4,t4,a5
    1342:	9e3e                	add	t3,t3,a5
    1344:	98be                	add	a7,a7,a5
    1346:	933e                	add	t1,t1,a5
    1348:	983e                	add	a6,a6,a5
    134a:	953e                	add	a0,a0,a5
    134c:	0005c983          	lbu	s3,0(a1)
    1350:	00044403          	lbu	s0,0(s0)
    1354:	00064583          	lbu	a1,0(a2)
    1358:	0003c383          	lbu	t2,0(t2)
    135c:	0006c603          	lbu	a2,0(a3)
    1360:	0002c283          	lbu	t0,0(t0)
    1364:	000fcf83          	lbu	t6,0(t6)
    1368:	000f4f03          	lbu	t5,0(t5)
    136c:	000ece83          	lbu	t4,0(t4)
    1370:	000e4e03          	lbu	t3,0(t3)
    1374:	0008c883          	lbu	a7,0(a7)
    1378:	00034303          	lbu	t1,0(t1)
    137c:	00084803          	lbu	a6,0(a6)
    1380:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1384:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1388:	92f1                	srli	a3,a3,0x3c
    138a:	8b3d                	andi	a4,a4,15
    138c:	96be                	add	a3,a3,a5
    138e:	97ba                	add	a5,a5,a4
    1390:	00810d23          	sb	s0,26(sp)
    1394:	00710da3          	sb	t2,27(sp)
    1398:	00510e23          	sb	t0,28(sp)
    139c:	01f10ea3          	sb	t6,29(sp)
    13a0:	01e10f23          	sb	t5,30(sp)
    13a4:	01d10fa3          	sb	t4,31(sp)
    13a8:	03c10023          	sb	t3,32(sp)
    13ac:	031100a3          	sb	a7,33(sp)
    13b0:	02610123          	sb	t1,34(sp)
    13b4:	030101a3          	sb	a6,35(sp)
    13b8:	02a10223          	sb	a0,36(sp)
    13bc:	033102a3          	sb	s3,37(sp)
    13c0:	02b10323          	sb	a1,38(sp)
    13c4:	02c103a3          	sb	a2,39(sp)
    13c8:	0006c683          	lbu	a3,0(a3)
    13cc:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    13d0:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13d4:	02d10423          	sb	a3,40(sp)
    13d8:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    13dc:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    13e0:	11578263          	beq	a5,s5,14e4 <printf+0x2b6>
		len = out_unlocked(s, l);
    13e4:	45c9                	li	a1,18
    13e6:	0828                	addi	a0,sp,24
    13e8:	2d2000ef          	jal	ra,16ba <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13ec:	00248993          	addi	s3,s1,2
		if (!*s)
    13f0:	0009c783          	lbu	a5,0(s3)
    13f4:	e6079ee3          	bnez	a5,1270 <printf+0x42>
	}
	va_end(ap);
    13f8:	70e6                	ld	ra,120(sp)
    13fa:	7446                	ld	s0,112(sp)
    13fc:	74a6                	ld	s1,104(sp)
    13fe:	7906                	ld	s2,96(sp)
    1400:	69e6                	ld	s3,88(sp)
    1402:	6a46                	ld	s4,80(sp)
    1404:	6aa6                	ld	s5,72(sp)
    1406:	6b06                	ld	s6,64(sp)
    1408:	6129                	addi	sp,sp,192
    140a:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    140c:	0005c783          	lbu	a5,0(a1)
    1410:	84ae                	mv	s1,a1
    1412:	01278963          	beq	a5,s2,1424 <printf+0x1f6>
    1416:	b5ad                	j	1280 <printf+0x52>
    1418:	0024c783          	lbu	a5,2(s1)
    141c:	0585                	addi	a1,a1,1
    141e:	0489                	addi	s1,s1,2
    1420:	e72790e3          	bne	a5,s2,1280 <printf+0x52>
    1424:	0014c783          	lbu	a5,1(s1)
    1428:	ff2788e3          	beq	a5,s2,1418 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    142c:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1430:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1434:	e5579ce3          	bne	a5,s5,128c <printf+0x5e>
		mutex_lock(buffer_lock);
    1438:	10ca2503          	lw	a0,268(s4)
    143c:	292010ef          	jal	ra,26ce <mutex_lock>
		len = out_unlocked(s, l);
    1440:	85a2                	mv	a1,s0
    1442:	854e                	mv	a0,s3
    1444:	276000ef          	jal	ra,16ba <out_unlocked>
		mutex_unlock(buffer_lock);
    1448:	10ca2503          	lw	a0,268(s4)
    144c:	28e010ef          	jal	ra,26da <mutex_unlock>
		if (l)
    1450:	e40404e3          	beqz	s0,1298 <printf+0x6a>
    1454:	89a6                	mv	s3,s1
    1456:	bd09                	j	1268 <printf+0x3a>
		switch (s[1]) {
    1458:	07800713          	li	a4,120
    145c:	04e79363          	bne	a5,a4,14a2 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1460:	67c2                	ld	a5,16(sp)
    1462:	45c1                	li	a1,16
		s += 2;
    1464:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1468:	4388                	lw	a0,0(a5)
    146a:	07a1                	addi	a5,a5,8
    146c:	e83e                	sd	a5,16(sp)
    146e:	5f8000ef          	jal	ra,1a66 <printint.constprop.0>
		s += 2;
    1472:	bfbd                	j	13f0 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1474:	67c2                	ld	a5,16(sp)
    1476:	6380                	ld	s0,0(a5)
    1478:	07a1                	addi	a5,a5,8
    147a:	e83e                	sd	a5,16(sp)
    147c:	1c040163          	beqz	s0,163e <printf+0x410>
			l = strnlen(a, 200);
    1480:	0c800593          	li	a1,200
    1484:	8522                	mv	a0,s0
    1486:	3f7000ef          	jal	ra,207c <strnlen>
	if (buffer_lock_enabled == 1) {
    148a:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    148e:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1492:	19578663          	beq	a5,s5,161e <printf+0x3f0>
		len = out_unlocked(s, l);
    1496:	8522                	mv	a0,s0
    1498:	222000ef          	jal	ra,16ba <out_unlocked>
		s += 2;
    149c:	00248993          	addi	s3,s1,2
    14a0:	bf81                	j	13f0 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    14a2:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14a6:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14aa:	0f578663          	beq	a5,s5,1596 <printf+0x368>
		len = out_unlocked(s, l);
    14ae:	0828                	addi	a0,sp,24
    14b0:	316000ef          	jal	ra,17c6 <out_unlocked.constprop.0>
			putchar(s[1]);
    14b4:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14b8:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14bc:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14c0:	05578163          	beq	a5,s5,1502 <printf+0x2d4>
		len = out_unlocked(s, l);
    14c4:	0828                	addi	a0,sp,24
    14c6:	300000ef          	jal	ra,17c6 <out_unlocked.constprop.0>
		s += 2;
    14ca:	00248993          	addi	s3,s1,2
    14ce:	b70d                	j	13f0 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    14d0:	67c2                	ld	a5,16(sp)
    14d2:	45a9                	li	a1,10
		s += 2;
    14d4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    14d8:	4388                	lw	a0,0(a5)
    14da:	07a1                	addi	a5,a5,8
    14dc:	e83e                	sd	a5,16(sp)
    14de:	588000ef          	jal	ra,1a66 <printint.constprop.0>
		s += 2;
    14e2:	b739                	j	13f0 <printf+0x1c2>
		mutex_lock(buffer_lock);
    14e4:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14e8:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14ec:	1e2010ef          	jal	ra,26ce <mutex_lock>
		len = out_unlocked(s, l);
    14f0:	45c9                	li	a1,18
    14f2:	0828                	addi	a0,sp,24
    14f4:	1c6000ef          	jal	ra,16ba <out_unlocked>
		mutex_unlock(buffer_lock);
    14f8:	10ca2503          	lw	a0,268(s4)
    14fc:	1de010ef          	jal	ra,26da <mutex_unlock>
		s += 2;
    1500:	bdc5                	j	13f0 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1502:	10ca2503          	lw	a0,268(s4)
    1506:	1c8010ef          	jal	ra,26ce <mutex_lock>
		buffer[buffer_len++] = c;
    150a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    150e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1512:	0017861b          	addiw	a2,a5,1
    1516:	97d2                	add	a5,a5,s4
    1518:	00ca2023          	sw	a2,0(s4)
    151c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1520:	00c6cc63          	blt	a3,a2,1538 <printf+0x30a>
    1524:	47a9                	li	a5,10
    1526:	06f40663          	beq	s0,a5,1592 <printf+0x364>
		mutex_unlock(buffer_lock);
    152a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    152e:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1532:	1a8010ef          	jal	ra,26da <mutex_unlock>
		s += 2;
    1536:	bd6d                	j	13f0 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1538:	10000793          	li	a5,256
    153c:	00f61e63          	bne	a2,a5,1558 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1540:	00001597          	auipc	a1,0x1
    1544:	3b058593          	addi	a1,a1,944 # 28f0 <buffer>
    1548:	4505                	li	a0,1
    154a:	70d000ef          	jal	ra,2456 <write>
	buffer_len = 0;
    154e:	00001797          	auipc	a5,0x1
    1552:	3807ad23          	sw	zero,922(a5) # 28e8 <buffer_len>
			if (r < 0) {
    1556:	bfd1                	j	152a <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1558:	709000ef          	jal	ra,2460 <getpid>
    155c:	842a                	mv	s0,a0
    155e:	00001517          	auipc	a0,0x1
    1562:	29a50513          	addi	a0,a0,666 # 27f8 <enable_deadlock_detect+0xca>
    1566:	5d1000ef          	jal	ra,2336 <basename>
    156a:	872a                	mv	a4,a0
    156c:	00001617          	auipc	a2,0x1
    1570:	22460613          	addi	a2,a2,548 # 2790 <enable_deadlock_detect+0x62>
    1574:	05400793          	li	a5,84
    1578:	86a2                	mv	a3,s0
    157a:	45fd                	li	a1,31
    157c:	00001517          	auipc	a0,0x1
    1580:	2bc50513          	addi	a0,a0,700 # 2838 <enable_deadlock_detect+0x10a>
    1584:	cabff0ef          	jal	ra,122e <printf>
    1588:	557d                	li	a0,-1
    158a:	707000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    158e:	000a2603          	lw	a2,0(s4)
    1592:	de41                	beqz	a2,152a <printf+0x2fc>
    1594:	b775                	j	1540 <printf+0x312>
		mutex_lock(buffer_lock);
    1596:	10ca2503          	lw	a0,268(s4)
    159a:	134010ef          	jal	ra,26ce <mutex_lock>
		buffer[buffer_len++] = c;
    159e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15a2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15a6:	0017861b          	addiw	a2,a5,1
    15aa:	97d2                	add	a5,a5,s4
    15ac:	00ca2023          	sw	a2,0(s4)
    15b0:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15b4:	02c6d163          	bge	a3,a2,15d6 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15b8:	10000793          	li	a5,256
    15bc:	02f61263          	bne	a2,a5,15e0 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15c0:	00001597          	auipc	a1,0x1
    15c4:	33058593          	addi	a1,a1,816 # 28f0 <buffer>
    15c8:	4505                	li	a0,1
    15ca:	68d000ef          	jal	ra,2456 <write>
	buffer_len = 0;
    15ce:	00001797          	auipc	a5,0x1
    15d2:	3007ad23          	sw	zero,794(a5) # 28e8 <buffer_len>
		mutex_unlock(buffer_lock);
    15d6:	10ca2503          	lw	a0,268(s4)
    15da:	100010ef          	jal	ra,26da <mutex_unlock>
    15de:	bdd9                	j	14b4 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    15e0:	681000ef          	jal	ra,2460 <getpid>
    15e4:	842a                	mv	s0,a0
    15e6:	00001517          	auipc	a0,0x1
    15ea:	21250513          	addi	a0,a0,530 # 27f8 <enable_deadlock_detect+0xca>
    15ee:	549000ef          	jal	ra,2336 <basename>
    15f2:	872a                	mv	a4,a0
    15f4:	00001617          	auipc	a2,0x1
    15f8:	19c60613          	addi	a2,a2,412 # 2790 <enable_deadlock_detect+0x62>
    15fc:	05400793          	li	a5,84
    1600:	86a2                	mv	a3,s0
    1602:	45fd                	li	a1,31
    1604:	00001517          	auipc	a0,0x1
    1608:	23450513          	addi	a0,a0,564 # 2838 <enable_deadlock_detect+0x10a>
    160c:	c23ff0ef          	jal	ra,122e <printf>
    1610:	557d                	li	a0,-1
    1612:	67f000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    1616:	000a2603          	lw	a2,0(s4)
    161a:	de55                	beqz	a2,15d6 <printf+0x3a8>
    161c:	b755                	j	15c0 <printf+0x392>
		mutex_lock(buffer_lock);
    161e:	10ca2503          	lw	a0,268(s4)
    1622:	e42e                	sd	a1,8(sp)
		s += 2;
    1624:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1628:	0a6010ef          	jal	ra,26ce <mutex_lock>
		len = out_unlocked(s, l);
    162c:	65a2                	ld	a1,8(sp)
    162e:	8522                	mv	a0,s0
    1630:	08a000ef          	jal	ra,16ba <out_unlocked>
		mutex_unlock(buffer_lock);
    1634:	10ca2503          	lw	a0,268(s4)
    1638:	0a2010ef          	jal	ra,26da <mutex_unlock>
		s += 2;
    163c:	bb55                	j	13f0 <printf+0x1c2>
				a = "(null)";
    163e:	00001417          	auipc	s0,0x1
    1642:	1b240413          	addi	s0,s0,434 # 27f0 <enable_deadlock_detect+0xc2>
    1646:	bd2d                	j	1480 <printf+0x252>

0000000000001648 <enable_thread_io_buffer>:
{
    1648:	1101                	addi	sp,sp,-32
    164a:	e822                	sd	s0,16(sp)
    164c:	ec06                	sd	ra,24(sp)
    164e:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1650:	00001417          	auipc	s0,0x1
    1654:	29840413          	addi	s0,s0,664 # 28e8 <buffer_len>
    1658:	05a010ef          	jal	ra,26b2 <mutex_create>
    165c:	10a42623          	sw	a0,268(s0)
    1660:	00054a63          	bltz	a0,1674 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1664:	4785                	li	a5,1
}
    1666:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1668:	10f42423          	sw	a5,264(s0)
}
    166c:	6442                	ld	s0,16(sp)
    166e:	64a2                	ld	s1,8(sp)
    1670:	6105                	addi	sp,sp,32
    1672:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1674:	5ed000ef          	jal	ra,2460 <getpid>
    1678:	84aa                	mv	s1,a0
    167a:	00001517          	auipc	a0,0x1
    167e:	17e50513          	addi	a0,a0,382 # 27f8 <enable_deadlock_detect+0xca>
    1682:	4b5000ef          	jal	ra,2336 <basename>
    1686:	872a                	mv	a4,a0
    1688:	04800793          	li	a5,72
    168c:	86a6                	mv	a3,s1
    168e:	00001517          	auipc	a0,0x1
    1692:	1ea50513          	addi	a0,a0,490 # 2878 <enable_deadlock_detect+0x14a>
    1696:	00001617          	auipc	a2,0x1
    169a:	0fa60613          	addi	a2,a2,250 # 2790 <enable_deadlock_detect+0x62>
    169e:	45fd                	li	a1,31
    16a0:	b8fff0ef          	jal	ra,122e <printf>
    16a4:	557d                	li	a0,-1
    16a6:	5eb000ef          	jal	ra,2490 <exit>
	buffer_lock_enabled = 1;
    16aa:	4785                	li	a5,1
}
    16ac:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16ae:	10f42423          	sw	a5,264(s0)
}
    16b2:	6442                	ld	s0,16(sp)
    16b4:	64a2                	ld	s1,8(sp)
    16b6:	6105                	addi	sp,sp,32
    16b8:	8082                	ret

00000000000016ba <out_unlocked>:
{
    16ba:	7159                	addi	sp,sp,-112
    16bc:	f486                	sd	ra,104(sp)
    16be:	f0a2                	sd	s0,96(sp)
    16c0:	eca6                	sd	s1,88(sp)
    16c2:	e8ca                	sd	s2,80(sp)
    16c4:	e4ce                	sd	s3,72(sp)
    16c6:	e0d2                	sd	s4,64(sp)
    16c8:	fc56                	sd	s5,56(sp)
    16ca:	f85a                	sd	s6,48(sp)
    16cc:	f45e                	sd	s7,40(sp)
    16ce:	f062                	sd	s8,32(sp)
    16d0:	ec66                	sd	s9,24(sp)
    16d2:	e86a                	sd	s10,16(sp)
    16d4:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    16d6:	0e058663          	beqz	a1,17c2 <out_unlocked+0x108>
    16da:	842a                	mv	s0,a0
    16dc:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    16e0:	4981                	li	s3,0
    16e2:	00001d17          	auipc	s10,0x1
    16e6:	206d0d13          	addi	s10,s10,518 # 28e8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ea:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16ee:	00001b17          	auipc	s6,0x1
    16f2:	202b0b13          	addi	s6,s6,514 # 28f0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16f6:	10000a93          	li	s5,256
    16fa:	00001c97          	auipc	s9,0x1
    16fe:	0fec8c93          	addi	s9,s9,254 # 27f8 <enable_deadlock_detect+0xca>
    1702:	00001c17          	auipc	s8,0x1
    1706:	08ec0c13          	addi	s8,s8,142 # 2790 <enable_deadlock_detect+0x62>
    170a:	00001b97          	auipc	s7,0x1
    170e:	12eb8b93          	addi	s7,s7,302 # 2838 <enable_deadlock_detect+0x10a>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1712:	4a29                	li	s4,10
    1714:	a031                	j	1720 <out_unlocked+0x66>
    1716:	09468863          	beq	a3,s4,17a6 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    171a:	0405                	addi	s0,s0,1
    171c:	04848163          	beq	s1,s0,175e <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1720:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1724:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1728:	0017861b          	addiw	a2,a5,1
    172c:	97ea                	add	a5,a5,s10
    172e:	00cd2023          	sw	a2,0(s10)
    1732:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1736:	fec950e3          	bge	s2,a2,1716 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    173a:	05561263          	bne	a2,s5,177e <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    173e:	85da                	mv	a1,s6
    1740:	4505                	li	a0,1
    1742:	515000ef          	jal	ra,2456 <write>
    1746:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1748:	00001797          	auipc	a5,0x1
    174c:	1a07a023          	sw	zero,416(a5) # 28e8 <buffer_len>
			if (r < 0) {
    1750:	06054763          	bltz	a0,17be <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1754:	0405                	addi	s0,s0,1
			ret += r;
    1756:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    175a:	fc8493e3          	bne	s1,s0,1720 <out_unlocked+0x66>
}
    175e:	70a6                	ld	ra,104(sp)
    1760:	7406                	ld	s0,96(sp)
    1762:	64e6                	ld	s1,88(sp)
    1764:	6946                	ld	s2,80(sp)
    1766:	6a06                	ld	s4,64(sp)
    1768:	7ae2                	ld	s5,56(sp)
    176a:	7b42                	ld	s6,48(sp)
    176c:	7ba2                	ld	s7,40(sp)
    176e:	7c02                	ld	s8,32(sp)
    1770:	6ce2                	ld	s9,24(sp)
    1772:	6d42                	ld	s10,16(sp)
    1774:	6da2                	ld	s11,8(sp)
    1776:	854e                	mv	a0,s3
    1778:	69a6                	ld	s3,72(sp)
    177a:	6165                	addi	sp,sp,112
    177c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    177e:	4e3000ef          	jal	ra,2460 <getpid>
    1782:	8daa                	mv	s11,a0
    1784:	8566                	mv	a0,s9
    1786:	3b1000ef          	jal	ra,2336 <basename>
    178a:	872a                	mv	a4,a0
    178c:	8662                	mv	a2,s8
    178e:	05400793          	li	a5,84
    1792:	86ee                	mv	a3,s11
    1794:	45fd                	li	a1,31
    1796:	855e                	mv	a0,s7
    1798:	a97ff0ef          	jal	ra,122e <printf>
    179c:	557d                	li	a0,-1
    179e:	4f3000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    17a2:	000d2603          	lw	a2,0(s10)
    17a6:	da35                	beqz	a2,171a <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17a8:	85da                	mv	a1,s6
    17aa:	4505                	li	a0,1
    17ac:	4ab000ef          	jal	ra,2456 <write>
    17b0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17b2:	00001797          	auipc	a5,0x1
    17b6:	1207ab23          	sw	zero,310(a5) # 28e8 <buffer_len>
			if (r < 0) {
    17ba:	f8055de3          	bgez	a0,1754 <out_unlocked+0x9a>
    17be:	89aa                	mv	s3,a0
    17c0:	bf79                	j	175e <out_unlocked+0xa4>
	int ret = 0;
    17c2:	4981                	li	s3,0
    17c4:	bf69                	j	175e <out_unlocked+0xa4>

00000000000017c6 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17c6:	1101                	addi	sp,sp,-32
    17c8:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17ca:	00001497          	auipc	s1,0x1
    17ce:	11e48493          	addi	s1,s1,286 # 28e8 <buffer_len>
    17d2:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    17d4:	ec06                	sd	ra,24(sp)
    17d6:	e822                	sd	s0,16(sp)
		char c = s[i];
    17d8:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    17dc:	0017861b          	addiw	a2,a5,1
    17e0:	97a6                	add	a5,a5,s1
    17e2:	00e78423          	sb	a4,8(a5)
    17e6:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17e8:	0ff00793          	li	a5,255
    17ec:	00c7cc63          	blt	a5,a2,1804 <out_unlocked.constprop.0+0x3e>
    17f0:	47a9                	li	a5,10
    17f2:	06f70c63          	beq	a4,a5,186a <out_unlocked.constprop.0+0xa4>
    17f6:	4601                	li	a2,0
}
    17f8:	60e2                	ld	ra,24(sp)
    17fa:	6442                	ld	s0,16(sp)
    17fc:	64a2                	ld	s1,8(sp)
    17fe:	8532                	mv	a0,a2
    1800:	6105                	addi	sp,sp,32
    1802:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1804:	10000793          	li	a5,256
    1808:	02f61563          	bne	a2,a5,1832 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    180c:	00001597          	auipc	a1,0x1
    1810:	0e458593          	addi	a1,a1,228 # 28f0 <buffer>
    1814:	4505                	li	a0,1
    1816:	441000ef          	jal	ra,2456 <write>
}
    181a:	60e2                	ld	ra,24(sp)
    181c:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    181e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1822:	00001797          	auipc	a5,0x1
    1826:	0c07a323          	sw	zero,198(a5) # 28e8 <buffer_len>
}
    182a:	64a2                	ld	s1,8(sp)
    182c:	8532                	mv	a0,a2
    182e:	6105                	addi	sp,sp,32
    1830:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1832:	42f000ef          	jal	ra,2460 <getpid>
    1836:	842a                	mv	s0,a0
    1838:	00001517          	auipc	a0,0x1
    183c:	fc050513          	addi	a0,a0,-64 # 27f8 <enable_deadlock_detect+0xca>
    1840:	2f7000ef          	jal	ra,2336 <basename>
    1844:	872a                	mv	a4,a0
    1846:	00001617          	auipc	a2,0x1
    184a:	f4a60613          	addi	a2,a2,-182 # 2790 <enable_deadlock_detect+0x62>
    184e:	05400793          	li	a5,84
    1852:	86a2                	mv	a3,s0
    1854:	45fd                	li	a1,31
    1856:	00001517          	auipc	a0,0x1
    185a:	fe250513          	addi	a0,a0,-30 # 2838 <enable_deadlock_detect+0x10a>
    185e:	9d1ff0ef          	jal	ra,122e <printf>
    1862:	557d                	li	a0,-1
    1864:	42d000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    1868:	4090                	lw	a2,0(s1)
    186a:	d659                	beqz	a2,17f8 <out_unlocked.constprop.0+0x32>
    186c:	b745                	j	180c <out_unlocked.constprop.0+0x46>

000000000000186e <putchar>:
{
    186e:	7139                	addi	sp,sp,-64
    1870:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1872:	00001497          	auipc	s1,0x1
    1876:	07648493          	addi	s1,s1,118 # 28e8 <buffer_len>
    187a:	1084a703          	lw	a4,264(s1)
{
    187e:	f822                	sd	s0,48(sp)
	char byte = c;
    1880:	0ff57413          	zext.b	s0,a0
{
    1884:	fc06                	sd	ra,56(sp)
	char byte = c;
    1886:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    188a:	4785                	li	a5,1
    188c:	00f70d63          	beq	a4,a5,18a6 <putchar+0x38>
		len = out_unlocked(s, l);
    1890:	01f10513          	addi	a0,sp,31
    1894:	f33ff0ef          	jal	ra,17c6 <out_unlocked.constprop.0>
}
    1898:	70e2                	ld	ra,56(sp)
    189a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    189c:	862a                	mv	a2,a0
}
    189e:	74a2                	ld	s1,40(sp)
    18a0:	8532                	mv	a0,a2
    18a2:	6121                	addi	sp,sp,64
    18a4:	8082                	ret
		mutex_lock(buffer_lock);
    18a6:	10c4a503          	lw	a0,268(s1)
    18aa:	625000ef          	jal	ra,26ce <mutex_lock>
		buffer[buffer_len++] = c;
    18ae:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18b4:	0017861b          	addiw	a2,a5,1
    18b8:	97a6                	add	a5,a5,s1
    18ba:	c090                	sw	a2,0(s1)
    18bc:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18c0:	02c6c263          	blt	a3,a2,18e4 <putchar+0x76>
    18c4:	47a9                	li	a5,10
    18c6:	06f40d63          	beq	s0,a5,1940 <putchar+0xd2>
    18ca:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18cc:	10c4a503          	lw	a0,268(s1)
    18d0:	e432                	sd	a2,8(sp)
    18d2:	609000ef          	jal	ra,26da <mutex_unlock>
    18d6:	6622                	ld	a2,8(sp)
}
    18d8:	70e2                	ld	ra,56(sp)
    18da:	7442                	ld	s0,48(sp)
    18dc:	74a2                	ld	s1,40(sp)
    18de:	8532                	mv	a0,a2
    18e0:	6121                	addi	sp,sp,64
    18e2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18e4:	10000793          	li	a5,256
    18e8:	02f61063          	bne	a2,a5,1908 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18ec:	00001597          	auipc	a1,0x1
    18f0:	00458593          	addi	a1,a1,4 # 28f0 <buffer>
    18f4:	4505                	li	a0,1
    18f6:	361000ef          	jal	ra,2456 <write>
    18fa:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18fe:	00001797          	auipc	a5,0x1
    1902:	fe07a523          	sw	zero,-22(a5) # 28e8 <buffer_len>
			if (r < 0) {
    1906:	b7d9                	j	18cc <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1908:	359000ef          	jal	ra,2460 <getpid>
    190c:	842a                	mv	s0,a0
    190e:	00001517          	auipc	a0,0x1
    1912:	eea50513          	addi	a0,a0,-278 # 27f8 <enable_deadlock_detect+0xca>
    1916:	221000ef          	jal	ra,2336 <basename>
    191a:	872a                	mv	a4,a0
    191c:	00001617          	auipc	a2,0x1
    1920:	e7460613          	addi	a2,a2,-396 # 2790 <enable_deadlock_detect+0x62>
    1924:	05400793          	li	a5,84
    1928:	86a2                	mv	a3,s0
    192a:	45fd                	li	a1,31
    192c:	00001517          	auipc	a0,0x1
    1930:	f0c50513          	addi	a0,a0,-244 # 2838 <enable_deadlock_detect+0x10a>
    1934:	8fbff0ef          	jal	ra,122e <printf>
    1938:	557d                	li	a0,-1
    193a:	357000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    193e:	4090                	lw	a2,0(s1)
    1940:	d651                	beqz	a2,18cc <putchar+0x5e>
    1942:	b76d                	j	18ec <putchar+0x7e>

0000000000001944 <puts>:
{
    1944:	7139                	addi	sp,sp,-64
    1946:	f822                	sd	s0,48(sp)
    1948:	f426                	sd	s1,40(sp)
    194a:	fc06                	sd	ra,56(sp)
    194c:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    194e:	00001417          	auipc	s0,0x1
    1952:	f9a40413          	addi	s0,s0,-102 # 28e8 <buffer_len>
{
    1956:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1958:	638000ef          	jal	ra,1f90 <strlen>
	if (buffer_lock_enabled == 1) {
    195c:	10842703          	lw	a4,264(s0)
    1960:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1962:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1964:	04f70563          	beq	a4,a5,19ae <puts+0x6a>
		len = out_unlocked(s, l);
    1968:	8526                	mv	a0,s1
    196a:	d51ff0ef          	jal	ra,16ba <out_unlocked>
    196e:	892a                	mv	s2,a0
    1970:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1972:	00095963          	bgez	s2,1984 <puts+0x40>
}
    1976:	70e2                	ld	ra,56(sp)
    1978:	7442                	ld	s0,48(sp)
    197a:	7902                	ld	s2,32(sp)
    197c:	8526                	mv	a0,s1
    197e:	74a2                	ld	s1,40(sp)
    1980:	6121                	addi	sp,sp,64
    1982:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1984:	10842703          	lw	a4,264(s0)
	char byte = c;
    1988:	44a9                	li	s1,10
    198a:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    198e:	4785                	li	a5,1
    1990:	02f70e63          	beq	a4,a5,19cc <puts+0x88>
		len = out_unlocked(s, l);
    1994:	01f10513          	addi	a0,sp,31
    1998:	e2fff0ef          	jal	ra,17c6 <out_unlocked.constprop.0>
}
    199c:	70e2                	ld	ra,56(sp)
    199e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19a0:	41f5549b          	sraiw	s1,a0,0x1f
}
    19a4:	7902                	ld	s2,32(sp)
    19a6:	8526                	mv	a0,s1
    19a8:	74a2                	ld	s1,40(sp)
    19aa:	6121                	addi	sp,sp,64
    19ac:	8082                	ret
		mutex_lock(buffer_lock);
    19ae:	e42a                	sd	a0,8(sp)
    19b0:	10c42503          	lw	a0,268(s0)
    19b4:	51b000ef          	jal	ra,26ce <mutex_lock>
		len = out_unlocked(s, l);
    19b8:	65a2                	ld	a1,8(sp)
    19ba:	8526                	mv	a0,s1
    19bc:	cffff0ef          	jal	ra,16ba <out_unlocked>
    19c0:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19c2:	10c42503          	lw	a0,268(s0)
    19c6:	515000ef          	jal	ra,26da <mutex_unlock>
    19ca:	b75d                	j	1970 <puts+0x2c>
		mutex_lock(buffer_lock);
    19cc:	10c42503          	lw	a0,268(s0)
    19d0:	4ff000ef          	jal	ra,26ce <mutex_lock>
		buffer[buffer_len++] = c;
    19d4:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d6:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19da:	0017861b          	addiw	a2,a5,1
    19de:	97a2                	add	a5,a5,s0
    19e0:	c010                	sw	a2,0(s0)
    19e2:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19e6:	06c6dc63          	bge	a3,a2,1a5e <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    19ea:	10000793          	li	a5,256
    19ee:	02f61c63          	bne	a2,a5,1a26 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19f2:	00001597          	auipc	a1,0x1
    19f6:	efe58593          	addi	a1,a1,-258 # 28f0 <buffer>
    19fa:	4505                	li	a0,1
    19fc:	25b000ef          	jal	ra,2456 <write>
			if (r < 0) {
    1a00:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a02:	00001797          	auipc	a5,0x1
    1a06:	ee07a323          	sw	zero,-282(a5) # 28e8 <buffer_len>
			if (r < 0) {
    1a0a:	04054c63          	bltz	a0,1a62 <puts+0x11e>
			if (r < buffer_len) {
    1a0e:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a10:	10c42503          	lw	a0,268(s0)
    1a14:	4c7000ef          	jal	ra,26da <mutex_unlock>
}
    1a18:	70e2                	ld	ra,56(sp)
    1a1a:	7442                	ld	s0,48(sp)
    1a1c:	7902                	ld	s2,32(sp)
    1a1e:	8526                	mv	a0,s1
    1a20:	74a2                	ld	s1,40(sp)
    1a22:	6121                	addi	sp,sp,64
    1a24:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a26:	23b000ef          	jal	ra,2460 <getpid>
    1a2a:	84aa                	mv	s1,a0
    1a2c:	00001517          	auipc	a0,0x1
    1a30:	dcc50513          	addi	a0,a0,-564 # 27f8 <enable_deadlock_detect+0xca>
    1a34:	103000ef          	jal	ra,2336 <basename>
    1a38:	872a                	mv	a4,a0
    1a3a:	00001617          	auipc	a2,0x1
    1a3e:	d5660613          	addi	a2,a2,-682 # 2790 <enable_deadlock_detect+0x62>
    1a42:	05400793          	li	a5,84
    1a46:	86a6                	mv	a3,s1
    1a48:	45fd                	li	a1,31
    1a4a:	00001517          	auipc	a0,0x1
    1a4e:	dee50513          	addi	a0,a0,-530 # 2838 <enable_deadlock_detect+0x10a>
    1a52:	fdcff0ef          	jal	ra,122e <printf>
    1a56:	557d                	li	a0,-1
    1a58:	239000ef          	jal	ra,2490 <exit>
	if (buffer_len == 0)
    1a5c:	4010                	lw	a2,0(s0)
    1a5e:	da45                	beqz	a2,1a0e <puts+0xca>
    1a60:	bf49                	j	19f2 <puts+0xae>
    1a62:	54fd                	li	s1,-1
    1a64:	b775                	j	1a10 <puts+0xcc>

0000000000001a66 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a66:	715d                	addi	sp,sp,-80
    1a68:	e486                	sd	ra,72(sp)
    1a6a:	e0a2                	sd	s0,64(sp)
    1a6c:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a6e:	14054363          	bltz	a0,1bb4 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a72:	02b577bb          	remuw	a5,a0,a1
    1a76:	00001617          	auipc	a2,0x1
    1a7a:	f8260613          	addi	a2,a2,-126 # 29f8 <digits>
	buf[16] = 0;
    1a7e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a82:	0005871b          	sext.w	a4,a1
    1a86:	1782                	slli	a5,a5,0x20
    1a88:	9381                	srli	a5,a5,0x20
    1a8a:	97b2                	add	a5,a5,a2
    1a8c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a90:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a94:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a98:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a9a:	0eb56763          	bltu	a0,a1,1b88 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a9e:	02e877bb          	remuw	a5,a6,a4
    1aa2:	1782                	slli	a5,a5,0x20
    1aa4:	9381                	srli	a5,a5,0x20
    1aa6:	97b2                	add	a5,a5,a2
    1aa8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1aac:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1ab0:	02f10323          	sb	a5,38(sp)
    1ab4:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ab6:	0ce86963          	bltu	a6,a4,1b88 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aba:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1abe:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1ac2:	1582                	slli	a1,a1,0x20
    1ac4:	9181                	srli	a1,a1,0x20
    1ac6:	95b2                	add	a1,a1,a2
    1ac8:	0005c583          	lbu	a1,0(a1)
    1acc:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1ad0:	0007859b          	sext.w	a1,a5
    1ad4:	16e6e563          	bltu	a3,a4,1c3e <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ad8:	02e7f6bb          	remuw	a3,a5,a4
    1adc:	1682                	slli	a3,a3,0x20
    1ade:	9281                	srli	a3,a3,0x20
    1ae0:	96b2                	add	a3,a3,a2
    1ae2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae6:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1aea:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1aee:	16e5e163          	bltu	a1,a4,1c50 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1af2:	02e876bb          	remuw	a3,a6,a4
    1af6:	1682                	slli	a3,a3,0x20
    1af8:	9281                	srli	a3,a3,0x20
    1afa:	96b2                	add	a3,a3,a2
    1afc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b00:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b04:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b08:	14e86d63          	bltu	a6,a4,1c62 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b0c:	02e5f6bb          	remuw	a3,a1,a4
    1b10:	1682                	slli	a3,a3,0x20
    1b12:	9281                	srli	a3,a3,0x20
    1b14:	96b2                	add	a3,a3,a2
    1b16:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b1a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b1e:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b22:	10e5e563          	bltu	a1,a4,1c2c <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b26:	02e876bb          	remuw	a3,a6,a4
    1b2a:	1682                	slli	a3,a3,0x20
    1b2c:	9281                	srli	a3,a3,0x20
    1b2e:	96b2                	add	a3,a3,a2
    1b30:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b34:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b38:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b3c:	14e86263          	bltu	a6,a4,1c80 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b40:	02e5f6bb          	remuw	a3,a1,a4
    1b44:	1682                	slli	a3,a3,0x20
    1b46:	9281                	srli	a3,a3,0x20
    1b48:	96b2                	add	a3,a3,a2
    1b4a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b4e:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b52:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b56:	14e5e463          	bltu	a1,a4,1c9e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b5a:	02e876bb          	remuw	a3,a6,a4
    1b5e:	1682                	slli	a3,a3,0x20
    1b60:	9281                	srli	a3,a3,0x20
    1b62:	96b2                	add	a3,a3,a2
    1b64:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b68:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b6c:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b70:	14e86063          	bltu	a6,a4,1cb0 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b74:	1782                	slli	a5,a5,0x20
    1b76:	9381                	srli	a5,a5,0x20
    1b78:	97b2                	add	a5,a5,a2
    1b7a:	0007c703          	lbu	a4,0(a5)
    1b7e:	4799                	li	a5,6
    1b80:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b84:	10054763          	bltz	a0,1c92 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b88:	00001497          	auipc	s1,0x1
    1b8c:	d6048493          	addi	s1,s1,-672 # 28e8 <buffer_len>
    1b90:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b94:	0828                	addi	a0,sp,24
    1b96:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b98:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b9a:	00f50433          	add	s0,a0,a5
    1b9e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1ba0:	06e68463          	beq	a3,a4,1c08 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1ba4:	8522                	mv	a0,s0
    1ba6:	b15ff0ef          	jal	ra,16ba <out_unlocked>
}
    1baa:	60a6                	ld	ra,72(sp)
    1bac:	6406                	ld	s0,64(sp)
    1bae:	74e2                	ld	s1,56(sp)
    1bb0:	6161                	addi	sp,sp,80
    1bb2:	8082                	ret
		x = -xx;
    1bb4:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1bb8:	02b877bb          	remuw	a5,a6,a1
    1bbc:	00001617          	auipc	a2,0x1
    1bc0:	e3c60613          	addi	a2,a2,-452 # 29f8 <digits>
	buf[16] = 0;
    1bc4:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bc8:	0005871b          	sext.w	a4,a1
    1bcc:	1782                	slli	a5,a5,0x20
    1bce:	9381                	srli	a5,a5,0x20
    1bd0:	97b2                	add	a5,a5,a2
    1bd2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bd6:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1bda:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1bde:	08b86b63          	bltu	a6,a1,1c74 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1be2:	02e8f7bb          	remuw	a5,a7,a4
    1be6:	1782                	slli	a5,a5,0x20
    1be8:	9381                	srli	a5,a5,0x20
    1bea:	97b2                	add	a5,a5,a2
    1bec:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bf0:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1bf4:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1bf8:	ece8f1e3          	bgeu	a7,a4,1aba <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bfc:	02d00793          	li	a5,45
    1c00:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c04:	47b5                	li	a5,13
    1c06:	b749                	j	1b88 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c08:	10c4a503          	lw	a0,268(s1)
    1c0c:	e42e                	sd	a1,8(sp)
    1c0e:	2c1000ef          	jal	ra,26ce <mutex_lock>
		len = out_unlocked(s, l);
    1c12:	65a2                	ld	a1,8(sp)
    1c14:	8522                	mv	a0,s0
    1c16:	aa5ff0ef          	jal	ra,16ba <out_unlocked>
		mutex_unlock(buffer_lock);
    1c1a:	10c4a503          	lw	a0,268(s1)
    1c1e:	2bd000ef          	jal	ra,26da <mutex_unlock>
}
    1c22:	60a6                	ld	ra,72(sp)
    1c24:	6406                	ld	s0,64(sp)
    1c26:	74e2                	ld	s1,56(sp)
    1c28:	6161                	addi	sp,sp,80
    1c2a:	8082                	ret
		buf[i--] = digits[x % base];
    1c2c:	47a9                	li	a5,10
	if (sign)
    1c2e:	f4055de3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c32:	02d00793          	li	a5,45
    1c36:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c3a:	47a5                	li	a5,9
    1c3c:	b7b1                	j	1b88 <printint.constprop.0+0x122>
    1c3e:	47b5                	li	a5,13
	if (sign)
    1c40:	f40554e3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c44:	02d00793          	li	a5,45
    1c48:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c4c:	47b1                	li	a5,12
    1c4e:	bf2d                	j	1b88 <printint.constprop.0+0x122>
    1c50:	47b1                	li	a5,12
	if (sign)
    1c52:	f2055be3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c56:	02d00793          	li	a5,45
    1c5a:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c5e:	47ad                	li	a5,11
    1c60:	b725                	j	1b88 <printint.constprop.0+0x122>
    1c62:	47ad                	li	a5,11
	if (sign)
    1c64:	f20552e3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c68:	02d00793          	li	a5,45
    1c6c:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c70:	47a9                	li	a5,10
    1c72:	bf19                	j	1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c74:	02d00793          	li	a5,45
    1c78:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c7c:	47b9                	li	a5,14
    1c7e:	b729                	j	1b88 <printint.constprop.0+0x122>
    1c80:	47a5                	li	a5,9
	if (sign)
    1c82:	f00553e3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c86:	02d00793          	li	a5,45
    1c8a:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c8e:	47a1                	li	a5,8
    1c90:	bde5                	j	1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c92:	02d00793          	li	a5,45
    1c96:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c9a:	4795                	li	a5,5
    1c9c:	b5f5                	j	1b88 <printint.constprop.0+0x122>
    1c9e:	47a1                	li	a5,8
	if (sign)
    1ca0:	ee0554e3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca4:	02d00793          	li	a5,45
    1ca8:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1cac:	479d                	li	a5,7
    1cae:	bde9                	j	1b88 <printint.constprop.0+0x122>
    1cb0:	479d                	li	a5,7
	if (sign)
    1cb2:	ec055be3          	bgez	a0,1b88 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb6:	02d00793          	li	a5,45
    1cba:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cbe:	4799                	li	a5,6
    1cc0:	b5e1                	j	1b88 <printint.constprop.0+0x122>

0000000000001cc2 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cc2:	02000793          	li	a5,32
    1cc6:	00f50663          	beq	a0,a5,1cd2 <isspace+0x10>
    1cca:	355d                	addiw	a0,a0,-9
    1ccc:	00553513          	sltiu	a0,a0,5
    1cd0:	8082                	ret
    1cd2:	4505                	li	a0,1
}
    1cd4:	8082                	ret

0000000000001cd6 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1cd6:	fd05051b          	addiw	a0,a0,-48
}
    1cda:	00a53513          	sltiu	a0,a0,10
    1cde:	8082                	ret

0000000000001ce0 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1ce0:	02000613          	li	a2,32
    1ce4:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1ce6:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cea:	ff77869b          	addiw	a3,a5,-9
    1cee:	04c78c63          	beq	a5,a2,1d46 <atoi+0x66>
    1cf2:	0007871b          	sext.w	a4,a5
    1cf6:	04d5f863          	bgeu	a1,a3,1d46 <atoi+0x66>
		s++;
	switch (*s) {
    1cfa:	02b00693          	li	a3,43
    1cfe:	04d78963          	beq	a5,a3,1d50 <atoi+0x70>
    1d02:	02d00693          	li	a3,45
    1d06:	06d78263          	beq	a5,a3,1d6a <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d0a:	fd07061b          	addiw	a2,a4,-48
    1d0e:	47a5                	li	a5,9
    1d10:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d12:	4e01                	li	t3,0
	while (isdigit(*s))
    1d14:	04c7e963          	bltu	a5,a2,1d66 <atoi+0x86>
	int n = 0, neg = 0;
    1d18:	4501                	li	a0,0
	while (isdigit(*s))
    1d1a:	4825                	li	a6,9
    1d1c:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d20:	0025179b          	slliw	a5,a0,0x2
    1d24:	9fa9                	addw	a5,a5,a0
    1d26:	fd07031b          	addiw	t1,a4,-48
    1d2a:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d2e:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d32:	0685                	addi	a3,a3,1
    1d34:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d38:	0006071b          	sext.w	a4,a2
    1d3c:	feb870e3          	bgeu	a6,a1,1d1c <atoi+0x3c>
	return neg ? n : -n;
    1d40:	000e0563          	beqz	t3,1d4a <atoi+0x6a>
}
    1d44:	8082                	ret
		s++;
    1d46:	0505                	addi	a0,a0,1
    1d48:	bf79                	j	1ce6 <atoi+0x6>
	return neg ? n : -n;
    1d4a:	4113053b          	subw	a0,t1,a7
    1d4e:	8082                	ret
	while (isdigit(*s))
    1d50:	00154703          	lbu	a4,1(a0)
    1d54:	47a5                	li	a5,9
		s++;
    1d56:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d5a:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d5e:	4e01                	li	t3,0
	while (isdigit(*s))
    1d60:	2701                	sext.w	a4,a4
    1d62:	fac7fbe3          	bgeu	a5,a2,1d18 <atoi+0x38>
    1d66:	4501                	li	a0,0
}
    1d68:	8082                	ret
	while (isdigit(*s))
    1d6a:	00154703          	lbu	a4,1(a0)
    1d6e:	47a5                	li	a5,9
		s++;
    1d70:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d74:	fd07061b          	addiw	a2,a4,-48
    1d78:	2701                	sext.w	a4,a4
    1d7a:	fec7e6e3          	bltu	a5,a2,1d66 <atoi+0x86>
		neg = 1;
    1d7e:	4e05                	li	t3,1
    1d80:	bf61                	j	1d18 <atoi+0x38>

0000000000001d82 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d82:	16060d63          	beqz	a2,1efc <memset+0x17a>
    1d86:	40a007b3          	neg	a5,a0
    1d8a:	8b9d                	andi	a5,a5,7
    1d8c:	00778693          	addi	a3,a5,7
    1d90:	482d                	li	a6,11
    1d92:	0ff5f713          	zext.b	a4,a1
    1d96:	fff60593          	addi	a1,a2,-1
    1d9a:	1706e263          	bltu	a3,a6,1efe <memset+0x17c>
    1d9e:	16d5ea63          	bltu	a1,a3,1f12 <memset+0x190>
    1da2:	16078563          	beqz	a5,1f0c <memset+0x18a>
    1da6:	00e50023          	sb	a4,0(a0)
    1daa:	4685                	li	a3,1
    1dac:	00150593          	addi	a1,a0,1
    1db0:	14d78c63          	beq	a5,a3,1f08 <memset+0x186>
    1db4:	00e500a3          	sb	a4,1(a0)
    1db8:	4689                	li	a3,2
    1dba:	00250593          	addi	a1,a0,2
    1dbe:	14d78d63          	beq	a5,a3,1f18 <memset+0x196>
    1dc2:	00e50123          	sb	a4,2(a0)
    1dc6:	468d                	li	a3,3
    1dc8:	00350593          	addi	a1,a0,3
    1dcc:	12d78b63          	beq	a5,a3,1f02 <memset+0x180>
    1dd0:	00e501a3          	sb	a4,3(a0)
    1dd4:	4691                	li	a3,4
    1dd6:	00450593          	addi	a1,a0,4
    1dda:	14d78163          	beq	a5,a3,1f1c <memset+0x19a>
    1dde:	00e50223          	sb	a4,4(a0)
    1de2:	4695                	li	a3,5
    1de4:	00550593          	addi	a1,a0,5
    1de8:	12d78c63          	beq	a5,a3,1f20 <memset+0x19e>
    1dec:	00e502a3          	sb	a4,5(a0)
    1df0:	469d                	li	a3,7
    1df2:	00650593          	addi	a1,a0,6
    1df6:	12d79763          	bne	a5,a3,1f24 <memset+0x1a2>
    1dfa:	00750593          	addi	a1,a0,7
    1dfe:	00e50323          	sb	a4,6(a0)
    1e02:	481d                	li	a6,7
    1e04:	00871693          	slli	a3,a4,0x8
    1e08:	01071893          	slli	a7,a4,0x10
    1e0c:	8ed9                	or	a3,a3,a4
    1e0e:	01871313          	slli	t1,a4,0x18
    1e12:	0116e6b3          	or	a3,a3,a7
    1e16:	0066e6b3          	or	a3,a3,t1
    1e1a:	02071893          	slli	a7,a4,0x20
    1e1e:	02871e13          	slli	t3,a4,0x28
    1e22:	0116e6b3          	or	a3,a3,a7
    1e26:	40f60333          	sub	t1,a2,a5
    1e2a:	03071893          	slli	a7,a4,0x30
    1e2e:	01c6e6b3          	or	a3,a3,t3
    1e32:	0116e6b3          	or	a3,a3,a7
    1e36:	03871e13          	slli	t3,a4,0x38
    1e3a:	97aa                	add	a5,a5,a0
    1e3c:	ff837893          	andi	a7,t1,-8
    1e40:	01c6e6b3          	or	a3,a3,t3
    1e44:	98be                	add	a7,a7,a5
    1e46:	e394                	sd	a3,0(a5)
    1e48:	07a1                	addi	a5,a5,8
    1e4a:	ff179ee3          	bne	a5,a7,1e46 <memset+0xc4>
    1e4e:	ff837893          	andi	a7,t1,-8
    1e52:	011587b3          	add	a5,a1,a7
    1e56:	010886bb          	addw	a3,a7,a6
    1e5a:	0b130663          	beq	t1,a7,1f06 <memset+0x184>
    1e5e:	00e78023          	sb	a4,0(a5)
    1e62:	0016859b          	addiw	a1,a3,1
    1e66:	08c5fb63          	bgeu	a1,a2,1efc <memset+0x17a>
    1e6a:	00e780a3          	sb	a4,1(a5)
    1e6e:	0026859b          	addiw	a1,a3,2
    1e72:	08c5f563          	bgeu	a1,a2,1efc <memset+0x17a>
    1e76:	00e78123          	sb	a4,2(a5)
    1e7a:	0036859b          	addiw	a1,a3,3
    1e7e:	06c5ff63          	bgeu	a1,a2,1efc <memset+0x17a>
    1e82:	00e781a3          	sb	a4,3(a5)
    1e86:	0046859b          	addiw	a1,a3,4
    1e8a:	06c5f963          	bgeu	a1,a2,1efc <memset+0x17a>
    1e8e:	00e78223          	sb	a4,4(a5)
    1e92:	0056859b          	addiw	a1,a3,5
    1e96:	06c5f363          	bgeu	a1,a2,1efc <memset+0x17a>
    1e9a:	00e782a3          	sb	a4,5(a5)
    1e9e:	0066859b          	addiw	a1,a3,6
    1ea2:	04c5fd63          	bgeu	a1,a2,1efc <memset+0x17a>
    1ea6:	00e78323          	sb	a4,6(a5)
    1eaa:	0076859b          	addiw	a1,a3,7
    1eae:	04c5f763          	bgeu	a1,a2,1efc <memset+0x17a>
    1eb2:	00e783a3          	sb	a4,7(a5)
    1eb6:	0086859b          	addiw	a1,a3,8
    1eba:	04c5f163          	bgeu	a1,a2,1efc <memset+0x17a>
    1ebe:	00e78423          	sb	a4,8(a5)
    1ec2:	0096859b          	addiw	a1,a3,9
    1ec6:	02c5fb63          	bgeu	a1,a2,1efc <memset+0x17a>
    1eca:	00e784a3          	sb	a4,9(a5)
    1ece:	00a6859b          	addiw	a1,a3,10
    1ed2:	02c5f563          	bgeu	a1,a2,1efc <memset+0x17a>
    1ed6:	00e78523          	sb	a4,10(a5)
    1eda:	00b6859b          	addiw	a1,a3,11
    1ede:	00c5ff63          	bgeu	a1,a2,1efc <memset+0x17a>
    1ee2:	00e785a3          	sb	a4,11(a5)
    1ee6:	00c6859b          	addiw	a1,a3,12
    1eea:	00c5f963          	bgeu	a1,a2,1efc <memset+0x17a>
    1eee:	00e78623          	sb	a4,12(a5)
    1ef2:	26b5                	addiw	a3,a3,13
    1ef4:	00c6f463          	bgeu	a3,a2,1efc <memset+0x17a>
    1ef8:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1efc:	8082                	ret
    1efe:	46ad                	li	a3,11
    1f00:	bd79                	j	1d9e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f02:	480d                	li	a6,3
    1f04:	b701                	j	1e04 <memset+0x82>
    1f06:	8082                	ret
    1f08:	4805                	li	a6,1
    1f0a:	bded                	j	1e04 <memset+0x82>
    1f0c:	85aa                	mv	a1,a0
    1f0e:	4801                	li	a6,0
    1f10:	bdd5                	j	1e04 <memset+0x82>
    1f12:	87aa                	mv	a5,a0
    1f14:	4681                	li	a3,0
    1f16:	b7a1                	j	1e5e <memset+0xdc>
    1f18:	4809                	li	a6,2
    1f1a:	b5ed                	j	1e04 <memset+0x82>
    1f1c:	4811                	li	a6,4
    1f1e:	b5dd                	j	1e04 <memset+0x82>
    1f20:	4815                	li	a6,5
    1f22:	b5cd                	j	1e04 <memset+0x82>
    1f24:	4819                	li	a6,6
    1f26:	bdf9                	j	1e04 <memset+0x82>

0000000000001f28 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f28:	00054783          	lbu	a5,0(a0)
    1f2c:	0005c703          	lbu	a4,0(a1)
    1f30:	00e79863          	bne	a5,a4,1f40 <strcmp+0x18>
    1f34:	0505                	addi	a0,a0,1
    1f36:	0585                	addi	a1,a1,1
    1f38:	fbe5                	bnez	a5,1f28 <strcmp>
    1f3a:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f3c:	9d19                	subw	a0,a0,a4
    1f3e:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f40:	0007851b          	sext.w	a0,a5
    1f44:	bfe5                	j	1f3c <strcmp+0x14>

0000000000001f46 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f46:	ca15                	beqz	a2,1f7a <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f48:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f4c:	167d                	addi	a2,a2,-1
    1f4e:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f52:	eb99                	bnez	a5,1f68 <strncmp+0x22>
    1f54:	a815                	j	1f88 <strncmp+0x42>
    1f56:	00a68e63          	beq	a3,a0,1f72 <strncmp+0x2c>
    1f5a:	0505                	addi	a0,a0,1
    1f5c:	00f71b63          	bne	a4,a5,1f72 <strncmp+0x2c>
    1f60:	00054783          	lbu	a5,0(a0)
    1f64:	cf89                	beqz	a5,1f7e <strncmp+0x38>
    1f66:	85b2                	mv	a1,a2
    1f68:	0005c703          	lbu	a4,0(a1)
    1f6c:	00158613          	addi	a2,a1,1
    1f70:	f37d                	bnez	a4,1f56 <strncmp+0x10>
		;
	return *l - *r;
    1f72:	0007851b          	sext.w	a0,a5
    1f76:	9d19                	subw	a0,a0,a4
    1f78:	8082                	ret
		return 0;
    1f7a:	4501                	li	a0,0
}
    1f7c:	8082                	ret
	return *l - *r;
    1f7e:	0015c703          	lbu	a4,1(a1)
    1f82:	4501                	li	a0,0
    1f84:	9d19                	subw	a0,a0,a4
    1f86:	8082                	ret
    1f88:	0005c703          	lbu	a4,0(a1)
    1f8c:	4501                	li	a0,0
    1f8e:	b7e5                	j	1f76 <strncmp+0x30>

0000000000001f90 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f90:	00757793          	andi	a5,a0,7
    1f94:	cf89                	beqz	a5,1fae <strlen+0x1e>
    1f96:	87aa                	mv	a5,a0
    1f98:	a029                	j	1fa2 <strlen+0x12>
    1f9a:	0785                	addi	a5,a5,1
    1f9c:	0077f713          	andi	a4,a5,7
    1fa0:	cb01                	beqz	a4,1fb0 <strlen+0x20>
		if (!*s)
    1fa2:	0007c703          	lbu	a4,0(a5)
    1fa6:	fb75                	bnez	a4,1f9a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1fa8:	40a78533          	sub	a0,a5,a0
}
    1fac:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1fae:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fb0:	6394                	ld	a3,0(a5)
    1fb2:	00001597          	auipc	a1,0x1
    1fb6:	91e5b583          	ld	a1,-1762(a1) # 28d0 <enable_deadlock_detect+0x1a2>
    1fba:	00001617          	auipc	a2,0x1
    1fbe:	91e63603          	ld	a2,-1762(a2) # 28d8 <enable_deadlock_detect+0x1aa>
    1fc2:	a019                	j	1fc8 <strlen+0x38>
    1fc4:	6794                	ld	a3,8(a5)
    1fc6:	07a1                	addi	a5,a5,8
    1fc8:	00b68733          	add	a4,a3,a1
    1fcc:	fff6c693          	not	a3,a3
    1fd0:	8f75                	and	a4,a4,a3
    1fd2:	8f71                	and	a4,a4,a2
    1fd4:	db65                	beqz	a4,1fc4 <strlen+0x34>
	for (; *s; s++)
    1fd6:	0007c703          	lbu	a4,0(a5)
    1fda:	d779                	beqz	a4,1fa8 <strlen+0x18>
    1fdc:	0017c703          	lbu	a4,1(a5)
    1fe0:	0785                	addi	a5,a5,1
    1fe2:	d379                	beqz	a4,1fa8 <strlen+0x18>
    1fe4:	0017c703          	lbu	a4,1(a5)
    1fe8:	0785                	addi	a5,a5,1
    1fea:	fb6d                	bnez	a4,1fdc <strlen+0x4c>
    1fec:	bf75                	j	1fa8 <strlen+0x18>

0000000000001fee <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fee:	00757713          	andi	a4,a0,7
{
    1ff2:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1ff4:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1ff8:	cb19                	beqz	a4,200e <memchr+0x20>
    1ffa:	ce25                	beqz	a2,2072 <memchr+0x84>
    1ffc:	0007c703          	lbu	a4,0(a5)
    2000:	04b70e63          	beq	a4,a1,205c <memchr+0x6e>
    2004:	0785                	addi	a5,a5,1
    2006:	0077f713          	andi	a4,a5,7
    200a:	167d                	addi	a2,a2,-1
    200c:	f77d                	bnez	a4,1ffa <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    200e:	4501                	li	a0,0
	if (n && *s != c) {
    2010:	c235                	beqz	a2,2074 <memchr+0x86>
    2012:	0007c703          	lbu	a4,0(a5)
    2016:	04b70363          	beq	a4,a1,205c <memchr+0x6e>
		size_t k = ONES * c;
    201a:	00001517          	auipc	a0,0x1
    201e:	8c653503          	ld	a0,-1850(a0) # 28e0 <enable_deadlock_detect+0x1b2>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2022:	471d                	li	a4,7
		size_t k = ONES * c;
    2024:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2028:	02c77a63          	bgeu	a4,a2,205c <memchr+0x6e>
    202c:	00001897          	auipc	a7,0x1
    2030:	8a48b883          	ld	a7,-1884(a7) # 28d0 <enable_deadlock_detect+0x1a2>
    2034:	00001817          	auipc	a6,0x1
    2038:	8a483803          	ld	a6,-1884(a6) # 28d8 <enable_deadlock_detect+0x1aa>
    203c:	431d                	li	t1,7
    203e:	a029                	j	2048 <memchr+0x5a>
		     w++, n -= SS)
    2040:	1661                	addi	a2,a2,-8
    2042:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2044:	02c37963          	bgeu	t1,a2,2076 <memchr+0x88>
    2048:	6398                	ld	a4,0(a5)
    204a:	8f29                	xor	a4,a4,a0
    204c:	011706b3          	add	a3,a4,a7
    2050:	fff74713          	not	a4,a4
    2054:	8f75                	and	a4,a4,a3
    2056:	01077733          	and	a4,a4,a6
    205a:	d37d                	beqz	a4,2040 <memchr+0x52>
{
    205c:	853e                	mv	a0,a5
    205e:	97b2                	add	a5,a5,a2
    2060:	a021                	j	2068 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2062:	0505                	addi	a0,a0,1
    2064:	00f50763          	beq	a0,a5,2072 <memchr+0x84>
    2068:	00054703          	lbu	a4,0(a0)
    206c:	feb71be3          	bne	a4,a1,2062 <memchr+0x74>
    2070:	8082                	ret
	return n ? (void *)s : 0;
    2072:	4501                	li	a0,0
}
    2074:	8082                	ret
	return n ? (void *)s : 0;
    2076:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2078:	f275                	bnez	a2,205c <memchr+0x6e>
}
    207a:	8082                	ret

000000000000207c <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    207c:	1101                	addi	sp,sp,-32
    207e:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2080:	862e                	mv	a2,a1
{
    2082:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2084:	4581                	li	a1,0
{
    2086:	e426                	sd	s1,8(sp)
    2088:	ec06                	sd	ra,24(sp)
    208a:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    208c:	f63ff0ef          	jal	ra,1fee <memchr>
	return p ? p - s : n;
    2090:	c519                	beqz	a0,209e <strnlen+0x22>
}
    2092:	60e2                	ld	ra,24(sp)
    2094:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2096:	8d05                	sub	a0,a0,s1
}
    2098:	64a2                	ld	s1,8(sp)
    209a:	6105                	addi	sp,sp,32
    209c:	8082                	ret
    209e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20a0:	8522                	mv	a0,s0
}
    20a2:	6442                	ld	s0,16(sp)
    20a4:	64a2                	ld	s1,8(sp)
    20a6:	6105                	addi	sp,sp,32
    20a8:	8082                	ret

00000000000020aa <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20aa:	00a5c7b3          	xor	a5,a1,a0
    20ae:	8b9d                	andi	a5,a5,7
    20b0:	eb95                	bnez	a5,20e4 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20b2:	0075f793          	andi	a5,a1,7
    20b6:	e7b1                	bnez	a5,2102 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20b8:	6198                	ld	a4,0(a1)
    20ba:	00001617          	auipc	a2,0x1
    20be:	81663603          	ld	a2,-2026(a2) # 28d0 <enable_deadlock_detect+0x1a2>
    20c2:	00001817          	auipc	a6,0x1
    20c6:	81683803          	ld	a6,-2026(a6) # 28d8 <enable_deadlock_detect+0x1aa>
    20ca:	a029                	j	20d4 <stpcpy+0x2a>
    20cc:	05a1                	addi	a1,a1,8
    20ce:	e118                	sd	a4,0(a0)
    20d0:	6198                	ld	a4,0(a1)
    20d2:	0521                	addi	a0,a0,8
    20d4:	00c707b3          	add	a5,a4,a2
    20d8:	fff74693          	not	a3,a4
    20dc:	8ff5                	and	a5,a5,a3
    20de:	0107f7b3          	and	a5,a5,a6
    20e2:	d7ed                	beqz	a5,20cc <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    20e4:	0005c783          	lbu	a5,0(a1)
    20e8:	00f50023          	sb	a5,0(a0)
    20ec:	c785                	beqz	a5,2114 <stpcpy+0x6a>
    20ee:	0015c783          	lbu	a5,1(a1)
    20f2:	0505                	addi	a0,a0,1
    20f4:	0585                	addi	a1,a1,1
    20f6:	00f50023          	sb	a5,0(a0)
    20fa:	fbf5                	bnez	a5,20ee <stpcpy+0x44>
		;
	return d;
}
    20fc:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20fe:	0505                	addi	a0,a0,1
    2100:	df45                	beqz	a4,20b8 <stpcpy+0xe>
			if (!(*d = *s))
    2102:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2106:	0585                	addi	a1,a1,1
    2108:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    210c:	00f50023          	sb	a5,0(a0)
    2110:	f7fd                	bnez	a5,20fe <stpcpy+0x54>
}
    2112:	8082                	ret
    2114:	8082                	ret

0000000000002116 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2116:	00a5c7b3          	xor	a5,a1,a0
    211a:	8b9d                	andi	a5,a5,7
    211c:	1a079863          	bnez	a5,22cc <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2120:	0075f793          	andi	a5,a1,7
    2124:	16078463          	beqz	a5,228c <stpncpy+0x176>
    2128:	ea01                	bnez	a2,2138 <stpncpy+0x22>
    212a:	a421                	j	2332 <stpncpy+0x21c>
    212c:	167d                	addi	a2,a2,-1
    212e:	0505                	addi	a0,a0,1
    2130:	14070e63          	beqz	a4,228c <stpncpy+0x176>
    2134:	1a060863          	beqz	a2,22e4 <stpncpy+0x1ce>
    2138:	0005c783          	lbu	a5,0(a1)
    213c:	0585                	addi	a1,a1,1
    213e:	0075f713          	andi	a4,a1,7
    2142:	00f50023          	sb	a5,0(a0)
    2146:	f3fd                	bnez	a5,212c <stpncpy+0x16>
    2148:	4805                	li	a6,1
    214a:	1a061863          	bnez	a2,22fa <stpncpy+0x1e4>
    214e:	40a007b3          	neg	a5,a0
    2152:	8b9d                	andi	a5,a5,7
    2154:	4681                	li	a3,0
    2156:	18061a63          	bnez	a2,22ea <stpncpy+0x1d4>
    215a:	00778713          	addi	a4,a5,7
    215e:	45ad                	li	a1,11
    2160:	18b76363          	bltu	a4,a1,22e6 <stpncpy+0x1d0>
    2164:	1ae6eb63          	bltu	a3,a4,231a <stpncpy+0x204>
    2168:	1a078363          	beqz	a5,230e <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    216c:	00050023          	sb	zero,0(a0)
    2170:	4685                	li	a3,1
    2172:	00150713          	addi	a4,a0,1
    2176:	18d78f63          	beq	a5,a3,2314 <stpncpy+0x1fe>
    217a:	000500a3          	sb	zero,1(a0)
    217e:	4689                	li	a3,2
    2180:	00250713          	addi	a4,a0,2
    2184:	18d78e63          	beq	a5,a3,2320 <stpncpy+0x20a>
    2188:	00050123          	sb	zero,2(a0)
    218c:	468d                	li	a3,3
    218e:	00350713          	addi	a4,a0,3
    2192:	16d78c63          	beq	a5,a3,230a <stpncpy+0x1f4>
    2196:	000501a3          	sb	zero,3(a0)
    219a:	4691                	li	a3,4
    219c:	00450713          	addi	a4,a0,4
    21a0:	18d78263          	beq	a5,a3,2324 <stpncpy+0x20e>
    21a4:	00050223          	sb	zero,4(a0)
    21a8:	4695                	li	a3,5
    21aa:	00550713          	addi	a4,a0,5
    21ae:	16d78d63          	beq	a5,a3,2328 <stpncpy+0x212>
    21b2:	000502a3          	sb	zero,5(a0)
    21b6:	469d                	li	a3,7
    21b8:	00650713          	addi	a4,a0,6
    21bc:	16d79863          	bne	a5,a3,232c <stpncpy+0x216>
    21c0:	00750713          	addi	a4,a0,7
    21c4:	00050323          	sb	zero,6(a0)
    21c8:	40f80833          	sub	a6,a6,a5
    21cc:	ff887593          	andi	a1,a6,-8
    21d0:	97aa                	add	a5,a5,a0
    21d2:	95be                	add	a1,a1,a5
    21d4:	0007b023          	sd	zero,0(a5)
    21d8:	07a1                	addi	a5,a5,8
    21da:	feb79de3          	bne	a5,a1,21d4 <stpncpy+0xbe>
    21de:	ff887593          	andi	a1,a6,-8
    21e2:	9ead                	addw	a3,a3,a1
    21e4:	00b707b3          	add	a5,a4,a1
    21e8:	12b80863          	beq	a6,a1,2318 <stpncpy+0x202>
    21ec:	00078023          	sb	zero,0(a5)
    21f0:	0016871b          	addiw	a4,a3,1
    21f4:	0ec77863          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    21f8:	000780a3          	sb	zero,1(a5)
    21fc:	0026871b          	addiw	a4,a3,2
    2200:	0ec77263          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2204:	00078123          	sb	zero,2(a5)
    2208:	0036871b          	addiw	a4,a3,3
    220c:	0cc77c63          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2210:	000781a3          	sb	zero,3(a5)
    2214:	0046871b          	addiw	a4,a3,4
    2218:	0cc77663          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    221c:	00078223          	sb	zero,4(a5)
    2220:	0056871b          	addiw	a4,a3,5
    2224:	0cc77063          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2228:	000782a3          	sb	zero,5(a5)
    222c:	0066871b          	addiw	a4,a3,6
    2230:	0ac77a63          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2234:	00078323          	sb	zero,6(a5)
    2238:	0076871b          	addiw	a4,a3,7
    223c:	0ac77463          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2240:	000783a3          	sb	zero,7(a5)
    2244:	0086871b          	addiw	a4,a3,8
    2248:	08c77e63          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    224c:	00078423          	sb	zero,8(a5)
    2250:	0096871b          	addiw	a4,a3,9
    2254:	08c77863          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2258:	000784a3          	sb	zero,9(a5)
    225c:	00a6871b          	addiw	a4,a3,10
    2260:	08c77263          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2264:	00078523          	sb	zero,10(a5)
    2268:	00b6871b          	addiw	a4,a3,11
    226c:	06c77c63          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    2270:	000785a3          	sb	zero,11(a5)
    2274:	00c6871b          	addiw	a4,a3,12
    2278:	06c77663          	bgeu	a4,a2,22e4 <stpncpy+0x1ce>
    227c:	00078623          	sb	zero,12(a5)
    2280:	26b5                	addiw	a3,a3,13
    2282:	06c6f163          	bgeu	a3,a2,22e4 <stpncpy+0x1ce>
    2286:	000786a3          	sb	zero,13(a5)
    228a:	8082                	ret
			;
		if (!n || !*s)
    228c:	c645                	beqz	a2,2334 <stpncpy+0x21e>
    228e:	0005c783          	lbu	a5,0(a1)
    2292:	ea078be3          	beqz	a5,2148 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2296:	479d                	li	a5,7
    2298:	02c7ff63          	bgeu	a5,a2,22d6 <stpncpy+0x1c0>
    229c:	00000897          	auipc	a7,0x0
    22a0:	6348b883          	ld	a7,1588(a7) # 28d0 <enable_deadlock_detect+0x1a2>
    22a4:	00000817          	auipc	a6,0x0
    22a8:	63483803          	ld	a6,1588(a6) # 28d8 <enable_deadlock_detect+0x1aa>
    22ac:	431d                	li	t1,7
    22ae:	6198                	ld	a4,0(a1)
    22b0:	011707b3          	add	a5,a4,a7
    22b4:	fff74693          	not	a3,a4
    22b8:	8ff5                	and	a5,a5,a3
    22ba:	0107f7b3          	and	a5,a5,a6
    22be:	ef81                	bnez	a5,22d6 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22c0:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22c2:	1661                	addi	a2,a2,-8
    22c4:	05a1                	addi	a1,a1,8
    22c6:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22c8:	fec363e3          	bltu	t1,a2,22ae <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22cc:	e609                	bnez	a2,22d6 <stpncpy+0x1c0>
    22ce:	a08d                	j	2330 <stpncpy+0x21a>
    22d0:	167d                	addi	a2,a2,-1
    22d2:	0505                	addi	a0,a0,1
    22d4:	ca01                	beqz	a2,22e4 <stpncpy+0x1ce>
    22d6:	0005c783          	lbu	a5,0(a1)
    22da:	0585                	addi	a1,a1,1
    22dc:	00f50023          	sb	a5,0(a0)
    22e0:	fbe5                	bnez	a5,22d0 <stpncpy+0x1ba>
		;
tail:
    22e2:	b59d                	j	2148 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    22e4:	8082                	ret
    22e6:	472d                	li	a4,11
    22e8:	bdb5                	j	2164 <stpncpy+0x4e>
    22ea:	00778713          	addi	a4,a5,7
    22ee:	45ad                	li	a1,11
    22f0:	fff60693          	addi	a3,a2,-1
    22f4:	e6b778e3          	bgeu	a4,a1,2164 <stpncpy+0x4e>
    22f8:	b7fd                	j	22e6 <stpncpy+0x1d0>
    22fa:	40a007b3          	neg	a5,a0
    22fe:	8832                	mv	a6,a2
    2300:	8b9d                	andi	a5,a5,7
    2302:	4681                	li	a3,0
    2304:	e4060be3          	beqz	a2,215a <stpncpy+0x44>
    2308:	b7cd                	j	22ea <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    230a:	468d                	li	a3,3
    230c:	bd75                	j	21c8 <stpncpy+0xb2>
    230e:	872a                	mv	a4,a0
    2310:	4681                	li	a3,0
    2312:	bd5d                	j	21c8 <stpncpy+0xb2>
    2314:	4685                	li	a3,1
    2316:	bd4d                	j	21c8 <stpncpy+0xb2>
    2318:	8082                	ret
    231a:	87aa                	mv	a5,a0
    231c:	4681                	li	a3,0
    231e:	b5f9                	j	21ec <stpncpy+0xd6>
    2320:	4689                	li	a3,2
    2322:	b55d                	j	21c8 <stpncpy+0xb2>
    2324:	4691                	li	a3,4
    2326:	b54d                	j	21c8 <stpncpy+0xb2>
    2328:	4695                	li	a3,5
    232a:	bd79                	j	21c8 <stpncpy+0xb2>
    232c:	4699                	li	a3,6
    232e:	bd69                	j	21c8 <stpncpy+0xb2>
    2330:	8082                	ret
    2332:	8082                	ret
    2334:	8082                	ret

0000000000002336 <basename>:

char *basename(char *s)
{
    2336:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2338:	c54d                	beqz	a0,23e2 <basename+0xac>
    233a:	00054783          	lbu	a5,0(a0)
		return ".";
    233e:	00000517          	auipc	a0,0x0
    2342:	58a50513          	addi	a0,a0,1418 # 28c8 <enable_deadlock_detect+0x19a>
	if (!s || !*s)
    2346:	e391                	bnez	a5,234a <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2348:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    234a:	0076f713          	andi	a4,a3,7
    234e:	87b6                	mv	a5,a3
    2350:	cf51                	beqz	a4,23ec <basename+0xb6>
    2352:	0785                	addi	a5,a5,1
    2354:	0077f713          	andi	a4,a5,7
    2358:	c729                	beqz	a4,23a2 <basename+0x6c>
		if (!*s)
    235a:	0007c703          	lbu	a4,0(a5)
    235e:	fb75                	bnez	a4,2352 <basename+0x1c>
	return s - a;
    2360:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2362:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2364:	cf8d                	beqz	a5,239e <basename+0x68>
    2366:	00f68733          	add	a4,a3,a5
    236a:	02f00593          	li	a1,47
    236e:	a031                	j	237a <basename+0x44>
		s[i] = 0;
    2370:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2374:	17fd                	addi	a5,a5,-1
    2376:	177d                	addi	a4,a4,-1
    2378:	c39d                	beqz	a5,239e <basename+0x68>
    237a:	00074603          	lbu	a2,0(a4)
    237e:	feb609e3          	beq	a2,a1,2370 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2382:	02f00613          	li	a2,47
    2386:	a011                	j	238a <basename+0x54>
    2388:	cb99                	beqz	a5,239e <basename+0x68>
    238a:	853e                	mv	a0,a5
    238c:	17fd                	addi	a5,a5,-1
    238e:	00f68733          	add	a4,a3,a5
    2392:	00074703          	lbu	a4,0(a4)
    2396:	fec719e3          	bne	a4,a2,2388 <basename+0x52>
	return s + i;
    239a:	9536                	add	a0,a0,a3
    239c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    239e:	8536                	mv	a0,a3
    23a0:	8082                	ret
    23a2:	6390                	ld	a2,0(a5)
    23a4:	00000517          	auipc	a0,0x0
    23a8:	52c53503          	ld	a0,1324(a0) # 28d0 <enable_deadlock_detect+0x1a2>
    23ac:	00000597          	auipc	a1,0x0
    23b0:	52c5b583          	ld	a1,1324(a1) # 28d8 <enable_deadlock_detect+0x1aa>
    23b4:	fff64713          	not	a4,a2
    23b8:	962a                	add	a2,a2,a0
    23ba:	8f71                	and	a4,a4,a2
    23bc:	8f6d                	and	a4,a4,a1
    23be:	eb11                	bnez	a4,23d2 <basename+0x9c>
    23c0:	6790                	ld	a2,8(a5)
    23c2:	07a1                	addi	a5,a5,8
    23c4:	00a60733          	add	a4,a2,a0
    23c8:	fff64613          	not	a2,a2
    23cc:	8f71                	and	a4,a4,a2
    23ce:	8f6d                	and	a4,a4,a1
    23d0:	db65                	beqz	a4,23c0 <basename+0x8a>
	for (; *s; s++)
    23d2:	0007c703          	lbu	a4,0(a5)
    23d6:	d749                	beqz	a4,2360 <basename+0x2a>
    23d8:	0017c703          	lbu	a4,1(a5)
    23dc:	0785                	addi	a5,a5,1
    23de:	ff6d                	bnez	a4,23d8 <basename+0xa2>
    23e0:	b741                	j	2360 <basename+0x2a>
		return ".";
    23e2:	00000517          	auipc	a0,0x0
    23e6:	4e650513          	addi	a0,a0,1254 # 28c8 <enable_deadlock_detect+0x19a>
    23ea:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23ec:	6290                	ld	a2,0(a3)
    23ee:	00000517          	auipc	a0,0x0
    23f2:	4e253503          	ld	a0,1250(a0) # 28d0 <enable_deadlock_detect+0x1a2>
    23f6:	00000597          	auipc	a1,0x0
    23fa:	4e25b583          	ld	a1,1250(a1) # 28d8 <enable_deadlock_detect+0x1aa>
    23fe:	fff64713          	not	a4,a2
    2402:	962a                	add	a2,a2,a0
    2404:	8f71                	and	a4,a4,a2
    2406:	8f6d                	and	a4,a4,a1
    2408:	df45                	beqz	a4,23c0 <basename+0x8a>
    240a:	b7f9                	j	23d8 <basename+0xa2>

000000000000240c <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    240c:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2410:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2412:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2416:	2501                	sext.w	a0,a0
    2418:	8082                	ret

000000000000241a <close>:

int close(int fd)
{
	if (fd == 1) {
    241a:	4785                	li	a5,1
    241c:	00f50863          	beq	a0,a5,242c <close+0x12>
	register long a7 __asm__("a7") = n;
    2420:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2424:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2428:	2501                	sext.w	a0,a0
    242a:	8082                	ret
{
    242c:	1101                	addi	sp,sp,-32
    242e:	ec06                	sd	ra,24(sp)
    2430:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2432:	cdffe0ef          	jal	ra,1110 <__write_buffer>
		__clear_buffer();
    2436:	d03fe0ef          	jal	ra,1138 <__clear_buffer>
    243a:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    243c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2440:	00000073          	ecall
}
    2444:	60e2                	ld	ra,24(sp)
    2446:	2501                	sext.w	a0,a0
    2448:	6105                	addi	sp,sp,32
    244a:	8082                	ret

000000000000244c <read>:
	register long a7 __asm__("a7") = n;
    244c:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2450:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2454:	8082                	ret

0000000000002456 <write>:
	register long a7 __asm__("a7") = n;
    2456:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    245a:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    245e:	8082                	ret

0000000000002460 <getpid>:
	register long a7 __asm__("a7") = n;
    2460:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2464:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2468:	2501                	sext.w	a0,a0
    246a:	8082                	ret

000000000000246c <getppid>:
	register long a7 __asm__("a7") = n;
    246c:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2470:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2474:	2501                	sext.w	a0,a0
    2476:	8082                	ret

0000000000002478 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2478:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    247c:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2480:	2501                	sext.w	a0,a0
    2482:	8082                	ret

0000000000002484 <fork>:
	register long a7 __asm__("a7") = n;
    2484:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2488:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    248c:	2501                	sext.w	a0,a0
    248e:	8082                	ret

0000000000002490 <exit>:

void exit(int code)
{
    2490:	1141                	addi	sp,sp,-16
    2492:	e406                	sd	ra,8(sp)
    2494:	e022                	sd	s0,0(sp)
    2496:	842a                	mv	s0,a0
	__write_buffer();
    2498:	c79fe0ef          	jal	ra,1110 <__write_buffer>
	__clear_buffer();
    249c:	c9dfe0ef          	jal	ra,1138 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24a0:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24a4:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24a6:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24aa:	60a2                	ld	ra,8(sp)
    24ac:	6402                	ld	s0,0(sp)
    24ae:	0141                	addi	sp,sp,16
    24b0:	8082                	ret

00000000000024b2 <waitpid>:
	register long a7 __asm__("a7") = n;
    24b2:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24b6:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24ba:	2501                	sext.w	a0,a0
    24bc:	8082                	ret

00000000000024be <exec>:
	register long a7 __asm__("a7") = n;
    24be:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c2:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24c6:	2501                	sext.w	a0,a0
    24c8:	8082                	ret

00000000000024ca <get_mtime>:

int64 get_mtime()
{
    24ca:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24cc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24d0:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    24d2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24d4:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    24d8:	2501                	sext.w	a0,a0
    24da:	ed01                	bnez	a0,24f2 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    24dc:	6722                	ld	a4,8(sp)
    24de:	3e800793          	li	a5,1000
    24e2:	6682                	ld	a3,0(sp)
    24e4:	02f75733          	divu	a4,a4,a5
    24e8:	02d78533          	mul	a0,a5,a3
    24ec:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24ee:	0141                	addi	sp,sp,16
    24f0:	8082                	ret
	return -1;
    24f2:	557d                	li	a0,-1
    24f4:	bfed                	j	24ee <get_mtime+0x24>

00000000000024f6 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24f6:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24fa:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24fe:	2501                	sext.w	a0,a0
    2500:	8082                	ret

0000000000002502 <sleep>:

int sleep(unsigned long long time)
{
    2502:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2504:	880a                	mv	a6,sp
{
    2506:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2508:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    250c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    250e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2510:	00000073          	ecall
	if (err == 0) {
    2514:	2501                	sext.w	a0,a0
    2516:	ed31                	bnez	a0,2572 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2518:	6722                	ld	a4,8(sp)
    251a:	3e800793          	li	a5,1000
    251e:	6682                	ld	a3,0(sp)
    2520:	02f75733          	divu	a4,a4,a5
    2524:	02d787b3          	mul	a5,a5,a3
    2528:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    252a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    252e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2530:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2532:	00000073          	ecall
	if (err == 0) {
    2536:	2501                	sext.w	a0,a0
    2538:	e915                	bnez	a0,256c <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    253a:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    253c:	3e800693          	li	a3,1000
    2540:	a819                	j	2556 <sleep+0x54>
	__asm_syscall("r"(a7))
    2542:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2546:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    254a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    254c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254e:	00000073          	ecall
	if (err == 0) {
    2552:	2501                	sext.w	a0,a0
    2554:	ed01                	bnez	a0,256c <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2556:	6722                	ld	a4,8(sp)
    2558:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    255a:	07c00893          	li	a7,124
    255e:	02d75733          	divu	a4,a4,a3
    2562:	02f687b3          	mul	a5,a3,a5
    2566:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2568:	fcc7ede3          	bltu	a5,a2,2542 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    256c:	4501                	li	a0,0
    256e:	0141                	addi	sp,sp,16
    2570:	8082                	ret
    2572:	57fd                	li	a5,-1
    2574:	bf5d                	j	252a <sleep+0x28>

0000000000002576 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2576:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    257a:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <set_priority>:
	register long a7 __asm__("a7") = n;
    2582:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2586:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    258a:	2501                	sext.w	a0,a0
    258c:	8082                	ret

000000000000258e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    258e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2592:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2596:	2501                	sext.w	a0,a0
    2598:	8082                	ret

000000000000259a <munmap>:
	register long a7 __asm__("a7") = n;
    259a:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259e:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <wait>:

int wait(int *code)
{
    25a6:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25a8:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25ac:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ae:	00000073          	ecall
	return waitpid(-1, code);
}
    25b2:	2501                	sext.w	a0,a0
    25b4:	8082                	ret

00000000000025b6 <spawn>:
	register long a7 __asm__("a7") = n;
    25b6:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25ba:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25be:	2501                	sext.w	a0,a0
    25c0:	8082                	ret

00000000000025c2 <pipe>:
	register long a7 __asm__("a7") = n;
    25c2:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25c6:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25ca:	2501                	sext.w	a0,a0
    25cc:	8082                	ret

00000000000025ce <mailread>:
	register long a7 __asm__("a7") = n;
    25ce:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25d2:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    25d6:	2501                	sext.w	a0,a0
    25d8:	8082                	ret

00000000000025da <mailwrite>:
	register long a7 __asm__("a7") = n;
    25da:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25de:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    25e2:	2501                	sext.w	a0,a0
    25e4:	8082                	ret

00000000000025e6 <fstat>:
	register long a7 __asm__("a7") = n;
    25e6:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ea:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25ee:	2501                	sext.w	a0,a0
    25f0:	8082                	ret

00000000000025f2 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25f2:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25f4:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25f8:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25fa:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2602:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2604:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2608:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    260a:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    260e:	2501                	sext.w	a0,a0
    2610:	8082                	ret

0000000000002612 <link>:

int link(char *old_path, char *new_path)
{
    2612:	87aa                	mv	a5,a0
    2614:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2616:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    261a:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    261e:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2620:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2624:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2626:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    262a:	2501                	sext.w	a0,a0
    262c:	8082                	ret

000000000000262e <unlink>:

int unlink(char *path)
{
    262e:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2630:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2634:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2638:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    263a:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    263e:	2501                	sext.w	a0,a0
    2640:	8082                	ret

0000000000002642 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2642:	00000797          	auipc	a5,0x0
    2646:	3d67b783          	ld	a5,982(a5) # 2a18 <_GLOBAL_OFFSET_TABLE_+0x8>
    264a:	439c                	lw	a5,0(a5)
    264c:	c799                	beqz	a5,265a <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    264e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2652:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret
{
    265a:	1101                	addi	sp,sp,-32
    265c:	ec06                	sd	ra,24(sp)
    265e:	e42e                	sd	a1,8(sp)
    2660:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2662:	fe7fe0ef          	jal	ra,1648 <enable_thread_io_buffer>
    2666:	65a2                	ld	a1,8(sp)
    2668:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    266a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266e:	00000073          	ecall
}
    2672:	60e2                	ld	ra,24(sp)
    2674:	2501                	sext.w	a0,a0
    2676:	6105                	addi	sp,sp,32
    2678:	8082                	ret

000000000000267a <gettid>:
	register long a7 __asm__("a7") = n;
    267a:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    267e:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2682:	2501                	sext.w	a0,a0
    2684:	8082                	ret

0000000000002686 <waittid>:

int waittid(int tid)
{
    2686:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2688:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    268c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2690:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2692:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2694:	00e51e63          	bne	a0,a4,26b0 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2698:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    269c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26a0:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26a4:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26a6:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26aa:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26ac:	fee506e3          	beq	a0,a4,2698 <waittid+0x12>
	}
	return ret;
}
    26b0:	8082                	ret

00000000000026b2 <mutex_create>:
	register long a7 __asm__("a7") = n;
    26b2:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26b6:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26b8:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26bc:	2501                	sext.w	a0,a0
    26be:	8082                	ret

00000000000026c0 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26c0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26c4:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26c6:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26ca:	2501                	sext.w	a0,a0
    26cc:	8082                	ret

00000000000026ce <mutex_lock>:
	register long a7 __asm__("a7") = n;
    26ce:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    26d2:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    26d6:	2501                	sext.w	a0,a0
    26d8:	8082                	ret

00000000000026da <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    26da:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    26de:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    26e2:	2501                	sext.w	a0,a0
    26e4:	8082                	ret

00000000000026e6 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    26e6:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    26ea:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26ee:	2501                	sext.w	a0,a0
    26f0:	8082                	ret

00000000000026f2 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26f2:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26f6:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret

00000000000026fe <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26fe:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2702:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2706:	2501                	sext.w	a0,a0
    2708:	8082                	ret

000000000000270a <condvar_create>:
	register long a7 __asm__("a7") = n;
    270a:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    270e:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2712:	2501                	sext.w	a0,a0
    2714:	8082                	ret

0000000000002716 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2716:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    271a:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    271e:	2501                	sext.w	a0,a0
    2720:	8082                	ret

0000000000002722 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2722:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2726:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    272a:	2501                	sext.w	a0,a0
    272c:	8082                	ret

000000000000272e <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    272e:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2732:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2736:	2501                	sext.w	a0,a0
    2738:	8082                	ret
