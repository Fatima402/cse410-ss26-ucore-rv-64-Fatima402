
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch4_mmap0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a201                	j	1100 <__start_main>

0000000000001002 <main>:
/*
理想结果：输出 Test 04_1 OK!
*/

int main()
{
    1002:	7139                	addi	sp,sp,-64
	uint64 start = 0x10000000;
	uint64 len = 4096;
	int prot = 3;
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1004:	577d                	li	a4,-1
    1006:	4681                	li	a3,0
    1008:	460d                	li	a2,3
    100a:	6585                	lui	a1,0x1
    100c:	10000537          	lui	a0,0x10000
{
    1010:	fc06                	sd	ra,56(sp)
    1012:	f822                	sd	s0,48(sp)
    1014:	f426                	sd	s1,40(sp)
    1016:	f04a                	sd	s2,32(sp)
    1018:	ec4e                	sd	s3,24(sp)
    101a:	e852                	sd	s4,16(sp)
    101c:	e456                	sd	s5,8(sp)
    101e:	e05a                	sd	s6,0(sp)
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1020:	59a010ef          	jal	ra,25ba <mmap>
    1024:	e941                	bnez	a0,10b4 <main+0xb2>
{
    1026:	100007b7          	lui	a5,0x10000
	for (uint64 i = start; i < (start + len); ++i) {
    102a:	10001737          	lui	a4,0x10001
		uint8 *addr = (uint8 *)i;
		*addr = (uint8)i;
    102e:	00f78023          	sb	a5,0(a5) # 10000000 <.got.plt+0xfffd5d0>
	for (uint64 i = start; i < (start + len); ++i) {
    1032:	0785                	addi	a5,a5,1
    1034:	fee79de3          	bne	a5,a4,102e <main+0x2c>
	}
	for (uint64 i = start; i < (start + len); ++i) {
    1038:	10000437          	lui	s0,0x10000
		uint8 *addr = (uint8 *)i;
		assert_eq(*addr, (uint8)i);
    103c:	00001b17          	auipc	s6,0x1
    1040:	72cb0b13          	addi	s6,s6,1836 # 2768 <enable_deadlock_detect+0xe>
    1044:	00001a97          	auipc	s5,0x1
    1048:	76ca8a93          	addi	s5,s5,1900 # 27b0 <enable_deadlock_detect+0x56>
    104c:	00001a17          	auipc	s4,0x1
    1050:	76ca0a13          	addi	s4,s4,1900 # 27b8 <enable_deadlock_detect+0x5e>
	for (uint64 i = start; i < (start + len); ++i) {
    1054:	100019b7          	lui	s3,0x10001
		assert_eq(*addr, (uint8)i);
    1058:	00044783          	lbu	a5,0(s0) # 10000000 <.got.plt+0xfffd5d0>
    105c:	0ff47493          	zext.b	s1,s0
    1060:	02978663          	beq	a5,s1,108c <main+0x8a>
    1064:	428010ef          	jal	ra,248c <getpid>
    1068:	892a                	mv	s2,a0
    106a:	855a                	mv	a0,s6
    106c:	2f6010ef          	jal	ra,2362 <basename>
    1070:	00044803          	lbu	a6,0(s0)
    1074:	872a                	mv	a4,a0
    1076:	88a6                	mv	a7,s1
    1078:	8552                	mv	a0,s4
    107a:	47d9                	li	a5,22
    107c:	86ca                	mv	a3,s2
    107e:	8656                	mv	a2,s5
    1080:	45fd                	li	a1,31
    1082:	1d8000ef          	jal	ra,125a <printf>
    1086:	557d                	li	a0,-1
    1088:	434010ef          	jal	ra,24bc <exit>
	for (uint64 i = start; i < (start + len); ++i) {
    108c:	0405                	addi	s0,s0,1
    108e:	fd3415e3          	bne	s0,s3,1058 <main+0x56>
	}
	puts("Test 04_0 OK!");
    1092:	00001517          	auipc	a0,0x1
    1096:	75e50513          	addi	a0,a0,1886 # 27f0 <enable_deadlock_detect+0x96>
    109a:	0d7000ef          	jal	ra,1970 <puts>
	return 0;
    109e:	70e2                	ld	ra,56(sp)
    10a0:	7442                	ld	s0,48(sp)
    10a2:	74a2                	ld	s1,40(sp)
    10a4:	7902                	ld	s2,32(sp)
    10a6:	69e2                	ld	s3,24(sp)
    10a8:	6a42                	ld	s4,16(sp)
    10aa:	6aa2                	ld	s5,8(sp)
    10ac:	6b02                	ld	s6,0(sp)
    10ae:	4501                	li	a0,0
    10b0:	6121                	addi	sp,sp,64
    10b2:	8082                	ret
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    10b4:	3d8010ef          	jal	ra,248c <getpid>
    10b8:	842a                	mv	s0,a0
    10ba:	00001517          	auipc	a0,0x1
    10be:	6ae50513          	addi	a0,a0,1710 # 2768 <enable_deadlock_detect+0xe>
    10c2:	2a0010ef          	jal	ra,2362 <basename>
    10c6:	84aa                	mv	s1,a0
    10c8:	577d                	li	a4,-1
    10ca:	4681                	li	a3,0
    10cc:	460d                	li	a2,3
    10ce:	6585                	lui	a1,0x1
    10d0:	10000537          	lui	a0,0x10000
    10d4:	4e6010ef          	jal	ra,25ba <mmap>
    10d8:	88aa                	mv	a7,a0
    10da:	4801                	li	a6,0
    10dc:	00001517          	auipc	a0,0x1
    10e0:	6dc50513          	addi	a0,a0,1756 # 27b8 <enable_deadlock_detect+0x5e>
    10e4:	47bd                	li	a5,15
    10e6:	8726                	mv	a4,s1
    10e8:	86a2                	mv	a3,s0
    10ea:	00001617          	auipc	a2,0x1
    10ee:	6c660613          	addi	a2,a2,1734 # 27b0 <enable_deadlock_detect+0x56>
    10f2:	45fd                	li	a1,31
    10f4:	166000ef          	jal	ra,125a <printf>
    10f8:	557d                	li	a0,-1
    10fa:	3c2010ef          	jal	ra,24bc <exit>
    10fe:	b725                	j	1026 <main+0x24>

0000000000001100 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1100:	1141                	addi	sp,sp,-16
    1102:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1104:	effff0ef          	jal	ra,1002 <main>
    1108:	3b4010ef          	jal	ra,24bc <exit>
	return 0;
    110c:	60a2                	ld	ra,8(sp)
    110e:	4501                	li	a0,0
    1110:	0141                	addi	sp,sp,16
    1112:	8082                	ret

0000000000001114 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1114:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1116:	4605                	li	a2,1
    1118:	00f10593          	addi	a1,sp,15
    111c:	4501                	li	a0,0
{
    111e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1120:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1124:	354010ef          	jal	ra,2478 <read>
    1128:	4785                	li	a5,1
    112a:	00f51763          	bne	a0,a5,1138 <getchar+0x24>
		return byte;
    112e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1132:	60e2                	ld	ra,24(sp)
    1134:	6105                	addi	sp,sp,32
    1136:	8082                	ret
		return EOF;
    1138:	557d                	li	a0,-1
    113a:	bfe5                	j	1132 <getchar+0x1e>

000000000000113c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    113c:	00001517          	auipc	a0,0x1
    1140:	7bc52503          	lw	a0,1980(a0) # 28f8 <buffer_len>
    1144:	e111                	bnez	a0,1148 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1146:	8082                	ret
{
    1148:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    114a:	862a                	mv	a2,a0
    114c:	00001597          	auipc	a1,0x1
    1150:	7b458593          	addi	a1,a1,1972 # 2900 <buffer>
    1154:	4505                	li	a0,1
{
    1156:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1158:	32a010ef          	jal	ra,2482 <write>
}
    115c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    115e:	2501                	sext.w	a0,a0
}
    1160:	0141                	addi	sp,sp,16
    1162:	8082                	ret

0000000000001164 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1164:	00001797          	auipc	a5,0x1
    1168:	7807aa23          	sw	zero,1940(a5) # 28f8 <buffer_len>
}
    116c:	8082                	ret

000000000000116e <__fflush>:
	if (buffer_len == 0)
    116e:	00001517          	auipc	a0,0x1
    1172:	78a52503          	lw	a0,1930(a0) # 28f8 <buffer_len>
    1176:	e511                	bnez	a0,1182 <__fflush+0x14>
	buffer_len = 0;
    1178:	00001797          	auipc	a5,0x1
    117c:	7807a023          	sw	zero,1920(a5) # 28f8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1180:	8082                	ret
{
    1182:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1184:	862a                	mv	a2,a0
    1186:	00001597          	auipc	a1,0x1
    118a:	77a58593          	addi	a1,a1,1914 # 2900 <buffer>
    118e:	4505                	li	a0,1
{
    1190:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1192:	2f0010ef          	jal	ra,2482 <write>
	return r >= 0 ? 0 : r;
    1196:	0005079b          	sext.w	a5,a0
}
    119a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    119c:	0017a793          	slti	a5,a5,1
    11a0:	40f007bb          	negw	a5,a5
    11a4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11a6:	00001797          	auipc	a5,0x1
    11aa:	7407a923          	sw	zero,1874(a5) # 28f8 <buffer_len>
	return r >= 0 ? 0 : r;
    11ae:	2501                	sext.w	a0,a0
}
    11b0:	0141                	addi	sp,sp,16
    11b2:	8082                	ret

00000000000011b4 <fflush>:

int fflush(int fd)
{
    11b4:	1101                	addi	sp,sp,-32
    11b6:	e822                	sd	s0,16(sp)
    11b8:	ec06                	sd	ra,24(sp)
    11ba:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11bc:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    11be:	4401                	li	s0,0
	if (fd == 1) {
    11c0:	00e50863          	beq	a0,a4,11d0 <fflush+0x1c>
}
    11c4:	60e2                	ld	ra,24(sp)
    11c6:	8522                	mv	a0,s0
    11c8:	6442                	ld	s0,16(sp)
    11ca:	64a2                	ld	s1,8(sp)
    11cc:	6105                	addi	sp,sp,32
    11ce:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11d0:	00001497          	auipc	s1,0x1
    11d4:	72848493          	addi	s1,s1,1832 # 28f8 <buffer_len>
    11d8:	1084a703          	lw	a4,264(s1)
    11dc:	02a70e63          	beq	a4,a0,1218 <fflush+0x64>
	if (buffer_len == 0)
    11e0:	4080                	lw	s0,0(s1)
    11e2:	c00d                	beqz	s0,1204 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11e4:	8622                	mv	a2,s0
    11e6:	00001597          	auipc	a1,0x1
    11ea:	71a58593          	addi	a1,a1,1818 # 2900 <buffer>
    11ee:	294010ef          	jal	ra,2482 <write>
	return r >= 0 ? 0 : r;
    11f2:	0005079b          	sext.w	a5,a0
    11f6:	0017a793          	slti	a5,a5,1
    11fa:	40f007bb          	negw	a5,a5
    11fe:	8d7d                	and	a0,a0,a5
    1200:	0005041b          	sext.w	s0,a0
}
    1204:	60e2                	ld	ra,24(sp)
    1206:	8522                	mv	a0,s0
    1208:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    120a:	00001797          	auipc	a5,0x1
    120e:	6e07a723          	sw	zero,1774(a5) # 28f8 <buffer_len>
}
    1212:	64a2                	ld	s1,8(sp)
    1214:	6105                	addi	sp,sp,32
    1216:	8082                	ret
			mutex_lock(buffer_lock);
    1218:	10c4a503          	lw	a0,268(s1)
    121c:	4de010ef          	jal	ra,26fa <mutex_lock>
	if (buffer_len == 0)
    1220:	4080                	lw	s0,0(s1)
    1222:	e811                	bnez	s0,1236 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1224:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1228:	00001797          	auipc	a5,0x1
    122c:	6c07a823          	sw	zero,1744(a5) # 28f8 <buffer_len>
			mutex_unlock(buffer_lock);
    1230:	4d6010ef          	jal	ra,2706 <mutex_unlock>
    1234:	bf41                	j	11c4 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1236:	8622                	mv	a2,s0
    1238:	00001597          	auipc	a1,0x1
    123c:	6c858593          	addi	a1,a1,1736 # 2900 <buffer>
    1240:	4505                	li	a0,1
    1242:	240010ef          	jal	ra,2482 <write>
	return r >= 0 ? 0 : r;
    1246:	0005079b          	sext.w	a5,a0
    124a:	0017a793          	slti	a5,a5,1
    124e:	40f007bb          	negw	a5,a5
    1252:	8d7d                	and	a0,a0,a5
    1254:	0005041b          	sext.w	s0,a0
	return r;
    1258:	b7f1                	j	1224 <fflush+0x70>

000000000000125a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    125a:	7131                	addi	sp,sp,-192
    125c:	e0da                	sd	s6,64(sp)
    125e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1260:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1262:	013c                	addi	a5,sp,136
{
    1264:	f0ca                	sd	s2,96(sp)
    1266:	ecce                	sd	s3,88(sp)
    1268:	e8d2                	sd	s4,80(sp)
    126a:	e4d6                	sd	s5,72(sp)
    126c:	fc86                	sd	ra,120(sp)
    126e:	f8a2                	sd	s0,112(sp)
    1270:	f4a6                	sd	s1,104(sp)
    1272:	89aa                	mv	s3,a0
    1274:	e52e                	sd	a1,136(sp)
    1276:	e932                	sd	a2,144(sp)
    1278:	ed36                	sd	a3,152(sp)
    127a:	f13a                	sd	a4,160(sp)
    127c:	f942                	sd	a6,176(sp)
    127e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1280:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1282:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1286:	00001a17          	auipc	s4,0x1
    128a:	672a0a13          	addi	s4,s4,1650 # 28f8 <buffer_len>
    128e:	4a85                	li	s5,1
	buf[i++] = '0';
    1290:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1294:	0009c783          	lbu	a5,0(s3) # 10001000 <.got.plt+0xfffe5d0>
    1298:	18078663          	beqz	a5,1424 <printf+0x1ca>
    129c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    129e:	19278d63          	beq	a5,s2,1438 <printf+0x1de>
    12a2:	0015c783          	lbu	a5,1(a1)
    12a6:	0585                	addi	a1,a1,1
    12a8:	fbfd                	bnez	a5,129e <printf+0x44>
    12aa:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12ac:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12b0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12b4:	1b578863          	beq	a5,s5,1464 <printf+0x20a>
		len = out_unlocked(s, l);
    12b8:	85a2                	mv	a1,s0
    12ba:	854e                	mv	a0,s3
    12bc:	42a000ef          	jal	ra,16e6 <out_unlocked>
		out(f, a, l);
		if (l)
    12c0:	1c041063          	bnez	s0,1480 <printf+0x226>
			continue;
		if (s[1] == 0)
    12c4:	0014c783          	lbu	a5,1(s1)
    12c8:	14078e63          	beqz	a5,1424 <printf+0x1ca>
			break;
		switch (s[1]) {
    12cc:	07300713          	li	a4,115
    12d0:	1ce78863          	beq	a5,a4,14a0 <printf+0x246>
    12d4:	1af76863          	bltu	a4,a5,1484 <printf+0x22a>
    12d8:	06400713          	li	a4,100
    12dc:	22e78063          	beq	a5,a4,14fc <printf+0x2a2>
    12e0:	07000713          	li	a4,112
    12e4:	1ee79563          	bne	a5,a4,14ce <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12e8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12ea:	00001797          	auipc	a5,0x1
    12ee:	71e78793          	addi	a5,a5,1822 # 2a08 <digits>
	buf[i++] = '0';
    12f2:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12f6:	6298                	ld	a4,0(a3)
    12f8:	06a1                	addi	a3,a3,8
    12fa:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12fc:	00471393          	slli	t2,a4,0x4
    1300:	00871293          	slli	t0,a4,0x8
    1304:	00c71f93          	slli	t6,a4,0xc
    1308:	01071f13          	slli	t5,a4,0x10
    130c:	01471e93          	slli	t4,a4,0x14
    1310:	01871e13          	slli	t3,a4,0x18
    1314:	01c71893          	slli	a7,a4,0x1c
    1318:	02471813          	slli	a6,a4,0x24
    131c:	02871513          	slli	a0,a4,0x28
    1320:	02c71593          	slli	a1,a4,0x2c
    1324:	03071613          	slli	a2,a4,0x30
    1328:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    132c:	03c75413          	srli	s0,a4,0x3c
    1330:	01c7531b          	srliw	t1,a4,0x1c
    1334:	03c3d393          	srli	t2,t2,0x3c
    1338:	03c2d293          	srli	t0,t0,0x3c
    133c:	03cfdf93          	srli	t6,t6,0x3c
    1340:	03cf5f13          	srli	t5,t5,0x3c
    1344:	03cede93          	srli	t4,t4,0x3c
    1348:	03ce5e13          	srli	t3,t3,0x3c
    134c:	03c8d893          	srli	a7,a7,0x3c
    1350:	03c85813          	srli	a6,a6,0x3c
    1354:	9171                	srli	a0,a0,0x3c
    1356:	91f1                	srli	a1,a1,0x3c
    1358:	9271                	srli	a2,a2,0x3c
    135a:	92f1                	srli	a3,a3,0x3c
    135c:	95be                	add	a1,a1,a5
    135e:	963e                	add	a2,a2,a5
    1360:	96be                	add	a3,a3,a5
    1362:	943e                	add	s0,s0,a5
    1364:	93be                	add	t2,t2,a5
    1366:	92be                	add	t0,t0,a5
    1368:	9fbe                	add	t6,t6,a5
    136a:	9f3e                	add	t5,t5,a5
    136c:	9ebe                	add	t4,t4,a5
    136e:	9e3e                	add	t3,t3,a5
    1370:	98be                	add	a7,a7,a5
    1372:	933e                	add	t1,t1,a5
    1374:	983e                	add	a6,a6,a5
    1376:	953e                	add	a0,a0,a5
    1378:	0005c983          	lbu	s3,0(a1)
    137c:	00044403          	lbu	s0,0(s0)
    1380:	00064583          	lbu	a1,0(a2)
    1384:	0003c383          	lbu	t2,0(t2)
    1388:	0006c603          	lbu	a2,0(a3)
    138c:	0002c283          	lbu	t0,0(t0)
    1390:	000fcf83          	lbu	t6,0(t6)
    1394:	000f4f03          	lbu	t5,0(t5)
    1398:	000ece83          	lbu	t4,0(t4)
    139c:	000e4e03          	lbu	t3,0(t3)
    13a0:	0008c883          	lbu	a7,0(a7)
    13a4:	00034303          	lbu	t1,0(t1)
    13a8:	00084803          	lbu	a6,0(a6)
    13ac:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13b0:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13b4:	92f1                	srli	a3,a3,0x3c
    13b6:	8b3d                	andi	a4,a4,15
    13b8:	96be                	add	a3,a3,a5
    13ba:	97ba                	add	a5,a5,a4
    13bc:	00810d23          	sb	s0,26(sp)
    13c0:	00710da3          	sb	t2,27(sp)
    13c4:	00510e23          	sb	t0,28(sp)
    13c8:	01f10ea3          	sb	t6,29(sp)
    13cc:	01e10f23          	sb	t5,30(sp)
    13d0:	01d10fa3          	sb	t4,31(sp)
    13d4:	03c10023          	sb	t3,32(sp)
    13d8:	031100a3          	sb	a7,33(sp)
    13dc:	02610123          	sb	t1,34(sp)
    13e0:	030101a3          	sb	a6,35(sp)
    13e4:	02a10223          	sb	a0,36(sp)
    13e8:	033102a3          	sb	s3,37(sp)
    13ec:	02b10323          	sb	a1,38(sp)
    13f0:	02c103a3          	sb	a2,39(sp)
    13f4:	0006c683          	lbu	a3,0(a3)
    13f8:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    13fc:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1400:	02d10423          	sb	a3,40(sp)
    1404:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1408:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    140c:	11578263          	beq	a5,s5,1510 <printf+0x2b6>
		len = out_unlocked(s, l);
    1410:	45c9                	li	a1,18
    1412:	0828                	addi	a0,sp,24
    1414:	2d2000ef          	jal	ra,16e6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1418:	00248993          	addi	s3,s1,2
		if (!*s)
    141c:	0009c783          	lbu	a5,0(s3)
    1420:	e6079ee3          	bnez	a5,129c <printf+0x42>
	}
	va_end(ap);
    1424:	70e6                	ld	ra,120(sp)
    1426:	7446                	ld	s0,112(sp)
    1428:	74a6                	ld	s1,104(sp)
    142a:	7906                	ld	s2,96(sp)
    142c:	69e6                	ld	s3,88(sp)
    142e:	6a46                	ld	s4,80(sp)
    1430:	6aa6                	ld	s5,72(sp)
    1432:	6b06                	ld	s6,64(sp)
    1434:	6129                	addi	sp,sp,192
    1436:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1438:	0005c783          	lbu	a5,0(a1)
    143c:	84ae                	mv	s1,a1
    143e:	01278963          	beq	a5,s2,1450 <printf+0x1f6>
    1442:	b5ad                	j	12ac <printf+0x52>
    1444:	0024c783          	lbu	a5,2(s1)
    1448:	0585                	addi	a1,a1,1
    144a:	0489                	addi	s1,s1,2
    144c:	e72790e3          	bne	a5,s2,12ac <printf+0x52>
    1450:	0014c783          	lbu	a5,1(s1)
    1454:	ff2788e3          	beq	a5,s2,1444 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1458:	108a2783          	lw	a5,264(s4)
		l = z - a;
    145c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1460:	e5579ce3          	bne	a5,s5,12b8 <printf+0x5e>
		mutex_lock(buffer_lock);
    1464:	10ca2503          	lw	a0,268(s4)
    1468:	292010ef          	jal	ra,26fa <mutex_lock>
		len = out_unlocked(s, l);
    146c:	85a2                	mv	a1,s0
    146e:	854e                	mv	a0,s3
    1470:	276000ef          	jal	ra,16e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1474:	10ca2503          	lw	a0,268(s4)
    1478:	28e010ef          	jal	ra,2706 <mutex_unlock>
		if (l)
    147c:	e40404e3          	beqz	s0,12c4 <printf+0x6a>
    1480:	89a6                	mv	s3,s1
    1482:	bd09                	j	1294 <printf+0x3a>
		switch (s[1]) {
    1484:	07800713          	li	a4,120
    1488:	04e79363          	bne	a5,a4,14ce <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    148c:	67c2                	ld	a5,16(sp)
    148e:	45c1                	li	a1,16
		s += 2;
    1490:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1494:	4388                	lw	a0,0(a5)
    1496:	07a1                	addi	a5,a5,8
    1498:	e83e                	sd	a5,16(sp)
    149a:	5f8000ef          	jal	ra,1a92 <printint.constprop.0>
		s += 2;
    149e:	bfbd                	j	141c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14a0:	67c2                	ld	a5,16(sp)
    14a2:	6380                	ld	s0,0(a5)
    14a4:	07a1                	addi	a5,a5,8
    14a6:	e83e                	sd	a5,16(sp)
    14a8:	1c040163          	beqz	s0,166a <printf+0x410>
			l = strnlen(a, 200);
    14ac:	0c800593          	li	a1,200
    14b0:	8522                	mv	a0,s0
    14b2:	3f7000ef          	jal	ra,20a8 <strnlen>
	if (buffer_lock_enabled == 1) {
    14b6:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14ba:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    14be:	19578663          	beq	a5,s5,164a <printf+0x3f0>
		len = out_unlocked(s, l);
    14c2:	8522                	mv	a0,s0
    14c4:	222000ef          	jal	ra,16e6 <out_unlocked>
		s += 2;
    14c8:	00248993          	addi	s3,s1,2
    14cc:	bf81                	j	141c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    14ce:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14d2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14d6:	0f578663          	beq	a5,s5,15c2 <printf+0x368>
		len = out_unlocked(s, l);
    14da:	0828                	addi	a0,sp,24
    14dc:	316000ef          	jal	ra,17f2 <out_unlocked.constprop.0>
			putchar(s[1]);
    14e0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14e4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14e8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14ec:	05578163          	beq	a5,s5,152e <printf+0x2d4>
		len = out_unlocked(s, l);
    14f0:	0828                	addi	a0,sp,24
    14f2:	300000ef          	jal	ra,17f2 <out_unlocked.constprop.0>
		s += 2;
    14f6:	00248993          	addi	s3,s1,2
    14fa:	b70d                	j	141c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    14fc:	67c2                	ld	a5,16(sp)
    14fe:	45a9                	li	a1,10
		s += 2;
    1500:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1504:	4388                	lw	a0,0(a5)
    1506:	07a1                	addi	a5,a5,8
    1508:	e83e                	sd	a5,16(sp)
    150a:	588000ef          	jal	ra,1a92 <printint.constprop.0>
		s += 2;
    150e:	b739                	j	141c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1510:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1514:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1518:	1e2010ef          	jal	ra,26fa <mutex_lock>
		len = out_unlocked(s, l);
    151c:	45c9                	li	a1,18
    151e:	0828                	addi	a0,sp,24
    1520:	1c6000ef          	jal	ra,16e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1524:	10ca2503          	lw	a0,268(s4)
    1528:	1de010ef          	jal	ra,2706 <mutex_unlock>
		s += 2;
    152c:	bdc5                	j	141c <printf+0x1c2>
		mutex_lock(buffer_lock);
    152e:	10ca2503          	lw	a0,268(s4)
    1532:	1c8010ef          	jal	ra,26fa <mutex_lock>
		buffer[buffer_len++] = c;
    1536:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    153a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    153e:	0017861b          	addiw	a2,a5,1
    1542:	97d2                	add	a5,a5,s4
    1544:	00ca2023          	sw	a2,0(s4)
    1548:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    154c:	00c6cc63          	blt	a3,a2,1564 <printf+0x30a>
    1550:	47a9                	li	a5,10
    1552:	06f40663          	beq	s0,a5,15be <printf+0x364>
		mutex_unlock(buffer_lock);
    1556:	10ca2503          	lw	a0,268(s4)
		s += 2;
    155a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    155e:	1a8010ef          	jal	ra,2706 <mutex_unlock>
		s += 2;
    1562:	bd6d                	j	141c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1564:	10000793          	li	a5,256
    1568:	00f61e63          	bne	a2,a5,1584 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    156c:	00001597          	auipc	a1,0x1
    1570:	39458593          	addi	a1,a1,916 # 2900 <buffer>
    1574:	4505                	li	a0,1
    1576:	70d000ef          	jal	ra,2482 <write>
	buffer_len = 0;
    157a:	00001797          	auipc	a5,0x1
    157e:	3607af23          	sw	zero,894(a5) # 28f8 <buffer_len>
			if (r < 0) {
    1582:	bfd1                	j	1556 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1584:	709000ef          	jal	ra,248c <getpid>
    1588:	842a                	mv	s0,a0
    158a:	00001517          	auipc	a0,0x1
    158e:	27e50513          	addi	a0,a0,638 # 2808 <enable_deadlock_detect+0xae>
    1592:	5d1000ef          	jal	ra,2362 <basename>
    1596:	872a                	mv	a4,a0
    1598:	00001617          	auipc	a2,0x1
    159c:	21860613          	addi	a2,a2,536 # 27b0 <enable_deadlock_detect+0x56>
    15a0:	05400793          	li	a5,84
    15a4:	86a2                	mv	a3,s0
    15a6:	45fd                	li	a1,31
    15a8:	00001517          	auipc	a0,0x1
    15ac:	2a050513          	addi	a0,a0,672 # 2848 <enable_deadlock_detect+0xee>
    15b0:	cabff0ef          	jal	ra,125a <printf>
    15b4:	557d                	li	a0,-1
    15b6:	707000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    15ba:	000a2603          	lw	a2,0(s4)
    15be:	de41                	beqz	a2,1556 <printf+0x2fc>
    15c0:	b775                	j	156c <printf+0x312>
		mutex_lock(buffer_lock);
    15c2:	10ca2503          	lw	a0,268(s4)
    15c6:	134010ef          	jal	ra,26fa <mutex_lock>
		buffer[buffer_len++] = c;
    15ca:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15ce:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15d2:	0017861b          	addiw	a2,a5,1
    15d6:	97d2                	add	a5,a5,s4
    15d8:	00ca2023          	sw	a2,0(s4)
    15dc:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15e0:	02c6d163          	bge	a3,a2,1602 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15e4:	10000793          	li	a5,256
    15e8:	02f61263          	bne	a2,a5,160c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15ec:	00001597          	auipc	a1,0x1
    15f0:	31458593          	addi	a1,a1,788 # 2900 <buffer>
    15f4:	4505                	li	a0,1
    15f6:	68d000ef          	jal	ra,2482 <write>
	buffer_len = 0;
    15fa:	00001797          	auipc	a5,0x1
    15fe:	2e07af23          	sw	zero,766(a5) # 28f8 <buffer_len>
		mutex_unlock(buffer_lock);
    1602:	10ca2503          	lw	a0,268(s4)
    1606:	100010ef          	jal	ra,2706 <mutex_unlock>
    160a:	bdd9                	j	14e0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    160c:	681000ef          	jal	ra,248c <getpid>
    1610:	842a                	mv	s0,a0
    1612:	00001517          	auipc	a0,0x1
    1616:	1f650513          	addi	a0,a0,502 # 2808 <enable_deadlock_detect+0xae>
    161a:	549000ef          	jal	ra,2362 <basename>
    161e:	872a                	mv	a4,a0
    1620:	00001617          	auipc	a2,0x1
    1624:	19060613          	addi	a2,a2,400 # 27b0 <enable_deadlock_detect+0x56>
    1628:	05400793          	li	a5,84
    162c:	86a2                	mv	a3,s0
    162e:	45fd                	li	a1,31
    1630:	00001517          	auipc	a0,0x1
    1634:	21850513          	addi	a0,a0,536 # 2848 <enable_deadlock_detect+0xee>
    1638:	c23ff0ef          	jal	ra,125a <printf>
    163c:	557d                	li	a0,-1
    163e:	67f000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    1642:	000a2603          	lw	a2,0(s4)
    1646:	de55                	beqz	a2,1602 <printf+0x3a8>
    1648:	b755                	j	15ec <printf+0x392>
		mutex_lock(buffer_lock);
    164a:	10ca2503          	lw	a0,268(s4)
    164e:	e42e                	sd	a1,8(sp)
		s += 2;
    1650:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1654:	0a6010ef          	jal	ra,26fa <mutex_lock>
		len = out_unlocked(s, l);
    1658:	65a2                	ld	a1,8(sp)
    165a:	8522                	mv	a0,s0
    165c:	08a000ef          	jal	ra,16e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1660:	10ca2503          	lw	a0,268(s4)
    1664:	0a2010ef          	jal	ra,2706 <mutex_unlock>
		s += 2;
    1668:	bb55                	j	141c <printf+0x1c2>
				a = "(null)";
    166a:	00001417          	auipc	s0,0x1
    166e:	19640413          	addi	s0,s0,406 # 2800 <enable_deadlock_detect+0xa6>
    1672:	bd2d                	j	14ac <printf+0x252>

0000000000001674 <enable_thread_io_buffer>:
{
    1674:	1101                	addi	sp,sp,-32
    1676:	e822                	sd	s0,16(sp)
    1678:	ec06                	sd	ra,24(sp)
    167a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    167c:	00001417          	auipc	s0,0x1
    1680:	27c40413          	addi	s0,s0,636 # 28f8 <buffer_len>
    1684:	05a010ef          	jal	ra,26de <mutex_create>
    1688:	10a42623          	sw	a0,268(s0)
    168c:	00054a63          	bltz	a0,16a0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1690:	4785                	li	a5,1
}
    1692:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1694:	10f42423          	sw	a5,264(s0)
}
    1698:	6442                	ld	s0,16(sp)
    169a:	64a2                	ld	s1,8(sp)
    169c:	6105                	addi	sp,sp,32
    169e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16a0:	5ed000ef          	jal	ra,248c <getpid>
    16a4:	84aa                	mv	s1,a0
    16a6:	00001517          	auipc	a0,0x1
    16aa:	16250513          	addi	a0,a0,354 # 2808 <enable_deadlock_detect+0xae>
    16ae:	4b5000ef          	jal	ra,2362 <basename>
    16b2:	872a                	mv	a4,a0
    16b4:	04800793          	li	a5,72
    16b8:	86a6                	mv	a3,s1
    16ba:	00001517          	auipc	a0,0x1
    16be:	1ce50513          	addi	a0,a0,462 # 2888 <enable_deadlock_detect+0x12e>
    16c2:	00001617          	auipc	a2,0x1
    16c6:	0ee60613          	addi	a2,a2,238 # 27b0 <enable_deadlock_detect+0x56>
    16ca:	45fd                	li	a1,31
    16cc:	b8fff0ef          	jal	ra,125a <printf>
    16d0:	557d                	li	a0,-1
    16d2:	5eb000ef          	jal	ra,24bc <exit>
	buffer_lock_enabled = 1;
    16d6:	4785                	li	a5,1
}
    16d8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16da:	10f42423          	sw	a5,264(s0)
}
    16de:	6442                	ld	s0,16(sp)
    16e0:	64a2                	ld	s1,8(sp)
    16e2:	6105                	addi	sp,sp,32
    16e4:	8082                	ret

00000000000016e6 <out_unlocked>:
{
    16e6:	7159                	addi	sp,sp,-112
    16e8:	f486                	sd	ra,104(sp)
    16ea:	f0a2                	sd	s0,96(sp)
    16ec:	eca6                	sd	s1,88(sp)
    16ee:	e8ca                	sd	s2,80(sp)
    16f0:	e4ce                	sd	s3,72(sp)
    16f2:	e0d2                	sd	s4,64(sp)
    16f4:	fc56                	sd	s5,56(sp)
    16f6:	f85a                	sd	s6,48(sp)
    16f8:	f45e                	sd	s7,40(sp)
    16fa:	f062                	sd	s8,32(sp)
    16fc:	ec66                	sd	s9,24(sp)
    16fe:	e86a                	sd	s10,16(sp)
    1700:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1702:	0e058663          	beqz	a1,17ee <out_unlocked+0x108>
    1706:	842a                	mv	s0,a0
    1708:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    170c:	4981                	li	s3,0
    170e:	00001d17          	auipc	s10,0x1
    1712:	1ead0d13          	addi	s10,s10,490 # 28f8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1716:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    171a:	00001b17          	auipc	s6,0x1
    171e:	1e6b0b13          	addi	s6,s6,486 # 2900 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1722:	10000a93          	li	s5,256
    1726:	00001c97          	auipc	s9,0x1
    172a:	0e2c8c93          	addi	s9,s9,226 # 2808 <enable_deadlock_detect+0xae>
    172e:	00001c17          	auipc	s8,0x1
    1732:	082c0c13          	addi	s8,s8,130 # 27b0 <enable_deadlock_detect+0x56>
    1736:	00001b97          	auipc	s7,0x1
    173a:	112b8b93          	addi	s7,s7,274 # 2848 <enable_deadlock_detect+0xee>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    173e:	4a29                	li	s4,10
    1740:	a031                	j	174c <out_unlocked+0x66>
    1742:	09468863          	beq	a3,s4,17d2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1746:	0405                	addi	s0,s0,1
    1748:	04848163          	beq	s1,s0,178a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    174c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1750:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1754:	0017861b          	addiw	a2,a5,1
    1758:	97ea                	add	a5,a5,s10
    175a:	00cd2023          	sw	a2,0(s10)
    175e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1762:	fec950e3          	bge	s2,a2,1742 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1766:	05561263          	bne	a2,s5,17aa <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    176a:	85da                	mv	a1,s6
    176c:	4505                	li	a0,1
    176e:	515000ef          	jal	ra,2482 <write>
    1772:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1774:	00001797          	auipc	a5,0x1
    1778:	1807a223          	sw	zero,388(a5) # 28f8 <buffer_len>
			if (r < 0) {
    177c:	06054763          	bltz	a0,17ea <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1780:	0405                	addi	s0,s0,1
			ret += r;
    1782:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1786:	fc8493e3          	bne	s1,s0,174c <out_unlocked+0x66>
}
    178a:	70a6                	ld	ra,104(sp)
    178c:	7406                	ld	s0,96(sp)
    178e:	64e6                	ld	s1,88(sp)
    1790:	6946                	ld	s2,80(sp)
    1792:	6a06                	ld	s4,64(sp)
    1794:	7ae2                	ld	s5,56(sp)
    1796:	7b42                	ld	s6,48(sp)
    1798:	7ba2                	ld	s7,40(sp)
    179a:	7c02                	ld	s8,32(sp)
    179c:	6ce2                	ld	s9,24(sp)
    179e:	6d42                	ld	s10,16(sp)
    17a0:	6da2                	ld	s11,8(sp)
    17a2:	854e                	mv	a0,s3
    17a4:	69a6                	ld	s3,72(sp)
    17a6:	6165                	addi	sp,sp,112
    17a8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17aa:	4e3000ef          	jal	ra,248c <getpid>
    17ae:	8daa                	mv	s11,a0
    17b0:	8566                	mv	a0,s9
    17b2:	3b1000ef          	jal	ra,2362 <basename>
    17b6:	872a                	mv	a4,a0
    17b8:	8662                	mv	a2,s8
    17ba:	05400793          	li	a5,84
    17be:	86ee                	mv	a3,s11
    17c0:	45fd                	li	a1,31
    17c2:	855e                	mv	a0,s7
    17c4:	a97ff0ef          	jal	ra,125a <printf>
    17c8:	557d                	li	a0,-1
    17ca:	4f3000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    17ce:	000d2603          	lw	a2,0(s10)
    17d2:	da35                	beqz	a2,1746 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17d4:	85da                	mv	a1,s6
    17d6:	4505                	li	a0,1
    17d8:	4ab000ef          	jal	ra,2482 <write>
    17dc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17de:	00001797          	auipc	a5,0x1
    17e2:	1007ad23          	sw	zero,282(a5) # 28f8 <buffer_len>
			if (r < 0) {
    17e6:	f8055de3          	bgez	a0,1780 <out_unlocked+0x9a>
    17ea:	89aa                	mv	s3,a0
    17ec:	bf79                	j	178a <out_unlocked+0xa4>
	int ret = 0;
    17ee:	4981                	li	s3,0
    17f0:	bf69                	j	178a <out_unlocked+0xa4>

00000000000017f2 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17f2:	1101                	addi	sp,sp,-32
    17f4:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17f6:	00001497          	auipc	s1,0x1
    17fa:	10248493          	addi	s1,s1,258 # 28f8 <buffer_len>
    17fe:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1800:	ec06                	sd	ra,24(sp)
    1802:	e822                	sd	s0,16(sp)
		char c = s[i];
    1804:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1808:	0017861b          	addiw	a2,a5,1
    180c:	97a6                	add	a5,a5,s1
    180e:	00e78423          	sb	a4,8(a5)
    1812:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1814:	0ff00793          	li	a5,255
    1818:	00c7cc63          	blt	a5,a2,1830 <out_unlocked.constprop.0+0x3e>
    181c:	47a9                	li	a5,10
    181e:	06f70c63          	beq	a4,a5,1896 <out_unlocked.constprop.0+0xa4>
    1822:	4601                	li	a2,0
}
    1824:	60e2                	ld	ra,24(sp)
    1826:	6442                	ld	s0,16(sp)
    1828:	64a2                	ld	s1,8(sp)
    182a:	8532                	mv	a0,a2
    182c:	6105                	addi	sp,sp,32
    182e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1830:	10000793          	li	a5,256
    1834:	02f61563          	bne	a2,a5,185e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1838:	00001597          	auipc	a1,0x1
    183c:	0c858593          	addi	a1,a1,200 # 2900 <buffer>
    1840:	4505                	li	a0,1
    1842:	441000ef          	jal	ra,2482 <write>
}
    1846:	60e2                	ld	ra,24(sp)
    1848:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    184a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    184e:	00001797          	auipc	a5,0x1
    1852:	0a07a523          	sw	zero,170(a5) # 28f8 <buffer_len>
}
    1856:	64a2                	ld	s1,8(sp)
    1858:	8532                	mv	a0,a2
    185a:	6105                	addi	sp,sp,32
    185c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    185e:	42f000ef          	jal	ra,248c <getpid>
    1862:	842a                	mv	s0,a0
    1864:	00001517          	auipc	a0,0x1
    1868:	fa450513          	addi	a0,a0,-92 # 2808 <enable_deadlock_detect+0xae>
    186c:	2f7000ef          	jal	ra,2362 <basename>
    1870:	872a                	mv	a4,a0
    1872:	00001617          	auipc	a2,0x1
    1876:	f3e60613          	addi	a2,a2,-194 # 27b0 <enable_deadlock_detect+0x56>
    187a:	05400793          	li	a5,84
    187e:	86a2                	mv	a3,s0
    1880:	45fd                	li	a1,31
    1882:	00001517          	auipc	a0,0x1
    1886:	fc650513          	addi	a0,a0,-58 # 2848 <enable_deadlock_detect+0xee>
    188a:	9d1ff0ef          	jal	ra,125a <printf>
    188e:	557d                	li	a0,-1
    1890:	42d000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    1894:	4090                	lw	a2,0(s1)
    1896:	d659                	beqz	a2,1824 <out_unlocked.constprop.0+0x32>
    1898:	b745                	j	1838 <out_unlocked.constprop.0+0x46>

000000000000189a <putchar>:
{
    189a:	7139                	addi	sp,sp,-64
    189c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    189e:	00001497          	auipc	s1,0x1
    18a2:	05a48493          	addi	s1,s1,90 # 28f8 <buffer_len>
    18a6:	1084a703          	lw	a4,264(s1)
{
    18aa:	f822                	sd	s0,48(sp)
	char byte = c;
    18ac:	0ff57413          	zext.b	s0,a0
{
    18b0:	fc06                	sd	ra,56(sp)
	char byte = c;
    18b2:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18b6:	4785                	li	a5,1
    18b8:	00f70d63          	beq	a4,a5,18d2 <putchar+0x38>
		len = out_unlocked(s, l);
    18bc:	01f10513          	addi	a0,sp,31
    18c0:	f33ff0ef          	jal	ra,17f2 <out_unlocked.constprop.0>
}
    18c4:	70e2                	ld	ra,56(sp)
    18c6:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    18c8:	862a                	mv	a2,a0
}
    18ca:	74a2                	ld	s1,40(sp)
    18cc:	8532                	mv	a0,a2
    18ce:	6121                	addi	sp,sp,64
    18d0:	8082                	ret
		mutex_lock(buffer_lock);
    18d2:	10c4a503          	lw	a0,268(s1)
    18d6:	625000ef          	jal	ra,26fa <mutex_lock>
		buffer[buffer_len++] = c;
    18da:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18dc:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18e0:	0017861b          	addiw	a2,a5,1
    18e4:	97a6                	add	a5,a5,s1
    18e6:	c090                	sw	a2,0(s1)
    18e8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ec:	02c6c263          	blt	a3,a2,1910 <putchar+0x76>
    18f0:	47a9                	li	a5,10
    18f2:	06f40d63          	beq	s0,a5,196c <putchar+0xd2>
    18f6:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18f8:	10c4a503          	lw	a0,268(s1)
    18fc:	e432                	sd	a2,8(sp)
    18fe:	609000ef          	jal	ra,2706 <mutex_unlock>
    1902:	6622                	ld	a2,8(sp)
}
    1904:	70e2                	ld	ra,56(sp)
    1906:	7442                	ld	s0,48(sp)
    1908:	74a2                	ld	s1,40(sp)
    190a:	8532                	mv	a0,a2
    190c:	6121                	addi	sp,sp,64
    190e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1910:	10000793          	li	a5,256
    1914:	02f61063          	bne	a2,a5,1934 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1918:	00001597          	auipc	a1,0x1
    191c:	fe858593          	addi	a1,a1,-24 # 2900 <buffer>
    1920:	4505                	li	a0,1
    1922:	361000ef          	jal	ra,2482 <write>
    1926:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    192a:	00001797          	auipc	a5,0x1
    192e:	fc07a723          	sw	zero,-50(a5) # 28f8 <buffer_len>
			if (r < 0) {
    1932:	b7d9                	j	18f8 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1934:	359000ef          	jal	ra,248c <getpid>
    1938:	842a                	mv	s0,a0
    193a:	00001517          	auipc	a0,0x1
    193e:	ece50513          	addi	a0,a0,-306 # 2808 <enable_deadlock_detect+0xae>
    1942:	221000ef          	jal	ra,2362 <basename>
    1946:	872a                	mv	a4,a0
    1948:	00001617          	auipc	a2,0x1
    194c:	e6860613          	addi	a2,a2,-408 # 27b0 <enable_deadlock_detect+0x56>
    1950:	05400793          	li	a5,84
    1954:	86a2                	mv	a3,s0
    1956:	45fd                	li	a1,31
    1958:	00001517          	auipc	a0,0x1
    195c:	ef050513          	addi	a0,a0,-272 # 2848 <enable_deadlock_detect+0xee>
    1960:	8fbff0ef          	jal	ra,125a <printf>
    1964:	557d                	li	a0,-1
    1966:	357000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    196a:	4090                	lw	a2,0(s1)
    196c:	d651                	beqz	a2,18f8 <putchar+0x5e>
    196e:	b76d                	j	1918 <putchar+0x7e>

0000000000001970 <puts>:
{
    1970:	7139                	addi	sp,sp,-64
    1972:	f822                	sd	s0,48(sp)
    1974:	f426                	sd	s1,40(sp)
    1976:	fc06                	sd	ra,56(sp)
    1978:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    197a:	00001417          	auipc	s0,0x1
    197e:	f7e40413          	addi	s0,s0,-130 # 28f8 <buffer_len>
{
    1982:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1984:	638000ef          	jal	ra,1fbc <strlen>
	if (buffer_lock_enabled == 1) {
    1988:	10842703          	lw	a4,264(s0)
    198c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    198e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1990:	04f70563          	beq	a4,a5,19da <puts+0x6a>
		len = out_unlocked(s, l);
    1994:	8526                	mv	a0,s1
    1996:	d51ff0ef          	jal	ra,16e6 <out_unlocked>
    199a:	892a                	mv	s2,a0
    199c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    199e:	00095963          	bgez	s2,19b0 <puts+0x40>
}
    19a2:	70e2                	ld	ra,56(sp)
    19a4:	7442                	ld	s0,48(sp)
    19a6:	7902                	ld	s2,32(sp)
    19a8:	8526                	mv	a0,s1
    19aa:	74a2                	ld	s1,40(sp)
    19ac:	6121                	addi	sp,sp,64
    19ae:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19b0:	10842703          	lw	a4,264(s0)
	char byte = c;
    19b4:	44a9                	li	s1,10
    19b6:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19ba:	4785                	li	a5,1
    19bc:	02f70e63          	beq	a4,a5,19f8 <puts+0x88>
		len = out_unlocked(s, l);
    19c0:	01f10513          	addi	a0,sp,31
    19c4:	e2fff0ef          	jal	ra,17f2 <out_unlocked.constprop.0>
}
    19c8:	70e2                	ld	ra,56(sp)
    19ca:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19cc:	41f5549b          	sraiw	s1,a0,0x1f
}
    19d0:	7902                	ld	s2,32(sp)
    19d2:	8526                	mv	a0,s1
    19d4:	74a2                	ld	s1,40(sp)
    19d6:	6121                	addi	sp,sp,64
    19d8:	8082                	ret
		mutex_lock(buffer_lock);
    19da:	e42a                	sd	a0,8(sp)
    19dc:	10c42503          	lw	a0,268(s0)
    19e0:	51b000ef          	jal	ra,26fa <mutex_lock>
		len = out_unlocked(s, l);
    19e4:	65a2                	ld	a1,8(sp)
    19e6:	8526                	mv	a0,s1
    19e8:	cffff0ef          	jal	ra,16e6 <out_unlocked>
    19ec:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19ee:	10c42503          	lw	a0,268(s0)
    19f2:	515000ef          	jal	ra,2706 <mutex_unlock>
    19f6:	b75d                	j	199c <puts+0x2c>
		mutex_lock(buffer_lock);
    19f8:	10c42503          	lw	a0,268(s0)
    19fc:	4ff000ef          	jal	ra,26fa <mutex_lock>
		buffer[buffer_len++] = c;
    1a00:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a02:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a06:	0017861b          	addiw	a2,a5,1
    1a0a:	97a2                	add	a5,a5,s0
    1a0c:	c010                	sw	a2,0(s0)
    1a0e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a12:	06c6dc63          	bge	a3,a2,1a8a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a16:	10000793          	li	a5,256
    1a1a:	02f61c63          	bne	a2,a5,1a52 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a1e:	00001597          	auipc	a1,0x1
    1a22:	ee258593          	addi	a1,a1,-286 # 2900 <buffer>
    1a26:	4505                	li	a0,1
    1a28:	25b000ef          	jal	ra,2482 <write>
			if (r < 0) {
    1a2c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a2e:	00001797          	auipc	a5,0x1
    1a32:	ec07a523          	sw	zero,-310(a5) # 28f8 <buffer_len>
			if (r < 0) {
    1a36:	04054c63          	bltz	a0,1a8e <puts+0x11e>
			if (r < buffer_len) {
    1a3a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a3c:	10c42503          	lw	a0,268(s0)
    1a40:	4c7000ef          	jal	ra,2706 <mutex_unlock>
}
    1a44:	70e2                	ld	ra,56(sp)
    1a46:	7442                	ld	s0,48(sp)
    1a48:	7902                	ld	s2,32(sp)
    1a4a:	8526                	mv	a0,s1
    1a4c:	74a2                	ld	s1,40(sp)
    1a4e:	6121                	addi	sp,sp,64
    1a50:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a52:	23b000ef          	jal	ra,248c <getpid>
    1a56:	84aa                	mv	s1,a0
    1a58:	00001517          	auipc	a0,0x1
    1a5c:	db050513          	addi	a0,a0,-592 # 2808 <enable_deadlock_detect+0xae>
    1a60:	103000ef          	jal	ra,2362 <basename>
    1a64:	872a                	mv	a4,a0
    1a66:	00001617          	auipc	a2,0x1
    1a6a:	d4a60613          	addi	a2,a2,-694 # 27b0 <enable_deadlock_detect+0x56>
    1a6e:	05400793          	li	a5,84
    1a72:	86a6                	mv	a3,s1
    1a74:	45fd                	li	a1,31
    1a76:	00001517          	auipc	a0,0x1
    1a7a:	dd250513          	addi	a0,a0,-558 # 2848 <enable_deadlock_detect+0xee>
    1a7e:	fdcff0ef          	jal	ra,125a <printf>
    1a82:	557d                	li	a0,-1
    1a84:	239000ef          	jal	ra,24bc <exit>
	if (buffer_len == 0)
    1a88:	4010                	lw	a2,0(s0)
    1a8a:	da45                	beqz	a2,1a3a <puts+0xca>
    1a8c:	bf49                	j	1a1e <puts+0xae>
    1a8e:	54fd                	li	s1,-1
    1a90:	b775                	j	1a3c <puts+0xcc>

0000000000001a92 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a92:	715d                	addi	sp,sp,-80
    1a94:	e486                	sd	ra,72(sp)
    1a96:	e0a2                	sd	s0,64(sp)
    1a98:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a9a:	14054363          	bltz	a0,1be0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a9e:	02b577bb          	remuw	a5,a0,a1
    1aa2:	00001617          	auipc	a2,0x1
    1aa6:	f6660613          	addi	a2,a2,-154 # 2a08 <digits>
	buf[16] = 0;
    1aaa:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1aae:	0005871b          	sext.w	a4,a1
    1ab2:	1782                	slli	a5,a5,0x20
    1ab4:	9381                	srli	a5,a5,0x20
    1ab6:	97b2                	add	a5,a5,a2
    1ab8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1abc:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ac0:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ac4:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ac6:	0eb56763          	bltu	a0,a1,1bb4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aca:	02e877bb          	remuw	a5,a6,a4
    1ace:	1782                	slli	a5,a5,0x20
    1ad0:	9381                	srli	a5,a5,0x20
    1ad2:	97b2                	add	a5,a5,a2
    1ad4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ad8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1adc:	02f10323          	sb	a5,38(sp)
    1ae0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ae2:	0ce86963          	bltu	a6,a4,1bb4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ae6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1aea:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1aee:	1582                	slli	a1,a1,0x20
    1af0:	9181                	srli	a1,a1,0x20
    1af2:	95b2                	add	a1,a1,a2
    1af4:	0005c583          	lbu	a1,0(a1)
    1af8:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1afc:	0007859b          	sext.w	a1,a5
    1b00:	16e6e563          	bltu	a3,a4,1c6a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b04:	02e7f6bb          	remuw	a3,a5,a4
    1b08:	1682                	slli	a3,a3,0x20
    1b0a:	9281                	srli	a3,a3,0x20
    1b0c:	96b2                	add	a3,a3,a2
    1b0e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b12:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b16:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b1a:	16e5e163          	bltu	a1,a4,1c7c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b1e:	02e876bb          	remuw	a3,a6,a4
    1b22:	1682                	slli	a3,a3,0x20
    1b24:	9281                	srli	a3,a3,0x20
    1b26:	96b2                	add	a3,a3,a2
    1b28:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b2c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b30:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b34:	14e86d63          	bltu	a6,a4,1c8e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b38:	02e5f6bb          	remuw	a3,a1,a4
    1b3c:	1682                	slli	a3,a3,0x20
    1b3e:	9281                	srli	a3,a3,0x20
    1b40:	96b2                	add	a3,a3,a2
    1b42:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b46:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b4a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b4e:	10e5e563          	bltu	a1,a4,1c58 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b52:	02e876bb          	remuw	a3,a6,a4
    1b56:	1682                	slli	a3,a3,0x20
    1b58:	9281                	srli	a3,a3,0x20
    1b5a:	96b2                	add	a3,a3,a2
    1b5c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b60:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b64:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b68:	14e86263          	bltu	a6,a4,1cac <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b6c:	02e5f6bb          	remuw	a3,a1,a4
    1b70:	1682                	slli	a3,a3,0x20
    1b72:	9281                	srli	a3,a3,0x20
    1b74:	96b2                	add	a3,a3,a2
    1b76:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b7a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b7e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b82:	14e5e463          	bltu	a1,a4,1cca <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b86:	02e876bb          	remuw	a3,a6,a4
    1b8a:	1682                	slli	a3,a3,0x20
    1b8c:	9281                	srli	a3,a3,0x20
    1b8e:	96b2                	add	a3,a3,a2
    1b90:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b94:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b98:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b9c:	14e86063          	bltu	a6,a4,1cdc <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1ba0:	1782                	slli	a5,a5,0x20
    1ba2:	9381                	srli	a5,a5,0x20
    1ba4:	97b2                	add	a5,a5,a2
    1ba6:	0007c703          	lbu	a4,0(a5)
    1baa:	4799                	li	a5,6
    1bac:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1bb0:	10054763          	bltz	a0,1cbe <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1bb4:	00001497          	auipc	s1,0x1
    1bb8:	d4448493          	addi	s1,s1,-700 # 28f8 <buffer_len>
    1bbc:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1bc0:	0828                	addi	a0,sp,24
    1bc2:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1bc4:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1bc6:	00f50433          	add	s0,a0,a5
    1bca:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1bcc:	06e68463          	beq	a3,a4,1c34 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1bd0:	8522                	mv	a0,s0
    1bd2:	b15ff0ef          	jal	ra,16e6 <out_unlocked>
}
    1bd6:	60a6                	ld	ra,72(sp)
    1bd8:	6406                	ld	s0,64(sp)
    1bda:	74e2                	ld	s1,56(sp)
    1bdc:	6161                	addi	sp,sp,80
    1bde:	8082                	ret
		x = -xx;
    1be0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1be4:	02b877bb          	remuw	a5,a6,a1
    1be8:	00001617          	auipc	a2,0x1
    1bec:	e2060613          	addi	a2,a2,-480 # 2a08 <digits>
	buf[16] = 0;
    1bf0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bf4:	0005871b          	sext.w	a4,a1
    1bf8:	1782                	slli	a5,a5,0x20
    1bfa:	9381                	srli	a5,a5,0x20
    1bfc:	97b2                	add	a5,a5,a2
    1bfe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c02:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c06:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c0a:	08b86b63          	bltu	a6,a1,1ca0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c0e:	02e8f7bb          	remuw	a5,a7,a4
    1c12:	1782                	slli	a5,a5,0x20
    1c14:	9381                	srli	a5,a5,0x20
    1c16:	97b2                	add	a5,a5,a2
    1c18:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c1c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c20:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c24:	ece8f1e3          	bgeu	a7,a4,1ae6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c28:	02d00793          	li	a5,45
    1c2c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c30:	47b5                	li	a5,13
    1c32:	b749                	j	1bb4 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c34:	10c4a503          	lw	a0,268(s1)
    1c38:	e42e                	sd	a1,8(sp)
    1c3a:	2c1000ef          	jal	ra,26fa <mutex_lock>
		len = out_unlocked(s, l);
    1c3e:	65a2                	ld	a1,8(sp)
    1c40:	8522                	mv	a0,s0
    1c42:	aa5ff0ef          	jal	ra,16e6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c46:	10c4a503          	lw	a0,268(s1)
    1c4a:	2bd000ef          	jal	ra,2706 <mutex_unlock>
}
    1c4e:	60a6                	ld	ra,72(sp)
    1c50:	6406                	ld	s0,64(sp)
    1c52:	74e2                	ld	s1,56(sp)
    1c54:	6161                	addi	sp,sp,80
    1c56:	8082                	ret
		buf[i--] = digits[x % base];
    1c58:	47a9                	li	a5,10
	if (sign)
    1c5a:	f4055de3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c5e:	02d00793          	li	a5,45
    1c62:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c66:	47a5                	li	a5,9
    1c68:	b7b1                	j	1bb4 <printint.constprop.0+0x122>
    1c6a:	47b5                	li	a5,13
	if (sign)
    1c6c:	f40554e3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c70:	02d00793          	li	a5,45
    1c74:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c78:	47b1                	li	a5,12
    1c7a:	bf2d                	j	1bb4 <printint.constprop.0+0x122>
    1c7c:	47b1                	li	a5,12
	if (sign)
    1c7e:	f2055be3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c82:	02d00793          	li	a5,45
    1c86:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c8a:	47ad                	li	a5,11
    1c8c:	b725                	j	1bb4 <printint.constprop.0+0x122>
    1c8e:	47ad                	li	a5,11
	if (sign)
    1c90:	f20552e3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c94:	02d00793          	li	a5,45
    1c98:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c9c:	47a9                	li	a5,10
    1c9e:	bf19                	j	1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca0:	02d00793          	li	a5,45
    1ca4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ca8:	47b9                	li	a5,14
    1caa:	b729                	j	1bb4 <printint.constprop.0+0x122>
    1cac:	47a5                	li	a5,9
	if (sign)
    1cae:	f00553e3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb2:	02d00793          	li	a5,45
    1cb6:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1cba:	47a1                	li	a5,8
    1cbc:	bde5                	j	1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cbe:	02d00793          	li	a5,45
    1cc2:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1cc6:	4795                	li	a5,5
    1cc8:	b5f5                	j	1bb4 <printint.constprop.0+0x122>
    1cca:	47a1                	li	a5,8
	if (sign)
    1ccc:	ee0554e3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd0:	02d00793          	li	a5,45
    1cd4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1cd8:	479d                	li	a5,7
    1cda:	bde9                	j	1bb4 <printint.constprop.0+0x122>
    1cdc:	479d                	li	a5,7
	if (sign)
    1cde:	ec055be3          	bgez	a0,1bb4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce2:	02d00793          	li	a5,45
    1ce6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cea:	4799                	li	a5,6
    1cec:	b5e1                	j	1bb4 <printint.constprop.0+0x122>

0000000000001cee <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cee:	02000793          	li	a5,32
    1cf2:	00f50663          	beq	a0,a5,1cfe <isspace+0x10>
    1cf6:	355d                	addiw	a0,a0,-9
    1cf8:	00553513          	sltiu	a0,a0,5
    1cfc:	8082                	ret
    1cfe:	4505                	li	a0,1
}
    1d00:	8082                	ret

0000000000001d02 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d02:	fd05051b          	addiw	a0,a0,-48
}
    1d06:	00a53513          	sltiu	a0,a0,10
    1d0a:	8082                	ret

0000000000001d0c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d0c:	02000613          	li	a2,32
    1d10:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d12:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d16:	ff77869b          	addiw	a3,a5,-9
    1d1a:	04c78c63          	beq	a5,a2,1d72 <atoi+0x66>
    1d1e:	0007871b          	sext.w	a4,a5
    1d22:	04d5f863          	bgeu	a1,a3,1d72 <atoi+0x66>
		s++;
	switch (*s) {
    1d26:	02b00693          	li	a3,43
    1d2a:	04d78963          	beq	a5,a3,1d7c <atoi+0x70>
    1d2e:	02d00693          	li	a3,45
    1d32:	06d78263          	beq	a5,a3,1d96 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d36:	fd07061b          	addiw	a2,a4,-48
    1d3a:	47a5                	li	a5,9
    1d3c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d3e:	4e01                	li	t3,0
	while (isdigit(*s))
    1d40:	04c7e963          	bltu	a5,a2,1d92 <atoi+0x86>
	int n = 0, neg = 0;
    1d44:	4501                	li	a0,0
	while (isdigit(*s))
    1d46:	4825                	li	a6,9
    1d48:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d4c:	0025179b          	slliw	a5,a0,0x2
    1d50:	9fa9                	addw	a5,a5,a0
    1d52:	fd07031b          	addiw	t1,a4,-48
    1d56:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d5a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d5e:	0685                	addi	a3,a3,1
    1d60:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d64:	0006071b          	sext.w	a4,a2
    1d68:	feb870e3          	bgeu	a6,a1,1d48 <atoi+0x3c>
	return neg ? n : -n;
    1d6c:	000e0563          	beqz	t3,1d76 <atoi+0x6a>
}
    1d70:	8082                	ret
		s++;
    1d72:	0505                	addi	a0,a0,1
    1d74:	bf79                	j	1d12 <atoi+0x6>
	return neg ? n : -n;
    1d76:	4113053b          	subw	a0,t1,a7
    1d7a:	8082                	ret
	while (isdigit(*s))
    1d7c:	00154703          	lbu	a4,1(a0)
    1d80:	47a5                	li	a5,9
		s++;
    1d82:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d86:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d8a:	4e01                	li	t3,0
	while (isdigit(*s))
    1d8c:	2701                	sext.w	a4,a4
    1d8e:	fac7fbe3          	bgeu	a5,a2,1d44 <atoi+0x38>
    1d92:	4501                	li	a0,0
}
    1d94:	8082                	ret
	while (isdigit(*s))
    1d96:	00154703          	lbu	a4,1(a0)
    1d9a:	47a5                	li	a5,9
		s++;
    1d9c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1da0:	fd07061b          	addiw	a2,a4,-48
    1da4:	2701                	sext.w	a4,a4
    1da6:	fec7e6e3          	bltu	a5,a2,1d92 <atoi+0x86>
		neg = 1;
    1daa:	4e05                	li	t3,1
    1dac:	bf61                	j	1d44 <atoi+0x38>

0000000000001dae <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1dae:	16060d63          	beqz	a2,1f28 <memset+0x17a>
    1db2:	40a007b3          	neg	a5,a0
    1db6:	8b9d                	andi	a5,a5,7
    1db8:	00778693          	addi	a3,a5,7
    1dbc:	482d                	li	a6,11
    1dbe:	0ff5f713          	zext.b	a4,a1
    1dc2:	fff60593          	addi	a1,a2,-1
    1dc6:	1706e263          	bltu	a3,a6,1f2a <memset+0x17c>
    1dca:	16d5ea63          	bltu	a1,a3,1f3e <memset+0x190>
    1dce:	16078563          	beqz	a5,1f38 <memset+0x18a>
    1dd2:	00e50023          	sb	a4,0(a0)
    1dd6:	4685                	li	a3,1
    1dd8:	00150593          	addi	a1,a0,1
    1ddc:	14d78c63          	beq	a5,a3,1f34 <memset+0x186>
    1de0:	00e500a3          	sb	a4,1(a0)
    1de4:	4689                	li	a3,2
    1de6:	00250593          	addi	a1,a0,2
    1dea:	14d78d63          	beq	a5,a3,1f44 <memset+0x196>
    1dee:	00e50123          	sb	a4,2(a0)
    1df2:	468d                	li	a3,3
    1df4:	00350593          	addi	a1,a0,3
    1df8:	12d78b63          	beq	a5,a3,1f2e <memset+0x180>
    1dfc:	00e501a3          	sb	a4,3(a0)
    1e00:	4691                	li	a3,4
    1e02:	00450593          	addi	a1,a0,4
    1e06:	14d78163          	beq	a5,a3,1f48 <memset+0x19a>
    1e0a:	00e50223          	sb	a4,4(a0)
    1e0e:	4695                	li	a3,5
    1e10:	00550593          	addi	a1,a0,5
    1e14:	12d78c63          	beq	a5,a3,1f4c <memset+0x19e>
    1e18:	00e502a3          	sb	a4,5(a0)
    1e1c:	469d                	li	a3,7
    1e1e:	00650593          	addi	a1,a0,6
    1e22:	12d79763          	bne	a5,a3,1f50 <memset+0x1a2>
    1e26:	00750593          	addi	a1,a0,7
    1e2a:	00e50323          	sb	a4,6(a0)
    1e2e:	481d                	li	a6,7
    1e30:	00871693          	slli	a3,a4,0x8
    1e34:	01071893          	slli	a7,a4,0x10
    1e38:	8ed9                	or	a3,a3,a4
    1e3a:	01871313          	slli	t1,a4,0x18
    1e3e:	0116e6b3          	or	a3,a3,a7
    1e42:	0066e6b3          	or	a3,a3,t1
    1e46:	02071893          	slli	a7,a4,0x20
    1e4a:	02871e13          	slli	t3,a4,0x28
    1e4e:	0116e6b3          	or	a3,a3,a7
    1e52:	40f60333          	sub	t1,a2,a5
    1e56:	03071893          	slli	a7,a4,0x30
    1e5a:	01c6e6b3          	or	a3,a3,t3
    1e5e:	0116e6b3          	or	a3,a3,a7
    1e62:	03871e13          	slli	t3,a4,0x38
    1e66:	97aa                	add	a5,a5,a0
    1e68:	ff837893          	andi	a7,t1,-8
    1e6c:	01c6e6b3          	or	a3,a3,t3
    1e70:	98be                	add	a7,a7,a5
    1e72:	e394                	sd	a3,0(a5)
    1e74:	07a1                	addi	a5,a5,8
    1e76:	ff179ee3          	bne	a5,a7,1e72 <memset+0xc4>
    1e7a:	ff837893          	andi	a7,t1,-8
    1e7e:	011587b3          	add	a5,a1,a7
    1e82:	010886bb          	addw	a3,a7,a6
    1e86:	0b130663          	beq	t1,a7,1f32 <memset+0x184>
    1e8a:	00e78023          	sb	a4,0(a5)
    1e8e:	0016859b          	addiw	a1,a3,1
    1e92:	08c5fb63          	bgeu	a1,a2,1f28 <memset+0x17a>
    1e96:	00e780a3          	sb	a4,1(a5)
    1e9a:	0026859b          	addiw	a1,a3,2
    1e9e:	08c5f563          	bgeu	a1,a2,1f28 <memset+0x17a>
    1ea2:	00e78123          	sb	a4,2(a5)
    1ea6:	0036859b          	addiw	a1,a3,3
    1eaa:	06c5ff63          	bgeu	a1,a2,1f28 <memset+0x17a>
    1eae:	00e781a3          	sb	a4,3(a5)
    1eb2:	0046859b          	addiw	a1,a3,4
    1eb6:	06c5f963          	bgeu	a1,a2,1f28 <memset+0x17a>
    1eba:	00e78223          	sb	a4,4(a5)
    1ebe:	0056859b          	addiw	a1,a3,5
    1ec2:	06c5f363          	bgeu	a1,a2,1f28 <memset+0x17a>
    1ec6:	00e782a3          	sb	a4,5(a5)
    1eca:	0066859b          	addiw	a1,a3,6
    1ece:	04c5fd63          	bgeu	a1,a2,1f28 <memset+0x17a>
    1ed2:	00e78323          	sb	a4,6(a5)
    1ed6:	0076859b          	addiw	a1,a3,7
    1eda:	04c5f763          	bgeu	a1,a2,1f28 <memset+0x17a>
    1ede:	00e783a3          	sb	a4,7(a5)
    1ee2:	0086859b          	addiw	a1,a3,8
    1ee6:	04c5f163          	bgeu	a1,a2,1f28 <memset+0x17a>
    1eea:	00e78423          	sb	a4,8(a5)
    1eee:	0096859b          	addiw	a1,a3,9
    1ef2:	02c5fb63          	bgeu	a1,a2,1f28 <memset+0x17a>
    1ef6:	00e784a3          	sb	a4,9(a5)
    1efa:	00a6859b          	addiw	a1,a3,10
    1efe:	02c5f563          	bgeu	a1,a2,1f28 <memset+0x17a>
    1f02:	00e78523          	sb	a4,10(a5)
    1f06:	00b6859b          	addiw	a1,a3,11
    1f0a:	00c5ff63          	bgeu	a1,a2,1f28 <memset+0x17a>
    1f0e:	00e785a3          	sb	a4,11(a5)
    1f12:	00c6859b          	addiw	a1,a3,12
    1f16:	00c5f963          	bgeu	a1,a2,1f28 <memset+0x17a>
    1f1a:	00e78623          	sb	a4,12(a5)
    1f1e:	26b5                	addiw	a3,a3,13
    1f20:	00c6f463          	bgeu	a3,a2,1f28 <memset+0x17a>
    1f24:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f28:	8082                	ret
    1f2a:	46ad                	li	a3,11
    1f2c:	bd79                	j	1dca <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f2e:	480d                	li	a6,3
    1f30:	b701                	j	1e30 <memset+0x82>
    1f32:	8082                	ret
    1f34:	4805                	li	a6,1
    1f36:	bded                	j	1e30 <memset+0x82>
    1f38:	85aa                	mv	a1,a0
    1f3a:	4801                	li	a6,0
    1f3c:	bdd5                	j	1e30 <memset+0x82>
    1f3e:	87aa                	mv	a5,a0
    1f40:	4681                	li	a3,0
    1f42:	b7a1                	j	1e8a <memset+0xdc>
    1f44:	4809                	li	a6,2
    1f46:	b5ed                	j	1e30 <memset+0x82>
    1f48:	4811                	li	a6,4
    1f4a:	b5dd                	j	1e30 <memset+0x82>
    1f4c:	4815                	li	a6,5
    1f4e:	b5cd                	j	1e30 <memset+0x82>
    1f50:	4819                	li	a6,6
    1f52:	bdf9                	j	1e30 <memset+0x82>

0000000000001f54 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f54:	00054783          	lbu	a5,0(a0)
    1f58:	0005c703          	lbu	a4,0(a1)
    1f5c:	00e79863          	bne	a5,a4,1f6c <strcmp+0x18>
    1f60:	0505                	addi	a0,a0,1
    1f62:	0585                	addi	a1,a1,1
    1f64:	fbe5                	bnez	a5,1f54 <strcmp>
    1f66:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f68:	9d19                	subw	a0,a0,a4
    1f6a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f6c:	0007851b          	sext.w	a0,a5
    1f70:	bfe5                	j	1f68 <strcmp+0x14>

0000000000001f72 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f72:	ca15                	beqz	a2,1fa6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f74:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f78:	167d                	addi	a2,a2,-1
    1f7a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f7e:	eb99                	bnez	a5,1f94 <strncmp+0x22>
    1f80:	a815                	j	1fb4 <strncmp+0x42>
    1f82:	00a68e63          	beq	a3,a0,1f9e <strncmp+0x2c>
    1f86:	0505                	addi	a0,a0,1
    1f88:	00f71b63          	bne	a4,a5,1f9e <strncmp+0x2c>
    1f8c:	00054783          	lbu	a5,0(a0)
    1f90:	cf89                	beqz	a5,1faa <strncmp+0x38>
    1f92:	85b2                	mv	a1,a2
    1f94:	0005c703          	lbu	a4,0(a1)
    1f98:	00158613          	addi	a2,a1,1
    1f9c:	f37d                	bnez	a4,1f82 <strncmp+0x10>
		;
	return *l - *r;
    1f9e:	0007851b          	sext.w	a0,a5
    1fa2:	9d19                	subw	a0,a0,a4
    1fa4:	8082                	ret
		return 0;
    1fa6:	4501                	li	a0,0
}
    1fa8:	8082                	ret
	return *l - *r;
    1faa:	0015c703          	lbu	a4,1(a1)
    1fae:	4501                	li	a0,0
    1fb0:	9d19                	subw	a0,a0,a4
    1fb2:	8082                	ret
    1fb4:	0005c703          	lbu	a4,0(a1)
    1fb8:	4501                	li	a0,0
    1fba:	b7e5                	j	1fa2 <strncmp+0x30>

0000000000001fbc <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1fbc:	00757793          	andi	a5,a0,7
    1fc0:	cf89                	beqz	a5,1fda <strlen+0x1e>
    1fc2:	87aa                	mv	a5,a0
    1fc4:	a029                	j	1fce <strlen+0x12>
    1fc6:	0785                	addi	a5,a5,1
    1fc8:	0077f713          	andi	a4,a5,7
    1fcc:	cb01                	beqz	a4,1fdc <strlen+0x20>
		if (!*s)
    1fce:	0007c703          	lbu	a4,0(a5)
    1fd2:	fb75                	bnez	a4,1fc6 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1fd4:	40a78533          	sub	a0,a5,a0
}
    1fd8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1fda:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fdc:	6394                	ld	a3,0(a5)
    1fde:	00001597          	auipc	a1,0x1
    1fe2:	9025b583          	ld	a1,-1790(a1) # 28e0 <enable_deadlock_detect+0x186>
    1fe6:	00001617          	auipc	a2,0x1
    1fea:	90263603          	ld	a2,-1790(a2) # 28e8 <enable_deadlock_detect+0x18e>
    1fee:	a019                	j	1ff4 <strlen+0x38>
    1ff0:	6794                	ld	a3,8(a5)
    1ff2:	07a1                	addi	a5,a5,8
    1ff4:	00b68733          	add	a4,a3,a1
    1ff8:	fff6c693          	not	a3,a3
    1ffc:	8f75                	and	a4,a4,a3
    1ffe:	8f71                	and	a4,a4,a2
    2000:	db65                	beqz	a4,1ff0 <strlen+0x34>
	for (; *s; s++)
    2002:	0007c703          	lbu	a4,0(a5)
    2006:	d779                	beqz	a4,1fd4 <strlen+0x18>
    2008:	0017c703          	lbu	a4,1(a5)
    200c:	0785                	addi	a5,a5,1
    200e:	d379                	beqz	a4,1fd4 <strlen+0x18>
    2010:	0017c703          	lbu	a4,1(a5)
    2014:	0785                	addi	a5,a5,1
    2016:	fb6d                	bnez	a4,2008 <strlen+0x4c>
    2018:	bf75                	j	1fd4 <strlen+0x18>

000000000000201a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    201a:	00757713          	andi	a4,a0,7
{
    201e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2020:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2024:	cb19                	beqz	a4,203a <memchr+0x20>
    2026:	ce25                	beqz	a2,209e <memchr+0x84>
    2028:	0007c703          	lbu	a4,0(a5)
    202c:	04b70e63          	beq	a4,a1,2088 <memchr+0x6e>
    2030:	0785                	addi	a5,a5,1
    2032:	0077f713          	andi	a4,a5,7
    2036:	167d                	addi	a2,a2,-1
    2038:	f77d                	bnez	a4,2026 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    203a:	4501                	li	a0,0
	if (n && *s != c) {
    203c:	c235                	beqz	a2,20a0 <memchr+0x86>
    203e:	0007c703          	lbu	a4,0(a5)
    2042:	04b70363          	beq	a4,a1,2088 <memchr+0x6e>
		size_t k = ONES * c;
    2046:	00001517          	auipc	a0,0x1
    204a:	8aa53503          	ld	a0,-1878(a0) # 28f0 <enable_deadlock_detect+0x196>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    204e:	471d                	li	a4,7
		size_t k = ONES * c;
    2050:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2054:	02c77a63          	bgeu	a4,a2,2088 <memchr+0x6e>
    2058:	00001897          	auipc	a7,0x1
    205c:	8888b883          	ld	a7,-1912(a7) # 28e0 <enable_deadlock_detect+0x186>
    2060:	00001817          	auipc	a6,0x1
    2064:	88883803          	ld	a6,-1912(a6) # 28e8 <enable_deadlock_detect+0x18e>
    2068:	431d                	li	t1,7
    206a:	a029                	j	2074 <memchr+0x5a>
		     w++, n -= SS)
    206c:	1661                	addi	a2,a2,-8
    206e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2070:	02c37963          	bgeu	t1,a2,20a2 <memchr+0x88>
    2074:	6398                	ld	a4,0(a5)
    2076:	8f29                	xor	a4,a4,a0
    2078:	011706b3          	add	a3,a4,a7
    207c:	fff74713          	not	a4,a4
    2080:	8f75                	and	a4,a4,a3
    2082:	01077733          	and	a4,a4,a6
    2086:	d37d                	beqz	a4,206c <memchr+0x52>
{
    2088:	853e                	mv	a0,a5
    208a:	97b2                	add	a5,a5,a2
    208c:	a021                	j	2094 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    208e:	0505                	addi	a0,a0,1
    2090:	00f50763          	beq	a0,a5,209e <memchr+0x84>
    2094:	00054703          	lbu	a4,0(a0)
    2098:	feb71be3          	bne	a4,a1,208e <memchr+0x74>
    209c:	8082                	ret
	return n ? (void *)s : 0;
    209e:	4501                	li	a0,0
}
    20a0:	8082                	ret
	return n ? (void *)s : 0;
    20a2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20a4:	f275                	bnez	a2,2088 <memchr+0x6e>
}
    20a6:	8082                	ret

00000000000020a8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20a8:	1101                	addi	sp,sp,-32
    20aa:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20ac:	862e                	mv	a2,a1
{
    20ae:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20b0:	4581                	li	a1,0
{
    20b2:	e426                	sd	s1,8(sp)
    20b4:	ec06                	sd	ra,24(sp)
    20b6:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20b8:	f63ff0ef          	jal	ra,201a <memchr>
	return p ? p - s : n;
    20bc:	c519                	beqz	a0,20ca <strnlen+0x22>
}
    20be:	60e2                	ld	ra,24(sp)
    20c0:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    20c2:	8d05                	sub	a0,a0,s1
}
    20c4:	64a2                	ld	s1,8(sp)
    20c6:	6105                	addi	sp,sp,32
    20c8:	8082                	ret
    20ca:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20cc:	8522                	mv	a0,s0
}
    20ce:	6442                	ld	s0,16(sp)
    20d0:	64a2                	ld	s1,8(sp)
    20d2:	6105                	addi	sp,sp,32
    20d4:	8082                	ret

00000000000020d6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20d6:	00a5c7b3          	xor	a5,a1,a0
    20da:	8b9d                	andi	a5,a5,7
    20dc:	eb95                	bnez	a5,2110 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20de:	0075f793          	andi	a5,a1,7
    20e2:	e7b1                	bnez	a5,212e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20e4:	6198                	ld	a4,0(a1)
    20e6:	00000617          	auipc	a2,0x0
    20ea:	7fa63603          	ld	a2,2042(a2) # 28e0 <enable_deadlock_detect+0x186>
    20ee:	00000817          	auipc	a6,0x0
    20f2:	7fa83803          	ld	a6,2042(a6) # 28e8 <enable_deadlock_detect+0x18e>
    20f6:	a029                	j	2100 <stpcpy+0x2a>
    20f8:	05a1                	addi	a1,a1,8
    20fa:	e118                	sd	a4,0(a0)
    20fc:	6198                	ld	a4,0(a1)
    20fe:	0521                	addi	a0,a0,8
    2100:	00c707b3          	add	a5,a4,a2
    2104:	fff74693          	not	a3,a4
    2108:	8ff5                	and	a5,a5,a3
    210a:	0107f7b3          	and	a5,a5,a6
    210e:	d7ed                	beqz	a5,20f8 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2110:	0005c783          	lbu	a5,0(a1)
    2114:	00f50023          	sb	a5,0(a0)
    2118:	c785                	beqz	a5,2140 <stpcpy+0x6a>
    211a:	0015c783          	lbu	a5,1(a1)
    211e:	0505                	addi	a0,a0,1
    2120:	0585                	addi	a1,a1,1
    2122:	00f50023          	sb	a5,0(a0)
    2126:	fbf5                	bnez	a5,211a <stpcpy+0x44>
		;
	return d;
}
    2128:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    212a:	0505                	addi	a0,a0,1
    212c:	df45                	beqz	a4,20e4 <stpcpy+0xe>
			if (!(*d = *s))
    212e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2132:	0585                	addi	a1,a1,1
    2134:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2138:	00f50023          	sb	a5,0(a0)
    213c:	f7fd                	bnez	a5,212a <stpcpy+0x54>
}
    213e:	8082                	ret
    2140:	8082                	ret

0000000000002142 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2142:	00a5c7b3          	xor	a5,a1,a0
    2146:	8b9d                	andi	a5,a5,7
    2148:	1a079863          	bnez	a5,22f8 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    214c:	0075f793          	andi	a5,a1,7
    2150:	16078463          	beqz	a5,22b8 <stpncpy+0x176>
    2154:	ea01                	bnez	a2,2164 <stpncpy+0x22>
    2156:	a421                	j	235e <stpncpy+0x21c>
    2158:	167d                	addi	a2,a2,-1
    215a:	0505                	addi	a0,a0,1
    215c:	14070e63          	beqz	a4,22b8 <stpncpy+0x176>
    2160:	1a060863          	beqz	a2,2310 <stpncpy+0x1ce>
    2164:	0005c783          	lbu	a5,0(a1)
    2168:	0585                	addi	a1,a1,1
    216a:	0075f713          	andi	a4,a1,7
    216e:	00f50023          	sb	a5,0(a0)
    2172:	f3fd                	bnez	a5,2158 <stpncpy+0x16>
    2174:	4805                	li	a6,1
    2176:	1a061863          	bnez	a2,2326 <stpncpy+0x1e4>
    217a:	40a007b3          	neg	a5,a0
    217e:	8b9d                	andi	a5,a5,7
    2180:	4681                	li	a3,0
    2182:	18061a63          	bnez	a2,2316 <stpncpy+0x1d4>
    2186:	00778713          	addi	a4,a5,7
    218a:	45ad                	li	a1,11
    218c:	18b76363          	bltu	a4,a1,2312 <stpncpy+0x1d0>
    2190:	1ae6eb63          	bltu	a3,a4,2346 <stpncpy+0x204>
    2194:	1a078363          	beqz	a5,233a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2198:	00050023          	sb	zero,0(a0)
    219c:	4685                	li	a3,1
    219e:	00150713          	addi	a4,a0,1
    21a2:	18d78f63          	beq	a5,a3,2340 <stpncpy+0x1fe>
    21a6:	000500a3          	sb	zero,1(a0)
    21aa:	4689                	li	a3,2
    21ac:	00250713          	addi	a4,a0,2
    21b0:	18d78e63          	beq	a5,a3,234c <stpncpy+0x20a>
    21b4:	00050123          	sb	zero,2(a0)
    21b8:	468d                	li	a3,3
    21ba:	00350713          	addi	a4,a0,3
    21be:	16d78c63          	beq	a5,a3,2336 <stpncpy+0x1f4>
    21c2:	000501a3          	sb	zero,3(a0)
    21c6:	4691                	li	a3,4
    21c8:	00450713          	addi	a4,a0,4
    21cc:	18d78263          	beq	a5,a3,2350 <stpncpy+0x20e>
    21d0:	00050223          	sb	zero,4(a0)
    21d4:	4695                	li	a3,5
    21d6:	00550713          	addi	a4,a0,5
    21da:	16d78d63          	beq	a5,a3,2354 <stpncpy+0x212>
    21de:	000502a3          	sb	zero,5(a0)
    21e2:	469d                	li	a3,7
    21e4:	00650713          	addi	a4,a0,6
    21e8:	16d79863          	bne	a5,a3,2358 <stpncpy+0x216>
    21ec:	00750713          	addi	a4,a0,7
    21f0:	00050323          	sb	zero,6(a0)
    21f4:	40f80833          	sub	a6,a6,a5
    21f8:	ff887593          	andi	a1,a6,-8
    21fc:	97aa                	add	a5,a5,a0
    21fe:	95be                	add	a1,a1,a5
    2200:	0007b023          	sd	zero,0(a5)
    2204:	07a1                	addi	a5,a5,8
    2206:	feb79de3          	bne	a5,a1,2200 <stpncpy+0xbe>
    220a:	ff887593          	andi	a1,a6,-8
    220e:	9ead                	addw	a3,a3,a1
    2210:	00b707b3          	add	a5,a4,a1
    2214:	12b80863          	beq	a6,a1,2344 <stpncpy+0x202>
    2218:	00078023          	sb	zero,0(a5)
    221c:	0016871b          	addiw	a4,a3,1
    2220:	0ec77863          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2224:	000780a3          	sb	zero,1(a5)
    2228:	0026871b          	addiw	a4,a3,2
    222c:	0ec77263          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2230:	00078123          	sb	zero,2(a5)
    2234:	0036871b          	addiw	a4,a3,3
    2238:	0cc77c63          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    223c:	000781a3          	sb	zero,3(a5)
    2240:	0046871b          	addiw	a4,a3,4
    2244:	0cc77663          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2248:	00078223          	sb	zero,4(a5)
    224c:	0056871b          	addiw	a4,a3,5
    2250:	0cc77063          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2254:	000782a3          	sb	zero,5(a5)
    2258:	0066871b          	addiw	a4,a3,6
    225c:	0ac77a63          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2260:	00078323          	sb	zero,6(a5)
    2264:	0076871b          	addiw	a4,a3,7
    2268:	0ac77463          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    226c:	000783a3          	sb	zero,7(a5)
    2270:	0086871b          	addiw	a4,a3,8
    2274:	08c77e63          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2278:	00078423          	sb	zero,8(a5)
    227c:	0096871b          	addiw	a4,a3,9
    2280:	08c77863          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2284:	000784a3          	sb	zero,9(a5)
    2288:	00a6871b          	addiw	a4,a3,10
    228c:	08c77263          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    2290:	00078523          	sb	zero,10(a5)
    2294:	00b6871b          	addiw	a4,a3,11
    2298:	06c77c63          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    229c:	000785a3          	sb	zero,11(a5)
    22a0:	00c6871b          	addiw	a4,a3,12
    22a4:	06c77663          	bgeu	a4,a2,2310 <stpncpy+0x1ce>
    22a8:	00078623          	sb	zero,12(a5)
    22ac:	26b5                	addiw	a3,a3,13
    22ae:	06c6f163          	bgeu	a3,a2,2310 <stpncpy+0x1ce>
    22b2:	000786a3          	sb	zero,13(a5)
    22b6:	8082                	ret
			;
		if (!n || !*s)
    22b8:	c645                	beqz	a2,2360 <stpncpy+0x21e>
    22ba:	0005c783          	lbu	a5,0(a1)
    22be:	ea078be3          	beqz	a5,2174 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22c2:	479d                	li	a5,7
    22c4:	02c7ff63          	bgeu	a5,a2,2302 <stpncpy+0x1c0>
    22c8:	00000897          	auipc	a7,0x0
    22cc:	6188b883          	ld	a7,1560(a7) # 28e0 <enable_deadlock_detect+0x186>
    22d0:	00000817          	auipc	a6,0x0
    22d4:	61883803          	ld	a6,1560(a6) # 28e8 <enable_deadlock_detect+0x18e>
    22d8:	431d                	li	t1,7
    22da:	6198                	ld	a4,0(a1)
    22dc:	011707b3          	add	a5,a4,a7
    22e0:	fff74693          	not	a3,a4
    22e4:	8ff5                	and	a5,a5,a3
    22e6:	0107f7b3          	and	a5,a5,a6
    22ea:	ef81                	bnez	a5,2302 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22ec:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22ee:	1661                	addi	a2,a2,-8
    22f0:	05a1                	addi	a1,a1,8
    22f2:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22f4:	fec363e3          	bltu	t1,a2,22da <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22f8:	e609                	bnez	a2,2302 <stpncpy+0x1c0>
    22fa:	a08d                	j	235c <stpncpy+0x21a>
    22fc:	167d                	addi	a2,a2,-1
    22fe:	0505                	addi	a0,a0,1
    2300:	ca01                	beqz	a2,2310 <stpncpy+0x1ce>
    2302:	0005c783          	lbu	a5,0(a1)
    2306:	0585                	addi	a1,a1,1
    2308:	00f50023          	sb	a5,0(a0)
    230c:	fbe5                	bnez	a5,22fc <stpncpy+0x1ba>
		;
tail:
    230e:	b59d                	j	2174 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2310:	8082                	ret
    2312:	472d                	li	a4,11
    2314:	bdb5                	j	2190 <stpncpy+0x4e>
    2316:	00778713          	addi	a4,a5,7
    231a:	45ad                	li	a1,11
    231c:	fff60693          	addi	a3,a2,-1
    2320:	e6b778e3          	bgeu	a4,a1,2190 <stpncpy+0x4e>
    2324:	b7fd                	j	2312 <stpncpy+0x1d0>
    2326:	40a007b3          	neg	a5,a0
    232a:	8832                	mv	a6,a2
    232c:	8b9d                	andi	a5,a5,7
    232e:	4681                	li	a3,0
    2330:	e4060be3          	beqz	a2,2186 <stpncpy+0x44>
    2334:	b7cd                	j	2316 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2336:	468d                	li	a3,3
    2338:	bd75                	j	21f4 <stpncpy+0xb2>
    233a:	872a                	mv	a4,a0
    233c:	4681                	li	a3,0
    233e:	bd5d                	j	21f4 <stpncpy+0xb2>
    2340:	4685                	li	a3,1
    2342:	bd4d                	j	21f4 <stpncpy+0xb2>
    2344:	8082                	ret
    2346:	87aa                	mv	a5,a0
    2348:	4681                	li	a3,0
    234a:	b5f9                	j	2218 <stpncpy+0xd6>
    234c:	4689                	li	a3,2
    234e:	b55d                	j	21f4 <stpncpy+0xb2>
    2350:	4691                	li	a3,4
    2352:	b54d                	j	21f4 <stpncpy+0xb2>
    2354:	4695                	li	a3,5
    2356:	bd79                	j	21f4 <stpncpy+0xb2>
    2358:	4699                	li	a3,6
    235a:	bd69                	j	21f4 <stpncpy+0xb2>
    235c:	8082                	ret
    235e:	8082                	ret
    2360:	8082                	ret

0000000000002362 <basename>:

char *basename(char *s)
{
    2362:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2364:	c54d                	beqz	a0,240e <basename+0xac>
    2366:	00054783          	lbu	a5,0(a0)
		return ".";
    236a:	00000517          	auipc	a0,0x0
    236e:	56e50513          	addi	a0,a0,1390 # 28d8 <enable_deadlock_detect+0x17e>
	if (!s || !*s)
    2372:	e391                	bnez	a5,2376 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2374:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2376:	0076f713          	andi	a4,a3,7
    237a:	87b6                	mv	a5,a3
    237c:	cf51                	beqz	a4,2418 <basename+0xb6>
    237e:	0785                	addi	a5,a5,1
    2380:	0077f713          	andi	a4,a5,7
    2384:	c729                	beqz	a4,23ce <basename+0x6c>
		if (!*s)
    2386:	0007c703          	lbu	a4,0(a5)
    238a:	fb75                	bnez	a4,237e <basename+0x1c>
	return s - a;
    238c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    238e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2390:	cf8d                	beqz	a5,23ca <basename+0x68>
    2392:	00f68733          	add	a4,a3,a5
    2396:	02f00593          	li	a1,47
    239a:	a031                	j	23a6 <basename+0x44>
		s[i] = 0;
    239c:	00070023          	sb	zero,0(a4) # 10001000 <.got.plt+0xfffe5d0>
	for (; i && s[i] == '/'; i--)
    23a0:	17fd                	addi	a5,a5,-1
    23a2:	177d                	addi	a4,a4,-1
    23a4:	c39d                	beqz	a5,23ca <basename+0x68>
    23a6:	00074603          	lbu	a2,0(a4)
    23aa:	feb609e3          	beq	a2,a1,239c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23ae:	02f00613          	li	a2,47
    23b2:	a011                	j	23b6 <basename+0x54>
    23b4:	cb99                	beqz	a5,23ca <basename+0x68>
    23b6:	853e                	mv	a0,a5
    23b8:	17fd                	addi	a5,a5,-1
    23ba:	00f68733          	add	a4,a3,a5
    23be:	00074703          	lbu	a4,0(a4)
    23c2:	fec719e3          	bne	a4,a2,23b4 <basename+0x52>
	return s + i;
    23c6:	9536                	add	a0,a0,a3
    23c8:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23ca:	8536                	mv	a0,a3
    23cc:	8082                	ret
    23ce:	6390                	ld	a2,0(a5)
    23d0:	00000517          	auipc	a0,0x0
    23d4:	51053503          	ld	a0,1296(a0) # 28e0 <enable_deadlock_detect+0x186>
    23d8:	00000597          	auipc	a1,0x0
    23dc:	5105b583          	ld	a1,1296(a1) # 28e8 <enable_deadlock_detect+0x18e>
    23e0:	fff64713          	not	a4,a2
    23e4:	962a                	add	a2,a2,a0
    23e6:	8f71                	and	a4,a4,a2
    23e8:	8f6d                	and	a4,a4,a1
    23ea:	eb11                	bnez	a4,23fe <basename+0x9c>
    23ec:	6790                	ld	a2,8(a5)
    23ee:	07a1                	addi	a5,a5,8
    23f0:	00a60733          	add	a4,a2,a0
    23f4:	fff64613          	not	a2,a2
    23f8:	8f71                	and	a4,a4,a2
    23fa:	8f6d                	and	a4,a4,a1
    23fc:	db65                	beqz	a4,23ec <basename+0x8a>
	for (; *s; s++)
    23fe:	0007c703          	lbu	a4,0(a5)
    2402:	d749                	beqz	a4,238c <basename+0x2a>
    2404:	0017c703          	lbu	a4,1(a5)
    2408:	0785                	addi	a5,a5,1
    240a:	ff6d                	bnez	a4,2404 <basename+0xa2>
    240c:	b741                	j	238c <basename+0x2a>
		return ".";
    240e:	00000517          	auipc	a0,0x0
    2412:	4ca50513          	addi	a0,a0,1226 # 28d8 <enable_deadlock_detect+0x17e>
    2416:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2418:	6290                	ld	a2,0(a3)
    241a:	00000517          	auipc	a0,0x0
    241e:	4c653503          	ld	a0,1222(a0) # 28e0 <enable_deadlock_detect+0x186>
    2422:	00000597          	auipc	a1,0x0
    2426:	4c65b583          	ld	a1,1222(a1) # 28e8 <enable_deadlock_detect+0x18e>
    242a:	fff64713          	not	a4,a2
    242e:	962a                	add	a2,a2,a0
    2430:	8f71                	and	a4,a4,a2
    2432:	8f6d                	and	a4,a4,a1
    2434:	df45                	beqz	a4,23ec <basename+0x8a>
    2436:	b7f9                	j	2404 <basename+0xa2>

0000000000002438 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2438:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    243c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    243e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2442:	2501                	sext.w	a0,a0
    2444:	8082                	ret

0000000000002446 <close>:

int close(int fd)
{
	if (fd == 1) {
    2446:	4785                	li	a5,1
    2448:	00f50863          	beq	a0,a5,2458 <close+0x12>
	register long a7 __asm__("a7") = n;
    244c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2450:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2454:	2501                	sext.w	a0,a0
    2456:	8082                	ret
{
    2458:	1101                	addi	sp,sp,-32
    245a:	ec06                	sd	ra,24(sp)
    245c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    245e:	cdffe0ef          	jal	ra,113c <__write_buffer>
		__clear_buffer();
    2462:	d03fe0ef          	jal	ra,1164 <__clear_buffer>
    2466:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2468:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    246c:	00000073          	ecall
}
    2470:	60e2                	ld	ra,24(sp)
    2472:	2501                	sext.w	a0,a0
    2474:	6105                	addi	sp,sp,32
    2476:	8082                	ret

0000000000002478 <read>:
	register long a7 __asm__("a7") = n;
    2478:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    247c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2480:	8082                	ret

0000000000002482 <write>:
	register long a7 __asm__("a7") = n;
    2482:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2486:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    248a:	8082                	ret

000000000000248c <getpid>:
	register long a7 __asm__("a7") = n;
    248c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2490:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2494:	2501                	sext.w	a0,a0
    2496:	8082                	ret

0000000000002498 <getppid>:
	register long a7 __asm__("a7") = n;
    2498:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    249c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24a0:	2501                	sext.w	a0,a0
    24a2:	8082                	ret

00000000000024a4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24a4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24a8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24ac:	2501                	sext.w	a0,a0
    24ae:	8082                	ret

00000000000024b0 <fork>:
	register long a7 __asm__("a7") = n;
    24b0:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24b4:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24b8:	2501                	sext.w	a0,a0
    24ba:	8082                	ret

00000000000024bc <exit>:

void exit(int code)
{
    24bc:	1141                	addi	sp,sp,-16
    24be:	e406                	sd	ra,8(sp)
    24c0:	e022                	sd	s0,0(sp)
    24c2:	842a                	mv	s0,a0
	__write_buffer();
    24c4:	c79fe0ef          	jal	ra,113c <__write_buffer>
	__clear_buffer();
    24c8:	c9dfe0ef          	jal	ra,1164 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24cc:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24d0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24d2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24d6:	60a2                	ld	ra,8(sp)
    24d8:	6402                	ld	s0,0(sp)
    24da:	0141                	addi	sp,sp,16
    24dc:	8082                	ret

00000000000024de <waitpid>:
	register long a7 __asm__("a7") = n;
    24de:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24e6:	2501                	sext.w	a0,a0
    24e8:	8082                	ret

00000000000024ea <exec>:
	register long a7 __asm__("a7") = n;
    24ea:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ee:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24f2:	2501                	sext.w	a0,a0
    24f4:	8082                	ret

00000000000024f6 <get_mtime>:

int64 get_mtime()
{
    24f6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24f8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24fc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    24fe:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2500:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2504:	2501                	sext.w	a0,a0
    2506:	ed01                	bnez	a0,251e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2508:	6722                	ld	a4,8(sp)
    250a:	3e800793          	li	a5,1000
    250e:	6682                	ld	a3,0(sp)
    2510:	02f75733          	divu	a4,a4,a5
    2514:	02d78533          	mul	a0,a5,a3
    2518:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    251a:	0141                	addi	sp,sp,16
    251c:	8082                	ret
	return -1;
    251e:	557d                	li	a0,-1
    2520:	bfed                	j	251a <get_mtime+0x24>

0000000000002522 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2522:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2526:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    252a:	2501                	sext.w	a0,a0
    252c:	8082                	ret

000000000000252e <sleep>:

int sleep(unsigned long long time)
{
    252e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2530:	880a                	mv	a6,sp
{
    2532:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2534:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2538:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    253a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    253c:	00000073          	ecall
	if (err == 0) {
    2540:	2501                	sext.w	a0,a0
    2542:	ed31                	bnez	a0,259e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2544:	6722                	ld	a4,8(sp)
    2546:	3e800793          	li	a5,1000
    254a:	6682                	ld	a3,0(sp)
    254c:	02f75733          	divu	a4,a4,a5
    2550:	02d787b3          	mul	a5,a5,a3
    2554:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2556:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    255a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    255c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    255e:	00000073          	ecall
	if (err == 0) {
    2562:	2501                	sext.w	a0,a0
    2564:	e915                	bnez	a0,2598 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2566:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2568:	3e800693          	li	a3,1000
    256c:	a819                	j	2582 <sleep+0x54>
	__asm_syscall("r"(a7))
    256e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2572:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2576:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2578:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    257a:	00000073          	ecall
	if (err == 0) {
    257e:	2501                	sext.w	a0,a0
    2580:	ed01                	bnez	a0,2598 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2582:	6722                	ld	a4,8(sp)
    2584:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2586:	07c00893          	li	a7,124
    258a:	02d75733          	divu	a4,a4,a3
    258e:	02f687b3          	mul	a5,a3,a5
    2592:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2594:	fcc7ede3          	bltu	a5,a2,256e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2598:	4501                	li	a0,0
    259a:	0141                	addi	sp,sp,16
    259c:	8082                	ret
    259e:	57fd                	li	a5,-1
    25a0:	bf5d                	j	2556 <sleep+0x28>

00000000000025a2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25a2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25a6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25aa:	2501                	sext.w	a0,a0
    25ac:	8082                	ret

00000000000025ae <set_priority>:
	register long a7 __asm__("a7") = n;
    25ae:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25b2:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25b6:	2501                	sext.w	a0,a0
    25b8:	8082                	ret

00000000000025ba <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25ba:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25be:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    25c2:	2501                	sext.w	a0,a0
    25c4:	8082                	ret

00000000000025c6 <munmap>:
	register long a7 __asm__("a7") = n;
    25c6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ca:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    25ce:	2501                	sext.w	a0,a0
    25d0:	8082                	ret

00000000000025d2 <wait>:

int wait(int *code)
{
    25d2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25d4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25d8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25da:	00000073          	ecall
	return waitpid(-1, code);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret

00000000000025e2 <spawn>:
	register long a7 __asm__("a7") = n;
    25e2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25e6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25ea:	2501                	sext.w	a0,a0
    25ec:	8082                	ret

00000000000025ee <pipe>:
	register long a7 __asm__("a7") = n;
    25ee:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25f2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25f6:	2501                	sext.w	a0,a0
    25f8:	8082                	ret

00000000000025fa <mailread>:
	register long a7 __asm__("a7") = n;
    25fa:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fe:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2602:	2501                	sext.w	a0,a0
    2604:	8082                	ret

0000000000002606 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2606:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    260a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    260e:	2501                	sext.w	a0,a0
    2610:	8082                	ret

0000000000002612 <fstat>:
	register long a7 __asm__("a7") = n;
    2612:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2616:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    261a:	2501                	sext.w	a0,a0
    261c:	8082                	ret

000000000000261e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    261e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2620:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2624:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2626:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    262a:	2501                	sext.w	a0,a0
    262c:	8082                	ret

000000000000262e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    262e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2630:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2634:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2636:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <link>:

int link(char *old_path, char *new_path)
{
    263e:	87aa                	mv	a5,a0
    2640:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2642:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2646:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    264a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    264c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2650:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2652:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret

000000000000265a <unlink>:

int unlink(char *path)
{
    265a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    265c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2660:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2664:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2666:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    266a:	2501                	sext.w	a0,a0
    266c:	8082                	ret

000000000000266e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    266e:	00000797          	auipc	a5,0x0
    2672:	3ba7b783          	ld	a5,954(a5) # 2a28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2676:	439c                	lw	a5,0(a5)
    2678:	c799                	beqz	a5,2686 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    267a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2682:	2501                	sext.w	a0,a0
    2684:	8082                	ret
{
    2686:	1101                	addi	sp,sp,-32
    2688:	ec06                	sd	ra,24(sp)
    268a:	e42e                	sd	a1,8(sp)
    268c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    268e:	fe7fe0ef          	jal	ra,1674 <enable_thread_io_buffer>
    2692:	65a2                	ld	a1,8(sp)
    2694:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2696:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    269a:	00000073          	ecall
}
    269e:	60e2                	ld	ra,24(sp)
    26a0:	2501                	sext.w	a0,a0
    26a2:	6105                	addi	sp,sp,32
    26a4:	8082                	ret

00000000000026a6 <gettid>:
	register long a7 __asm__("a7") = n;
    26a6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26aa:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <waittid>:

int waittid(int tid)
{
    26b2:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26b4:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26b8:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26bc:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    26be:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26c0:	00e51e63          	bne	a0,a4,26dc <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    26c4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26c8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26cc:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26d0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26d2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26d6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26d8:	fee506e3          	beq	a0,a4,26c4 <waittid+0x12>
	}
	return ret;
}
    26dc:	8082                	ret

00000000000026de <mutex_create>:
	register long a7 __asm__("a7") = n;
    26de:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26e2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26e4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26e8:	2501                	sext.w	a0,a0
    26ea:	8082                	ret

00000000000026ec <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26ec:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26f0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26f2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26f6:	2501                	sext.w	a0,a0
    26f8:	8082                	ret

00000000000026fa <mutex_lock>:
	register long a7 __asm__("a7") = n;
    26fa:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    26fe:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2702:	2501                	sext.w	a0,a0
    2704:	8082                	ret

0000000000002706 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2706:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    270a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    270e:	2501                	sext.w	a0,a0
    2710:	8082                	ret

0000000000002712 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2712:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2716:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    271a:	2501                	sext.w	a0,a0
    271c:	8082                	ret

000000000000271e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    271e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2722:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2726:	2501                	sext.w	a0,a0
    2728:	8082                	ret

000000000000272a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    272a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    272e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2732:	2501                	sext.w	a0,a0
    2734:	8082                	ret

0000000000002736 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2736:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    273a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    273e:	2501                	sext.w	a0,a0
    2740:	8082                	ret

0000000000002742 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2742:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2746:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    274e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2752:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    275a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    275e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2762:	2501                	sext.w	a0,a0
    2764:	8082                	ret
