
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_forktest0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	aa91                	j	1154 <__start_main>

0000000000001002 <main>:
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    1002:	7179                	addi	sp,sp,-48
	assert(wait(0) < 0);
    1004:	4501                	li	a0,0
{
    1006:	f406                	sd	ra,40(sp)
    1008:	f022                	sd	s0,32(sp)
    100a:	ec26                	sd	s1,24(sp)
    100c:	e84a                	sd	s2,16(sp)
	assert(wait(0) < 0);
    100e:	618010ef          	jal	ra,2626 <wait>
    1012:	02054c63          	bltz	a0,104a <main+0x48>
    1016:	4ca010ef          	jal	ra,24e0 <getpid>
    101a:	842a                	mv	s0,a0
    101c:	00001517          	auipc	a0,0x1
    1020:	7a450513          	addi	a0,a0,1956 # 27c0 <enable_deadlock_detect+0x12>
    1024:	392010ef          	jal	ra,23b6 <basename>
    1028:	872a                	mv	a4,a0
    102a:	479d                	li	a5,7
    102c:	00001517          	auipc	a0,0x1
    1030:	7e450513          	addi	a0,a0,2020 # 2810 <enable_deadlock_detect+0x62>
    1034:	86a2                	mv	a3,s0
    1036:	00001617          	auipc	a2,0x1
    103a:	7d260613          	addi	a2,a2,2002 # 2808 <enable_deadlock_detect+0x5a>
    103e:	45fd                	li	a1,31
    1040:	26e000ef          	jal	ra,12ae <printf>
    1044:	557d                	li	a0,-1
    1046:	4ca010ef          	jal	ra,2510 <exit>
	printf("sys_wait without child process test passed!\n");
    104a:	00001517          	auipc	a0,0x1
    104e:	7fe50513          	addi	a0,a0,2046 # 2848 <enable_deadlock_detect+0x9a>
    1052:	25c000ef          	jal	ra,12ae <printf>
	printf("parent start, pid = %d!\n", getpid());
    1056:	48a010ef          	jal	ra,24e0 <getpid>
    105a:	85aa                	mv	a1,a0
    105c:	00002517          	auipc	a0,0x2
    1060:	81c50513          	addi	a0,a0,-2020 # 2878 <enable_deadlock_detect+0xca>
    1064:	24a000ef          	jal	ra,12ae <printf>
	int pid = fork();
    1068:	49c010ef          	jal	ra,2504 <fork>
    106c:	842a                	mv	s0,a0
	if (pid == 0) {
    106e:	e905                	bnez	a0,109e <main+0x9c>
		// child process
		printf("hello child process!\n");
    1070:	00002517          	auipc	a0,0x2
    1074:	82850513          	addi	a0,a0,-2008 # 2898 <enable_deadlock_detect+0xea>
    1078:	236000ef          	jal	ra,12ae <printf>
		exit(100);
    107c:	06400513          	li	a0,100
    1080:	490010ef          	jal	ra,2510 <exit>
		printf("ready waiting on parent process!\n");
		assert_eq(pid, wait(&xstate));
		assert_eq(xstate, 100);
		printf("child process pid = %d, exit code = %d\n", pid, xstate);
	}
	printf("forktest0 pass.\n");
    1084:	00002517          	auipc	a0,0x2
    1088:	8b450513          	addi	a0,a0,-1868 # 2938 <enable_deadlock_detect+0x18a>
    108c:	222000ef          	jal	ra,12ae <printf>
	return 0;
    1090:	70a2                	ld	ra,40(sp)
    1092:	7402                	ld	s0,32(sp)
    1094:	64e2                	ld	s1,24(sp)
    1096:	6942                	ld	s2,16(sp)
    1098:	4501                	li	a0,0
    109a:	6145                	addi	sp,sp,48
    109c:	8082                	ret
		printf("ready waiting on parent process!\n");
    109e:	00002517          	auipc	a0,0x2
    10a2:	81250513          	addi	a0,a0,-2030 # 28b0 <enable_deadlock_detect+0x102>
		int xstate = 0;
    10a6:	c602                	sw	zero,12(sp)
		assert_eq(pid, wait(&xstate));
    10a8:	0064                	addi	s1,sp,12
		printf("ready waiting on parent process!\n");
    10aa:	204000ef          	jal	ra,12ae <printf>
		assert_eq(pid, wait(&xstate));
    10ae:	8526                	mv	a0,s1
    10b0:	576010ef          	jal	ra,2626 <wait>
    10b4:	04851e63          	bne	a0,s0,1110 <main+0x10e>
		assert_eq(xstate, 100);
    10b8:	4632                	lw	a2,12(sp)
    10ba:	06400793          	li	a5,100
    10be:	00f61a63          	bne	a2,a5,10d2 <main+0xd0>
		printf("child process pid = %d, exit code = %d\n", pid, xstate);
    10c2:	85a2                	mv	a1,s0
    10c4:	00002517          	auipc	a0,0x2
    10c8:	84c50513          	addi	a0,a0,-1972 # 2910 <enable_deadlock_detect+0x162>
    10cc:	1e2000ef          	jal	ra,12ae <printf>
    10d0:	bf55                	j	1084 <main+0x82>
		assert_eq(xstate, 100);
    10d2:	40e010ef          	jal	ra,24e0 <getpid>
    10d6:	84aa                	mv	s1,a0
    10d8:	00001517          	auipc	a0,0x1
    10dc:	6e850513          	addi	a0,a0,1768 # 27c0 <enable_deadlock_detect+0x12>
    10e0:	2d6010ef          	jal	ra,23b6 <basename>
    10e4:	4832                	lw	a6,12(sp)
    10e6:	872a                	mv	a4,a0
    10e8:	00001617          	auipc	a2,0x1
    10ec:	72060613          	addi	a2,a2,1824 # 2808 <enable_deadlock_detect+0x5a>
    10f0:	06400893          	li	a7,100
    10f4:	47d1                	li	a5,20
    10f6:	86a6                	mv	a3,s1
    10f8:	45fd                	li	a1,31
    10fa:	00001517          	auipc	a0,0x1
    10fe:	7de50513          	addi	a0,a0,2014 # 28d8 <enable_deadlock_detect+0x12a>
    1102:	1ac000ef          	jal	ra,12ae <printf>
    1106:	557d                	li	a0,-1
    1108:	408010ef          	jal	ra,2510 <exit>
    110c:	4632                	lw	a2,12(sp)
    110e:	bf55                	j	10c2 <main+0xc0>
		assert_eq(pid, wait(&xstate));
    1110:	3d0010ef          	jal	ra,24e0 <getpid>
    1114:	892a                	mv	s2,a0
    1116:	00001517          	auipc	a0,0x1
    111a:	6aa50513          	addi	a0,a0,1706 # 27c0 <enable_deadlock_detect+0x12>
    111e:	298010ef          	jal	ra,23b6 <basename>
    1122:	872a                	mv	a4,a0
    1124:	8526                	mv	a0,s1
    1126:	84ba                	mv	s1,a4
    1128:	4fe010ef          	jal	ra,2626 <wait>
    112c:	88aa                	mv	a7,a0
    112e:	8822                	mv	a6,s0
    1130:	00001517          	auipc	a0,0x1
    1134:	7a850513          	addi	a0,a0,1960 # 28d8 <enable_deadlock_detect+0x12a>
    1138:	47cd                	li	a5,19
    113a:	8726                	mv	a4,s1
    113c:	86ca                	mv	a3,s2
    113e:	00001617          	auipc	a2,0x1
    1142:	6ca60613          	addi	a2,a2,1738 # 2808 <enable_deadlock_detect+0x5a>
    1146:	45fd                	li	a1,31
    1148:	166000ef          	jal	ra,12ae <printf>
    114c:	557d                	li	a0,-1
    114e:	3c2010ef          	jal	ra,2510 <exit>
    1152:	b79d                	j	10b8 <main+0xb6>

0000000000001154 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1154:	1141                	addi	sp,sp,-16
    1156:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1158:	eabff0ef          	jal	ra,1002 <main>
    115c:	3b4010ef          	jal	ra,2510 <exit>
	return 0;
    1160:	60a2                	ld	ra,8(sp)
    1162:	4501                	li	a0,0
    1164:	0141                	addi	sp,sp,16
    1166:	8082                	ret

0000000000001168 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1168:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    116a:	4605                	li	a2,1
    116c:	00f10593          	addi	a1,sp,15
    1170:	4501                	li	a0,0
{
    1172:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1174:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1178:	354010ef          	jal	ra,24cc <read>
    117c:	4785                	li	a5,1
    117e:	00f51763          	bne	a0,a5,118c <getchar+0x24>
		return byte;
    1182:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1186:	60e2                	ld	ra,24(sp)
    1188:	6105                	addi	sp,sp,32
    118a:	8082                	ret
		return EOF;
    118c:	557d                	li	a0,-1
    118e:	bfe5                	j	1186 <getchar+0x1e>

0000000000001190 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1190:	00002517          	auipc	a0,0x2
    1194:	8b852503          	lw	a0,-1864(a0) # 2a48 <buffer_len>
    1198:	e111                	bnez	a0,119c <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    119a:	8082                	ret
{
    119c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    119e:	862a                	mv	a2,a0
    11a0:	00002597          	auipc	a1,0x2
    11a4:	8b058593          	addi	a1,a1,-1872 # 2a50 <buffer>
    11a8:	4505                	li	a0,1
{
    11aa:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11ac:	32a010ef          	jal	ra,24d6 <write>
}
    11b0:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11b2:	2501                	sext.w	a0,a0
}
    11b4:	0141                	addi	sp,sp,16
    11b6:	8082                	ret

00000000000011b8 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    11b8:	00002797          	auipc	a5,0x2
    11bc:	8807a823          	sw	zero,-1904(a5) # 2a48 <buffer_len>
}
    11c0:	8082                	ret

00000000000011c2 <__fflush>:
	if (buffer_len == 0)
    11c2:	00002517          	auipc	a0,0x2
    11c6:	88652503          	lw	a0,-1914(a0) # 2a48 <buffer_len>
    11ca:	e511                	bnez	a0,11d6 <__fflush+0x14>
	buffer_len = 0;
    11cc:	00002797          	auipc	a5,0x2
    11d0:	8607ae23          	sw	zero,-1924(a5) # 2a48 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11d4:	8082                	ret
{
    11d6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11d8:	862a                	mv	a2,a0
    11da:	00002597          	auipc	a1,0x2
    11de:	87658593          	addi	a1,a1,-1930 # 2a50 <buffer>
    11e2:	4505                	li	a0,1
{
    11e4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11e6:	2f0010ef          	jal	ra,24d6 <write>
	return r >= 0 ? 0 : r;
    11ea:	0005079b          	sext.w	a5,a0
}
    11ee:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11f0:	0017a793          	slti	a5,a5,1
    11f4:	40f007bb          	negw	a5,a5
    11f8:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11fa:	00002797          	auipc	a5,0x2
    11fe:	8407a723          	sw	zero,-1970(a5) # 2a48 <buffer_len>
	return r >= 0 ? 0 : r;
    1202:	2501                	sext.w	a0,a0
}
    1204:	0141                	addi	sp,sp,16
    1206:	8082                	ret

0000000000001208 <fflush>:

int fflush(int fd)
{
    1208:	1101                	addi	sp,sp,-32
    120a:	e822                	sd	s0,16(sp)
    120c:	ec06                	sd	ra,24(sp)
    120e:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1210:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1212:	4401                	li	s0,0
	if (fd == 1) {
    1214:	00e50863          	beq	a0,a4,1224 <fflush+0x1c>
}
    1218:	60e2                	ld	ra,24(sp)
    121a:	8522                	mv	a0,s0
    121c:	6442                	ld	s0,16(sp)
    121e:	64a2                	ld	s1,8(sp)
    1220:	6105                	addi	sp,sp,32
    1222:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1224:	00002497          	auipc	s1,0x2
    1228:	82448493          	addi	s1,s1,-2012 # 2a48 <buffer_len>
    122c:	1084a703          	lw	a4,264(s1)
    1230:	02a70e63          	beq	a4,a0,126c <fflush+0x64>
	if (buffer_len == 0)
    1234:	4080                	lw	s0,0(s1)
    1236:	c00d                	beqz	s0,1258 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1238:	8622                	mv	a2,s0
    123a:	00002597          	auipc	a1,0x2
    123e:	81658593          	addi	a1,a1,-2026 # 2a50 <buffer>
    1242:	294010ef          	jal	ra,24d6 <write>
	return r >= 0 ? 0 : r;
    1246:	0005079b          	sext.w	a5,a0
    124a:	0017a793          	slti	a5,a5,1
    124e:	40f007bb          	negw	a5,a5
    1252:	8d7d                	and	a0,a0,a5
    1254:	0005041b          	sext.w	s0,a0
}
    1258:	60e2                	ld	ra,24(sp)
    125a:	8522                	mv	a0,s0
    125c:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    125e:	00001797          	auipc	a5,0x1
    1262:	7e07a523          	sw	zero,2026(a5) # 2a48 <buffer_len>
}
    1266:	64a2                	ld	s1,8(sp)
    1268:	6105                	addi	sp,sp,32
    126a:	8082                	ret
			mutex_lock(buffer_lock);
    126c:	10c4a503          	lw	a0,268(s1)
    1270:	4de010ef          	jal	ra,274e <mutex_lock>
	if (buffer_len == 0)
    1274:	4080                	lw	s0,0(s1)
    1276:	e811                	bnez	s0,128a <fflush+0x82>
			mutex_unlock(buffer_lock);
    1278:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    127c:	00001797          	auipc	a5,0x1
    1280:	7c07a623          	sw	zero,1996(a5) # 2a48 <buffer_len>
			mutex_unlock(buffer_lock);
    1284:	4d6010ef          	jal	ra,275a <mutex_unlock>
    1288:	bf41                	j	1218 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    128a:	8622                	mv	a2,s0
    128c:	00001597          	auipc	a1,0x1
    1290:	7c458593          	addi	a1,a1,1988 # 2a50 <buffer>
    1294:	4505                	li	a0,1
    1296:	240010ef          	jal	ra,24d6 <write>
	return r >= 0 ? 0 : r;
    129a:	0005079b          	sext.w	a5,a0
    129e:	0017a793          	slti	a5,a5,1
    12a2:	40f007bb          	negw	a5,a5
    12a6:	8d7d                	and	a0,a0,a5
    12a8:	0005041b          	sext.w	s0,a0
	return r;
    12ac:	b7f1                	j	1278 <fflush+0x70>

00000000000012ae <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    12ae:	7131                	addi	sp,sp,-192
    12b0:	e0da                	sd	s6,64(sp)
    12b2:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    12b4:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    12b6:	013c                	addi	a5,sp,136
{
    12b8:	f0ca                	sd	s2,96(sp)
    12ba:	ecce                	sd	s3,88(sp)
    12bc:	e8d2                	sd	s4,80(sp)
    12be:	e4d6                	sd	s5,72(sp)
    12c0:	fc86                	sd	ra,120(sp)
    12c2:	f8a2                	sd	s0,112(sp)
    12c4:	f4a6                	sd	s1,104(sp)
    12c6:	89aa                	mv	s3,a0
    12c8:	e52e                	sd	a1,136(sp)
    12ca:	e932                	sd	a2,144(sp)
    12cc:	ed36                	sd	a3,152(sp)
    12ce:	f13a                	sd	a4,160(sp)
    12d0:	f942                	sd	a6,176(sp)
    12d2:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12d4:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12d6:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12da:	00001a17          	auipc	s4,0x1
    12de:	76ea0a13          	addi	s4,s4,1902 # 2a48 <buffer_len>
    12e2:	4a85                	li	s5,1
	buf[i++] = '0';
    12e4:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12e8:	0009c783          	lbu	a5,0(s3)
    12ec:	18078663          	beqz	a5,1478 <printf+0x1ca>
    12f0:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12f2:	19278d63          	beq	a5,s2,148c <printf+0x1de>
    12f6:	0015c783          	lbu	a5,1(a1)
    12fa:	0585                	addi	a1,a1,1
    12fc:	fbfd                	bnez	a5,12f2 <printf+0x44>
    12fe:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1300:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1304:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1308:	1b578863          	beq	a5,s5,14b8 <printf+0x20a>
		len = out_unlocked(s, l);
    130c:	85a2                	mv	a1,s0
    130e:	854e                	mv	a0,s3
    1310:	42a000ef          	jal	ra,173a <out_unlocked>
		out(f, a, l);
		if (l)
    1314:	1c041063          	bnez	s0,14d4 <printf+0x226>
			continue;
		if (s[1] == 0)
    1318:	0014c783          	lbu	a5,1(s1)
    131c:	14078e63          	beqz	a5,1478 <printf+0x1ca>
			break;
		switch (s[1]) {
    1320:	07300713          	li	a4,115
    1324:	1ce78863          	beq	a5,a4,14f4 <printf+0x246>
    1328:	1af76863          	bltu	a4,a5,14d8 <printf+0x22a>
    132c:	06400713          	li	a4,100
    1330:	22e78063          	beq	a5,a4,1550 <printf+0x2a2>
    1334:	07000713          	li	a4,112
    1338:	1ee79563          	bne	a5,a4,1522 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    133c:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    133e:	00002797          	auipc	a5,0x2
    1342:	81a78793          	addi	a5,a5,-2022 # 2b58 <digits>
	buf[i++] = '0';
    1346:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    134a:	6298                	ld	a4,0(a3)
    134c:	06a1                	addi	a3,a3,8
    134e:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1350:	00471393          	slli	t2,a4,0x4
    1354:	00871293          	slli	t0,a4,0x8
    1358:	00c71f93          	slli	t6,a4,0xc
    135c:	01071f13          	slli	t5,a4,0x10
    1360:	01471e93          	slli	t4,a4,0x14
    1364:	01871e13          	slli	t3,a4,0x18
    1368:	01c71893          	slli	a7,a4,0x1c
    136c:	02471813          	slli	a6,a4,0x24
    1370:	02871513          	slli	a0,a4,0x28
    1374:	02c71593          	slli	a1,a4,0x2c
    1378:	03071613          	slli	a2,a4,0x30
    137c:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1380:	03c75413          	srli	s0,a4,0x3c
    1384:	01c7531b          	srliw	t1,a4,0x1c
    1388:	03c3d393          	srli	t2,t2,0x3c
    138c:	03c2d293          	srli	t0,t0,0x3c
    1390:	03cfdf93          	srli	t6,t6,0x3c
    1394:	03cf5f13          	srli	t5,t5,0x3c
    1398:	03cede93          	srli	t4,t4,0x3c
    139c:	03ce5e13          	srli	t3,t3,0x3c
    13a0:	03c8d893          	srli	a7,a7,0x3c
    13a4:	03c85813          	srli	a6,a6,0x3c
    13a8:	9171                	srli	a0,a0,0x3c
    13aa:	91f1                	srli	a1,a1,0x3c
    13ac:	9271                	srli	a2,a2,0x3c
    13ae:	92f1                	srli	a3,a3,0x3c
    13b0:	95be                	add	a1,a1,a5
    13b2:	963e                	add	a2,a2,a5
    13b4:	96be                	add	a3,a3,a5
    13b6:	943e                	add	s0,s0,a5
    13b8:	93be                	add	t2,t2,a5
    13ba:	92be                	add	t0,t0,a5
    13bc:	9fbe                	add	t6,t6,a5
    13be:	9f3e                	add	t5,t5,a5
    13c0:	9ebe                	add	t4,t4,a5
    13c2:	9e3e                	add	t3,t3,a5
    13c4:	98be                	add	a7,a7,a5
    13c6:	933e                	add	t1,t1,a5
    13c8:	983e                	add	a6,a6,a5
    13ca:	953e                	add	a0,a0,a5
    13cc:	0005c983          	lbu	s3,0(a1)
    13d0:	00044403          	lbu	s0,0(s0)
    13d4:	00064583          	lbu	a1,0(a2)
    13d8:	0003c383          	lbu	t2,0(t2)
    13dc:	0006c603          	lbu	a2,0(a3)
    13e0:	0002c283          	lbu	t0,0(t0)
    13e4:	000fcf83          	lbu	t6,0(t6)
    13e8:	000f4f03          	lbu	t5,0(t5)
    13ec:	000ece83          	lbu	t4,0(t4)
    13f0:	000e4e03          	lbu	t3,0(t3)
    13f4:	0008c883          	lbu	a7,0(a7)
    13f8:	00034303          	lbu	t1,0(t1)
    13fc:	00084803          	lbu	a6,0(a6)
    1400:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1404:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1408:	92f1                	srli	a3,a3,0x3c
    140a:	8b3d                	andi	a4,a4,15
    140c:	96be                	add	a3,a3,a5
    140e:	97ba                	add	a5,a5,a4
    1410:	00810d23          	sb	s0,26(sp)
    1414:	00710da3          	sb	t2,27(sp)
    1418:	00510e23          	sb	t0,28(sp)
    141c:	01f10ea3          	sb	t6,29(sp)
    1420:	01e10f23          	sb	t5,30(sp)
    1424:	01d10fa3          	sb	t4,31(sp)
    1428:	03c10023          	sb	t3,32(sp)
    142c:	031100a3          	sb	a7,33(sp)
    1430:	02610123          	sb	t1,34(sp)
    1434:	030101a3          	sb	a6,35(sp)
    1438:	02a10223          	sb	a0,36(sp)
    143c:	033102a3          	sb	s3,37(sp)
    1440:	02b10323          	sb	a1,38(sp)
    1444:	02c103a3          	sb	a2,39(sp)
    1448:	0006c683          	lbu	a3,0(a3)
    144c:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1450:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1454:	02d10423          	sb	a3,40(sp)
    1458:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    145c:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1460:	11578263          	beq	a5,s5,1564 <printf+0x2b6>
		len = out_unlocked(s, l);
    1464:	45c9                	li	a1,18
    1466:	0828                	addi	a0,sp,24
    1468:	2d2000ef          	jal	ra,173a <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    146c:	00248993          	addi	s3,s1,2
		if (!*s)
    1470:	0009c783          	lbu	a5,0(s3)
    1474:	e6079ee3          	bnez	a5,12f0 <printf+0x42>
	}
	va_end(ap);
    1478:	70e6                	ld	ra,120(sp)
    147a:	7446                	ld	s0,112(sp)
    147c:	74a6                	ld	s1,104(sp)
    147e:	7906                	ld	s2,96(sp)
    1480:	69e6                	ld	s3,88(sp)
    1482:	6a46                	ld	s4,80(sp)
    1484:	6aa6                	ld	s5,72(sp)
    1486:	6b06                	ld	s6,64(sp)
    1488:	6129                	addi	sp,sp,192
    148a:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    148c:	0005c783          	lbu	a5,0(a1)
    1490:	84ae                	mv	s1,a1
    1492:	01278963          	beq	a5,s2,14a4 <printf+0x1f6>
    1496:	b5ad                	j	1300 <printf+0x52>
    1498:	0024c783          	lbu	a5,2(s1)
    149c:	0585                	addi	a1,a1,1
    149e:	0489                	addi	s1,s1,2
    14a0:	e72790e3          	bne	a5,s2,1300 <printf+0x52>
    14a4:	0014c783          	lbu	a5,1(s1)
    14a8:	ff2788e3          	beq	a5,s2,1498 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    14ac:	108a2783          	lw	a5,264(s4)
		l = z - a;
    14b0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14b4:	e5579ce3          	bne	a5,s5,130c <printf+0x5e>
		mutex_lock(buffer_lock);
    14b8:	10ca2503          	lw	a0,268(s4)
    14bc:	292010ef          	jal	ra,274e <mutex_lock>
		len = out_unlocked(s, l);
    14c0:	85a2                	mv	a1,s0
    14c2:	854e                	mv	a0,s3
    14c4:	276000ef          	jal	ra,173a <out_unlocked>
		mutex_unlock(buffer_lock);
    14c8:	10ca2503          	lw	a0,268(s4)
    14cc:	28e010ef          	jal	ra,275a <mutex_unlock>
		if (l)
    14d0:	e40404e3          	beqz	s0,1318 <printf+0x6a>
    14d4:	89a6                	mv	s3,s1
    14d6:	bd09                	j	12e8 <printf+0x3a>
		switch (s[1]) {
    14d8:	07800713          	li	a4,120
    14dc:	04e79363          	bne	a5,a4,1522 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    14e0:	67c2                	ld	a5,16(sp)
    14e2:	45c1                	li	a1,16
		s += 2;
    14e4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14e8:	4388                	lw	a0,0(a5)
    14ea:	07a1                	addi	a5,a5,8
    14ec:	e83e                	sd	a5,16(sp)
    14ee:	5f8000ef          	jal	ra,1ae6 <printint.constprop.0>
		s += 2;
    14f2:	bfbd                	j	1470 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14f4:	67c2                	ld	a5,16(sp)
    14f6:	6380                	ld	s0,0(a5)
    14f8:	07a1                	addi	a5,a5,8
    14fa:	e83e                	sd	a5,16(sp)
    14fc:	1c040163          	beqz	s0,16be <printf+0x410>
			l = strnlen(a, 200);
    1500:	0c800593          	li	a1,200
    1504:	8522                	mv	a0,s0
    1506:	3f7000ef          	jal	ra,20fc <strnlen>
	if (buffer_lock_enabled == 1) {
    150a:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    150e:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1512:	19578663          	beq	a5,s5,169e <printf+0x3f0>
		len = out_unlocked(s, l);
    1516:	8522                	mv	a0,s0
    1518:	222000ef          	jal	ra,173a <out_unlocked>
		s += 2;
    151c:	00248993          	addi	s3,s1,2
    1520:	bf81                	j	1470 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1522:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1526:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    152a:	0f578663          	beq	a5,s5,1616 <printf+0x368>
		len = out_unlocked(s, l);
    152e:	0828                	addi	a0,sp,24
    1530:	316000ef          	jal	ra,1846 <out_unlocked.constprop.0>
			putchar(s[1]);
    1534:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1538:	108a2783          	lw	a5,264(s4)
	char byte = c;
    153c:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1540:	05578163          	beq	a5,s5,1582 <printf+0x2d4>
		len = out_unlocked(s, l);
    1544:	0828                	addi	a0,sp,24
    1546:	300000ef          	jal	ra,1846 <out_unlocked.constprop.0>
		s += 2;
    154a:	00248993          	addi	s3,s1,2
    154e:	b70d                	j	1470 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1550:	67c2                	ld	a5,16(sp)
    1552:	45a9                	li	a1,10
		s += 2;
    1554:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1558:	4388                	lw	a0,0(a5)
    155a:	07a1                	addi	a5,a5,8
    155c:	e83e                	sd	a5,16(sp)
    155e:	588000ef          	jal	ra,1ae6 <printint.constprop.0>
		s += 2;
    1562:	b739                	j	1470 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1564:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1568:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    156c:	1e2010ef          	jal	ra,274e <mutex_lock>
		len = out_unlocked(s, l);
    1570:	45c9                	li	a1,18
    1572:	0828                	addi	a0,sp,24
    1574:	1c6000ef          	jal	ra,173a <out_unlocked>
		mutex_unlock(buffer_lock);
    1578:	10ca2503          	lw	a0,268(s4)
    157c:	1de010ef          	jal	ra,275a <mutex_unlock>
		s += 2;
    1580:	bdc5                	j	1470 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1582:	10ca2503          	lw	a0,268(s4)
    1586:	1c8010ef          	jal	ra,274e <mutex_lock>
		buffer[buffer_len++] = c;
    158a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    158e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1592:	0017861b          	addiw	a2,a5,1
    1596:	97d2                	add	a5,a5,s4
    1598:	00ca2023          	sw	a2,0(s4)
    159c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15a0:	00c6cc63          	blt	a3,a2,15b8 <printf+0x30a>
    15a4:	47a9                	li	a5,10
    15a6:	06f40663          	beq	s0,a5,1612 <printf+0x364>
		mutex_unlock(buffer_lock);
    15aa:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15ae:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    15b2:	1a8010ef          	jal	ra,275a <mutex_unlock>
		s += 2;
    15b6:	bd6d                	j	1470 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    15b8:	10000793          	li	a5,256
    15bc:	00f61e63          	bne	a2,a5,15d8 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    15c0:	00001597          	auipc	a1,0x1
    15c4:	49058593          	addi	a1,a1,1168 # 2a50 <buffer>
    15c8:	4505                	li	a0,1
    15ca:	70d000ef          	jal	ra,24d6 <write>
	buffer_len = 0;
    15ce:	00001797          	auipc	a5,0x1
    15d2:	4607ad23          	sw	zero,1146(a5) # 2a48 <buffer_len>
			if (r < 0) {
    15d6:	bfd1                	j	15aa <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15d8:	709000ef          	jal	ra,24e0 <getpid>
    15dc:	842a                	mv	s0,a0
    15de:	00001517          	auipc	a0,0x1
    15e2:	37a50513          	addi	a0,a0,890 # 2958 <enable_deadlock_detect+0x1aa>
    15e6:	5d1000ef          	jal	ra,23b6 <basename>
    15ea:	872a                	mv	a4,a0
    15ec:	00001617          	auipc	a2,0x1
    15f0:	21c60613          	addi	a2,a2,540 # 2808 <enable_deadlock_detect+0x5a>
    15f4:	05400793          	li	a5,84
    15f8:	86a2                	mv	a3,s0
    15fa:	45fd                	li	a1,31
    15fc:	00001517          	auipc	a0,0x1
    1600:	39c50513          	addi	a0,a0,924 # 2998 <enable_deadlock_detect+0x1ea>
    1604:	cabff0ef          	jal	ra,12ae <printf>
    1608:	557d                	li	a0,-1
    160a:	707000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    160e:	000a2603          	lw	a2,0(s4)
    1612:	de41                	beqz	a2,15aa <printf+0x2fc>
    1614:	b775                	j	15c0 <printf+0x312>
		mutex_lock(buffer_lock);
    1616:	10ca2503          	lw	a0,268(s4)
    161a:	134010ef          	jal	ra,274e <mutex_lock>
		buffer[buffer_len++] = c;
    161e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1622:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1626:	0017861b          	addiw	a2,a5,1
    162a:	97d2                	add	a5,a5,s4
    162c:	00ca2023          	sw	a2,0(s4)
    1630:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1634:	02c6d163          	bge	a3,a2,1656 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1638:	10000793          	li	a5,256
    163c:	02f61263          	bne	a2,a5,1660 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1640:	00001597          	auipc	a1,0x1
    1644:	41058593          	addi	a1,a1,1040 # 2a50 <buffer>
    1648:	4505                	li	a0,1
    164a:	68d000ef          	jal	ra,24d6 <write>
	buffer_len = 0;
    164e:	00001797          	auipc	a5,0x1
    1652:	3e07ad23          	sw	zero,1018(a5) # 2a48 <buffer_len>
		mutex_unlock(buffer_lock);
    1656:	10ca2503          	lw	a0,268(s4)
    165a:	100010ef          	jal	ra,275a <mutex_unlock>
    165e:	bdd9                	j	1534 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1660:	681000ef          	jal	ra,24e0 <getpid>
    1664:	842a                	mv	s0,a0
    1666:	00001517          	auipc	a0,0x1
    166a:	2f250513          	addi	a0,a0,754 # 2958 <enable_deadlock_detect+0x1aa>
    166e:	549000ef          	jal	ra,23b6 <basename>
    1672:	872a                	mv	a4,a0
    1674:	00001617          	auipc	a2,0x1
    1678:	19460613          	addi	a2,a2,404 # 2808 <enable_deadlock_detect+0x5a>
    167c:	05400793          	li	a5,84
    1680:	86a2                	mv	a3,s0
    1682:	45fd                	li	a1,31
    1684:	00001517          	auipc	a0,0x1
    1688:	31450513          	addi	a0,a0,788 # 2998 <enable_deadlock_detect+0x1ea>
    168c:	c23ff0ef          	jal	ra,12ae <printf>
    1690:	557d                	li	a0,-1
    1692:	67f000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    1696:	000a2603          	lw	a2,0(s4)
    169a:	de55                	beqz	a2,1656 <printf+0x3a8>
    169c:	b755                	j	1640 <printf+0x392>
		mutex_lock(buffer_lock);
    169e:	10ca2503          	lw	a0,268(s4)
    16a2:	e42e                	sd	a1,8(sp)
		s += 2;
    16a4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16a8:	0a6010ef          	jal	ra,274e <mutex_lock>
		len = out_unlocked(s, l);
    16ac:	65a2                	ld	a1,8(sp)
    16ae:	8522                	mv	a0,s0
    16b0:	08a000ef          	jal	ra,173a <out_unlocked>
		mutex_unlock(buffer_lock);
    16b4:	10ca2503          	lw	a0,268(s4)
    16b8:	0a2010ef          	jal	ra,275a <mutex_unlock>
		s += 2;
    16bc:	bb55                	j	1470 <printf+0x1c2>
				a = "(null)";
    16be:	00001417          	auipc	s0,0x1
    16c2:	29240413          	addi	s0,s0,658 # 2950 <enable_deadlock_detect+0x1a2>
    16c6:	bd2d                	j	1500 <printf+0x252>

00000000000016c8 <enable_thread_io_buffer>:
{
    16c8:	1101                	addi	sp,sp,-32
    16ca:	e822                	sd	s0,16(sp)
    16cc:	ec06                	sd	ra,24(sp)
    16ce:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    16d0:	00001417          	auipc	s0,0x1
    16d4:	37840413          	addi	s0,s0,888 # 2a48 <buffer_len>
    16d8:	05a010ef          	jal	ra,2732 <mutex_create>
    16dc:	10a42623          	sw	a0,268(s0)
    16e0:	00054a63          	bltz	a0,16f4 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16e4:	4785                	li	a5,1
}
    16e6:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16e8:	10f42423          	sw	a5,264(s0)
}
    16ec:	6442                	ld	s0,16(sp)
    16ee:	64a2                	ld	s1,8(sp)
    16f0:	6105                	addi	sp,sp,32
    16f2:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16f4:	5ed000ef          	jal	ra,24e0 <getpid>
    16f8:	84aa                	mv	s1,a0
    16fa:	00001517          	auipc	a0,0x1
    16fe:	25e50513          	addi	a0,a0,606 # 2958 <enable_deadlock_detect+0x1aa>
    1702:	4b5000ef          	jal	ra,23b6 <basename>
    1706:	872a                	mv	a4,a0
    1708:	04800793          	li	a5,72
    170c:	86a6                	mv	a3,s1
    170e:	00001517          	auipc	a0,0x1
    1712:	2ca50513          	addi	a0,a0,714 # 29d8 <enable_deadlock_detect+0x22a>
    1716:	00001617          	auipc	a2,0x1
    171a:	0f260613          	addi	a2,a2,242 # 2808 <enable_deadlock_detect+0x5a>
    171e:	45fd                	li	a1,31
    1720:	b8fff0ef          	jal	ra,12ae <printf>
    1724:	557d                	li	a0,-1
    1726:	5eb000ef          	jal	ra,2510 <exit>
	buffer_lock_enabled = 1;
    172a:	4785                	li	a5,1
}
    172c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    172e:	10f42423          	sw	a5,264(s0)
}
    1732:	6442                	ld	s0,16(sp)
    1734:	64a2                	ld	s1,8(sp)
    1736:	6105                	addi	sp,sp,32
    1738:	8082                	ret

000000000000173a <out_unlocked>:
{
    173a:	7159                	addi	sp,sp,-112
    173c:	f486                	sd	ra,104(sp)
    173e:	f0a2                	sd	s0,96(sp)
    1740:	eca6                	sd	s1,88(sp)
    1742:	e8ca                	sd	s2,80(sp)
    1744:	e4ce                	sd	s3,72(sp)
    1746:	e0d2                	sd	s4,64(sp)
    1748:	fc56                	sd	s5,56(sp)
    174a:	f85a                	sd	s6,48(sp)
    174c:	f45e                	sd	s7,40(sp)
    174e:	f062                	sd	s8,32(sp)
    1750:	ec66                	sd	s9,24(sp)
    1752:	e86a                	sd	s10,16(sp)
    1754:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1756:	0e058663          	beqz	a1,1842 <out_unlocked+0x108>
    175a:	842a                	mv	s0,a0
    175c:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1760:	4981                	li	s3,0
    1762:	00001d17          	auipc	s10,0x1
    1766:	2e6d0d13          	addi	s10,s10,742 # 2a48 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    176a:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    176e:	00001b17          	auipc	s6,0x1
    1772:	2e2b0b13          	addi	s6,s6,738 # 2a50 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1776:	10000a93          	li	s5,256
    177a:	00001c97          	auipc	s9,0x1
    177e:	1dec8c93          	addi	s9,s9,478 # 2958 <enable_deadlock_detect+0x1aa>
    1782:	00001c17          	auipc	s8,0x1
    1786:	086c0c13          	addi	s8,s8,134 # 2808 <enable_deadlock_detect+0x5a>
    178a:	00001b97          	auipc	s7,0x1
    178e:	20eb8b93          	addi	s7,s7,526 # 2998 <enable_deadlock_detect+0x1ea>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1792:	4a29                	li	s4,10
    1794:	a031                	j	17a0 <out_unlocked+0x66>
    1796:	09468863          	beq	a3,s4,1826 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    179a:	0405                	addi	s0,s0,1
    179c:	04848163          	beq	s1,s0,17de <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    17a0:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    17a4:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    17a8:	0017861b          	addiw	a2,a5,1
    17ac:	97ea                	add	a5,a5,s10
    17ae:	00cd2023          	sw	a2,0(s10)
    17b2:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17b6:	fec950e3          	bge	s2,a2,1796 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    17ba:	05561263          	bne	a2,s5,17fe <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    17be:	85da                	mv	a1,s6
    17c0:	4505                	li	a0,1
    17c2:	515000ef          	jal	ra,24d6 <write>
    17c6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17c8:	00001797          	auipc	a5,0x1
    17cc:	2807a023          	sw	zero,640(a5) # 2a48 <buffer_len>
			if (r < 0) {
    17d0:	06054763          	bltz	a0,183e <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17d4:	0405                	addi	s0,s0,1
			ret += r;
    17d6:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17da:	fc8493e3          	bne	s1,s0,17a0 <out_unlocked+0x66>
}
    17de:	70a6                	ld	ra,104(sp)
    17e0:	7406                	ld	s0,96(sp)
    17e2:	64e6                	ld	s1,88(sp)
    17e4:	6946                	ld	s2,80(sp)
    17e6:	6a06                	ld	s4,64(sp)
    17e8:	7ae2                	ld	s5,56(sp)
    17ea:	7b42                	ld	s6,48(sp)
    17ec:	7ba2                	ld	s7,40(sp)
    17ee:	7c02                	ld	s8,32(sp)
    17f0:	6ce2                	ld	s9,24(sp)
    17f2:	6d42                	ld	s10,16(sp)
    17f4:	6da2                	ld	s11,8(sp)
    17f6:	854e                	mv	a0,s3
    17f8:	69a6                	ld	s3,72(sp)
    17fa:	6165                	addi	sp,sp,112
    17fc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17fe:	4e3000ef          	jal	ra,24e0 <getpid>
    1802:	8daa                	mv	s11,a0
    1804:	8566                	mv	a0,s9
    1806:	3b1000ef          	jal	ra,23b6 <basename>
    180a:	872a                	mv	a4,a0
    180c:	8662                	mv	a2,s8
    180e:	05400793          	li	a5,84
    1812:	86ee                	mv	a3,s11
    1814:	45fd                	li	a1,31
    1816:	855e                	mv	a0,s7
    1818:	a97ff0ef          	jal	ra,12ae <printf>
    181c:	557d                	li	a0,-1
    181e:	4f3000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    1822:	000d2603          	lw	a2,0(s10)
    1826:	da35                	beqz	a2,179a <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1828:	85da                	mv	a1,s6
    182a:	4505                	li	a0,1
    182c:	4ab000ef          	jal	ra,24d6 <write>
    1830:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1832:	00001797          	auipc	a5,0x1
    1836:	2007ab23          	sw	zero,534(a5) # 2a48 <buffer_len>
			if (r < 0) {
    183a:	f8055de3          	bgez	a0,17d4 <out_unlocked+0x9a>
    183e:	89aa                	mv	s3,a0
    1840:	bf79                	j	17de <out_unlocked+0xa4>
	int ret = 0;
    1842:	4981                	li	s3,0
    1844:	bf69                	j	17de <out_unlocked+0xa4>

0000000000001846 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1846:	1101                	addi	sp,sp,-32
    1848:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    184a:	00001497          	auipc	s1,0x1
    184e:	1fe48493          	addi	s1,s1,510 # 2a48 <buffer_len>
    1852:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1854:	ec06                	sd	ra,24(sp)
    1856:	e822                	sd	s0,16(sp)
		char c = s[i];
    1858:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    185c:	0017861b          	addiw	a2,a5,1
    1860:	97a6                	add	a5,a5,s1
    1862:	00e78423          	sb	a4,8(a5)
    1866:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1868:	0ff00793          	li	a5,255
    186c:	00c7cc63          	blt	a5,a2,1884 <out_unlocked.constprop.0+0x3e>
    1870:	47a9                	li	a5,10
    1872:	06f70c63          	beq	a4,a5,18ea <out_unlocked.constprop.0+0xa4>
    1876:	4601                	li	a2,0
}
    1878:	60e2                	ld	ra,24(sp)
    187a:	6442                	ld	s0,16(sp)
    187c:	64a2                	ld	s1,8(sp)
    187e:	8532                	mv	a0,a2
    1880:	6105                	addi	sp,sp,32
    1882:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1884:	10000793          	li	a5,256
    1888:	02f61563          	bne	a2,a5,18b2 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    188c:	00001597          	auipc	a1,0x1
    1890:	1c458593          	addi	a1,a1,452 # 2a50 <buffer>
    1894:	4505                	li	a0,1
    1896:	441000ef          	jal	ra,24d6 <write>
}
    189a:	60e2                	ld	ra,24(sp)
    189c:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    189e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18a2:	00001797          	auipc	a5,0x1
    18a6:	1a07a323          	sw	zero,422(a5) # 2a48 <buffer_len>
}
    18aa:	64a2                	ld	s1,8(sp)
    18ac:	8532                	mv	a0,a2
    18ae:	6105                	addi	sp,sp,32
    18b0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18b2:	42f000ef          	jal	ra,24e0 <getpid>
    18b6:	842a                	mv	s0,a0
    18b8:	00001517          	auipc	a0,0x1
    18bc:	0a050513          	addi	a0,a0,160 # 2958 <enable_deadlock_detect+0x1aa>
    18c0:	2f7000ef          	jal	ra,23b6 <basename>
    18c4:	872a                	mv	a4,a0
    18c6:	00001617          	auipc	a2,0x1
    18ca:	f4260613          	addi	a2,a2,-190 # 2808 <enable_deadlock_detect+0x5a>
    18ce:	05400793          	li	a5,84
    18d2:	86a2                	mv	a3,s0
    18d4:	45fd                	li	a1,31
    18d6:	00001517          	auipc	a0,0x1
    18da:	0c250513          	addi	a0,a0,194 # 2998 <enable_deadlock_detect+0x1ea>
    18de:	9d1ff0ef          	jal	ra,12ae <printf>
    18e2:	557d                	li	a0,-1
    18e4:	42d000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    18e8:	4090                	lw	a2,0(s1)
    18ea:	d659                	beqz	a2,1878 <out_unlocked.constprop.0+0x32>
    18ec:	b745                	j	188c <out_unlocked.constprop.0+0x46>

00000000000018ee <putchar>:
{
    18ee:	7139                	addi	sp,sp,-64
    18f0:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18f2:	00001497          	auipc	s1,0x1
    18f6:	15648493          	addi	s1,s1,342 # 2a48 <buffer_len>
    18fa:	1084a703          	lw	a4,264(s1)
{
    18fe:	f822                	sd	s0,48(sp)
	char byte = c;
    1900:	0ff57413          	zext.b	s0,a0
{
    1904:	fc06                	sd	ra,56(sp)
	char byte = c;
    1906:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    190a:	4785                	li	a5,1
    190c:	00f70d63          	beq	a4,a5,1926 <putchar+0x38>
		len = out_unlocked(s, l);
    1910:	01f10513          	addi	a0,sp,31
    1914:	f33ff0ef          	jal	ra,1846 <out_unlocked.constprop.0>
}
    1918:	70e2                	ld	ra,56(sp)
    191a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    191c:	862a                	mv	a2,a0
}
    191e:	74a2                	ld	s1,40(sp)
    1920:	8532                	mv	a0,a2
    1922:	6121                	addi	sp,sp,64
    1924:	8082                	ret
		mutex_lock(buffer_lock);
    1926:	10c4a503          	lw	a0,268(s1)
    192a:	625000ef          	jal	ra,274e <mutex_lock>
		buffer[buffer_len++] = c;
    192e:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1930:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1934:	0017861b          	addiw	a2,a5,1
    1938:	97a6                	add	a5,a5,s1
    193a:	c090                	sw	a2,0(s1)
    193c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1940:	02c6c263          	blt	a3,a2,1964 <putchar+0x76>
    1944:	47a9                	li	a5,10
    1946:	06f40d63          	beq	s0,a5,19c0 <putchar+0xd2>
    194a:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    194c:	10c4a503          	lw	a0,268(s1)
    1950:	e432                	sd	a2,8(sp)
    1952:	609000ef          	jal	ra,275a <mutex_unlock>
    1956:	6622                	ld	a2,8(sp)
}
    1958:	70e2                	ld	ra,56(sp)
    195a:	7442                	ld	s0,48(sp)
    195c:	74a2                	ld	s1,40(sp)
    195e:	8532                	mv	a0,a2
    1960:	6121                	addi	sp,sp,64
    1962:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1964:	10000793          	li	a5,256
    1968:	02f61063          	bne	a2,a5,1988 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    196c:	00001597          	auipc	a1,0x1
    1970:	0e458593          	addi	a1,a1,228 # 2a50 <buffer>
    1974:	4505                	li	a0,1
    1976:	361000ef          	jal	ra,24d6 <write>
    197a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    197e:	00001797          	auipc	a5,0x1
    1982:	0c07a523          	sw	zero,202(a5) # 2a48 <buffer_len>
			if (r < 0) {
    1986:	b7d9                	j	194c <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1988:	359000ef          	jal	ra,24e0 <getpid>
    198c:	842a                	mv	s0,a0
    198e:	00001517          	auipc	a0,0x1
    1992:	fca50513          	addi	a0,a0,-54 # 2958 <enable_deadlock_detect+0x1aa>
    1996:	221000ef          	jal	ra,23b6 <basename>
    199a:	872a                	mv	a4,a0
    199c:	00001617          	auipc	a2,0x1
    19a0:	e6c60613          	addi	a2,a2,-404 # 2808 <enable_deadlock_detect+0x5a>
    19a4:	05400793          	li	a5,84
    19a8:	86a2                	mv	a3,s0
    19aa:	45fd                	li	a1,31
    19ac:	00001517          	auipc	a0,0x1
    19b0:	fec50513          	addi	a0,a0,-20 # 2998 <enable_deadlock_detect+0x1ea>
    19b4:	8fbff0ef          	jal	ra,12ae <printf>
    19b8:	557d                	li	a0,-1
    19ba:	357000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    19be:	4090                	lw	a2,0(s1)
    19c0:	d651                	beqz	a2,194c <putchar+0x5e>
    19c2:	b76d                	j	196c <putchar+0x7e>

00000000000019c4 <puts>:
{
    19c4:	7139                	addi	sp,sp,-64
    19c6:	f822                	sd	s0,48(sp)
    19c8:	f426                	sd	s1,40(sp)
    19ca:	fc06                	sd	ra,56(sp)
    19cc:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    19ce:	00001417          	auipc	s0,0x1
    19d2:	07a40413          	addi	s0,s0,122 # 2a48 <buffer_len>
{
    19d6:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19d8:	638000ef          	jal	ra,2010 <strlen>
	if (buffer_lock_enabled == 1) {
    19dc:	10842703          	lw	a4,264(s0)
    19e0:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19e2:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19e4:	04f70563          	beq	a4,a5,1a2e <puts+0x6a>
		len = out_unlocked(s, l);
    19e8:	8526                	mv	a0,s1
    19ea:	d51ff0ef          	jal	ra,173a <out_unlocked>
    19ee:	892a                	mv	s2,a0
    19f0:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19f2:	00095963          	bgez	s2,1a04 <puts+0x40>
}
    19f6:	70e2                	ld	ra,56(sp)
    19f8:	7442                	ld	s0,48(sp)
    19fa:	7902                	ld	s2,32(sp)
    19fc:	8526                	mv	a0,s1
    19fe:	74a2                	ld	s1,40(sp)
    1a00:	6121                	addi	sp,sp,64
    1a02:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a04:	10842703          	lw	a4,264(s0)
	char byte = c;
    1a08:	44a9                	li	s1,10
    1a0a:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1a0e:	4785                	li	a5,1
    1a10:	02f70e63          	beq	a4,a5,1a4c <puts+0x88>
		len = out_unlocked(s, l);
    1a14:	01f10513          	addi	a0,sp,31
    1a18:	e2fff0ef          	jal	ra,1846 <out_unlocked.constprop.0>
}
    1a1c:	70e2                	ld	ra,56(sp)
    1a1e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a20:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a24:	7902                	ld	s2,32(sp)
    1a26:	8526                	mv	a0,s1
    1a28:	74a2                	ld	s1,40(sp)
    1a2a:	6121                	addi	sp,sp,64
    1a2c:	8082                	ret
		mutex_lock(buffer_lock);
    1a2e:	e42a                	sd	a0,8(sp)
    1a30:	10c42503          	lw	a0,268(s0)
    1a34:	51b000ef          	jal	ra,274e <mutex_lock>
		len = out_unlocked(s, l);
    1a38:	65a2                	ld	a1,8(sp)
    1a3a:	8526                	mv	a0,s1
    1a3c:	cffff0ef          	jal	ra,173a <out_unlocked>
    1a40:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a42:	10c42503          	lw	a0,268(s0)
    1a46:	515000ef          	jal	ra,275a <mutex_unlock>
    1a4a:	b75d                	j	19f0 <puts+0x2c>
		mutex_lock(buffer_lock);
    1a4c:	10c42503          	lw	a0,268(s0)
    1a50:	4ff000ef          	jal	ra,274e <mutex_lock>
		buffer[buffer_len++] = c;
    1a54:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a56:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a5a:	0017861b          	addiw	a2,a5,1
    1a5e:	97a2                	add	a5,a5,s0
    1a60:	c010                	sw	a2,0(s0)
    1a62:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a66:	06c6dc63          	bge	a3,a2,1ade <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a6a:	10000793          	li	a5,256
    1a6e:	02f61c63          	bne	a2,a5,1aa6 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a72:	00001597          	auipc	a1,0x1
    1a76:	fde58593          	addi	a1,a1,-34 # 2a50 <buffer>
    1a7a:	4505                	li	a0,1
    1a7c:	25b000ef          	jal	ra,24d6 <write>
			if (r < 0) {
    1a80:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a82:	00001797          	auipc	a5,0x1
    1a86:	fc07a323          	sw	zero,-58(a5) # 2a48 <buffer_len>
			if (r < 0) {
    1a8a:	04054c63          	bltz	a0,1ae2 <puts+0x11e>
			if (r < buffer_len) {
    1a8e:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a90:	10c42503          	lw	a0,268(s0)
    1a94:	4c7000ef          	jal	ra,275a <mutex_unlock>
}
    1a98:	70e2                	ld	ra,56(sp)
    1a9a:	7442                	ld	s0,48(sp)
    1a9c:	7902                	ld	s2,32(sp)
    1a9e:	8526                	mv	a0,s1
    1aa0:	74a2                	ld	s1,40(sp)
    1aa2:	6121                	addi	sp,sp,64
    1aa4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1aa6:	23b000ef          	jal	ra,24e0 <getpid>
    1aaa:	84aa                	mv	s1,a0
    1aac:	00001517          	auipc	a0,0x1
    1ab0:	eac50513          	addi	a0,a0,-340 # 2958 <enable_deadlock_detect+0x1aa>
    1ab4:	103000ef          	jal	ra,23b6 <basename>
    1ab8:	872a                	mv	a4,a0
    1aba:	00001617          	auipc	a2,0x1
    1abe:	d4e60613          	addi	a2,a2,-690 # 2808 <enable_deadlock_detect+0x5a>
    1ac2:	05400793          	li	a5,84
    1ac6:	86a6                	mv	a3,s1
    1ac8:	45fd                	li	a1,31
    1aca:	00001517          	auipc	a0,0x1
    1ace:	ece50513          	addi	a0,a0,-306 # 2998 <enable_deadlock_detect+0x1ea>
    1ad2:	fdcff0ef          	jal	ra,12ae <printf>
    1ad6:	557d                	li	a0,-1
    1ad8:	239000ef          	jal	ra,2510 <exit>
	if (buffer_len == 0)
    1adc:	4010                	lw	a2,0(s0)
    1ade:	da45                	beqz	a2,1a8e <puts+0xca>
    1ae0:	bf49                	j	1a72 <puts+0xae>
    1ae2:	54fd                	li	s1,-1
    1ae4:	b775                	j	1a90 <puts+0xcc>

0000000000001ae6 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ae6:	715d                	addi	sp,sp,-80
    1ae8:	e486                	sd	ra,72(sp)
    1aea:	e0a2                	sd	s0,64(sp)
    1aec:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1aee:	14054363          	bltz	a0,1c34 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1af2:	02b577bb          	remuw	a5,a0,a1
    1af6:	00001617          	auipc	a2,0x1
    1afa:	06260613          	addi	a2,a2,98 # 2b58 <digits>
	buf[16] = 0;
    1afe:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b02:	0005871b          	sext.w	a4,a1
    1b06:	1782                	slli	a5,a5,0x20
    1b08:	9381                	srli	a5,a5,0x20
    1b0a:	97b2                	add	a5,a5,a2
    1b0c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b10:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b14:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b18:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b1a:	0eb56763          	bltu	a0,a1,1c08 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b1e:	02e877bb          	remuw	a5,a6,a4
    1b22:	1782                	slli	a5,a5,0x20
    1b24:	9381                	srli	a5,a5,0x20
    1b26:	97b2                	add	a5,a5,a2
    1b28:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b2c:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b30:	02f10323          	sb	a5,38(sp)
    1b34:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b36:	0ce86963          	bltu	a6,a4,1c08 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b3a:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b3e:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b42:	1582                	slli	a1,a1,0x20
    1b44:	9181                	srli	a1,a1,0x20
    1b46:	95b2                	add	a1,a1,a2
    1b48:	0005c583          	lbu	a1,0(a1)
    1b4c:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b50:	0007859b          	sext.w	a1,a5
    1b54:	16e6e563          	bltu	a3,a4,1cbe <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b58:	02e7f6bb          	remuw	a3,a5,a4
    1b5c:	1682                	slli	a3,a3,0x20
    1b5e:	9281                	srli	a3,a3,0x20
    1b60:	96b2                	add	a3,a3,a2
    1b62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b66:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b6a:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b6e:	16e5e163          	bltu	a1,a4,1cd0 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b72:	02e876bb          	remuw	a3,a6,a4
    1b76:	1682                	slli	a3,a3,0x20
    1b78:	9281                	srli	a3,a3,0x20
    1b7a:	96b2                	add	a3,a3,a2
    1b7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b80:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b84:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b88:	14e86d63          	bltu	a6,a4,1ce2 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b8c:	02e5f6bb          	remuw	a3,a1,a4
    1b90:	1682                	slli	a3,a3,0x20
    1b92:	9281                	srli	a3,a3,0x20
    1b94:	96b2                	add	a3,a3,a2
    1b96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b9a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b9e:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ba2:	10e5e563          	bltu	a1,a4,1cac <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ba6:	02e876bb          	remuw	a3,a6,a4
    1baa:	1682                	slli	a3,a3,0x20
    1bac:	9281                	srli	a3,a3,0x20
    1bae:	96b2                	add	a3,a3,a2
    1bb0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bb4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1bb8:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1bbc:	14e86263          	bltu	a6,a4,1d00 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1bc0:	02e5f6bb          	remuw	a3,a1,a4
    1bc4:	1682                	slli	a3,a3,0x20
    1bc6:	9281                	srli	a3,a3,0x20
    1bc8:	96b2                	add	a3,a3,a2
    1bca:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bce:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bd2:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1bd6:	14e5e463          	bltu	a1,a4,1d1e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1bda:	02e876bb          	remuw	a3,a6,a4
    1bde:	1682                	slli	a3,a3,0x20
    1be0:	9281                	srli	a3,a3,0x20
    1be2:	96b2                	add	a3,a3,a2
    1be4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1be8:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1bec:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1bf0:	14e86063          	bltu	a6,a4,1d30 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1bf4:	1782                	slli	a5,a5,0x20
    1bf6:	9381                	srli	a5,a5,0x20
    1bf8:	97b2                	add	a5,a5,a2
    1bfa:	0007c703          	lbu	a4,0(a5)
    1bfe:	4799                	li	a5,6
    1c00:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c04:	10054763          	bltz	a0,1d12 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1c08:	00001497          	auipc	s1,0x1
    1c0c:	e4048493          	addi	s1,s1,-448 # 2a48 <buffer_len>
    1c10:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c14:	0828                	addi	a0,sp,24
    1c16:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c18:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c1a:	00f50433          	add	s0,a0,a5
    1c1e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c20:	06e68463          	beq	a3,a4,1c88 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c24:	8522                	mv	a0,s0
    1c26:	b15ff0ef          	jal	ra,173a <out_unlocked>
}
    1c2a:	60a6                	ld	ra,72(sp)
    1c2c:	6406                	ld	s0,64(sp)
    1c2e:	74e2                	ld	s1,56(sp)
    1c30:	6161                	addi	sp,sp,80
    1c32:	8082                	ret
		x = -xx;
    1c34:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c38:	02b877bb          	remuw	a5,a6,a1
    1c3c:	00001617          	auipc	a2,0x1
    1c40:	f1c60613          	addi	a2,a2,-228 # 2b58 <digits>
	buf[16] = 0;
    1c44:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c48:	0005871b          	sext.w	a4,a1
    1c4c:	1782                	slli	a5,a5,0x20
    1c4e:	9381                	srli	a5,a5,0x20
    1c50:	97b2                	add	a5,a5,a2
    1c52:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c56:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c5a:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c5e:	08b86b63          	bltu	a6,a1,1cf4 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c62:	02e8f7bb          	remuw	a5,a7,a4
    1c66:	1782                	slli	a5,a5,0x20
    1c68:	9381                	srli	a5,a5,0x20
    1c6a:	97b2                	add	a5,a5,a2
    1c6c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c70:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c74:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c78:	ece8f1e3          	bgeu	a7,a4,1b3a <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c7c:	02d00793          	li	a5,45
    1c80:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c84:	47b5                	li	a5,13
    1c86:	b749                	j	1c08 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c88:	10c4a503          	lw	a0,268(s1)
    1c8c:	e42e                	sd	a1,8(sp)
    1c8e:	2c1000ef          	jal	ra,274e <mutex_lock>
		len = out_unlocked(s, l);
    1c92:	65a2                	ld	a1,8(sp)
    1c94:	8522                	mv	a0,s0
    1c96:	aa5ff0ef          	jal	ra,173a <out_unlocked>
		mutex_unlock(buffer_lock);
    1c9a:	10c4a503          	lw	a0,268(s1)
    1c9e:	2bd000ef          	jal	ra,275a <mutex_unlock>
}
    1ca2:	60a6                	ld	ra,72(sp)
    1ca4:	6406                	ld	s0,64(sp)
    1ca6:	74e2                	ld	s1,56(sp)
    1ca8:	6161                	addi	sp,sp,80
    1caa:	8082                	ret
		buf[i--] = digits[x % base];
    1cac:	47a9                	li	a5,10
	if (sign)
    1cae:	f4055de3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb2:	02d00793          	li	a5,45
    1cb6:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1cba:	47a5                	li	a5,9
    1cbc:	b7b1                	j	1c08 <printint.constprop.0+0x122>
    1cbe:	47b5                	li	a5,13
	if (sign)
    1cc0:	f40554e3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc4:	02d00793          	li	a5,45
    1cc8:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1ccc:	47b1                	li	a5,12
    1cce:	bf2d                	j	1c08 <printint.constprop.0+0x122>
    1cd0:	47b1                	li	a5,12
	if (sign)
    1cd2:	f2055be3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd6:	02d00793          	li	a5,45
    1cda:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1cde:	47ad                	li	a5,11
    1ce0:	b725                	j	1c08 <printint.constprop.0+0x122>
    1ce2:	47ad                	li	a5,11
	if (sign)
    1ce4:	f20552e3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce8:	02d00793          	li	a5,45
    1cec:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1cf0:	47a9                	li	a5,10
    1cf2:	bf19                	j	1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf4:	02d00793          	li	a5,45
    1cf8:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cfc:	47b9                	li	a5,14
    1cfe:	b729                	j	1c08 <printint.constprop.0+0x122>
    1d00:	47a5                	li	a5,9
	if (sign)
    1d02:	f00553e3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d06:	02d00793          	li	a5,45
    1d0a:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1d0e:	47a1                	li	a5,8
    1d10:	bde5                	j	1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d12:	02d00793          	li	a5,45
    1d16:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d1a:	4795                	li	a5,5
    1d1c:	b5f5                	j	1c08 <printint.constprop.0+0x122>
    1d1e:	47a1                	li	a5,8
	if (sign)
    1d20:	ee0554e3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d24:	02d00793          	li	a5,45
    1d28:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d2c:	479d                	li	a5,7
    1d2e:	bde9                	j	1c08 <printint.constprop.0+0x122>
    1d30:	479d                	li	a5,7
	if (sign)
    1d32:	ec055be3          	bgez	a0,1c08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d36:	02d00793          	li	a5,45
    1d3a:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d3e:	4799                	li	a5,6
    1d40:	b5e1                	j	1c08 <printint.constprop.0+0x122>

0000000000001d42 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d42:	02000793          	li	a5,32
    1d46:	00f50663          	beq	a0,a5,1d52 <isspace+0x10>
    1d4a:	355d                	addiw	a0,a0,-9
    1d4c:	00553513          	sltiu	a0,a0,5
    1d50:	8082                	ret
    1d52:	4505                	li	a0,1
}
    1d54:	8082                	ret

0000000000001d56 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d56:	fd05051b          	addiw	a0,a0,-48
}
    1d5a:	00a53513          	sltiu	a0,a0,10
    1d5e:	8082                	ret

0000000000001d60 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d60:	02000613          	li	a2,32
    1d64:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d66:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d6a:	ff77869b          	addiw	a3,a5,-9
    1d6e:	04c78c63          	beq	a5,a2,1dc6 <atoi+0x66>
    1d72:	0007871b          	sext.w	a4,a5
    1d76:	04d5f863          	bgeu	a1,a3,1dc6 <atoi+0x66>
		s++;
	switch (*s) {
    1d7a:	02b00693          	li	a3,43
    1d7e:	04d78963          	beq	a5,a3,1dd0 <atoi+0x70>
    1d82:	02d00693          	li	a3,45
    1d86:	06d78263          	beq	a5,a3,1dea <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d8a:	fd07061b          	addiw	a2,a4,-48
    1d8e:	47a5                	li	a5,9
    1d90:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d92:	4e01                	li	t3,0
	while (isdigit(*s))
    1d94:	04c7e963          	bltu	a5,a2,1de6 <atoi+0x86>
	int n = 0, neg = 0;
    1d98:	4501                	li	a0,0
	while (isdigit(*s))
    1d9a:	4825                	li	a6,9
    1d9c:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1da0:	0025179b          	slliw	a5,a0,0x2
    1da4:	9fa9                	addw	a5,a5,a0
    1da6:	fd07031b          	addiw	t1,a4,-48
    1daa:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1dae:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1db2:	0685                	addi	a3,a3,1
    1db4:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1db8:	0006071b          	sext.w	a4,a2
    1dbc:	feb870e3          	bgeu	a6,a1,1d9c <atoi+0x3c>
	return neg ? n : -n;
    1dc0:	000e0563          	beqz	t3,1dca <atoi+0x6a>
}
    1dc4:	8082                	ret
		s++;
    1dc6:	0505                	addi	a0,a0,1
    1dc8:	bf79                	j	1d66 <atoi+0x6>
	return neg ? n : -n;
    1dca:	4113053b          	subw	a0,t1,a7
    1dce:	8082                	ret
	while (isdigit(*s))
    1dd0:	00154703          	lbu	a4,1(a0)
    1dd4:	47a5                	li	a5,9
		s++;
    1dd6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dda:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1dde:	4e01                	li	t3,0
	while (isdigit(*s))
    1de0:	2701                	sext.w	a4,a4
    1de2:	fac7fbe3          	bgeu	a5,a2,1d98 <atoi+0x38>
    1de6:	4501                	li	a0,0
}
    1de8:	8082                	ret
	while (isdigit(*s))
    1dea:	00154703          	lbu	a4,1(a0)
    1dee:	47a5                	li	a5,9
		s++;
    1df0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1df4:	fd07061b          	addiw	a2,a4,-48
    1df8:	2701                	sext.w	a4,a4
    1dfa:	fec7e6e3          	bltu	a5,a2,1de6 <atoi+0x86>
		neg = 1;
    1dfe:	4e05                	li	t3,1
    1e00:	bf61                	j	1d98 <atoi+0x38>

0000000000001e02 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e02:	16060d63          	beqz	a2,1f7c <memset+0x17a>
    1e06:	40a007b3          	neg	a5,a0
    1e0a:	8b9d                	andi	a5,a5,7
    1e0c:	00778693          	addi	a3,a5,7
    1e10:	482d                	li	a6,11
    1e12:	0ff5f713          	zext.b	a4,a1
    1e16:	fff60593          	addi	a1,a2,-1
    1e1a:	1706e263          	bltu	a3,a6,1f7e <memset+0x17c>
    1e1e:	16d5ea63          	bltu	a1,a3,1f92 <memset+0x190>
    1e22:	16078563          	beqz	a5,1f8c <memset+0x18a>
    1e26:	00e50023          	sb	a4,0(a0)
    1e2a:	4685                	li	a3,1
    1e2c:	00150593          	addi	a1,a0,1
    1e30:	14d78c63          	beq	a5,a3,1f88 <memset+0x186>
    1e34:	00e500a3          	sb	a4,1(a0)
    1e38:	4689                	li	a3,2
    1e3a:	00250593          	addi	a1,a0,2
    1e3e:	14d78d63          	beq	a5,a3,1f98 <memset+0x196>
    1e42:	00e50123          	sb	a4,2(a0)
    1e46:	468d                	li	a3,3
    1e48:	00350593          	addi	a1,a0,3
    1e4c:	12d78b63          	beq	a5,a3,1f82 <memset+0x180>
    1e50:	00e501a3          	sb	a4,3(a0)
    1e54:	4691                	li	a3,4
    1e56:	00450593          	addi	a1,a0,4
    1e5a:	14d78163          	beq	a5,a3,1f9c <memset+0x19a>
    1e5e:	00e50223          	sb	a4,4(a0)
    1e62:	4695                	li	a3,5
    1e64:	00550593          	addi	a1,a0,5
    1e68:	12d78c63          	beq	a5,a3,1fa0 <memset+0x19e>
    1e6c:	00e502a3          	sb	a4,5(a0)
    1e70:	469d                	li	a3,7
    1e72:	00650593          	addi	a1,a0,6
    1e76:	12d79763          	bne	a5,a3,1fa4 <memset+0x1a2>
    1e7a:	00750593          	addi	a1,a0,7
    1e7e:	00e50323          	sb	a4,6(a0)
    1e82:	481d                	li	a6,7
    1e84:	00871693          	slli	a3,a4,0x8
    1e88:	01071893          	slli	a7,a4,0x10
    1e8c:	8ed9                	or	a3,a3,a4
    1e8e:	01871313          	slli	t1,a4,0x18
    1e92:	0116e6b3          	or	a3,a3,a7
    1e96:	0066e6b3          	or	a3,a3,t1
    1e9a:	02071893          	slli	a7,a4,0x20
    1e9e:	02871e13          	slli	t3,a4,0x28
    1ea2:	0116e6b3          	or	a3,a3,a7
    1ea6:	40f60333          	sub	t1,a2,a5
    1eaa:	03071893          	slli	a7,a4,0x30
    1eae:	01c6e6b3          	or	a3,a3,t3
    1eb2:	0116e6b3          	or	a3,a3,a7
    1eb6:	03871e13          	slli	t3,a4,0x38
    1eba:	97aa                	add	a5,a5,a0
    1ebc:	ff837893          	andi	a7,t1,-8
    1ec0:	01c6e6b3          	or	a3,a3,t3
    1ec4:	98be                	add	a7,a7,a5
    1ec6:	e394                	sd	a3,0(a5)
    1ec8:	07a1                	addi	a5,a5,8
    1eca:	ff179ee3          	bne	a5,a7,1ec6 <memset+0xc4>
    1ece:	ff837893          	andi	a7,t1,-8
    1ed2:	011587b3          	add	a5,a1,a7
    1ed6:	010886bb          	addw	a3,a7,a6
    1eda:	0b130663          	beq	t1,a7,1f86 <memset+0x184>
    1ede:	00e78023          	sb	a4,0(a5)
    1ee2:	0016859b          	addiw	a1,a3,1
    1ee6:	08c5fb63          	bgeu	a1,a2,1f7c <memset+0x17a>
    1eea:	00e780a3          	sb	a4,1(a5)
    1eee:	0026859b          	addiw	a1,a3,2
    1ef2:	08c5f563          	bgeu	a1,a2,1f7c <memset+0x17a>
    1ef6:	00e78123          	sb	a4,2(a5)
    1efa:	0036859b          	addiw	a1,a3,3
    1efe:	06c5ff63          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f02:	00e781a3          	sb	a4,3(a5)
    1f06:	0046859b          	addiw	a1,a3,4
    1f0a:	06c5f963          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f0e:	00e78223          	sb	a4,4(a5)
    1f12:	0056859b          	addiw	a1,a3,5
    1f16:	06c5f363          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f1a:	00e782a3          	sb	a4,5(a5)
    1f1e:	0066859b          	addiw	a1,a3,6
    1f22:	04c5fd63          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f26:	00e78323          	sb	a4,6(a5)
    1f2a:	0076859b          	addiw	a1,a3,7
    1f2e:	04c5f763          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f32:	00e783a3          	sb	a4,7(a5)
    1f36:	0086859b          	addiw	a1,a3,8
    1f3a:	04c5f163          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f3e:	00e78423          	sb	a4,8(a5)
    1f42:	0096859b          	addiw	a1,a3,9
    1f46:	02c5fb63          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f4a:	00e784a3          	sb	a4,9(a5)
    1f4e:	00a6859b          	addiw	a1,a3,10
    1f52:	02c5f563          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f56:	00e78523          	sb	a4,10(a5)
    1f5a:	00b6859b          	addiw	a1,a3,11
    1f5e:	00c5ff63          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f62:	00e785a3          	sb	a4,11(a5)
    1f66:	00c6859b          	addiw	a1,a3,12
    1f6a:	00c5f963          	bgeu	a1,a2,1f7c <memset+0x17a>
    1f6e:	00e78623          	sb	a4,12(a5)
    1f72:	26b5                	addiw	a3,a3,13
    1f74:	00c6f463          	bgeu	a3,a2,1f7c <memset+0x17a>
    1f78:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f7c:	8082                	ret
    1f7e:	46ad                	li	a3,11
    1f80:	bd79                	j	1e1e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f82:	480d                	li	a6,3
    1f84:	b701                	j	1e84 <memset+0x82>
    1f86:	8082                	ret
    1f88:	4805                	li	a6,1
    1f8a:	bded                	j	1e84 <memset+0x82>
    1f8c:	85aa                	mv	a1,a0
    1f8e:	4801                	li	a6,0
    1f90:	bdd5                	j	1e84 <memset+0x82>
    1f92:	87aa                	mv	a5,a0
    1f94:	4681                	li	a3,0
    1f96:	b7a1                	j	1ede <memset+0xdc>
    1f98:	4809                	li	a6,2
    1f9a:	b5ed                	j	1e84 <memset+0x82>
    1f9c:	4811                	li	a6,4
    1f9e:	b5dd                	j	1e84 <memset+0x82>
    1fa0:	4815                	li	a6,5
    1fa2:	b5cd                	j	1e84 <memset+0x82>
    1fa4:	4819                	li	a6,6
    1fa6:	bdf9                	j	1e84 <memset+0x82>

0000000000001fa8 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1fa8:	00054783          	lbu	a5,0(a0)
    1fac:	0005c703          	lbu	a4,0(a1)
    1fb0:	00e79863          	bne	a5,a4,1fc0 <strcmp+0x18>
    1fb4:	0505                	addi	a0,a0,1
    1fb6:	0585                	addi	a1,a1,1
    1fb8:	fbe5                	bnez	a5,1fa8 <strcmp>
    1fba:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1fbc:	9d19                	subw	a0,a0,a4
    1fbe:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1fc0:	0007851b          	sext.w	a0,a5
    1fc4:	bfe5                	j	1fbc <strcmp+0x14>

0000000000001fc6 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1fc6:	ca15                	beqz	a2,1ffa <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fc8:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1fcc:	167d                	addi	a2,a2,-1
    1fce:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fd2:	eb99                	bnez	a5,1fe8 <strncmp+0x22>
    1fd4:	a815                	j	2008 <strncmp+0x42>
    1fd6:	00a68e63          	beq	a3,a0,1ff2 <strncmp+0x2c>
    1fda:	0505                	addi	a0,a0,1
    1fdc:	00f71b63          	bne	a4,a5,1ff2 <strncmp+0x2c>
    1fe0:	00054783          	lbu	a5,0(a0)
    1fe4:	cf89                	beqz	a5,1ffe <strncmp+0x38>
    1fe6:	85b2                	mv	a1,a2
    1fe8:	0005c703          	lbu	a4,0(a1)
    1fec:	00158613          	addi	a2,a1,1
    1ff0:	f37d                	bnez	a4,1fd6 <strncmp+0x10>
		;
	return *l - *r;
    1ff2:	0007851b          	sext.w	a0,a5
    1ff6:	9d19                	subw	a0,a0,a4
    1ff8:	8082                	ret
		return 0;
    1ffa:	4501                	li	a0,0
}
    1ffc:	8082                	ret
	return *l - *r;
    1ffe:	0015c703          	lbu	a4,1(a1)
    2002:	4501                	li	a0,0
    2004:	9d19                	subw	a0,a0,a4
    2006:	8082                	ret
    2008:	0005c703          	lbu	a4,0(a1)
    200c:	4501                	li	a0,0
    200e:	b7e5                	j	1ff6 <strncmp+0x30>

0000000000002010 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2010:	00757793          	andi	a5,a0,7
    2014:	cf89                	beqz	a5,202e <strlen+0x1e>
    2016:	87aa                	mv	a5,a0
    2018:	a029                	j	2022 <strlen+0x12>
    201a:	0785                	addi	a5,a5,1
    201c:	0077f713          	andi	a4,a5,7
    2020:	cb01                	beqz	a4,2030 <strlen+0x20>
		if (!*s)
    2022:	0007c703          	lbu	a4,0(a5)
    2026:	fb75                	bnez	a4,201a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2028:	40a78533          	sub	a0,a5,a0
}
    202c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    202e:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2030:	6394                	ld	a3,0(a5)
    2032:	00001597          	auipc	a1,0x1
    2036:	9fe5b583          	ld	a1,-1538(a1) # 2a30 <enable_deadlock_detect+0x282>
    203a:	00001617          	auipc	a2,0x1
    203e:	9fe63603          	ld	a2,-1538(a2) # 2a38 <enable_deadlock_detect+0x28a>
    2042:	a019                	j	2048 <strlen+0x38>
    2044:	6794                	ld	a3,8(a5)
    2046:	07a1                	addi	a5,a5,8
    2048:	00b68733          	add	a4,a3,a1
    204c:	fff6c693          	not	a3,a3
    2050:	8f75                	and	a4,a4,a3
    2052:	8f71                	and	a4,a4,a2
    2054:	db65                	beqz	a4,2044 <strlen+0x34>
	for (; *s; s++)
    2056:	0007c703          	lbu	a4,0(a5)
    205a:	d779                	beqz	a4,2028 <strlen+0x18>
    205c:	0017c703          	lbu	a4,1(a5)
    2060:	0785                	addi	a5,a5,1
    2062:	d379                	beqz	a4,2028 <strlen+0x18>
    2064:	0017c703          	lbu	a4,1(a5)
    2068:	0785                	addi	a5,a5,1
    206a:	fb6d                	bnez	a4,205c <strlen+0x4c>
    206c:	bf75                	j	2028 <strlen+0x18>

000000000000206e <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    206e:	00757713          	andi	a4,a0,7
{
    2072:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2074:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2078:	cb19                	beqz	a4,208e <memchr+0x20>
    207a:	ce25                	beqz	a2,20f2 <memchr+0x84>
    207c:	0007c703          	lbu	a4,0(a5)
    2080:	04b70e63          	beq	a4,a1,20dc <memchr+0x6e>
    2084:	0785                	addi	a5,a5,1
    2086:	0077f713          	andi	a4,a5,7
    208a:	167d                	addi	a2,a2,-1
    208c:	f77d                	bnez	a4,207a <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    208e:	4501                	li	a0,0
	if (n && *s != c) {
    2090:	c235                	beqz	a2,20f4 <memchr+0x86>
    2092:	0007c703          	lbu	a4,0(a5)
    2096:	04b70363          	beq	a4,a1,20dc <memchr+0x6e>
		size_t k = ONES * c;
    209a:	00001517          	auipc	a0,0x1
    209e:	9a653503          	ld	a0,-1626(a0) # 2a40 <enable_deadlock_detect+0x292>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20a2:	471d                	li	a4,7
		size_t k = ONES * c;
    20a4:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20a8:	02c77a63          	bgeu	a4,a2,20dc <memchr+0x6e>
    20ac:	00001897          	auipc	a7,0x1
    20b0:	9848b883          	ld	a7,-1660(a7) # 2a30 <enable_deadlock_detect+0x282>
    20b4:	00001817          	auipc	a6,0x1
    20b8:	98483803          	ld	a6,-1660(a6) # 2a38 <enable_deadlock_detect+0x28a>
    20bc:	431d                	li	t1,7
    20be:	a029                	j	20c8 <memchr+0x5a>
		     w++, n -= SS)
    20c0:	1661                	addi	a2,a2,-8
    20c2:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20c4:	02c37963          	bgeu	t1,a2,20f6 <memchr+0x88>
    20c8:	6398                	ld	a4,0(a5)
    20ca:	8f29                	xor	a4,a4,a0
    20cc:	011706b3          	add	a3,a4,a7
    20d0:	fff74713          	not	a4,a4
    20d4:	8f75                	and	a4,a4,a3
    20d6:	01077733          	and	a4,a4,a6
    20da:	d37d                	beqz	a4,20c0 <memchr+0x52>
{
    20dc:	853e                	mv	a0,a5
    20de:	97b2                	add	a5,a5,a2
    20e0:	a021                	j	20e8 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20e2:	0505                	addi	a0,a0,1
    20e4:	00f50763          	beq	a0,a5,20f2 <memchr+0x84>
    20e8:	00054703          	lbu	a4,0(a0)
    20ec:	feb71be3          	bne	a4,a1,20e2 <memchr+0x74>
    20f0:	8082                	ret
	return n ? (void *)s : 0;
    20f2:	4501                	li	a0,0
}
    20f4:	8082                	ret
	return n ? (void *)s : 0;
    20f6:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20f8:	f275                	bnez	a2,20dc <memchr+0x6e>
}
    20fa:	8082                	ret

00000000000020fc <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20fc:	1101                	addi	sp,sp,-32
    20fe:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2100:	862e                	mv	a2,a1
{
    2102:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2104:	4581                	li	a1,0
{
    2106:	e426                	sd	s1,8(sp)
    2108:	ec06                	sd	ra,24(sp)
    210a:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    210c:	f63ff0ef          	jal	ra,206e <memchr>
	return p ? p - s : n;
    2110:	c519                	beqz	a0,211e <strnlen+0x22>
}
    2112:	60e2                	ld	ra,24(sp)
    2114:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2116:	8d05                	sub	a0,a0,s1
}
    2118:	64a2                	ld	s1,8(sp)
    211a:	6105                	addi	sp,sp,32
    211c:	8082                	ret
    211e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2120:	8522                	mv	a0,s0
}
    2122:	6442                	ld	s0,16(sp)
    2124:	64a2                	ld	s1,8(sp)
    2126:	6105                	addi	sp,sp,32
    2128:	8082                	ret

000000000000212a <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    212a:	00a5c7b3          	xor	a5,a1,a0
    212e:	8b9d                	andi	a5,a5,7
    2130:	eb95                	bnez	a5,2164 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2132:	0075f793          	andi	a5,a1,7
    2136:	e7b1                	bnez	a5,2182 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2138:	6198                	ld	a4,0(a1)
    213a:	00001617          	auipc	a2,0x1
    213e:	8f663603          	ld	a2,-1802(a2) # 2a30 <enable_deadlock_detect+0x282>
    2142:	00001817          	auipc	a6,0x1
    2146:	8f683803          	ld	a6,-1802(a6) # 2a38 <enable_deadlock_detect+0x28a>
    214a:	a029                	j	2154 <stpcpy+0x2a>
    214c:	05a1                	addi	a1,a1,8
    214e:	e118                	sd	a4,0(a0)
    2150:	6198                	ld	a4,0(a1)
    2152:	0521                	addi	a0,a0,8
    2154:	00c707b3          	add	a5,a4,a2
    2158:	fff74693          	not	a3,a4
    215c:	8ff5                	and	a5,a5,a3
    215e:	0107f7b3          	and	a5,a5,a6
    2162:	d7ed                	beqz	a5,214c <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2164:	0005c783          	lbu	a5,0(a1)
    2168:	00f50023          	sb	a5,0(a0)
    216c:	c785                	beqz	a5,2194 <stpcpy+0x6a>
    216e:	0015c783          	lbu	a5,1(a1)
    2172:	0505                	addi	a0,a0,1
    2174:	0585                	addi	a1,a1,1
    2176:	00f50023          	sb	a5,0(a0)
    217a:	fbf5                	bnez	a5,216e <stpcpy+0x44>
		;
	return d;
}
    217c:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    217e:	0505                	addi	a0,a0,1
    2180:	df45                	beqz	a4,2138 <stpcpy+0xe>
			if (!(*d = *s))
    2182:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2186:	0585                	addi	a1,a1,1
    2188:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    218c:	00f50023          	sb	a5,0(a0)
    2190:	f7fd                	bnez	a5,217e <stpcpy+0x54>
}
    2192:	8082                	ret
    2194:	8082                	ret

0000000000002196 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2196:	00a5c7b3          	xor	a5,a1,a0
    219a:	8b9d                	andi	a5,a5,7
    219c:	1a079863          	bnez	a5,234c <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    21a0:	0075f793          	andi	a5,a1,7
    21a4:	16078463          	beqz	a5,230c <stpncpy+0x176>
    21a8:	ea01                	bnez	a2,21b8 <stpncpy+0x22>
    21aa:	a421                	j	23b2 <stpncpy+0x21c>
    21ac:	167d                	addi	a2,a2,-1
    21ae:	0505                	addi	a0,a0,1
    21b0:	14070e63          	beqz	a4,230c <stpncpy+0x176>
    21b4:	1a060863          	beqz	a2,2364 <stpncpy+0x1ce>
    21b8:	0005c783          	lbu	a5,0(a1)
    21bc:	0585                	addi	a1,a1,1
    21be:	0075f713          	andi	a4,a1,7
    21c2:	00f50023          	sb	a5,0(a0)
    21c6:	f3fd                	bnez	a5,21ac <stpncpy+0x16>
    21c8:	4805                	li	a6,1
    21ca:	1a061863          	bnez	a2,237a <stpncpy+0x1e4>
    21ce:	40a007b3          	neg	a5,a0
    21d2:	8b9d                	andi	a5,a5,7
    21d4:	4681                	li	a3,0
    21d6:	18061a63          	bnez	a2,236a <stpncpy+0x1d4>
    21da:	00778713          	addi	a4,a5,7
    21de:	45ad                	li	a1,11
    21e0:	18b76363          	bltu	a4,a1,2366 <stpncpy+0x1d0>
    21e4:	1ae6eb63          	bltu	a3,a4,239a <stpncpy+0x204>
    21e8:	1a078363          	beqz	a5,238e <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21ec:	00050023          	sb	zero,0(a0)
    21f0:	4685                	li	a3,1
    21f2:	00150713          	addi	a4,a0,1
    21f6:	18d78f63          	beq	a5,a3,2394 <stpncpy+0x1fe>
    21fa:	000500a3          	sb	zero,1(a0)
    21fe:	4689                	li	a3,2
    2200:	00250713          	addi	a4,a0,2
    2204:	18d78e63          	beq	a5,a3,23a0 <stpncpy+0x20a>
    2208:	00050123          	sb	zero,2(a0)
    220c:	468d                	li	a3,3
    220e:	00350713          	addi	a4,a0,3
    2212:	16d78c63          	beq	a5,a3,238a <stpncpy+0x1f4>
    2216:	000501a3          	sb	zero,3(a0)
    221a:	4691                	li	a3,4
    221c:	00450713          	addi	a4,a0,4
    2220:	18d78263          	beq	a5,a3,23a4 <stpncpy+0x20e>
    2224:	00050223          	sb	zero,4(a0)
    2228:	4695                	li	a3,5
    222a:	00550713          	addi	a4,a0,5
    222e:	16d78d63          	beq	a5,a3,23a8 <stpncpy+0x212>
    2232:	000502a3          	sb	zero,5(a0)
    2236:	469d                	li	a3,7
    2238:	00650713          	addi	a4,a0,6
    223c:	16d79863          	bne	a5,a3,23ac <stpncpy+0x216>
    2240:	00750713          	addi	a4,a0,7
    2244:	00050323          	sb	zero,6(a0)
    2248:	40f80833          	sub	a6,a6,a5
    224c:	ff887593          	andi	a1,a6,-8
    2250:	97aa                	add	a5,a5,a0
    2252:	95be                	add	a1,a1,a5
    2254:	0007b023          	sd	zero,0(a5)
    2258:	07a1                	addi	a5,a5,8
    225a:	feb79de3          	bne	a5,a1,2254 <stpncpy+0xbe>
    225e:	ff887593          	andi	a1,a6,-8
    2262:	9ead                	addw	a3,a3,a1
    2264:	00b707b3          	add	a5,a4,a1
    2268:	12b80863          	beq	a6,a1,2398 <stpncpy+0x202>
    226c:	00078023          	sb	zero,0(a5)
    2270:	0016871b          	addiw	a4,a3,1
    2274:	0ec77863          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    2278:	000780a3          	sb	zero,1(a5)
    227c:	0026871b          	addiw	a4,a3,2
    2280:	0ec77263          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    2284:	00078123          	sb	zero,2(a5)
    2288:	0036871b          	addiw	a4,a3,3
    228c:	0cc77c63          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    2290:	000781a3          	sb	zero,3(a5)
    2294:	0046871b          	addiw	a4,a3,4
    2298:	0cc77663          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    229c:	00078223          	sb	zero,4(a5)
    22a0:	0056871b          	addiw	a4,a3,5
    22a4:	0cc77063          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22a8:	000782a3          	sb	zero,5(a5)
    22ac:	0066871b          	addiw	a4,a3,6
    22b0:	0ac77a63          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22b4:	00078323          	sb	zero,6(a5)
    22b8:	0076871b          	addiw	a4,a3,7
    22bc:	0ac77463          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22c0:	000783a3          	sb	zero,7(a5)
    22c4:	0086871b          	addiw	a4,a3,8
    22c8:	08c77e63          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22cc:	00078423          	sb	zero,8(a5)
    22d0:	0096871b          	addiw	a4,a3,9
    22d4:	08c77863          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22d8:	000784a3          	sb	zero,9(a5)
    22dc:	00a6871b          	addiw	a4,a3,10
    22e0:	08c77263          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22e4:	00078523          	sb	zero,10(a5)
    22e8:	00b6871b          	addiw	a4,a3,11
    22ec:	06c77c63          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22f0:	000785a3          	sb	zero,11(a5)
    22f4:	00c6871b          	addiw	a4,a3,12
    22f8:	06c77663          	bgeu	a4,a2,2364 <stpncpy+0x1ce>
    22fc:	00078623          	sb	zero,12(a5)
    2300:	26b5                	addiw	a3,a3,13
    2302:	06c6f163          	bgeu	a3,a2,2364 <stpncpy+0x1ce>
    2306:	000786a3          	sb	zero,13(a5)
    230a:	8082                	ret
			;
		if (!n || !*s)
    230c:	c645                	beqz	a2,23b4 <stpncpy+0x21e>
    230e:	0005c783          	lbu	a5,0(a1)
    2312:	ea078be3          	beqz	a5,21c8 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2316:	479d                	li	a5,7
    2318:	02c7ff63          	bgeu	a5,a2,2356 <stpncpy+0x1c0>
    231c:	00000897          	auipc	a7,0x0
    2320:	7148b883          	ld	a7,1812(a7) # 2a30 <enable_deadlock_detect+0x282>
    2324:	00000817          	auipc	a6,0x0
    2328:	71483803          	ld	a6,1812(a6) # 2a38 <enable_deadlock_detect+0x28a>
    232c:	431d                	li	t1,7
    232e:	6198                	ld	a4,0(a1)
    2330:	011707b3          	add	a5,a4,a7
    2334:	fff74693          	not	a3,a4
    2338:	8ff5                	and	a5,a5,a3
    233a:	0107f7b3          	and	a5,a5,a6
    233e:	ef81                	bnez	a5,2356 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2340:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2342:	1661                	addi	a2,a2,-8
    2344:	05a1                	addi	a1,a1,8
    2346:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2348:	fec363e3          	bltu	t1,a2,232e <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    234c:	e609                	bnez	a2,2356 <stpncpy+0x1c0>
    234e:	a08d                	j	23b0 <stpncpy+0x21a>
    2350:	167d                	addi	a2,a2,-1
    2352:	0505                	addi	a0,a0,1
    2354:	ca01                	beqz	a2,2364 <stpncpy+0x1ce>
    2356:	0005c783          	lbu	a5,0(a1)
    235a:	0585                	addi	a1,a1,1
    235c:	00f50023          	sb	a5,0(a0)
    2360:	fbe5                	bnez	a5,2350 <stpncpy+0x1ba>
		;
tail:
    2362:	b59d                	j	21c8 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2364:	8082                	ret
    2366:	472d                	li	a4,11
    2368:	bdb5                	j	21e4 <stpncpy+0x4e>
    236a:	00778713          	addi	a4,a5,7
    236e:	45ad                	li	a1,11
    2370:	fff60693          	addi	a3,a2,-1
    2374:	e6b778e3          	bgeu	a4,a1,21e4 <stpncpy+0x4e>
    2378:	b7fd                	j	2366 <stpncpy+0x1d0>
    237a:	40a007b3          	neg	a5,a0
    237e:	8832                	mv	a6,a2
    2380:	8b9d                	andi	a5,a5,7
    2382:	4681                	li	a3,0
    2384:	e4060be3          	beqz	a2,21da <stpncpy+0x44>
    2388:	b7cd                	j	236a <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    238a:	468d                	li	a3,3
    238c:	bd75                	j	2248 <stpncpy+0xb2>
    238e:	872a                	mv	a4,a0
    2390:	4681                	li	a3,0
    2392:	bd5d                	j	2248 <stpncpy+0xb2>
    2394:	4685                	li	a3,1
    2396:	bd4d                	j	2248 <stpncpy+0xb2>
    2398:	8082                	ret
    239a:	87aa                	mv	a5,a0
    239c:	4681                	li	a3,0
    239e:	b5f9                	j	226c <stpncpy+0xd6>
    23a0:	4689                	li	a3,2
    23a2:	b55d                	j	2248 <stpncpy+0xb2>
    23a4:	4691                	li	a3,4
    23a6:	b54d                	j	2248 <stpncpy+0xb2>
    23a8:	4695                	li	a3,5
    23aa:	bd79                	j	2248 <stpncpy+0xb2>
    23ac:	4699                	li	a3,6
    23ae:	bd69                	j	2248 <stpncpy+0xb2>
    23b0:	8082                	ret
    23b2:	8082                	ret
    23b4:	8082                	ret

00000000000023b6 <basename>:

char *basename(char *s)
{
    23b6:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    23b8:	c54d                	beqz	a0,2462 <basename+0xac>
    23ba:	00054783          	lbu	a5,0(a0)
		return ".";
    23be:	00000517          	auipc	a0,0x0
    23c2:	66a50513          	addi	a0,a0,1642 # 2a28 <enable_deadlock_detect+0x27a>
	if (!s || !*s)
    23c6:	e391                	bnez	a5,23ca <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    23c8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23ca:	0076f713          	andi	a4,a3,7
    23ce:	87b6                	mv	a5,a3
    23d0:	cf51                	beqz	a4,246c <basename+0xb6>
    23d2:	0785                	addi	a5,a5,1
    23d4:	0077f713          	andi	a4,a5,7
    23d8:	c729                	beqz	a4,2422 <basename+0x6c>
		if (!*s)
    23da:	0007c703          	lbu	a4,0(a5)
    23de:	fb75                	bnez	a4,23d2 <basename+0x1c>
	return s - a;
    23e0:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23e2:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23e4:	cf8d                	beqz	a5,241e <basename+0x68>
    23e6:	00f68733          	add	a4,a3,a5
    23ea:	02f00593          	li	a1,47
    23ee:	a031                	j	23fa <basename+0x44>
		s[i] = 0;
    23f0:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23f4:	17fd                	addi	a5,a5,-1
    23f6:	177d                	addi	a4,a4,-1
    23f8:	c39d                	beqz	a5,241e <basename+0x68>
    23fa:	00074603          	lbu	a2,0(a4)
    23fe:	feb609e3          	beq	a2,a1,23f0 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2402:	02f00613          	li	a2,47
    2406:	a011                	j	240a <basename+0x54>
    2408:	cb99                	beqz	a5,241e <basename+0x68>
    240a:	853e                	mv	a0,a5
    240c:	17fd                	addi	a5,a5,-1
    240e:	00f68733          	add	a4,a3,a5
    2412:	00074703          	lbu	a4,0(a4)
    2416:	fec719e3          	bne	a4,a2,2408 <basename+0x52>
	return s + i;
    241a:	9536                	add	a0,a0,a3
    241c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    241e:	8536                	mv	a0,a3
    2420:	8082                	ret
    2422:	6390                	ld	a2,0(a5)
    2424:	00000517          	auipc	a0,0x0
    2428:	60c53503          	ld	a0,1548(a0) # 2a30 <enable_deadlock_detect+0x282>
    242c:	00000597          	auipc	a1,0x0
    2430:	60c5b583          	ld	a1,1548(a1) # 2a38 <enable_deadlock_detect+0x28a>
    2434:	fff64713          	not	a4,a2
    2438:	962a                	add	a2,a2,a0
    243a:	8f71                	and	a4,a4,a2
    243c:	8f6d                	and	a4,a4,a1
    243e:	eb11                	bnez	a4,2452 <basename+0x9c>
    2440:	6790                	ld	a2,8(a5)
    2442:	07a1                	addi	a5,a5,8
    2444:	00a60733          	add	a4,a2,a0
    2448:	fff64613          	not	a2,a2
    244c:	8f71                	and	a4,a4,a2
    244e:	8f6d                	and	a4,a4,a1
    2450:	db65                	beqz	a4,2440 <basename+0x8a>
	for (; *s; s++)
    2452:	0007c703          	lbu	a4,0(a5)
    2456:	d749                	beqz	a4,23e0 <basename+0x2a>
    2458:	0017c703          	lbu	a4,1(a5)
    245c:	0785                	addi	a5,a5,1
    245e:	ff6d                	bnez	a4,2458 <basename+0xa2>
    2460:	b741                	j	23e0 <basename+0x2a>
		return ".";
    2462:	00000517          	auipc	a0,0x0
    2466:	5c650513          	addi	a0,a0,1478 # 2a28 <enable_deadlock_detect+0x27a>
    246a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    246c:	6290                	ld	a2,0(a3)
    246e:	00000517          	auipc	a0,0x0
    2472:	5c253503          	ld	a0,1474(a0) # 2a30 <enable_deadlock_detect+0x282>
    2476:	00000597          	auipc	a1,0x0
    247a:	5c25b583          	ld	a1,1474(a1) # 2a38 <enable_deadlock_detect+0x28a>
    247e:	fff64713          	not	a4,a2
    2482:	962a                	add	a2,a2,a0
    2484:	8f71                	and	a4,a4,a2
    2486:	8f6d                	and	a4,a4,a1
    2488:	df45                	beqz	a4,2440 <basename+0x8a>
    248a:	b7f9                	j	2458 <basename+0xa2>

000000000000248c <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    248c:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2490:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2492:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2496:	2501                	sext.w	a0,a0
    2498:	8082                	ret

000000000000249a <close>:

int close(int fd)
{
	if (fd == 1) {
    249a:	4785                	li	a5,1
    249c:	00f50863          	beq	a0,a5,24ac <close+0x12>
	register long a7 __asm__("a7") = n;
    24a0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24a4:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    24a8:	2501                	sext.w	a0,a0
    24aa:	8082                	ret
{
    24ac:	1101                	addi	sp,sp,-32
    24ae:	ec06                	sd	ra,24(sp)
    24b0:	e42a                	sd	a0,8(sp)
		__write_buffer();
    24b2:	cdffe0ef          	jal	ra,1190 <__write_buffer>
		__clear_buffer();
    24b6:	d03fe0ef          	jal	ra,11b8 <__clear_buffer>
    24ba:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    24bc:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24c0:	00000073          	ecall
}
    24c4:	60e2                	ld	ra,24(sp)
    24c6:	2501                	sext.w	a0,a0
    24c8:	6105                	addi	sp,sp,32
    24ca:	8082                	ret

00000000000024cc <read>:
	register long a7 __asm__("a7") = n;
    24cc:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24d0:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24d4:	8082                	ret

00000000000024d6 <write>:
	register long a7 __asm__("a7") = n;
    24d6:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24da:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    24de:	8082                	ret

00000000000024e0 <getpid>:
	register long a7 __asm__("a7") = n;
    24e0:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24e4:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24e8:	2501                	sext.w	a0,a0
    24ea:	8082                	ret

00000000000024ec <getppid>:
	register long a7 __asm__("a7") = n;
    24ec:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24f0:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24f4:	2501                	sext.w	a0,a0
    24f6:	8082                	ret

00000000000024f8 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24f8:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24fc:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2500:	2501                	sext.w	a0,a0
    2502:	8082                	ret

0000000000002504 <fork>:
	register long a7 __asm__("a7") = n;
    2504:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2508:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    250c:	2501                	sext.w	a0,a0
    250e:	8082                	ret

0000000000002510 <exit>:

void exit(int code)
{
    2510:	1141                	addi	sp,sp,-16
    2512:	e406                	sd	ra,8(sp)
    2514:	e022                	sd	s0,0(sp)
    2516:	842a                	mv	s0,a0
	__write_buffer();
    2518:	c79fe0ef          	jal	ra,1190 <__write_buffer>
	__clear_buffer();
    251c:	c9dfe0ef          	jal	ra,11b8 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2520:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2524:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2526:	00000073          	ecall
	syscall(SYS_exit, code);
}
    252a:	60a2                	ld	ra,8(sp)
    252c:	6402                	ld	s0,0(sp)
    252e:	0141                	addi	sp,sp,16
    2530:	8082                	ret

0000000000002532 <waitpid>:
	register long a7 __asm__("a7") = n;
    2532:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2536:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    253a:	2501                	sext.w	a0,a0
    253c:	8082                	ret

000000000000253e <exec>:
	register long a7 __asm__("a7") = n;
    253e:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2542:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2546:	2501                	sext.w	a0,a0
    2548:	8082                	ret

000000000000254a <get_mtime>:

int64 get_mtime()
{
    254a:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    254c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2550:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2552:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2554:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2558:	2501                	sext.w	a0,a0
    255a:	ed01                	bnez	a0,2572 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    255c:	6722                	ld	a4,8(sp)
    255e:	3e800793          	li	a5,1000
    2562:	6682                	ld	a3,0(sp)
    2564:	02f75733          	divu	a4,a4,a5
    2568:	02d78533          	mul	a0,a5,a3
    256c:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    256e:	0141                	addi	sp,sp,16
    2570:	8082                	ret
	return -1;
    2572:	557d                	li	a0,-1
    2574:	bfed                	j	256e <get_mtime+0x24>

0000000000002576 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2576:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    257a:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <sleep>:

int sleep(unsigned long long time)
{
    2582:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2584:	880a                	mv	a6,sp
{
    2586:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2588:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    258c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    258e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2590:	00000073          	ecall
	if (err == 0) {
    2594:	2501                	sext.w	a0,a0
    2596:	ed31                	bnez	a0,25f2 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2598:	6722                	ld	a4,8(sp)
    259a:	3e800793          	li	a5,1000
    259e:	6682                	ld	a3,0(sp)
    25a0:	02f75733          	divu	a4,a4,a5
    25a4:	02d787b3          	mul	a5,a5,a3
    25a8:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    25aa:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25ae:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25b0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25b2:	00000073          	ecall
	if (err == 0) {
    25b6:	2501                	sext.w	a0,a0
    25b8:	e915                	bnez	a0,25ec <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    25ba:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    25bc:	3e800693          	li	a3,1000
    25c0:	a819                	j	25d6 <sleep+0x54>
	__asm_syscall("r"(a7))
    25c2:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25c6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25ca:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25cc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ce:	00000073          	ecall
	if (err == 0) {
    25d2:	2501                	sext.w	a0,a0
    25d4:	ed01                	bnez	a0,25ec <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25d6:	6722                	ld	a4,8(sp)
    25d8:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25da:	07c00893          	li	a7,124
    25de:	02d75733          	divu	a4,a4,a3
    25e2:	02f687b3          	mul	a5,a3,a5
    25e6:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25e8:	fcc7ede3          	bltu	a5,a2,25c2 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25ec:	4501                	li	a0,0
    25ee:	0141                	addi	sp,sp,16
    25f0:	8082                	ret
    25f2:	57fd                	li	a5,-1
    25f4:	bf5d                	j	25aa <sleep+0x28>

00000000000025f6 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25f6:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25fa:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <set_priority>:
	register long a7 __asm__("a7") = n;
    2602:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2606:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret

000000000000260e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    260e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2612:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2616:	2501                	sext.w	a0,a0
    2618:	8082                	ret

000000000000261a <munmap>:
	register long a7 __asm__("a7") = n;
    261a:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261e:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2622:	2501                	sext.w	a0,a0
    2624:	8082                	ret

0000000000002626 <wait>:

int wait(int *code)
{
    2626:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2628:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    262c:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    262e:	00000073          	ecall
	return waitpid(-1, code);
}
    2632:	2501                	sext.w	a0,a0
    2634:	8082                	ret

0000000000002636 <spawn>:
	register long a7 __asm__("a7") = n;
    2636:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    263a:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    263e:	2501                	sext.w	a0,a0
    2640:	8082                	ret

0000000000002642 <pipe>:
	register long a7 __asm__("a7") = n;
    2642:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2646:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    264a:	2501                	sext.w	a0,a0
    264c:	8082                	ret

000000000000264e <mailread>:
	register long a7 __asm__("a7") = n;
    264e:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2652:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret

000000000000265a <mailwrite>:
	register long a7 __asm__("a7") = n;
    265a:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    265e:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2662:	2501                	sext.w	a0,a0
    2664:	8082                	ret

0000000000002666 <fstat>:
	register long a7 __asm__("a7") = n;
    2666:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266a:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    266e:	2501                	sext.w	a0,a0
    2670:	8082                	ret

0000000000002672 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2672:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2674:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2678:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    267a:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2682:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2684:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2688:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    268a:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    268e:	2501                	sext.w	a0,a0
    2690:	8082                	ret

0000000000002692 <link>:

int link(char *old_path, char *new_path)
{
    2692:	87aa                	mv	a5,a0
    2694:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2696:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    269a:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    269e:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    26a0:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    26a4:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26a6:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    26aa:	2501                	sext.w	a0,a0
    26ac:	8082                	ret

00000000000026ae <unlink>:

int unlink(char *path)
{
    26ae:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26b0:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    26b4:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    26b8:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26ba:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    26be:	2501                	sext.w	a0,a0
    26c0:	8082                	ret

00000000000026c2 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    26c2:	00000797          	auipc	a5,0x0
    26c6:	4b67b783          	ld	a5,1206(a5) # 2b78 <_GLOBAL_OFFSET_TABLE_+0x8>
    26ca:	439c                	lw	a5,0(a5)
    26cc:	c799                	beqz	a5,26da <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    26ce:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26d2:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26d6:	2501                	sext.w	a0,a0
    26d8:	8082                	ret
{
    26da:	1101                	addi	sp,sp,-32
    26dc:	ec06                	sd	ra,24(sp)
    26de:	e42e                	sd	a1,8(sp)
    26e0:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26e2:	fe7fe0ef          	jal	ra,16c8 <enable_thread_io_buffer>
    26e6:	65a2                	ld	a1,8(sp)
    26e8:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26ea:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ee:	00000073          	ecall
}
    26f2:	60e2                	ld	ra,24(sp)
    26f4:	2501                	sext.w	a0,a0
    26f6:	6105                	addi	sp,sp,32
    26f8:	8082                	ret

00000000000026fa <gettid>:
	register long a7 __asm__("a7") = n;
    26fa:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26fe:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2702:	2501                	sext.w	a0,a0
    2704:	8082                	ret

0000000000002706 <waittid>:

int waittid(int tid)
{
    2706:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2708:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    270c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2710:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2712:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2714:	00e51e63          	bne	a0,a4,2730 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2718:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    271c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2720:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2724:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2726:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    272a:	2501                	sext.w	a0,a0
	while (ret == -2) {
    272c:	fee506e3          	beq	a0,a4,2718 <waittid+0x12>
	}
	return ret;
}
    2730:	8082                	ret

0000000000002732 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2732:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2736:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2738:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    273c:	2501                	sext.w	a0,a0
    273e:	8082                	ret

0000000000002740 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2740:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2744:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2746:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <mutex_lock>:
	register long a7 __asm__("a7") = n;
    274e:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2752:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    275a:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    275e:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2762:	2501                	sext.w	a0,a0
    2764:	8082                	ret

0000000000002766 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2766:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    276a:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    276e:	2501                	sext.w	a0,a0
    2770:	8082                	ret

0000000000002772 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2772:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2776:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    277a:	2501                	sext.w	a0,a0
    277c:	8082                	ret

000000000000277e <semaphore_down>:
	register long a7 __asm__("a7") = n;
    277e:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2782:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2786:	2501                	sext.w	a0,a0
    2788:	8082                	ret

000000000000278a <condvar_create>:
	register long a7 __asm__("a7") = n;
    278a:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    278e:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2792:	2501                	sext.w	a0,a0
    2794:	8082                	ret

0000000000002796 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2796:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    279a:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    279e:	2501                	sext.w	a0,a0
    27a0:	8082                	ret

00000000000027a2 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    27a2:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27a6:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    27aa:	2501                	sext.w	a0,a0
    27ac:	8082                	ret

00000000000027ae <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    27ae:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    27b2:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    27b6:	2501                	sext.w	a0,a0
    27b8:	8082                	ret
