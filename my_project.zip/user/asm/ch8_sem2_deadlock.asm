
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8_sem2_deadlock:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a339                	j	150e <__start_main>

0000000000001002 <try_sem_down.part.0>:
int semaphore_barrier_id;

void try_sem_down(int id, int sem_id)
{
	if (semaphore_down(sem_id) == -0xdead) {
		assert_eq(semaphore_up(alloc[id]), 0);
    1002:	050a                	slli	a0,a0,0x2
    1004:	00002797          	auipc	a5,0x2
    1008:	f1c78793          	addi	a5,a5,-228 # 2f20 <alloc>
void try_sem_down(int id, int sem_id)
    100c:	1101                	addi	sp,sp,-32
		assert_eq(semaphore_up(alloc[id]), 0);
    100e:	97aa                	add	a5,a5,a0
void try_sem_down(int id, int sem_id)
    1010:	e822                	sd	s0,16(sp)
		assert_eq(semaphore_up(alloc[id]), 0);
    1012:	4380                	lw	s0,0(a5)
void try_sem_down(int id, int sem_id)
    1014:	ec06                	sd	ra,24(sp)
    1016:	e426                	sd	s1,8(sp)
		assert_eq(semaphore_up(alloc[id]), 0);
    1018:	8522                	mv	a0,s0
    101a:	313010ef          	jal	ra,2b2c <semaphore_up>
    101e:	e105                	bnez	a0,103e <try_sem_down.part.0+0x3c>
		assert_eq(semaphore_up(semaphore_barrier_id), 0);
    1020:	00002417          	auipc	s0,0x2
    1024:	dd840413          	addi	s0,s0,-552 # 2df8 <semaphore_barrier_id>
    1028:	4008                	lw	a0,0(s0)
    102a:	303010ef          	jal	ra,2b2c <semaphore_up>
    102e:	e12d                	bnez	a0,1090 <try_sem_down.part.0+0x8e>
		exit(-1);
	}
}
    1030:	6442                	ld	s0,16(sp)
    1032:	60e2                	ld	ra,24(sp)
    1034:	64a2                	ld	s1,8(sp)
		exit(-1);
    1036:	557d                	li	a0,-1
}
    1038:	6105                	addi	sp,sp,32
		exit(-1);
    103a:	0910106f          	j	28ca <exit>
		assert_eq(semaphore_up(alloc[id]), 0);
    103e:	05d010ef          	jal	ra,289a <getpid>
    1042:	84aa                	mv	s1,a0
    1044:	00002517          	auipc	a0,0x2
    1048:	b3450513          	addi	a0,a0,-1228 # 2b78 <enable_deadlock_detect+0x10>
    104c:	724010ef          	jal	ra,2770 <basename>
    1050:	872a                	mv	a4,a0
    1052:	8522                	mv	a0,s0
    1054:	843a                	mv	s0,a4
    1056:	2d7010ef          	jal	ra,2b2c <semaphore_up>
    105a:	882a                	mv	a6,a0
    105c:	8722                	mv	a4,s0
    105e:	4881                	li	a7,0
    1060:	00002517          	auipc	a0,0x2
    1064:	b7050513          	addi	a0,a0,-1168 # 2bd0 <enable_deadlock_detect+0x68>
    1068:	47dd                	li	a5,23
    106a:	86a6                	mv	a3,s1
    106c:	00002617          	auipc	a2,0x2
    1070:	b5c60613          	addi	a2,a2,-1188 # 2bc8 <enable_deadlock_detect+0x60>
    1074:	45fd                	li	a1,31
    1076:	5f2000ef          	jal	ra,1668 <printf>
    107a:	557d                	li	a0,-1
    107c:	04f010ef          	jal	ra,28ca <exit>
		assert_eq(semaphore_up(semaphore_barrier_id), 0);
    1080:	00002417          	auipc	s0,0x2
    1084:	d7840413          	addi	s0,s0,-648 # 2df8 <semaphore_barrier_id>
    1088:	4008                	lw	a0,0(s0)
    108a:	2a3010ef          	jal	ra,2b2c <semaphore_up>
    108e:	d14d                	beqz	a0,1030 <try_sem_down.part.0+0x2e>
    1090:	00b010ef          	jal	ra,289a <getpid>
    1094:	84aa                	mv	s1,a0
    1096:	00002517          	auipc	a0,0x2
    109a:	ae250513          	addi	a0,a0,-1310 # 2b78 <enable_deadlock_detect+0x10>
    109e:	6d2010ef          	jal	ra,2770 <basename>
    10a2:	872a                	mv	a4,a0
    10a4:	4008                	lw	a0,0(s0)
    10a6:	843a                	mv	s0,a4
    10a8:	285010ef          	jal	ra,2b2c <semaphore_up>
    10ac:	882a                	mv	a6,a0
    10ae:	8722                	mv	a4,s0
    10b0:	86a6                	mv	a3,s1
    10b2:	4881                	li	a7,0
    10b4:	00002517          	auipc	a0,0x2
    10b8:	b1c50513          	addi	a0,a0,-1252 # 2bd0 <enable_deadlock_detect+0x68>
    10bc:	47e1                	li	a5,24
    10be:	00002617          	auipc	a2,0x2
    10c2:	b0a60613          	addi	a2,a2,-1270 # 2bc8 <enable_deadlock_detect+0x60>
    10c6:	45fd                	li	a1,31
    10c8:	5a0000ef          	jal	ra,1668 <printf>
    10cc:	557d                	li	a0,-1
    10ce:	7fc010ef          	jal	ra,28ca <exit>
}
    10d2:	6442                	ld	s0,16(sp)
    10d4:	60e2                	ld	ra,24(sp)
    10d6:	64a2                	ld	s1,8(sp)
		exit(-1);
    10d8:	557d                	li	a0,-1
}
    10da:	6105                	addi	sp,sp,32
		exit(-1);
    10dc:	7ee0106f          	j	28ca <exit>

00000000000010e0 <deadlock_test>:

void deadlock_test(long _id)
{
    10e0:	7139                	addi	sp,sp,-64
    10e2:	f822                	sd	s0,48(sp)
	int id = _id;
    10e4:	0005041b          	sext.w	s0,a0
{
    10e8:	ec4e                	sd	s3,24(sp)
	assert_eq(semaphore_down(alloc[id]), 0);
    10ea:	00002797          	auipc	a5,0x2
    10ee:	e3678793          	addi	a5,a5,-458 # 2f20 <alloc>
    10f2:	00241993          	slli	s3,s0,0x2
    10f6:	97ce                	add	a5,a5,s3
{
    10f8:	f426                	sd	s1,40(sp)
	assert_eq(semaphore_down(alloc[id]), 0);
    10fa:	4384                	lw	s1,0(a5)
{
    10fc:	fc06                	sd	ra,56(sp)
    10fe:	f04a                	sd	s2,32(sp)
	assert_eq(semaphore_down(alloc[id]), 0);
    1100:	8526                	mv	a0,s1
{
    1102:	e852                	sd	s4,16(sp)
    1104:	e456                	sd	s5,8(sp)
	assert_eq(semaphore_down(alloc[id]), 0);
    1106:	233010ef          	jal	ra,2b38 <semaphore_down>
    110a:	18051b63          	bnez	a0,12a0 <deadlock_test+0x1c0>
	assert_eq(semaphore_down(semaphore_barrier_id), 0);
    110e:	00002917          	auipc	s2,0x2
    1112:	cea90913          	addi	s2,s2,-790 # 2df8 <semaphore_barrier_id>
    1116:	00092503          	lw	a0,0(s2)
    111a:	21f010ef          	jal	ra,2b38 <semaphore_down>
    111e:	12051e63          	bnez	a0,125a <deadlock_test+0x17a>
	int sem_id = request[id];
    1122:	00002797          	auipc	a5,0x2
    1126:	dee78793          	addi	a5,a5,-530 # 2f10 <request>
    112a:	97ce                	add	a5,a5,s3
    112c:	0007a983          	lw	s3,0(a5)
	if (sem_id >= 0) {
    1130:	0209d763          	bgez	s3,115e <deadlock_test+0x7e>
		try_sem_down(id, sem_id);
		assert_eq(semaphore_up(sem_id), 0);
	}
	assert_eq(semaphore_up(semaphore_barrier_id), 0);
    1134:	00092503          	lw	a0,0(s2)
    1138:	1f5010ef          	jal	ra,2b2c <semaphore_up>
    113c:	e541                	bnez	a0,11c4 <deadlock_test+0xe4>
	assert_eq(semaphore_up(alloc[id]), 0);
    113e:	8526                	mv	a0,s1
    1140:	1ed010ef          	jal	ra,2b2c <semaphore_up>
    1144:	0c051863          	bnez	a0,1214 <deadlock_test+0x134>
	exit(0);
}
    1148:	7442                	ld	s0,48(sp)
    114a:	70e2                	ld	ra,56(sp)
    114c:	74a2                	ld	s1,40(sp)
    114e:	7902                	ld	s2,32(sp)
    1150:	69e2                	ld	s3,24(sp)
    1152:	6a42                	ld	s4,16(sp)
    1154:	6aa2                	ld	s5,8(sp)
	exit(0);
    1156:	4501                	li	a0,0
}
    1158:	6121                	addi	sp,sp,64
	exit(0);
    115a:	7700106f          	j	28ca <exit>
	if (semaphore_down(sem_id) == -0xdead) {
    115e:	854e                	mv	a0,s3
    1160:	1d9010ef          	jal	ra,2b38 <semaphore_down>
    1164:	77c9                	lui	a5,0xffff2
    1166:	15378793          	addi	a5,a5,339 # ffffffffffff2153 <.got.plt+0xfffffffffffef1f3>
    116a:	16f50d63          	beq	a0,a5,12e4 <deadlock_test+0x204>
		assert_eq(semaphore_up(sem_id), 0);
    116e:	854e                	mv	a0,s3
    1170:	1bd010ef          	jal	ra,2b2c <semaphore_up>
    1174:	d161                	beqz	a0,1134 <deadlock_test+0x54>
    1176:	724010ef          	jal	ra,289a <getpid>
    117a:	842a                	mv	s0,a0
    117c:	00002517          	auipc	a0,0x2
    1180:	9fc50513          	addi	a0,a0,-1540 # 2b78 <enable_deadlock_detect+0x10>
    1184:	5ec010ef          	jal	ra,2770 <basename>
    1188:	872a                	mv	a4,a0
    118a:	854e                	mv	a0,s3
    118c:	89ba                	mv	s3,a4
    118e:	19f010ef          	jal	ra,2b2c <semaphore_up>
    1192:	882a                	mv	a6,a0
    1194:	4881                	li	a7,0
    1196:	00002517          	auipc	a0,0x2
    119a:	a3a50513          	addi	a0,a0,-1478 # 2bd0 <enable_deadlock_detect+0x68>
    119e:	02500793          	li	a5,37
    11a2:	874e                	mv	a4,s3
    11a4:	86a2                	mv	a3,s0
    11a6:	00002617          	auipc	a2,0x2
    11aa:	a2260613          	addi	a2,a2,-1502 # 2bc8 <enable_deadlock_detect+0x60>
    11ae:	45fd                	li	a1,31
    11b0:	4b8000ef          	jal	ra,1668 <printf>
    11b4:	557d                	li	a0,-1
    11b6:	714010ef          	jal	ra,28ca <exit>
	assert_eq(semaphore_up(semaphore_barrier_id), 0);
    11ba:	00092503          	lw	a0,0(s2)
    11be:	16f010ef          	jal	ra,2b2c <semaphore_up>
    11c2:	dd35                	beqz	a0,113e <deadlock_test+0x5e>
    11c4:	6d6010ef          	jal	ra,289a <getpid>
    11c8:	842a                	mv	s0,a0
    11ca:	00002517          	auipc	a0,0x2
    11ce:	9ae50513          	addi	a0,a0,-1618 # 2b78 <enable_deadlock_detect+0x10>
    11d2:	59e010ef          	jal	ra,2770 <basename>
    11d6:	872a                	mv	a4,a0
    11d8:	00092503          	lw	a0,0(s2)
    11dc:	893a                	mv	s2,a4
    11de:	14f010ef          	jal	ra,2b2c <semaphore_up>
    11e2:	882a                	mv	a6,a0
    11e4:	4881                	li	a7,0
    11e6:	00002517          	auipc	a0,0x2
    11ea:	9ea50513          	addi	a0,a0,-1558 # 2bd0 <enable_deadlock_detect+0x68>
    11ee:	02700793          	li	a5,39
    11f2:	874a                	mv	a4,s2
    11f4:	86a2                	mv	a3,s0
    11f6:	00002617          	auipc	a2,0x2
    11fa:	9d260613          	addi	a2,a2,-1582 # 2bc8 <enable_deadlock_detect+0x60>
    11fe:	45fd                	li	a1,31
    1200:	468000ef          	jal	ra,1668 <printf>
    1204:	557d                	li	a0,-1
    1206:	6c4010ef          	jal	ra,28ca <exit>
	assert_eq(semaphore_up(alloc[id]), 0);
    120a:	8526                	mv	a0,s1
    120c:	121010ef          	jal	ra,2b2c <semaphore_up>
    1210:	f2050ce3          	beqz	a0,1148 <deadlock_test+0x68>
    1214:	686010ef          	jal	ra,289a <getpid>
    1218:	842a                	mv	s0,a0
    121a:	00002517          	auipc	a0,0x2
    121e:	95e50513          	addi	a0,a0,-1698 # 2b78 <enable_deadlock_detect+0x10>
    1222:	54e010ef          	jal	ra,2770 <basename>
    1226:	872a                	mv	a4,a0
    1228:	8526                	mv	a0,s1
    122a:	84ba                	mv	s1,a4
    122c:	101010ef          	jal	ra,2b2c <semaphore_up>
    1230:	882a                	mv	a6,a0
    1232:	4881                	li	a7,0
    1234:	00002517          	auipc	a0,0x2
    1238:	99c50513          	addi	a0,a0,-1636 # 2bd0 <enable_deadlock_detect+0x68>
    123c:	02800793          	li	a5,40
    1240:	8726                	mv	a4,s1
    1242:	86a2                	mv	a3,s0
    1244:	00002617          	auipc	a2,0x2
    1248:	98460613          	addi	a2,a2,-1660 # 2bc8 <enable_deadlock_detect+0x60>
    124c:	45fd                	li	a1,31
    124e:	41a000ef          	jal	ra,1668 <printf>
    1252:	557d                	li	a0,-1
    1254:	676010ef          	jal	ra,28ca <exit>
    1258:	bdc5                	j	1148 <deadlock_test+0x68>
	assert_eq(semaphore_down(semaphore_barrier_id), 0);
    125a:	640010ef          	jal	ra,289a <getpid>
    125e:	8a2a                	mv	s4,a0
    1260:	00002517          	auipc	a0,0x2
    1264:	91850513          	addi	a0,a0,-1768 # 2b78 <enable_deadlock_detect+0x10>
    1268:	508010ef          	jal	ra,2770 <basename>
    126c:	8aaa                	mv	s5,a0
    126e:	00092503          	lw	a0,0(s2)
    1272:	0c7010ef          	jal	ra,2b38 <semaphore_down>
    1276:	882a                	mv	a6,a0
    1278:	4881                	li	a7,0
    127a:	00002517          	auipc	a0,0x2
    127e:	95650513          	addi	a0,a0,-1706 # 2bd0 <enable_deadlock_detect+0x68>
    1282:	02100793          	li	a5,33
    1286:	8756                	mv	a4,s5
    1288:	86d2                	mv	a3,s4
    128a:	00002617          	auipc	a2,0x2
    128e:	93e60613          	addi	a2,a2,-1730 # 2bc8 <enable_deadlock_detect+0x60>
    1292:	45fd                	li	a1,31
    1294:	3d4000ef          	jal	ra,1668 <printf>
    1298:	557d                	li	a0,-1
    129a:	630010ef          	jal	ra,28ca <exit>
    129e:	b551                	j	1122 <deadlock_test+0x42>
	assert_eq(semaphore_down(alloc[id]), 0);
    12a0:	5fa010ef          	jal	ra,289a <getpid>
    12a4:	892a                	mv	s2,a0
    12a6:	00002517          	auipc	a0,0x2
    12aa:	8d250513          	addi	a0,a0,-1838 # 2b78 <enable_deadlock_detect+0x10>
    12ae:	4c2010ef          	jal	ra,2770 <basename>
    12b2:	8a2a                	mv	s4,a0
    12b4:	8526                	mv	a0,s1
    12b6:	083010ef          	jal	ra,2b38 <semaphore_down>
    12ba:	882a                	mv	a6,a0
    12bc:	4881                	li	a7,0
    12be:	00002517          	auipc	a0,0x2
    12c2:	91250513          	addi	a0,a0,-1774 # 2bd0 <enable_deadlock_detect+0x68>
    12c6:	02000793          	li	a5,32
    12ca:	8752                	mv	a4,s4
    12cc:	86ca                	mv	a3,s2
    12ce:	00002617          	auipc	a2,0x2
    12d2:	8fa60613          	addi	a2,a2,-1798 # 2bc8 <enable_deadlock_detect+0x60>
    12d6:	45fd                	li	a1,31
    12d8:	390000ef          	jal	ra,1668 <printf>
    12dc:	557d                	li	a0,-1
    12de:	5ec010ef          	jal	ra,28ca <exit>
    12e2:	b535                	j	110e <deadlock_test+0x2e>
    12e4:	8522                	mv	a0,s0
    12e6:	d1dff0ef          	jal	ra,1002 <try_sem_down.part.0>
    12ea:	b551                	j	116e <deadlock_test+0x8e>

00000000000012ec <try_sem_down>:
{
    12ec:	1141                	addi	sp,sp,-16
    12ee:	e022                	sd	s0,0(sp)
    12f0:	842a                	mv	s0,a0
	if (semaphore_down(sem_id) == -0xdead) {
    12f2:	852e                	mv	a0,a1
{
    12f4:	e406                	sd	ra,8(sp)
	if (semaphore_down(sem_id) == -0xdead) {
    12f6:	043010ef          	jal	ra,2b38 <semaphore_down>
    12fa:	77c9                	lui	a5,0xffff2
    12fc:	15378793          	addi	a5,a5,339 # ffffffffffff2153 <.got.plt+0xfffffffffffef1f3>
    1300:	00f50663          	beq	a0,a5,130c <try_sem_down+0x20>
}
    1304:	60a2                	ld	ra,8(sp)
    1306:	6402                	ld	s0,0(sp)
    1308:	0141                	addi	sp,sp,16
    130a:	8082                	ret
    130c:	8522                	mv	a0,s0
    130e:	6402                	ld	s0,0(sp)
    1310:	60a2                	ld	ra,8(sp)
    1312:	0141                	addi	sp,sp,16
    1314:	b1fd                	j	1002 <try_sem_down.part.0>

0000000000001316 <main>:

int main()
{
    1316:	7159                	addi	sp,sp,-112
	enable_deadlock_detect(1);
    1318:	4505                	li	a0,1
{
    131a:	f486                	sd	ra,104(sp)
    131c:	e4ce                	sd	s3,72(sp)
    131e:	f0a2                	sd	s0,96(sp)
    1320:	eca6                	sd	s1,88(sp)
    1322:	e8ca                	sd	s2,80(sp)
    1324:	e0d2                	sd	s4,64(sp)
    1326:	fc56                	sd	s5,56(sp)
    1328:	f85a                	sd	s6,48(sp)
    132a:	f45e                	sd	s7,40(sp)
    132c:	f062                	sd	s8,32(sp)
    132e:	ec66                	sd	s9,24(sp)
	enable_deadlock_detect(1);
    1330:	039010ef          	jal	ra,2b68 <enable_deadlock_detect>
	assert((semaphore_barrier_id = semaphore_create(THREAD_N)) == 0);
    1334:	4511                	li	a0,4
    1336:	7ea010ef          	jal	ra,2b20 <semaphore_create>
    133a:	00002997          	auipc	s3,0x2
    133e:	abe98993          	addi	s3,s3,-1346 # 2df8 <semaphore_barrier_id>
    1342:	00a9a023          	sw	a0,0(s3)
    1346:	14051a63          	bnez	a0,149a <main+0x184>
{
    134a:	4411                	li	s0,4
	for (int i = 0; i < THREAD_N; i++) {
    134c:	347d                	addiw	s0,s0,-1
		semaphore_down(semaphore_barrier_id);
    134e:	7ea010ef          	jal	ra,2b38 <semaphore_down>
	for (int i = 0; i < THREAD_N; i++) {
    1352:	c419                	beqz	s0,1360 <main+0x4a>
		semaphore_down(semaphore_barrier_id);
    1354:	0009a503          	lw	a0,0(s3)
	for (int i = 0; i < THREAD_N; i++) {
    1358:	347d                	addiw	s0,s0,-1
		semaphore_down(semaphore_barrier_id);
    135a:	7de010ef          	jal	ra,2b38 <semaphore_down>
	for (int i = 0; i < THREAD_N; i++) {
    135e:	f87d                	bnez	s0,1354 <main+0x3e>
    1360:	00002417          	auipc	s0,0x2
    1364:	bd040413          	addi	s0,s0,-1072 # 2f30 <res_num>
	}
	for (int i = 0; i < RES_TYPE; i++) {
    1368:	4901                	li	s2,0
    136a:	4b09                	li	s6,2
		assert_eq(semaphore_create(res_num[i]), i + 1);
    136c:	00002c97          	auipc	s9,0x2
    1370:	80cc8c93          	addi	s9,s9,-2036 # 2b78 <enable_deadlock_detect+0x10>
    1374:	00002c17          	auipc	s8,0x2
    1378:	854c0c13          	addi	s8,s8,-1964 # 2bc8 <enable_deadlock_detect+0x60>
    137c:	00002b97          	auipc	s7,0x2
    1380:	854b8b93          	addi	s7,s7,-1964 # 2bd0 <enable_deadlock_detect+0x68>
    1384:	00042a03          	lw	s4,0(s0)
    1388:	00190493          	addi	s1,s2,1
{
    138c:	4905                	li	s2,1
		assert_eq(semaphore_create(res_num[i]), i + 1);
    138e:	8552                	mv	a0,s4
    1390:	790010ef          	jal	ra,2b20 <semaphore_create>
    1394:	0e950f63          	beq	a0,s1,1492 <main+0x17c>
    1398:	502010ef          	jal	ra,289a <getpid>
    139c:	8aaa                	mv	s5,a0
    139e:	8566                	mv	a0,s9
    13a0:	3d0010ef          	jal	ra,2770 <basename>
    13a4:	872a                	mv	a4,a0
    13a6:	8552                	mv	a0,s4
    13a8:	8a3a                	mv	s4,a4
    13aa:	776010ef          	jal	ra,2b20 <semaphore_create>
    13ae:	882a                	mv	a6,a0
    13b0:	88a6                	mv	a7,s1
    13b2:	03400793          	li	a5,52
    13b6:	8752                	mv	a4,s4
    13b8:	86d6                	mv	a3,s5
    13ba:	8662                	mv	a2,s8
    13bc:	45fd                	li	a1,31
    13be:	855e                	mv	a0,s7
    13c0:	2a8000ef          	jal	ra,1668 <printf>
    13c4:	557d                	li	a0,-1
    13c6:	504010ef          	jal	ra,28ca <exit>
	for (int i = 0; i < RES_TYPE; i++) {
    13ca:	0411                	addi	s0,s0,4
    13cc:	fb649ce3          	bne	s1,s6,1384 <main+0x6e>
	}
	int threads[THREAD_N] = {};
    13d0:	848a                	mv	s1,sp
    13d2:	e002                	sd	zero,0(sp)
    13d4:	e402                	sd	zero,8(sp)
    13d6:	8926                	mv	s2,s1
    13d8:	4401                	li	s0,0
	for (int i = 0; i < THREAD_N; i++) {
		threads[i] = thread_create(deadlock_test, (void *)i);
    13da:	00000a97          	auipc	s5,0x0
    13de:	d06a8a93          	addi	s5,s5,-762 # 10e0 <deadlock_test>
		assert(threads[i] == i + 1);
    13e2:	00001c17          	auipc	s8,0x1
    13e6:	796c0c13          	addi	s8,s8,1942 # 2b78 <enable_deadlock_detect+0x10>
    13ea:	00001b97          	auipc	s7,0x1
    13ee:	7deb8b93          	addi	s7,s7,2014 # 2bc8 <enable_deadlock_detect+0x60>
    13f2:	00002b17          	auipc	s6,0x2
    13f6:	876b0b13          	addi	s6,s6,-1930 # 2c68 <enable_deadlock_detect+0x100>
	for (int i = 0; i < THREAD_N; i++) {
    13fa:	4a11                	li	s4,4
		threads[i] = thread_create(deadlock_test, (void *)i);
    13fc:	85a2                	mv	a1,s0
    13fe:	8556                	mv	a0,s5
    1400:	67c010ef          	jal	ra,2a7c <thread_create>
		assert(threads[i] == i + 1);
    1404:	0014079b          	addiw	a5,s0,1
		threads[i] = thread_create(deadlock_test, (void *)i);
    1408:	00a92023          	sw	a0,0(s2)
	for (int i = 0; i < THREAD_N; i++) {
    140c:	0405                	addi	s0,s0,1
		assert(threads[i] == i + 1);
    140e:	02a78463          	beq	a5,a0,1436 <main+0x120>
    1412:	488010ef          	jal	ra,289a <getpid>
    1416:	8caa                	mv	s9,a0
    1418:	8562                	mv	a0,s8
    141a:	356010ef          	jal	ra,2770 <basename>
    141e:	872a                	mv	a4,a0
    1420:	03900793          	li	a5,57
    1424:	855a                	mv	a0,s6
    1426:	86e6                	mv	a3,s9
    1428:	865e                	mv	a2,s7
    142a:	45fd                	li	a1,31
    142c:	23c000ef          	jal	ra,1668 <printf>
    1430:	557d                	li	a0,-1
    1432:	498010ef          	jal	ra,28ca <exit>
	for (int i = 0; i < THREAD_N; i++) {
    1436:	0911                	addi	s2,s2,4
    1438:	fd4412e3          	bne	s0,s4,13fc <main+0xe6>
	}
	sleep(500);
    143c:	1f400513          	li	a0,500
    1440:	4fc010ef          	jal	ra,293c <sleep>
    1444:	4411                	li	s0,4
	for (int i = 0; i < THREAD_N; i++) {
		semaphore_up(semaphore_barrier_id);
    1446:	0009a503          	lw	a0,0(s3)
	for (int i = 0; i < THREAD_N; i++) {
    144a:	347d                	addiw	s0,s0,-1
		semaphore_up(semaphore_barrier_id);
    144c:	6e0010ef          	jal	ra,2b2c <semaphore_up>
	for (int i = 0; i < THREAD_N; i++) {
    1450:	f87d                	bnez	s0,1446 <main+0x130>
    1452:	01048913          	addi	s2,s1,16
	}
	int fail = 0;
	for (int i = 0; i < THREAD_N; i++) {
		fail += waittid(threads[i]) != 0;
    1456:	4088                	lw	a0,0(s1)
	for (int i = 0; i < THREAD_N; i++) {
    1458:	0491                	addi	s1,s1,4
		fail += waittid(threads[i]) != 0;
    145a:	666010ef          	jal	ra,2ac0 <waittid>
    145e:	00a03533          	snez	a0,a0
    1462:	9c29                	addw	s0,s0,a0
	for (int i = 0; i < THREAD_N; i++) {
    1464:	ff2499e3          	bne	s1,s2,1456 <main+0x140>
	}
	assert(fail == 0);
    1468:	e43d                	bnez	s0,14d6 <main+0x1c0>
	puts("deadlock test semaphore 2 OK!");
    146a:	00002517          	auipc	a0,0x2
    146e:	87650513          	addi	a0,a0,-1930 # 2ce0 <enable_deadlock_detect+0x178>
    1472:	10d000ef          	jal	ra,1d7e <puts>
	return 0;
}
    1476:	70a6                	ld	ra,104(sp)
    1478:	7406                	ld	s0,96(sp)
    147a:	64e6                	ld	s1,88(sp)
    147c:	6946                	ld	s2,80(sp)
    147e:	69a6                	ld	s3,72(sp)
    1480:	6a06                	ld	s4,64(sp)
    1482:	7ae2                	ld	s5,56(sp)
    1484:	7b42                	ld	s6,48(sp)
    1486:	7ba2                	ld	s7,40(sp)
    1488:	7c02                	ld	s8,32(sp)
    148a:	6ce2                	ld	s9,24(sp)
    148c:	4501                	li	a0,0
    148e:	6165                	addi	sp,sp,112
    1490:	8082                	ret
	for (int i = 0; i < RES_TYPE; i++) {
    1492:	0411                	addi	s0,s0,4
    1494:	ef6518e3          	bne	a0,s6,1384 <main+0x6e>
    1498:	bf25                	j	13d0 <main+0xba>
	assert((semaphore_barrier_id = semaphore_create(THREAD_N)) == 0);
    149a:	400010ef          	jal	ra,289a <getpid>
    149e:	842a                	mv	s0,a0
    14a0:	00001517          	auipc	a0,0x1
    14a4:	6d850513          	addi	a0,a0,1752 # 2b78 <enable_deadlock_detect+0x10>
    14a8:	2c8010ef          	jal	ra,2770 <basename>
    14ac:	872a                	mv	a4,a0
    14ae:	02f00793          	li	a5,47
    14b2:	86a2                	mv	a3,s0
    14b4:	00001617          	auipc	a2,0x1
    14b8:	71460613          	addi	a2,a2,1812 # 2bc8 <enable_deadlock_detect+0x60>
    14bc:	45fd                	li	a1,31
    14be:	00001517          	auipc	a0,0x1
    14c2:	74a50513          	addi	a0,a0,1866 # 2c08 <enable_deadlock_detect+0xa0>
    14c6:	1a2000ef          	jal	ra,1668 <printf>
    14ca:	557d                	li	a0,-1
    14cc:	3fe010ef          	jal	ra,28ca <exit>
		semaphore_down(semaphore_barrier_id);
    14d0:	0009a503          	lw	a0,0(s3)
    14d4:	bd9d                	j	134a <main+0x34>
	assert(fail == 0);
    14d6:	3c4010ef          	jal	ra,289a <getpid>
    14da:	842a                	mv	s0,a0
    14dc:	00001517          	auipc	a0,0x1
    14e0:	69c50513          	addi	a0,a0,1692 # 2b78 <enable_deadlock_detect+0x10>
    14e4:	28c010ef          	jal	ra,2770 <basename>
    14e8:	872a                	mv	a4,a0
    14ea:	04300793          	li	a5,67
    14ee:	00001517          	auipc	a0,0x1
    14f2:	7ba50513          	addi	a0,a0,1978 # 2ca8 <enable_deadlock_detect+0x140>
    14f6:	86a2                	mv	a3,s0
    14f8:	00001617          	auipc	a2,0x1
    14fc:	6d060613          	addi	a2,a2,1744 # 2bc8 <enable_deadlock_detect+0x60>
    1500:	45fd                	li	a1,31
    1502:	166000ef          	jal	ra,1668 <printf>
    1506:	557d                	li	a0,-1
    1508:	3c2010ef          	jal	ra,28ca <exit>
    150c:	bfb9                	j	146a <main+0x154>

000000000000150e <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    150e:	1141                	addi	sp,sp,-16
    1510:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1512:	e05ff0ef          	jal	ra,1316 <main>
    1516:	3b4010ef          	jal	ra,28ca <exit>
	return 0;
    151a:	60a2                	ld	ra,8(sp)
    151c:	4501                	li	a0,0
    151e:	0141                	addi	sp,sp,16
    1520:	8082                	ret

0000000000001522 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1522:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1524:	4605                	li	a2,1
    1526:	00f10593          	addi	a1,sp,15
    152a:	4501                	li	a0,0
{
    152c:	ec06                	sd	ra,24(sp)
	char byte = 0;
    152e:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1532:	354010ef          	jal	ra,2886 <read>
    1536:	4785                	li	a5,1
    1538:	00f51763          	bne	a0,a5,1546 <getchar+0x24>
		return byte;
    153c:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1540:	60e2                	ld	ra,24(sp)
    1542:	6105                	addi	sp,sp,32
    1544:	8082                	ret
		return EOF;
    1546:	557d                	li	a0,-1
    1548:	bfe5                	j	1540 <getchar+0x1e>

000000000000154a <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    154a:	00002517          	auipc	a0,0x2
    154e:	8b652503          	lw	a0,-1866(a0) # 2e00 <buffer_len>
    1552:	e111                	bnez	a0,1556 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1554:	8082                	ret
{
    1556:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1558:	862a                	mv	a2,a0
    155a:	00002597          	auipc	a1,0x2
    155e:	8ae58593          	addi	a1,a1,-1874 # 2e08 <buffer>
    1562:	4505                	li	a0,1
{
    1564:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1566:	32a010ef          	jal	ra,2890 <write>
}
    156a:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    156c:	2501                	sext.w	a0,a0
}
    156e:	0141                	addi	sp,sp,16
    1570:	8082                	ret

0000000000001572 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1572:	00002797          	auipc	a5,0x2
    1576:	8807a723          	sw	zero,-1906(a5) # 2e00 <buffer_len>
}
    157a:	8082                	ret

000000000000157c <__fflush>:
	if (buffer_len == 0)
    157c:	00002517          	auipc	a0,0x2
    1580:	88452503          	lw	a0,-1916(a0) # 2e00 <buffer_len>
    1584:	e511                	bnez	a0,1590 <__fflush+0x14>
	buffer_len = 0;
    1586:	00002797          	auipc	a5,0x2
    158a:	8607ad23          	sw	zero,-1926(a5) # 2e00 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    158e:	8082                	ret
{
    1590:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1592:	862a                	mv	a2,a0
    1594:	00002597          	auipc	a1,0x2
    1598:	87458593          	addi	a1,a1,-1932 # 2e08 <buffer>
    159c:	4505                	li	a0,1
{
    159e:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    15a0:	2f0010ef          	jal	ra,2890 <write>
	return r >= 0 ? 0 : r;
    15a4:	0005079b          	sext.w	a5,a0
}
    15a8:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    15aa:	0017a793          	slti	a5,a5,1
    15ae:	40f007bb          	negw	a5,a5
    15b2:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    15b4:	00002797          	auipc	a5,0x2
    15b8:	8407a623          	sw	zero,-1972(a5) # 2e00 <buffer_len>
	return r >= 0 ? 0 : r;
    15bc:	2501                	sext.w	a0,a0
}
    15be:	0141                	addi	sp,sp,16
    15c0:	8082                	ret

00000000000015c2 <fflush>:

int fflush(int fd)
{
    15c2:	1101                	addi	sp,sp,-32
    15c4:	e822                	sd	s0,16(sp)
    15c6:	ec06                	sd	ra,24(sp)
    15c8:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    15ca:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    15cc:	4401                	li	s0,0
	if (fd == 1) {
    15ce:	00e50863          	beq	a0,a4,15de <fflush+0x1c>
}
    15d2:	60e2                	ld	ra,24(sp)
    15d4:	8522                	mv	a0,s0
    15d6:	6442                	ld	s0,16(sp)
    15d8:	64a2                	ld	s1,8(sp)
    15da:	6105                	addi	sp,sp,32
    15dc:	8082                	ret
		if (buffer_lock_enabled == 1) {
    15de:	00002497          	auipc	s1,0x2
    15e2:	82248493          	addi	s1,s1,-2014 # 2e00 <buffer_len>
    15e6:	1084a703          	lw	a4,264(s1)
    15ea:	02a70e63          	beq	a4,a0,1626 <fflush+0x64>
	if (buffer_len == 0)
    15ee:	4080                	lw	s0,0(s1)
    15f0:	c00d                	beqz	s0,1612 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    15f2:	8622                	mv	a2,s0
    15f4:	00002597          	auipc	a1,0x2
    15f8:	81458593          	addi	a1,a1,-2028 # 2e08 <buffer>
    15fc:	294010ef          	jal	ra,2890 <write>
	return r >= 0 ? 0 : r;
    1600:	0005079b          	sext.w	a5,a0
    1604:	0017a793          	slti	a5,a5,1
    1608:	40f007bb          	negw	a5,a5
    160c:	8d7d                	and	a0,a0,a5
    160e:	0005041b          	sext.w	s0,a0
}
    1612:	60e2                	ld	ra,24(sp)
    1614:	8522                	mv	a0,s0
    1616:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1618:	00001797          	auipc	a5,0x1
    161c:	7e07a423          	sw	zero,2024(a5) # 2e00 <buffer_len>
}
    1620:	64a2                	ld	s1,8(sp)
    1622:	6105                	addi	sp,sp,32
    1624:	8082                	ret
			mutex_lock(buffer_lock);
    1626:	10c4a503          	lw	a0,268(s1)
    162a:	4de010ef          	jal	ra,2b08 <mutex_lock>
	if (buffer_len == 0)
    162e:	4080                	lw	s0,0(s1)
    1630:	e811                	bnez	s0,1644 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1632:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1636:	00001797          	auipc	a5,0x1
    163a:	7c07a523          	sw	zero,1994(a5) # 2e00 <buffer_len>
			mutex_unlock(buffer_lock);
    163e:	4d6010ef          	jal	ra,2b14 <mutex_unlock>
    1642:	bf41                	j	15d2 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1644:	8622                	mv	a2,s0
    1646:	00001597          	auipc	a1,0x1
    164a:	7c258593          	addi	a1,a1,1986 # 2e08 <buffer>
    164e:	4505                	li	a0,1
    1650:	240010ef          	jal	ra,2890 <write>
	return r >= 0 ? 0 : r;
    1654:	0005079b          	sext.w	a5,a0
    1658:	0017a793          	slti	a5,a5,1
    165c:	40f007bb          	negw	a5,a5
    1660:	8d7d                	and	a0,a0,a5
    1662:	0005041b          	sext.w	s0,a0
	return r;
    1666:	b7f1                	j	1632 <fflush+0x70>

0000000000001668 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1668:	7131                	addi	sp,sp,-192
    166a:	e0da                	sd	s6,64(sp)
    166c:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    166e:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1670:	013c                	addi	a5,sp,136
{
    1672:	f0ca                	sd	s2,96(sp)
    1674:	ecce                	sd	s3,88(sp)
    1676:	e8d2                	sd	s4,80(sp)
    1678:	e4d6                	sd	s5,72(sp)
    167a:	fc86                	sd	ra,120(sp)
    167c:	f8a2                	sd	s0,112(sp)
    167e:	f4a6                	sd	s1,104(sp)
    1680:	89aa                	mv	s3,a0
    1682:	e52e                	sd	a1,136(sp)
    1684:	e932                	sd	a2,144(sp)
    1686:	ed36                	sd	a3,152(sp)
    1688:	f13a                	sd	a4,160(sp)
    168a:	f942                	sd	a6,176(sp)
    168c:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    168e:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1690:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1694:	00001a17          	auipc	s4,0x1
    1698:	76ca0a13          	addi	s4,s4,1900 # 2e00 <buffer_len>
    169c:	4a85                	li	s5,1
	buf[i++] = '0';
    169e:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    16a2:	0009c783          	lbu	a5,0(s3)
    16a6:	18078663          	beqz	a5,1832 <printf+0x1ca>
    16aa:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    16ac:	19278d63          	beq	a5,s2,1846 <printf+0x1de>
    16b0:	0015c783          	lbu	a5,1(a1)
    16b4:	0585                	addi	a1,a1,1
    16b6:	fbfd                	bnez	a5,16ac <printf+0x44>
    16b8:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    16ba:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    16be:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    16c2:	1b578863          	beq	a5,s5,1872 <printf+0x20a>
		len = out_unlocked(s, l);
    16c6:	85a2                	mv	a1,s0
    16c8:	854e                	mv	a0,s3
    16ca:	42a000ef          	jal	ra,1af4 <out_unlocked>
		out(f, a, l);
		if (l)
    16ce:	1c041063          	bnez	s0,188e <printf+0x226>
			continue;
		if (s[1] == 0)
    16d2:	0014c783          	lbu	a5,1(s1)
    16d6:	14078e63          	beqz	a5,1832 <printf+0x1ca>
			break;
		switch (s[1]) {
    16da:	07300713          	li	a4,115
    16de:	1ce78863          	beq	a5,a4,18ae <printf+0x246>
    16e2:	1af76863          	bltu	a4,a5,1892 <printf+0x22a>
    16e6:	06400713          	li	a4,100
    16ea:	22e78063          	beq	a5,a4,190a <printf+0x2a2>
    16ee:	07000713          	li	a4,112
    16f2:	1ee79563          	bne	a5,a4,18dc <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    16f6:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16f8:	00002797          	auipc	a5,0x2
    16fc:	84078793          	addi	a5,a5,-1984 # 2f38 <digits>
	buf[i++] = '0';
    1700:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1704:	6298                	ld	a4,0(a3)
    1706:	06a1                	addi	a3,a3,8
    1708:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    170a:	00471393          	slli	t2,a4,0x4
    170e:	00871293          	slli	t0,a4,0x8
    1712:	00c71f93          	slli	t6,a4,0xc
    1716:	01071f13          	slli	t5,a4,0x10
    171a:	01471e93          	slli	t4,a4,0x14
    171e:	01871e13          	slli	t3,a4,0x18
    1722:	01c71893          	slli	a7,a4,0x1c
    1726:	02471813          	slli	a6,a4,0x24
    172a:	02871513          	slli	a0,a4,0x28
    172e:	02c71593          	slli	a1,a4,0x2c
    1732:	03071613          	slli	a2,a4,0x30
    1736:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    173a:	03c75413          	srli	s0,a4,0x3c
    173e:	01c7531b          	srliw	t1,a4,0x1c
    1742:	03c3d393          	srli	t2,t2,0x3c
    1746:	03c2d293          	srli	t0,t0,0x3c
    174a:	03cfdf93          	srli	t6,t6,0x3c
    174e:	03cf5f13          	srli	t5,t5,0x3c
    1752:	03cede93          	srli	t4,t4,0x3c
    1756:	03ce5e13          	srli	t3,t3,0x3c
    175a:	03c8d893          	srli	a7,a7,0x3c
    175e:	03c85813          	srli	a6,a6,0x3c
    1762:	9171                	srli	a0,a0,0x3c
    1764:	91f1                	srli	a1,a1,0x3c
    1766:	9271                	srli	a2,a2,0x3c
    1768:	92f1                	srli	a3,a3,0x3c
    176a:	95be                	add	a1,a1,a5
    176c:	963e                	add	a2,a2,a5
    176e:	96be                	add	a3,a3,a5
    1770:	943e                	add	s0,s0,a5
    1772:	93be                	add	t2,t2,a5
    1774:	92be                	add	t0,t0,a5
    1776:	9fbe                	add	t6,t6,a5
    1778:	9f3e                	add	t5,t5,a5
    177a:	9ebe                	add	t4,t4,a5
    177c:	9e3e                	add	t3,t3,a5
    177e:	98be                	add	a7,a7,a5
    1780:	933e                	add	t1,t1,a5
    1782:	983e                	add	a6,a6,a5
    1784:	953e                	add	a0,a0,a5
    1786:	0005c983          	lbu	s3,0(a1)
    178a:	00044403          	lbu	s0,0(s0)
    178e:	00064583          	lbu	a1,0(a2)
    1792:	0003c383          	lbu	t2,0(t2)
    1796:	0006c603          	lbu	a2,0(a3)
    179a:	0002c283          	lbu	t0,0(t0)
    179e:	000fcf83          	lbu	t6,0(t6)
    17a2:	000f4f03          	lbu	t5,0(t5)
    17a6:	000ece83          	lbu	t4,0(t4)
    17aa:	000e4e03          	lbu	t3,0(t3)
    17ae:	0008c883          	lbu	a7,0(a7)
    17b2:	00034303          	lbu	t1,0(t1)
    17b6:	00084803          	lbu	a6,0(a6)
    17ba:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    17be:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    17c2:	92f1                	srli	a3,a3,0x3c
    17c4:	8b3d                	andi	a4,a4,15
    17c6:	96be                	add	a3,a3,a5
    17c8:	97ba                	add	a5,a5,a4
    17ca:	00810d23          	sb	s0,26(sp)
    17ce:	00710da3          	sb	t2,27(sp)
    17d2:	00510e23          	sb	t0,28(sp)
    17d6:	01f10ea3          	sb	t6,29(sp)
    17da:	01e10f23          	sb	t5,30(sp)
    17de:	01d10fa3          	sb	t4,31(sp)
    17e2:	03c10023          	sb	t3,32(sp)
    17e6:	031100a3          	sb	a7,33(sp)
    17ea:	02610123          	sb	t1,34(sp)
    17ee:	030101a3          	sb	a6,35(sp)
    17f2:	02a10223          	sb	a0,36(sp)
    17f6:	033102a3          	sb	s3,37(sp)
    17fa:	02b10323          	sb	a1,38(sp)
    17fe:	02c103a3          	sb	a2,39(sp)
    1802:	0006c683          	lbu	a3,0(a3)
    1806:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    180a:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    180e:	02d10423          	sb	a3,40(sp)
    1812:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1816:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    181a:	11578263          	beq	a5,s5,191e <printf+0x2b6>
		len = out_unlocked(s, l);
    181e:	45c9                	li	a1,18
    1820:	0828                	addi	a0,sp,24
    1822:	2d2000ef          	jal	ra,1af4 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1826:	00248993          	addi	s3,s1,2
		if (!*s)
    182a:	0009c783          	lbu	a5,0(s3)
    182e:	e6079ee3          	bnez	a5,16aa <printf+0x42>
	}
	va_end(ap);
    1832:	70e6                	ld	ra,120(sp)
    1834:	7446                	ld	s0,112(sp)
    1836:	74a6                	ld	s1,104(sp)
    1838:	7906                	ld	s2,96(sp)
    183a:	69e6                	ld	s3,88(sp)
    183c:	6a46                	ld	s4,80(sp)
    183e:	6aa6                	ld	s5,72(sp)
    1840:	6b06                	ld	s6,64(sp)
    1842:	6129                	addi	sp,sp,192
    1844:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1846:	0005c783          	lbu	a5,0(a1)
    184a:	84ae                	mv	s1,a1
    184c:	01278963          	beq	a5,s2,185e <printf+0x1f6>
    1850:	b5ad                	j	16ba <printf+0x52>
    1852:	0024c783          	lbu	a5,2(s1)
    1856:	0585                	addi	a1,a1,1
    1858:	0489                	addi	s1,s1,2
    185a:	e72790e3          	bne	a5,s2,16ba <printf+0x52>
    185e:	0014c783          	lbu	a5,1(s1)
    1862:	ff2788e3          	beq	a5,s2,1852 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1866:	108a2783          	lw	a5,264(s4)
		l = z - a;
    186a:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    186e:	e5579ce3          	bne	a5,s5,16c6 <printf+0x5e>
		mutex_lock(buffer_lock);
    1872:	10ca2503          	lw	a0,268(s4)
    1876:	292010ef          	jal	ra,2b08 <mutex_lock>
		len = out_unlocked(s, l);
    187a:	85a2                	mv	a1,s0
    187c:	854e                	mv	a0,s3
    187e:	276000ef          	jal	ra,1af4 <out_unlocked>
		mutex_unlock(buffer_lock);
    1882:	10ca2503          	lw	a0,268(s4)
    1886:	28e010ef          	jal	ra,2b14 <mutex_unlock>
		if (l)
    188a:	e40404e3          	beqz	s0,16d2 <printf+0x6a>
    188e:	89a6                	mv	s3,s1
    1890:	bd09                	j	16a2 <printf+0x3a>
		switch (s[1]) {
    1892:	07800713          	li	a4,120
    1896:	04e79363          	bne	a5,a4,18dc <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    189a:	67c2                	ld	a5,16(sp)
    189c:	45c1                	li	a1,16
		s += 2;
    189e:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    18a2:	4388                	lw	a0,0(a5)
    18a4:	07a1                	addi	a5,a5,8
    18a6:	e83e                	sd	a5,16(sp)
    18a8:	5f8000ef          	jal	ra,1ea0 <printint.constprop.0>
		s += 2;
    18ac:	bfbd                	j	182a <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    18ae:	67c2                	ld	a5,16(sp)
    18b0:	6380                	ld	s0,0(a5)
    18b2:	07a1                	addi	a5,a5,8
    18b4:	e83e                	sd	a5,16(sp)
    18b6:	1c040163          	beqz	s0,1a78 <printf+0x410>
			l = strnlen(a, 200);
    18ba:	0c800593          	li	a1,200
    18be:	8522                	mv	a0,s0
    18c0:	3f7000ef          	jal	ra,24b6 <strnlen>
	if (buffer_lock_enabled == 1) {
    18c4:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    18c8:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    18cc:	19578663          	beq	a5,s5,1a58 <printf+0x3f0>
		len = out_unlocked(s, l);
    18d0:	8522                	mv	a0,s0
    18d2:	222000ef          	jal	ra,1af4 <out_unlocked>
		s += 2;
    18d6:	00248993          	addi	s3,s1,2
    18da:	bf81                	j	182a <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    18dc:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18e0:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    18e4:	0f578663          	beq	a5,s5,19d0 <printf+0x368>
		len = out_unlocked(s, l);
    18e8:	0828                	addi	a0,sp,24
    18ea:	316000ef          	jal	ra,1c00 <out_unlocked.constprop.0>
			putchar(s[1]);
    18ee:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    18f2:	108a2783          	lw	a5,264(s4)
	char byte = c;
    18f6:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    18fa:	05578163          	beq	a5,s5,193c <printf+0x2d4>
		len = out_unlocked(s, l);
    18fe:	0828                	addi	a0,sp,24
    1900:	300000ef          	jal	ra,1c00 <out_unlocked.constprop.0>
		s += 2;
    1904:	00248993          	addi	s3,s1,2
    1908:	b70d                	j	182a <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    190a:	67c2                	ld	a5,16(sp)
    190c:	45a9                	li	a1,10
		s += 2;
    190e:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1912:	4388                	lw	a0,0(a5)
    1914:	07a1                	addi	a5,a5,8
    1916:	e83e                	sd	a5,16(sp)
    1918:	588000ef          	jal	ra,1ea0 <printint.constprop.0>
		s += 2;
    191c:	b739                	j	182a <printf+0x1c2>
		mutex_lock(buffer_lock);
    191e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1922:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1926:	1e2010ef          	jal	ra,2b08 <mutex_lock>
		len = out_unlocked(s, l);
    192a:	45c9                	li	a1,18
    192c:	0828                	addi	a0,sp,24
    192e:	1c6000ef          	jal	ra,1af4 <out_unlocked>
		mutex_unlock(buffer_lock);
    1932:	10ca2503          	lw	a0,268(s4)
    1936:	1de010ef          	jal	ra,2b14 <mutex_unlock>
		s += 2;
    193a:	bdc5                	j	182a <printf+0x1c2>
		mutex_lock(buffer_lock);
    193c:	10ca2503          	lw	a0,268(s4)
    1940:	1c8010ef          	jal	ra,2b08 <mutex_lock>
		buffer[buffer_len++] = c;
    1944:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1948:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    194c:	0017861b          	addiw	a2,a5,1
    1950:	97d2                	add	a5,a5,s4
    1952:	00ca2023          	sw	a2,0(s4)
    1956:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    195a:	00c6cc63          	blt	a3,a2,1972 <printf+0x30a>
    195e:	47a9                	li	a5,10
    1960:	06f40663          	beq	s0,a5,19cc <printf+0x364>
		mutex_unlock(buffer_lock);
    1964:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1968:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    196c:	1a8010ef          	jal	ra,2b14 <mutex_unlock>
		s += 2;
    1970:	bd6d                	j	182a <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1972:	10000793          	li	a5,256
    1976:	00f61e63          	bne	a2,a5,1992 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    197a:	00001597          	auipc	a1,0x1
    197e:	48e58593          	addi	a1,a1,1166 # 2e08 <buffer>
    1982:	4505                	li	a0,1
    1984:	70d000ef          	jal	ra,2890 <write>
	buffer_len = 0;
    1988:	00001797          	auipc	a5,0x1
    198c:	4607ac23          	sw	zero,1144(a5) # 2e00 <buffer_len>
			if (r < 0) {
    1990:	bfd1                	j	1964 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1992:	709000ef          	jal	ra,289a <getpid>
    1996:	842a                	mv	s0,a0
    1998:	00001517          	auipc	a0,0x1
    199c:	37050513          	addi	a0,a0,880 # 2d08 <enable_deadlock_detect+0x1a0>
    19a0:	5d1000ef          	jal	ra,2770 <basename>
    19a4:	872a                	mv	a4,a0
    19a6:	00001617          	auipc	a2,0x1
    19aa:	22260613          	addi	a2,a2,546 # 2bc8 <enable_deadlock_detect+0x60>
    19ae:	05400793          	li	a5,84
    19b2:	86a2                	mv	a3,s0
    19b4:	45fd                	li	a1,31
    19b6:	00001517          	auipc	a0,0x1
    19ba:	39250513          	addi	a0,a0,914 # 2d48 <enable_deadlock_detect+0x1e0>
    19be:	cabff0ef          	jal	ra,1668 <printf>
    19c2:	557d                	li	a0,-1
    19c4:	707000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    19c8:	000a2603          	lw	a2,0(s4)
    19cc:	de41                	beqz	a2,1964 <printf+0x2fc>
    19ce:	b775                	j	197a <printf+0x312>
		mutex_lock(buffer_lock);
    19d0:	10ca2503          	lw	a0,268(s4)
    19d4:	134010ef          	jal	ra,2b08 <mutex_lock>
		buffer[buffer_len++] = c;
    19d8:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19dc:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19e0:	0017861b          	addiw	a2,a5,1
    19e4:	97d2                	add	a5,a5,s4
    19e6:	00ca2023          	sw	a2,0(s4)
    19ea:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19ee:	02c6d163          	bge	a3,a2,1a10 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    19f2:	10000793          	li	a5,256
    19f6:	02f61263          	bne	a2,a5,1a1a <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    19fa:	00001597          	auipc	a1,0x1
    19fe:	40e58593          	addi	a1,a1,1038 # 2e08 <buffer>
    1a02:	4505                	li	a0,1
    1a04:	68d000ef          	jal	ra,2890 <write>
	buffer_len = 0;
    1a08:	00001797          	auipc	a5,0x1
    1a0c:	3e07ac23          	sw	zero,1016(a5) # 2e00 <buffer_len>
		mutex_unlock(buffer_lock);
    1a10:	10ca2503          	lw	a0,268(s4)
    1a14:	100010ef          	jal	ra,2b14 <mutex_unlock>
    1a18:	bdd9                	j	18ee <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1a1a:	681000ef          	jal	ra,289a <getpid>
    1a1e:	842a                	mv	s0,a0
    1a20:	00001517          	auipc	a0,0x1
    1a24:	2e850513          	addi	a0,a0,744 # 2d08 <enable_deadlock_detect+0x1a0>
    1a28:	549000ef          	jal	ra,2770 <basename>
    1a2c:	872a                	mv	a4,a0
    1a2e:	00001617          	auipc	a2,0x1
    1a32:	19a60613          	addi	a2,a2,410 # 2bc8 <enable_deadlock_detect+0x60>
    1a36:	05400793          	li	a5,84
    1a3a:	86a2                	mv	a3,s0
    1a3c:	45fd                	li	a1,31
    1a3e:	00001517          	auipc	a0,0x1
    1a42:	30a50513          	addi	a0,a0,778 # 2d48 <enable_deadlock_detect+0x1e0>
    1a46:	c23ff0ef          	jal	ra,1668 <printf>
    1a4a:	557d                	li	a0,-1
    1a4c:	67f000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    1a50:	000a2603          	lw	a2,0(s4)
    1a54:	de55                	beqz	a2,1a10 <printf+0x3a8>
    1a56:	b755                	j	19fa <printf+0x392>
		mutex_lock(buffer_lock);
    1a58:	10ca2503          	lw	a0,268(s4)
    1a5c:	e42e                	sd	a1,8(sp)
		s += 2;
    1a5e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1a62:	0a6010ef          	jal	ra,2b08 <mutex_lock>
		len = out_unlocked(s, l);
    1a66:	65a2                	ld	a1,8(sp)
    1a68:	8522                	mv	a0,s0
    1a6a:	08a000ef          	jal	ra,1af4 <out_unlocked>
		mutex_unlock(buffer_lock);
    1a6e:	10ca2503          	lw	a0,268(s4)
    1a72:	0a2010ef          	jal	ra,2b14 <mutex_unlock>
		s += 2;
    1a76:	bb55                	j	182a <printf+0x1c2>
				a = "(null)";
    1a78:	00001417          	auipc	s0,0x1
    1a7c:	28840413          	addi	s0,s0,648 # 2d00 <enable_deadlock_detect+0x198>
    1a80:	bd2d                	j	18ba <printf+0x252>

0000000000001a82 <enable_thread_io_buffer>:
{
    1a82:	1101                	addi	sp,sp,-32
    1a84:	e822                	sd	s0,16(sp)
    1a86:	ec06                	sd	ra,24(sp)
    1a88:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1a8a:	00001417          	auipc	s0,0x1
    1a8e:	37640413          	addi	s0,s0,886 # 2e00 <buffer_len>
    1a92:	05a010ef          	jal	ra,2aec <mutex_create>
    1a96:	10a42623          	sw	a0,268(s0)
    1a9a:	00054a63          	bltz	a0,1aae <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1a9e:	4785                	li	a5,1
}
    1aa0:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1aa2:	10f42423          	sw	a5,264(s0)
}
    1aa6:	6442                	ld	s0,16(sp)
    1aa8:	64a2                	ld	s1,8(sp)
    1aaa:	6105                	addi	sp,sp,32
    1aac:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1aae:	5ed000ef          	jal	ra,289a <getpid>
    1ab2:	84aa                	mv	s1,a0
    1ab4:	00001517          	auipc	a0,0x1
    1ab8:	25450513          	addi	a0,a0,596 # 2d08 <enable_deadlock_detect+0x1a0>
    1abc:	4b5000ef          	jal	ra,2770 <basename>
    1ac0:	872a                	mv	a4,a0
    1ac2:	04800793          	li	a5,72
    1ac6:	86a6                	mv	a3,s1
    1ac8:	00001517          	auipc	a0,0x1
    1acc:	2c050513          	addi	a0,a0,704 # 2d88 <enable_deadlock_detect+0x220>
    1ad0:	00001617          	auipc	a2,0x1
    1ad4:	0f860613          	addi	a2,a2,248 # 2bc8 <enable_deadlock_detect+0x60>
    1ad8:	45fd                	li	a1,31
    1ada:	b8fff0ef          	jal	ra,1668 <printf>
    1ade:	557d                	li	a0,-1
    1ae0:	5eb000ef          	jal	ra,28ca <exit>
	buffer_lock_enabled = 1;
    1ae4:	4785                	li	a5,1
}
    1ae6:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1ae8:	10f42423          	sw	a5,264(s0)
}
    1aec:	6442                	ld	s0,16(sp)
    1aee:	64a2                	ld	s1,8(sp)
    1af0:	6105                	addi	sp,sp,32
    1af2:	8082                	ret

0000000000001af4 <out_unlocked>:
{
    1af4:	7159                	addi	sp,sp,-112
    1af6:	f486                	sd	ra,104(sp)
    1af8:	f0a2                	sd	s0,96(sp)
    1afa:	eca6                	sd	s1,88(sp)
    1afc:	e8ca                	sd	s2,80(sp)
    1afe:	e4ce                	sd	s3,72(sp)
    1b00:	e0d2                	sd	s4,64(sp)
    1b02:	fc56                	sd	s5,56(sp)
    1b04:	f85a                	sd	s6,48(sp)
    1b06:	f45e                	sd	s7,40(sp)
    1b08:	f062                	sd	s8,32(sp)
    1b0a:	ec66                	sd	s9,24(sp)
    1b0c:	e86a                	sd	s10,16(sp)
    1b0e:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1b10:	0e058663          	beqz	a1,1bfc <out_unlocked+0x108>
    1b14:	842a                	mv	s0,a0
    1b16:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1b1a:	4981                	li	s3,0
    1b1c:	00001d17          	auipc	s10,0x1
    1b20:	2e4d0d13          	addi	s10,s10,740 # 2e00 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b24:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1b28:	00001b17          	auipc	s6,0x1
    1b2c:	2e0b0b13          	addi	s6,s6,736 # 2e08 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1b30:	10000a93          	li	s5,256
    1b34:	00001c97          	auipc	s9,0x1
    1b38:	1d4c8c93          	addi	s9,s9,468 # 2d08 <enable_deadlock_detect+0x1a0>
    1b3c:	00001c17          	auipc	s8,0x1
    1b40:	08cc0c13          	addi	s8,s8,140 # 2bc8 <enable_deadlock_detect+0x60>
    1b44:	00001b97          	auipc	s7,0x1
    1b48:	204b8b93          	addi	s7,s7,516 # 2d48 <enable_deadlock_detect+0x1e0>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b4c:	4a29                	li	s4,10
    1b4e:	a031                	j	1b5a <out_unlocked+0x66>
    1b50:	09468863          	beq	a3,s4,1be0 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1b54:	0405                	addi	s0,s0,1
    1b56:	04848163          	beq	s1,s0,1b98 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1b5a:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1b5e:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1b62:	0017861b          	addiw	a2,a5,1
    1b66:	97ea                	add	a5,a5,s10
    1b68:	00cd2023          	sw	a2,0(s10)
    1b6c:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b70:	fec950e3          	bge	s2,a2,1b50 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1b74:	05561263          	bne	a2,s5,1bb8 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1b78:	85da                	mv	a1,s6
    1b7a:	4505                	li	a0,1
    1b7c:	515000ef          	jal	ra,2890 <write>
    1b80:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b82:	00001797          	auipc	a5,0x1
    1b86:	2607af23          	sw	zero,638(a5) # 2e00 <buffer_len>
			if (r < 0) {
    1b8a:	06054763          	bltz	a0,1bf8 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1b8e:	0405                	addi	s0,s0,1
			ret += r;
    1b90:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1b94:	fc8493e3          	bne	s1,s0,1b5a <out_unlocked+0x66>
}
    1b98:	70a6                	ld	ra,104(sp)
    1b9a:	7406                	ld	s0,96(sp)
    1b9c:	64e6                	ld	s1,88(sp)
    1b9e:	6946                	ld	s2,80(sp)
    1ba0:	6a06                	ld	s4,64(sp)
    1ba2:	7ae2                	ld	s5,56(sp)
    1ba4:	7b42                	ld	s6,48(sp)
    1ba6:	7ba2                	ld	s7,40(sp)
    1ba8:	7c02                	ld	s8,32(sp)
    1baa:	6ce2                	ld	s9,24(sp)
    1bac:	6d42                	ld	s10,16(sp)
    1bae:	6da2                	ld	s11,8(sp)
    1bb0:	854e                	mv	a0,s3
    1bb2:	69a6                	ld	s3,72(sp)
    1bb4:	6165                	addi	sp,sp,112
    1bb6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bb8:	4e3000ef          	jal	ra,289a <getpid>
    1bbc:	8daa                	mv	s11,a0
    1bbe:	8566                	mv	a0,s9
    1bc0:	3b1000ef          	jal	ra,2770 <basename>
    1bc4:	872a                	mv	a4,a0
    1bc6:	8662                	mv	a2,s8
    1bc8:	05400793          	li	a5,84
    1bcc:	86ee                	mv	a3,s11
    1bce:	45fd                	li	a1,31
    1bd0:	855e                	mv	a0,s7
    1bd2:	a97ff0ef          	jal	ra,1668 <printf>
    1bd6:	557d                	li	a0,-1
    1bd8:	4f3000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    1bdc:	000d2603          	lw	a2,0(s10)
    1be0:	da35                	beqz	a2,1b54 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1be2:	85da                	mv	a1,s6
    1be4:	4505                	li	a0,1
    1be6:	4ab000ef          	jal	ra,2890 <write>
    1bea:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1bec:	00001797          	auipc	a5,0x1
    1bf0:	2007aa23          	sw	zero,532(a5) # 2e00 <buffer_len>
			if (r < 0) {
    1bf4:	f8055de3          	bgez	a0,1b8e <out_unlocked+0x9a>
    1bf8:	89aa                	mv	s3,a0
    1bfa:	bf79                	j	1b98 <out_unlocked+0xa4>
	int ret = 0;
    1bfc:	4981                	li	s3,0
    1bfe:	bf69                	j	1b98 <out_unlocked+0xa4>

0000000000001c00 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1c00:	1101                	addi	sp,sp,-32
    1c02:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1c04:	00001497          	auipc	s1,0x1
    1c08:	1fc48493          	addi	s1,s1,508 # 2e00 <buffer_len>
    1c0c:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1c0e:	ec06                	sd	ra,24(sp)
    1c10:	e822                	sd	s0,16(sp)
		char c = s[i];
    1c12:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1c16:	0017861b          	addiw	a2,a5,1
    1c1a:	97a6                	add	a5,a5,s1
    1c1c:	00e78423          	sb	a4,8(a5)
    1c20:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c22:	0ff00793          	li	a5,255
    1c26:	00c7cc63          	blt	a5,a2,1c3e <out_unlocked.constprop.0+0x3e>
    1c2a:	47a9                	li	a5,10
    1c2c:	06f70c63          	beq	a4,a5,1ca4 <out_unlocked.constprop.0+0xa4>
    1c30:	4601                	li	a2,0
}
    1c32:	60e2                	ld	ra,24(sp)
    1c34:	6442                	ld	s0,16(sp)
    1c36:	64a2                	ld	s1,8(sp)
    1c38:	8532                	mv	a0,a2
    1c3a:	6105                	addi	sp,sp,32
    1c3c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c3e:	10000793          	li	a5,256
    1c42:	02f61563          	bne	a2,a5,1c6c <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1c46:	00001597          	auipc	a1,0x1
    1c4a:	1c258593          	addi	a1,a1,450 # 2e08 <buffer>
    1c4e:	4505                	li	a0,1
    1c50:	441000ef          	jal	ra,2890 <write>
}
    1c54:	60e2                	ld	ra,24(sp)
    1c56:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1c58:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1c5c:	00001797          	auipc	a5,0x1
    1c60:	1a07a223          	sw	zero,420(a5) # 2e00 <buffer_len>
}
    1c64:	64a2                	ld	s1,8(sp)
    1c66:	8532                	mv	a0,a2
    1c68:	6105                	addi	sp,sp,32
    1c6a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c6c:	42f000ef          	jal	ra,289a <getpid>
    1c70:	842a                	mv	s0,a0
    1c72:	00001517          	auipc	a0,0x1
    1c76:	09650513          	addi	a0,a0,150 # 2d08 <enable_deadlock_detect+0x1a0>
    1c7a:	2f7000ef          	jal	ra,2770 <basename>
    1c7e:	872a                	mv	a4,a0
    1c80:	00001617          	auipc	a2,0x1
    1c84:	f4860613          	addi	a2,a2,-184 # 2bc8 <enable_deadlock_detect+0x60>
    1c88:	05400793          	li	a5,84
    1c8c:	86a2                	mv	a3,s0
    1c8e:	45fd                	li	a1,31
    1c90:	00001517          	auipc	a0,0x1
    1c94:	0b850513          	addi	a0,a0,184 # 2d48 <enable_deadlock_detect+0x1e0>
    1c98:	9d1ff0ef          	jal	ra,1668 <printf>
    1c9c:	557d                	li	a0,-1
    1c9e:	42d000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    1ca2:	4090                	lw	a2,0(s1)
    1ca4:	d659                	beqz	a2,1c32 <out_unlocked.constprop.0+0x32>
    1ca6:	b745                	j	1c46 <out_unlocked.constprop.0+0x46>

0000000000001ca8 <putchar>:
{
    1ca8:	7139                	addi	sp,sp,-64
    1caa:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1cac:	00001497          	auipc	s1,0x1
    1cb0:	15448493          	addi	s1,s1,340 # 2e00 <buffer_len>
    1cb4:	1084a703          	lw	a4,264(s1)
{
    1cb8:	f822                	sd	s0,48(sp)
	char byte = c;
    1cba:	0ff57413          	zext.b	s0,a0
{
    1cbe:	fc06                	sd	ra,56(sp)
	char byte = c;
    1cc0:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1cc4:	4785                	li	a5,1
    1cc6:	00f70d63          	beq	a4,a5,1ce0 <putchar+0x38>
		len = out_unlocked(s, l);
    1cca:	01f10513          	addi	a0,sp,31
    1cce:	f33ff0ef          	jal	ra,1c00 <out_unlocked.constprop.0>
}
    1cd2:	70e2                	ld	ra,56(sp)
    1cd4:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1cd6:	862a                	mv	a2,a0
}
    1cd8:	74a2                	ld	s1,40(sp)
    1cda:	8532                	mv	a0,a2
    1cdc:	6121                	addi	sp,sp,64
    1cde:	8082                	ret
		mutex_lock(buffer_lock);
    1ce0:	10c4a503          	lw	a0,268(s1)
    1ce4:	625000ef          	jal	ra,2b08 <mutex_lock>
		buffer[buffer_len++] = c;
    1ce8:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cea:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1cee:	0017861b          	addiw	a2,a5,1
    1cf2:	97a6                	add	a5,a5,s1
    1cf4:	c090                	sw	a2,0(s1)
    1cf6:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cfa:	02c6c263          	blt	a3,a2,1d1e <putchar+0x76>
    1cfe:	47a9                	li	a5,10
    1d00:	06f40d63          	beq	s0,a5,1d7a <putchar+0xd2>
    1d04:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1d06:	10c4a503          	lw	a0,268(s1)
    1d0a:	e432                	sd	a2,8(sp)
    1d0c:	609000ef          	jal	ra,2b14 <mutex_unlock>
    1d10:	6622                	ld	a2,8(sp)
}
    1d12:	70e2                	ld	ra,56(sp)
    1d14:	7442                	ld	s0,48(sp)
    1d16:	74a2                	ld	s1,40(sp)
    1d18:	8532                	mv	a0,a2
    1d1a:	6121                	addi	sp,sp,64
    1d1c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1d1e:	10000793          	li	a5,256
    1d22:	02f61063          	bne	a2,a5,1d42 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1d26:	00001597          	auipc	a1,0x1
    1d2a:	0e258593          	addi	a1,a1,226 # 2e08 <buffer>
    1d2e:	4505                	li	a0,1
    1d30:	361000ef          	jal	ra,2890 <write>
    1d34:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1d38:	00001797          	auipc	a5,0x1
    1d3c:	0c07a423          	sw	zero,200(a5) # 2e00 <buffer_len>
			if (r < 0) {
    1d40:	b7d9                	j	1d06 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1d42:	359000ef          	jal	ra,289a <getpid>
    1d46:	842a                	mv	s0,a0
    1d48:	00001517          	auipc	a0,0x1
    1d4c:	fc050513          	addi	a0,a0,-64 # 2d08 <enable_deadlock_detect+0x1a0>
    1d50:	221000ef          	jal	ra,2770 <basename>
    1d54:	872a                	mv	a4,a0
    1d56:	00001617          	auipc	a2,0x1
    1d5a:	e7260613          	addi	a2,a2,-398 # 2bc8 <enable_deadlock_detect+0x60>
    1d5e:	05400793          	li	a5,84
    1d62:	86a2                	mv	a3,s0
    1d64:	45fd                	li	a1,31
    1d66:	00001517          	auipc	a0,0x1
    1d6a:	fe250513          	addi	a0,a0,-30 # 2d48 <enable_deadlock_detect+0x1e0>
    1d6e:	8fbff0ef          	jal	ra,1668 <printf>
    1d72:	557d                	li	a0,-1
    1d74:	357000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    1d78:	4090                	lw	a2,0(s1)
    1d7a:	d651                	beqz	a2,1d06 <putchar+0x5e>
    1d7c:	b76d                	j	1d26 <putchar+0x7e>

0000000000001d7e <puts>:
{
    1d7e:	7139                	addi	sp,sp,-64
    1d80:	f822                	sd	s0,48(sp)
    1d82:	f426                	sd	s1,40(sp)
    1d84:	fc06                	sd	ra,56(sp)
    1d86:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1d88:	00001417          	auipc	s0,0x1
    1d8c:	07840413          	addi	s0,s0,120 # 2e00 <buffer_len>
{
    1d90:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d92:	638000ef          	jal	ra,23ca <strlen>
	if (buffer_lock_enabled == 1) {
    1d96:	10842703          	lw	a4,264(s0)
    1d9a:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1d9c:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1d9e:	04f70563          	beq	a4,a5,1de8 <puts+0x6a>
		len = out_unlocked(s, l);
    1da2:	8526                	mv	a0,s1
    1da4:	d51ff0ef          	jal	ra,1af4 <out_unlocked>
    1da8:	892a                	mv	s2,a0
    1daa:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1dac:	00095963          	bgez	s2,1dbe <puts+0x40>
}
    1db0:	70e2                	ld	ra,56(sp)
    1db2:	7442                	ld	s0,48(sp)
    1db4:	7902                	ld	s2,32(sp)
    1db6:	8526                	mv	a0,s1
    1db8:	74a2                	ld	s1,40(sp)
    1dba:	6121                	addi	sp,sp,64
    1dbc:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1dbe:	10842703          	lw	a4,264(s0)
	char byte = c;
    1dc2:	44a9                	li	s1,10
    1dc4:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1dc8:	4785                	li	a5,1
    1dca:	02f70e63          	beq	a4,a5,1e06 <puts+0x88>
		len = out_unlocked(s, l);
    1dce:	01f10513          	addi	a0,sp,31
    1dd2:	e2fff0ef          	jal	ra,1c00 <out_unlocked.constprop.0>
}
    1dd6:	70e2                	ld	ra,56(sp)
    1dd8:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1dda:	41f5549b          	sraiw	s1,a0,0x1f
}
    1dde:	7902                	ld	s2,32(sp)
    1de0:	8526                	mv	a0,s1
    1de2:	74a2                	ld	s1,40(sp)
    1de4:	6121                	addi	sp,sp,64
    1de6:	8082                	ret
		mutex_lock(buffer_lock);
    1de8:	e42a                	sd	a0,8(sp)
    1dea:	10c42503          	lw	a0,268(s0)
    1dee:	51b000ef          	jal	ra,2b08 <mutex_lock>
		len = out_unlocked(s, l);
    1df2:	65a2                	ld	a1,8(sp)
    1df4:	8526                	mv	a0,s1
    1df6:	cffff0ef          	jal	ra,1af4 <out_unlocked>
    1dfa:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1dfc:	10c42503          	lw	a0,268(s0)
    1e00:	515000ef          	jal	ra,2b14 <mutex_unlock>
    1e04:	b75d                	j	1daa <puts+0x2c>
		mutex_lock(buffer_lock);
    1e06:	10c42503          	lw	a0,268(s0)
    1e0a:	4ff000ef          	jal	ra,2b08 <mutex_lock>
		buffer[buffer_len++] = c;
    1e0e:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1e10:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1e14:	0017861b          	addiw	a2,a5,1
    1e18:	97a2                	add	a5,a5,s0
    1e1a:	c010                	sw	a2,0(s0)
    1e1c:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1e20:	06c6dc63          	bge	a3,a2,1e98 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1e24:	10000793          	li	a5,256
    1e28:	02f61c63          	bne	a2,a5,1e60 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1e2c:	00001597          	auipc	a1,0x1
    1e30:	fdc58593          	addi	a1,a1,-36 # 2e08 <buffer>
    1e34:	4505                	li	a0,1
    1e36:	25b000ef          	jal	ra,2890 <write>
			if (r < 0) {
    1e3a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1e3c:	00001797          	auipc	a5,0x1
    1e40:	fc07a223          	sw	zero,-60(a5) # 2e00 <buffer_len>
			if (r < 0) {
    1e44:	04054c63          	bltz	a0,1e9c <puts+0x11e>
			if (r < buffer_len) {
    1e48:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1e4a:	10c42503          	lw	a0,268(s0)
    1e4e:	4c7000ef          	jal	ra,2b14 <mutex_unlock>
}
    1e52:	70e2                	ld	ra,56(sp)
    1e54:	7442                	ld	s0,48(sp)
    1e56:	7902                	ld	s2,32(sp)
    1e58:	8526                	mv	a0,s1
    1e5a:	74a2                	ld	s1,40(sp)
    1e5c:	6121                	addi	sp,sp,64
    1e5e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1e60:	23b000ef          	jal	ra,289a <getpid>
    1e64:	84aa                	mv	s1,a0
    1e66:	00001517          	auipc	a0,0x1
    1e6a:	ea250513          	addi	a0,a0,-350 # 2d08 <enable_deadlock_detect+0x1a0>
    1e6e:	103000ef          	jal	ra,2770 <basename>
    1e72:	872a                	mv	a4,a0
    1e74:	00001617          	auipc	a2,0x1
    1e78:	d5460613          	addi	a2,a2,-684 # 2bc8 <enable_deadlock_detect+0x60>
    1e7c:	05400793          	li	a5,84
    1e80:	86a6                	mv	a3,s1
    1e82:	45fd                	li	a1,31
    1e84:	00001517          	auipc	a0,0x1
    1e88:	ec450513          	addi	a0,a0,-316 # 2d48 <enable_deadlock_detect+0x1e0>
    1e8c:	fdcff0ef          	jal	ra,1668 <printf>
    1e90:	557d                	li	a0,-1
    1e92:	239000ef          	jal	ra,28ca <exit>
	if (buffer_len == 0)
    1e96:	4010                	lw	a2,0(s0)
    1e98:	da45                	beqz	a2,1e48 <puts+0xca>
    1e9a:	bf49                	j	1e2c <puts+0xae>
    1e9c:	54fd                	li	s1,-1
    1e9e:	b775                	j	1e4a <puts+0xcc>

0000000000001ea0 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ea0:	715d                	addi	sp,sp,-80
    1ea2:	e486                	sd	ra,72(sp)
    1ea4:	e0a2                	sd	s0,64(sp)
    1ea6:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1ea8:	14054363          	bltz	a0,1fee <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1eac:	02b577bb          	remuw	a5,a0,a1
    1eb0:	00001617          	auipc	a2,0x1
    1eb4:	08860613          	addi	a2,a2,136 # 2f38 <digits>
	buf[16] = 0;
    1eb8:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ebc:	0005871b          	sext.w	a4,a1
    1ec0:	1782                	slli	a5,a5,0x20
    1ec2:	9381                	srli	a5,a5,0x20
    1ec4:	97b2                	add	a5,a5,a2
    1ec6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1eca:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ece:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ed2:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ed4:	0eb56763          	bltu	a0,a1,1fc2 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ed8:	02e877bb          	remuw	a5,a6,a4
    1edc:	1782                	slli	a5,a5,0x20
    1ede:	9381                	srli	a5,a5,0x20
    1ee0:	97b2                	add	a5,a5,a2
    1ee2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ee6:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1eea:	02f10323          	sb	a5,38(sp)
    1eee:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ef0:	0ce86963          	bltu	a6,a4,1fc2 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ef4:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1ef8:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1efc:	1582                	slli	a1,a1,0x20
    1efe:	9181                	srli	a1,a1,0x20
    1f00:	95b2                	add	a1,a1,a2
    1f02:	0005c583          	lbu	a1,0(a1)
    1f06:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1f0a:	0007859b          	sext.w	a1,a5
    1f0e:	16e6e563          	bltu	a3,a4,2078 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1f12:	02e7f6bb          	remuw	a3,a5,a4
    1f16:	1682                	slli	a3,a3,0x20
    1f18:	9281                	srli	a3,a3,0x20
    1f1a:	96b2                	add	a3,a3,a2
    1f1c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f20:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1f24:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1f28:	16e5e163          	bltu	a1,a4,208a <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1f2c:	02e876bb          	remuw	a3,a6,a4
    1f30:	1682                	slli	a3,a3,0x20
    1f32:	9281                	srli	a3,a3,0x20
    1f34:	96b2                	add	a3,a3,a2
    1f36:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f3a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f3e:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1f42:	14e86d63          	bltu	a6,a4,209c <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1f46:	02e5f6bb          	remuw	a3,a1,a4
    1f4a:	1682                	slli	a3,a3,0x20
    1f4c:	9281                	srli	a3,a3,0x20
    1f4e:	96b2                	add	a3,a3,a2
    1f50:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f54:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f58:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1f5c:	10e5e563          	bltu	a1,a4,2066 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1f60:	02e876bb          	remuw	a3,a6,a4
    1f64:	1682                	slli	a3,a3,0x20
    1f66:	9281                	srli	a3,a3,0x20
    1f68:	96b2                	add	a3,a3,a2
    1f6a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f6e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1f72:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1f76:	14e86263          	bltu	a6,a4,20ba <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1f7a:	02e5f6bb          	remuw	a3,a1,a4
    1f7e:	1682                	slli	a3,a3,0x20
    1f80:	9281                	srli	a3,a3,0x20
    1f82:	96b2                	add	a3,a3,a2
    1f84:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1f88:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1f8c:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1f90:	14e5e463          	bltu	a1,a4,20d8 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1f94:	02e876bb          	remuw	a3,a6,a4
    1f98:	1682                	slli	a3,a3,0x20
    1f9a:	9281                	srli	a3,a3,0x20
    1f9c:	96b2                	add	a3,a3,a2
    1f9e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1fa2:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1fa6:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1faa:	14e86063          	bltu	a6,a4,20ea <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1fae:	1782                	slli	a5,a5,0x20
    1fb0:	9381                	srli	a5,a5,0x20
    1fb2:	97b2                	add	a5,a5,a2
    1fb4:	0007c703          	lbu	a4,0(a5)
    1fb8:	4799                	li	a5,6
    1fba:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1fbe:	10054763          	bltz	a0,20cc <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1fc2:	00001497          	auipc	s1,0x1
    1fc6:	e3e48493          	addi	s1,s1,-450 # 2e00 <buffer_len>
    1fca:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1fce:	0828                	addi	a0,sp,24
    1fd0:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1fd2:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1fd4:	00f50433          	add	s0,a0,a5
    1fd8:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1fda:	06e68463          	beq	a3,a4,2042 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1fde:	8522                	mv	a0,s0
    1fe0:	b15ff0ef          	jal	ra,1af4 <out_unlocked>
}
    1fe4:	60a6                	ld	ra,72(sp)
    1fe6:	6406                	ld	s0,64(sp)
    1fe8:	74e2                	ld	s1,56(sp)
    1fea:	6161                	addi	sp,sp,80
    1fec:	8082                	ret
		x = -xx;
    1fee:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1ff2:	02b877bb          	remuw	a5,a6,a1
    1ff6:	00001617          	auipc	a2,0x1
    1ffa:	f4260613          	addi	a2,a2,-190 # 2f38 <digits>
	buf[16] = 0;
    1ffe:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    2002:	0005871b          	sext.w	a4,a1
    2006:	1782                	slli	a5,a5,0x20
    2008:	9381                	srli	a5,a5,0x20
    200a:	97b2                	add	a5,a5,a2
    200c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    2010:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    2014:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    2018:	08b86b63          	bltu	a6,a1,20ae <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    201c:	02e8f7bb          	remuw	a5,a7,a4
    2020:	1782                	slli	a5,a5,0x20
    2022:	9381                	srli	a5,a5,0x20
    2024:	97b2                	add	a5,a5,a2
    2026:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    202a:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    202e:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    2032:	ece8f1e3          	bgeu	a7,a4,1ef4 <printint.constprop.0+0x54>
		buf[i--] = '-';
    2036:	02d00793          	li	a5,45
    203a:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    203e:	47b5                	li	a5,13
    2040:	b749                	j	1fc2 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    2042:	10c4a503          	lw	a0,268(s1)
    2046:	e42e                	sd	a1,8(sp)
    2048:	2c1000ef          	jal	ra,2b08 <mutex_lock>
		len = out_unlocked(s, l);
    204c:	65a2                	ld	a1,8(sp)
    204e:	8522                	mv	a0,s0
    2050:	aa5ff0ef          	jal	ra,1af4 <out_unlocked>
		mutex_unlock(buffer_lock);
    2054:	10c4a503          	lw	a0,268(s1)
    2058:	2bd000ef          	jal	ra,2b14 <mutex_unlock>
}
    205c:	60a6                	ld	ra,72(sp)
    205e:	6406                	ld	s0,64(sp)
    2060:	74e2                	ld	s1,56(sp)
    2062:	6161                	addi	sp,sp,80
    2064:	8082                	ret
		buf[i--] = digits[x % base];
    2066:	47a9                	li	a5,10
	if (sign)
    2068:	f4055de3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    206c:	02d00793          	li	a5,45
    2070:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    2074:	47a5                	li	a5,9
    2076:	b7b1                	j	1fc2 <printint.constprop.0+0x122>
    2078:	47b5                	li	a5,13
	if (sign)
    207a:	f40554e3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    207e:	02d00793          	li	a5,45
    2082:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    2086:	47b1                	li	a5,12
    2088:	bf2d                	j	1fc2 <printint.constprop.0+0x122>
    208a:	47b1                	li	a5,12
	if (sign)
    208c:	f2055be3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    2090:	02d00793          	li	a5,45
    2094:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    2098:	47ad                	li	a5,11
    209a:	b725                	j	1fc2 <printint.constprop.0+0x122>
    209c:	47ad                	li	a5,11
	if (sign)
    209e:	f20552e3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20a2:	02d00793          	li	a5,45
    20a6:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    20aa:	47a9                	li	a5,10
    20ac:	bf19                	j	1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20ae:	02d00793          	li	a5,45
    20b2:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    20b6:	47b9                	li	a5,14
    20b8:	b729                	j	1fc2 <printint.constprop.0+0x122>
    20ba:	47a5                	li	a5,9
	if (sign)
    20bc:	f00553e3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20c0:	02d00793          	li	a5,45
    20c4:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    20c8:	47a1                	li	a5,8
    20ca:	bde5                	j	1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20cc:	02d00793          	li	a5,45
    20d0:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    20d4:	4795                	li	a5,5
    20d6:	b5f5                	j	1fc2 <printint.constprop.0+0x122>
    20d8:	47a1                	li	a5,8
	if (sign)
    20da:	ee0554e3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20de:	02d00793          	li	a5,45
    20e2:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    20e6:	479d                	li	a5,7
    20e8:	bde9                	j	1fc2 <printint.constprop.0+0x122>
    20ea:	479d                	li	a5,7
	if (sign)
    20ec:	ec055be3          	bgez	a0,1fc2 <printint.constprop.0+0x122>
		buf[i--] = '-';
    20f0:	02d00793          	li	a5,45
    20f4:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    20f8:	4799                	li	a5,6
    20fa:	b5e1                	j	1fc2 <printint.constprop.0+0x122>

00000000000020fc <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    20fc:	02000793          	li	a5,32
    2100:	00f50663          	beq	a0,a5,210c <isspace+0x10>
    2104:	355d                	addiw	a0,a0,-9
    2106:	00553513          	sltiu	a0,a0,5
    210a:	8082                	ret
    210c:	4505                	li	a0,1
}
    210e:	8082                	ret

0000000000002110 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    2110:	fd05051b          	addiw	a0,a0,-48
}
    2114:	00a53513          	sltiu	a0,a0,10
    2118:	8082                	ret

000000000000211a <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    211a:	02000613          	li	a2,32
    211e:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    2120:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    2124:	ff77869b          	addiw	a3,a5,-9
    2128:	04c78c63          	beq	a5,a2,2180 <atoi+0x66>
    212c:	0007871b          	sext.w	a4,a5
    2130:	04d5f863          	bgeu	a1,a3,2180 <atoi+0x66>
		s++;
	switch (*s) {
    2134:	02b00693          	li	a3,43
    2138:	04d78963          	beq	a5,a3,218a <atoi+0x70>
    213c:	02d00693          	li	a3,45
    2140:	06d78263          	beq	a5,a3,21a4 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    2144:	fd07061b          	addiw	a2,a4,-48
    2148:	47a5                	li	a5,9
    214a:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    214c:	4e01                	li	t3,0
	while (isdigit(*s))
    214e:	04c7e963          	bltu	a5,a2,21a0 <atoi+0x86>
	int n = 0, neg = 0;
    2152:	4501                	li	a0,0
	while (isdigit(*s))
    2154:	4825                	li	a6,9
    2156:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    215a:	0025179b          	slliw	a5,a0,0x2
    215e:	9fa9                	addw	a5,a5,a0
    2160:	fd07031b          	addiw	t1,a4,-48
    2164:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    2168:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    216c:	0685                	addi	a3,a3,1
    216e:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    2172:	0006071b          	sext.w	a4,a2
    2176:	feb870e3          	bgeu	a6,a1,2156 <atoi+0x3c>
	return neg ? n : -n;
    217a:	000e0563          	beqz	t3,2184 <atoi+0x6a>
}
    217e:	8082                	ret
		s++;
    2180:	0505                	addi	a0,a0,1
    2182:	bf79                	j	2120 <atoi+0x6>
	return neg ? n : -n;
    2184:	4113053b          	subw	a0,t1,a7
    2188:	8082                	ret
	while (isdigit(*s))
    218a:	00154703          	lbu	a4,1(a0)
    218e:	47a5                	li	a5,9
		s++;
    2190:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2194:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    2198:	4e01                	li	t3,0
	while (isdigit(*s))
    219a:	2701                	sext.w	a4,a4
    219c:	fac7fbe3          	bgeu	a5,a2,2152 <atoi+0x38>
    21a0:	4501                	li	a0,0
}
    21a2:	8082                	ret
	while (isdigit(*s))
    21a4:	00154703          	lbu	a4,1(a0)
    21a8:	47a5                	li	a5,9
		s++;
    21aa:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    21ae:	fd07061b          	addiw	a2,a4,-48
    21b2:	2701                	sext.w	a4,a4
    21b4:	fec7e6e3          	bltu	a5,a2,21a0 <atoi+0x86>
		neg = 1;
    21b8:	4e05                	li	t3,1
    21ba:	bf61                	j	2152 <atoi+0x38>

00000000000021bc <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    21bc:	16060d63          	beqz	a2,2336 <memset+0x17a>
    21c0:	40a007b3          	neg	a5,a0
    21c4:	8b9d                	andi	a5,a5,7
    21c6:	00778693          	addi	a3,a5,7
    21ca:	482d                	li	a6,11
    21cc:	0ff5f713          	zext.b	a4,a1
    21d0:	fff60593          	addi	a1,a2,-1
    21d4:	1706e263          	bltu	a3,a6,2338 <memset+0x17c>
    21d8:	16d5ea63          	bltu	a1,a3,234c <memset+0x190>
    21dc:	16078563          	beqz	a5,2346 <memset+0x18a>
    21e0:	00e50023          	sb	a4,0(a0)
    21e4:	4685                	li	a3,1
    21e6:	00150593          	addi	a1,a0,1
    21ea:	14d78c63          	beq	a5,a3,2342 <memset+0x186>
    21ee:	00e500a3          	sb	a4,1(a0)
    21f2:	4689                	li	a3,2
    21f4:	00250593          	addi	a1,a0,2
    21f8:	14d78d63          	beq	a5,a3,2352 <memset+0x196>
    21fc:	00e50123          	sb	a4,2(a0)
    2200:	468d                	li	a3,3
    2202:	00350593          	addi	a1,a0,3
    2206:	12d78b63          	beq	a5,a3,233c <memset+0x180>
    220a:	00e501a3          	sb	a4,3(a0)
    220e:	4691                	li	a3,4
    2210:	00450593          	addi	a1,a0,4
    2214:	14d78163          	beq	a5,a3,2356 <memset+0x19a>
    2218:	00e50223          	sb	a4,4(a0)
    221c:	4695                	li	a3,5
    221e:	00550593          	addi	a1,a0,5
    2222:	12d78c63          	beq	a5,a3,235a <memset+0x19e>
    2226:	00e502a3          	sb	a4,5(a0)
    222a:	469d                	li	a3,7
    222c:	00650593          	addi	a1,a0,6
    2230:	12d79763          	bne	a5,a3,235e <memset+0x1a2>
    2234:	00750593          	addi	a1,a0,7
    2238:	00e50323          	sb	a4,6(a0)
    223c:	481d                	li	a6,7
    223e:	00871693          	slli	a3,a4,0x8
    2242:	01071893          	slli	a7,a4,0x10
    2246:	8ed9                	or	a3,a3,a4
    2248:	01871313          	slli	t1,a4,0x18
    224c:	0116e6b3          	or	a3,a3,a7
    2250:	0066e6b3          	or	a3,a3,t1
    2254:	02071893          	slli	a7,a4,0x20
    2258:	02871e13          	slli	t3,a4,0x28
    225c:	0116e6b3          	or	a3,a3,a7
    2260:	40f60333          	sub	t1,a2,a5
    2264:	03071893          	slli	a7,a4,0x30
    2268:	01c6e6b3          	or	a3,a3,t3
    226c:	0116e6b3          	or	a3,a3,a7
    2270:	03871e13          	slli	t3,a4,0x38
    2274:	97aa                	add	a5,a5,a0
    2276:	ff837893          	andi	a7,t1,-8
    227a:	01c6e6b3          	or	a3,a3,t3
    227e:	98be                	add	a7,a7,a5
    2280:	e394                	sd	a3,0(a5)
    2282:	07a1                	addi	a5,a5,8
    2284:	ff179ee3          	bne	a5,a7,2280 <memset+0xc4>
    2288:	ff837893          	andi	a7,t1,-8
    228c:	011587b3          	add	a5,a1,a7
    2290:	010886bb          	addw	a3,a7,a6
    2294:	0b130663          	beq	t1,a7,2340 <memset+0x184>
    2298:	00e78023          	sb	a4,0(a5)
    229c:	0016859b          	addiw	a1,a3,1
    22a0:	08c5fb63          	bgeu	a1,a2,2336 <memset+0x17a>
    22a4:	00e780a3          	sb	a4,1(a5)
    22a8:	0026859b          	addiw	a1,a3,2
    22ac:	08c5f563          	bgeu	a1,a2,2336 <memset+0x17a>
    22b0:	00e78123          	sb	a4,2(a5)
    22b4:	0036859b          	addiw	a1,a3,3
    22b8:	06c5ff63          	bgeu	a1,a2,2336 <memset+0x17a>
    22bc:	00e781a3          	sb	a4,3(a5)
    22c0:	0046859b          	addiw	a1,a3,4
    22c4:	06c5f963          	bgeu	a1,a2,2336 <memset+0x17a>
    22c8:	00e78223          	sb	a4,4(a5)
    22cc:	0056859b          	addiw	a1,a3,5
    22d0:	06c5f363          	bgeu	a1,a2,2336 <memset+0x17a>
    22d4:	00e782a3          	sb	a4,5(a5)
    22d8:	0066859b          	addiw	a1,a3,6
    22dc:	04c5fd63          	bgeu	a1,a2,2336 <memset+0x17a>
    22e0:	00e78323          	sb	a4,6(a5)
    22e4:	0076859b          	addiw	a1,a3,7
    22e8:	04c5f763          	bgeu	a1,a2,2336 <memset+0x17a>
    22ec:	00e783a3          	sb	a4,7(a5)
    22f0:	0086859b          	addiw	a1,a3,8
    22f4:	04c5f163          	bgeu	a1,a2,2336 <memset+0x17a>
    22f8:	00e78423          	sb	a4,8(a5)
    22fc:	0096859b          	addiw	a1,a3,9
    2300:	02c5fb63          	bgeu	a1,a2,2336 <memset+0x17a>
    2304:	00e784a3          	sb	a4,9(a5)
    2308:	00a6859b          	addiw	a1,a3,10
    230c:	02c5f563          	bgeu	a1,a2,2336 <memset+0x17a>
    2310:	00e78523          	sb	a4,10(a5)
    2314:	00b6859b          	addiw	a1,a3,11
    2318:	00c5ff63          	bgeu	a1,a2,2336 <memset+0x17a>
    231c:	00e785a3          	sb	a4,11(a5)
    2320:	00c6859b          	addiw	a1,a3,12
    2324:	00c5f963          	bgeu	a1,a2,2336 <memset+0x17a>
    2328:	00e78623          	sb	a4,12(a5)
    232c:	26b5                	addiw	a3,a3,13
    232e:	00c6f463          	bgeu	a3,a2,2336 <memset+0x17a>
    2332:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2336:	8082                	ret
    2338:	46ad                	li	a3,11
    233a:	bd79                	j	21d8 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    233c:	480d                	li	a6,3
    233e:	b701                	j	223e <memset+0x82>
    2340:	8082                	ret
    2342:	4805                	li	a6,1
    2344:	bded                	j	223e <memset+0x82>
    2346:	85aa                	mv	a1,a0
    2348:	4801                	li	a6,0
    234a:	bdd5                	j	223e <memset+0x82>
    234c:	87aa                	mv	a5,a0
    234e:	4681                	li	a3,0
    2350:	b7a1                	j	2298 <memset+0xdc>
    2352:	4809                	li	a6,2
    2354:	b5ed                	j	223e <memset+0x82>
    2356:	4811                	li	a6,4
    2358:	b5dd                	j	223e <memset+0x82>
    235a:	4815                	li	a6,5
    235c:	b5cd                	j	223e <memset+0x82>
    235e:	4819                	li	a6,6
    2360:	bdf9                	j	223e <memset+0x82>

0000000000002362 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2362:	00054783          	lbu	a5,0(a0)
    2366:	0005c703          	lbu	a4,0(a1)
    236a:	00e79863          	bne	a5,a4,237a <strcmp+0x18>
    236e:	0505                	addi	a0,a0,1
    2370:	0585                	addi	a1,a1,1
    2372:	fbe5                	bnez	a5,2362 <strcmp>
    2374:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2376:	9d19                	subw	a0,a0,a4
    2378:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    237a:	0007851b          	sext.w	a0,a5
    237e:	bfe5                	j	2376 <strcmp+0x14>

0000000000002380 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2380:	ca15                	beqz	a2,23b4 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2382:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2386:	167d                	addi	a2,a2,-1
    2388:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    238c:	eb99                	bnez	a5,23a2 <strncmp+0x22>
    238e:	a815                	j	23c2 <strncmp+0x42>
    2390:	00a68e63          	beq	a3,a0,23ac <strncmp+0x2c>
    2394:	0505                	addi	a0,a0,1
    2396:	00f71b63          	bne	a4,a5,23ac <strncmp+0x2c>
    239a:	00054783          	lbu	a5,0(a0)
    239e:	cf89                	beqz	a5,23b8 <strncmp+0x38>
    23a0:	85b2                	mv	a1,a2
    23a2:	0005c703          	lbu	a4,0(a1)
    23a6:	00158613          	addi	a2,a1,1
    23aa:	f37d                	bnez	a4,2390 <strncmp+0x10>
		;
	return *l - *r;
    23ac:	0007851b          	sext.w	a0,a5
    23b0:	9d19                	subw	a0,a0,a4
    23b2:	8082                	ret
		return 0;
    23b4:	4501                	li	a0,0
}
    23b6:	8082                	ret
	return *l - *r;
    23b8:	0015c703          	lbu	a4,1(a1)
    23bc:	4501                	li	a0,0
    23be:	9d19                	subw	a0,a0,a4
    23c0:	8082                	ret
    23c2:	0005c703          	lbu	a4,0(a1)
    23c6:	4501                	li	a0,0
    23c8:	b7e5                	j	23b0 <strncmp+0x30>

00000000000023ca <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    23ca:	00757793          	andi	a5,a0,7
    23ce:	cf89                	beqz	a5,23e8 <strlen+0x1e>
    23d0:	87aa                	mv	a5,a0
    23d2:	a029                	j	23dc <strlen+0x12>
    23d4:	0785                	addi	a5,a5,1
    23d6:	0077f713          	andi	a4,a5,7
    23da:	cb01                	beqz	a4,23ea <strlen+0x20>
		if (!*s)
    23dc:	0007c703          	lbu	a4,0(a5)
    23e0:	fb75                	bnez	a4,23d4 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    23e2:	40a78533          	sub	a0,a5,a0
}
    23e6:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23e8:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    23ea:	6394                	ld	a3,0(a5)
    23ec:	00001597          	auipc	a1,0x1
    23f0:	9f45b583          	ld	a1,-1548(a1) # 2de0 <enable_deadlock_detect+0x278>
    23f4:	00001617          	auipc	a2,0x1
    23f8:	9f463603          	ld	a2,-1548(a2) # 2de8 <enable_deadlock_detect+0x280>
    23fc:	a019                	j	2402 <strlen+0x38>
    23fe:	6794                	ld	a3,8(a5)
    2400:	07a1                	addi	a5,a5,8
    2402:	00b68733          	add	a4,a3,a1
    2406:	fff6c693          	not	a3,a3
    240a:	8f75                	and	a4,a4,a3
    240c:	8f71                	and	a4,a4,a2
    240e:	db65                	beqz	a4,23fe <strlen+0x34>
	for (; *s; s++)
    2410:	0007c703          	lbu	a4,0(a5)
    2414:	d779                	beqz	a4,23e2 <strlen+0x18>
    2416:	0017c703          	lbu	a4,1(a5)
    241a:	0785                	addi	a5,a5,1
    241c:	d379                	beqz	a4,23e2 <strlen+0x18>
    241e:	0017c703          	lbu	a4,1(a5)
    2422:	0785                	addi	a5,a5,1
    2424:	fb6d                	bnez	a4,2416 <strlen+0x4c>
    2426:	bf75                	j	23e2 <strlen+0x18>

0000000000002428 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2428:	00757713          	andi	a4,a0,7
{
    242c:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    242e:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2432:	cb19                	beqz	a4,2448 <memchr+0x20>
    2434:	ce25                	beqz	a2,24ac <memchr+0x84>
    2436:	0007c703          	lbu	a4,0(a5)
    243a:	04b70e63          	beq	a4,a1,2496 <memchr+0x6e>
    243e:	0785                	addi	a5,a5,1
    2440:	0077f713          	andi	a4,a5,7
    2444:	167d                	addi	a2,a2,-1
    2446:	f77d                	bnez	a4,2434 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2448:	4501                	li	a0,0
	if (n && *s != c) {
    244a:	c235                	beqz	a2,24ae <memchr+0x86>
    244c:	0007c703          	lbu	a4,0(a5)
    2450:	04b70363          	beq	a4,a1,2496 <memchr+0x6e>
		size_t k = ONES * c;
    2454:	00001517          	auipc	a0,0x1
    2458:	99c53503          	ld	a0,-1636(a0) # 2df0 <enable_deadlock_detect+0x288>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    245c:	471d                	li	a4,7
		size_t k = ONES * c;
    245e:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2462:	02c77a63          	bgeu	a4,a2,2496 <memchr+0x6e>
    2466:	00001897          	auipc	a7,0x1
    246a:	97a8b883          	ld	a7,-1670(a7) # 2de0 <enable_deadlock_detect+0x278>
    246e:	00001817          	auipc	a6,0x1
    2472:	97a83803          	ld	a6,-1670(a6) # 2de8 <enable_deadlock_detect+0x280>
    2476:	431d                	li	t1,7
    2478:	a029                	j	2482 <memchr+0x5a>
		     w++, n -= SS)
    247a:	1661                	addi	a2,a2,-8
    247c:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    247e:	02c37963          	bgeu	t1,a2,24b0 <memchr+0x88>
    2482:	6398                	ld	a4,0(a5)
    2484:	8f29                	xor	a4,a4,a0
    2486:	011706b3          	add	a3,a4,a7
    248a:	fff74713          	not	a4,a4
    248e:	8f75                	and	a4,a4,a3
    2490:	01077733          	and	a4,a4,a6
    2494:	d37d                	beqz	a4,247a <memchr+0x52>
{
    2496:	853e                	mv	a0,a5
    2498:	97b2                	add	a5,a5,a2
    249a:	a021                	j	24a2 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    249c:	0505                	addi	a0,a0,1
    249e:	00f50763          	beq	a0,a5,24ac <memchr+0x84>
    24a2:	00054703          	lbu	a4,0(a0)
    24a6:	feb71be3          	bne	a4,a1,249c <memchr+0x74>
    24aa:	8082                	ret
	return n ? (void *)s : 0;
    24ac:	4501                	li	a0,0
}
    24ae:	8082                	ret
	return n ? (void *)s : 0;
    24b0:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    24b2:	f275                	bnez	a2,2496 <memchr+0x6e>
}
    24b4:	8082                	ret

00000000000024b6 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    24b6:	1101                	addi	sp,sp,-32
    24b8:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    24ba:	862e                	mv	a2,a1
{
    24bc:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    24be:	4581                	li	a1,0
{
    24c0:	e426                	sd	s1,8(sp)
    24c2:	ec06                	sd	ra,24(sp)
    24c4:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    24c6:	f63ff0ef          	jal	ra,2428 <memchr>
	return p ? p - s : n;
    24ca:	c519                	beqz	a0,24d8 <strnlen+0x22>
}
    24cc:	60e2                	ld	ra,24(sp)
    24ce:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    24d0:	8d05                	sub	a0,a0,s1
}
    24d2:	64a2                	ld	s1,8(sp)
    24d4:	6105                	addi	sp,sp,32
    24d6:	8082                	ret
    24d8:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    24da:	8522                	mv	a0,s0
}
    24dc:	6442                	ld	s0,16(sp)
    24de:	64a2                	ld	s1,8(sp)
    24e0:	6105                	addi	sp,sp,32
    24e2:	8082                	ret

00000000000024e4 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    24e4:	00a5c7b3          	xor	a5,a1,a0
    24e8:	8b9d                	andi	a5,a5,7
    24ea:	eb95                	bnez	a5,251e <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    24ec:	0075f793          	andi	a5,a1,7
    24f0:	e7b1                	bnez	a5,253c <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    24f2:	6198                	ld	a4,0(a1)
    24f4:	00001617          	auipc	a2,0x1
    24f8:	8ec63603          	ld	a2,-1812(a2) # 2de0 <enable_deadlock_detect+0x278>
    24fc:	00001817          	auipc	a6,0x1
    2500:	8ec83803          	ld	a6,-1812(a6) # 2de8 <enable_deadlock_detect+0x280>
    2504:	a029                	j	250e <stpcpy+0x2a>
    2506:	05a1                	addi	a1,a1,8
    2508:	e118                	sd	a4,0(a0)
    250a:	6198                	ld	a4,0(a1)
    250c:	0521                	addi	a0,a0,8
    250e:	00c707b3          	add	a5,a4,a2
    2512:	fff74693          	not	a3,a4
    2516:	8ff5                	and	a5,a5,a3
    2518:	0107f7b3          	and	a5,a5,a6
    251c:	d7ed                	beqz	a5,2506 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    251e:	0005c783          	lbu	a5,0(a1)
    2522:	00f50023          	sb	a5,0(a0)
    2526:	c785                	beqz	a5,254e <stpcpy+0x6a>
    2528:	0015c783          	lbu	a5,1(a1)
    252c:	0505                	addi	a0,a0,1
    252e:	0585                	addi	a1,a1,1
    2530:	00f50023          	sb	a5,0(a0)
    2534:	fbf5                	bnez	a5,2528 <stpcpy+0x44>
		;
	return d;
}
    2536:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2538:	0505                	addi	a0,a0,1
    253a:	df45                	beqz	a4,24f2 <stpcpy+0xe>
			if (!(*d = *s))
    253c:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2540:	0585                	addi	a1,a1,1
    2542:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2546:	00f50023          	sb	a5,0(a0)
    254a:	f7fd                	bnez	a5,2538 <stpcpy+0x54>
}
    254c:	8082                	ret
    254e:	8082                	ret

0000000000002550 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2550:	00a5c7b3          	xor	a5,a1,a0
    2554:	8b9d                	andi	a5,a5,7
    2556:	1a079863          	bnez	a5,2706 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    255a:	0075f793          	andi	a5,a1,7
    255e:	16078463          	beqz	a5,26c6 <stpncpy+0x176>
    2562:	ea01                	bnez	a2,2572 <stpncpy+0x22>
    2564:	a421                	j	276c <stpncpy+0x21c>
    2566:	167d                	addi	a2,a2,-1
    2568:	0505                	addi	a0,a0,1
    256a:	14070e63          	beqz	a4,26c6 <stpncpy+0x176>
    256e:	1a060863          	beqz	a2,271e <stpncpy+0x1ce>
    2572:	0005c783          	lbu	a5,0(a1)
    2576:	0585                	addi	a1,a1,1
    2578:	0075f713          	andi	a4,a1,7
    257c:	00f50023          	sb	a5,0(a0)
    2580:	f3fd                	bnez	a5,2566 <stpncpy+0x16>
    2582:	4805                	li	a6,1
    2584:	1a061863          	bnez	a2,2734 <stpncpy+0x1e4>
    2588:	40a007b3          	neg	a5,a0
    258c:	8b9d                	andi	a5,a5,7
    258e:	4681                	li	a3,0
    2590:	18061a63          	bnez	a2,2724 <stpncpy+0x1d4>
    2594:	00778713          	addi	a4,a5,7
    2598:	45ad                	li	a1,11
    259a:	18b76363          	bltu	a4,a1,2720 <stpncpy+0x1d0>
    259e:	1ae6eb63          	bltu	a3,a4,2754 <stpncpy+0x204>
    25a2:	1a078363          	beqz	a5,2748 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    25a6:	00050023          	sb	zero,0(a0)
    25aa:	4685                	li	a3,1
    25ac:	00150713          	addi	a4,a0,1
    25b0:	18d78f63          	beq	a5,a3,274e <stpncpy+0x1fe>
    25b4:	000500a3          	sb	zero,1(a0)
    25b8:	4689                	li	a3,2
    25ba:	00250713          	addi	a4,a0,2
    25be:	18d78e63          	beq	a5,a3,275a <stpncpy+0x20a>
    25c2:	00050123          	sb	zero,2(a0)
    25c6:	468d                	li	a3,3
    25c8:	00350713          	addi	a4,a0,3
    25cc:	16d78c63          	beq	a5,a3,2744 <stpncpy+0x1f4>
    25d0:	000501a3          	sb	zero,3(a0)
    25d4:	4691                	li	a3,4
    25d6:	00450713          	addi	a4,a0,4
    25da:	18d78263          	beq	a5,a3,275e <stpncpy+0x20e>
    25de:	00050223          	sb	zero,4(a0)
    25e2:	4695                	li	a3,5
    25e4:	00550713          	addi	a4,a0,5
    25e8:	16d78d63          	beq	a5,a3,2762 <stpncpy+0x212>
    25ec:	000502a3          	sb	zero,5(a0)
    25f0:	469d                	li	a3,7
    25f2:	00650713          	addi	a4,a0,6
    25f6:	16d79863          	bne	a5,a3,2766 <stpncpy+0x216>
    25fa:	00750713          	addi	a4,a0,7
    25fe:	00050323          	sb	zero,6(a0)
    2602:	40f80833          	sub	a6,a6,a5
    2606:	ff887593          	andi	a1,a6,-8
    260a:	97aa                	add	a5,a5,a0
    260c:	95be                	add	a1,a1,a5
    260e:	0007b023          	sd	zero,0(a5)
    2612:	07a1                	addi	a5,a5,8
    2614:	feb79de3          	bne	a5,a1,260e <stpncpy+0xbe>
    2618:	ff887593          	andi	a1,a6,-8
    261c:	9ead                	addw	a3,a3,a1
    261e:	00b707b3          	add	a5,a4,a1
    2622:	12b80863          	beq	a6,a1,2752 <stpncpy+0x202>
    2626:	00078023          	sb	zero,0(a5)
    262a:	0016871b          	addiw	a4,a3,1
    262e:	0ec77863          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    2632:	000780a3          	sb	zero,1(a5)
    2636:	0026871b          	addiw	a4,a3,2
    263a:	0ec77263          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    263e:	00078123          	sb	zero,2(a5)
    2642:	0036871b          	addiw	a4,a3,3
    2646:	0cc77c63          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    264a:	000781a3          	sb	zero,3(a5)
    264e:	0046871b          	addiw	a4,a3,4
    2652:	0cc77663          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    2656:	00078223          	sb	zero,4(a5)
    265a:	0056871b          	addiw	a4,a3,5
    265e:	0cc77063          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    2662:	000782a3          	sb	zero,5(a5)
    2666:	0066871b          	addiw	a4,a3,6
    266a:	0ac77a63          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    266e:	00078323          	sb	zero,6(a5)
    2672:	0076871b          	addiw	a4,a3,7
    2676:	0ac77463          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    267a:	000783a3          	sb	zero,7(a5)
    267e:	0086871b          	addiw	a4,a3,8
    2682:	08c77e63          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    2686:	00078423          	sb	zero,8(a5)
    268a:	0096871b          	addiw	a4,a3,9
    268e:	08c77863          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    2692:	000784a3          	sb	zero,9(a5)
    2696:	00a6871b          	addiw	a4,a3,10
    269a:	08c77263          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    269e:	00078523          	sb	zero,10(a5)
    26a2:	00b6871b          	addiw	a4,a3,11
    26a6:	06c77c63          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    26aa:	000785a3          	sb	zero,11(a5)
    26ae:	00c6871b          	addiw	a4,a3,12
    26b2:	06c77663          	bgeu	a4,a2,271e <stpncpy+0x1ce>
    26b6:	00078623          	sb	zero,12(a5)
    26ba:	26b5                	addiw	a3,a3,13
    26bc:	06c6f163          	bgeu	a3,a2,271e <stpncpy+0x1ce>
    26c0:	000786a3          	sb	zero,13(a5)
    26c4:	8082                	ret
			;
		if (!n || !*s)
    26c6:	c645                	beqz	a2,276e <stpncpy+0x21e>
    26c8:	0005c783          	lbu	a5,0(a1)
    26cc:	ea078be3          	beqz	a5,2582 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    26d0:	479d                	li	a5,7
    26d2:	02c7ff63          	bgeu	a5,a2,2710 <stpncpy+0x1c0>
    26d6:	00000897          	auipc	a7,0x0
    26da:	70a8b883          	ld	a7,1802(a7) # 2de0 <enable_deadlock_detect+0x278>
    26de:	00000817          	auipc	a6,0x0
    26e2:	70a83803          	ld	a6,1802(a6) # 2de8 <enable_deadlock_detect+0x280>
    26e6:	431d                	li	t1,7
    26e8:	6198                	ld	a4,0(a1)
    26ea:	011707b3          	add	a5,a4,a7
    26ee:	fff74693          	not	a3,a4
    26f2:	8ff5                	and	a5,a5,a3
    26f4:	0107f7b3          	and	a5,a5,a6
    26f8:	ef81                	bnez	a5,2710 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    26fa:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    26fc:	1661                	addi	a2,a2,-8
    26fe:	05a1                	addi	a1,a1,8
    2700:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2702:	fec363e3          	bltu	t1,a2,26e8 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2706:	e609                	bnez	a2,2710 <stpncpy+0x1c0>
    2708:	a08d                	j	276a <stpncpy+0x21a>
    270a:	167d                	addi	a2,a2,-1
    270c:	0505                	addi	a0,a0,1
    270e:	ca01                	beqz	a2,271e <stpncpy+0x1ce>
    2710:	0005c783          	lbu	a5,0(a1)
    2714:	0585                	addi	a1,a1,1
    2716:	00f50023          	sb	a5,0(a0)
    271a:	fbe5                	bnez	a5,270a <stpncpy+0x1ba>
		;
tail:
    271c:	b59d                	j	2582 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    271e:	8082                	ret
    2720:	472d                	li	a4,11
    2722:	bdb5                	j	259e <stpncpy+0x4e>
    2724:	00778713          	addi	a4,a5,7
    2728:	45ad                	li	a1,11
    272a:	fff60693          	addi	a3,a2,-1
    272e:	e6b778e3          	bgeu	a4,a1,259e <stpncpy+0x4e>
    2732:	b7fd                	j	2720 <stpncpy+0x1d0>
    2734:	40a007b3          	neg	a5,a0
    2738:	8832                	mv	a6,a2
    273a:	8b9d                	andi	a5,a5,7
    273c:	4681                	li	a3,0
    273e:	e4060be3          	beqz	a2,2594 <stpncpy+0x44>
    2742:	b7cd                	j	2724 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2744:	468d                	li	a3,3
    2746:	bd75                	j	2602 <stpncpy+0xb2>
    2748:	872a                	mv	a4,a0
    274a:	4681                	li	a3,0
    274c:	bd5d                	j	2602 <stpncpy+0xb2>
    274e:	4685                	li	a3,1
    2750:	bd4d                	j	2602 <stpncpy+0xb2>
    2752:	8082                	ret
    2754:	87aa                	mv	a5,a0
    2756:	4681                	li	a3,0
    2758:	b5f9                	j	2626 <stpncpy+0xd6>
    275a:	4689                	li	a3,2
    275c:	b55d                	j	2602 <stpncpy+0xb2>
    275e:	4691                	li	a3,4
    2760:	b54d                	j	2602 <stpncpy+0xb2>
    2762:	4695                	li	a3,5
    2764:	bd79                	j	2602 <stpncpy+0xb2>
    2766:	4699                	li	a3,6
    2768:	bd69                	j	2602 <stpncpy+0xb2>
    276a:	8082                	ret
    276c:	8082                	ret
    276e:	8082                	ret

0000000000002770 <basename>:

char *basename(char *s)
{
    2770:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2772:	c54d                	beqz	a0,281c <basename+0xac>
    2774:	00054783          	lbu	a5,0(a0)
		return ".";
    2778:	00000517          	auipc	a0,0x0
    277c:	66050513          	addi	a0,a0,1632 # 2dd8 <enable_deadlock_detect+0x270>
	if (!s || !*s)
    2780:	e391                	bnez	a5,2784 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2782:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2784:	0076f713          	andi	a4,a3,7
    2788:	87b6                	mv	a5,a3
    278a:	cf51                	beqz	a4,2826 <basename+0xb6>
    278c:	0785                	addi	a5,a5,1
    278e:	0077f713          	andi	a4,a5,7
    2792:	c729                	beqz	a4,27dc <basename+0x6c>
		if (!*s)
    2794:	0007c703          	lbu	a4,0(a5)
    2798:	fb75                	bnez	a4,278c <basename+0x1c>
	return s - a;
    279a:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    279c:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    279e:	cf8d                	beqz	a5,27d8 <basename+0x68>
    27a0:	00f68733          	add	a4,a3,a5
    27a4:	02f00593          	li	a1,47
    27a8:	a031                	j	27b4 <basename+0x44>
		s[i] = 0;
    27aa:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    27ae:	17fd                	addi	a5,a5,-1
    27b0:	177d                	addi	a4,a4,-1
    27b2:	c39d                	beqz	a5,27d8 <basename+0x68>
    27b4:	00074603          	lbu	a2,0(a4)
    27b8:	feb609e3          	beq	a2,a1,27aa <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    27bc:	02f00613          	li	a2,47
    27c0:	a011                	j	27c4 <basename+0x54>
    27c2:	cb99                	beqz	a5,27d8 <basename+0x68>
    27c4:	853e                	mv	a0,a5
    27c6:	17fd                	addi	a5,a5,-1
    27c8:	00f68733          	add	a4,a3,a5
    27cc:	00074703          	lbu	a4,0(a4)
    27d0:	fec719e3          	bne	a4,a2,27c2 <basename+0x52>
	return s + i;
    27d4:	9536                	add	a0,a0,a3
    27d6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    27d8:	8536                	mv	a0,a3
    27da:	8082                	ret
    27dc:	6390                	ld	a2,0(a5)
    27de:	00000517          	auipc	a0,0x0
    27e2:	60253503          	ld	a0,1538(a0) # 2de0 <enable_deadlock_detect+0x278>
    27e6:	00000597          	auipc	a1,0x0
    27ea:	6025b583          	ld	a1,1538(a1) # 2de8 <enable_deadlock_detect+0x280>
    27ee:	fff64713          	not	a4,a2
    27f2:	962a                	add	a2,a2,a0
    27f4:	8f71                	and	a4,a4,a2
    27f6:	8f6d                	and	a4,a4,a1
    27f8:	eb11                	bnez	a4,280c <basename+0x9c>
    27fa:	6790                	ld	a2,8(a5)
    27fc:	07a1                	addi	a5,a5,8
    27fe:	00a60733          	add	a4,a2,a0
    2802:	fff64613          	not	a2,a2
    2806:	8f71                	and	a4,a4,a2
    2808:	8f6d                	and	a4,a4,a1
    280a:	db65                	beqz	a4,27fa <basename+0x8a>
	for (; *s; s++)
    280c:	0007c703          	lbu	a4,0(a5)
    2810:	d749                	beqz	a4,279a <basename+0x2a>
    2812:	0017c703          	lbu	a4,1(a5)
    2816:	0785                	addi	a5,a5,1
    2818:	ff6d                	bnez	a4,2812 <basename+0xa2>
    281a:	b741                	j	279a <basename+0x2a>
		return ".";
    281c:	00000517          	auipc	a0,0x0
    2820:	5bc50513          	addi	a0,a0,1468 # 2dd8 <enable_deadlock_detect+0x270>
    2824:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2826:	6290                	ld	a2,0(a3)
    2828:	00000517          	auipc	a0,0x0
    282c:	5b853503          	ld	a0,1464(a0) # 2de0 <enable_deadlock_detect+0x278>
    2830:	00000597          	auipc	a1,0x0
    2834:	5b85b583          	ld	a1,1464(a1) # 2de8 <enable_deadlock_detect+0x280>
    2838:	fff64713          	not	a4,a2
    283c:	962a                	add	a2,a2,a0
    283e:	8f71                	and	a4,a4,a2
    2840:	8f6d                	and	a4,a4,a1
    2842:	df45                	beqz	a4,27fa <basename+0x8a>
    2844:	b7f9                	j	2812 <basename+0xa2>

0000000000002846 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2846:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    284a:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    284c:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2850:	2501                	sext.w	a0,a0
    2852:	8082                	ret

0000000000002854 <close>:

int close(int fd)
{
	if (fd == 1) {
    2854:	4785                	li	a5,1
    2856:	00f50863          	beq	a0,a5,2866 <close+0x12>
	register long a7 __asm__("a7") = n;
    285a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    285e:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2862:	2501                	sext.w	a0,a0
    2864:	8082                	ret
{
    2866:	1101                	addi	sp,sp,-32
    2868:	ec06                	sd	ra,24(sp)
    286a:	e42a                	sd	a0,8(sp)
		__write_buffer();
    286c:	cdffe0ef          	jal	ra,154a <__write_buffer>
		__clear_buffer();
    2870:	d03fe0ef          	jal	ra,1572 <__clear_buffer>
    2874:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2876:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    287a:	00000073          	ecall
}
    287e:	60e2                	ld	ra,24(sp)
    2880:	2501                	sext.w	a0,a0
    2882:	6105                	addi	sp,sp,32
    2884:	8082                	ret

0000000000002886 <read>:
	register long a7 __asm__("a7") = n;
    2886:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    288a:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    288e:	8082                	ret

0000000000002890 <write>:
	register long a7 __asm__("a7") = n;
    2890:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2894:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2898:	8082                	ret

000000000000289a <getpid>:
	register long a7 __asm__("a7") = n;
    289a:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    289e:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    28a2:	2501                	sext.w	a0,a0
    28a4:	8082                	ret

00000000000028a6 <getppid>:
	register long a7 __asm__("a7") = n;
    28a6:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    28aa:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    28ae:	2501                	sext.w	a0,a0
    28b0:	8082                	ret

00000000000028b2 <sched_yield>:
	register long a7 __asm__("a7") = n;
    28b2:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    28b6:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    28ba:	2501                	sext.w	a0,a0
    28bc:	8082                	ret

00000000000028be <fork>:
	register long a7 __asm__("a7") = n;
    28be:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    28c2:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    28c6:	2501                	sext.w	a0,a0
    28c8:	8082                	ret

00000000000028ca <exit>:

void exit(int code)
{
    28ca:	1141                	addi	sp,sp,-16
    28cc:	e406                	sd	ra,8(sp)
    28ce:	e022                	sd	s0,0(sp)
    28d0:	842a                	mv	s0,a0
	__write_buffer();
    28d2:	c79fe0ef          	jal	ra,154a <__write_buffer>
	__clear_buffer();
    28d6:	c9dfe0ef          	jal	ra,1572 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    28da:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    28de:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    28e0:	00000073          	ecall
	syscall(SYS_exit, code);
}
    28e4:	60a2                	ld	ra,8(sp)
    28e6:	6402                	ld	s0,0(sp)
    28e8:	0141                	addi	sp,sp,16
    28ea:	8082                	ret

00000000000028ec <waitpid>:
	register long a7 __asm__("a7") = n;
    28ec:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28f0:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    28f4:	2501                	sext.w	a0,a0
    28f6:	8082                	ret

00000000000028f8 <exec>:
	register long a7 __asm__("a7") = n;
    28f8:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28fc:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2900:	2501                	sext.w	a0,a0
    2902:	8082                	ret

0000000000002904 <get_mtime>:

int64 get_mtime()
{
    2904:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2906:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    290a:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    290c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    290e:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2912:	2501                	sext.w	a0,a0
    2914:	ed01                	bnez	a0,292c <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2916:	6722                	ld	a4,8(sp)
    2918:	3e800793          	li	a5,1000
    291c:	6682                	ld	a3,0(sp)
    291e:	02f75733          	divu	a4,a4,a5
    2922:	02d78533          	mul	a0,a5,a3
    2926:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2928:	0141                	addi	sp,sp,16
    292a:	8082                	ret
	return -1;
    292c:	557d                	li	a0,-1
    292e:	bfed                	j	2928 <get_mtime+0x24>

0000000000002930 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2930:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2934:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2938:	2501                	sext.w	a0,a0
    293a:	8082                	ret

000000000000293c <sleep>:

int sleep(unsigned long long time)
{
    293c:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    293e:	880a                	mv	a6,sp
{
    2940:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2942:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2946:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2948:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    294a:	00000073          	ecall
	if (err == 0) {
    294e:	2501                	sext.w	a0,a0
    2950:	ed31                	bnez	a0,29ac <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2952:	6722                	ld	a4,8(sp)
    2954:	3e800793          	li	a5,1000
    2958:	6682                	ld	a3,0(sp)
    295a:	02f75733          	divu	a4,a4,a5
    295e:	02d787b3          	mul	a5,a5,a3
    2962:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2964:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2968:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    296a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    296c:	00000073          	ecall
	if (err == 0) {
    2970:	2501                	sext.w	a0,a0
    2972:	e915                	bnez	a0,29a6 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2974:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2976:	3e800693          	li	a3,1000
    297a:	a819                	j	2990 <sleep+0x54>
	__asm_syscall("r"(a7))
    297c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2980:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2984:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2986:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2988:	00000073          	ecall
	if (err == 0) {
    298c:	2501                	sext.w	a0,a0
    298e:	ed01                	bnez	a0,29a6 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2990:	6722                	ld	a4,8(sp)
    2992:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2994:	07c00893          	li	a7,124
    2998:	02d75733          	divu	a4,a4,a3
    299c:	02f687b3          	mul	a5,a3,a5
    29a0:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    29a2:	fcc7ede3          	bltu	a5,a2,297c <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    29a6:	4501                	li	a0,0
    29a8:	0141                	addi	sp,sp,16
    29aa:	8082                	ret
    29ac:	57fd                	li	a5,-1
    29ae:	bf5d                	j	2964 <sleep+0x28>

00000000000029b0 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    29b0:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    29b4:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    29b8:	2501                	sext.w	a0,a0
    29ba:	8082                	ret

00000000000029bc <set_priority>:
	register long a7 __asm__("a7") = n;
    29bc:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    29c0:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    29c4:	2501                	sext.w	a0,a0
    29c6:	8082                	ret

00000000000029c8 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    29c8:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    29cc:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    29d0:	2501                	sext.w	a0,a0
    29d2:	8082                	ret

00000000000029d4 <munmap>:
	register long a7 __asm__("a7") = n;
    29d4:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29d8:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    29dc:	2501                	sext.w	a0,a0
    29de:	8082                	ret

00000000000029e0 <wait>:

int wait(int *code)
{
    29e0:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    29e2:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    29e6:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    29e8:	00000073          	ecall
	return waitpid(-1, code);
}
    29ec:	2501                	sext.w	a0,a0
    29ee:	8082                	ret

00000000000029f0 <spawn>:
	register long a7 __asm__("a7") = n;
    29f0:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    29f4:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    29f8:	2501                	sext.w	a0,a0
    29fa:	8082                	ret

00000000000029fc <pipe>:
	register long a7 __asm__("a7") = n;
    29fc:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2a00:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2a04:	2501                	sext.w	a0,a0
    2a06:	8082                	ret

0000000000002a08 <mailread>:
	register long a7 __asm__("a7") = n;
    2a08:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a0c:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2a10:	2501                	sext.w	a0,a0
    2a12:	8082                	ret

0000000000002a14 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2a14:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a18:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2a1c:	2501                	sext.w	a0,a0
    2a1e:	8082                	ret

0000000000002a20 <fstat>:
	register long a7 __asm__("a7") = n;
    2a20:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a24:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2a28:	2501                	sext.w	a0,a0
    2a2a:	8082                	ret

0000000000002a2c <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2a2c:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2a2e:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2a32:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a34:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2a38:	2501                	sext.w	a0,a0
    2a3a:	8082                	ret

0000000000002a3c <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2a3c:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2a3e:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2a42:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a44:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2a48:	2501                	sext.w	a0,a0
    2a4a:	8082                	ret

0000000000002a4c <link>:

int link(char *old_path, char *new_path)
{
    2a4c:	87aa                	mv	a5,a0
    2a4e:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2a50:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2a54:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2a58:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2a5a:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2a5e:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2a60:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2a64:	2501                	sext.w	a0,a0
    2a66:	8082                	ret

0000000000002a68 <unlink>:

int unlink(char *path)
{
    2a68:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2a6a:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2a6e:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2a72:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2a74:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2a78:	2501                	sext.w	a0,a0
    2a7a:	8082                	ret

0000000000002a7c <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2a7c:	00000797          	auipc	a5,0x0
    2a80:	4dc7b783          	ld	a5,1244(a5) # 2f58 <_GLOBAL_OFFSET_TABLE_+0x8>
    2a84:	439c                	lw	a5,0(a5)
    2a86:	c799                	beqz	a5,2a94 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2a88:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a8c:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2a90:	2501                	sext.w	a0,a0
    2a92:	8082                	ret
{
    2a94:	1101                	addi	sp,sp,-32
    2a96:	ec06                	sd	ra,24(sp)
    2a98:	e42e                	sd	a1,8(sp)
    2a9a:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2a9c:	fe7fe0ef          	jal	ra,1a82 <enable_thread_io_buffer>
    2aa0:	65a2                	ld	a1,8(sp)
    2aa2:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2aa4:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2aa8:	00000073          	ecall
}
    2aac:	60e2                	ld	ra,24(sp)
    2aae:	2501                	sext.w	a0,a0
    2ab0:	6105                	addi	sp,sp,32
    2ab2:	8082                	ret

0000000000002ab4 <gettid>:
	register long a7 __asm__("a7") = n;
    2ab4:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2ab8:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2abc:	2501                	sext.w	a0,a0
    2abe:	8082                	ret

0000000000002ac0 <waittid>:

int waittid(int tid)
{
    2ac0:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2ac2:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2ac6:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2aca:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2acc:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2ace:	00e51e63          	bne	a0,a4,2aea <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2ad2:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2ad6:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2ada:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2ade:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2ae0:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2ae4:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2ae6:	fee506e3          	beq	a0,a4,2ad2 <waittid+0x12>
	}
	return ret;
}
    2aea:	8082                	ret

0000000000002aec <mutex_create>:
	register long a7 __asm__("a7") = n;
    2aec:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2af0:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2af2:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2af6:	2501                	sext.w	a0,a0
    2af8:	8082                	ret

0000000000002afa <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2afa:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2afe:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2b00:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2b04:	2501                	sext.w	a0,a0
    2b06:	8082                	ret

0000000000002b08 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2b08:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2b0c:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2b10:	2501                	sext.w	a0,a0
    2b12:	8082                	ret

0000000000002b14 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2b14:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2b18:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2b1c:	2501                	sext.w	a0,a0
    2b1e:	8082                	ret

0000000000002b20 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2b20:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2b24:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2b28:	2501                	sext.w	a0,a0
    2b2a:	8082                	ret

0000000000002b2c <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2b2c:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2b30:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2b34:	2501                	sext.w	a0,a0
    2b36:	8082                	ret

0000000000002b38 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2b38:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2b3c:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2b40:	2501                	sext.w	a0,a0
    2b42:	8082                	ret

0000000000002b44 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2b44:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2b48:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2b4c:	2501                	sext.w	a0,a0
    2b4e:	8082                	ret

0000000000002b50 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2b50:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2b54:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2b58:	2501                	sext.w	a0,a0
    2b5a:	8082                	ret

0000000000002b5c <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2b5c:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2b60:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2b64:	2501                	sext.w	a0,a0
    2b66:	8082                	ret

0000000000002b68 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2b68:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2b6c:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2b70:	2501                	sext.w	a0,a0
    2b72:	8082                	ret
