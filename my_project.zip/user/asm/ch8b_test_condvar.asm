
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_test_condvar:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a6ed                	j	13ea <__start_main>

0000000000001002 <first>:
int a = 0;
int condvar_id;
int mutex_id;

void first()
{
    1002:	1101                	addi	sp,sp,-32
	sleep(10);
    1004:	4529                	li	a0,10
{
    1006:	ec06                	sd	ra,24(sp)
    1008:	e822                	sd	s0,16(sp)
    100a:	e426                	sd	s1,8(sp)
    100c:	e04a                	sd	s2,0(sp)
	sleep(10);
    100e:	00b010ef          	jal	ra,2818 <sleep>
	puts("First work, Change A --> 1 and wakeup Second");
    1012:	00002517          	auipc	a0,0x2
    1016:	a3e50513          	addi	a0,a0,-1474 # 2a50 <enable_deadlock_detect+0xc>
    101a:	441000ef          	jal	ra,1c5a <puts>
	assert_eq(mutex_lock(mutex_id), 0);
    101e:	00002417          	auipc	s0,0x2
    1022:	d4240413          	addi	s0,s0,-702 # 2d60 <mutex_id>
    1026:	4008                	lw	a0,0(s0)
    1028:	1bd010ef          	jal	ra,29e4 <mutex_lock>
    102c:	ed1d                	bnez	a0,106a <first+0x68>
	a = 1;
    102e:	4785                	li	a5,1
	puts("First changed A --> 1");
    1030:	00002517          	auipc	a0,0x2
    1034:	ae050513          	addi	a0,a0,-1312 # 2b10 <enable_deadlock_detect+0xcc>
	a = 1;
    1038:	c05c                	sw	a5,4(s0)
	puts("First changed A --> 1");
    103a:	421000ef          	jal	ra,1c5a <puts>
	assert_eq(condvar_signal(condvar_id), 0);
    103e:	4408                	lw	a0,8(s0)
    1040:	1ed010ef          	jal	ra,2a2c <condvar_signal>
    1044:	e555                	bnez	a0,10f0 <first+0xee>
	assert_eq(mutex_unlock(mutex_id), 0);
    1046:	4008                	lw	a0,0(s0)
    1048:	1a9010ef          	jal	ra,29f0 <mutex_unlock>
    104c:	e125                	bnez	a0,10ac <first+0xaa>
	puts("First finish the job");
    104e:	00002517          	auipc	a0,0x2
    1052:	ada50513          	addi	a0,a0,-1318 # 2b28 <enable_deadlock_detect+0xe4>
    1056:	405000ef          	jal	ra,1c5a <puts>
	exit(0);
}
    105a:	6442                	ld	s0,16(sp)
    105c:	60e2                	ld	ra,24(sp)
    105e:	64a2                	ld	s1,8(sp)
    1060:	6902                	ld	s2,0(sp)
	exit(0);
    1062:	4501                	li	a0,0
}
    1064:	6105                	addi	sp,sp,32
	exit(0);
    1066:	7400106f          	j	27a6 <exit>
	assert_eq(mutex_lock(mutex_id), 0);
    106a:	70c010ef          	jal	ra,2776 <getpid>
    106e:	84aa                	mv	s1,a0
    1070:	00002517          	auipc	a0,0x2
    1074:	a1050513          	addi	a0,a0,-1520 # 2a80 <enable_deadlock_detect+0x3c>
    1078:	5d4010ef          	jal	ra,264c <basename>
    107c:	892a                	mv	s2,a0
    107e:	4008                	lw	a0,0(s0)
    1080:	165010ef          	jal	ra,29e4 <mutex_lock>
    1084:	882a                	mv	a6,a0
    1086:	4881                	li	a7,0
    1088:	00002517          	auipc	a0,0x2
    108c:	a5050513          	addi	a0,a0,-1456 # 2ad8 <enable_deadlock_detect+0x94>
    1090:	47bd                	li	a5,15
    1092:	874a                	mv	a4,s2
    1094:	86a6                	mv	a3,s1
    1096:	00002617          	auipc	a2,0x2
    109a:	a3a60613          	addi	a2,a2,-1478 # 2ad0 <enable_deadlock_detect+0x8c>
    109e:	45fd                	li	a1,31
    10a0:	4a4000ef          	jal	ra,1544 <printf>
    10a4:	557d                	li	a0,-1
    10a6:	700010ef          	jal	ra,27a6 <exit>
    10aa:	b751                	j	102e <first+0x2c>
	assert_eq(mutex_unlock(mutex_id), 0);
    10ac:	6ca010ef          	jal	ra,2776 <getpid>
    10b0:	84aa                	mv	s1,a0
    10b2:	00002517          	auipc	a0,0x2
    10b6:	9ce50513          	addi	a0,a0,-1586 # 2a80 <enable_deadlock_detect+0x3c>
    10ba:	592010ef          	jal	ra,264c <basename>
    10be:	872a                	mv	a4,a0
    10c0:	4008                	lw	a0,0(s0)
    10c2:	843a                	mv	s0,a4
    10c4:	12d010ef          	jal	ra,29f0 <mutex_unlock>
    10c8:	882a                	mv	a6,a0
    10ca:	4881                	li	a7,0
    10cc:	00002517          	auipc	a0,0x2
    10d0:	a0c50513          	addi	a0,a0,-1524 # 2ad8 <enable_deadlock_detect+0x94>
    10d4:	47cd                	li	a5,19
    10d6:	8722                	mv	a4,s0
    10d8:	86a6                	mv	a3,s1
    10da:	00002617          	auipc	a2,0x2
    10de:	9f660613          	addi	a2,a2,-1546 # 2ad0 <enable_deadlock_detect+0x8c>
    10e2:	45fd                	li	a1,31
    10e4:	460000ef          	jal	ra,1544 <printf>
    10e8:	557d                	li	a0,-1
    10ea:	6bc010ef          	jal	ra,27a6 <exit>
    10ee:	b785                	j	104e <first+0x4c>
	assert_eq(condvar_signal(condvar_id), 0);
    10f0:	686010ef          	jal	ra,2776 <getpid>
    10f4:	84aa                	mv	s1,a0
    10f6:	00002517          	auipc	a0,0x2
    10fa:	98a50513          	addi	a0,a0,-1654 # 2a80 <enable_deadlock_detect+0x3c>
    10fe:	54e010ef          	jal	ra,264c <basename>
    1102:	892a                	mv	s2,a0
    1104:	4408                	lw	a0,8(s0)
    1106:	127010ef          	jal	ra,2a2c <condvar_signal>
    110a:	882a                	mv	a6,a0
    110c:	4881                	li	a7,0
    110e:	00002517          	auipc	a0,0x2
    1112:	9ca50513          	addi	a0,a0,-1590 # 2ad8 <enable_deadlock_detect+0x94>
    1116:	47c9                	li	a5,18
    1118:	874a                	mv	a4,s2
    111a:	86a6                	mv	a3,s1
    111c:	00002617          	auipc	a2,0x2
    1120:	9b460613          	addi	a2,a2,-1612 # 2ad0 <enable_deadlock_detect+0x8c>
    1124:	45fd                	li	a1,31
    1126:	41e000ef          	jal	ra,1544 <printf>
    112a:	557d                	li	a0,-1
    112c:	67a010ef          	jal	ra,27a6 <exit>
    1130:	bf19                	j	1046 <first+0x44>

0000000000001132 <second>:

void second()
{
    1132:	7139                	addi	sp,sp,-64
	puts("Second want to continue,but need to wait A=1");
    1134:	00002517          	auipc	a0,0x2
    1138:	a0c50513          	addi	a0,a0,-1524 # 2b40 <enable_deadlock_detect+0xfc>
{
    113c:	f822                	sd	s0,48(sp)
    113e:	fc06                	sd	ra,56(sp)
    1140:	f426                	sd	s1,40(sp)
    1142:	f04a                	sd	s2,32(sp)
    1144:	ec4e                	sd	s3,24(sp)
    1146:	e852                	sd	s4,16(sp)
    1148:	e456                	sd	s5,8(sp)
    114a:	e05a                	sd	s6,0(sp)
	assert_eq(mutex_lock(mutex_id), 0);
    114c:	00002417          	auipc	s0,0x2
    1150:	c1440413          	addi	s0,s0,-1004 # 2d60 <mutex_id>
	puts("Second want to continue,but need to wait A=1");
    1154:	307000ef          	jal	ra,1c5a <puts>
	assert_eq(mutex_lock(mutex_id), 0);
    1158:	4008                	lw	a0,0(s0)
    115a:	08b010ef          	jal	ra,29e4 <mutex_lock>
    115e:	ed49                	bnez	a0,11f8 <second+0xc6>
	while (a == 0) {
		printf("Second : A is %d\n", a);
    1160:	00002497          	auipc	s1,0x2
    1164:	a1048493          	addi	s1,s1,-1520 # 2b70 <enable_deadlock_detect+0x12c>
		assert_eq(condvar_wait(condvar_id, mutex_id), 0);
    1168:	00002b17          	auipc	s6,0x2
    116c:	918b0b13          	addi	s6,s6,-1768 # 2a80 <enable_deadlock_detect+0x3c>
    1170:	00002a97          	auipc	s5,0x2
    1174:	960a8a93          	addi	s5,s5,-1696 # 2ad0 <enable_deadlock_detect+0x8c>
    1178:	00002a17          	auipc	s4,0x2
    117c:	960a0a13          	addi	s4,s4,-1696 # 2ad8 <enable_deadlock_detect+0x94>
    1180:	a801                	j	1190 <second+0x5e>
		printf("Second : A is %d\n", a);
    1182:	3c2000ef          	jal	ra,1544 <printf>
		assert_eq(condvar_wait(condvar_id, mutex_id), 0);
    1186:	400c                	lw	a1,0(s0)
    1188:	4408                	lw	a0,8(s0)
    118a:	0af010ef          	jal	ra,2a38 <condvar_wait>
    118e:	ed05                	bnez	a0,11c6 <second+0x94>
	while (a == 0) {
    1190:	405c                	lw	a5,4(s0)
		printf("Second : A is %d\n", a);
    1192:	4581                	li	a1,0
    1194:	8526                	mv	a0,s1
	while (a == 0) {
    1196:	d7f5                	beqz	a5,1182 <second+0x50>
	}
	assert_eq(mutex_unlock(mutex_id), 0);
    1198:	4008                	lw	a0,0(s0)
    119a:	057010ef          	jal	ra,29f0 <mutex_unlock>
    119e:	ed51                	bnez	a0,123a <second+0x108>
	printf("A is %d, Second can work now\n", a);
    11a0:	404c                	lw	a1,4(s0)
    11a2:	00002517          	auipc	a0,0x2
    11a6:	9e650513          	addi	a0,a0,-1562 # 2b88 <enable_deadlock_detect+0x144>
    11aa:	39a000ef          	jal	ra,1544 <printf>
	exit(0);
}
    11ae:	7442                	ld	s0,48(sp)
    11b0:	70e2                	ld	ra,56(sp)
    11b2:	74a2                	ld	s1,40(sp)
    11b4:	7902                	ld	s2,32(sp)
    11b6:	69e2                	ld	s3,24(sp)
    11b8:	6a42                	ld	s4,16(sp)
    11ba:	6aa2                	ld	s5,8(sp)
    11bc:	6b02                	ld	s6,0(sp)
	exit(0);
    11be:	4501                	li	a0,0
}
    11c0:	6121                	addi	sp,sp,64
	exit(0);
    11c2:	5e40106f          	j	27a6 <exit>
		assert_eq(condvar_wait(condvar_id, mutex_id), 0);
    11c6:	5b0010ef          	jal	ra,2776 <getpid>
    11ca:	892a                	mv	s2,a0
    11cc:	855a                	mv	a0,s6
    11ce:	47e010ef          	jal	ra,264c <basename>
    11d2:	400c                	lw	a1,0(s0)
    11d4:	89aa                	mv	s3,a0
    11d6:	4408                	lw	a0,8(s0)
    11d8:	061010ef          	jal	ra,2a38 <condvar_wait>
    11dc:	882a                	mv	a6,a0
    11de:	4881                	li	a7,0
    11e0:	8552                	mv	a0,s4
    11e2:	47f9                	li	a5,30
    11e4:	874e                	mv	a4,s3
    11e6:	86ca                	mv	a3,s2
    11e8:	8656                	mv	a2,s5
    11ea:	45fd                	li	a1,31
    11ec:	358000ef          	jal	ra,1544 <printf>
    11f0:	557d                	li	a0,-1
    11f2:	5b4010ef          	jal	ra,27a6 <exit>
    11f6:	bf69                	j	1190 <second+0x5e>
	assert_eq(mutex_lock(mutex_id), 0);
    11f8:	57e010ef          	jal	ra,2776 <getpid>
    11fc:	84aa                	mv	s1,a0
    11fe:	00002517          	auipc	a0,0x2
    1202:	88250513          	addi	a0,a0,-1918 # 2a80 <enable_deadlock_detect+0x3c>
    1206:	446010ef          	jal	ra,264c <basename>
    120a:	892a                	mv	s2,a0
    120c:	4008                	lw	a0,0(s0)
    120e:	7d6010ef          	jal	ra,29e4 <mutex_lock>
    1212:	882a                	mv	a6,a0
    1214:	4881                	li	a7,0
    1216:	00002517          	auipc	a0,0x2
    121a:	8c250513          	addi	a0,a0,-1854 # 2ad8 <enable_deadlock_detect+0x94>
    121e:	47ed                	li	a5,27
    1220:	874a                	mv	a4,s2
    1222:	86a6                	mv	a3,s1
    1224:	00002617          	auipc	a2,0x2
    1228:	8ac60613          	addi	a2,a2,-1876 # 2ad0 <enable_deadlock_detect+0x8c>
    122c:	45fd                	li	a1,31
    122e:	316000ef          	jal	ra,1544 <printf>
    1232:	557d                	li	a0,-1
    1234:	572010ef          	jal	ra,27a6 <exit>
    1238:	b725                	j	1160 <second+0x2e>
	assert_eq(mutex_unlock(mutex_id), 0);
    123a:	53c010ef          	jal	ra,2776 <getpid>
    123e:	84aa                	mv	s1,a0
    1240:	00002517          	auipc	a0,0x2
    1244:	84050513          	addi	a0,a0,-1984 # 2a80 <enable_deadlock_detect+0x3c>
    1248:	404010ef          	jal	ra,264c <basename>
    124c:	892a                	mv	s2,a0
    124e:	4008                	lw	a0,0(s0)
    1250:	7a0010ef          	jal	ra,29f0 <mutex_unlock>
    1254:	882a                	mv	a6,a0
    1256:	4881                	li	a7,0
    1258:	00002517          	auipc	a0,0x2
    125c:	88050513          	addi	a0,a0,-1920 # 2ad8 <enable_deadlock_detect+0x94>
    1260:	02000793          	li	a5,32
    1264:	874a                	mv	a4,s2
    1266:	86a6                	mv	a3,s1
    1268:	00002617          	auipc	a2,0x2
    126c:	86860613          	addi	a2,a2,-1944 # 2ad0 <enable_deadlock_detect+0x8c>
    1270:	45fd                	li	a1,31
    1272:	2d2000ef          	jal	ra,1544 <printf>
    1276:	557d                	li	a0,-1
    1278:	52e010ef          	jal	ra,27a6 <exit>
    127c:	b715                	j	11a0 <second+0x6e>

000000000000127e <main>:

int main()
{
    127e:	1101                	addi	sp,sp,-32
    1280:	e822                	sd	s0,16(sp)
    1282:	ec06                	sd	ra,24(sp)
    1284:	e426                	sd	s1,8(sp)
    1286:	e04a                	sd	s2,0(sp)
	assert((condvar_id = condvar_create()) >= 0);
    1288:	00002417          	auipc	s0,0x2
    128c:	ad840413          	addi	s0,s0,-1320 # 2d60 <mutex_id>
    1290:	790010ef          	jal	ra,2a20 <condvar_create>
    1294:	c408                	sw	a0,8(s0)
    1296:	10054e63          	bltz	a0,13b2 <main+0x134>
	assert((mutex_id = mutex_blocking_create()) >= 0);
    129a:	73c010ef          	jal	ra,29d6 <mutex_blocking_create>
    129e:	c008                	sw	a0,0(s0)
    12a0:	0c054d63          	bltz	a0,137a <main+0xfc>
	int t1 = thread_create(first, 0);
    12a4:	4581                	li	a1,0
    12a6:	00000517          	auipc	a0,0x0
    12aa:	d5c50513          	addi	a0,a0,-676 # 1002 <first>
    12ae:	6aa010ef          	jal	ra,2958 <thread_create>
    12b2:	84aa                	mv	s1,a0
	int t2 = thread_create(second, 0);
    12b4:	4581                	li	a1,0
    12b6:	00000517          	auipc	a0,0x0
    12ba:	e7c50513          	addi	a0,a0,-388 # 1132 <second>
    12be:	69a010ef          	jal	ra,2958 <thread_create>
    12c2:	842a                	mv	s0,a0
	assert_eq(waittid(t1), 0);
    12c4:	8526                	mv	a0,s1
    12c6:	6d6010ef          	jal	ra,299c <waittid>
    12ca:	e115                	bnez	a0,12ee <main+0x70>
	assert_eq(waittid(t2), 0);
    12cc:	8522                	mv	a0,s0
    12ce:	6ce010ef          	jal	ra,299c <waittid>
    12d2:	e12d                	bnez	a0,1334 <main+0xb6>
	puts("test_condvar passed!");
    12d4:	00002517          	auipc	a0,0x2
    12d8:	97c50513          	addi	a0,a0,-1668 # 2c50 <enable_deadlock_detect+0x20c>
    12dc:	17f000ef          	jal	ra,1c5a <puts>
	return 0;
}
    12e0:	60e2                	ld	ra,24(sp)
    12e2:	6442                	ld	s0,16(sp)
    12e4:	64a2                	ld	s1,8(sp)
    12e6:	6902                	ld	s2,0(sp)
    12e8:	4501                	li	a0,0
    12ea:	6105                	addi	sp,sp,32
    12ec:	8082                	ret
	assert_eq(waittid(t1), 0);
    12ee:	488010ef          	jal	ra,2776 <getpid>
    12f2:	892a                	mv	s2,a0
    12f4:	00001517          	auipc	a0,0x1
    12f8:	78c50513          	addi	a0,a0,1932 # 2a80 <enable_deadlock_detect+0x3c>
    12fc:	350010ef          	jal	ra,264c <basename>
    1300:	872a                	mv	a4,a0
    1302:	8526                	mv	a0,s1
    1304:	84ba                	mv	s1,a4
    1306:	696010ef          	jal	ra,299c <waittid>
    130a:	882a                	mv	a6,a0
    130c:	4881                	li	a7,0
    130e:	00001517          	auipc	a0,0x1
    1312:	7ca50513          	addi	a0,a0,1994 # 2ad8 <enable_deadlock_detect+0x94>
    1316:	02b00793          	li	a5,43
    131a:	8726                	mv	a4,s1
    131c:	86ca                	mv	a3,s2
    131e:	00001617          	auipc	a2,0x1
    1322:	7b260613          	addi	a2,a2,1970 # 2ad0 <enable_deadlock_detect+0x8c>
    1326:	45fd                	li	a1,31
    1328:	21c000ef          	jal	ra,1544 <printf>
    132c:	557d                	li	a0,-1
    132e:	478010ef          	jal	ra,27a6 <exit>
    1332:	bf69                	j	12cc <main+0x4e>
	assert_eq(waittid(t2), 0);
    1334:	442010ef          	jal	ra,2776 <getpid>
    1338:	84aa                	mv	s1,a0
    133a:	00001517          	auipc	a0,0x1
    133e:	74650513          	addi	a0,a0,1862 # 2a80 <enable_deadlock_detect+0x3c>
    1342:	30a010ef          	jal	ra,264c <basename>
    1346:	872a                	mv	a4,a0
    1348:	8522                	mv	a0,s0
    134a:	843a                	mv	s0,a4
    134c:	650010ef          	jal	ra,299c <waittid>
    1350:	882a                	mv	a6,a0
    1352:	4881                	li	a7,0
    1354:	00001517          	auipc	a0,0x1
    1358:	78450513          	addi	a0,a0,1924 # 2ad8 <enable_deadlock_detect+0x94>
    135c:	02c00793          	li	a5,44
    1360:	8722                	mv	a4,s0
    1362:	86a6                	mv	a3,s1
    1364:	00001617          	auipc	a2,0x1
    1368:	76c60613          	addi	a2,a2,1900 # 2ad0 <enable_deadlock_detect+0x8c>
    136c:	45fd                	li	a1,31
    136e:	1d6000ef          	jal	ra,1544 <printf>
    1372:	557d                	li	a0,-1
    1374:	432010ef          	jal	ra,27a6 <exit>
    1378:	bfb1                	j	12d4 <main+0x56>
	assert((mutex_id = mutex_blocking_create()) >= 0);
    137a:	3fc010ef          	jal	ra,2776 <getpid>
    137e:	842a                	mv	s0,a0
    1380:	00001517          	auipc	a0,0x1
    1384:	70050513          	addi	a0,a0,1792 # 2a80 <enable_deadlock_detect+0x3c>
    1388:	2c4010ef          	jal	ra,264c <basename>
    138c:	872a                	mv	a4,a0
    138e:	02800793          	li	a5,40
    1392:	00002517          	auipc	a0,0x2
    1396:	86650513          	addi	a0,a0,-1946 # 2bf8 <enable_deadlock_detect+0x1b4>
    139a:	86a2                	mv	a3,s0
    139c:	00001617          	auipc	a2,0x1
    13a0:	73460613          	addi	a2,a2,1844 # 2ad0 <enable_deadlock_detect+0x8c>
    13a4:	45fd                	li	a1,31
    13a6:	19e000ef          	jal	ra,1544 <printf>
    13aa:	557d                	li	a0,-1
    13ac:	3fa010ef          	jal	ra,27a6 <exit>
    13b0:	bdd5                	j	12a4 <main+0x26>
	assert((condvar_id = condvar_create()) >= 0);
    13b2:	3c4010ef          	jal	ra,2776 <getpid>
    13b6:	84aa                	mv	s1,a0
    13b8:	00001517          	auipc	a0,0x1
    13bc:	6c850513          	addi	a0,a0,1736 # 2a80 <enable_deadlock_detect+0x3c>
    13c0:	28c010ef          	jal	ra,264c <basename>
    13c4:	872a                	mv	a4,a0
    13c6:	02700793          	li	a5,39
    13ca:	00001517          	auipc	a0,0x1
    13ce:	7de50513          	addi	a0,a0,2014 # 2ba8 <enable_deadlock_detect+0x164>
    13d2:	86a6                	mv	a3,s1
    13d4:	00001617          	auipc	a2,0x1
    13d8:	6fc60613          	addi	a2,a2,1788 # 2ad0 <enable_deadlock_detect+0x8c>
    13dc:	45fd                	li	a1,31
    13de:	166000ef          	jal	ra,1544 <printf>
    13e2:	557d                	li	a0,-1
    13e4:	3c2010ef          	jal	ra,27a6 <exit>
    13e8:	bd4d                	j	129a <main+0x1c>

00000000000013ea <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    13ea:	1141                	addi	sp,sp,-16
    13ec:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    13ee:	e91ff0ef          	jal	ra,127e <main>
    13f2:	3b4010ef          	jal	ra,27a6 <exit>
	return 0;
    13f6:	60a2                	ld	ra,8(sp)
    13f8:	4501                	li	a0,0
    13fa:	0141                	addi	sp,sp,16
    13fc:	8082                	ret

00000000000013fe <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    13fe:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1400:	4605                	li	a2,1
    1402:	00f10593          	addi	a1,sp,15
    1406:	4501                	li	a0,0
{
    1408:	ec06                	sd	ra,24(sp)
	char byte = 0;
    140a:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    140e:	354010ef          	jal	ra,2762 <read>
    1412:	4785                	li	a5,1
    1414:	00f51763          	bne	a0,a5,1422 <getchar+0x24>
		return byte;
    1418:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    141c:	60e2                	ld	ra,24(sp)
    141e:	6105                	addi	sp,sp,32
    1420:	8082                	ret
		return EOF;
    1422:	557d                	li	a0,-1
    1424:	bfe5                	j	141c <getchar+0x1e>

0000000000001426 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1426:	00002517          	auipc	a0,0x2
    142a:	94a52503          	lw	a0,-1718(a0) # 2d70 <buffer_len>
    142e:	e111                	bnez	a0,1432 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1430:	8082                	ret
{
    1432:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1434:	862a                	mv	a2,a0
    1436:	00002597          	auipc	a1,0x2
    143a:	94258593          	addi	a1,a1,-1726 # 2d78 <buffer>
    143e:	4505                	li	a0,1
{
    1440:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1442:	32a010ef          	jal	ra,276c <write>
}
    1446:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1448:	2501                	sext.w	a0,a0
}
    144a:	0141                	addi	sp,sp,16
    144c:	8082                	ret

000000000000144e <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    144e:	00002797          	auipc	a5,0x2
    1452:	9207a123          	sw	zero,-1758(a5) # 2d70 <buffer_len>
}
    1456:	8082                	ret

0000000000001458 <__fflush>:
	if (buffer_len == 0)
    1458:	00002517          	auipc	a0,0x2
    145c:	91852503          	lw	a0,-1768(a0) # 2d70 <buffer_len>
    1460:	e511                	bnez	a0,146c <__fflush+0x14>
	buffer_len = 0;
    1462:	00002797          	auipc	a5,0x2
    1466:	9007a723          	sw	zero,-1778(a5) # 2d70 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    146a:	8082                	ret
{
    146c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    146e:	862a                	mv	a2,a0
    1470:	00002597          	auipc	a1,0x2
    1474:	90858593          	addi	a1,a1,-1784 # 2d78 <buffer>
    1478:	4505                	li	a0,1
{
    147a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    147c:	2f0010ef          	jal	ra,276c <write>
	return r >= 0 ? 0 : r;
    1480:	0005079b          	sext.w	a5,a0
}
    1484:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1486:	0017a793          	slti	a5,a5,1
    148a:	40f007bb          	negw	a5,a5
    148e:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1490:	00002797          	auipc	a5,0x2
    1494:	8e07a023          	sw	zero,-1824(a5) # 2d70 <buffer_len>
	return r >= 0 ? 0 : r;
    1498:	2501                	sext.w	a0,a0
}
    149a:	0141                	addi	sp,sp,16
    149c:	8082                	ret

000000000000149e <fflush>:

int fflush(int fd)
{
    149e:	1101                	addi	sp,sp,-32
    14a0:	e822                	sd	s0,16(sp)
    14a2:	ec06                	sd	ra,24(sp)
    14a4:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    14a6:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    14a8:	4401                	li	s0,0
	if (fd == 1) {
    14aa:	00e50863          	beq	a0,a4,14ba <fflush+0x1c>
}
    14ae:	60e2                	ld	ra,24(sp)
    14b0:	8522                	mv	a0,s0
    14b2:	6442                	ld	s0,16(sp)
    14b4:	64a2                	ld	s1,8(sp)
    14b6:	6105                	addi	sp,sp,32
    14b8:	8082                	ret
		if (buffer_lock_enabled == 1) {
    14ba:	00002497          	auipc	s1,0x2
    14be:	8b648493          	addi	s1,s1,-1866 # 2d70 <buffer_len>
    14c2:	1084a703          	lw	a4,264(s1)
    14c6:	02a70e63          	beq	a4,a0,1502 <fflush+0x64>
	if (buffer_len == 0)
    14ca:	4080                	lw	s0,0(s1)
    14cc:	c00d                	beqz	s0,14ee <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    14ce:	8622                	mv	a2,s0
    14d0:	00002597          	auipc	a1,0x2
    14d4:	8a858593          	addi	a1,a1,-1880 # 2d78 <buffer>
    14d8:	294010ef          	jal	ra,276c <write>
	return r >= 0 ? 0 : r;
    14dc:	0005079b          	sext.w	a5,a0
    14e0:	0017a793          	slti	a5,a5,1
    14e4:	40f007bb          	negw	a5,a5
    14e8:	8d7d                	and	a0,a0,a5
    14ea:	0005041b          	sext.w	s0,a0
}
    14ee:	60e2                	ld	ra,24(sp)
    14f0:	8522                	mv	a0,s0
    14f2:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    14f4:	00002797          	auipc	a5,0x2
    14f8:	8607ae23          	sw	zero,-1924(a5) # 2d70 <buffer_len>
}
    14fc:	64a2                	ld	s1,8(sp)
    14fe:	6105                	addi	sp,sp,32
    1500:	8082                	ret
			mutex_lock(buffer_lock);
    1502:	10c4a503          	lw	a0,268(s1)
    1506:	4de010ef          	jal	ra,29e4 <mutex_lock>
	if (buffer_len == 0)
    150a:	4080                	lw	s0,0(s1)
    150c:	e811                	bnez	s0,1520 <fflush+0x82>
			mutex_unlock(buffer_lock);
    150e:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1512:	00002797          	auipc	a5,0x2
    1516:	8407af23          	sw	zero,-1954(a5) # 2d70 <buffer_len>
			mutex_unlock(buffer_lock);
    151a:	4d6010ef          	jal	ra,29f0 <mutex_unlock>
    151e:	bf41                	j	14ae <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1520:	8622                	mv	a2,s0
    1522:	00002597          	auipc	a1,0x2
    1526:	85658593          	addi	a1,a1,-1962 # 2d78 <buffer>
    152a:	4505                	li	a0,1
    152c:	240010ef          	jal	ra,276c <write>
	return r >= 0 ? 0 : r;
    1530:	0005079b          	sext.w	a5,a0
    1534:	0017a793          	slti	a5,a5,1
    1538:	40f007bb          	negw	a5,a5
    153c:	8d7d                	and	a0,a0,a5
    153e:	0005041b          	sext.w	s0,a0
	return r;
    1542:	b7f1                	j	150e <fflush+0x70>

0000000000001544 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1544:	7131                	addi	sp,sp,-192
    1546:	e0da                	sd	s6,64(sp)
    1548:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    154a:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    154c:	013c                	addi	a5,sp,136
{
    154e:	f0ca                	sd	s2,96(sp)
    1550:	ecce                	sd	s3,88(sp)
    1552:	e8d2                	sd	s4,80(sp)
    1554:	e4d6                	sd	s5,72(sp)
    1556:	fc86                	sd	ra,120(sp)
    1558:	f8a2                	sd	s0,112(sp)
    155a:	f4a6                	sd	s1,104(sp)
    155c:	89aa                	mv	s3,a0
    155e:	e52e                	sd	a1,136(sp)
    1560:	e932                	sd	a2,144(sp)
    1562:	ed36                	sd	a3,152(sp)
    1564:	f13a                	sd	a4,160(sp)
    1566:	f942                	sd	a6,176(sp)
    1568:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    156a:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    156c:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1570:	00002a17          	auipc	s4,0x2
    1574:	800a0a13          	addi	s4,s4,-2048 # 2d70 <buffer_len>
    1578:	4a85                	li	s5,1
	buf[i++] = '0';
    157a:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    157e:	0009c783          	lbu	a5,0(s3)
    1582:	18078663          	beqz	a5,170e <printf+0x1ca>
    1586:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1588:	19278d63          	beq	a5,s2,1722 <printf+0x1de>
    158c:	0015c783          	lbu	a5,1(a1)
    1590:	0585                	addi	a1,a1,1
    1592:	fbfd                	bnez	a5,1588 <printf+0x44>
    1594:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1596:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    159a:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    159e:	1b578863          	beq	a5,s5,174e <printf+0x20a>
		len = out_unlocked(s, l);
    15a2:	85a2                	mv	a1,s0
    15a4:	854e                	mv	a0,s3
    15a6:	42a000ef          	jal	ra,19d0 <out_unlocked>
		out(f, a, l);
		if (l)
    15aa:	1c041063          	bnez	s0,176a <printf+0x226>
			continue;
		if (s[1] == 0)
    15ae:	0014c783          	lbu	a5,1(s1)
    15b2:	14078e63          	beqz	a5,170e <printf+0x1ca>
			break;
		switch (s[1]) {
    15b6:	07300713          	li	a4,115
    15ba:	1ce78863          	beq	a5,a4,178a <printf+0x246>
    15be:	1af76863          	bltu	a4,a5,176e <printf+0x22a>
    15c2:	06400713          	li	a4,100
    15c6:	22e78063          	beq	a5,a4,17e6 <printf+0x2a2>
    15ca:	07000713          	li	a4,112
    15ce:	1ee79563          	bne	a5,a4,17b8 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    15d2:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15d4:	00002797          	auipc	a5,0x2
    15d8:	8ac78793          	addi	a5,a5,-1876 # 2e80 <digits>
	buf[i++] = '0';
    15dc:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    15e0:	6298                	ld	a4,0(a3)
    15e2:	06a1                	addi	a3,a3,8
    15e4:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15e6:	00471393          	slli	t2,a4,0x4
    15ea:	00871293          	slli	t0,a4,0x8
    15ee:	00c71f93          	slli	t6,a4,0xc
    15f2:	01071f13          	slli	t5,a4,0x10
    15f6:	01471e93          	slli	t4,a4,0x14
    15fa:	01871e13          	slli	t3,a4,0x18
    15fe:	01c71893          	slli	a7,a4,0x1c
    1602:	02471813          	slli	a6,a4,0x24
    1606:	02871513          	slli	a0,a4,0x28
    160a:	02c71593          	slli	a1,a4,0x2c
    160e:	03071613          	slli	a2,a4,0x30
    1612:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1616:	03c75413          	srli	s0,a4,0x3c
    161a:	01c7531b          	srliw	t1,a4,0x1c
    161e:	03c3d393          	srli	t2,t2,0x3c
    1622:	03c2d293          	srli	t0,t0,0x3c
    1626:	03cfdf93          	srli	t6,t6,0x3c
    162a:	03cf5f13          	srli	t5,t5,0x3c
    162e:	03cede93          	srli	t4,t4,0x3c
    1632:	03ce5e13          	srli	t3,t3,0x3c
    1636:	03c8d893          	srli	a7,a7,0x3c
    163a:	03c85813          	srli	a6,a6,0x3c
    163e:	9171                	srli	a0,a0,0x3c
    1640:	91f1                	srli	a1,a1,0x3c
    1642:	9271                	srli	a2,a2,0x3c
    1644:	92f1                	srli	a3,a3,0x3c
    1646:	95be                	add	a1,a1,a5
    1648:	963e                	add	a2,a2,a5
    164a:	96be                	add	a3,a3,a5
    164c:	943e                	add	s0,s0,a5
    164e:	93be                	add	t2,t2,a5
    1650:	92be                	add	t0,t0,a5
    1652:	9fbe                	add	t6,t6,a5
    1654:	9f3e                	add	t5,t5,a5
    1656:	9ebe                	add	t4,t4,a5
    1658:	9e3e                	add	t3,t3,a5
    165a:	98be                	add	a7,a7,a5
    165c:	933e                	add	t1,t1,a5
    165e:	983e                	add	a6,a6,a5
    1660:	953e                	add	a0,a0,a5
    1662:	0005c983          	lbu	s3,0(a1)
    1666:	00044403          	lbu	s0,0(s0)
    166a:	00064583          	lbu	a1,0(a2)
    166e:	0003c383          	lbu	t2,0(t2)
    1672:	0006c603          	lbu	a2,0(a3)
    1676:	0002c283          	lbu	t0,0(t0)
    167a:	000fcf83          	lbu	t6,0(t6)
    167e:	000f4f03          	lbu	t5,0(t5)
    1682:	000ece83          	lbu	t4,0(t4)
    1686:	000e4e03          	lbu	t3,0(t3)
    168a:	0008c883          	lbu	a7,0(a7)
    168e:	00034303          	lbu	t1,0(t1)
    1692:	00084803          	lbu	a6,0(a6)
    1696:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    169a:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    169e:	92f1                	srli	a3,a3,0x3c
    16a0:	8b3d                	andi	a4,a4,15
    16a2:	96be                	add	a3,a3,a5
    16a4:	97ba                	add	a5,a5,a4
    16a6:	00810d23          	sb	s0,26(sp)
    16aa:	00710da3          	sb	t2,27(sp)
    16ae:	00510e23          	sb	t0,28(sp)
    16b2:	01f10ea3          	sb	t6,29(sp)
    16b6:	01e10f23          	sb	t5,30(sp)
    16ba:	01d10fa3          	sb	t4,31(sp)
    16be:	03c10023          	sb	t3,32(sp)
    16c2:	031100a3          	sb	a7,33(sp)
    16c6:	02610123          	sb	t1,34(sp)
    16ca:	030101a3          	sb	a6,35(sp)
    16ce:	02a10223          	sb	a0,36(sp)
    16d2:	033102a3          	sb	s3,37(sp)
    16d6:	02b10323          	sb	a1,38(sp)
    16da:	02c103a3          	sb	a2,39(sp)
    16de:	0006c683          	lbu	a3,0(a3)
    16e2:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    16e6:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    16ea:	02d10423          	sb	a3,40(sp)
    16ee:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    16f2:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    16f6:	11578263          	beq	a5,s5,17fa <printf+0x2b6>
		len = out_unlocked(s, l);
    16fa:	45c9                	li	a1,18
    16fc:	0828                	addi	a0,sp,24
    16fe:	2d2000ef          	jal	ra,19d0 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1702:	00248993          	addi	s3,s1,2
		if (!*s)
    1706:	0009c783          	lbu	a5,0(s3)
    170a:	e6079ee3          	bnez	a5,1586 <printf+0x42>
	}
	va_end(ap);
    170e:	70e6                	ld	ra,120(sp)
    1710:	7446                	ld	s0,112(sp)
    1712:	74a6                	ld	s1,104(sp)
    1714:	7906                	ld	s2,96(sp)
    1716:	69e6                	ld	s3,88(sp)
    1718:	6a46                	ld	s4,80(sp)
    171a:	6aa6                	ld	s5,72(sp)
    171c:	6b06                	ld	s6,64(sp)
    171e:	6129                	addi	sp,sp,192
    1720:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1722:	0005c783          	lbu	a5,0(a1)
    1726:	84ae                	mv	s1,a1
    1728:	01278963          	beq	a5,s2,173a <printf+0x1f6>
    172c:	b5ad                	j	1596 <printf+0x52>
    172e:	0024c783          	lbu	a5,2(s1)
    1732:	0585                	addi	a1,a1,1
    1734:	0489                	addi	s1,s1,2
    1736:	e72790e3          	bne	a5,s2,1596 <printf+0x52>
    173a:	0014c783          	lbu	a5,1(s1)
    173e:	ff2788e3          	beq	a5,s2,172e <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1742:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1746:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    174a:	e5579ce3          	bne	a5,s5,15a2 <printf+0x5e>
		mutex_lock(buffer_lock);
    174e:	10ca2503          	lw	a0,268(s4)
    1752:	292010ef          	jal	ra,29e4 <mutex_lock>
		len = out_unlocked(s, l);
    1756:	85a2                	mv	a1,s0
    1758:	854e                	mv	a0,s3
    175a:	276000ef          	jal	ra,19d0 <out_unlocked>
		mutex_unlock(buffer_lock);
    175e:	10ca2503          	lw	a0,268(s4)
    1762:	28e010ef          	jal	ra,29f0 <mutex_unlock>
		if (l)
    1766:	e40404e3          	beqz	s0,15ae <printf+0x6a>
    176a:	89a6                	mv	s3,s1
    176c:	bd09                	j	157e <printf+0x3a>
		switch (s[1]) {
    176e:	07800713          	li	a4,120
    1772:	04e79363          	bne	a5,a4,17b8 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1776:	67c2                	ld	a5,16(sp)
    1778:	45c1                	li	a1,16
		s += 2;
    177a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    177e:	4388                	lw	a0,0(a5)
    1780:	07a1                	addi	a5,a5,8
    1782:	e83e                	sd	a5,16(sp)
    1784:	5f8000ef          	jal	ra,1d7c <printint.constprop.0>
		s += 2;
    1788:	bfbd                	j	1706 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    178a:	67c2                	ld	a5,16(sp)
    178c:	6380                	ld	s0,0(a5)
    178e:	07a1                	addi	a5,a5,8
    1790:	e83e                	sd	a5,16(sp)
    1792:	1c040163          	beqz	s0,1954 <printf+0x410>
			l = strnlen(a, 200);
    1796:	0c800593          	li	a1,200
    179a:	8522                	mv	a0,s0
    179c:	3f7000ef          	jal	ra,2392 <strnlen>
	if (buffer_lock_enabled == 1) {
    17a0:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    17a4:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    17a8:	19578663          	beq	a5,s5,1934 <printf+0x3f0>
		len = out_unlocked(s, l);
    17ac:	8522                	mv	a0,s0
    17ae:	222000ef          	jal	ra,19d0 <out_unlocked>
		s += 2;
    17b2:	00248993          	addi	s3,s1,2
    17b6:	bf81                	j	1706 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    17b8:	108a2783          	lw	a5,264(s4)
	char byte = c;
    17bc:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    17c0:	0f578663          	beq	a5,s5,18ac <printf+0x368>
		len = out_unlocked(s, l);
    17c4:	0828                	addi	a0,sp,24
    17c6:	316000ef          	jal	ra,1adc <out_unlocked.constprop.0>
			putchar(s[1]);
    17ca:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    17ce:	108a2783          	lw	a5,264(s4)
	char byte = c;
    17d2:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    17d6:	05578163          	beq	a5,s5,1818 <printf+0x2d4>
		len = out_unlocked(s, l);
    17da:	0828                	addi	a0,sp,24
    17dc:	300000ef          	jal	ra,1adc <out_unlocked.constprop.0>
		s += 2;
    17e0:	00248993          	addi	s3,s1,2
    17e4:	b70d                	j	1706 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    17e6:	67c2                	ld	a5,16(sp)
    17e8:	45a9                	li	a1,10
		s += 2;
    17ea:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    17ee:	4388                	lw	a0,0(a5)
    17f0:	07a1                	addi	a5,a5,8
    17f2:	e83e                	sd	a5,16(sp)
    17f4:	588000ef          	jal	ra,1d7c <printint.constprop.0>
		s += 2;
    17f8:	b739                	j	1706 <printf+0x1c2>
		mutex_lock(buffer_lock);
    17fa:	10ca2503          	lw	a0,268(s4)
		s += 2;
    17fe:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1802:	1e2010ef          	jal	ra,29e4 <mutex_lock>
		len = out_unlocked(s, l);
    1806:	45c9                	li	a1,18
    1808:	0828                	addi	a0,sp,24
    180a:	1c6000ef          	jal	ra,19d0 <out_unlocked>
		mutex_unlock(buffer_lock);
    180e:	10ca2503          	lw	a0,268(s4)
    1812:	1de010ef          	jal	ra,29f0 <mutex_unlock>
		s += 2;
    1816:	bdc5                	j	1706 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1818:	10ca2503          	lw	a0,268(s4)
    181c:	1c8010ef          	jal	ra,29e4 <mutex_lock>
		buffer[buffer_len++] = c;
    1820:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1824:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1828:	0017861b          	addiw	a2,a5,1
    182c:	97d2                	add	a5,a5,s4
    182e:	00ca2023          	sw	a2,0(s4)
    1832:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1836:	00c6cc63          	blt	a3,a2,184e <printf+0x30a>
    183a:	47a9                	li	a5,10
    183c:	06f40663          	beq	s0,a5,18a8 <printf+0x364>
		mutex_unlock(buffer_lock);
    1840:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1844:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1848:	1a8010ef          	jal	ra,29f0 <mutex_unlock>
		s += 2;
    184c:	bd6d                	j	1706 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    184e:	10000793          	li	a5,256
    1852:	00f61e63          	bne	a2,a5,186e <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1856:	00001597          	auipc	a1,0x1
    185a:	52258593          	addi	a1,a1,1314 # 2d78 <buffer>
    185e:	4505                	li	a0,1
    1860:	70d000ef          	jal	ra,276c <write>
	buffer_len = 0;
    1864:	00001797          	auipc	a5,0x1
    1868:	5007a623          	sw	zero,1292(a5) # 2d70 <buffer_len>
			if (r < 0) {
    186c:	bfd1                	j	1840 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    186e:	709000ef          	jal	ra,2776 <getpid>
    1872:	842a                	mv	s0,a0
    1874:	00001517          	auipc	a0,0x1
    1878:	3fc50513          	addi	a0,a0,1020 # 2c70 <enable_deadlock_detect+0x22c>
    187c:	5d1000ef          	jal	ra,264c <basename>
    1880:	872a                	mv	a4,a0
    1882:	00001617          	auipc	a2,0x1
    1886:	24e60613          	addi	a2,a2,590 # 2ad0 <enable_deadlock_detect+0x8c>
    188a:	05400793          	li	a5,84
    188e:	86a2                	mv	a3,s0
    1890:	45fd                	li	a1,31
    1892:	00001517          	auipc	a0,0x1
    1896:	41e50513          	addi	a0,a0,1054 # 2cb0 <enable_deadlock_detect+0x26c>
    189a:	cabff0ef          	jal	ra,1544 <printf>
    189e:	557d                	li	a0,-1
    18a0:	707000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    18a4:	000a2603          	lw	a2,0(s4)
    18a8:	de41                	beqz	a2,1840 <printf+0x2fc>
    18aa:	b775                	j	1856 <printf+0x312>
		mutex_lock(buffer_lock);
    18ac:	10ca2503          	lw	a0,268(s4)
    18b0:	134010ef          	jal	ra,29e4 <mutex_lock>
		buffer[buffer_len++] = c;
    18b4:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18bc:	0017861b          	addiw	a2,a5,1
    18c0:	97d2                	add	a5,a5,s4
    18c2:	00ca2023          	sw	a2,0(s4)
    18c6:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ca:	02c6d163          	bge	a3,a2,18ec <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    18ce:	10000793          	li	a5,256
    18d2:	02f61263          	bne	a2,a5,18f6 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    18d6:	00001597          	auipc	a1,0x1
    18da:	4a258593          	addi	a1,a1,1186 # 2d78 <buffer>
    18de:	4505                	li	a0,1
    18e0:	68d000ef          	jal	ra,276c <write>
	buffer_len = 0;
    18e4:	00001797          	auipc	a5,0x1
    18e8:	4807a623          	sw	zero,1164(a5) # 2d70 <buffer_len>
		mutex_unlock(buffer_lock);
    18ec:	10ca2503          	lw	a0,268(s4)
    18f0:	100010ef          	jal	ra,29f0 <mutex_unlock>
    18f4:	bdd9                	j	17ca <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    18f6:	681000ef          	jal	ra,2776 <getpid>
    18fa:	842a                	mv	s0,a0
    18fc:	00001517          	auipc	a0,0x1
    1900:	37450513          	addi	a0,a0,884 # 2c70 <enable_deadlock_detect+0x22c>
    1904:	549000ef          	jal	ra,264c <basename>
    1908:	872a                	mv	a4,a0
    190a:	00001617          	auipc	a2,0x1
    190e:	1c660613          	addi	a2,a2,454 # 2ad0 <enable_deadlock_detect+0x8c>
    1912:	05400793          	li	a5,84
    1916:	86a2                	mv	a3,s0
    1918:	45fd                	li	a1,31
    191a:	00001517          	auipc	a0,0x1
    191e:	39650513          	addi	a0,a0,918 # 2cb0 <enable_deadlock_detect+0x26c>
    1922:	c23ff0ef          	jal	ra,1544 <printf>
    1926:	557d                	li	a0,-1
    1928:	67f000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    192c:	000a2603          	lw	a2,0(s4)
    1930:	de55                	beqz	a2,18ec <printf+0x3a8>
    1932:	b755                	j	18d6 <printf+0x392>
		mutex_lock(buffer_lock);
    1934:	10ca2503          	lw	a0,268(s4)
    1938:	e42e                	sd	a1,8(sp)
		s += 2;
    193a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    193e:	0a6010ef          	jal	ra,29e4 <mutex_lock>
		len = out_unlocked(s, l);
    1942:	65a2                	ld	a1,8(sp)
    1944:	8522                	mv	a0,s0
    1946:	08a000ef          	jal	ra,19d0 <out_unlocked>
		mutex_unlock(buffer_lock);
    194a:	10ca2503          	lw	a0,268(s4)
    194e:	0a2010ef          	jal	ra,29f0 <mutex_unlock>
		s += 2;
    1952:	bb55                	j	1706 <printf+0x1c2>
				a = "(null)";
    1954:	00001417          	auipc	s0,0x1
    1958:	31440413          	addi	s0,s0,788 # 2c68 <enable_deadlock_detect+0x224>
    195c:	bd2d                	j	1796 <printf+0x252>

000000000000195e <enable_thread_io_buffer>:
{
    195e:	1101                	addi	sp,sp,-32
    1960:	e822                	sd	s0,16(sp)
    1962:	ec06                	sd	ra,24(sp)
    1964:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1966:	00001417          	auipc	s0,0x1
    196a:	40a40413          	addi	s0,s0,1034 # 2d70 <buffer_len>
    196e:	05a010ef          	jal	ra,29c8 <mutex_create>
    1972:	10a42623          	sw	a0,268(s0)
    1976:	00054a63          	bltz	a0,198a <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    197a:	4785                	li	a5,1
}
    197c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    197e:	10f42423          	sw	a5,264(s0)
}
    1982:	6442                	ld	s0,16(sp)
    1984:	64a2                	ld	s1,8(sp)
    1986:	6105                	addi	sp,sp,32
    1988:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    198a:	5ed000ef          	jal	ra,2776 <getpid>
    198e:	84aa                	mv	s1,a0
    1990:	00001517          	auipc	a0,0x1
    1994:	2e050513          	addi	a0,a0,736 # 2c70 <enable_deadlock_detect+0x22c>
    1998:	4b5000ef          	jal	ra,264c <basename>
    199c:	872a                	mv	a4,a0
    199e:	04800793          	li	a5,72
    19a2:	86a6                	mv	a3,s1
    19a4:	00001517          	auipc	a0,0x1
    19a8:	34c50513          	addi	a0,a0,844 # 2cf0 <enable_deadlock_detect+0x2ac>
    19ac:	00001617          	auipc	a2,0x1
    19b0:	12460613          	addi	a2,a2,292 # 2ad0 <enable_deadlock_detect+0x8c>
    19b4:	45fd                	li	a1,31
    19b6:	b8fff0ef          	jal	ra,1544 <printf>
    19ba:	557d                	li	a0,-1
    19bc:	5eb000ef          	jal	ra,27a6 <exit>
	buffer_lock_enabled = 1;
    19c0:	4785                	li	a5,1
}
    19c2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    19c4:	10f42423          	sw	a5,264(s0)
}
    19c8:	6442                	ld	s0,16(sp)
    19ca:	64a2                	ld	s1,8(sp)
    19cc:	6105                	addi	sp,sp,32
    19ce:	8082                	ret

00000000000019d0 <out_unlocked>:
{
    19d0:	7159                	addi	sp,sp,-112
    19d2:	f486                	sd	ra,104(sp)
    19d4:	f0a2                	sd	s0,96(sp)
    19d6:	eca6                	sd	s1,88(sp)
    19d8:	e8ca                	sd	s2,80(sp)
    19da:	e4ce                	sd	s3,72(sp)
    19dc:	e0d2                	sd	s4,64(sp)
    19de:	fc56                	sd	s5,56(sp)
    19e0:	f85a                	sd	s6,48(sp)
    19e2:	f45e                	sd	s7,40(sp)
    19e4:	f062                	sd	s8,32(sp)
    19e6:	ec66                	sd	s9,24(sp)
    19e8:	e86a                	sd	s10,16(sp)
    19ea:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    19ec:	0e058663          	beqz	a1,1ad8 <out_unlocked+0x108>
    19f0:	842a                	mv	s0,a0
    19f2:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    19f6:	4981                	li	s3,0
    19f8:	00001d17          	auipc	s10,0x1
    19fc:	378d0d13          	addi	s10,s10,888 # 2d70 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a00:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1a04:	00001b17          	auipc	s6,0x1
    1a08:	374b0b13          	addi	s6,s6,884 # 2d78 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1a0c:	10000a93          	li	s5,256
    1a10:	00001c97          	auipc	s9,0x1
    1a14:	260c8c93          	addi	s9,s9,608 # 2c70 <enable_deadlock_detect+0x22c>
    1a18:	00001c17          	auipc	s8,0x1
    1a1c:	0b8c0c13          	addi	s8,s8,184 # 2ad0 <enable_deadlock_detect+0x8c>
    1a20:	00001b97          	auipc	s7,0x1
    1a24:	290b8b93          	addi	s7,s7,656 # 2cb0 <enable_deadlock_detect+0x26c>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a28:	4a29                	li	s4,10
    1a2a:	a031                	j	1a36 <out_unlocked+0x66>
    1a2c:	09468863          	beq	a3,s4,1abc <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1a30:	0405                	addi	s0,s0,1
    1a32:	04848163          	beq	s1,s0,1a74 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1a36:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1a3a:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1a3e:	0017861b          	addiw	a2,a5,1
    1a42:	97ea                	add	a5,a5,s10
    1a44:	00cd2023          	sw	a2,0(s10)
    1a48:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a4c:	fec950e3          	bge	s2,a2,1a2c <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1a50:	05561263          	bne	a2,s5,1a94 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1a54:	85da                	mv	a1,s6
    1a56:	4505                	li	a0,1
    1a58:	515000ef          	jal	ra,276c <write>
    1a5c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a5e:	00001797          	auipc	a5,0x1
    1a62:	3007a923          	sw	zero,786(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1a66:	06054763          	bltz	a0,1ad4 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1a6a:	0405                	addi	s0,s0,1
			ret += r;
    1a6c:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1a70:	fc8493e3          	bne	s1,s0,1a36 <out_unlocked+0x66>
}
    1a74:	70a6                	ld	ra,104(sp)
    1a76:	7406                	ld	s0,96(sp)
    1a78:	64e6                	ld	s1,88(sp)
    1a7a:	6946                	ld	s2,80(sp)
    1a7c:	6a06                	ld	s4,64(sp)
    1a7e:	7ae2                	ld	s5,56(sp)
    1a80:	7b42                	ld	s6,48(sp)
    1a82:	7ba2                	ld	s7,40(sp)
    1a84:	7c02                	ld	s8,32(sp)
    1a86:	6ce2                	ld	s9,24(sp)
    1a88:	6d42                	ld	s10,16(sp)
    1a8a:	6da2                	ld	s11,8(sp)
    1a8c:	854e                	mv	a0,s3
    1a8e:	69a6                	ld	s3,72(sp)
    1a90:	6165                	addi	sp,sp,112
    1a92:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a94:	4e3000ef          	jal	ra,2776 <getpid>
    1a98:	8daa                	mv	s11,a0
    1a9a:	8566                	mv	a0,s9
    1a9c:	3b1000ef          	jal	ra,264c <basename>
    1aa0:	872a                	mv	a4,a0
    1aa2:	8662                	mv	a2,s8
    1aa4:	05400793          	li	a5,84
    1aa8:	86ee                	mv	a3,s11
    1aaa:	45fd                	li	a1,31
    1aac:	855e                	mv	a0,s7
    1aae:	a97ff0ef          	jal	ra,1544 <printf>
    1ab2:	557d                	li	a0,-1
    1ab4:	4f3000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    1ab8:	000d2603          	lw	a2,0(s10)
    1abc:	da35                	beqz	a2,1a30 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1abe:	85da                	mv	a1,s6
    1ac0:	4505                	li	a0,1
    1ac2:	4ab000ef          	jal	ra,276c <write>
    1ac6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1ac8:	00001797          	auipc	a5,0x1
    1acc:	2a07a423          	sw	zero,680(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1ad0:	f8055de3          	bgez	a0,1a6a <out_unlocked+0x9a>
    1ad4:	89aa                	mv	s3,a0
    1ad6:	bf79                	j	1a74 <out_unlocked+0xa4>
	int ret = 0;
    1ad8:	4981                	li	s3,0
    1ada:	bf69                	j	1a74 <out_unlocked+0xa4>

0000000000001adc <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1adc:	1101                	addi	sp,sp,-32
    1ade:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1ae0:	00001497          	auipc	s1,0x1
    1ae4:	29048493          	addi	s1,s1,656 # 2d70 <buffer_len>
    1ae8:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1aea:	ec06                	sd	ra,24(sp)
    1aec:	e822                	sd	s0,16(sp)
		char c = s[i];
    1aee:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1af2:	0017861b          	addiw	a2,a5,1
    1af6:	97a6                	add	a5,a5,s1
    1af8:	00e78423          	sb	a4,8(a5)
    1afc:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1afe:	0ff00793          	li	a5,255
    1b02:	00c7cc63          	blt	a5,a2,1b1a <out_unlocked.constprop.0+0x3e>
    1b06:	47a9                	li	a5,10
    1b08:	06f70c63          	beq	a4,a5,1b80 <out_unlocked.constprop.0+0xa4>
    1b0c:	4601                	li	a2,0
}
    1b0e:	60e2                	ld	ra,24(sp)
    1b10:	6442                	ld	s0,16(sp)
    1b12:	64a2                	ld	s1,8(sp)
    1b14:	8532                	mv	a0,a2
    1b16:	6105                	addi	sp,sp,32
    1b18:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b1a:	10000793          	li	a5,256
    1b1e:	02f61563          	bne	a2,a5,1b48 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1b22:	00001597          	auipc	a1,0x1
    1b26:	25658593          	addi	a1,a1,598 # 2d78 <buffer>
    1b2a:	4505                	li	a0,1
    1b2c:	441000ef          	jal	ra,276c <write>
}
    1b30:	60e2                	ld	ra,24(sp)
    1b32:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1b34:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b38:	00001797          	auipc	a5,0x1
    1b3c:	2207ac23          	sw	zero,568(a5) # 2d70 <buffer_len>
}
    1b40:	64a2                	ld	s1,8(sp)
    1b42:	8532                	mv	a0,a2
    1b44:	6105                	addi	sp,sp,32
    1b46:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b48:	42f000ef          	jal	ra,2776 <getpid>
    1b4c:	842a                	mv	s0,a0
    1b4e:	00001517          	auipc	a0,0x1
    1b52:	12250513          	addi	a0,a0,290 # 2c70 <enable_deadlock_detect+0x22c>
    1b56:	2f7000ef          	jal	ra,264c <basename>
    1b5a:	872a                	mv	a4,a0
    1b5c:	00001617          	auipc	a2,0x1
    1b60:	f7460613          	addi	a2,a2,-140 # 2ad0 <enable_deadlock_detect+0x8c>
    1b64:	05400793          	li	a5,84
    1b68:	86a2                	mv	a3,s0
    1b6a:	45fd                	li	a1,31
    1b6c:	00001517          	auipc	a0,0x1
    1b70:	14450513          	addi	a0,a0,324 # 2cb0 <enable_deadlock_detect+0x26c>
    1b74:	9d1ff0ef          	jal	ra,1544 <printf>
    1b78:	557d                	li	a0,-1
    1b7a:	42d000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    1b7e:	4090                	lw	a2,0(s1)
    1b80:	d659                	beqz	a2,1b0e <out_unlocked.constprop.0+0x32>
    1b82:	b745                	j	1b22 <out_unlocked.constprop.0+0x46>

0000000000001b84 <putchar>:
{
    1b84:	7139                	addi	sp,sp,-64
    1b86:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1b88:	00001497          	auipc	s1,0x1
    1b8c:	1e848493          	addi	s1,s1,488 # 2d70 <buffer_len>
    1b90:	1084a703          	lw	a4,264(s1)
{
    1b94:	f822                	sd	s0,48(sp)
	char byte = c;
    1b96:	0ff57413          	zext.b	s0,a0
{
    1b9a:	fc06                	sd	ra,56(sp)
	char byte = c;
    1b9c:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1ba0:	4785                	li	a5,1
    1ba2:	00f70d63          	beq	a4,a5,1bbc <putchar+0x38>
		len = out_unlocked(s, l);
    1ba6:	01f10513          	addi	a0,sp,31
    1baa:	f33ff0ef          	jal	ra,1adc <out_unlocked.constprop.0>
}
    1bae:	70e2                	ld	ra,56(sp)
    1bb0:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1bb2:	862a                	mv	a2,a0
}
    1bb4:	74a2                	ld	s1,40(sp)
    1bb6:	8532                	mv	a0,a2
    1bb8:	6121                	addi	sp,sp,64
    1bba:	8082                	ret
		mutex_lock(buffer_lock);
    1bbc:	10c4a503          	lw	a0,268(s1)
    1bc0:	625000ef          	jal	ra,29e4 <mutex_lock>
		buffer[buffer_len++] = c;
    1bc4:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1bc6:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1bca:	0017861b          	addiw	a2,a5,1
    1bce:	97a6                	add	a5,a5,s1
    1bd0:	c090                	sw	a2,0(s1)
    1bd2:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1bd6:	02c6c263          	blt	a3,a2,1bfa <putchar+0x76>
    1bda:	47a9                	li	a5,10
    1bdc:	06f40d63          	beq	s0,a5,1c56 <putchar+0xd2>
    1be0:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1be2:	10c4a503          	lw	a0,268(s1)
    1be6:	e432                	sd	a2,8(sp)
    1be8:	609000ef          	jal	ra,29f0 <mutex_unlock>
    1bec:	6622                	ld	a2,8(sp)
}
    1bee:	70e2                	ld	ra,56(sp)
    1bf0:	7442                	ld	s0,48(sp)
    1bf2:	74a2                	ld	s1,40(sp)
    1bf4:	8532                	mv	a0,a2
    1bf6:	6121                	addi	sp,sp,64
    1bf8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bfa:	10000793          	li	a5,256
    1bfe:	02f61063          	bne	a2,a5,1c1e <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1c02:	00001597          	auipc	a1,0x1
    1c06:	17658593          	addi	a1,a1,374 # 2d78 <buffer>
    1c0a:	4505                	li	a0,1
    1c0c:	361000ef          	jal	ra,276c <write>
    1c10:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1c14:	00001797          	auipc	a5,0x1
    1c18:	1407ae23          	sw	zero,348(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1c1c:	b7d9                	j	1be2 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1c1e:	359000ef          	jal	ra,2776 <getpid>
    1c22:	842a                	mv	s0,a0
    1c24:	00001517          	auipc	a0,0x1
    1c28:	04c50513          	addi	a0,a0,76 # 2c70 <enable_deadlock_detect+0x22c>
    1c2c:	221000ef          	jal	ra,264c <basename>
    1c30:	872a                	mv	a4,a0
    1c32:	00001617          	auipc	a2,0x1
    1c36:	e9e60613          	addi	a2,a2,-354 # 2ad0 <enable_deadlock_detect+0x8c>
    1c3a:	05400793          	li	a5,84
    1c3e:	86a2                	mv	a3,s0
    1c40:	45fd                	li	a1,31
    1c42:	00001517          	auipc	a0,0x1
    1c46:	06e50513          	addi	a0,a0,110 # 2cb0 <enable_deadlock_detect+0x26c>
    1c4a:	8fbff0ef          	jal	ra,1544 <printf>
    1c4e:	557d                	li	a0,-1
    1c50:	357000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    1c54:	4090                	lw	a2,0(s1)
    1c56:	d651                	beqz	a2,1be2 <putchar+0x5e>
    1c58:	b76d                	j	1c02 <putchar+0x7e>

0000000000001c5a <puts>:
{
    1c5a:	7139                	addi	sp,sp,-64
    1c5c:	f822                	sd	s0,48(sp)
    1c5e:	f426                	sd	s1,40(sp)
    1c60:	fc06                	sd	ra,56(sp)
    1c62:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1c64:	00001417          	auipc	s0,0x1
    1c68:	10c40413          	addi	s0,s0,268 # 2d70 <buffer_len>
{
    1c6c:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c6e:	638000ef          	jal	ra,22a6 <strlen>
	if (buffer_lock_enabled == 1) {
    1c72:	10842703          	lw	a4,264(s0)
    1c76:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c78:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1c7a:	04f70563          	beq	a4,a5,1cc4 <puts+0x6a>
		len = out_unlocked(s, l);
    1c7e:	8526                	mv	a0,s1
    1c80:	d51ff0ef          	jal	ra,19d0 <out_unlocked>
    1c84:	892a                	mv	s2,a0
    1c86:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c88:	00095963          	bgez	s2,1c9a <puts+0x40>
}
    1c8c:	70e2                	ld	ra,56(sp)
    1c8e:	7442                	ld	s0,48(sp)
    1c90:	7902                	ld	s2,32(sp)
    1c92:	8526                	mv	a0,s1
    1c94:	74a2                	ld	s1,40(sp)
    1c96:	6121                	addi	sp,sp,64
    1c98:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1c9a:	10842703          	lw	a4,264(s0)
	char byte = c;
    1c9e:	44a9                	li	s1,10
    1ca0:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1ca4:	4785                	li	a5,1
    1ca6:	02f70e63          	beq	a4,a5,1ce2 <puts+0x88>
		len = out_unlocked(s, l);
    1caa:	01f10513          	addi	a0,sp,31
    1cae:	e2fff0ef          	jal	ra,1adc <out_unlocked.constprop.0>
}
    1cb2:	70e2                	ld	ra,56(sp)
    1cb4:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1cb6:	41f5549b          	sraiw	s1,a0,0x1f
}
    1cba:	7902                	ld	s2,32(sp)
    1cbc:	8526                	mv	a0,s1
    1cbe:	74a2                	ld	s1,40(sp)
    1cc0:	6121                	addi	sp,sp,64
    1cc2:	8082                	ret
		mutex_lock(buffer_lock);
    1cc4:	e42a                	sd	a0,8(sp)
    1cc6:	10c42503          	lw	a0,268(s0)
    1cca:	51b000ef          	jal	ra,29e4 <mutex_lock>
		len = out_unlocked(s, l);
    1cce:	65a2                	ld	a1,8(sp)
    1cd0:	8526                	mv	a0,s1
    1cd2:	cffff0ef          	jal	ra,19d0 <out_unlocked>
    1cd6:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1cd8:	10c42503          	lw	a0,268(s0)
    1cdc:	515000ef          	jal	ra,29f0 <mutex_unlock>
    1ce0:	b75d                	j	1c86 <puts+0x2c>
		mutex_lock(buffer_lock);
    1ce2:	10c42503          	lw	a0,268(s0)
    1ce6:	4ff000ef          	jal	ra,29e4 <mutex_lock>
		buffer[buffer_len++] = c;
    1cea:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cec:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1cf0:	0017861b          	addiw	a2,a5,1
    1cf4:	97a2                	add	a5,a5,s0
    1cf6:	c010                	sw	a2,0(s0)
    1cf8:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1cfc:	06c6dc63          	bge	a3,a2,1d74 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1d00:	10000793          	li	a5,256
    1d04:	02f61c63          	bne	a2,a5,1d3c <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1d08:	00001597          	auipc	a1,0x1
    1d0c:	07058593          	addi	a1,a1,112 # 2d78 <buffer>
    1d10:	4505                	li	a0,1
    1d12:	25b000ef          	jal	ra,276c <write>
			if (r < 0) {
    1d16:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1d18:	00001797          	auipc	a5,0x1
    1d1c:	0407ac23          	sw	zero,88(a5) # 2d70 <buffer_len>
			if (r < 0) {
    1d20:	04054c63          	bltz	a0,1d78 <puts+0x11e>
			if (r < buffer_len) {
    1d24:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1d26:	10c42503          	lw	a0,268(s0)
    1d2a:	4c7000ef          	jal	ra,29f0 <mutex_unlock>
}
    1d2e:	70e2                	ld	ra,56(sp)
    1d30:	7442                	ld	s0,48(sp)
    1d32:	7902                	ld	s2,32(sp)
    1d34:	8526                	mv	a0,s1
    1d36:	74a2                	ld	s1,40(sp)
    1d38:	6121                	addi	sp,sp,64
    1d3a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1d3c:	23b000ef          	jal	ra,2776 <getpid>
    1d40:	84aa                	mv	s1,a0
    1d42:	00001517          	auipc	a0,0x1
    1d46:	f2e50513          	addi	a0,a0,-210 # 2c70 <enable_deadlock_detect+0x22c>
    1d4a:	103000ef          	jal	ra,264c <basename>
    1d4e:	872a                	mv	a4,a0
    1d50:	00001617          	auipc	a2,0x1
    1d54:	d8060613          	addi	a2,a2,-640 # 2ad0 <enable_deadlock_detect+0x8c>
    1d58:	05400793          	li	a5,84
    1d5c:	86a6                	mv	a3,s1
    1d5e:	45fd                	li	a1,31
    1d60:	00001517          	auipc	a0,0x1
    1d64:	f5050513          	addi	a0,a0,-176 # 2cb0 <enable_deadlock_detect+0x26c>
    1d68:	fdcff0ef          	jal	ra,1544 <printf>
    1d6c:	557d                	li	a0,-1
    1d6e:	239000ef          	jal	ra,27a6 <exit>
	if (buffer_len == 0)
    1d72:	4010                	lw	a2,0(s0)
    1d74:	da45                	beqz	a2,1d24 <puts+0xca>
    1d76:	bf49                	j	1d08 <puts+0xae>
    1d78:	54fd                	li	s1,-1
    1d7a:	b775                	j	1d26 <puts+0xcc>

0000000000001d7c <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1d7c:	715d                	addi	sp,sp,-80
    1d7e:	e486                	sd	ra,72(sp)
    1d80:	e0a2                	sd	s0,64(sp)
    1d82:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1d84:	14054363          	bltz	a0,1eca <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1d88:	02b577bb          	remuw	a5,a0,a1
    1d8c:	00001617          	auipc	a2,0x1
    1d90:	0f460613          	addi	a2,a2,244 # 2e80 <digits>
	buf[16] = 0;
    1d94:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d98:	0005871b          	sext.w	a4,a1
    1d9c:	1782                	slli	a5,a5,0x20
    1d9e:	9381                	srli	a5,a5,0x20
    1da0:	97b2                	add	a5,a5,a2
    1da2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1da6:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1daa:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1dae:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1db0:	0eb56763          	bltu	a0,a1,1e9e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1db4:	02e877bb          	remuw	a5,a6,a4
    1db8:	1782                	slli	a5,a5,0x20
    1dba:	9381                	srli	a5,a5,0x20
    1dbc:	97b2                	add	a5,a5,a2
    1dbe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1dc2:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1dc6:	02f10323          	sb	a5,38(sp)
    1dca:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1dcc:	0ce86963          	bltu	a6,a4,1e9e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1dd0:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1dd4:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1dd8:	1582                	slli	a1,a1,0x20
    1dda:	9181                	srli	a1,a1,0x20
    1ddc:	95b2                	add	a1,a1,a2
    1dde:	0005c583          	lbu	a1,0(a1)
    1de2:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1de6:	0007859b          	sext.w	a1,a5
    1dea:	16e6e563          	bltu	a3,a4,1f54 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1dee:	02e7f6bb          	remuw	a3,a5,a4
    1df2:	1682                	slli	a3,a3,0x20
    1df4:	9281                	srli	a3,a3,0x20
    1df6:	96b2                	add	a3,a3,a2
    1df8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dfc:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1e00:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1e04:	16e5e163          	bltu	a1,a4,1f66 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1e08:	02e876bb          	remuw	a3,a6,a4
    1e0c:	1682                	slli	a3,a3,0x20
    1e0e:	9281                	srli	a3,a3,0x20
    1e10:	96b2                	add	a3,a3,a2
    1e12:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e16:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1e1a:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1e1e:	14e86d63          	bltu	a6,a4,1f78 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1e22:	02e5f6bb          	remuw	a3,a1,a4
    1e26:	1682                	slli	a3,a3,0x20
    1e28:	9281                	srli	a3,a3,0x20
    1e2a:	96b2                	add	a3,a3,a2
    1e2c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e30:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1e34:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1e38:	10e5e563          	bltu	a1,a4,1f42 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1e3c:	02e876bb          	remuw	a3,a6,a4
    1e40:	1682                	slli	a3,a3,0x20
    1e42:	9281                	srli	a3,a3,0x20
    1e44:	96b2                	add	a3,a3,a2
    1e46:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e4a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1e4e:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1e52:	14e86263          	bltu	a6,a4,1f96 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1e56:	02e5f6bb          	remuw	a3,a1,a4
    1e5a:	1682                	slli	a3,a3,0x20
    1e5c:	9281                	srli	a3,a3,0x20
    1e5e:	96b2                	add	a3,a3,a2
    1e60:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e64:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1e68:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1e6c:	14e5e463          	bltu	a1,a4,1fb4 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1e70:	02e876bb          	remuw	a3,a6,a4
    1e74:	1682                	slli	a3,a3,0x20
    1e76:	9281                	srli	a3,a3,0x20
    1e78:	96b2                	add	a3,a3,a2
    1e7a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e7e:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1e82:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1e86:	14e86063          	bltu	a6,a4,1fc6 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1e8a:	1782                	slli	a5,a5,0x20
    1e8c:	9381                	srli	a5,a5,0x20
    1e8e:	97b2                	add	a5,a5,a2
    1e90:	0007c703          	lbu	a4,0(a5)
    1e94:	4799                	li	a5,6
    1e96:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1e9a:	10054763          	bltz	a0,1fa8 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1e9e:	00001497          	auipc	s1,0x1
    1ea2:	ed248493          	addi	s1,s1,-302 # 2d70 <buffer_len>
    1ea6:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1eaa:	0828                	addi	a0,sp,24
    1eac:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1eae:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1eb0:	00f50433          	add	s0,a0,a5
    1eb4:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1eb6:	06e68463          	beq	a3,a4,1f1e <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1eba:	8522                	mv	a0,s0
    1ebc:	b15ff0ef          	jal	ra,19d0 <out_unlocked>
}
    1ec0:	60a6                	ld	ra,72(sp)
    1ec2:	6406                	ld	s0,64(sp)
    1ec4:	74e2                	ld	s1,56(sp)
    1ec6:	6161                	addi	sp,sp,80
    1ec8:	8082                	ret
		x = -xx;
    1eca:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1ece:	02b877bb          	remuw	a5,a6,a1
    1ed2:	00001617          	auipc	a2,0x1
    1ed6:	fae60613          	addi	a2,a2,-82 # 2e80 <digits>
	buf[16] = 0;
    1eda:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ede:	0005871b          	sext.w	a4,a1
    1ee2:	1782                	slli	a5,a5,0x20
    1ee4:	9381                	srli	a5,a5,0x20
    1ee6:	97b2                	add	a5,a5,a2
    1ee8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1eec:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1ef0:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1ef4:	08b86b63          	bltu	a6,a1,1f8a <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1ef8:	02e8f7bb          	remuw	a5,a7,a4
    1efc:	1782                	slli	a5,a5,0x20
    1efe:	9381                	srli	a5,a5,0x20
    1f00:	97b2                	add	a5,a5,a2
    1f02:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1f06:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1f0a:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1f0e:	ece8f1e3          	bgeu	a7,a4,1dd0 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1f12:	02d00793          	li	a5,45
    1f16:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1f1a:	47b5                	li	a5,13
    1f1c:	b749                	j	1e9e <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1f1e:	10c4a503          	lw	a0,268(s1)
    1f22:	e42e                	sd	a1,8(sp)
    1f24:	2c1000ef          	jal	ra,29e4 <mutex_lock>
		len = out_unlocked(s, l);
    1f28:	65a2                	ld	a1,8(sp)
    1f2a:	8522                	mv	a0,s0
    1f2c:	aa5ff0ef          	jal	ra,19d0 <out_unlocked>
		mutex_unlock(buffer_lock);
    1f30:	10c4a503          	lw	a0,268(s1)
    1f34:	2bd000ef          	jal	ra,29f0 <mutex_unlock>
}
    1f38:	60a6                	ld	ra,72(sp)
    1f3a:	6406                	ld	s0,64(sp)
    1f3c:	74e2                	ld	s1,56(sp)
    1f3e:	6161                	addi	sp,sp,80
    1f40:	8082                	ret
		buf[i--] = digits[x % base];
    1f42:	47a9                	li	a5,10
	if (sign)
    1f44:	f4055de3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f48:	02d00793          	li	a5,45
    1f4c:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1f50:	47a5                	li	a5,9
    1f52:	b7b1                	j	1e9e <printint.constprop.0+0x122>
    1f54:	47b5                	li	a5,13
	if (sign)
    1f56:	f40554e3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f5a:	02d00793          	li	a5,45
    1f5e:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1f62:	47b1                	li	a5,12
    1f64:	bf2d                	j	1e9e <printint.constprop.0+0x122>
    1f66:	47b1                	li	a5,12
	if (sign)
    1f68:	f2055be3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f6c:	02d00793          	li	a5,45
    1f70:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1f74:	47ad                	li	a5,11
    1f76:	b725                	j	1e9e <printint.constprop.0+0x122>
    1f78:	47ad                	li	a5,11
	if (sign)
    1f7a:	f20552e3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f7e:	02d00793          	li	a5,45
    1f82:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1f86:	47a9                	li	a5,10
    1f88:	bf19                	j	1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f8a:	02d00793          	li	a5,45
    1f8e:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1f92:	47b9                	li	a5,14
    1f94:	b729                	j	1e9e <printint.constprop.0+0x122>
    1f96:	47a5                	li	a5,9
	if (sign)
    1f98:	f00553e3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f9c:	02d00793          	li	a5,45
    1fa0:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1fa4:	47a1                	li	a5,8
    1fa6:	bde5                	j	1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1fa8:	02d00793          	li	a5,45
    1fac:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1fb0:	4795                	li	a5,5
    1fb2:	b5f5                	j	1e9e <printint.constprop.0+0x122>
    1fb4:	47a1                	li	a5,8
	if (sign)
    1fb6:	ee0554e3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1fba:	02d00793          	li	a5,45
    1fbe:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1fc2:	479d                	li	a5,7
    1fc4:	bde9                	j	1e9e <printint.constprop.0+0x122>
    1fc6:	479d                	li	a5,7
	if (sign)
    1fc8:	ec055be3          	bgez	a0,1e9e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1fcc:	02d00793          	li	a5,45
    1fd0:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1fd4:	4799                	li	a5,6
    1fd6:	b5e1                	j	1e9e <printint.constprop.0+0x122>

0000000000001fd8 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1fd8:	02000793          	li	a5,32
    1fdc:	00f50663          	beq	a0,a5,1fe8 <isspace+0x10>
    1fe0:	355d                	addiw	a0,a0,-9
    1fe2:	00553513          	sltiu	a0,a0,5
    1fe6:	8082                	ret
    1fe8:	4505                	li	a0,1
}
    1fea:	8082                	ret

0000000000001fec <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1fec:	fd05051b          	addiw	a0,a0,-48
}
    1ff0:	00a53513          	sltiu	a0,a0,10
    1ff4:	8082                	ret

0000000000001ff6 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1ff6:	02000613          	li	a2,32
    1ffa:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1ffc:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    2000:	ff77869b          	addiw	a3,a5,-9
    2004:	04c78c63          	beq	a5,a2,205c <atoi+0x66>
    2008:	0007871b          	sext.w	a4,a5
    200c:	04d5f863          	bgeu	a1,a3,205c <atoi+0x66>
		s++;
	switch (*s) {
    2010:	02b00693          	li	a3,43
    2014:	04d78963          	beq	a5,a3,2066 <atoi+0x70>
    2018:	02d00693          	li	a3,45
    201c:	06d78263          	beq	a5,a3,2080 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    2020:	fd07061b          	addiw	a2,a4,-48
    2024:	47a5                	li	a5,9
    2026:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    2028:	4e01                	li	t3,0
	while (isdigit(*s))
    202a:	04c7e963          	bltu	a5,a2,207c <atoi+0x86>
	int n = 0, neg = 0;
    202e:	4501                	li	a0,0
	while (isdigit(*s))
    2030:	4825                	li	a6,9
    2032:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    2036:	0025179b          	slliw	a5,a0,0x2
    203a:	9fa9                	addw	a5,a5,a0
    203c:	fd07031b          	addiw	t1,a4,-48
    2040:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    2044:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    2048:	0685                	addi	a3,a3,1
    204a:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    204e:	0006071b          	sext.w	a4,a2
    2052:	feb870e3          	bgeu	a6,a1,2032 <atoi+0x3c>
	return neg ? n : -n;
    2056:	000e0563          	beqz	t3,2060 <atoi+0x6a>
}
    205a:	8082                	ret
		s++;
    205c:	0505                	addi	a0,a0,1
    205e:	bf79                	j	1ffc <atoi+0x6>
	return neg ? n : -n;
    2060:	4113053b          	subw	a0,t1,a7
    2064:	8082                	ret
	while (isdigit(*s))
    2066:	00154703          	lbu	a4,1(a0)
    206a:	47a5                	li	a5,9
		s++;
    206c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    2070:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    2074:	4e01                	li	t3,0
	while (isdigit(*s))
    2076:	2701                	sext.w	a4,a4
    2078:	fac7fbe3          	bgeu	a5,a2,202e <atoi+0x38>
    207c:	4501                	li	a0,0
}
    207e:	8082                	ret
	while (isdigit(*s))
    2080:	00154703          	lbu	a4,1(a0)
    2084:	47a5                	li	a5,9
		s++;
    2086:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    208a:	fd07061b          	addiw	a2,a4,-48
    208e:	2701                	sext.w	a4,a4
    2090:	fec7e6e3          	bltu	a5,a2,207c <atoi+0x86>
		neg = 1;
    2094:	4e05                	li	t3,1
    2096:	bf61                	j	202e <atoi+0x38>

0000000000002098 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    2098:	16060d63          	beqz	a2,2212 <memset+0x17a>
    209c:	40a007b3          	neg	a5,a0
    20a0:	8b9d                	andi	a5,a5,7
    20a2:	00778693          	addi	a3,a5,7
    20a6:	482d                	li	a6,11
    20a8:	0ff5f713          	zext.b	a4,a1
    20ac:	fff60593          	addi	a1,a2,-1
    20b0:	1706e263          	bltu	a3,a6,2214 <memset+0x17c>
    20b4:	16d5ea63          	bltu	a1,a3,2228 <memset+0x190>
    20b8:	16078563          	beqz	a5,2222 <memset+0x18a>
    20bc:	00e50023          	sb	a4,0(a0)
    20c0:	4685                	li	a3,1
    20c2:	00150593          	addi	a1,a0,1
    20c6:	14d78c63          	beq	a5,a3,221e <memset+0x186>
    20ca:	00e500a3          	sb	a4,1(a0)
    20ce:	4689                	li	a3,2
    20d0:	00250593          	addi	a1,a0,2
    20d4:	14d78d63          	beq	a5,a3,222e <memset+0x196>
    20d8:	00e50123          	sb	a4,2(a0)
    20dc:	468d                	li	a3,3
    20de:	00350593          	addi	a1,a0,3
    20e2:	12d78b63          	beq	a5,a3,2218 <memset+0x180>
    20e6:	00e501a3          	sb	a4,3(a0)
    20ea:	4691                	li	a3,4
    20ec:	00450593          	addi	a1,a0,4
    20f0:	14d78163          	beq	a5,a3,2232 <memset+0x19a>
    20f4:	00e50223          	sb	a4,4(a0)
    20f8:	4695                	li	a3,5
    20fa:	00550593          	addi	a1,a0,5
    20fe:	12d78c63          	beq	a5,a3,2236 <memset+0x19e>
    2102:	00e502a3          	sb	a4,5(a0)
    2106:	469d                	li	a3,7
    2108:	00650593          	addi	a1,a0,6
    210c:	12d79763          	bne	a5,a3,223a <memset+0x1a2>
    2110:	00750593          	addi	a1,a0,7
    2114:	00e50323          	sb	a4,6(a0)
    2118:	481d                	li	a6,7
    211a:	00871693          	slli	a3,a4,0x8
    211e:	01071893          	slli	a7,a4,0x10
    2122:	8ed9                	or	a3,a3,a4
    2124:	01871313          	slli	t1,a4,0x18
    2128:	0116e6b3          	or	a3,a3,a7
    212c:	0066e6b3          	or	a3,a3,t1
    2130:	02071893          	slli	a7,a4,0x20
    2134:	02871e13          	slli	t3,a4,0x28
    2138:	0116e6b3          	or	a3,a3,a7
    213c:	40f60333          	sub	t1,a2,a5
    2140:	03071893          	slli	a7,a4,0x30
    2144:	01c6e6b3          	or	a3,a3,t3
    2148:	0116e6b3          	or	a3,a3,a7
    214c:	03871e13          	slli	t3,a4,0x38
    2150:	97aa                	add	a5,a5,a0
    2152:	ff837893          	andi	a7,t1,-8
    2156:	01c6e6b3          	or	a3,a3,t3
    215a:	98be                	add	a7,a7,a5
    215c:	e394                	sd	a3,0(a5)
    215e:	07a1                	addi	a5,a5,8
    2160:	ff179ee3          	bne	a5,a7,215c <memset+0xc4>
    2164:	ff837893          	andi	a7,t1,-8
    2168:	011587b3          	add	a5,a1,a7
    216c:	010886bb          	addw	a3,a7,a6
    2170:	0b130663          	beq	t1,a7,221c <memset+0x184>
    2174:	00e78023          	sb	a4,0(a5)
    2178:	0016859b          	addiw	a1,a3,1
    217c:	08c5fb63          	bgeu	a1,a2,2212 <memset+0x17a>
    2180:	00e780a3          	sb	a4,1(a5)
    2184:	0026859b          	addiw	a1,a3,2
    2188:	08c5f563          	bgeu	a1,a2,2212 <memset+0x17a>
    218c:	00e78123          	sb	a4,2(a5)
    2190:	0036859b          	addiw	a1,a3,3
    2194:	06c5ff63          	bgeu	a1,a2,2212 <memset+0x17a>
    2198:	00e781a3          	sb	a4,3(a5)
    219c:	0046859b          	addiw	a1,a3,4
    21a0:	06c5f963          	bgeu	a1,a2,2212 <memset+0x17a>
    21a4:	00e78223          	sb	a4,4(a5)
    21a8:	0056859b          	addiw	a1,a3,5
    21ac:	06c5f363          	bgeu	a1,a2,2212 <memset+0x17a>
    21b0:	00e782a3          	sb	a4,5(a5)
    21b4:	0066859b          	addiw	a1,a3,6
    21b8:	04c5fd63          	bgeu	a1,a2,2212 <memset+0x17a>
    21bc:	00e78323          	sb	a4,6(a5)
    21c0:	0076859b          	addiw	a1,a3,7
    21c4:	04c5f763          	bgeu	a1,a2,2212 <memset+0x17a>
    21c8:	00e783a3          	sb	a4,7(a5)
    21cc:	0086859b          	addiw	a1,a3,8
    21d0:	04c5f163          	bgeu	a1,a2,2212 <memset+0x17a>
    21d4:	00e78423          	sb	a4,8(a5)
    21d8:	0096859b          	addiw	a1,a3,9
    21dc:	02c5fb63          	bgeu	a1,a2,2212 <memset+0x17a>
    21e0:	00e784a3          	sb	a4,9(a5)
    21e4:	00a6859b          	addiw	a1,a3,10
    21e8:	02c5f563          	bgeu	a1,a2,2212 <memset+0x17a>
    21ec:	00e78523          	sb	a4,10(a5)
    21f0:	00b6859b          	addiw	a1,a3,11
    21f4:	00c5ff63          	bgeu	a1,a2,2212 <memset+0x17a>
    21f8:	00e785a3          	sb	a4,11(a5)
    21fc:	00c6859b          	addiw	a1,a3,12
    2200:	00c5f963          	bgeu	a1,a2,2212 <memset+0x17a>
    2204:	00e78623          	sb	a4,12(a5)
    2208:	26b5                	addiw	a3,a3,13
    220a:	00c6f463          	bgeu	a3,a2,2212 <memset+0x17a>
    220e:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2212:	8082                	ret
    2214:	46ad                	li	a3,11
    2216:	bd79                	j	20b4 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2218:	480d                	li	a6,3
    221a:	b701                	j	211a <memset+0x82>
    221c:	8082                	ret
    221e:	4805                	li	a6,1
    2220:	bded                	j	211a <memset+0x82>
    2222:	85aa                	mv	a1,a0
    2224:	4801                	li	a6,0
    2226:	bdd5                	j	211a <memset+0x82>
    2228:	87aa                	mv	a5,a0
    222a:	4681                	li	a3,0
    222c:	b7a1                	j	2174 <memset+0xdc>
    222e:	4809                	li	a6,2
    2230:	b5ed                	j	211a <memset+0x82>
    2232:	4811                	li	a6,4
    2234:	b5dd                	j	211a <memset+0x82>
    2236:	4815                	li	a6,5
    2238:	b5cd                	j	211a <memset+0x82>
    223a:	4819                	li	a6,6
    223c:	bdf9                	j	211a <memset+0x82>

000000000000223e <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    223e:	00054783          	lbu	a5,0(a0)
    2242:	0005c703          	lbu	a4,0(a1)
    2246:	00e79863          	bne	a5,a4,2256 <strcmp+0x18>
    224a:	0505                	addi	a0,a0,1
    224c:	0585                	addi	a1,a1,1
    224e:	fbe5                	bnez	a5,223e <strcmp>
    2250:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2252:	9d19                	subw	a0,a0,a4
    2254:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    2256:	0007851b          	sext.w	a0,a5
    225a:	bfe5                	j	2252 <strcmp+0x14>

000000000000225c <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    225c:	ca15                	beqz	a2,2290 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    225e:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2262:	167d                	addi	a2,a2,-1
    2264:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2268:	eb99                	bnez	a5,227e <strncmp+0x22>
    226a:	a815                	j	229e <strncmp+0x42>
    226c:	00a68e63          	beq	a3,a0,2288 <strncmp+0x2c>
    2270:	0505                	addi	a0,a0,1
    2272:	00f71b63          	bne	a4,a5,2288 <strncmp+0x2c>
    2276:	00054783          	lbu	a5,0(a0)
    227a:	cf89                	beqz	a5,2294 <strncmp+0x38>
    227c:	85b2                	mv	a1,a2
    227e:	0005c703          	lbu	a4,0(a1)
    2282:	00158613          	addi	a2,a1,1
    2286:	f37d                	bnez	a4,226c <strncmp+0x10>
		;
	return *l - *r;
    2288:	0007851b          	sext.w	a0,a5
    228c:	9d19                	subw	a0,a0,a4
    228e:	8082                	ret
		return 0;
    2290:	4501                	li	a0,0
}
    2292:	8082                	ret
	return *l - *r;
    2294:	0015c703          	lbu	a4,1(a1)
    2298:	4501                	li	a0,0
    229a:	9d19                	subw	a0,a0,a4
    229c:	8082                	ret
    229e:	0005c703          	lbu	a4,0(a1)
    22a2:	4501                	li	a0,0
    22a4:	b7e5                	j	228c <strncmp+0x30>

00000000000022a6 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    22a6:	00757793          	andi	a5,a0,7
    22aa:	cf89                	beqz	a5,22c4 <strlen+0x1e>
    22ac:	87aa                	mv	a5,a0
    22ae:	a029                	j	22b8 <strlen+0x12>
    22b0:	0785                	addi	a5,a5,1
    22b2:	0077f713          	andi	a4,a5,7
    22b6:	cb01                	beqz	a4,22c6 <strlen+0x20>
		if (!*s)
    22b8:	0007c703          	lbu	a4,0(a5)
    22bc:	fb75                	bnez	a4,22b0 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    22be:	40a78533          	sub	a0,a5,a0
}
    22c2:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22c4:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    22c6:	6394                	ld	a3,0(a5)
    22c8:	00001597          	auipc	a1,0x1
    22cc:	a805b583          	ld	a1,-1408(a1) # 2d48 <enable_deadlock_detect+0x304>
    22d0:	00001617          	auipc	a2,0x1
    22d4:	a8063603          	ld	a2,-1408(a2) # 2d50 <enable_deadlock_detect+0x30c>
    22d8:	a019                	j	22de <strlen+0x38>
    22da:	6794                	ld	a3,8(a5)
    22dc:	07a1                	addi	a5,a5,8
    22de:	00b68733          	add	a4,a3,a1
    22e2:	fff6c693          	not	a3,a3
    22e6:	8f75                	and	a4,a4,a3
    22e8:	8f71                	and	a4,a4,a2
    22ea:	db65                	beqz	a4,22da <strlen+0x34>
	for (; *s; s++)
    22ec:	0007c703          	lbu	a4,0(a5)
    22f0:	d779                	beqz	a4,22be <strlen+0x18>
    22f2:	0017c703          	lbu	a4,1(a5)
    22f6:	0785                	addi	a5,a5,1
    22f8:	d379                	beqz	a4,22be <strlen+0x18>
    22fa:	0017c703          	lbu	a4,1(a5)
    22fe:	0785                	addi	a5,a5,1
    2300:	fb6d                	bnez	a4,22f2 <strlen+0x4c>
    2302:	bf75                	j	22be <strlen+0x18>

0000000000002304 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2304:	00757713          	andi	a4,a0,7
{
    2308:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    230a:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    230e:	cb19                	beqz	a4,2324 <memchr+0x20>
    2310:	ce25                	beqz	a2,2388 <memchr+0x84>
    2312:	0007c703          	lbu	a4,0(a5)
    2316:	04b70e63          	beq	a4,a1,2372 <memchr+0x6e>
    231a:	0785                	addi	a5,a5,1
    231c:	0077f713          	andi	a4,a5,7
    2320:	167d                	addi	a2,a2,-1
    2322:	f77d                	bnez	a4,2310 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2324:	4501                	li	a0,0
	if (n && *s != c) {
    2326:	c235                	beqz	a2,238a <memchr+0x86>
    2328:	0007c703          	lbu	a4,0(a5)
    232c:	04b70363          	beq	a4,a1,2372 <memchr+0x6e>
		size_t k = ONES * c;
    2330:	00001517          	auipc	a0,0x1
    2334:	a2853503          	ld	a0,-1496(a0) # 2d58 <enable_deadlock_detect+0x314>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2338:	471d                	li	a4,7
		size_t k = ONES * c;
    233a:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    233e:	02c77a63          	bgeu	a4,a2,2372 <memchr+0x6e>
    2342:	00001897          	auipc	a7,0x1
    2346:	a068b883          	ld	a7,-1530(a7) # 2d48 <enable_deadlock_detect+0x304>
    234a:	00001817          	auipc	a6,0x1
    234e:	a0683803          	ld	a6,-1530(a6) # 2d50 <enable_deadlock_detect+0x30c>
    2352:	431d                	li	t1,7
    2354:	a029                	j	235e <memchr+0x5a>
		     w++, n -= SS)
    2356:	1661                	addi	a2,a2,-8
    2358:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    235a:	02c37963          	bgeu	t1,a2,238c <memchr+0x88>
    235e:	6398                	ld	a4,0(a5)
    2360:	8f29                	xor	a4,a4,a0
    2362:	011706b3          	add	a3,a4,a7
    2366:	fff74713          	not	a4,a4
    236a:	8f75                	and	a4,a4,a3
    236c:	01077733          	and	a4,a4,a6
    2370:	d37d                	beqz	a4,2356 <memchr+0x52>
{
    2372:	853e                	mv	a0,a5
    2374:	97b2                	add	a5,a5,a2
    2376:	a021                	j	237e <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2378:	0505                	addi	a0,a0,1
    237a:	00f50763          	beq	a0,a5,2388 <memchr+0x84>
    237e:	00054703          	lbu	a4,0(a0)
    2382:	feb71be3          	bne	a4,a1,2378 <memchr+0x74>
    2386:	8082                	ret
	return n ? (void *)s : 0;
    2388:	4501                	li	a0,0
}
    238a:	8082                	ret
	return n ? (void *)s : 0;
    238c:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    238e:	f275                	bnez	a2,2372 <memchr+0x6e>
}
    2390:	8082                	ret

0000000000002392 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2392:	1101                	addi	sp,sp,-32
    2394:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2396:	862e                	mv	a2,a1
{
    2398:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    239a:	4581                	li	a1,0
{
    239c:	e426                	sd	s1,8(sp)
    239e:	ec06                	sd	ra,24(sp)
    23a0:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    23a2:	f63ff0ef          	jal	ra,2304 <memchr>
	return p ? p - s : n;
    23a6:	c519                	beqz	a0,23b4 <strnlen+0x22>
}
    23a8:	60e2                	ld	ra,24(sp)
    23aa:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    23ac:	8d05                	sub	a0,a0,s1
}
    23ae:	64a2                	ld	s1,8(sp)
    23b0:	6105                	addi	sp,sp,32
    23b2:	8082                	ret
    23b4:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    23b6:	8522                	mv	a0,s0
}
    23b8:	6442                	ld	s0,16(sp)
    23ba:	64a2                	ld	s1,8(sp)
    23bc:	6105                	addi	sp,sp,32
    23be:	8082                	ret

00000000000023c0 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    23c0:	00a5c7b3          	xor	a5,a1,a0
    23c4:	8b9d                	andi	a5,a5,7
    23c6:	eb95                	bnez	a5,23fa <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    23c8:	0075f793          	andi	a5,a1,7
    23cc:	e7b1                	bnez	a5,2418 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    23ce:	6198                	ld	a4,0(a1)
    23d0:	00001617          	auipc	a2,0x1
    23d4:	97863603          	ld	a2,-1672(a2) # 2d48 <enable_deadlock_detect+0x304>
    23d8:	00001817          	auipc	a6,0x1
    23dc:	97883803          	ld	a6,-1672(a6) # 2d50 <enable_deadlock_detect+0x30c>
    23e0:	a029                	j	23ea <stpcpy+0x2a>
    23e2:	05a1                	addi	a1,a1,8
    23e4:	e118                	sd	a4,0(a0)
    23e6:	6198                	ld	a4,0(a1)
    23e8:	0521                	addi	a0,a0,8
    23ea:	00c707b3          	add	a5,a4,a2
    23ee:	fff74693          	not	a3,a4
    23f2:	8ff5                	and	a5,a5,a3
    23f4:	0107f7b3          	and	a5,a5,a6
    23f8:	d7ed                	beqz	a5,23e2 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    23fa:	0005c783          	lbu	a5,0(a1)
    23fe:	00f50023          	sb	a5,0(a0)
    2402:	c785                	beqz	a5,242a <stpcpy+0x6a>
    2404:	0015c783          	lbu	a5,1(a1)
    2408:	0505                	addi	a0,a0,1
    240a:	0585                	addi	a1,a1,1
    240c:	00f50023          	sb	a5,0(a0)
    2410:	fbf5                	bnez	a5,2404 <stpcpy+0x44>
		;
	return d;
}
    2412:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2414:	0505                	addi	a0,a0,1
    2416:	df45                	beqz	a4,23ce <stpcpy+0xe>
			if (!(*d = *s))
    2418:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    241c:	0585                	addi	a1,a1,1
    241e:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2422:	00f50023          	sb	a5,0(a0)
    2426:	f7fd                	bnez	a5,2414 <stpcpy+0x54>
}
    2428:	8082                	ret
    242a:	8082                	ret

000000000000242c <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    242c:	00a5c7b3          	xor	a5,a1,a0
    2430:	8b9d                	andi	a5,a5,7
    2432:	1a079863          	bnez	a5,25e2 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2436:	0075f793          	andi	a5,a1,7
    243a:	16078463          	beqz	a5,25a2 <stpncpy+0x176>
    243e:	ea01                	bnez	a2,244e <stpncpy+0x22>
    2440:	a421                	j	2648 <stpncpy+0x21c>
    2442:	167d                	addi	a2,a2,-1
    2444:	0505                	addi	a0,a0,1
    2446:	14070e63          	beqz	a4,25a2 <stpncpy+0x176>
    244a:	1a060863          	beqz	a2,25fa <stpncpy+0x1ce>
    244e:	0005c783          	lbu	a5,0(a1)
    2452:	0585                	addi	a1,a1,1
    2454:	0075f713          	andi	a4,a1,7
    2458:	00f50023          	sb	a5,0(a0)
    245c:	f3fd                	bnez	a5,2442 <stpncpy+0x16>
    245e:	4805                	li	a6,1
    2460:	1a061863          	bnez	a2,2610 <stpncpy+0x1e4>
    2464:	40a007b3          	neg	a5,a0
    2468:	8b9d                	andi	a5,a5,7
    246a:	4681                	li	a3,0
    246c:	18061a63          	bnez	a2,2600 <stpncpy+0x1d4>
    2470:	00778713          	addi	a4,a5,7
    2474:	45ad                	li	a1,11
    2476:	18b76363          	bltu	a4,a1,25fc <stpncpy+0x1d0>
    247a:	1ae6eb63          	bltu	a3,a4,2630 <stpncpy+0x204>
    247e:	1a078363          	beqz	a5,2624 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2482:	00050023          	sb	zero,0(a0)
    2486:	4685                	li	a3,1
    2488:	00150713          	addi	a4,a0,1
    248c:	18d78f63          	beq	a5,a3,262a <stpncpy+0x1fe>
    2490:	000500a3          	sb	zero,1(a0)
    2494:	4689                	li	a3,2
    2496:	00250713          	addi	a4,a0,2
    249a:	18d78e63          	beq	a5,a3,2636 <stpncpy+0x20a>
    249e:	00050123          	sb	zero,2(a0)
    24a2:	468d                	li	a3,3
    24a4:	00350713          	addi	a4,a0,3
    24a8:	16d78c63          	beq	a5,a3,2620 <stpncpy+0x1f4>
    24ac:	000501a3          	sb	zero,3(a0)
    24b0:	4691                	li	a3,4
    24b2:	00450713          	addi	a4,a0,4
    24b6:	18d78263          	beq	a5,a3,263a <stpncpy+0x20e>
    24ba:	00050223          	sb	zero,4(a0)
    24be:	4695                	li	a3,5
    24c0:	00550713          	addi	a4,a0,5
    24c4:	16d78d63          	beq	a5,a3,263e <stpncpy+0x212>
    24c8:	000502a3          	sb	zero,5(a0)
    24cc:	469d                	li	a3,7
    24ce:	00650713          	addi	a4,a0,6
    24d2:	16d79863          	bne	a5,a3,2642 <stpncpy+0x216>
    24d6:	00750713          	addi	a4,a0,7
    24da:	00050323          	sb	zero,6(a0)
    24de:	40f80833          	sub	a6,a6,a5
    24e2:	ff887593          	andi	a1,a6,-8
    24e6:	97aa                	add	a5,a5,a0
    24e8:	95be                	add	a1,a1,a5
    24ea:	0007b023          	sd	zero,0(a5)
    24ee:	07a1                	addi	a5,a5,8
    24f0:	feb79de3          	bne	a5,a1,24ea <stpncpy+0xbe>
    24f4:	ff887593          	andi	a1,a6,-8
    24f8:	9ead                	addw	a3,a3,a1
    24fa:	00b707b3          	add	a5,a4,a1
    24fe:	12b80863          	beq	a6,a1,262e <stpncpy+0x202>
    2502:	00078023          	sb	zero,0(a5)
    2506:	0016871b          	addiw	a4,a3,1
    250a:	0ec77863          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    250e:	000780a3          	sb	zero,1(a5)
    2512:	0026871b          	addiw	a4,a3,2
    2516:	0ec77263          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    251a:	00078123          	sb	zero,2(a5)
    251e:	0036871b          	addiw	a4,a3,3
    2522:	0cc77c63          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2526:	000781a3          	sb	zero,3(a5)
    252a:	0046871b          	addiw	a4,a3,4
    252e:	0cc77663          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2532:	00078223          	sb	zero,4(a5)
    2536:	0056871b          	addiw	a4,a3,5
    253a:	0cc77063          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    253e:	000782a3          	sb	zero,5(a5)
    2542:	0066871b          	addiw	a4,a3,6
    2546:	0ac77a63          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    254a:	00078323          	sb	zero,6(a5)
    254e:	0076871b          	addiw	a4,a3,7
    2552:	0ac77463          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2556:	000783a3          	sb	zero,7(a5)
    255a:	0086871b          	addiw	a4,a3,8
    255e:	08c77e63          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2562:	00078423          	sb	zero,8(a5)
    2566:	0096871b          	addiw	a4,a3,9
    256a:	08c77863          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    256e:	000784a3          	sb	zero,9(a5)
    2572:	00a6871b          	addiw	a4,a3,10
    2576:	08c77263          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    257a:	00078523          	sb	zero,10(a5)
    257e:	00b6871b          	addiw	a4,a3,11
    2582:	06c77c63          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2586:	000785a3          	sb	zero,11(a5)
    258a:	00c6871b          	addiw	a4,a3,12
    258e:	06c77663          	bgeu	a4,a2,25fa <stpncpy+0x1ce>
    2592:	00078623          	sb	zero,12(a5)
    2596:	26b5                	addiw	a3,a3,13
    2598:	06c6f163          	bgeu	a3,a2,25fa <stpncpy+0x1ce>
    259c:	000786a3          	sb	zero,13(a5)
    25a0:	8082                	ret
			;
		if (!n || !*s)
    25a2:	c645                	beqz	a2,264a <stpncpy+0x21e>
    25a4:	0005c783          	lbu	a5,0(a1)
    25a8:	ea078be3          	beqz	a5,245e <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    25ac:	479d                	li	a5,7
    25ae:	02c7ff63          	bgeu	a5,a2,25ec <stpncpy+0x1c0>
    25b2:	00000897          	auipc	a7,0x0
    25b6:	7968b883          	ld	a7,1942(a7) # 2d48 <enable_deadlock_detect+0x304>
    25ba:	00000817          	auipc	a6,0x0
    25be:	79683803          	ld	a6,1942(a6) # 2d50 <enable_deadlock_detect+0x30c>
    25c2:	431d                	li	t1,7
    25c4:	6198                	ld	a4,0(a1)
    25c6:	011707b3          	add	a5,a4,a7
    25ca:	fff74693          	not	a3,a4
    25ce:	8ff5                	and	a5,a5,a3
    25d0:	0107f7b3          	and	a5,a5,a6
    25d4:	ef81                	bnez	a5,25ec <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    25d6:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    25d8:	1661                	addi	a2,a2,-8
    25da:	05a1                	addi	a1,a1,8
    25dc:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    25de:	fec363e3          	bltu	t1,a2,25c4 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    25e2:	e609                	bnez	a2,25ec <stpncpy+0x1c0>
    25e4:	a08d                	j	2646 <stpncpy+0x21a>
    25e6:	167d                	addi	a2,a2,-1
    25e8:	0505                	addi	a0,a0,1
    25ea:	ca01                	beqz	a2,25fa <stpncpy+0x1ce>
    25ec:	0005c783          	lbu	a5,0(a1)
    25f0:	0585                	addi	a1,a1,1
    25f2:	00f50023          	sb	a5,0(a0)
    25f6:	fbe5                	bnez	a5,25e6 <stpncpy+0x1ba>
		;
tail:
    25f8:	b59d                	j	245e <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    25fa:	8082                	ret
    25fc:	472d                	li	a4,11
    25fe:	bdb5                	j	247a <stpncpy+0x4e>
    2600:	00778713          	addi	a4,a5,7
    2604:	45ad                	li	a1,11
    2606:	fff60693          	addi	a3,a2,-1
    260a:	e6b778e3          	bgeu	a4,a1,247a <stpncpy+0x4e>
    260e:	b7fd                	j	25fc <stpncpy+0x1d0>
    2610:	40a007b3          	neg	a5,a0
    2614:	8832                	mv	a6,a2
    2616:	8b9d                	andi	a5,a5,7
    2618:	4681                	li	a3,0
    261a:	e4060be3          	beqz	a2,2470 <stpncpy+0x44>
    261e:	b7cd                	j	2600 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2620:	468d                	li	a3,3
    2622:	bd75                	j	24de <stpncpy+0xb2>
    2624:	872a                	mv	a4,a0
    2626:	4681                	li	a3,0
    2628:	bd5d                	j	24de <stpncpy+0xb2>
    262a:	4685                	li	a3,1
    262c:	bd4d                	j	24de <stpncpy+0xb2>
    262e:	8082                	ret
    2630:	87aa                	mv	a5,a0
    2632:	4681                	li	a3,0
    2634:	b5f9                	j	2502 <stpncpy+0xd6>
    2636:	4689                	li	a3,2
    2638:	b55d                	j	24de <stpncpy+0xb2>
    263a:	4691                	li	a3,4
    263c:	b54d                	j	24de <stpncpy+0xb2>
    263e:	4695                	li	a3,5
    2640:	bd79                	j	24de <stpncpy+0xb2>
    2642:	4699                	li	a3,6
    2644:	bd69                	j	24de <stpncpy+0xb2>
    2646:	8082                	ret
    2648:	8082                	ret
    264a:	8082                	ret

000000000000264c <basename>:

char *basename(char *s)
{
    264c:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    264e:	c54d                	beqz	a0,26f8 <basename+0xac>
    2650:	00054783          	lbu	a5,0(a0)
		return ".";
    2654:	00000517          	auipc	a0,0x0
    2658:	6ec50513          	addi	a0,a0,1772 # 2d40 <enable_deadlock_detect+0x2fc>
	if (!s || !*s)
    265c:	e391                	bnez	a5,2660 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    265e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2660:	0076f713          	andi	a4,a3,7
    2664:	87b6                	mv	a5,a3
    2666:	cf51                	beqz	a4,2702 <basename+0xb6>
    2668:	0785                	addi	a5,a5,1
    266a:	0077f713          	andi	a4,a5,7
    266e:	c729                	beqz	a4,26b8 <basename+0x6c>
		if (!*s)
    2670:	0007c703          	lbu	a4,0(a5)
    2674:	fb75                	bnez	a4,2668 <basename+0x1c>
	return s - a;
    2676:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2678:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    267a:	cf8d                	beqz	a5,26b4 <basename+0x68>
    267c:	00f68733          	add	a4,a3,a5
    2680:	02f00593          	li	a1,47
    2684:	a031                	j	2690 <basename+0x44>
		s[i] = 0;
    2686:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    268a:	17fd                	addi	a5,a5,-1
    268c:	177d                	addi	a4,a4,-1
    268e:	c39d                	beqz	a5,26b4 <basename+0x68>
    2690:	00074603          	lbu	a2,0(a4)
    2694:	feb609e3          	beq	a2,a1,2686 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2698:	02f00613          	li	a2,47
    269c:	a011                	j	26a0 <basename+0x54>
    269e:	cb99                	beqz	a5,26b4 <basename+0x68>
    26a0:	853e                	mv	a0,a5
    26a2:	17fd                	addi	a5,a5,-1
    26a4:	00f68733          	add	a4,a3,a5
    26a8:	00074703          	lbu	a4,0(a4)
    26ac:	fec719e3          	bne	a4,a2,269e <basename+0x52>
	return s + i;
    26b0:	9536                	add	a0,a0,a3
    26b2:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    26b4:	8536                	mv	a0,a3
    26b6:	8082                	ret
    26b8:	6390                	ld	a2,0(a5)
    26ba:	00000517          	auipc	a0,0x0
    26be:	68e53503          	ld	a0,1678(a0) # 2d48 <enable_deadlock_detect+0x304>
    26c2:	00000597          	auipc	a1,0x0
    26c6:	68e5b583          	ld	a1,1678(a1) # 2d50 <enable_deadlock_detect+0x30c>
    26ca:	fff64713          	not	a4,a2
    26ce:	962a                	add	a2,a2,a0
    26d0:	8f71                	and	a4,a4,a2
    26d2:	8f6d                	and	a4,a4,a1
    26d4:	eb11                	bnez	a4,26e8 <basename+0x9c>
    26d6:	6790                	ld	a2,8(a5)
    26d8:	07a1                	addi	a5,a5,8
    26da:	00a60733          	add	a4,a2,a0
    26de:	fff64613          	not	a2,a2
    26e2:	8f71                	and	a4,a4,a2
    26e4:	8f6d                	and	a4,a4,a1
    26e6:	db65                	beqz	a4,26d6 <basename+0x8a>
	for (; *s; s++)
    26e8:	0007c703          	lbu	a4,0(a5)
    26ec:	d749                	beqz	a4,2676 <basename+0x2a>
    26ee:	0017c703          	lbu	a4,1(a5)
    26f2:	0785                	addi	a5,a5,1
    26f4:	ff6d                	bnez	a4,26ee <basename+0xa2>
    26f6:	b741                	j	2676 <basename+0x2a>
		return ".";
    26f8:	00000517          	auipc	a0,0x0
    26fc:	64850513          	addi	a0,a0,1608 # 2d40 <enable_deadlock_detect+0x2fc>
    2700:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2702:	6290                	ld	a2,0(a3)
    2704:	00000517          	auipc	a0,0x0
    2708:	64453503          	ld	a0,1604(a0) # 2d48 <enable_deadlock_detect+0x304>
    270c:	00000597          	auipc	a1,0x0
    2710:	6445b583          	ld	a1,1604(a1) # 2d50 <enable_deadlock_detect+0x30c>
    2714:	fff64713          	not	a4,a2
    2718:	962a                	add	a2,a2,a0
    271a:	8f71                	and	a4,a4,a2
    271c:	8f6d                	and	a4,a4,a1
    271e:	df45                	beqz	a4,26d6 <basename+0x8a>
    2720:	b7f9                	j	26ee <basename+0xa2>

0000000000002722 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2722:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2726:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2728:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    272c:	2501                	sext.w	a0,a0
    272e:	8082                	ret

0000000000002730 <close>:

int close(int fd)
{
	if (fd == 1) {
    2730:	4785                	li	a5,1
    2732:	00f50863          	beq	a0,a5,2742 <close+0x12>
	register long a7 __asm__("a7") = n;
    2736:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    273a:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    273e:	2501                	sext.w	a0,a0
    2740:	8082                	ret
{
    2742:	1101                	addi	sp,sp,-32
    2744:	ec06                	sd	ra,24(sp)
    2746:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2748:	cdffe0ef          	jal	ra,1426 <__write_buffer>
		__clear_buffer();
    274c:	d03fe0ef          	jal	ra,144e <__clear_buffer>
    2750:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2752:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2756:	00000073          	ecall
}
    275a:	60e2                	ld	ra,24(sp)
    275c:	2501                	sext.w	a0,a0
    275e:	6105                	addi	sp,sp,32
    2760:	8082                	ret

0000000000002762 <read>:
	register long a7 __asm__("a7") = n;
    2762:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2766:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    276a:	8082                	ret

000000000000276c <write>:
	register long a7 __asm__("a7") = n;
    276c:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2770:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2774:	8082                	ret

0000000000002776 <getpid>:
	register long a7 __asm__("a7") = n;
    2776:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    277a:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    277e:	2501                	sext.w	a0,a0
    2780:	8082                	ret

0000000000002782 <getppid>:
	register long a7 __asm__("a7") = n;
    2782:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2786:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    278a:	2501                	sext.w	a0,a0
    278c:	8082                	ret

000000000000278e <sched_yield>:
	register long a7 __asm__("a7") = n;
    278e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2792:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2796:	2501                	sext.w	a0,a0
    2798:	8082                	ret

000000000000279a <fork>:
	register long a7 __asm__("a7") = n;
    279a:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    279e:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    27a2:	2501                	sext.w	a0,a0
    27a4:	8082                	ret

00000000000027a6 <exit>:

void exit(int code)
{
    27a6:	1141                	addi	sp,sp,-16
    27a8:	e406                	sd	ra,8(sp)
    27aa:	e022                	sd	s0,0(sp)
    27ac:	842a                	mv	s0,a0
	__write_buffer();
    27ae:	c79fe0ef          	jal	ra,1426 <__write_buffer>
	__clear_buffer();
    27b2:	c9dfe0ef          	jal	ra,144e <__clear_buffer>
	register long a7 __asm__("a7") = n;
    27b6:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    27ba:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    27bc:	00000073          	ecall
	syscall(SYS_exit, code);
}
    27c0:	60a2                	ld	ra,8(sp)
    27c2:	6402                	ld	s0,0(sp)
    27c4:	0141                	addi	sp,sp,16
    27c6:	8082                	ret

00000000000027c8 <waitpid>:
	register long a7 __asm__("a7") = n;
    27c8:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27cc:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    27d0:	2501                	sext.w	a0,a0
    27d2:	8082                	ret

00000000000027d4 <exec>:
	register long a7 __asm__("a7") = n;
    27d4:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27d8:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    27dc:	2501                	sext.w	a0,a0
    27de:	8082                	ret

00000000000027e0 <get_mtime>:

int64 get_mtime()
{
    27e0:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    27e2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    27e6:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    27e8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ea:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    27ee:	2501                	sext.w	a0,a0
    27f0:	ed01                	bnez	a0,2808 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    27f2:	6722                	ld	a4,8(sp)
    27f4:	3e800793          	li	a5,1000
    27f8:	6682                	ld	a3,0(sp)
    27fa:	02f75733          	divu	a4,a4,a5
    27fe:	02d78533          	mul	a0,a5,a3
    2802:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2804:	0141                	addi	sp,sp,16
    2806:	8082                	ret
	return -1;
    2808:	557d                	li	a0,-1
    280a:	bfed                	j	2804 <get_mtime+0x24>

000000000000280c <sys_get_time>:
	register long a7 __asm__("a7") = n;
    280c:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2810:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2814:	2501                	sext.w	a0,a0
    2816:	8082                	ret

0000000000002818 <sleep>:

int sleep(unsigned long long time)
{
    2818:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    281a:	880a                	mv	a6,sp
{
    281c:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    281e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2822:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2824:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2826:	00000073          	ecall
	if (err == 0) {
    282a:	2501                	sext.w	a0,a0
    282c:	ed31                	bnez	a0,2888 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    282e:	6722                	ld	a4,8(sp)
    2830:	3e800793          	li	a5,1000
    2834:	6682                	ld	a3,0(sp)
    2836:	02f75733          	divu	a4,a4,a5
    283a:	02d787b3          	mul	a5,a5,a3
    283e:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2840:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2844:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2846:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2848:	00000073          	ecall
	if (err == 0) {
    284c:	2501                	sext.w	a0,a0
    284e:	e915                	bnez	a0,2882 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2850:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2852:	3e800693          	li	a3,1000
    2856:	a819                	j	286c <sleep+0x54>
	__asm_syscall("r"(a7))
    2858:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    285c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2860:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2862:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2864:	00000073          	ecall
	if (err == 0) {
    2868:	2501                	sext.w	a0,a0
    286a:	ed01                	bnez	a0,2882 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    286c:	6722                	ld	a4,8(sp)
    286e:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2870:	07c00893          	li	a7,124
    2874:	02d75733          	divu	a4,a4,a3
    2878:	02f687b3          	mul	a5,a3,a5
    287c:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    287e:	fcc7ede3          	bltu	a5,a2,2858 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2882:	4501                	li	a0,0
    2884:	0141                	addi	sp,sp,16
    2886:	8082                	ret
    2888:	57fd                	li	a5,-1
    288a:	bf5d                	j	2840 <sleep+0x28>

000000000000288c <sys_task_info>:
	register long a7 __asm__("a7") = n;
    288c:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2890:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2894:	2501                	sext.w	a0,a0
    2896:	8082                	ret

0000000000002898 <set_priority>:
	register long a7 __asm__("a7") = n;
    2898:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    289c:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    28a0:	2501                	sext.w	a0,a0
    28a2:	8082                	ret

00000000000028a4 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    28a4:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    28a8:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    28ac:	2501                	sext.w	a0,a0
    28ae:	8082                	ret

00000000000028b0 <munmap>:
	register long a7 __asm__("a7") = n;
    28b0:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28b4:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    28b8:	2501                	sext.w	a0,a0
    28ba:	8082                	ret

00000000000028bc <wait>:

int wait(int *code)
{
    28bc:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    28be:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    28c2:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28c4:	00000073          	ecall
	return waitpid(-1, code);
}
    28c8:	2501                	sext.w	a0,a0
    28ca:	8082                	ret

00000000000028cc <spawn>:
	register long a7 __asm__("a7") = n;
    28cc:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    28d0:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    28d4:	2501                	sext.w	a0,a0
    28d6:	8082                	ret

00000000000028d8 <pipe>:
	register long a7 __asm__("a7") = n;
    28d8:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    28dc:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    28e0:	2501                	sext.w	a0,a0
    28e2:	8082                	ret

00000000000028e4 <mailread>:
	register long a7 __asm__("a7") = n;
    28e4:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28e8:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    28ec:	2501                	sext.w	a0,a0
    28ee:	8082                	ret

00000000000028f0 <mailwrite>:
	register long a7 __asm__("a7") = n;
    28f0:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    28f4:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    28f8:	2501                	sext.w	a0,a0
    28fa:	8082                	ret

00000000000028fc <fstat>:
	register long a7 __asm__("a7") = n;
    28fc:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2900:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2904:	2501                	sext.w	a0,a0
    2906:	8082                	ret

0000000000002908 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2908:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    290a:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    290e:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2910:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2914:	2501                	sext.w	a0,a0
    2916:	8082                	ret

0000000000002918 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2918:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    291a:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    291e:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2920:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2924:	2501                	sext.w	a0,a0
    2926:	8082                	ret

0000000000002928 <link>:

int link(char *old_path, char *new_path)
{
    2928:	87aa                	mv	a5,a0
    292a:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    292c:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2930:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2934:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2936:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    293a:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    293c:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2940:	2501                	sext.w	a0,a0
    2942:	8082                	ret

0000000000002944 <unlink>:

int unlink(char *path)
{
    2944:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2946:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    294a:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    294e:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2950:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2954:	2501                	sext.w	a0,a0
    2956:	8082                	ret

0000000000002958 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2958:	00000797          	auipc	a5,0x0
    295c:	5487b783          	ld	a5,1352(a5) # 2ea0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2960:	439c                	lw	a5,0(a5)
    2962:	c799                	beqz	a5,2970 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2964:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2968:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    296c:	2501                	sext.w	a0,a0
    296e:	8082                	ret
{
    2970:	1101                	addi	sp,sp,-32
    2972:	ec06                	sd	ra,24(sp)
    2974:	e42e                	sd	a1,8(sp)
    2976:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2978:	fe7fe0ef          	jal	ra,195e <enable_thread_io_buffer>
    297c:	65a2                	ld	a1,8(sp)
    297e:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2980:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2984:	00000073          	ecall
}
    2988:	60e2                	ld	ra,24(sp)
    298a:	2501                	sext.w	a0,a0
    298c:	6105                	addi	sp,sp,32
    298e:	8082                	ret

0000000000002990 <gettid>:
	register long a7 __asm__("a7") = n;
    2990:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2994:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2998:	2501                	sext.w	a0,a0
    299a:	8082                	ret

000000000000299c <waittid>:

int waittid(int tid)
{
    299c:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    299e:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    29a2:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    29a6:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    29a8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    29aa:	00e51e63          	bne	a0,a4,29c6 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    29ae:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    29b2:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    29b6:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    29ba:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    29bc:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    29c0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    29c2:	fee506e3          	beq	a0,a4,29ae <waittid+0x12>
	}
	return ret;
}
    29c6:	8082                	ret

00000000000029c8 <mutex_create>:
	register long a7 __asm__("a7") = n;
    29c8:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    29cc:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    29ce:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    29d2:	2501                	sext.w	a0,a0
    29d4:	8082                	ret

00000000000029d6 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    29d6:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    29da:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    29dc:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    29e0:	2501                	sext.w	a0,a0
    29e2:	8082                	ret

00000000000029e4 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    29e4:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    29e8:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    29ec:	2501                	sext.w	a0,a0
    29ee:	8082                	ret

00000000000029f0 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    29f0:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    29f4:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    29f8:	2501                	sext.w	a0,a0
    29fa:	8082                	ret

00000000000029fc <semaphore_create>:
	register long a7 __asm__("a7") = n;
    29fc:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2a00:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2a04:	2501                	sext.w	a0,a0
    2a06:	8082                	ret

0000000000002a08 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2a08:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2a0c:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2a10:	2501                	sext.w	a0,a0
    2a12:	8082                	ret

0000000000002a14 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2a14:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2a18:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2a1c:	2501                	sext.w	a0,a0
    2a1e:	8082                	ret

0000000000002a20 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2a20:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2a24:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2a28:	2501                	sext.w	a0,a0
    2a2a:	8082                	ret

0000000000002a2c <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2a2c:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2a30:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2a34:	2501                	sext.w	a0,a0
    2a36:	8082                	ret

0000000000002a38 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2a38:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2a3c:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2a40:	2501                	sext.w	a0,a0
    2a42:	8082                	ret

0000000000002a44 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2a44:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2a48:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2a4c:	2501                	sext.w	a0,a0
    2a4e:	8082                	ret
