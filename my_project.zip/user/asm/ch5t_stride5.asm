
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5t_stride5:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0bd                	j	106e <__start_main>

0000000000001002 <spin_delay>:
{
	int j = 1;
	for (int _ = 0; _ < 10; ++_) {
		j = !j;
	}
}
    1002:	8082                	ret

0000000000001004 <count_during>:

// to get enough accuracy, MAX_TIME (the running time of each process) should >
// 1000 mseconds.
const int MAX_TIME = 1000;
int count_during(int prio)
{
    1004:	7179                	addi	sp,sp,-48
    1006:	f406                	sd	ra,40(sp)
    1008:	f022                	sd	s0,32(sp)
    100a:	ec26                	sd	s1,24(sp)
    100c:	842a                	mv	s0,a0
    100e:	e84a                	sd	s2,16(sp)
    1010:	e44e                	sd	s3,8(sp)
	uint64 start_time = get_mtime();
    1012:	452010ef          	jal	ra,2464 <get_mtime>
    1016:	892a                	mv	s2,a0
	int acc = 0;
	set_priority(prio);
    1018:	8522                	mv	a0,s0
    101a:	502010ef          	jal	ra,251c <set_priority>
	for (;;) {
		spin_delay();
		acc += 1;
    101e:	4405                	li	s0,1
    1020:	19000493          	li	s1,400
		if (acc % 400 == 0) {
			uint64 time = get_mtime() - start_time;
			if (time > MAX_TIME) {
    1024:	3e800993          	li	s3,1000
		acc += 1;
    1028:	2405                	addiw	s0,s0,1
		if (acc % 400 == 0) {
    102a:	0294673b          	remw	a4,s0,s1
    102e:	ff6d                	bnez	a4,1028 <count_during+0x24>
			uint64 time = get_mtime() - start_time;
    1030:	434010ef          	jal	ra,2464 <get_mtime>
    1034:	41250533          	sub	a0,a0,s2
			if (time > MAX_TIME) {
    1038:	fea9f8e3          	bgeu	s3,a0,1028 <count_during+0x24>
				return acc;
			}
		}
	}
}
    103c:	70a2                	ld	ra,40(sp)
    103e:	8522                	mv	a0,s0
    1040:	7402                	ld	s0,32(sp)
    1042:	64e2                	ld	s1,24(sp)
    1044:	6942                	ld	s2,16(sp)
    1046:	69a2                	ld	s3,8(sp)
    1048:	6145                	addi	sp,sp,48
    104a:	8082                	ret

000000000000104c <main>:

int main()
{
    104c:	1141                	addi	sp,sp,-16
	int prio = 10;
	int count = count_during(prio);
    104e:	4529                	li	a0,10
{
    1050:	e406                	sd	ra,8(sp)
	int count = count_during(prio);
    1052:	fb3ff0ef          	jal	ra,1004 <count_during>
    1056:	862a                	mv	a2,a0
	printf("priority = %d, exitcode = %d\n", prio, count);
    1058:	45a9                	li	a1,10
    105a:	00001517          	auipc	a0,0x1
    105e:	67e50513          	addi	a0,a0,1662 # 26d8 <enable_deadlock_detect+0x10>
    1062:	166000ef          	jal	ra,11c8 <printf>
	return 0;
    1066:	60a2                	ld	ra,8(sp)
    1068:	4501                	li	a0,0
    106a:	0141                	addi	sp,sp,16
    106c:	8082                	ret

000000000000106e <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    106e:	1141                	addi	sp,sp,-16
    1070:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1072:	fdbff0ef          	jal	ra,104c <main>
    1076:	3b4010ef          	jal	ra,242a <exit>
	return 0;
    107a:	60a2                	ld	ra,8(sp)
    107c:	4501                	li	a0,0
    107e:	0141                	addi	sp,sp,16
    1080:	8082                	ret

0000000000001082 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1082:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1084:	4605                	li	a2,1
    1086:	00f10593          	addi	a1,sp,15
    108a:	4501                	li	a0,0
{
    108c:	ec06                	sd	ra,24(sp)
	char byte = 0;
    108e:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1092:	354010ef          	jal	ra,23e6 <read>
    1096:	4785                	li	a5,1
    1098:	00f51763          	bne	a0,a5,10a6 <getchar+0x24>
		return byte;
    109c:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10a0:	60e2                	ld	ra,24(sp)
    10a2:	6105                	addi	sp,sp,32
    10a4:	8082                	ret
		return EOF;
    10a6:	557d                	li	a0,-1
    10a8:	bfe5                	j	10a0 <getchar+0x1e>

00000000000010aa <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10aa:	00001517          	auipc	a0,0x1
    10ae:	74e52503          	lw	a0,1870(a0) # 27f8 <buffer_len>
    10b2:	e111                	bnez	a0,10b6 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10b4:	8082                	ret
{
    10b6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10b8:	862a                	mv	a2,a0
    10ba:	00001597          	auipc	a1,0x1
    10be:	74658593          	addi	a1,a1,1862 # 2800 <buffer>
    10c2:	4505                	li	a0,1
{
    10c4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10c6:	32a010ef          	jal	ra,23f0 <write>
}
    10ca:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10cc:	2501                	sext.w	a0,a0
}
    10ce:	0141                	addi	sp,sp,16
    10d0:	8082                	ret

00000000000010d2 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10d2:	00001797          	auipc	a5,0x1
    10d6:	7207a323          	sw	zero,1830(a5) # 27f8 <buffer_len>
}
    10da:	8082                	ret

00000000000010dc <__fflush>:
	if (buffer_len == 0)
    10dc:	00001517          	auipc	a0,0x1
    10e0:	71c52503          	lw	a0,1820(a0) # 27f8 <buffer_len>
    10e4:	e511                	bnez	a0,10f0 <__fflush+0x14>
	buffer_len = 0;
    10e6:	00001797          	auipc	a5,0x1
    10ea:	7007a923          	sw	zero,1810(a5) # 27f8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10ee:	8082                	ret
{
    10f0:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10f2:	862a                	mv	a2,a0
    10f4:	00001597          	auipc	a1,0x1
    10f8:	70c58593          	addi	a1,a1,1804 # 2800 <buffer>
    10fc:	4505                	li	a0,1
{
    10fe:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1100:	2f0010ef          	jal	ra,23f0 <write>
	return r >= 0 ? 0 : r;
    1104:	0005079b          	sext.w	a5,a0
}
    1108:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    110a:	0017a793          	slti	a5,a5,1
    110e:	40f007bb          	negw	a5,a5
    1112:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1114:	00001797          	auipc	a5,0x1
    1118:	6e07a223          	sw	zero,1764(a5) # 27f8 <buffer_len>
	return r >= 0 ? 0 : r;
    111c:	2501                	sext.w	a0,a0
}
    111e:	0141                	addi	sp,sp,16
    1120:	8082                	ret

0000000000001122 <fflush>:

int fflush(int fd)
{
    1122:	1101                	addi	sp,sp,-32
    1124:	e822                	sd	s0,16(sp)
    1126:	ec06                	sd	ra,24(sp)
    1128:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    112a:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    112c:	4401                	li	s0,0
	if (fd == 1) {
    112e:	00e50863          	beq	a0,a4,113e <fflush+0x1c>
}
    1132:	60e2                	ld	ra,24(sp)
    1134:	8522                	mv	a0,s0
    1136:	6442                	ld	s0,16(sp)
    1138:	64a2                	ld	s1,8(sp)
    113a:	6105                	addi	sp,sp,32
    113c:	8082                	ret
		if (buffer_lock_enabled == 1) {
    113e:	00001497          	auipc	s1,0x1
    1142:	6ba48493          	addi	s1,s1,1722 # 27f8 <buffer_len>
    1146:	1084a703          	lw	a4,264(s1)
    114a:	02a70e63          	beq	a4,a0,1186 <fflush+0x64>
	if (buffer_len == 0)
    114e:	4080                	lw	s0,0(s1)
    1150:	c00d                	beqz	s0,1172 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1152:	8622                	mv	a2,s0
    1154:	00001597          	auipc	a1,0x1
    1158:	6ac58593          	addi	a1,a1,1708 # 2800 <buffer>
    115c:	294010ef          	jal	ra,23f0 <write>
	return r >= 0 ? 0 : r;
    1160:	0005079b          	sext.w	a5,a0
    1164:	0017a793          	slti	a5,a5,1
    1168:	40f007bb          	negw	a5,a5
    116c:	8d7d                	and	a0,a0,a5
    116e:	0005041b          	sext.w	s0,a0
}
    1172:	60e2                	ld	ra,24(sp)
    1174:	8522                	mv	a0,s0
    1176:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1178:	00001797          	auipc	a5,0x1
    117c:	6807a023          	sw	zero,1664(a5) # 27f8 <buffer_len>
}
    1180:	64a2                	ld	s1,8(sp)
    1182:	6105                	addi	sp,sp,32
    1184:	8082                	ret
			mutex_lock(buffer_lock);
    1186:	10c4a503          	lw	a0,268(s1)
    118a:	4de010ef          	jal	ra,2668 <mutex_lock>
	if (buffer_len == 0)
    118e:	4080                	lw	s0,0(s1)
    1190:	e811                	bnez	s0,11a4 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1192:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1196:	00001797          	auipc	a5,0x1
    119a:	6607a123          	sw	zero,1634(a5) # 27f8 <buffer_len>
			mutex_unlock(buffer_lock);
    119e:	4d6010ef          	jal	ra,2674 <mutex_unlock>
    11a2:	bf41                	j	1132 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11a4:	8622                	mv	a2,s0
    11a6:	00001597          	auipc	a1,0x1
    11aa:	65a58593          	addi	a1,a1,1626 # 2800 <buffer>
    11ae:	4505                	li	a0,1
    11b0:	240010ef          	jal	ra,23f0 <write>
	return r >= 0 ? 0 : r;
    11b4:	0005079b          	sext.w	a5,a0
    11b8:	0017a793          	slti	a5,a5,1
    11bc:	40f007bb          	negw	a5,a5
    11c0:	8d7d                	and	a0,a0,a5
    11c2:	0005041b          	sext.w	s0,a0
	return r;
    11c6:	b7f1                	j	1192 <fflush+0x70>

00000000000011c8 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11c8:	7131                	addi	sp,sp,-192
    11ca:	e0da                	sd	s6,64(sp)
    11cc:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11ce:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11d0:	013c                	addi	a5,sp,136
{
    11d2:	f0ca                	sd	s2,96(sp)
    11d4:	ecce                	sd	s3,88(sp)
    11d6:	e8d2                	sd	s4,80(sp)
    11d8:	e4d6                	sd	s5,72(sp)
    11da:	fc86                	sd	ra,120(sp)
    11dc:	f8a2                	sd	s0,112(sp)
    11de:	f4a6                	sd	s1,104(sp)
    11e0:	89aa                	mv	s3,a0
    11e2:	e52e                	sd	a1,136(sp)
    11e4:	e932                	sd	a2,144(sp)
    11e6:	ed36                	sd	a3,152(sp)
    11e8:	f13a                	sd	a4,160(sp)
    11ea:	f942                	sd	a6,176(sp)
    11ec:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11ee:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11f0:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11f4:	00001a17          	auipc	s4,0x1
    11f8:	604a0a13          	addi	s4,s4,1540 # 27f8 <buffer_len>
    11fc:	4a85                	li	s5,1
	buf[i++] = '0';
    11fe:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1202:	0009c783          	lbu	a5,0(s3)
    1206:	18078663          	beqz	a5,1392 <printf+0x1ca>
    120a:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    120c:	19278d63          	beq	a5,s2,13a6 <printf+0x1de>
    1210:	0015c783          	lbu	a5,1(a1)
    1214:	0585                	addi	a1,a1,1
    1216:	fbfd                	bnez	a5,120c <printf+0x44>
    1218:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    121a:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    121e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1222:	1b578863          	beq	a5,s5,13d2 <printf+0x20a>
		len = out_unlocked(s, l);
    1226:	85a2                	mv	a1,s0
    1228:	854e                	mv	a0,s3
    122a:	42a000ef          	jal	ra,1654 <out_unlocked>
		out(f, a, l);
		if (l)
    122e:	1c041063          	bnez	s0,13ee <printf+0x226>
			continue;
		if (s[1] == 0)
    1232:	0014c783          	lbu	a5,1(s1)
    1236:	14078e63          	beqz	a5,1392 <printf+0x1ca>
			break;
		switch (s[1]) {
    123a:	07300713          	li	a4,115
    123e:	1ce78863          	beq	a5,a4,140e <printf+0x246>
    1242:	1af76863          	bltu	a4,a5,13f2 <printf+0x22a>
    1246:	06400713          	li	a4,100
    124a:	22e78063          	beq	a5,a4,146a <printf+0x2a2>
    124e:	07000713          	li	a4,112
    1252:	1ee79563          	bne	a5,a4,143c <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1256:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1258:	00001797          	auipc	a5,0x1
    125c:	6b878793          	addi	a5,a5,1720 # 2910 <digits>
	buf[i++] = '0';
    1260:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1264:	6298                	ld	a4,0(a3)
    1266:	06a1                	addi	a3,a3,8
    1268:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    126a:	00471393          	slli	t2,a4,0x4
    126e:	00871293          	slli	t0,a4,0x8
    1272:	00c71f93          	slli	t6,a4,0xc
    1276:	01071f13          	slli	t5,a4,0x10
    127a:	01471e93          	slli	t4,a4,0x14
    127e:	01871e13          	slli	t3,a4,0x18
    1282:	01c71893          	slli	a7,a4,0x1c
    1286:	02471813          	slli	a6,a4,0x24
    128a:	02871513          	slli	a0,a4,0x28
    128e:	02c71593          	slli	a1,a4,0x2c
    1292:	03071613          	slli	a2,a4,0x30
    1296:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    129a:	03c75413          	srli	s0,a4,0x3c
    129e:	01c7531b          	srliw	t1,a4,0x1c
    12a2:	03c3d393          	srli	t2,t2,0x3c
    12a6:	03c2d293          	srli	t0,t0,0x3c
    12aa:	03cfdf93          	srli	t6,t6,0x3c
    12ae:	03cf5f13          	srli	t5,t5,0x3c
    12b2:	03cede93          	srli	t4,t4,0x3c
    12b6:	03ce5e13          	srli	t3,t3,0x3c
    12ba:	03c8d893          	srli	a7,a7,0x3c
    12be:	03c85813          	srli	a6,a6,0x3c
    12c2:	9171                	srli	a0,a0,0x3c
    12c4:	91f1                	srli	a1,a1,0x3c
    12c6:	9271                	srli	a2,a2,0x3c
    12c8:	92f1                	srli	a3,a3,0x3c
    12ca:	95be                	add	a1,a1,a5
    12cc:	963e                	add	a2,a2,a5
    12ce:	96be                	add	a3,a3,a5
    12d0:	943e                	add	s0,s0,a5
    12d2:	93be                	add	t2,t2,a5
    12d4:	92be                	add	t0,t0,a5
    12d6:	9fbe                	add	t6,t6,a5
    12d8:	9f3e                	add	t5,t5,a5
    12da:	9ebe                	add	t4,t4,a5
    12dc:	9e3e                	add	t3,t3,a5
    12de:	98be                	add	a7,a7,a5
    12e0:	933e                	add	t1,t1,a5
    12e2:	983e                	add	a6,a6,a5
    12e4:	953e                	add	a0,a0,a5
    12e6:	0005c983          	lbu	s3,0(a1)
    12ea:	00044403          	lbu	s0,0(s0)
    12ee:	00064583          	lbu	a1,0(a2)
    12f2:	0003c383          	lbu	t2,0(t2)
    12f6:	0006c603          	lbu	a2,0(a3)
    12fa:	0002c283          	lbu	t0,0(t0)
    12fe:	000fcf83          	lbu	t6,0(t6)
    1302:	000f4f03          	lbu	t5,0(t5)
    1306:	000ece83          	lbu	t4,0(t4)
    130a:	000e4e03          	lbu	t3,0(t3)
    130e:	0008c883          	lbu	a7,0(a7)
    1312:	00034303          	lbu	t1,0(t1)
    1316:	00084803          	lbu	a6,0(a6)
    131a:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    131e:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1322:	92f1                	srli	a3,a3,0x3c
    1324:	8b3d                	andi	a4,a4,15
    1326:	96be                	add	a3,a3,a5
    1328:	97ba                	add	a5,a5,a4
    132a:	00810d23          	sb	s0,26(sp)
    132e:	00710da3          	sb	t2,27(sp)
    1332:	00510e23          	sb	t0,28(sp)
    1336:	01f10ea3          	sb	t6,29(sp)
    133a:	01e10f23          	sb	t5,30(sp)
    133e:	01d10fa3          	sb	t4,31(sp)
    1342:	03c10023          	sb	t3,32(sp)
    1346:	031100a3          	sb	a7,33(sp)
    134a:	02610123          	sb	t1,34(sp)
    134e:	030101a3          	sb	a6,35(sp)
    1352:	02a10223          	sb	a0,36(sp)
    1356:	033102a3          	sb	s3,37(sp)
    135a:	02b10323          	sb	a1,38(sp)
    135e:	02c103a3          	sb	a2,39(sp)
    1362:	0006c683          	lbu	a3,0(a3)
    1366:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    136a:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    136e:	02d10423          	sb	a3,40(sp)
    1372:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1376:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    137a:	11578263          	beq	a5,s5,147e <printf+0x2b6>
		len = out_unlocked(s, l);
    137e:	45c9                	li	a1,18
    1380:	0828                	addi	a0,sp,24
    1382:	2d2000ef          	jal	ra,1654 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1386:	00248993          	addi	s3,s1,2
		if (!*s)
    138a:	0009c783          	lbu	a5,0(s3)
    138e:	e6079ee3          	bnez	a5,120a <printf+0x42>
	}
	va_end(ap);
    1392:	70e6                	ld	ra,120(sp)
    1394:	7446                	ld	s0,112(sp)
    1396:	74a6                	ld	s1,104(sp)
    1398:	7906                	ld	s2,96(sp)
    139a:	69e6                	ld	s3,88(sp)
    139c:	6a46                	ld	s4,80(sp)
    139e:	6aa6                	ld	s5,72(sp)
    13a0:	6b06                	ld	s6,64(sp)
    13a2:	6129                	addi	sp,sp,192
    13a4:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13a6:	0005c783          	lbu	a5,0(a1)
    13aa:	84ae                	mv	s1,a1
    13ac:	01278963          	beq	a5,s2,13be <printf+0x1f6>
    13b0:	b5ad                	j	121a <printf+0x52>
    13b2:	0024c783          	lbu	a5,2(s1)
    13b6:	0585                	addi	a1,a1,1
    13b8:	0489                	addi	s1,s1,2
    13ba:	e72790e3          	bne	a5,s2,121a <printf+0x52>
    13be:	0014c783          	lbu	a5,1(s1)
    13c2:	ff2788e3          	beq	a5,s2,13b2 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13c6:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13ca:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13ce:	e5579ce3          	bne	a5,s5,1226 <printf+0x5e>
		mutex_lock(buffer_lock);
    13d2:	10ca2503          	lw	a0,268(s4)
    13d6:	292010ef          	jal	ra,2668 <mutex_lock>
		len = out_unlocked(s, l);
    13da:	85a2                	mv	a1,s0
    13dc:	854e                	mv	a0,s3
    13de:	276000ef          	jal	ra,1654 <out_unlocked>
		mutex_unlock(buffer_lock);
    13e2:	10ca2503          	lw	a0,268(s4)
    13e6:	28e010ef          	jal	ra,2674 <mutex_unlock>
		if (l)
    13ea:	e40404e3          	beqz	s0,1232 <printf+0x6a>
    13ee:	89a6                	mv	s3,s1
    13f0:	bd09                	j	1202 <printf+0x3a>
		switch (s[1]) {
    13f2:	07800713          	li	a4,120
    13f6:	04e79363          	bne	a5,a4,143c <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13fa:	67c2                	ld	a5,16(sp)
    13fc:	45c1                	li	a1,16
		s += 2;
    13fe:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1402:	4388                	lw	a0,0(a5)
    1404:	07a1                	addi	a5,a5,8
    1406:	e83e                	sd	a5,16(sp)
    1408:	5f8000ef          	jal	ra,1a00 <printint.constprop.0>
		s += 2;
    140c:	bfbd                	j	138a <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    140e:	67c2                	ld	a5,16(sp)
    1410:	6380                	ld	s0,0(a5)
    1412:	07a1                	addi	a5,a5,8
    1414:	e83e                	sd	a5,16(sp)
    1416:	1c040163          	beqz	s0,15d8 <printf+0x410>
			l = strnlen(a, 200);
    141a:	0c800593          	li	a1,200
    141e:	8522                	mv	a0,s0
    1420:	3f7000ef          	jal	ra,2016 <strnlen>
	if (buffer_lock_enabled == 1) {
    1424:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1428:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    142c:	19578663          	beq	a5,s5,15b8 <printf+0x3f0>
		len = out_unlocked(s, l);
    1430:	8522                	mv	a0,s0
    1432:	222000ef          	jal	ra,1654 <out_unlocked>
		s += 2;
    1436:	00248993          	addi	s3,s1,2
    143a:	bf81                	j	138a <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    143c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1440:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1444:	0f578663          	beq	a5,s5,1530 <printf+0x368>
		len = out_unlocked(s, l);
    1448:	0828                	addi	a0,sp,24
    144a:	316000ef          	jal	ra,1760 <out_unlocked.constprop.0>
			putchar(s[1]);
    144e:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1452:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1456:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    145a:	05578163          	beq	a5,s5,149c <printf+0x2d4>
		len = out_unlocked(s, l);
    145e:	0828                	addi	a0,sp,24
    1460:	300000ef          	jal	ra,1760 <out_unlocked.constprop.0>
		s += 2;
    1464:	00248993          	addi	s3,s1,2
    1468:	b70d                	j	138a <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    146a:	67c2                	ld	a5,16(sp)
    146c:	45a9                	li	a1,10
		s += 2;
    146e:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1472:	4388                	lw	a0,0(a5)
    1474:	07a1                	addi	a5,a5,8
    1476:	e83e                	sd	a5,16(sp)
    1478:	588000ef          	jal	ra,1a00 <printint.constprop.0>
		s += 2;
    147c:	b739                	j	138a <printf+0x1c2>
		mutex_lock(buffer_lock);
    147e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1482:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1486:	1e2010ef          	jal	ra,2668 <mutex_lock>
		len = out_unlocked(s, l);
    148a:	45c9                	li	a1,18
    148c:	0828                	addi	a0,sp,24
    148e:	1c6000ef          	jal	ra,1654 <out_unlocked>
		mutex_unlock(buffer_lock);
    1492:	10ca2503          	lw	a0,268(s4)
    1496:	1de010ef          	jal	ra,2674 <mutex_unlock>
		s += 2;
    149a:	bdc5                	j	138a <printf+0x1c2>
		mutex_lock(buffer_lock);
    149c:	10ca2503          	lw	a0,268(s4)
    14a0:	1c8010ef          	jal	ra,2668 <mutex_lock>
		buffer[buffer_len++] = c;
    14a4:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14a8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14ac:	0017861b          	addiw	a2,a5,1
    14b0:	97d2                	add	a5,a5,s4
    14b2:	00ca2023          	sw	a2,0(s4)
    14b6:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14ba:	00c6cc63          	blt	a3,a2,14d2 <printf+0x30a>
    14be:	47a9                	li	a5,10
    14c0:	06f40663          	beq	s0,a5,152c <printf+0x364>
		mutex_unlock(buffer_lock);
    14c4:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14c8:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14cc:	1a8010ef          	jal	ra,2674 <mutex_unlock>
		s += 2;
    14d0:	bd6d                	j	138a <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14d2:	10000793          	li	a5,256
    14d6:	00f61e63          	bne	a2,a5,14f2 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14da:	00001597          	auipc	a1,0x1
    14de:	32658593          	addi	a1,a1,806 # 2800 <buffer>
    14e2:	4505                	li	a0,1
    14e4:	70d000ef          	jal	ra,23f0 <write>
	buffer_len = 0;
    14e8:	00001797          	auipc	a5,0x1
    14ec:	3007a823          	sw	zero,784(a5) # 27f8 <buffer_len>
			if (r < 0) {
    14f0:	bfd1                	j	14c4 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14f2:	709000ef          	jal	ra,23fa <getpid>
    14f6:	842a                	mv	s0,a0
    14f8:	00001517          	auipc	a0,0x1
    14fc:	20850513          	addi	a0,a0,520 # 2700 <enable_deadlock_detect+0x38>
    1500:	5d1000ef          	jal	ra,22d0 <basename>
    1504:	872a                	mv	a4,a0
    1506:	00001617          	auipc	a2,0x1
    150a:	23a60613          	addi	a2,a2,570 # 2740 <enable_deadlock_detect+0x78>
    150e:	05400793          	li	a5,84
    1512:	86a2                	mv	a3,s0
    1514:	45fd                	li	a1,31
    1516:	00001517          	auipc	a0,0x1
    151a:	23250513          	addi	a0,a0,562 # 2748 <enable_deadlock_detect+0x80>
    151e:	cabff0ef          	jal	ra,11c8 <printf>
    1522:	557d                	li	a0,-1
    1524:	707000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    1528:	000a2603          	lw	a2,0(s4)
    152c:	de41                	beqz	a2,14c4 <printf+0x2fc>
    152e:	b775                	j	14da <printf+0x312>
		mutex_lock(buffer_lock);
    1530:	10ca2503          	lw	a0,268(s4)
    1534:	134010ef          	jal	ra,2668 <mutex_lock>
		buffer[buffer_len++] = c;
    1538:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    153c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1540:	0017861b          	addiw	a2,a5,1
    1544:	97d2                	add	a5,a5,s4
    1546:	00ca2023          	sw	a2,0(s4)
    154a:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    154e:	02c6d163          	bge	a3,a2,1570 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1552:	10000793          	li	a5,256
    1556:	02f61263          	bne	a2,a5,157a <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    155a:	00001597          	auipc	a1,0x1
    155e:	2a658593          	addi	a1,a1,678 # 2800 <buffer>
    1562:	4505                	li	a0,1
    1564:	68d000ef          	jal	ra,23f0 <write>
	buffer_len = 0;
    1568:	00001797          	auipc	a5,0x1
    156c:	2807a823          	sw	zero,656(a5) # 27f8 <buffer_len>
		mutex_unlock(buffer_lock);
    1570:	10ca2503          	lw	a0,268(s4)
    1574:	100010ef          	jal	ra,2674 <mutex_unlock>
    1578:	bdd9                	j	144e <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    157a:	681000ef          	jal	ra,23fa <getpid>
    157e:	842a                	mv	s0,a0
    1580:	00001517          	auipc	a0,0x1
    1584:	18050513          	addi	a0,a0,384 # 2700 <enable_deadlock_detect+0x38>
    1588:	549000ef          	jal	ra,22d0 <basename>
    158c:	872a                	mv	a4,a0
    158e:	00001617          	auipc	a2,0x1
    1592:	1b260613          	addi	a2,a2,434 # 2740 <enable_deadlock_detect+0x78>
    1596:	05400793          	li	a5,84
    159a:	86a2                	mv	a3,s0
    159c:	45fd                	li	a1,31
    159e:	00001517          	auipc	a0,0x1
    15a2:	1aa50513          	addi	a0,a0,426 # 2748 <enable_deadlock_detect+0x80>
    15a6:	c23ff0ef          	jal	ra,11c8 <printf>
    15aa:	557d                	li	a0,-1
    15ac:	67f000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    15b0:	000a2603          	lw	a2,0(s4)
    15b4:	de55                	beqz	a2,1570 <printf+0x3a8>
    15b6:	b755                	j	155a <printf+0x392>
		mutex_lock(buffer_lock);
    15b8:	10ca2503          	lw	a0,268(s4)
    15bc:	e42e                	sd	a1,8(sp)
		s += 2;
    15be:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15c2:	0a6010ef          	jal	ra,2668 <mutex_lock>
		len = out_unlocked(s, l);
    15c6:	65a2                	ld	a1,8(sp)
    15c8:	8522                	mv	a0,s0
    15ca:	08a000ef          	jal	ra,1654 <out_unlocked>
		mutex_unlock(buffer_lock);
    15ce:	10ca2503          	lw	a0,268(s4)
    15d2:	0a2010ef          	jal	ra,2674 <mutex_unlock>
		s += 2;
    15d6:	bb55                	j	138a <printf+0x1c2>
				a = "(null)";
    15d8:	00001417          	auipc	s0,0x1
    15dc:	12040413          	addi	s0,s0,288 # 26f8 <enable_deadlock_detect+0x30>
    15e0:	bd2d                	j	141a <printf+0x252>

00000000000015e2 <enable_thread_io_buffer>:
{
    15e2:	1101                	addi	sp,sp,-32
    15e4:	e822                	sd	s0,16(sp)
    15e6:	ec06                	sd	ra,24(sp)
    15e8:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15ea:	00001417          	auipc	s0,0x1
    15ee:	20e40413          	addi	s0,s0,526 # 27f8 <buffer_len>
    15f2:	05a010ef          	jal	ra,264c <mutex_create>
    15f6:	10a42623          	sw	a0,268(s0)
    15fa:	00054a63          	bltz	a0,160e <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15fe:	4785                	li	a5,1
}
    1600:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1602:	10f42423          	sw	a5,264(s0)
}
    1606:	6442                	ld	s0,16(sp)
    1608:	64a2                	ld	s1,8(sp)
    160a:	6105                	addi	sp,sp,32
    160c:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    160e:	5ed000ef          	jal	ra,23fa <getpid>
    1612:	84aa                	mv	s1,a0
    1614:	00001517          	auipc	a0,0x1
    1618:	0ec50513          	addi	a0,a0,236 # 2700 <enable_deadlock_detect+0x38>
    161c:	4b5000ef          	jal	ra,22d0 <basename>
    1620:	872a                	mv	a4,a0
    1622:	04800793          	li	a5,72
    1626:	86a6                	mv	a3,s1
    1628:	00001517          	auipc	a0,0x1
    162c:	16050513          	addi	a0,a0,352 # 2788 <enable_deadlock_detect+0xc0>
    1630:	00001617          	auipc	a2,0x1
    1634:	11060613          	addi	a2,a2,272 # 2740 <enable_deadlock_detect+0x78>
    1638:	45fd                	li	a1,31
    163a:	b8fff0ef          	jal	ra,11c8 <printf>
    163e:	557d                	li	a0,-1
    1640:	5eb000ef          	jal	ra,242a <exit>
	buffer_lock_enabled = 1;
    1644:	4785                	li	a5,1
}
    1646:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1648:	10f42423          	sw	a5,264(s0)
}
    164c:	6442                	ld	s0,16(sp)
    164e:	64a2                	ld	s1,8(sp)
    1650:	6105                	addi	sp,sp,32
    1652:	8082                	ret

0000000000001654 <out_unlocked>:
{
    1654:	7159                	addi	sp,sp,-112
    1656:	f486                	sd	ra,104(sp)
    1658:	f0a2                	sd	s0,96(sp)
    165a:	eca6                	sd	s1,88(sp)
    165c:	e8ca                	sd	s2,80(sp)
    165e:	e4ce                	sd	s3,72(sp)
    1660:	e0d2                	sd	s4,64(sp)
    1662:	fc56                	sd	s5,56(sp)
    1664:	f85a                	sd	s6,48(sp)
    1666:	f45e                	sd	s7,40(sp)
    1668:	f062                	sd	s8,32(sp)
    166a:	ec66                	sd	s9,24(sp)
    166c:	e86a                	sd	s10,16(sp)
    166e:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1670:	0e058663          	beqz	a1,175c <out_unlocked+0x108>
    1674:	842a                	mv	s0,a0
    1676:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    167a:	4981                	li	s3,0
    167c:	00001d17          	auipc	s10,0x1
    1680:	17cd0d13          	addi	s10,s10,380 # 27f8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1684:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1688:	00001b17          	auipc	s6,0x1
    168c:	178b0b13          	addi	s6,s6,376 # 2800 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1690:	10000a93          	li	s5,256
    1694:	00001c97          	auipc	s9,0x1
    1698:	06cc8c93          	addi	s9,s9,108 # 2700 <enable_deadlock_detect+0x38>
    169c:	00001c17          	auipc	s8,0x1
    16a0:	0a4c0c13          	addi	s8,s8,164 # 2740 <enable_deadlock_detect+0x78>
    16a4:	00001b97          	auipc	s7,0x1
    16a8:	0a4b8b93          	addi	s7,s7,164 # 2748 <enable_deadlock_detect+0x80>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ac:	4a29                	li	s4,10
    16ae:	a031                	j	16ba <out_unlocked+0x66>
    16b0:	09468863          	beq	a3,s4,1740 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16b4:	0405                	addi	s0,s0,1
    16b6:	04848163          	beq	s1,s0,16f8 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16ba:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16be:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16c2:	0017861b          	addiw	a2,a5,1
    16c6:	97ea                	add	a5,a5,s10
    16c8:	00cd2023          	sw	a2,0(s10)
    16cc:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16d0:	fec950e3          	bge	s2,a2,16b0 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16d4:	05561263          	bne	a2,s5,1718 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16d8:	85da                	mv	a1,s6
    16da:	4505                	li	a0,1
    16dc:	515000ef          	jal	ra,23f0 <write>
    16e0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16e2:	00001797          	auipc	a5,0x1
    16e6:	1007ab23          	sw	zero,278(a5) # 27f8 <buffer_len>
			if (r < 0) {
    16ea:	06054763          	bltz	a0,1758 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16ee:	0405                	addi	s0,s0,1
			ret += r;
    16f0:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16f4:	fc8493e3          	bne	s1,s0,16ba <out_unlocked+0x66>
}
    16f8:	70a6                	ld	ra,104(sp)
    16fa:	7406                	ld	s0,96(sp)
    16fc:	64e6                	ld	s1,88(sp)
    16fe:	6946                	ld	s2,80(sp)
    1700:	6a06                	ld	s4,64(sp)
    1702:	7ae2                	ld	s5,56(sp)
    1704:	7b42                	ld	s6,48(sp)
    1706:	7ba2                	ld	s7,40(sp)
    1708:	7c02                	ld	s8,32(sp)
    170a:	6ce2                	ld	s9,24(sp)
    170c:	6d42                	ld	s10,16(sp)
    170e:	6da2                	ld	s11,8(sp)
    1710:	854e                	mv	a0,s3
    1712:	69a6                	ld	s3,72(sp)
    1714:	6165                	addi	sp,sp,112
    1716:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1718:	4e3000ef          	jal	ra,23fa <getpid>
    171c:	8daa                	mv	s11,a0
    171e:	8566                	mv	a0,s9
    1720:	3b1000ef          	jal	ra,22d0 <basename>
    1724:	872a                	mv	a4,a0
    1726:	8662                	mv	a2,s8
    1728:	05400793          	li	a5,84
    172c:	86ee                	mv	a3,s11
    172e:	45fd                	li	a1,31
    1730:	855e                	mv	a0,s7
    1732:	a97ff0ef          	jal	ra,11c8 <printf>
    1736:	557d                	li	a0,-1
    1738:	4f3000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    173c:	000d2603          	lw	a2,0(s10)
    1740:	da35                	beqz	a2,16b4 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1742:	85da                	mv	a1,s6
    1744:	4505                	li	a0,1
    1746:	4ab000ef          	jal	ra,23f0 <write>
    174a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    174c:	00001797          	auipc	a5,0x1
    1750:	0a07a623          	sw	zero,172(a5) # 27f8 <buffer_len>
			if (r < 0) {
    1754:	f8055de3          	bgez	a0,16ee <out_unlocked+0x9a>
    1758:	89aa                	mv	s3,a0
    175a:	bf79                	j	16f8 <out_unlocked+0xa4>
	int ret = 0;
    175c:	4981                	li	s3,0
    175e:	bf69                	j	16f8 <out_unlocked+0xa4>

0000000000001760 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1760:	1101                	addi	sp,sp,-32
    1762:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1764:	00001497          	auipc	s1,0x1
    1768:	09448493          	addi	s1,s1,148 # 27f8 <buffer_len>
    176c:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    176e:	ec06                	sd	ra,24(sp)
    1770:	e822                	sd	s0,16(sp)
		char c = s[i];
    1772:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1776:	0017861b          	addiw	a2,a5,1
    177a:	97a6                	add	a5,a5,s1
    177c:	00e78423          	sb	a4,8(a5)
    1780:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1782:	0ff00793          	li	a5,255
    1786:	00c7cc63          	blt	a5,a2,179e <out_unlocked.constprop.0+0x3e>
    178a:	47a9                	li	a5,10
    178c:	06f70c63          	beq	a4,a5,1804 <out_unlocked.constprop.0+0xa4>
    1790:	4601                	li	a2,0
}
    1792:	60e2                	ld	ra,24(sp)
    1794:	6442                	ld	s0,16(sp)
    1796:	64a2                	ld	s1,8(sp)
    1798:	8532                	mv	a0,a2
    179a:	6105                	addi	sp,sp,32
    179c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    179e:	10000793          	li	a5,256
    17a2:	02f61563          	bne	a2,a5,17cc <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17a6:	00001597          	auipc	a1,0x1
    17aa:	05a58593          	addi	a1,a1,90 # 2800 <buffer>
    17ae:	4505                	li	a0,1
    17b0:	441000ef          	jal	ra,23f0 <write>
}
    17b4:	60e2                	ld	ra,24(sp)
    17b6:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17b8:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17bc:	00001797          	auipc	a5,0x1
    17c0:	0207ae23          	sw	zero,60(a5) # 27f8 <buffer_len>
}
    17c4:	64a2                	ld	s1,8(sp)
    17c6:	8532                	mv	a0,a2
    17c8:	6105                	addi	sp,sp,32
    17ca:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17cc:	42f000ef          	jal	ra,23fa <getpid>
    17d0:	842a                	mv	s0,a0
    17d2:	00001517          	auipc	a0,0x1
    17d6:	f2e50513          	addi	a0,a0,-210 # 2700 <enable_deadlock_detect+0x38>
    17da:	2f7000ef          	jal	ra,22d0 <basename>
    17de:	872a                	mv	a4,a0
    17e0:	00001617          	auipc	a2,0x1
    17e4:	f6060613          	addi	a2,a2,-160 # 2740 <enable_deadlock_detect+0x78>
    17e8:	05400793          	li	a5,84
    17ec:	86a2                	mv	a3,s0
    17ee:	45fd                	li	a1,31
    17f0:	00001517          	auipc	a0,0x1
    17f4:	f5850513          	addi	a0,a0,-168 # 2748 <enable_deadlock_detect+0x80>
    17f8:	9d1ff0ef          	jal	ra,11c8 <printf>
    17fc:	557d                	li	a0,-1
    17fe:	42d000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    1802:	4090                	lw	a2,0(s1)
    1804:	d659                	beqz	a2,1792 <out_unlocked.constprop.0+0x32>
    1806:	b745                	j	17a6 <out_unlocked.constprop.0+0x46>

0000000000001808 <putchar>:
{
    1808:	7139                	addi	sp,sp,-64
    180a:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    180c:	00001497          	auipc	s1,0x1
    1810:	fec48493          	addi	s1,s1,-20 # 27f8 <buffer_len>
    1814:	1084a703          	lw	a4,264(s1)
{
    1818:	f822                	sd	s0,48(sp)
	char byte = c;
    181a:	0ff57413          	zext.b	s0,a0
{
    181e:	fc06                	sd	ra,56(sp)
	char byte = c;
    1820:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1824:	4785                	li	a5,1
    1826:	00f70d63          	beq	a4,a5,1840 <putchar+0x38>
		len = out_unlocked(s, l);
    182a:	01f10513          	addi	a0,sp,31
    182e:	f33ff0ef          	jal	ra,1760 <out_unlocked.constprop.0>
}
    1832:	70e2                	ld	ra,56(sp)
    1834:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1836:	862a                	mv	a2,a0
}
    1838:	74a2                	ld	s1,40(sp)
    183a:	8532                	mv	a0,a2
    183c:	6121                	addi	sp,sp,64
    183e:	8082                	ret
		mutex_lock(buffer_lock);
    1840:	10c4a503          	lw	a0,268(s1)
    1844:	625000ef          	jal	ra,2668 <mutex_lock>
		buffer[buffer_len++] = c;
    1848:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    184a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    184e:	0017861b          	addiw	a2,a5,1
    1852:	97a6                	add	a5,a5,s1
    1854:	c090                	sw	a2,0(s1)
    1856:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    185a:	02c6c263          	blt	a3,a2,187e <putchar+0x76>
    185e:	47a9                	li	a5,10
    1860:	06f40d63          	beq	s0,a5,18da <putchar+0xd2>
    1864:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1866:	10c4a503          	lw	a0,268(s1)
    186a:	e432                	sd	a2,8(sp)
    186c:	609000ef          	jal	ra,2674 <mutex_unlock>
    1870:	6622                	ld	a2,8(sp)
}
    1872:	70e2                	ld	ra,56(sp)
    1874:	7442                	ld	s0,48(sp)
    1876:	74a2                	ld	s1,40(sp)
    1878:	8532                	mv	a0,a2
    187a:	6121                	addi	sp,sp,64
    187c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    187e:	10000793          	li	a5,256
    1882:	02f61063          	bne	a2,a5,18a2 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1886:	00001597          	auipc	a1,0x1
    188a:	f7a58593          	addi	a1,a1,-134 # 2800 <buffer>
    188e:	4505                	li	a0,1
    1890:	361000ef          	jal	ra,23f0 <write>
    1894:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1898:	00001797          	auipc	a5,0x1
    189c:	f607a023          	sw	zero,-160(a5) # 27f8 <buffer_len>
			if (r < 0) {
    18a0:	b7d9                	j	1866 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18a2:	359000ef          	jal	ra,23fa <getpid>
    18a6:	842a                	mv	s0,a0
    18a8:	00001517          	auipc	a0,0x1
    18ac:	e5850513          	addi	a0,a0,-424 # 2700 <enable_deadlock_detect+0x38>
    18b0:	221000ef          	jal	ra,22d0 <basename>
    18b4:	872a                	mv	a4,a0
    18b6:	00001617          	auipc	a2,0x1
    18ba:	e8a60613          	addi	a2,a2,-374 # 2740 <enable_deadlock_detect+0x78>
    18be:	05400793          	li	a5,84
    18c2:	86a2                	mv	a3,s0
    18c4:	45fd                	li	a1,31
    18c6:	00001517          	auipc	a0,0x1
    18ca:	e8250513          	addi	a0,a0,-382 # 2748 <enable_deadlock_detect+0x80>
    18ce:	8fbff0ef          	jal	ra,11c8 <printf>
    18d2:	557d                	li	a0,-1
    18d4:	357000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    18d8:	4090                	lw	a2,0(s1)
    18da:	d651                	beqz	a2,1866 <putchar+0x5e>
    18dc:	b76d                	j	1886 <putchar+0x7e>

00000000000018de <puts>:
{
    18de:	7139                	addi	sp,sp,-64
    18e0:	f822                	sd	s0,48(sp)
    18e2:	f426                	sd	s1,40(sp)
    18e4:	fc06                	sd	ra,56(sp)
    18e6:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18e8:	00001417          	auipc	s0,0x1
    18ec:	f1040413          	addi	s0,s0,-240 # 27f8 <buffer_len>
{
    18f0:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18f2:	638000ef          	jal	ra,1f2a <strlen>
	if (buffer_lock_enabled == 1) {
    18f6:	10842703          	lw	a4,264(s0)
    18fa:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18fc:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18fe:	04f70563          	beq	a4,a5,1948 <puts+0x6a>
		len = out_unlocked(s, l);
    1902:	8526                	mv	a0,s1
    1904:	d51ff0ef          	jal	ra,1654 <out_unlocked>
    1908:	892a                	mv	s2,a0
    190a:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    190c:	00095963          	bgez	s2,191e <puts+0x40>
}
    1910:	70e2                	ld	ra,56(sp)
    1912:	7442                	ld	s0,48(sp)
    1914:	7902                	ld	s2,32(sp)
    1916:	8526                	mv	a0,s1
    1918:	74a2                	ld	s1,40(sp)
    191a:	6121                	addi	sp,sp,64
    191c:	8082                	ret
	if (buffer_lock_enabled == 1) {
    191e:	10842703          	lw	a4,264(s0)
	char byte = c;
    1922:	44a9                	li	s1,10
    1924:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1928:	4785                	li	a5,1
    192a:	02f70e63          	beq	a4,a5,1966 <puts+0x88>
		len = out_unlocked(s, l);
    192e:	01f10513          	addi	a0,sp,31
    1932:	e2fff0ef          	jal	ra,1760 <out_unlocked.constprop.0>
}
    1936:	70e2                	ld	ra,56(sp)
    1938:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    193a:	41f5549b          	sraiw	s1,a0,0x1f
}
    193e:	7902                	ld	s2,32(sp)
    1940:	8526                	mv	a0,s1
    1942:	74a2                	ld	s1,40(sp)
    1944:	6121                	addi	sp,sp,64
    1946:	8082                	ret
		mutex_lock(buffer_lock);
    1948:	e42a                	sd	a0,8(sp)
    194a:	10c42503          	lw	a0,268(s0)
    194e:	51b000ef          	jal	ra,2668 <mutex_lock>
		len = out_unlocked(s, l);
    1952:	65a2                	ld	a1,8(sp)
    1954:	8526                	mv	a0,s1
    1956:	cffff0ef          	jal	ra,1654 <out_unlocked>
    195a:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    195c:	10c42503          	lw	a0,268(s0)
    1960:	515000ef          	jal	ra,2674 <mutex_unlock>
    1964:	b75d                	j	190a <puts+0x2c>
		mutex_lock(buffer_lock);
    1966:	10c42503          	lw	a0,268(s0)
    196a:	4ff000ef          	jal	ra,2668 <mutex_lock>
		buffer[buffer_len++] = c;
    196e:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1970:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1974:	0017861b          	addiw	a2,a5,1
    1978:	97a2                	add	a5,a5,s0
    197a:	c010                	sw	a2,0(s0)
    197c:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1980:	06c6dc63          	bge	a3,a2,19f8 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1984:	10000793          	li	a5,256
    1988:	02f61c63          	bne	a2,a5,19c0 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    198c:	00001597          	auipc	a1,0x1
    1990:	e7458593          	addi	a1,a1,-396 # 2800 <buffer>
    1994:	4505                	li	a0,1
    1996:	25b000ef          	jal	ra,23f0 <write>
			if (r < 0) {
    199a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    199c:	00001797          	auipc	a5,0x1
    19a0:	e407ae23          	sw	zero,-420(a5) # 27f8 <buffer_len>
			if (r < 0) {
    19a4:	04054c63          	bltz	a0,19fc <puts+0x11e>
			if (r < buffer_len) {
    19a8:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19aa:	10c42503          	lw	a0,268(s0)
    19ae:	4c7000ef          	jal	ra,2674 <mutex_unlock>
}
    19b2:	70e2                	ld	ra,56(sp)
    19b4:	7442                	ld	s0,48(sp)
    19b6:	7902                	ld	s2,32(sp)
    19b8:	8526                	mv	a0,s1
    19ba:	74a2                	ld	s1,40(sp)
    19bc:	6121                	addi	sp,sp,64
    19be:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19c0:	23b000ef          	jal	ra,23fa <getpid>
    19c4:	84aa                	mv	s1,a0
    19c6:	00001517          	auipc	a0,0x1
    19ca:	d3a50513          	addi	a0,a0,-710 # 2700 <enable_deadlock_detect+0x38>
    19ce:	103000ef          	jal	ra,22d0 <basename>
    19d2:	872a                	mv	a4,a0
    19d4:	00001617          	auipc	a2,0x1
    19d8:	d6c60613          	addi	a2,a2,-660 # 2740 <enable_deadlock_detect+0x78>
    19dc:	05400793          	li	a5,84
    19e0:	86a6                	mv	a3,s1
    19e2:	45fd                	li	a1,31
    19e4:	00001517          	auipc	a0,0x1
    19e8:	d6450513          	addi	a0,a0,-668 # 2748 <enable_deadlock_detect+0x80>
    19ec:	fdcff0ef          	jal	ra,11c8 <printf>
    19f0:	557d                	li	a0,-1
    19f2:	239000ef          	jal	ra,242a <exit>
	if (buffer_len == 0)
    19f6:	4010                	lw	a2,0(s0)
    19f8:	da45                	beqz	a2,19a8 <puts+0xca>
    19fa:	bf49                	j	198c <puts+0xae>
    19fc:	54fd                	li	s1,-1
    19fe:	b775                	j	19aa <puts+0xcc>

0000000000001a00 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a00:	715d                	addi	sp,sp,-80
    1a02:	e486                	sd	ra,72(sp)
    1a04:	e0a2                	sd	s0,64(sp)
    1a06:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a08:	14054363          	bltz	a0,1b4e <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a0c:	02b577bb          	remuw	a5,a0,a1
    1a10:	00001617          	auipc	a2,0x1
    1a14:	f0060613          	addi	a2,a2,-256 # 2910 <digits>
	buf[16] = 0;
    1a18:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a1c:	0005871b          	sext.w	a4,a1
    1a20:	1782                	slli	a5,a5,0x20
    1a22:	9381                	srli	a5,a5,0x20
    1a24:	97b2                	add	a5,a5,a2
    1a26:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a2a:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a2e:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a32:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a34:	0eb56763          	bltu	a0,a1,1b22 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a38:	02e877bb          	remuw	a5,a6,a4
    1a3c:	1782                	slli	a5,a5,0x20
    1a3e:	9381                	srli	a5,a5,0x20
    1a40:	97b2                	add	a5,a5,a2
    1a42:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a46:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a4a:	02f10323          	sb	a5,38(sp)
    1a4e:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a50:	0ce86963          	bltu	a6,a4,1b22 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a54:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a58:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a5c:	1582                	slli	a1,a1,0x20
    1a5e:	9181                	srli	a1,a1,0x20
    1a60:	95b2                	add	a1,a1,a2
    1a62:	0005c583          	lbu	a1,0(a1)
    1a66:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a6a:	0007859b          	sext.w	a1,a5
    1a6e:	16e6e563          	bltu	a3,a4,1bd8 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a72:	02e7f6bb          	remuw	a3,a5,a4
    1a76:	1682                	slli	a3,a3,0x20
    1a78:	9281                	srli	a3,a3,0x20
    1a7a:	96b2                	add	a3,a3,a2
    1a7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a80:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a84:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a88:	16e5e163          	bltu	a1,a4,1bea <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a8c:	02e876bb          	remuw	a3,a6,a4
    1a90:	1682                	slli	a3,a3,0x20
    1a92:	9281                	srli	a3,a3,0x20
    1a94:	96b2                	add	a3,a3,a2
    1a96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a9a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a9e:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1aa2:	14e86d63          	bltu	a6,a4,1bfc <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1aa6:	02e5f6bb          	remuw	a3,a1,a4
    1aaa:	1682                	slli	a3,a3,0x20
    1aac:	9281                	srli	a3,a3,0x20
    1aae:	96b2                	add	a3,a3,a2
    1ab0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab4:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ab8:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1abc:	10e5e563          	bltu	a1,a4,1bc6 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ac0:	02e876bb          	remuw	a3,a6,a4
    1ac4:	1682                	slli	a3,a3,0x20
    1ac6:	9281                	srli	a3,a3,0x20
    1ac8:	96b2                	add	a3,a3,a2
    1aca:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ace:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ad2:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ad6:	14e86263          	bltu	a6,a4,1c1a <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1ada:	02e5f6bb          	remuw	a3,a1,a4
    1ade:	1682                	slli	a3,a3,0x20
    1ae0:	9281                	srli	a3,a3,0x20
    1ae2:	96b2                	add	a3,a3,a2
    1ae4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae8:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1aec:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1af0:	14e5e463          	bltu	a1,a4,1c38 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1af4:	02e876bb          	remuw	a3,a6,a4
    1af8:	1682                	slli	a3,a3,0x20
    1afa:	9281                	srli	a3,a3,0x20
    1afc:	96b2                	add	a3,a3,a2
    1afe:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b02:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b06:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b0a:	14e86063          	bltu	a6,a4,1c4a <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b0e:	1782                	slli	a5,a5,0x20
    1b10:	9381                	srli	a5,a5,0x20
    1b12:	97b2                	add	a5,a5,a2
    1b14:	0007c703          	lbu	a4,0(a5)
    1b18:	4799                	li	a5,6
    1b1a:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b1e:	10054763          	bltz	a0,1c2c <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b22:	00001497          	auipc	s1,0x1
    1b26:	cd648493          	addi	s1,s1,-810 # 27f8 <buffer_len>
    1b2a:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b2e:	0828                	addi	a0,sp,24
    1b30:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b32:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b34:	00f50433          	add	s0,a0,a5
    1b38:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b3a:	06e68463          	beq	a3,a4,1ba2 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b3e:	8522                	mv	a0,s0
    1b40:	b15ff0ef          	jal	ra,1654 <out_unlocked>
}
    1b44:	60a6                	ld	ra,72(sp)
    1b46:	6406                	ld	s0,64(sp)
    1b48:	74e2                	ld	s1,56(sp)
    1b4a:	6161                	addi	sp,sp,80
    1b4c:	8082                	ret
		x = -xx;
    1b4e:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b52:	02b877bb          	remuw	a5,a6,a1
    1b56:	00001617          	auipc	a2,0x1
    1b5a:	dba60613          	addi	a2,a2,-582 # 2910 <digits>
	buf[16] = 0;
    1b5e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b62:	0005871b          	sext.w	a4,a1
    1b66:	1782                	slli	a5,a5,0x20
    1b68:	9381                	srli	a5,a5,0x20
    1b6a:	97b2                	add	a5,a5,a2
    1b6c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b70:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b74:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b78:	08b86b63          	bltu	a6,a1,1c0e <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b7c:	02e8f7bb          	remuw	a5,a7,a4
    1b80:	1782                	slli	a5,a5,0x20
    1b82:	9381                	srli	a5,a5,0x20
    1b84:	97b2                	add	a5,a5,a2
    1b86:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b8a:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b8e:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b92:	ece8f1e3          	bgeu	a7,a4,1a54 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b96:	02d00793          	li	a5,45
    1b9a:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b9e:	47b5                	li	a5,13
    1ba0:	b749                	j	1b22 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1ba2:	10c4a503          	lw	a0,268(s1)
    1ba6:	e42e                	sd	a1,8(sp)
    1ba8:	2c1000ef          	jal	ra,2668 <mutex_lock>
		len = out_unlocked(s, l);
    1bac:	65a2                	ld	a1,8(sp)
    1bae:	8522                	mv	a0,s0
    1bb0:	aa5ff0ef          	jal	ra,1654 <out_unlocked>
		mutex_unlock(buffer_lock);
    1bb4:	10c4a503          	lw	a0,268(s1)
    1bb8:	2bd000ef          	jal	ra,2674 <mutex_unlock>
}
    1bbc:	60a6                	ld	ra,72(sp)
    1bbe:	6406                	ld	s0,64(sp)
    1bc0:	74e2                	ld	s1,56(sp)
    1bc2:	6161                	addi	sp,sp,80
    1bc4:	8082                	ret
		buf[i--] = digits[x % base];
    1bc6:	47a9                	li	a5,10
	if (sign)
    1bc8:	f4055de3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bcc:	02d00793          	li	a5,45
    1bd0:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bd4:	47a5                	li	a5,9
    1bd6:	b7b1                	j	1b22 <printint.constprop.0+0x122>
    1bd8:	47b5                	li	a5,13
	if (sign)
    1bda:	f40554e3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bde:	02d00793          	li	a5,45
    1be2:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1be6:	47b1                	li	a5,12
    1be8:	bf2d                	j	1b22 <printint.constprop.0+0x122>
    1bea:	47b1                	li	a5,12
	if (sign)
    1bec:	f2055be3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf0:	02d00793          	li	a5,45
    1bf4:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bf8:	47ad                	li	a5,11
    1bfa:	b725                	j	1b22 <printint.constprop.0+0x122>
    1bfc:	47ad                	li	a5,11
	if (sign)
    1bfe:	f20552e3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c02:	02d00793          	li	a5,45
    1c06:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c0a:	47a9                	li	a5,10
    1c0c:	bf19                	j	1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0e:	02d00793          	li	a5,45
    1c12:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c16:	47b9                	li	a5,14
    1c18:	b729                	j	1b22 <printint.constprop.0+0x122>
    1c1a:	47a5                	li	a5,9
	if (sign)
    1c1c:	f00553e3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c20:	02d00793          	li	a5,45
    1c24:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c28:	47a1                	li	a5,8
    1c2a:	bde5                	j	1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c2c:	02d00793          	li	a5,45
    1c30:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c34:	4795                	li	a5,5
    1c36:	b5f5                	j	1b22 <printint.constprop.0+0x122>
    1c38:	47a1                	li	a5,8
	if (sign)
    1c3a:	ee0554e3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c3e:	02d00793          	li	a5,45
    1c42:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c46:	479d                	li	a5,7
    1c48:	bde9                	j	1b22 <printint.constprop.0+0x122>
    1c4a:	479d                	li	a5,7
	if (sign)
    1c4c:	ec055be3          	bgez	a0,1b22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c50:	02d00793          	li	a5,45
    1c54:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c58:	4799                	li	a5,6
    1c5a:	b5e1                	j	1b22 <printint.constprop.0+0x122>

0000000000001c5c <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c5c:	02000793          	li	a5,32
    1c60:	00f50663          	beq	a0,a5,1c6c <isspace+0x10>
    1c64:	355d                	addiw	a0,a0,-9
    1c66:	00553513          	sltiu	a0,a0,5
    1c6a:	8082                	ret
    1c6c:	4505                	li	a0,1
}
    1c6e:	8082                	ret

0000000000001c70 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c70:	fd05051b          	addiw	a0,a0,-48
}
    1c74:	00a53513          	sltiu	a0,a0,10
    1c78:	8082                	ret

0000000000001c7a <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c7a:	02000613          	li	a2,32
    1c7e:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c80:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c84:	ff77869b          	addiw	a3,a5,-9
    1c88:	04c78c63          	beq	a5,a2,1ce0 <atoi+0x66>
    1c8c:	0007871b          	sext.w	a4,a5
    1c90:	04d5f863          	bgeu	a1,a3,1ce0 <atoi+0x66>
		s++;
	switch (*s) {
    1c94:	02b00693          	li	a3,43
    1c98:	04d78963          	beq	a5,a3,1cea <atoi+0x70>
    1c9c:	02d00693          	li	a3,45
    1ca0:	06d78263          	beq	a5,a3,1d04 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1ca4:	fd07061b          	addiw	a2,a4,-48
    1ca8:	47a5                	li	a5,9
    1caa:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cac:	4e01                	li	t3,0
	while (isdigit(*s))
    1cae:	04c7e963          	bltu	a5,a2,1d00 <atoi+0x86>
	int n = 0, neg = 0;
    1cb2:	4501                	li	a0,0
	while (isdigit(*s))
    1cb4:	4825                	li	a6,9
    1cb6:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cba:	0025179b          	slliw	a5,a0,0x2
    1cbe:	9fa9                	addw	a5,a5,a0
    1cc0:	fd07031b          	addiw	t1,a4,-48
    1cc4:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1cc8:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ccc:	0685                	addi	a3,a3,1
    1cce:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cd2:	0006071b          	sext.w	a4,a2
    1cd6:	feb870e3          	bgeu	a6,a1,1cb6 <atoi+0x3c>
	return neg ? n : -n;
    1cda:	000e0563          	beqz	t3,1ce4 <atoi+0x6a>
}
    1cde:	8082                	ret
		s++;
    1ce0:	0505                	addi	a0,a0,1
    1ce2:	bf79                	j	1c80 <atoi+0x6>
	return neg ? n : -n;
    1ce4:	4113053b          	subw	a0,t1,a7
    1ce8:	8082                	ret
	while (isdigit(*s))
    1cea:	00154703          	lbu	a4,1(a0)
    1cee:	47a5                	li	a5,9
		s++;
    1cf0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cf4:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cf8:	4e01                	li	t3,0
	while (isdigit(*s))
    1cfa:	2701                	sext.w	a4,a4
    1cfc:	fac7fbe3          	bgeu	a5,a2,1cb2 <atoi+0x38>
    1d00:	4501                	li	a0,0
}
    1d02:	8082                	ret
	while (isdigit(*s))
    1d04:	00154703          	lbu	a4,1(a0)
    1d08:	47a5                	li	a5,9
		s++;
    1d0a:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d0e:	fd07061b          	addiw	a2,a4,-48
    1d12:	2701                	sext.w	a4,a4
    1d14:	fec7e6e3          	bltu	a5,a2,1d00 <atoi+0x86>
		neg = 1;
    1d18:	4e05                	li	t3,1
    1d1a:	bf61                	j	1cb2 <atoi+0x38>

0000000000001d1c <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d1c:	16060d63          	beqz	a2,1e96 <memset+0x17a>
    1d20:	40a007b3          	neg	a5,a0
    1d24:	8b9d                	andi	a5,a5,7
    1d26:	00778693          	addi	a3,a5,7
    1d2a:	482d                	li	a6,11
    1d2c:	0ff5f713          	zext.b	a4,a1
    1d30:	fff60593          	addi	a1,a2,-1
    1d34:	1706e263          	bltu	a3,a6,1e98 <memset+0x17c>
    1d38:	16d5ea63          	bltu	a1,a3,1eac <memset+0x190>
    1d3c:	16078563          	beqz	a5,1ea6 <memset+0x18a>
    1d40:	00e50023          	sb	a4,0(a0)
    1d44:	4685                	li	a3,1
    1d46:	00150593          	addi	a1,a0,1
    1d4a:	14d78c63          	beq	a5,a3,1ea2 <memset+0x186>
    1d4e:	00e500a3          	sb	a4,1(a0)
    1d52:	4689                	li	a3,2
    1d54:	00250593          	addi	a1,a0,2
    1d58:	14d78d63          	beq	a5,a3,1eb2 <memset+0x196>
    1d5c:	00e50123          	sb	a4,2(a0)
    1d60:	468d                	li	a3,3
    1d62:	00350593          	addi	a1,a0,3
    1d66:	12d78b63          	beq	a5,a3,1e9c <memset+0x180>
    1d6a:	00e501a3          	sb	a4,3(a0)
    1d6e:	4691                	li	a3,4
    1d70:	00450593          	addi	a1,a0,4
    1d74:	14d78163          	beq	a5,a3,1eb6 <memset+0x19a>
    1d78:	00e50223          	sb	a4,4(a0)
    1d7c:	4695                	li	a3,5
    1d7e:	00550593          	addi	a1,a0,5
    1d82:	12d78c63          	beq	a5,a3,1eba <memset+0x19e>
    1d86:	00e502a3          	sb	a4,5(a0)
    1d8a:	469d                	li	a3,7
    1d8c:	00650593          	addi	a1,a0,6
    1d90:	12d79763          	bne	a5,a3,1ebe <memset+0x1a2>
    1d94:	00750593          	addi	a1,a0,7
    1d98:	00e50323          	sb	a4,6(a0)
    1d9c:	481d                	li	a6,7
    1d9e:	00871693          	slli	a3,a4,0x8
    1da2:	01071893          	slli	a7,a4,0x10
    1da6:	8ed9                	or	a3,a3,a4
    1da8:	01871313          	slli	t1,a4,0x18
    1dac:	0116e6b3          	or	a3,a3,a7
    1db0:	0066e6b3          	or	a3,a3,t1
    1db4:	02071893          	slli	a7,a4,0x20
    1db8:	02871e13          	slli	t3,a4,0x28
    1dbc:	0116e6b3          	or	a3,a3,a7
    1dc0:	40f60333          	sub	t1,a2,a5
    1dc4:	03071893          	slli	a7,a4,0x30
    1dc8:	01c6e6b3          	or	a3,a3,t3
    1dcc:	0116e6b3          	or	a3,a3,a7
    1dd0:	03871e13          	slli	t3,a4,0x38
    1dd4:	97aa                	add	a5,a5,a0
    1dd6:	ff837893          	andi	a7,t1,-8
    1dda:	01c6e6b3          	or	a3,a3,t3
    1dde:	98be                	add	a7,a7,a5
    1de0:	e394                	sd	a3,0(a5)
    1de2:	07a1                	addi	a5,a5,8
    1de4:	ff179ee3          	bne	a5,a7,1de0 <memset+0xc4>
    1de8:	ff837893          	andi	a7,t1,-8
    1dec:	011587b3          	add	a5,a1,a7
    1df0:	010886bb          	addw	a3,a7,a6
    1df4:	0b130663          	beq	t1,a7,1ea0 <memset+0x184>
    1df8:	00e78023          	sb	a4,0(a5)
    1dfc:	0016859b          	addiw	a1,a3,1
    1e00:	08c5fb63          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e04:	00e780a3          	sb	a4,1(a5)
    1e08:	0026859b          	addiw	a1,a3,2
    1e0c:	08c5f563          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e10:	00e78123          	sb	a4,2(a5)
    1e14:	0036859b          	addiw	a1,a3,3
    1e18:	06c5ff63          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e1c:	00e781a3          	sb	a4,3(a5)
    1e20:	0046859b          	addiw	a1,a3,4
    1e24:	06c5f963          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e28:	00e78223          	sb	a4,4(a5)
    1e2c:	0056859b          	addiw	a1,a3,5
    1e30:	06c5f363          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e34:	00e782a3          	sb	a4,5(a5)
    1e38:	0066859b          	addiw	a1,a3,6
    1e3c:	04c5fd63          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e40:	00e78323          	sb	a4,6(a5)
    1e44:	0076859b          	addiw	a1,a3,7
    1e48:	04c5f763          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e4c:	00e783a3          	sb	a4,7(a5)
    1e50:	0086859b          	addiw	a1,a3,8
    1e54:	04c5f163          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e58:	00e78423          	sb	a4,8(a5)
    1e5c:	0096859b          	addiw	a1,a3,9
    1e60:	02c5fb63          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e64:	00e784a3          	sb	a4,9(a5)
    1e68:	00a6859b          	addiw	a1,a3,10
    1e6c:	02c5f563          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e70:	00e78523          	sb	a4,10(a5)
    1e74:	00b6859b          	addiw	a1,a3,11
    1e78:	00c5ff63          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e7c:	00e785a3          	sb	a4,11(a5)
    1e80:	00c6859b          	addiw	a1,a3,12
    1e84:	00c5f963          	bgeu	a1,a2,1e96 <memset+0x17a>
    1e88:	00e78623          	sb	a4,12(a5)
    1e8c:	26b5                	addiw	a3,a3,13
    1e8e:	00c6f463          	bgeu	a3,a2,1e96 <memset+0x17a>
    1e92:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e96:	8082                	ret
    1e98:	46ad                	li	a3,11
    1e9a:	bd79                	j	1d38 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e9c:	480d                	li	a6,3
    1e9e:	b701                	j	1d9e <memset+0x82>
    1ea0:	8082                	ret
    1ea2:	4805                	li	a6,1
    1ea4:	bded                	j	1d9e <memset+0x82>
    1ea6:	85aa                	mv	a1,a0
    1ea8:	4801                	li	a6,0
    1eaa:	bdd5                	j	1d9e <memset+0x82>
    1eac:	87aa                	mv	a5,a0
    1eae:	4681                	li	a3,0
    1eb0:	b7a1                	j	1df8 <memset+0xdc>
    1eb2:	4809                	li	a6,2
    1eb4:	b5ed                	j	1d9e <memset+0x82>
    1eb6:	4811                	li	a6,4
    1eb8:	b5dd                	j	1d9e <memset+0x82>
    1eba:	4815                	li	a6,5
    1ebc:	b5cd                	j	1d9e <memset+0x82>
    1ebe:	4819                	li	a6,6
    1ec0:	bdf9                	j	1d9e <memset+0x82>

0000000000001ec2 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ec2:	00054783          	lbu	a5,0(a0)
    1ec6:	0005c703          	lbu	a4,0(a1)
    1eca:	00e79863          	bne	a5,a4,1eda <strcmp+0x18>
    1ece:	0505                	addi	a0,a0,1
    1ed0:	0585                	addi	a1,a1,1
    1ed2:	fbe5                	bnez	a5,1ec2 <strcmp>
    1ed4:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1ed6:	9d19                	subw	a0,a0,a4
    1ed8:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1eda:	0007851b          	sext.w	a0,a5
    1ede:	bfe5                	j	1ed6 <strcmp+0x14>

0000000000001ee0 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ee0:	ca15                	beqz	a2,1f14 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ee2:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ee6:	167d                	addi	a2,a2,-1
    1ee8:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1eec:	eb99                	bnez	a5,1f02 <strncmp+0x22>
    1eee:	a815                	j	1f22 <strncmp+0x42>
    1ef0:	00a68e63          	beq	a3,a0,1f0c <strncmp+0x2c>
    1ef4:	0505                	addi	a0,a0,1
    1ef6:	00f71b63          	bne	a4,a5,1f0c <strncmp+0x2c>
    1efa:	00054783          	lbu	a5,0(a0)
    1efe:	cf89                	beqz	a5,1f18 <strncmp+0x38>
    1f00:	85b2                	mv	a1,a2
    1f02:	0005c703          	lbu	a4,0(a1)
    1f06:	00158613          	addi	a2,a1,1
    1f0a:	f37d                	bnez	a4,1ef0 <strncmp+0x10>
		;
	return *l - *r;
    1f0c:	0007851b          	sext.w	a0,a5
    1f10:	9d19                	subw	a0,a0,a4
    1f12:	8082                	ret
		return 0;
    1f14:	4501                	li	a0,0
}
    1f16:	8082                	ret
	return *l - *r;
    1f18:	0015c703          	lbu	a4,1(a1)
    1f1c:	4501                	li	a0,0
    1f1e:	9d19                	subw	a0,a0,a4
    1f20:	8082                	ret
    1f22:	0005c703          	lbu	a4,0(a1)
    1f26:	4501                	li	a0,0
    1f28:	b7e5                	j	1f10 <strncmp+0x30>

0000000000001f2a <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f2a:	00757793          	andi	a5,a0,7
    1f2e:	cf89                	beqz	a5,1f48 <strlen+0x1e>
    1f30:	87aa                	mv	a5,a0
    1f32:	a029                	j	1f3c <strlen+0x12>
    1f34:	0785                	addi	a5,a5,1
    1f36:	0077f713          	andi	a4,a5,7
    1f3a:	cb01                	beqz	a4,1f4a <strlen+0x20>
		if (!*s)
    1f3c:	0007c703          	lbu	a4,0(a5)
    1f40:	fb75                	bnez	a4,1f34 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f42:	40a78533          	sub	a0,a5,a0
}
    1f46:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f48:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f4a:	6394                	ld	a3,0(a5)
    1f4c:	00001597          	auipc	a1,0x1
    1f50:	8945b583          	ld	a1,-1900(a1) # 27e0 <enable_deadlock_detect+0x118>
    1f54:	00001617          	auipc	a2,0x1
    1f58:	89463603          	ld	a2,-1900(a2) # 27e8 <enable_deadlock_detect+0x120>
    1f5c:	a019                	j	1f62 <strlen+0x38>
    1f5e:	6794                	ld	a3,8(a5)
    1f60:	07a1                	addi	a5,a5,8
    1f62:	00b68733          	add	a4,a3,a1
    1f66:	fff6c693          	not	a3,a3
    1f6a:	8f75                	and	a4,a4,a3
    1f6c:	8f71                	and	a4,a4,a2
    1f6e:	db65                	beqz	a4,1f5e <strlen+0x34>
	for (; *s; s++)
    1f70:	0007c703          	lbu	a4,0(a5)
    1f74:	d779                	beqz	a4,1f42 <strlen+0x18>
    1f76:	0017c703          	lbu	a4,1(a5)
    1f7a:	0785                	addi	a5,a5,1
    1f7c:	d379                	beqz	a4,1f42 <strlen+0x18>
    1f7e:	0017c703          	lbu	a4,1(a5)
    1f82:	0785                	addi	a5,a5,1
    1f84:	fb6d                	bnez	a4,1f76 <strlen+0x4c>
    1f86:	bf75                	j	1f42 <strlen+0x18>

0000000000001f88 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f88:	00757713          	andi	a4,a0,7
{
    1f8c:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f8e:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f92:	cb19                	beqz	a4,1fa8 <memchr+0x20>
    1f94:	ce25                	beqz	a2,200c <memchr+0x84>
    1f96:	0007c703          	lbu	a4,0(a5)
    1f9a:	04b70e63          	beq	a4,a1,1ff6 <memchr+0x6e>
    1f9e:	0785                	addi	a5,a5,1
    1fa0:	0077f713          	andi	a4,a5,7
    1fa4:	167d                	addi	a2,a2,-1
    1fa6:	f77d                	bnez	a4,1f94 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1fa8:	4501                	li	a0,0
	if (n && *s != c) {
    1faa:	c235                	beqz	a2,200e <memchr+0x86>
    1fac:	0007c703          	lbu	a4,0(a5)
    1fb0:	04b70363          	beq	a4,a1,1ff6 <memchr+0x6e>
		size_t k = ONES * c;
    1fb4:	00001517          	auipc	a0,0x1
    1fb8:	83c53503          	ld	a0,-1988(a0) # 27f0 <enable_deadlock_detect+0x128>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fbc:	471d                	li	a4,7
		size_t k = ONES * c;
    1fbe:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fc2:	02c77a63          	bgeu	a4,a2,1ff6 <memchr+0x6e>
    1fc6:	00001897          	auipc	a7,0x1
    1fca:	81a8b883          	ld	a7,-2022(a7) # 27e0 <enable_deadlock_detect+0x118>
    1fce:	00001817          	auipc	a6,0x1
    1fd2:	81a83803          	ld	a6,-2022(a6) # 27e8 <enable_deadlock_detect+0x120>
    1fd6:	431d                	li	t1,7
    1fd8:	a029                	j	1fe2 <memchr+0x5a>
		     w++, n -= SS)
    1fda:	1661                	addi	a2,a2,-8
    1fdc:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fde:	02c37963          	bgeu	t1,a2,2010 <memchr+0x88>
    1fe2:	6398                	ld	a4,0(a5)
    1fe4:	8f29                	xor	a4,a4,a0
    1fe6:	011706b3          	add	a3,a4,a7
    1fea:	fff74713          	not	a4,a4
    1fee:	8f75                	and	a4,a4,a3
    1ff0:	01077733          	and	a4,a4,a6
    1ff4:	d37d                	beqz	a4,1fda <memchr+0x52>
{
    1ff6:	853e                	mv	a0,a5
    1ff8:	97b2                	add	a5,a5,a2
    1ffa:	a021                	j	2002 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1ffc:	0505                	addi	a0,a0,1
    1ffe:	00f50763          	beq	a0,a5,200c <memchr+0x84>
    2002:	00054703          	lbu	a4,0(a0)
    2006:	feb71be3          	bne	a4,a1,1ffc <memchr+0x74>
    200a:	8082                	ret
	return n ? (void *)s : 0;
    200c:	4501                	li	a0,0
}
    200e:	8082                	ret
	return n ? (void *)s : 0;
    2010:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2012:	f275                	bnez	a2,1ff6 <memchr+0x6e>
}
    2014:	8082                	ret

0000000000002016 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2016:	1101                	addi	sp,sp,-32
    2018:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    201a:	862e                	mv	a2,a1
{
    201c:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    201e:	4581                	li	a1,0
{
    2020:	e426                	sd	s1,8(sp)
    2022:	ec06                	sd	ra,24(sp)
    2024:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2026:	f63ff0ef          	jal	ra,1f88 <memchr>
	return p ? p - s : n;
    202a:	c519                	beqz	a0,2038 <strnlen+0x22>
}
    202c:	60e2                	ld	ra,24(sp)
    202e:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2030:	8d05                	sub	a0,a0,s1
}
    2032:	64a2                	ld	s1,8(sp)
    2034:	6105                	addi	sp,sp,32
    2036:	8082                	ret
    2038:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    203a:	8522                	mv	a0,s0
}
    203c:	6442                	ld	s0,16(sp)
    203e:	64a2                	ld	s1,8(sp)
    2040:	6105                	addi	sp,sp,32
    2042:	8082                	ret

0000000000002044 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2044:	00a5c7b3          	xor	a5,a1,a0
    2048:	8b9d                	andi	a5,a5,7
    204a:	eb95                	bnez	a5,207e <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    204c:	0075f793          	andi	a5,a1,7
    2050:	e7b1                	bnez	a5,209c <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2052:	6198                	ld	a4,0(a1)
    2054:	00000617          	auipc	a2,0x0
    2058:	78c63603          	ld	a2,1932(a2) # 27e0 <enable_deadlock_detect+0x118>
    205c:	00000817          	auipc	a6,0x0
    2060:	78c83803          	ld	a6,1932(a6) # 27e8 <enable_deadlock_detect+0x120>
    2064:	a029                	j	206e <stpcpy+0x2a>
    2066:	05a1                	addi	a1,a1,8
    2068:	e118                	sd	a4,0(a0)
    206a:	6198                	ld	a4,0(a1)
    206c:	0521                	addi	a0,a0,8
    206e:	00c707b3          	add	a5,a4,a2
    2072:	fff74693          	not	a3,a4
    2076:	8ff5                	and	a5,a5,a3
    2078:	0107f7b3          	and	a5,a5,a6
    207c:	d7ed                	beqz	a5,2066 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    207e:	0005c783          	lbu	a5,0(a1)
    2082:	00f50023          	sb	a5,0(a0)
    2086:	c785                	beqz	a5,20ae <stpcpy+0x6a>
    2088:	0015c783          	lbu	a5,1(a1)
    208c:	0505                	addi	a0,a0,1
    208e:	0585                	addi	a1,a1,1
    2090:	00f50023          	sb	a5,0(a0)
    2094:	fbf5                	bnez	a5,2088 <stpcpy+0x44>
		;
	return d;
}
    2096:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2098:	0505                	addi	a0,a0,1
    209a:	df45                	beqz	a4,2052 <stpcpy+0xe>
			if (!(*d = *s))
    209c:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20a0:	0585                	addi	a1,a1,1
    20a2:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20a6:	00f50023          	sb	a5,0(a0)
    20aa:	f7fd                	bnez	a5,2098 <stpcpy+0x54>
}
    20ac:	8082                	ret
    20ae:	8082                	ret

00000000000020b0 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20b0:	00a5c7b3          	xor	a5,a1,a0
    20b4:	8b9d                	andi	a5,a5,7
    20b6:	1a079863          	bnez	a5,2266 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20ba:	0075f793          	andi	a5,a1,7
    20be:	16078463          	beqz	a5,2226 <stpncpy+0x176>
    20c2:	ea01                	bnez	a2,20d2 <stpncpy+0x22>
    20c4:	a421                	j	22cc <stpncpy+0x21c>
    20c6:	167d                	addi	a2,a2,-1
    20c8:	0505                	addi	a0,a0,1
    20ca:	14070e63          	beqz	a4,2226 <stpncpy+0x176>
    20ce:	1a060863          	beqz	a2,227e <stpncpy+0x1ce>
    20d2:	0005c783          	lbu	a5,0(a1)
    20d6:	0585                	addi	a1,a1,1
    20d8:	0075f713          	andi	a4,a1,7
    20dc:	00f50023          	sb	a5,0(a0)
    20e0:	f3fd                	bnez	a5,20c6 <stpncpy+0x16>
    20e2:	4805                	li	a6,1
    20e4:	1a061863          	bnez	a2,2294 <stpncpy+0x1e4>
    20e8:	40a007b3          	neg	a5,a0
    20ec:	8b9d                	andi	a5,a5,7
    20ee:	4681                	li	a3,0
    20f0:	18061a63          	bnez	a2,2284 <stpncpy+0x1d4>
    20f4:	00778713          	addi	a4,a5,7
    20f8:	45ad                	li	a1,11
    20fa:	18b76363          	bltu	a4,a1,2280 <stpncpy+0x1d0>
    20fe:	1ae6eb63          	bltu	a3,a4,22b4 <stpncpy+0x204>
    2102:	1a078363          	beqz	a5,22a8 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2106:	00050023          	sb	zero,0(a0)
    210a:	4685                	li	a3,1
    210c:	00150713          	addi	a4,a0,1
    2110:	18d78f63          	beq	a5,a3,22ae <stpncpy+0x1fe>
    2114:	000500a3          	sb	zero,1(a0)
    2118:	4689                	li	a3,2
    211a:	00250713          	addi	a4,a0,2
    211e:	18d78e63          	beq	a5,a3,22ba <stpncpy+0x20a>
    2122:	00050123          	sb	zero,2(a0)
    2126:	468d                	li	a3,3
    2128:	00350713          	addi	a4,a0,3
    212c:	16d78c63          	beq	a5,a3,22a4 <stpncpy+0x1f4>
    2130:	000501a3          	sb	zero,3(a0)
    2134:	4691                	li	a3,4
    2136:	00450713          	addi	a4,a0,4
    213a:	18d78263          	beq	a5,a3,22be <stpncpy+0x20e>
    213e:	00050223          	sb	zero,4(a0)
    2142:	4695                	li	a3,5
    2144:	00550713          	addi	a4,a0,5
    2148:	16d78d63          	beq	a5,a3,22c2 <stpncpy+0x212>
    214c:	000502a3          	sb	zero,5(a0)
    2150:	469d                	li	a3,7
    2152:	00650713          	addi	a4,a0,6
    2156:	16d79863          	bne	a5,a3,22c6 <stpncpy+0x216>
    215a:	00750713          	addi	a4,a0,7
    215e:	00050323          	sb	zero,6(a0)
    2162:	40f80833          	sub	a6,a6,a5
    2166:	ff887593          	andi	a1,a6,-8
    216a:	97aa                	add	a5,a5,a0
    216c:	95be                	add	a1,a1,a5
    216e:	0007b023          	sd	zero,0(a5)
    2172:	07a1                	addi	a5,a5,8
    2174:	feb79de3          	bne	a5,a1,216e <stpncpy+0xbe>
    2178:	ff887593          	andi	a1,a6,-8
    217c:	9ead                	addw	a3,a3,a1
    217e:	00b707b3          	add	a5,a4,a1
    2182:	12b80863          	beq	a6,a1,22b2 <stpncpy+0x202>
    2186:	00078023          	sb	zero,0(a5)
    218a:	0016871b          	addiw	a4,a3,1
    218e:	0ec77863          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    2192:	000780a3          	sb	zero,1(a5)
    2196:	0026871b          	addiw	a4,a3,2
    219a:	0ec77263          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    219e:	00078123          	sb	zero,2(a5)
    21a2:	0036871b          	addiw	a4,a3,3
    21a6:	0cc77c63          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21aa:	000781a3          	sb	zero,3(a5)
    21ae:	0046871b          	addiw	a4,a3,4
    21b2:	0cc77663          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21b6:	00078223          	sb	zero,4(a5)
    21ba:	0056871b          	addiw	a4,a3,5
    21be:	0cc77063          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21c2:	000782a3          	sb	zero,5(a5)
    21c6:	0066871b          	addiw	a4,a3,6
    21ca:	0ac77a63          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21ce:	00078323          	sb	zero,6(a5)
    21d2:	0076871b          	addiw	a4,a3,7
    21d6:	0ac77463          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21da:	000783a3          	sb	zero,7(a5)
    21de:	0086871b          	addiw	a4,a3,8
    21e2:	08c77e63          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21e6:	00078423          	sb	zero,8(a5)
    21ea:	0096871b          	addiw	a4,a3,9
    21ee:	08c77863          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21f2:	000784a3          	sb	zero,9(a5)
    21f6:	00a6871b          	addiw	a4,a3,10
    21fa:	08c77263          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    21fe:	00078523          	sb	zero,10(a5)
    2202:	00b6871b          	addiw	a4,a3,11
    2206:	06c77c63          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    220a:	000785a3          	sb	zero,11(a5)
    220e:	00c6871b          	addiw	a4,a3,12
    2212:	06c77663          	bgeu	a4,a2,227e <stpncpy+0x1ce>
    2216:	00078623          	sb	zero,12(a5)
    221a:	26b5                	addiw	a3,a3,13
    221c:	06c6f163          	bgeu	a3,a2,227e <stpncpy+0x1ce>
    2220:	000786a3          	sb	zero,13(a5)
    2224:	8082                	ret
			;
		if (!n || !*s)
    2226:	c645                	beqz	a2,22ce <stpncpy+0x21e>
    2228:	0005c783          	lbu	a5,0(a1)
    222c:	ea078be3          	beqz	a5,20e2 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2230:	479d                	li	a5,7
    2232:	02c7ff63          	bgeu	a5,a2,2270 <stpncpy+0x1c0>
    2236:	00000897          	auipc	a7,0x0
    223a:	5aa8b883          	ld	a7,1450(a7) # 27e0 <enable_deadlock_detect+0x118>
    223e:	00000817          	auipc	a6,0x0
    2242:	5aa83803          	ld	a6,1450(a6) # 27e8 <enable_deadlock_detect+0x120>
    2246:	431d                	li	t1,7
    2248:	6198                	ld	a4,0(a1)
    224a:	011707b3          	add	a5,a4,a7
    224e:	fff74693          	not	a3,a4
    2252:	8ff5                	and	a5,a5,a3
    2254:	0107f7b3          	and	a5,a5,a6
    2258:	ef81                	bnez	a5,2270 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    225a:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    225c:	1661                	addi	a2,a2,-8
    225e:	05a1                	addi	a1,a1,8
    2260:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2262:	fec363e3          	bltu	t1,a2,2248 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2266:	e609                	bnez	a2,2270 <stpncpy+0x1c0>
    2268:	a08d                	j	22ca <stpncpy+0x21a>
    226a:	167d                	addi	a2,a2,-1
    226c:	0505                	addi	a0,a0,1
    226e:	ca01                	beqz	a2,227e <stpncpy+0x1ce>
    2270:	0005c783          	lbu	a5,0(a1)
    2274:	0585                	addi	a1,a1,1
    2276:	00f50023          	sb	a5,0(a0)
    227a:	fbe5                	bnez	a5,226a <stpncpy+0x1ba>
		;
tail:
    227c:	b59d                	j	20e2 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    227e:	8082                	ret
    2280:	472d                	li	a4,11
    2282:	bdb5                	j	20fe <stpncpy+0x4e>
    2284:	00778713          	addi	a4,a5,7
    2288:	45ad                	li	a1,11
    228a:	fff60693          	addi	a3,a2,-1
    228e:	e6b778e3          	bgeu	a4,a1,20fe <stpncpy+0x4e>
    2292:	b7fd                	j	2280 <stpncpy+0x1d0>
    2294:	40a007b3          	neg	a5,a0
    2298:	8832                	mv	a6,a2
    229a:	8b9d                	andi	a5,a5,7
    229c:	4681                	li	a3,0
    229e:	e4060be3          	beqz	a2,20f4 <stpncpy+0x44>
    22a2:	b7cd                	j	2284 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22a4:	468d                	li	a3,3
    22a6:	bd75                	j	2162 <stpncpy+0xb2>
    22a8:	872a                	mv	a4,a0
    22aa:	4681                	li	a3,0
    22ac:	bd5d                	j	2162 <stpncpy+0xb2>
    22ae:	4685                	li	a3,1
    22b0:	bd4d                	j	2162 <stpncpy+0xb2>
    22b2:	8082                	ret
    22b4:	87aa                	mv	a5,a0
    22b6:	4681                	li	a3,0
    22b8:	b5f9                	j	2186 <stpncpy+0xd6>
    22ba:	4689                	li	a3,2
    22bc:	b55d                	j	2162 <stpncpy+0xb2>
    22be:	4691                	li	a3,4
    22c0:	b54d                	j	2162 <stpncpy+0xb2>
    22c2:	4695                	li	a3,5
    22c4:	bd79                	j	2162 <stpncpy+0xb2>
    22c6:	4699                	li	a3,6
    22c8:	bd69                	j	2162 <stpncpy+0xb2>
    22ca:	8082                	ret
    22cc:	8082                	ret
    22ce:	8082                	ret

00000000000022d0 <basename>:

char *basename(char *s)
{
    22d0:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22d2:	c54d                	beqz	a0,237c <basename+0xac>
    22d4:	00054783          	lbu	a5,0(a0)
		return ".";
    22d8:	00000517          	auipc	a0,0x0
    22dc:	50050513          	addi	a0,a0,1280 # 27d8 <enable_deadlock_detect+0x110>
	if (!s || !*s)
    22e0:	e391                	bnez	a5,22e4 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22e2:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22e4:	0076f713          	andi	a4,a3,7
    22e8:	87b6                	mv	a5,a3
    22ea:	cf51                	beqz	a4,2386 <basename+0xb6>
    22ec:	0785                	addi	a5,a5,1
    22ee:	0077f713          	andi	a4,a5,7
    22f2:	c729                	beqz	a4,233c <basename+0x6c>
		if (!*s)
    22f4:	0007c703          	lbu	a4,0(a5)
    22f8:	fb75                	bnez	a4,22ec <basename+0x1c>
	return s - a;
    22fa:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22fc:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22fe:	cf8d                	beqz	a5,2338 <basename+0x68>
    2300:	00f68733          	add	a4,a3,a5
    2304:	02f00593          	li	a1,47
    2308:	a031                	j	2314 <basename+0x44>
		s[i] = 0;
    230a:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    230e:	17fd                	addi	a5,a5,-1
    2310:	177d                	addi	a4,a4,-1
    2312:	c39d                	beqz	a5,2338 <basename+0x68>
    2314:	00074603          	lbu	a2,0(a4)
    2318:	feb609e3          	beq	a2,a1,230a <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    231c:	02f00613          	li	a2,47
    2320:	a011                	j	2324 <basename+0x54>
    2322:	cb99                	beqz	a5,2338 <basename+0x68>
    2324:	853e                	mv	a0,a5
    2326:	17fd                	addi	a5,a5,-1
    2328:	00f68733          	add	a4,a3,a5
    232c:	00074703          	lbu	a4,0(a4)
    2330:	fec719e3          	bne	a4,a2,2322 <basename+0x52>
	return s + i;
    2334:	9536                	add	a0,a0,a3
    2336:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2338:	8536                	mv	a0,a3
    233a:	8082                	ret
    233c:	6390                	ld	a2,0(a5)
    233e:	00000517          	auipc	a0,0x0
    2342:	4a253503          	ld	a0,1186(a0) # 27e0 <enable_deadlock_detect+0x118>
    2346:	00000597          	auipc	a1,0x0
    234a:	4a25b583          	ld	a1,1186(a1) # 27e8 <enable_deadlock_detect+0x120>
    234e:	fff64713          	not	a4,a2
    2352:	962a                	add	a2,a2,a0
    2354:	8f71                	and	a4,a4,a2
    2356:	8f6d                	and	a4,a4,a1
    2358:	eb11                	bnez	a4,236c <basename+0x9c>
    235a:	6790                	ld	a2,8(a5)
    235c:	07a1                	addi	a5,a5,8
    235e:	00a60733          	add	a4,a2,a0
    2362:	fff64613          	not	a2,a2
    2366:	8f71                	and	a4,a4,a2
    2368:	8f6d                	and	a4,a4,a1
    236a:	db65                	beqz	a4,235a <basename+0x8a>
	for (; *s; s++)
    236c:	0007c703          	lbu	a4,0(a5)
    2370:	d749                	beqz	a4,22fa <basename+0x2a>
    2372:	0017c703          	lbu	a4,1(a5)
    2376:	0785                	addi	a5,a5,1
    2378:	ff6d                	bnez	a4,2372 <basename+0xa2>
    237a:	b741                	j	22fa <basename+0x2a>
		return ".";
    237c:	00000517          	auipc	a0,0x0
    2380:	45c50513          	addi	a0,a0,1116 # 27d8 <enable_deadlock_detect+0x110>
    2384:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2386:	6290                	ld	a2,0(a3)
    2388:	00000517          	auipc	a0,0x0
    238c:	45853503          	ld	a0,1112(a0) # 27e0 <enable_deadlock_detect+0x118>
    2390:	00000597          	auipc	a1,0x0
    2394:	4585b583          	ld	a1,1112(a1) # 27e8 <enable_deadlock_detect+0x120>
    2398:	fff64713          	not	a4,a2
    239c:	962a                	add	a2,a2,a0
    239e:	8f71                	and	a4,a4,a2
    23a0:	8f6d                	and	a4,a4,a1
    23a2:	df45                	beqz	a4,235a <basename+0x8a>
    23a4:	b7f9                	j	2372 <basename+0xa2>

00000000000023a6 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23a6:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23aa:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ac:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23b0:	2501                	sext.w	a0,a0
    23b2:	8082                	ret

00000000000023b4 <close>:

int close(int fd)
{
	if (fd == 1) {
    23b4:	4785                	li	a5,1
    23b6:	00f50863          	beq	a0,a5,23c6 <close+0x12>
	register long a7 __asm__("a7") = n;
    23ba:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23be:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23c2:	2501                	sext.w	a0,a0
    23c4:	8082                	ret
{
    23c6:	1101                	addi	sp,sp,-32
    23c8:	ec06                	sd	ra,24(sp)
    23ca:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23cc:	cdffe0ef          	jal	ra,10aa <__write_buffer>
		__clear_buffer();
    23d0:	d03fe0ef          	jal	ra,10d2 <__clear_buffer>
    23d4:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23d6:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23da:	00000073          	ecall
}
    23de:	60e2                	ld	ra,24(sp)
    23e0:	2501                	sext.w	a0,a0
    23e2:	6105                	addi	sp,sp,32
    23e4:	8082                	ret

00000000000023e6 <read>:
	register long a7 __asm__("a7") = n;
    23e6:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ea:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23ee:	8082                	ret

00000000000023f0 <write>:
	register long a7 __asm__("a7") = n;
    23f0:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23f4:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23f8:	8082                	ret

00000000000023fa <getpid>:
	register long a7 __asm__("a7") = n;
    23fa:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23fe:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2402:	2501                	sext.w	a0,a0
    2404:	8082                	ret

0000000000002406 <getppid>:
	register long a7 __asm__("a7") = n;
    2406:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    240a:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    240e:	2501                	sext.w	a0,a0
    2410:	8082                	ret

0000000000002412 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2412:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2416:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    241a:	2501                	sext.w	a0,a0
    241c:	8082                	ret

000000000000241e <fork>:
	register long a7 __asm__("a7") = n;
    241e:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2422:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2426:	2501                	sext.w	a0,a0
    2428:	8082                	ret

000000000000242a <exit>:

void exit(int code)
{
    242a:	1141                	addi	sp,sp,-16
    242c:	e406                	sd	ra,8(sp)
    242e:	e022                	sd	s0,0(sp)
    2430:	842a                	mv	s0,a0
	__write_buffer();
    2432:	c79fe0ef          	jal	ra,10aa <__write_buffer>
	__clear_buffer();
    2436:	c9dfe0ef          	jal	ra,10d2 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    243a:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    243e:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2440:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2444:	60a2                	ld	ra,8(sp)
    2446:	6402                	ld	s0,0(sp)
    2448:	0141                	addi	sp,sp,16
    244a:	8082                	ret

000000000000244c <waitpid>:
	register long a7 __asm__("a7") = n;
    244c:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2450:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2454:	2501                	sext.w	a0,a0
    2456:	8082                	ret

0000000000002458 <exec>:
	register long a7 __asm__("a7") = n;
    2458:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    245c:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2460:	2501                	sext.w	a0,a0
    2462:	8082                	ret

0000000000002464 <get_mtime>:

int64 get_mtime()
{
    2464:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2466:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    246a:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    246c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    246e:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2472:	2501                	sext.w	a0,a0
    2474:	ed01                	bnez	a0,248c <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2476:	6722                	ld	a4,8(sp)
    2478:	3e800793          	li	a5,1000
    247c:	6682                	ld	a3,0(sp)
    247e:	02f75733          	divu	a4,a4,a5
    2482:	02d78533          	mul	a0,a5,a3
    2486:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2488:	0141                	addi	sp,sp,16
    248a:	8082                	ret
	return -1;
    248c:	557d                	li	a0,-1
    248e:	bfed                	j	2488 <get_mtime+0x24>

0000000000002490 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2490:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2494:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2498:	2501                	sext.w	a0,a0
    249a:	8082                	ret

000000000000249c <sleep>:

int sleep(unsigned long long time)
{
    249c:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    249e:	880a                	mv	a6,sp
{
    24a0:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24a2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a6:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24a8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24aa:	00000073          	ecall
	if (err == 0) {
    24ae:	2501                	sext.w	a0,a0
    24b0:	ed31                	bnez	a0,250c <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24b2:	6722                	ld	a4,8(sp)
    24b4:	3e800793          	li	a5,1000
    24b8:	6682                	ld	a3,0(sp)
    24ba:	02f75733          	divu	a4,a4,a5
    24be:	02d787b3          	mul	a5,a5,a3
    24c2:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24c4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24ca:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24cc:	00000073          	ecall
	if (err == 0) {
    24d0:	2501                	sext.w	a0,a0
    24d2:	e915                	bnez	a0,2506 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24d4:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24d6:	3e800693          	li	a3,1000
    24da:	a819                	j	24f0 <sleep+0x54>
	__asm_syscall("r"(a7))
    24dc:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24e0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24e4:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24e6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e8:	00000073          	ecall
	if (err == 0) {
    24ec:	2501                	sext.w	a0,a0
    24ee:	ed01                	bnez	a0,2506 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24f0:	6722                	ld	a4,8(sp)
    24f2:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24f4:	07c00893          	li	a7,124
    24f8:	02d75733          	divu	a4,a4,a3
    24fc:	02f687b3          	mul	a5,a3,a5
    2500:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2502:	fcc7ede3          	bltu	a5,a2,24dc <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2506:	4501                	li	a0,0
    2508:	0141                	addi	sp,sp,16
    250a:	8082                	ret
    250c:	57fd                	li	a5,-1
    250e:	bf5d                	j	24c4 <sleep+0x28>

0000000000002510 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2510:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2514:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2518:	2501                	sext.w	a0,a0
    251a:	8082                	ret

000000000000251c <set_priority>:
	register long a7 __asm__("a7") = n;
    251c:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2520:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2524:	2501                	sext.w	a0,a0
    2526:	8082                	ret

0000000000002528 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2528:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    252c:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2530:	2501                	sext.w	a0,a0
    2532:	8082                	ret

0000000000002534 <munmap>:
	register long a7 __asm__("a7") = n;
    2534:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2538:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    253c:	2501                	sext.w	a0,a0
    253e:	8082                	ret

0000000000002540 <wait>:

int wait(int *code)
{
    2540:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2542:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2546:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2548:	00000073          	ecall
	return waitpid(-1, code);
}
    254c:	2501                	sext.w	a0,a0
    254e:	8082                	ret

0000000000002550 <spawn>:
	register long a7 __asm__("a7") = n;
    2550:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2554:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2558:	2501                	sext.w	a0,a0
    255a:	8082                	ret

000000000000255c <pipe>:
	register long a7 __asm__("a7") = n;
    255c:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2560:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2564:	2501                	sext.w	a0,a0
    2566:	8082                	ret

0000000000002568 <mailread>:
	register long a7 __asm__("a7") = n;
    2568:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    256c:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2570:	2501                	sext.w	a0,a0
    2572:	8082                	ret

0000000000002574 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2574:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2578:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    257c:	2501                	sext.w	a0,a0
    257e:	8082                	ret

0000000000002580 <fstat>:
	register long a7 __asm__("a7") = n;
    2580:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2584:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2588:	2501                	sext.w	a0,a0
    258a:	8082                	ret

000000000000258c <sys_linkat>:
	register long a4 __asm__("a4") = e;
    258c:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    258e:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2592:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2594:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2598:	2501                	sext.w	a0,a0
    259a:	8082                	ret

000000000000259c <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    259c:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    259e:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25a2:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25a4:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25a8:	2501                	sext.w	a0,a0
    25aa:	8082                	ret

00000000000025ac <link>:

int link(char *old_path, char *new_path)
{
    25ac:	87aa                	mv	a5,a0
    25ae:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25b0:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25b4:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25b8:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25ba:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25be:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25c0:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25c4:	2501                	sext.w	a0,a0
    25c6:	8082                	ret

00000000000025c8 <unlink>:

int unlink(char *path)
{
    25c8:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25ca:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25ce:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25d2:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d4:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25d8:	2501                	sext.w	a0,a0
    25da:	8082                	ret

00000000000025dc <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25dc:	00000797          	auipc	a5,0x0
    25e0:	3547b783          	ld	a5,852(a5) # 2930 <_GLOBAL_OFFSET_TABLE_+0x8>
    25e4:	439c                	lw	a5,0(a5)
    25e6:	c799                	beqz	a5,25f4 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25e8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ec:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25f0:	2501                	sext.w	a0,a0
    25f2:	8082                	ret
{
    25f4:	1101                	addi	sp,sp,-32
    25f6:	ec06                	sd	ra,24(sp)
    25f8:	e42e                	sd	a1,8(sp)
    25fa:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25fc:	fe7fe0ef          	jal	ra,15e2 <enable_thread_io_buffer>
    2600:	65a2                	ld	a1,8(sp)
    2602:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2604:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2608:	00000073          	ecall
}
    260c:	60e2                	ld	ra,24(sp)
    260e:	2501                	sext.w	a0,a0
    2610:	6105                	addi	sp,sp,32
    2612:	8082                	ret

0000000000002614 <gettid>:
	register long a7 __asm__("a7") = n;
    2614:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2618:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    261c:	2501                	sext.w	a0,a0
    261e:	8082                	ret

0000000000002620 <waittid>:

int waittid(int tid)
{
    2620:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2622:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2626:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    262a:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    262c:	2501                	sext.w	a0,a0
	while (ret == -2) {
    262e:	00e51e63          	bne	a0,a4,264a <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2632:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2636:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    263a:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    263e:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2640:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2644:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2646:	fee506e3          	beq	a0,a4,2632 <waittid+0x12>
	}
	return ret;
}
    264a:	8082                	ret

000000000000264c <mutex_create>:
	register long a7 __asm__("a7") = n;
    264c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2650:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2652:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret

000000000000265a <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    265a:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    265e:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2660:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2664:	2501                	sext.w	a0,a0
    2666:	8082                	ret

0000000000002668 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2668:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    266c:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2674:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2678:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2680:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2684:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <semaphore_up>:
	register long a7 __asm__("a7") = n;
    268c:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2690:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret

0000000000002698 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2698:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    269c:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26a0:	2501                	sext.w	a0,a0
    26a2:	8082                	ret

00000000000026a4 <condvar_create>:
	register long a7 __asm__("a7") = n;
    26a4:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26a8:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26b0:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26b4:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26b8:	2501                	sext.w	a0,a0
    26ba:	8082                	ret

00000000000026bc <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26bc:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c0:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26c4:	2501                	sext.w	a0,a0
    26c6:	8082                	ret

00000000000026c8 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26c8:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26cc:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26d0:	2501                	sext.w	a0,a0
    26d2:	8082                	ret
