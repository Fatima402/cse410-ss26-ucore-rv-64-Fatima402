
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_exit:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a8c1                	j	10d0 <__start_main>

0000000000001002 <main>:
const int max_child = 32;

const int MAGIC = 0x1234;

int main()
{
    1002:	7179                	addi	sp,sp,-48
	puts("I am the parent. Forking the child...");
    1004:	00001517          	auipc	a0,0x1
    1008:	73450513          	addi	a0,a0,1844 # 2738 <enable_deadlock_detect+0xe>
{
    100c:	f406                	sd	ra,40(sp)
    100e:	ec26                	sd	s1,24(sp)
    1010:	f022                	sd	s0,32(sp)
	puts("I am the parent. Forking the child...");
    1012:	12f000ef          	jal	ra,1940 <puts>
	int pid = fork();
    1016:	46a010ef          	jal	ra,2480 <fork>
    101a:	84aa                	mv	s1,a0
	if (pid == 0) {
    101c:	ed41                	bnez	a0,10b4 <main+0xb2>
		puts("I am the child.");
    101e:	00001517          	auipc	a0,0x1
    1022:	74250513          	addi	a0,a0,1858 # 2760 <enable_deadlock_detect+0x36>
    1026:	11b000ef          	jal	ra,1940 <puts>
    102a:	4421                	li	s0,8
		for (int i = 0; i < 8; ++i) {
    102c:	347d                	addiw	s0,s0,-1
			sched_yield();
    102e:	446010ef          	jal	ra,2474 <sched_yield>
		for (int i = 0; i < 8; ++i) {
    1032:	fc6d                	bnez	s0,102c <main+0x2a>
		}
		exit(MAGIC);
    1034:	6505                	lui	a0,0x1
    1036:	23450513          	addi	a0,a0,564 # 1234 <printf+0xa>
    103a:	452010ef          	jal	ra,248c <exit>
	} else {
		printf("I am parent, fork a child pid %d\n", pid);
	}

	puts("I am the parent, waiting now..");
    103e:	00001517          	auipc	a0,0x1
    1042:	75a50513          	addi	a0,a0,1882 # 2798 <enable_deadlock_detect+0x6e>
    1046:	0fb000ef          	jal	ra,1940 <puts>
	int xstate = 0;
	if (waitpid(pid, &xstate) != pid || xstate != MAGIC) {
    104a:	0060                	addi	s0,sp,12
    104c:	85a2                	mv	a1,s0
    104e:	8526                	mv	a0,s1
	int xstate = 0;
    1050:	c602                	sw	zero,12(sp)
	if (waitpid(pid, &xstate) != pid || xstate != MAGIC) {
    1052:	45c010ef          	jal	ra,24ae <waitpid>
    1056:	00951863          	bne	a0,s1,1066 <main+0x64>
    105a:	4732                	lw	a4,12(sp)
    105c:	6785                	lui	a5,0x1
    105e:	23478793          	addi	a5,a5,564 # 1234 <printf+0xa>
    1062:	00f70963          	beq	a4,a5,1074 <main+0x72>
		printf("wait %d fail\n", pid);
    1066:	85a6                	mv	a1,s1
    1068:	00001517          	auipc	a0,0x1
    106c:	75050513          	addi	a0,a0,1872 # 27b8 <enable_deadlock_detect+0x8e>
    1070:	1ba000ef          	jal	ra,122a <printf>
	}
	if (waitpid(pid, &xstate) > 0 || wait(&xstate) > 0) {
    1074:	85a2                	mv	a1,s0
    1076:	8526                	mv	a0,s1
    1078:	436010ef          	jal	ra,24ae <waitpid>
    107c:	04a05463          	blez	a0,10c4 <main+0xc2>
		printf("wait should fail\n", pid);
    1080:	85a6                	mv	a1,s1
    1082:	00001517          	auipc	a0,0x1
    1086:	74650513          	addi	a0,a0,1862 # 27c8 <enable_deadlock_detect+0x9e>
    108a:	1a0000ef          	jal	ra,122a <printf>
	}
	printf("waitpid %d ok.\n", pid);
    108e:	85a6                	mv	a1,s1
    1090:	00001517          	auipc	a0,0x1
    1094:	75050513          	addi	a0,a0,1872 # 27e0 <enable_deadlock_detect+0xb6>
    1098:	192000ef          	jal	ra,122a <printf>
	puts("exit pass.");
    109c:	00001517          	auipc	a0,0x1
    10a0:	75450513          	addi	a0,a0,1876 # 27f0 <enable_deadlock_detect+0xc6>
    10a4:	09d000ef          	jal	ra,1940 <puts>
	return 0;
}
    10a8:	70a2                	ld	ra,40(sp)
    10aa:	7402                	ld	s0,32(sp)
    10ac:	64e2                	ld	s1,24(sp)
    10ae:	4501                	li	a0,0
    10b0:	6145                	addi	sp,sp,48
    10b2:	8082                	ret
		printf("I am parent, fork a child pid %d\n", pid);
    10b4:	85aa                	mv	a1,a0
    10b6:	00001517          	auipc	a0,0x1
    10ba:	6ba50513          	addi	a0,a0,1722 # 2770 <enable_deadlock_detect+0x46>
    10be:	16c000ef          	jal	ra,122a <printf>
    10c2:	bfb5                	j	103e <main+0x3c>
	if (waitpid(pid, &xstate) > 0 || wait(&xstate) > 0) {
    10c4:	8522                	mv	a0,s0
    10c6:	4dc010ef          	jal	ra,25a2 <wait>
    10ca:	faa04be3          	bgtz	a0,1080 <main+0x7e>
    10ce:	b7c1                	j	108e <main+0x8c>

00000000000010d0 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    10d0:	1141                	addi	sp,sp,-16
    10d2:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    10d4:	f2fff0ef          	jal	ra,1002 <main>
    10d8:	3b4010ef          	jal	ra,248c <exit>
	return 0;
    10dc:	60a2                	ld	ra,8(sp)
    10de:	4501                	li	a0,0
    10e0:	0141                	addi	sp,sp,16
    10e2:	8082                	ret

00000000000010e4 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    10e4:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    10e6:	4605                	li	a2,1
    10e8:	00f10593          	addi	a1,sp,15
    10ec:	4501                	li	a0,0
{
    10ee:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10f0:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10f4:	354010ef          	jal	ra,2448 <read>
    10f8:	4785                	li	a5,1
    10fa:	00f51763          	bne	a0,a5,1108 <getchar+0x24>
		return byte;
    10fe:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1102:	60e2                	ld	ra,24(sp)
    1104:	6105                	addi	sp,sp,32
    1106:	8082                	ret
		return EOF;
    1108:	557d                	li	a0,-1
    110a:	bfe5                	j	1102 <getchar+0x1e>

000000000000110c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    110c:	00001517          	auipc	a0,0x1
    1110:	7f452503          	lw	a0,2036(a0) # 2900 <buffer_len>
    1114:	e111                	bnez	a0,1118 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1116:	8082                	ret
{
    1118:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    111a:	862a                	mv	a2,a0
    111c:	00001597          	auipc	a1,0x1
    1120:	7ec58593          	addi	a1,a1,2028 # 2908 <buffer>
    1124:	4505                	li	a0,1
{
    1126:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1128:	32a010ef          	jal	ra,2452 <write>
}
    112c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    112e:	2501                	sext.w	a0,a0
}
    1130:	0141                	addi	sp,sp,16
    1132:	8082                	ret

0000000000001134 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1134:	00001797          	auipc	a5,0x1
    1138:	7c07a623          	sw	zero,1996(a5) # 2900 <buffer_len>
}
    113c:	8082                	ret

000000000000113e <__fflush>:
	if (buffer_len == 0)
    113e:	00001517          	auipc	a0,0x1
    1142:	7c252503          	lw	a0,1986(a0) # 2900 <buffer_len>
    1146:	e511                	bnez	a0,1152 <__fflush+0x14>
	buffer_len = 0;
    1148:	00001797          	auipc	a5,0x1
    114c:	7a07ac23          	sw	zero,1976(a5) # 2900 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1150:	8082                	ret
{
    1152:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1154:	862a                	mv	a2,a0
    1156:	00001597          	auipc	a1,0x1
    115a:	7b258593          	addi	a1,a1,1970 # 2908 <buffer>
    115e:	4505                	li	a0,1
{
    1160:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1162:	2f0010ef          	jal	ra,2452 <write>
	return r >= 0 ? 0 : r;
    1166:	0005079b          	sext.w	a5,a0
}
    116a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    116c:	0017a793          	slti	a5,a5,1
    1170:	40f007bb          	negw	a5,a5
    1174:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1176:	00001797          	auipc	a5,0x1
    117a:	7807a523          	sw	zero,1930(a5) # 2900 <buffer_len>
	return r >= 0 ? 0 : r;
    117e:	2501                	sext.w	a0,a0
}
    1180:	0141                	addi	sp,sp,16
    1182:	8082                	ret

0000000000001184 <fflush>:

int fflush(int fd)
{
    1184:	1101                	addi	sp,sp,-32
    1186:	e822                	sd	s0,16(sp)
    1188:	ec06                	sd	ra,24(sp)
    118a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    118c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    118e:	4401                	li	s0,0
	if (fd == 1) {
    1190:	00e50863          	beq	a0,a4,11a0 <fflush+0x1c>
}
    1194:	60e2                	ld	ra,24(sp)
    1196:	8522                	mv	a0,s0
    1198:	6442                	ld	s0,16(sp)
    119a:	64a2                	ld	s1,8(sp)
    119c:	6105                	addi	sp,sp,32
    119e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11a0:	00001497          	auipc	s1,0x1
    11a4:	76048493          	addi	s1,s1,1888 # 2900 <buffer_len>
    11a8:	1084a703          	lw	a4,264(s1)
    11ac:	02a70e63          	beq	a4,a0,11e8 <fflush+0x64>
	if (buffer_len == 0)
    11b0:	4080                	lw	s0,0(s1)
    11b2:	c00d                	beqz	s0,11d4 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11b4:	8622                	mv	a2,s0
    11b6:	00001597          	auipc	a1,0x1
    11ba:	75258593          	addi	a1,a1,1874 # 2908 <buffer>
    11be:	294010ef          	jal	ra,2452 <write>
	return r >= 0 ? 0 : r;
    11c2:	0005079b          	sext.w	a5,a0
    11c6:	0017a793          	slti	a5,a5,1
    11ca:	40f007bb          	negw	a5,a5
    11ce:	8d7d                	and	a0,a0,a5
    11d0:	0005041b          	sext.w	s0,a0
}
    11d4:	60e2                	ld	ra,24(sp)
    11d6:	8522                	mv	a0,s0
    11d8:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    11da:	00001797          	auipc	a5,0x1
    11de:	7207a323          	sw	zero,1830(a5) # 2900 <buffer_len>
}
    11e2:	64a2                	ld	s1,8(sp)
    11e4:	6105                	addi	sp,sp,32
    11e6:	8082                	ret
			mutex_lock(buffer_lock);
    11e8:	10c4a503          	lw	a0,268(s1)
    11ec:	4de010ef          	jal	ra,26ca <mutex_lock>
	if (buffer_len == 0)
    11f0:	4080                	lw	s0,0(s1)
    11f2:	e811                	bnez	s0,1206 <fflush+0x82>
			mutex_unlock(buffer_lock);
    11f4:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11f8:	00001797          	auipc	a5,0x1
    11fc:	7007a423          	sw	zero,1800(a5) # 2900 <buffer_len>
			mutex_unlock(buffer_lock);
    1200:	4d6010ef          	jal	ra,26d6 <mutex_unlock>
    1204:	bf41                	j	1194 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1206:	8622                	mv	a2,s0
    1208:	00001597          	auipc	a1,0x1
    120c:	70058593          	addi	a1,a1,1792 # 2908 <buffer>
    1210:	4505                	li	a0,1
    1212:	240010ef          	jal	ra,2452 <write>
	return r >= 0 ? 0 : r;
    1216:	0005079b          	sext.w	a5,a0
    121a:	0017a793          	slti	a5,a5,1
    121e:	40f007bb          	negw	a5,a5
    1222:	8d7d                	and	a0,a0,a5
    1224:	0005041b          	sext.w	s0,a0
	return r;
    1228:	b7f1                	j	11f4 <fflush+0x70>

000000000000122a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    122a:	7131                	addi	sp,sp,-192
    122c:	e0da                	sd	s6,64(sp)
    122e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1230:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1232:	013c                	addi	a5,sp,136
{
    1234:	f0ca                	sd	s2,96(sp)
    1236:	ecce                	sd	s3,88(sp)
    1238:	e8d2                	sd	s4,80(sp)
    123a:	e4d6                	sd	s5,72(sp)
    123c:	fc86                	sd	ra,120(sp)
    123e:	f8a2                	sd	s0,112(sp)
    1240:	f4a6                	sd	s1,104(sp)
    1242:	89aa                	mv	s3,a0
    1244:	e52e                	sd	a1,136(sp)
    1246:	e932                	sd	a2,144(sp)
    1248:	ed36                	sd	a3,152(sp)
    124a:	f13a                	sd	a4,160(sp)
    124c:	f942                	sd	a6,176(sp)
    124e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1250:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1252:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1256:	00001a17          	auipc	s4,0x1
    125a:	6aaa0a13          	addi	s4,s4,1706 # 2900 <buffer_len>
    125e:	4a85                	li	s5,1
	buf[i++] = '0';
    1260:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1264:	0009c783          	lbu	a5,0(s3)
    1268:	18078663          	beqz	a5,13f4 <printf+0x1ca>
    126c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    126e:	19278d63          	beq	a5,s2,1408 <printf+0x1de>
    1272:	0015c783          	lbu	a5,1(a1)
    1276:	0585                	addi	a1,a1,1
    1278:	fbfd                	bnez	a5,126e <printf+0x44>
    127a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    127c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1280:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1284:	1b578863          	beq	a5,s5,1434 <printf+0x20a>
		len = out_unlocked(s, l);
    1288:	85a2                	mv	a1,s0
    128a:	854e                	mv	a0,s3
    128c:	42a000ef          	jal	ra,16b6 <out_unlocked>
		out(f, a, l);
		if (l)
    1290:	1c041063          	bnez	s0,1450 <printf+0x226>
			continue;
		if (s[1] == 0)
    1294:	0014c783          	lbu	a5,1(s1)
    1298:	14078e63          	beqz	a5,13f4 <printf+0x1ca>
			break;
		switch (s[1]) {
    129c:	07300713          	li	a4,115
    12a0:	1ce78863          	beq	a5,a4,1470 <printf+0x246>
    12a4:	1af76863          	bltu	a4,a5,1454 <printf+0x22a>
    12a8:	06400713          	li	a4,100
    12ac:	22e78063          	beq	a5,a4,14cc <printf+0x2a2>
    12b0:	07000713          	li	a4,112
    12b4:	1ee79563          	bne	a5,a4,149e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12b8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12ba:	00001797          	auipc	a5,0x1
    12be:	75e78793          	addi	a5,a5,1886 # 2a18 <digits>
	buf[i++] = '0';
    12c2:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12c6:	6298                	ld	a4,0(a3)
    12c8:	06a1                	addi	a3,a3,8
    12ca:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12cc:	00471393          	slli	t2,a4,0x4
    12d0:	00871293          	slli	t0,a4,0x8
    12d4:	00c71f93          	slli	t6,a4,0xc
    12d8:	01071f13          	slli	t5,a4,0x10
    12dc:	01471e93          	slli	t4,a4,0x14
    12e0:	01871e13          	slli	t3,a4,0x18
    12e4:	01c71893          	slli	a7,a4,0x1c
    12e8:	02471813          	slli	a6,a4,0x24
    12ec:	02871513          	slli	a0,a4,0x28
    12f0:	02c71593          	slli	a1,a4,0x2c
    12f4:	03071613          	slli	a2,a4,0x30
    12f8:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12fc:	03c75413          	srli	s0,a4,0x3c
    1300:	01c7531b          	srliw	t1,a4,0x1c
    1304:	03c3d393          	srli	t2,t2,0x3c
    1308:	03c2d293          	srli	t0,t0,0x3c
    130c:	03cfdf93          	srli	t6,t6,0x3c
    1310:	03cf5f13          	srli	t5,t5,0x3c
    1314:	03cede93          	srli	t4,t4,0x3c
    1318:	03ce5e13          	srli	t3,t3,0x3c
    131c:	03c8d893          	srli	a7,a7,0x3c
    1320:	03c85813          	srli	a6,a6,0x3c
    1324:	9171                	srli	a0,a0,0x3c
    1326:	91f1                	srli	a1,a1,0x3c
    1328:	9271                	srli	a2,a2,0x3c
    132a:	92f1                	srli	a3,a3,0x3c
    132c:	95be                	add	a1,a1,a5
    132e:	963e                	add	a2,a2,a5
    1330:	96be                	add	a3,a3,a5
    1332:	943e                	add	s0,s0,a5
    1334:	93be                	add	t2,t2,a5
    1336:	92be                	add	t0,t0,a5
    1338:	9fbe                	add	t6,t6,a5
    133a:	9f3e                	add	t5,t5,a5
    133c:	9ebe                	add	t4,t4,a5
    133e:	9e3e                	add	t3,t3,a5
    1340:	98be                	add	a7,a7,a5
    1342:	933e                	add	t1,t1,a5
    1344:	983e                	add	a6,a6,a5
    1346:	953e                	add	a0,a0,a5
    1348:	0005c983          	lbu	s3,0(a1)
    134c:	00044403          	lbu	s0,0(s0)
    1350:	00064583          	lbu	a1,0(a2)
    1354:	0003c383          	lbu	t2,0(t2)
    1358:	0006c603          	lbu	a2,0(a3)
    135c:	0002c283          	lbu	t0,0(t0)
    1360:	000fcf83          	lbu	t6,0(t6)
    1364:	000f4f03          	lbu	t5,0(t5)
    1368:	000ece83          	lbu	t4,0(t4)
    136c:	000e4e03          	lbu	t3,0(t3)
    1370:	0008c883          	lbu	a7,0(a7)
    1374:	00034303          	lbu	t1,0(t1)
    1378:	00084803          	lbu	a6,0(a6)
    137c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1380:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1384:	92f1                	srli	a3,a3,0x3c
    1386:	8b3d                	andi	a4,a4,15
    1388:	96be                	add	a3,a3,a5
    138a:	97ba                	add	a5,a5,a4
    138c:	00810d23          	sb	s0,26(sp)
    1390:	00710da3          	sb	t2,27(sp)
    1394:	00510e23          	sb	t0,28(sp)
    1398:	01f10ea3          	sb	t6,29(sp)
    139c:	01e10f23          	sb	t5,30(sp)
    13a0:	01d10fa3          	sb	t4,31(sp)
    13a4:	03c10023          	sb	t3,32(sp)
    13a8:	031100a3          	sb	a7,33(sp)
    13ac:	02610123          	sb	t1,34(sp)
    13b0:	030101a3          	sb	a6,35(sp)
    13b4:	02a10223          	sb	a0,36(sp)
    13b8:	033102a3          	sb	s3,37(sp)
    13bc:	02b10323          	sb	a1,38(sp)
    13c0:	02c103a3          	sb	a2,39(sp)
    13c4:	0006c683          	lbu	a3,0(a3)
    13c8:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    13cc:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13d0:	02d10423          	sb	a3,40(sp)
    13d4:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    13d8:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    13dc:	11578263          	beq	a5,s5,14e0 <printf+0x2b6>
		len = out_unlocked(s, l);
    13e0:	45c9                	li	a1,18
    13e2:	0828                	addi	a0,sp,24
    13e4:	2d2000ef          	jal	ra,16b6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13e8:	00248993          	addi	s3,s1,2
		if (!*s)
    13ec:	0009c783          	lbu	a5,0(s3)
    13f0:	e6079ee3          	bnez	a5,126c <printf+0x42>
	}
	va_end(ap);
    13f4:	70e6                	ld	ra,120(sp)
    13f6:	7446                	ld	s0,112(sp)
    13f8:	74a6                	ld	s1,104(sp)
    13fa:	7906                	ld	s2,96(sp)
    13fc:	69e6                	ld	s3,88(sp)
    13fe:	6a46                	ld	s4,80(sp)
    1400:	6aa6                	ld	s5,72(sp)
    1402:	6b06                	ld	s6,64(sp)
    1404:	6129                	addi	sp,sp,192
    1406:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1408:	0005c783          	lbu	a5,0(a1)
    140c:	84ae                	mv	s1,a1
    140e:	01278963          	beq	a5,s2,1420 <printf+0x1f6>
    1412:	b5ad                	j	127c <printf+0x52>
    1414:	0024c783          	lbu	a5,2(s1)
    1418:	0585                	addi	a1,a1,1
    141a:	0489                	addi	s1,s1,2
    141c:	e72790e3          	bne	a5,s2,127c <printf+0x52>
    1420:	0014c783          	lbu	a5,1(s1)
    1424:	ff2788e3          	beq	a5,s2,1414 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1428:	108a2783          	lw	a5,264(s4)
		l = z - a;
    142c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1430:	e5579ce3          	bne	a5,s5,1288 <printf+0x5e>
		mutex_lock(buffer_lock);
    1434:	10ca2503          	lw	a0,268(s4)
    1438:	292010ef          	jal	ra,26ca <mutex_lock>
		len = out_unlocked(s, l);
    143c:	85a2                	mv	a1,s0
    143e:	854e                	mv	a0,s3
    1440:	276000ef          	jal	ra,16b6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1444:	10ca2503          	lw	a0,268(s4)
    1448:	28e010ef          	jal	ra,26d6 <mutex_unlock>
		if (l)
    144c:	e40404e3          	beqz	s0,1294 <printf+0x6a>
    1450:	89a6                	mv	s3,s1
    1452:	bd09                	j	1264 <printf+0x3a>
		switch (s[1]) {
    1454:	07800713          	li	a4,120
    1458:	04e79363          	bne	a5,a4,149e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    145c:	67c2                	ld	a5,16(sp)
    145e:	45c1                	li	a1,16
		s += 2;
    1460:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1464:	4388                	lw	a0,0(a5)
    1466:	07a1                	addi	a5,a5,8
    1468:	e83e                	sd	a5,16(sp)
    146a:	5f8000ef          	jal	ra,1a62 <printint.constprop.0>
		s += 2;
    146e:	bfbd                	j	13ec <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1470:	67c2                	ld	a5,16(sp)
    1472:	6380                	ld	s0,0(a5)
    1474:	07a1                	addi	a5,a5,8
    1476:	e83e                	sd	a5,16(sp)
    1478:	1c040163          	beqz	s0,163a <printf+0x410>
			l = strnlen(a, 200);
    147c:	0c800593          	li	a1,200
    1480:	8522                	mv	a0,s0
    1482:	3f7000ef          	jal	ra,2078 <strnlen>
	if (buffer_lock_enabled == 1) {
    1486:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    148a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    148e:	19578663          	beq	a5,s5,161a <printf+0x3f0>
		len = out_unlocked(s, l);
    1492:	8522                	mv	a0,s0
    1494:	222000ef          	jal	ra,16b6 <out_unlocked>
		s += 2;
    1498:	00248993          	addi	s3,s1,2
    149c:	bf81                	j	13ec <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    149e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14a2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14a6:	0f578663          	beq	a5,s5,1592 <printf+0x368>
		len = out_unlocked(s, l);
    14aa:	0828                	addi	a0,sp,24
    14ac:	316000ef          	jal	ra,17c2 <out_unlocked.constprop.0>
			putchar(s[1]);
    14b0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14b4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14b8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14bc:	05578163          	beq	a5,s5,14fe <printf+0x2d4>
		len = out_unlocked(s, l);
    14c0:	0828                	addi	a0,sp,24
    14c2:	300000ef          	jal	ra,17c2 <out_unlocked.constprop.0>
		s += 2;
    14c6:	00248993          	addi	s3,s1,2
    14ca:	b70d                	j	13ec <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    14cc:	67c2                	ld	a5,16(sp)
    14ce:	45a9                	li	a1,10
		s += 2;
    14d0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    14d4:	4388                	lw	a0,0(a5)
    14d6:	07a1                	addi	a5,a5,8
    14d8:	e83e                	sd	a5,16(sp)
    14da:	588000ef          	jal	ra,1a62 <printint.constprop.0>
		s += 2;
    14de:	b739                	j	13ec <printf+0x1c2>
		mutex_lock(buffer_lock);
    14e0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14e4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14e8:	1e2010ef          	jal	ra,26ca <mutex_lock>
		len = out_unlocked(s, l);
    14ec:	45c9                	li	a1,18
    14ee:	0828                	addi	a0,sp,24
    14f0:	1c6000ef          	jal	ra,16b6 <out_unlocked>
		mutex_unlock(buffer_lock);
    14f4:	10ca2503          	lw	a0,268(s4)
    14f8:	1de010ef          	jal	ra,26d6 <mutex_unlock>
		s += 2;
    14fc:	bdc5                	j	13ec <printf+0x1c2>
		mutex_lock(buffer_lock);
    14fe:	10ca2503          	lw	a0,268(s4)
    1502:	1c8010ef          	jal	ra,26ca <mutex_lock>
		buffer[buffer_len++] = c;
    1506:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    150a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    150e:	0017861b          	addiw	a2,a5,1
    1512:	97d2                	add	a5,a5,s4
    1514:	00ca2023          	sw	a2,0(s4)
    1518:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    151c:	00c6cc63          	blt	a3,a2,1534 <printf+0x30a>
    1520:	47a9                	li	a5,10
    1522:	06f40663          	beq	s0,a5,158e <printf+0x364>
		mutex_unlock(buffer_lock);
    1526:	10ca2503          	lw	a0,268(s4)
		s += 2;
    152a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    152e:	1a8010ef          	jal	ra,26d6 <mutex_unlock>
		s += 2;
    1532:	bd6d                	j	13ec <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1534:	10000793          	li	a5,256
    1538:	00f61e63          	bne	a2,a5,1554 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    153c:	00001597          	auipc	a1,0x1
    1540:	3cc58593          	addi	a1,a1,972 # 2908 <buffer>
    1544:	4505                	li	a0,1
    1546:	70d000ef          	jal	ra,2452 <write>
	buffer_len = 0;
    154a:	00001797          	auipc	a5,0x1
    154e:	3a07ab23          	sw	zero,950(a5) # 2900 <buffer_len>
			if (r < 0) {
    1552:	bfd1                	j	1526 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1554:	709000ef          	jal	ra,245c <getpid>
    1558:	842a                	mv	s0,a0
    155a:	00001517          	auipc	a0,0x1
    155e:	2ae50513          	addi	a0,a0,686 # 2808 <enable_deadlock_detect+0xde>
    1562:	5d1000ef          	jal	ra,2332 <basename>
    1566:	872a                	mv	a4,a0
    1568:	00001617          	auipc	a2,0x1
    156c:	2e060613          	addi	a2,a2,736 # 2848 <enable_deadlock_detect+0x11e>
    1570:	05400793          	li	a5,84
    1574:	86a2                	mv	a3,s0
    1576:	45fd                	li	a1,31
    1578:	00001517          	auipc	a0,0x1
    157c:	2d850513          	addi	a0,a0,728 # 2850 <enable_deadlock_detect+0x126>
    1580:	cabff0ef          	jal	ra,122a <printf>
    1584:	557d                	li	a0,-1
    1586:	707000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    158a:	000a2603          	lw	a2,0(s4)
    158e:	de41                	beqz	a2,1526 <printf+0x2fc>
    1590:	b775                	j	153c <printf+0x312>
		mutex_lock(buffer_lock);
    1592:	10ca2503          	lw	a0,268(s4)
    1596:	134010ef          	jal	ra,26ca <mutex_lock>
		buffer[buffer_len++] = c;
    159a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    159e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15a2:	0017861b          	addiw	a2,a5,1
    15a6:	97d2                	add	a5,a5,s4
    15a8:	00ca2023          	sw	a2,0(s4)
    15ac:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15b0:	02c6d163          	bge	a3,a2,15d2 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15b4:	10000793          	li	a5,256
    15b8:	02f61263          	bne	a2,a5,15dc <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15bc:	00001597          	auipc	a1,0x1
    15c0:	34c58593          	addi	a1,a1,844 # 2908 <buffer>
    15c4:	4505                	li	a0,1
    15c6:	68d000ef          	jal	ra,2452 <write>
	buffer_len = 0;
    15ca:	00001797          	auipc	a5,0x1
    15ce:	3207ab23          	sw	zero,822(a5) # 2900 <buffer_len>
		mutex_unlock(buffer_lock);
    15d2:	10ca2503          	lw	a0,268(s4)
    15d6:	100010ef          	jal	ra,26d6 <mutex_unlock>
    15da:	bdd9                	j	14b0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    15dc:	681000ef          	jal	ra,245c <getpid>
    15e0:	842a                	mv	s0,a0
    15e2:	00001517          	auipc	a0,0x1
    15e6:	22650513          	addi	a0,a0,550 # 2808 <enable_deadlock_detect+0xde>
    15ea:	549000ef          	jal	ra,2332 <basename>
    15ee:	872a                	mv	a4,a0
    15f0:	00001617          	auipc	a2,0x1
    15f4:	25860613          	addi	a2,a2,600 # 2848 <enable_deadlock_detect+0x11e>
    15f8:	05400793          	li	a5,84
    15fc:	86a2                	mv	a3,s0
    15fe:	45fd                	li	a1,31
    1600:	00001517          	auipc	a0,0x1
    1604:	25050513          	addi	a0,a0,592 # 2850 <enable_deadlock_detect+0x126>
    1608:	c23ff0ef          	jal	ra,122a <printf>
    160c:	557d                	li	a0,-1
    160e:	67f000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    1612:	000a2603          	lw	a2,0(s4)
    1616:	de55                	beqz	a2,15d2 <printf+0x3a8>
    1618:	b755                	j	15bc <printf+0x392>
		mutex_lock(buffer_lock);
    161a:	10ca2503          	lw	a0,268(s4)
    161e:	e42e                	sd	a1,8(sp)
		s += 2;
    1620:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1624:	0a6010ef          	jal	ra,26ca <mutex_lock>
		len = out_unlocked(s, l);
    1628:	65a2                	ld	a1,8(sp)
    162a:	8522                	mv	a0,s0
    162c:	08a000ef          	jal	ra,16b6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1630:	10ca2503          	lw	a0,268(s4)
    1634:	0a2010ef          	jal	ra,26d6 <mutex_unlock>
		s += 2;
    1638:	bb55                	j	13ec <printf+0x1c2>
				a = "(null)";
    163a:	00001417          	auipc	s0,0x1
    163e:	1c640413          	addi	s0,s0,454 # 2800 <enable_deadlock_detect+0xd6>
    1642:	bd2d                	j	147c <printf+0x252>

0000000000001644 <enable_thread_io_buffer>:
{
    1644:	1101                	addi	sp,sp,-32
    1646:	e822                	sd	s0,16(sp)
    1648:	ec06                	sd	ra,24(sp)
    164a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    164c:	00001417          	auipc	s0,0x1
    1650:	2b440413          	addi	s0,s0,692 # 2900 <buffer_len>
    1654:	05a010ef          	jal	ra,26ae <mutex_create>
    1658:	10a42623          	sw	a0,268(s0)
    165c:	00054a63          	bltz	a0,1670 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1660:	4785                	li	a5,1
}
    1662:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1664:	10f42423          	sw	a5,264(s0)
}
    1668:	6442                	ld	s0,16(sp)
    166a:	64a2                	ld	s1,8(sp)
    166c:	6105                	addi	sp,sp,32
    166e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1670:	5ed000ef          	jal	ra,245c <getpid>
    1674:	84aa                	mv	s1,a0
    1676:	00001517          	auipc	a0,0x1
    167a:	19250513          	addi	a0,a0,402 # 2808 <enable_deadlock_detect+0xde>
    167e:	4b5000ef          	jal	ra,2332 <basename>
    1682:	872a                	mv	a4,a0
    1684:	04800793          	li	a5,72
    1688:	86a6                	mv	a3,s1
    168a:	00001517          	auipc	a0,0x1
    168e:	20650513          	addi	a0,a0,518 # 2890 <enable_deadlock_detect+0x166>
    1692:	00001617          	auipc	a2,0x1
    1696:	1b660613          	addi	a2,a2,438 # 2848 <enable_deadlock_detect+0x11e>
    169a:	45fd                	li	a1,31
    169c:	b8fff0ef          	jal	ra,122a <printf>
    16a0:	557d                	li	a0,-1
    16a2:	5eb000ef          	jal	ra,248c <exit>
	buffer_lock_enabled = 1;
    16a6:	4785                	li	a5,1
}
    16a8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16aa:	10f42423          	sw	a5,264(s0)
}
    16ae:	6442                	ld	s0,16(sp)
    16b0:	64a2                	ld	s1,8(sp)
    16b2:	6105                	addi	sp,sp,32
    16b4:	8082                	ret

00000000000016b6 <out_unlocked>:
{
    16b6:	7159                	addi	sp,sp,-112
    16b8:	f486                	sd	ra,104(sp)
    16ba:	f0a2                	sd	s0,96(sp)
    16bc:	eca6                	sd	s1,88(sp)
    16be:	e8ca                	sd	s2,80(sp)
    16c0:	e4ce                	sd	s3,72(sp)
    16c2:	e0d2                	sd	s4,64(sp)
    16c4:	fc56                	sd	s5,56(sp)
    16c6:	f85a                	sd	s6,48(sp)
    16c8:	f45e                	sd	s7,40(sp)
    16ca:	f062                	sd	s8,32(sp)
    16cc:	ec66                	sd	s9,24(sp)
    16ce:	e86a                	sd	s10,16(sp)
    16d0:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    16d2:	0e058663          	beqz	a1,17be <out_unlocked+0x108>
    16d6:	842a                	mv	s0,a0
    16d8:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    16dc:	4981                	li	s3,0
    16de:	00001d17          	auipc	s10,0x1
    16e2:	222d0d13          	addi	s10,s10,546 # 2900 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16e6:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16ea:	00001b17          	auipc	s6,0x1
    16ee:	21eb0b13          	addi	s6,s6,542 # 2908 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16f2:	10000a93          	li	s5,256
    16f6:	00001c97          	auipc	s9,0x1
    16fa:	112c8c93          	addi	s9,s9,274 # 2808 <enable_deadlock_detect+0xde>
    16fe:	00001c17          	auipc	s8,0x1
    1702:	14ac0c13          	addi	s8,s8,330 # 2848 <enable_deadlock_detect+0x11e>
    1706:	00001b97          	auipc	s7,0x1
    170a:	14ab8b93          	addi	s7,s7,330 # 2850 <enable_deadlock_detect+0x126>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    170e:	4a29                	li	s4,10
    1710:	a031                	j	171c <out_unlocked+0x66>
    1712:	09468863          	beq	a3,s4,17a2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1716:	0405                	addi	s0,s0,1
    1718:	04848163          	beq	s1,s0,175a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    171c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1720:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1724:	0017861b          	addiw	a2,a5,1
    1728:	97ea                	add	a5,a5,s10
    172a:	00cd2023          	sw	a2,0(s10)
    172e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1732:	fec950e3          	bge	s2,a2,1712 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1736:	05561263          	bne	a2,s5,177a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    173a:	85da                	mv	a1,s6
    173c:	4505                	li	a0,1
    173e:	515000ef          	jal	ra,2452 <write>
    1742:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1744:	00001797          	auipc	a5,0x1
    1748:	1a07ae23          	sw	zero,444(a5) # 2900 <buffer_len>
			if (r < 0) {
    174c:	06054763          	bltz	a0,17ba <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1750:	0405                	addi	s0,s0,1
			ret += r;
    1752:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1756:	fc8493e3          	bne	s1,s0,171c <out_unlocked+0x66>
}
    175a:	70a6                	ld	ra,104(sp)
    175c:	7406                	ld	s0,96(sp)
    175e:	64e6                	ld	s1,88(sp)
    1760:	6946                	ld	s2,80(sp)
    1762:	6a06                	ld	s4,64(sp)
    1764:	7ae2                	ld	s5,56(sp)
    1766:	7b42                	ld	s6,48(sp)
    1768:	7ba2                	ld	s7,40(sp)
    176a:	7c02                	ld	s8,32(sp)
    176c:	6ce2                	ld	s9,24(sp)
    176e:	6d42                	ld	s10,16(sp)
    1770:	6da2                	ld	s11,8(sp)
    1772:	854e                	mv	a0,s3
    1774:	69a6                	ld	s3,72(sp)
    1776:	6165                	addi	sp,sp,112
    1778:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    177a:	4e3000ef          	jal	ra,245c <getpid>
    177e:	8daa                	mv	s11,a0
    1780:	8566                	mv	a0,s9
    1782:	3b1000ef          	jal	ra,2332 <basename>
    1786:	872a                	mv	a4,a0
    1788:	8662                	mv	a2,s8
    178a:	05400793          	li	a5,84
    178e:	86ee                	mv	a3,s11
    1790:	45fd                	li	a1,31
    1792:	855e                	mv	a0,s7
    1794:	a97ff0ef          	jal	ra,122a <printf>
    1798:	557d                	li	a0,-1
    179a:	4f3000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    179e:	000d2603          	lw	a2,0(s10)
    17a2:	da35                	beqz	a2,1716 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17a4:	85da                	mv	a1,s6
    17a6:	4505                	li	a0,1
    17a8:	4ab000ef          	jal	ra,2452 <write>
    17ac:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17ae:	00001797          	auipc	a5,0x1
    17b2:	1407a923          	sw	zero,338(a5) # 2900 <buffer_len>
			if (r < 0) {
    17b6:	f8055de3          	bgez	a0,1750 <out_unlocked+0x9a>
    17ba:	89aa                	mv	s3,a0
    17bc:	bf79                	j	175a <out_unlocked+0xa4>
	int ret = 0;
    17be:	4981                	li	s3,0
    17c0:	bf69                	j	175a <out_unlocked+0xa4>

00000000000017c2 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17c2:	1101                	addi	sp,sp,-32
    17c4:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17c6:	00001497          	auipc	s1,0x1
    17ca:	13a48493          	addi	s1,s1,314 # 2900 <buffer_len>
    17ce:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    17d0:	ec06                	sd	ra,24(sp)
    17d2:	e822                	sd	s0,16(sp)
		char c = s[i];
    17d4:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    17d8:	0017861b          	addiw	a2,a5,1
    17dc:	97a6                	add	a5,a5,s1
    17de:	00e78423          	sb	a4,8(a5)
    17e2:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17e4:	0ff00793          	li	a5,255
    17e8:	00c7cc63          	blt	a5,a2,1800 <out_unlocked.constprop.0+0x3e>
    17ec:	47a9                	li	a5,10
    17ee:	06f70c63          	beq	a4,a5,1866 <out_unlocked.constprop.0+0xa4>
    17f2:	4601                	li	a2,0
}
    17f4:	60e2                	ld	ra,24(sp)
    17f6:	6442                	ld	s0,16(sp)
    17f8:	64a2                	ld	s1,8(sp)
    17fa:	8532                	mv	a0,a2
    17fc:	6105                	addi	sp,sp,32
    17fe:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1800:	10000793          	li	a5,256
    1804:	02f61563          	bne	a2,a5,182e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1808:	00001597          	auipc	a1,0x1
    180c:	10058593          	addi	a1,a1,256 # 2908 <buffer>
    1810:	4505                	li	a0,1
    1812:	441000ef          	jal	ra,2452 <write>
}
    1816:	60e2                	ld	ra,24(sp)
    1818:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    181a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    181e:	00001797          	auipc	a5,0x1
    1822:	0e07a123          	sw	zero,226(a5) # 2900 <buffer_len>
}
    1826:	64a2                	ld	s1,8(sp)
    1828:	8532                	mv	a0,a2
    182a:	6105                	addi	sp,sp,32
    182c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    182e:	42f000ef          	jal	ra,245c <getpid>
    1832:	842a                	mv	s0,a0
    1834:	00001517          	auipc	a0,0x1
    1838:	fd450513          	addi	a0,a0,-44 # 2808 <enable_deadlock_detect+0xde>
    183c:	2f7000ef          	jal	ra,2332 <basename>
    1840:	872a                	mv	a4,a0
    1842:	00001617          	auipc	a2,0x1
    1846:	00660613          	addi	a2,a2,6 # 2848 <enable_deadlock_detect+0x11e>
    184a:	05400793          	li	a5,84
    184e:	86a2                	mv	a3,s0
    1850:	45fd                	li	a1,31
    1852:	00001517          	auipc	a0,0x1
    1856:	ffe50513          	addi	a0,a0,-2 # 2850 <enable_deadlock_detect+0x126>
    185a:	9d1ff0ef          	jal	ra,122a <printf>
    185e:	557d                	li	a0,-1
    1860:	42d000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    1864:	4090                	lw	a2,0(s1)
    1866:	d659                	beqz	a2,17f4 <out_unlocked.constprop.0+0x32>
    1868:	b745                	j	1808 <out_unlocked.constprop.0+0x46>

000000000000186a <putchar>:
{
    186a:	7139                	addi	sp,sp,-64
    186c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    186e:	00001497          	auipc	s1,0x1
    1872:	09248493          	addi	s1,s1,146 # 2900 <buffer_len>
    1876:	1084a703          	lw	a4,264(s1)
{
    187a:	f822                	sd	s0,48(sp)
	char byte = c;
    187c:	0ff57413          	zext.b	s0,a0
{
    1880:	fc06                	sd	ra,56(sp)
	char byte = c;
    1882:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1886:	4785                	li	a5,1
    1888:	00f70d63          	beq	a4,a5,18a2 <putchar+0x38>
		len = out_unlocked(s, l);
    188c:	01f10513          	addi	a0,sp,31
    1890:	f33ff0ef          	jal	ra,17c2 <out_unlocked.constprop.0>
}
    1894:	70e2                	ld	ra,56(sp)
    1896:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1898:	862a                	mv	a2,a0
}
    189a:	74a2                	ld	s1,40(sp)
    189c:	8532                	mv	a0,a2
    189e:	6121                	addi	sp,sp,64
    18a0:	8082                	ret
		mutex_lock(buffer_lock);
    18a2:	10c4a503          	lw	a0,268(s1)
    18a6:	625000ef          	jal	ra,26ca <mutex_lock>
		buffer[buffer_len++] = c;
    18aa:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18ac:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18b0:	0017861b          	addiw	a2,a5,1
    18b4:	97a6                	add	a5,a5,s1
    18b6:	c090                	sw	a2,0(s1)
    18b8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18bc:	02c6c263          	blt	a3,a2,18e0 <putchar+0x76>
    18c0:	47a9                	li	a5,10
    18c2:	06f40d63          	beq	s0,a5,193c <putchar+0xd2>
    18c6:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18c8:	10c4a503          	lw	a0,268(s1)
    18cc:	e432                	sd	a2,8(sp)
    18ce:	609000ef          	jal	ra,26d6 <mutex_unlock>
    18d2:	6622                	ld	a2,8(sp)
}
    18d4:	70e2                	ld	ra,56(sp)
    18d6:	7442                	ld	s0,48(sp)
    18d8:	74a2                	ld	s1,40(sp)
    18da:	8532                	mv	a0,a2
    18dc:	6121                	addi	sp,sp,64
    18de:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18e0:	10000793          	li	a5,256
    18e4:	02f61063          	bne	a2,a5,1904 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18e8:	00001597          	auipc	a1,0x1
    18ec:	02058593          	addi	a1,a1,32 # 2908 <buffer>
    18f0:	4505                	li	a0,1
    18f2:	361000ef          	jal	ra,2452 <write>
    18f6:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18fa:	00001797          	auipc	a5,0x1
    18fe:	0007a323          	sw	zero,6(a5) # 2900 <buffer_len>
			if (r < 0) {
    1902:	b7d9                	j	18c8 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1904:	359000ef          	jal	ra,245c <getpid>
    1908:	842a                	mv	s0,a0
    190a:	00001517          	auipc	a0,0x1
    190e:	efe50513          	addi	a0,a0,-258 # 2808 <enable_deadlock_detect+0xde>
    1912:	221000ef          	jal	ra,2332 <basename>
    1916:	872a                	mv	a4,a0
    1918:	00001617          	auipc	a2,0x1
    191c:	f3060613          	addi	a2,a2,-208 # 2848 <enable_deadlock_detect+0x11e>
    1920:	05400793          	li	a5,84
    1924:	86a2                	mv	a3,s0
    1926:	45fd                	li	a1,31
    1928:	00001517          	auipc	a0,0x1
    192c:	f2850513          	addi	a0,a0,-216 # 2850 <enable_deadlock_detect+0x126>
    1930:	8fbff0ef          	jal	ra,122a <printf>
    1934:	557d                	li	a0,-1
    1936:	357000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    193a:	4090                	lw	a2,0(s1)
    193c:	d651                	beqz	a2,18c8 <putchar+0x5e>
    193e:	b76d                	j	18e8 <putchar+0x7e>

0000000000001940 <puts>:
{
    1940:	7139                	addi	sp,sp,-64
    1942:	f822                	sd	s0,48(sp)
    1944:	f426                	sd	s1,40(sp)
    1946:	fc06                	sd	ra,56(sp)
    1948:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    194a:	00001417          	auipc	s0,0x1
    194e:	fb640413          	addi	s0,s0,-74 # 2900 <buffer_len>
{
    1952:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1954:	638000ef          	jal	ra,1f8c <strlen>
	if (buffer_lock_enabled == 1) {
    1958:	10842703          	lw	a4,264(s0)
    195c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    195e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1960:	04f70563          	beq	a4,a5,19aa <puts+0x6a>
		len = out_unlocked(s, l);
    1964:	8526                	mv	a0,s1
    1966:	d51ff0ef          	jal	ra,16b6 <out_unlocked>
    196a:	892a                	mv	s2,a0
    196c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    196e:	00095963          	bgez	s2,1980 <puts+0x40>
}
    1972:	70e2                	ld	ra,56(sp)
    1974:	7442                	ld	s0,48(sp)
    1976:	7902                	ld	s2,32(sp)
    1978:	8526                	mv	a0,s1
    197a:	74a2                	ld	s1,40(sp)
    197c:	6121                	addi	sp,sp,64
    197e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1980:	10842703          	lw	a4,264(s0)
	char byte = c;
    1984:	44a9                	li	s1,10
    1986:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    198a:	4785                	li	a5,1
    198c:	02f70e63          	beq	a4,a5,19c8 <puts+0x88>
		len = out_unlocked(s, l);
    1990:	01f10513          	addi	a0,sp,31
    1994:	e2fff0ef          	jal	ra,17c2 <out_unlocked.constprop.0>
}
    1998:	70e2                	ld	ra,56(sp)
    199a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    199c:	41f5549b          	sraiw	s1,a0,0x1f
}
    19a0:	7902                	ld	s2,32(sp)
    19a2:	8526                	mv	a0,s1
    19a4:	74a2                	ld	s1,40(sp)
    19a6:	6121                	addi	sp,sp,64
    19a8:	8082                	ret
		mutex_lock(buffer_lock);
    19aa:	e42a                	sd	a0,8(sp)
    19ac:	10c42503          	lw	a0,268(s0)
    19b0:	51b000ef          	jal	ra,26ca <mutex_lock>
		len = out_unlocked(s, l);
    19b4:	65a2                	ld	a1,8(sp)
    19b6:	8526                	mv	a0,s1
    19b8:	cffff0ef          	jal	ra,16b6 <out_unlocked>
    19bc:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19be:	10c42503          	lw	a0,268(s0)
    19c2:	515000ef          	jal	ra,26d6 <mutex_unlock>
    19c6:	b75d                	j	196c <puts+0x2c>
		mutex_lock(buffer_lock);
    19c8:	10c42503          	lw	a0,268(s0)
    19cc:	4ff000ef          	jal	ra,26ca <mutex_lock>
		buffer[buffer_len++] = c;
    19d0:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19d6:	0017861b          	addiw	a2,a5,1
    19da:	97a2                	add	a5,a5,s0
    19dc:	c010                	sw	a2,0(s0)
    19de:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19e2:	06c6dc63          	bge	a3,a2,1a5a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    19e6:	10000793          	li	a5,256
    19ea:	02f61c63          	bne	a2,a5,1a22 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19ee:	00001597          	auipc	a1,0x1
    19f2:	f1a58593          	addi	a1,a1,-230 # 2908 <buffer>
    19f6:	4505                	li	a0,1
    19f8:	25b000ef          	jal	ra,2452 <write>
			if (r < 0) {
    19fc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19fe:	00001797          	auipc	a5,0x1
    1a02:	f007a123          	sw	zero,-254(a5) # 2900 <buffer_len>
			if (r < 0) {
    1a06:	04054c63          	bltz	a0,1a5e <puts+0x11e>
			if (r < buffer_len) {
    1a0a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a0c:	10c42503          	lw	a0,268(s0)
    1a10:	4c7000ef          	jal	ra,26d6 <mutex_unlock>
}
    1a14:	70e2                	ld	ra,56(sp)
    1a16:	7442                	ld	s0,48(sp)
    1a18:	7902                	ld	s2,32(sp)
    1a1a:	8526                	mv	a0,s1
    1a1c:	74a2                	ld	s1,40(sp)
    1a1e:	6121                	addi	sp,sp,64
    1a20:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a22:	23b000ef          	jal	ra,245c <getpid>
    1a26:	84aa                	mv	s1,a0
    1a28:	00001517          	auipc	a0,0x1
    1a2c:	de050513          	addi	a0,a0,-544 # 2808 <enable_deadlock_detect+0xde>
    1a30:	103000ef          	jal	ra,2332 <basename>
    1a34:	872a                	mv	a4,a0
    1a36:	00001617          	auipc	a2,0x1
    1a3a:	e1260613          	addi	a2,a2,-494 # 2848 <enable_deadlock_detect+0x11e>
    1a3e:	05400793          	li	a5,84
    1a42:	86a6                	mv	a3,s1
    1a44:	45fd                	li	a1,31
    1a46:	00001517          	auipc	a0,0x1
    1a4a:	e0a50513          	addi	a0,a0,-502 # 2850 <enable_deadlock_detect+0x126>
    1a4e:	fdcff0ef          	jal	ra,122a <printf>
    1a52:	557d                	li	a0,-1
    1a54:	239000ef          	jal	ra,248c <exit>
	if (buffer_len == 0)
    1a58:	4010                	lw	a2,0(s0)
    1a5a:	da45                	beqz	a2,1a0a <puts+0xca>
    1a5c:	bf49                	j	19ee <puts+0xae>
    1a5e:	54fd                	li	s1,-1
    1a60:	b775                	j	1a0c <puts+0xcc>

0000000000001a62 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a62:	715d                	addi	sp,sp,-80
    1a64:	e486                	sd	ra,72(sp)
    1a66:	e0a2                	sd	s0,64(sp)
    1a68:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a6a:	14054363          	bltz	a0,1bb0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a6e:	02b577bb          	remuw	a5,a0,a1
    1a72:	00001617          	auipc	a2,0x1
    1a76:	fa660613          	addi	a2,a2,-90 # 2a18 <digits>
	buf[16] = 0;
    1a7a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a7e:	0005871b          	sext.w	a4,a1
    1a82:	1782                	slli	a5,a5,0x20
    1a84:	9381                	srli	a5,a5,0x20
    1a86:	97b2                	add	a5,a5,a2
    1a88:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a8c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a90:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a94:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a96:	0eb56763          	bltu	a0,a1,1b84 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a9a:	02e877bb          	remuw	a5,a6,a4
    1a9e:	1782                	slli	a5,a5,0x20
    1aa0:	9381                	srli	a5,a5,0x20
    1aa2:	97b2                	add	a5,a5,a2
    1aa4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1aa8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1aac:	02f10323          	sb	a5,38(sp)
    1ab0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ab2:	0ce86963          	bltu	a6,a4,1b84 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ab6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1aba:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1abe:	1582                	slli	a1,a1,0x20
    1ac0:	9181                	srli	a1,a1,0x20
    1ac2:	95b2                	add	a1,a1,a2
    1ac4:	0005c583          	lbu	a1,0(a1)
    1ac8:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1acc:	0007859b          	sext.w	a1,a5
    1ad0:	16e6e563          	bltu	a3,a4,1c3a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ad4:	02e7f6bb          	remuw	a3,a5,a4
    1ad8:	1682                	slli	a3,a3,0x20
    1ada:	9281                	srli	a3,a3,0x20
    1adc:	96b2                	add	a3,a3,a2
    1ade:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae2:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ae6:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1aea:	16e5e163          	bltu	a1,a4,1c4c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1aee:	02e876bb          	remuw	a3,a6,a4
    1af2:	1682                	slli	a3,a3,0x20
    1af4:	9281                	srli	a3,a3,0x20
    1af6:	96b2                	add	a3,a3,a2
    1af8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1afc:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b00:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b04:	14e86d63          	bltu	a6,a4,1c5e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b08:	02e5f6bb          	remuw	a3,a1,a4
    1b0c:	1682                	slli	a3,a3,0x20
    1b0e:	9281                	srli	a3,a3,0x20
    1b10:	96b2                	add	a3,a3,a2
    1b12:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b16:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b1a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b1e:	10e5e563          	bltu	a1,a4,1c28 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b22:	02e876bb          	remuw	a3,a6,a4
    1b26:	1682                	slli	a3,a3,0x20
    1b28:	9281                	srli	a3,a3,0x20
    1b2a:	96b2                	add	a3,a3,a2
    1b2c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b30:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b34:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b38:	14e86263          	bltu	a6,a4,1c7c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b3c:	02e5f6bb          	remuw	a3,a1,a4
    1b40:	1682                	slli	a3,a3,0x20
    1b42:	9281                	srli	a3,a3,0x20
    1b44:	96b2                	add	a3,a3,a2
    1b46:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b4a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b4e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b52:	14e5e463          	bltu	a1,a4,1c9a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b56:	02e876bb          	remuw	a3,a6,a4
    1b5a:	1682                	slli	a3,a3,0x20
    1b5c:	9281                	srli	a3,a3,0x20
    1b5e:	96b2                	add	a3,a3,a2
    1b60:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b64:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b68:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b6c:	14e86063          	bltu	a6,a4,1cac <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b70:	1782                	slli	a5,a5,0x20
    1b72:	9381                	srli	a5,a5,0x20
    1b74:	97b2                	add	a5,a5,a2
    1b76:	0007c703          	lbu	a4,0(a5)
    1b7a:	4799                	li	a5,6
    1b7c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b80:	10054763          	bltz	a0,1c8e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b84:	00001497          	auipc	s1,0x1
    1b88:	d7c48493          	addi	s1,s1,-644 # 2900 <buffer_len>
    1b8c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b90:	0828                	addi	a0,sp,24
    1b92:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b94:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b96:	00f50433          	add	s0,a0,a5
    1b9a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b9c:	06e68463          	beq	a3,a4,1c04 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1ba0:	8522                	mv	a0,s0
    1ba2:	b15ff0ef          	jal	ra,16b6 <out_unlocked>
}
    1ba6:	60a6                	ld	ra,72(sp)
    1ba8:	6406                	ld	s0,64(sp)
    1baa:	74e2                	ld	s1,56(sp)
    1bac:	6161                	addi	sp,sp,80
    1bae:	8082                	ret
		x = -xx;
    1bb0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1bb4:	02b877bb          	remuw	a5,a6,a1
    1bb8:	00001617          	auipc	a2,0x1
    1bbc:	e6060613          	addi	a2,a2,-416 # 2a18 <digits>
	buf[16] = 0;
    1bc0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bc4:	0005871b          	sext.w	a4,a1
    1bc8:	1782                	slli	a5,a5,0x20
    1bca:	9381                	srli	a5,a5,0x20
    1bcc:	97b2                	add	a5,a5,a2
    1bce:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bd2:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1bd6:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1bda:	08b86b63          	bltu	a6,a1,1c70 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1bde:	02e8f7bb          	remuw	a5,a7,a4
    1be2:	1782                	slli	a5,a5,0x20
    1be4:	9381                	srli	a5,a5,0x20
    1be6:	97b2                	add	a5,a5,a2
    1be8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bec:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1bf0:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1bf4:	ece8f1e3          	bgeu	a7,a4,1ab6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bf8:	02d00793          	li	a5,45
    1bfc:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c00:	47b5                	li	a5,13
    1c02:	b749                	j	1b84 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c04:	10c4a503          	lw	a0,268(s1)
    1c08:	e42e                	sd	a1,8(sp)
    1c0a:	2c1000ef          	jal	ra,26ca <mutex_lock>
		len = out_unlocked(s, l);
    1c0e:	65a2                	ld	a1,8(sp)
    1c10:	8522                	mv	a0,s0
    1c12:	aa5ff0ef          	jal	ra,16b6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c16:	10c4a503          	lw	a0,268(s1)
    1c1a:	2bd000ef          	jal	ra,26d6 <mutex_unlock>
}
    1c1e:	60a6                	ld	ra,72(sp)
    1c20:	6406                	ld	s0,64(sp)
    1c22:	74e2                	ld	s1,56(sp)
    1c24:	6161                	addi	sp,sp,80
    1c26:	8082                	ret
		buf[i--] = digits[x % base];
    1c28:	47a9                	li	a5,10
	if (sign)
    1c2a:	f4055de3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c2e:	02d00793          	li	a5,45
    1c32:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c36:	47a5                	li	a5,9
    1c38:	b7b1                	j	1b84 <printint.constprop.0+0x122>
    1c3a:	47b5                	li	a5,13
	if (sign)
    1c3c:	f40554e3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c40:	02d00793          	li	a5,45
    1c44:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c48:	47b1                	li	a5,12
    1c4a:	bf2d                	j	1b84 <printint.constprop.0+0x122>
    1c4c:	47b1                	li	a5,12
	if (sign)
    1c4e:	f2055be3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c52:	02d00793          	li	a5,45
    1c56:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c5a:	47ad                	li	a5,11
    1c5c:	b725                	j	1b84 <printint.constprop.0+0x122>
    1c5e:	47ad                	li	a5,11
	if (sign)
    1c60:	f20552e3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c64:	02d00793          	li	a5,45
    1c68:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c6c:	47a9                	li	a5,10
    1c6e:	bf19                	j	1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c70:	02d00793          	li	a5,45
    1c74:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c78:	47b9                	li	a5,14
    1c7a:	b729                	j	1b84 <printint.constprop.0+0x122>
    1c7c:	47a5                	li	a5,9
	if (sign)
    1c7e:	f00553e3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c82:	02d00793          	li	a5,45
    1c86:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c8a:	47a1                	li	a5,8
    1c8c:	bde5                	j	1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c8e:	02d00793          	li	a5,45
    1c92:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c96:	4795                	li	a5,5
    1c98:	b5f5                	j	1b84 <printint.constprop.0+0x122>
    1c9a:	47a1                	li	a5,8
	if (sign)
    1c9c:	ee0554e3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca0:	02d00793          	li	a5,45
    1ca4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1ca8:	479d                	li	a5,7
    1caa:	bde9                	j	1b84 <printint.constprop.0+0x122>
    1cac:	479d                	li	a5,7
	if (sign)
    1cae:	ec055be3          	bgez	a0,1b84 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb2:	02d00793          	li	a5,45
    1cb6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cba:	4799                	li	a5,6
    1cbc:	b5e1                	j	1b84 <printint.constprop.0+0x122>

0000000000001cbe <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cbe:	02000793          	li	a5,32
    1cc2:	00f50663          	beq	a0,a5,1cce <isspace+0x10>
    1cc6:	355d                	addiw	a0,a0,-9
    1cc8:	00553513          	sltiu	a0,a0,5
    1ccc:	8082                	ret
    1cce:	4505                	li	a0,1
}
    1cd0:	8082                	ret

0000000000001cd2 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1cd2:	fd05051b          	addiw	a0,a0,-48
}
    1cd6:	00a53513          	sltiu	a0,a0,10
    1cda:	8082                	ret

0000000000001cdc <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cdc:	02000613          	li	a2,32
    1ce0:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1ce2:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1ce6:	ff77869b          	addiw	a3,a5,-9
    1cea:	04c78c63          	beq	a5,a2,1d42 <atoi+0x66>
    1cee:	0007871b          	sext.w	a4,a5
    1cf2:	04d5f863          	bgeu	a1,a3,1d42 <atoi+0x66>
		s++;
	switch (*s) {
    1cf6:	02b00693          	li	a3,43
    1cfa:	04d78963          	beq	a5,a3,1d4c <atoi+0x70>
    1cfe:	02d00693          	li	a3,45
    1d02:	06d78263          	beq	a5,a3,1d66 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d06:	fd07061b          	addiw	a2,a4,-48
    1d0a:	47a5                	li	a5,9
    1d0c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d0e:	4e01                	li	t3,0
	while (isdigit(*s))
    1d10:	04c7e963          	bltu	a5,a2,1d62 <atoi+0x86>
	int n = 0, neg = 0;
    1d14:	4501                	li	a0,0
	while (isdigit(*s))
    1d16:	4825                	li	a6,9
    1d18:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d1c:	0025179b          	slliw	a5,a0,0x2
    1d20:	9fa9                	addw	a5,a5,a0
    1d22:	fd07031b          	addiw	t1,a4,-48
    1d26:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d2a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d2e:	0685                	addi	a3,a3,1
    1d30:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d34:	0006071b          	sext.w	a4,a2
    1d38:	feb870e3          	bgeu	a6,a1,1d18 <atoi+0x3c>
	return neg ? n : -n;
    1d3c:	000e0563          	beqz	t3,1d46 <atoi+0x6a>
}
    1d40:	8082                	ret
		s++;
    1d42:	0505                	addi	a0,a0,1
    1d44:	bf79                	j	1ce2 <atoi+0x6>
	return neg ? n : -n;
    1d46:	4113053b          	subw	a0,t1,a7
    1d4a:	8082                	ret
	while (isdigit(*s))
    1d4c:	00154703          	lbu	a4,1(a0)
    1d50:	47a5                	li	a5,9
		s++;
    1d52:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d56:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d5a:	4e01                	li	t3,0
	while (isdigit(*s))
    1d5c:	2701                	sext.w	a4,a4
    1d5e:	fac7fbe3          	bgeu	a5,a2,1d14 <atoi+0x38>
    1d62:	4501                	li	a0,0
}
    1d64:	8082                	ret
	while (isdigit(*s))
    1d66:	00154703          	lbu	a4,1(a0)
    1d6a:	47a5                	li	a5,9
		s++;
    1d6c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d70:	fd07061b          	addiw	a2,a4,-48
    1d74:	2701                	sext.w	a4,a4
    1d76:	fec7e6e3          	bltu	a5,a2,1d62 <atoi+0x86>
		neg = 1;
    1d7a:	4e05                	li	t3,1
    1d7c:	bf61                	j	1d14 <atoi+0x38>

0000000000001d7e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d7e:	16060d63          	beqz	a2,1ef8 <memset+0x17a>
    1d82:	40a007b3          	neg	a5,a0
    1d86:	8b9d                	andi	a5,a5,7
    1d88:	00778693          	addi	a3,a5,7
    1d8c:	482d                	li	a6,11
    1d8e:	0ff5f713          	zext.b	a4,a1
    1d92:	fff60593          	addi	a1,a2,-1
    1d96:	1706e263          	bltu	a3,a6,1efa <memset+0x17c>
    1d9a:	16d5ea63          	bltu	a1,a3,1f0e <memset+0x190>
    1d9e:	16078563          	beqz	a5,1f08 <memset+0x18a>
    1da2:	00e50023          	sb	a4,0(a0)
    1da6:	4685                	li	a3,1
    1da8:	00150593          	addi	a1,a0,1
    1dac:	14d78c63          	beq	a5,a3,1f04 <memset+0x186>
    1db0:	00e500a3          	sb	a4,1(a0)
    1db4:	4689                	li	a3,2
    1db6:	00250593          	addi	a1,a0,2
    1dba:	14d78d63          	beq	a5,a3,1f14 <memset+0x196>
    1dbe:	00e50123          	sb	a4,2(a0)
    1dc2:	468d                	li	a3,3
    1dc4:	00350593          	addi	a1,a0,3
    1dc8:	12d78b63          	beq	a5,a3,1efe <memset+0x180>
    1dcc:	00e501a3          	sb	a4,3(a0)
    1dd0:	4691                	li	a3,4
    1dd2:	00450593          	addi	a1,a0,4
    1dd6:	14d78163          	beq	a5,a3,1f18 <memset+0x19a>
    1dda:	00e50223          	sb	a4,4(a0)
    1dde:	4695                	li	a3,5
    1de0:	00550593          	addi	a1,a0,5
    1de4:	12d78c63          	beq	a5,a3,1f1c <memset+0x19e>
    1de8:	00e502a3          	sb	a4,5(a0)
    1dec:	469d                	li	a3,7
    1dee:	00650593          	addi	a1,a0,6
    1df2:	12d79763          	bne	a5,a3,1f20 <memset+0x1a2>
    1df6:	00750593          	addi	a1,a0,7
    1dfa:	00e50323          	sb	a4,6(a0)
    1dfe:	481d                	li	a6,7
    1e00:	00871693          	slli	a3,a4,0x8
    1e04:	01071893          	slli	a7,a4,0x10
    1e08:	8ed9                	or	a3,a3,a4
    1e0a:	01871313          	slli	t1,a4,0x18
    1e0e:	0116e6b3          	or	a3,a3,a7
    1e12:	0066e6b3          	or	a3,a3,t1
    1e16:	02071893          	slli	a7,a4,0x20
    1e1a:	02871e13          	slli	t3,a4,0x28
    1e1e:	0116e6b3          	or	a3,a3,a7
    1e22:	40f60333          	sub	t1,a2,a5
    1e26:	03071893          	slli	a7,a4,0x30
    1e2a:	01c6e6b3          	or	a3,a3,t3
    1e2e:	0116e6b3          	or	a3,a3,a7
    1e32:	03871e13          	slli	t3,a4,0x38
    1e36:	97aa                	add	a5,a5,a0
    1e38:	ff837893          	andi	a7,t1,-8
    1e3c:	01c6e6b3          	or	a3,a3,t3
    1e40:	98be                	add	a7,a7,a5
    1e42:	e394                	sd	a3,0(a5)
    1e44:	07a1                	addi	a5,a5,8
    1e46:	ff179ee3          	bne	a5,a7,1e42 <memset+0xc4>
    1e4a:	ff837893          	andi	a7,t1,-8
    1e4e:	011587b3          	add	a5,a1,a7
    1e52:	010886bb          	addw	a3,a7,a6
    1e56:	0b130663          	beq	t1,a7,1f02 <memset+0x184>
    1e5a:	00e78023          	sb	a4,0(a5)
    1e5e:	0016859b          	addiw	a1,a3,1
    1e62:	08c5fb63          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1e66:	00e780a3          	sb	a4,1(a5)
    1e6a:	0026859b          	addiw	a1,a3,2
    1e6e:	08c5f563          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1e72:	00e78123          	sb	a4,2(a5)
    1e76:	0036859b          	addiw	a1,a3,3
    1e7a:	06c5ff63          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1e7e:	00e781a3          	sb	a4,3(a5)
    1e82:	0046859b          	addiw	a1,a3,4
    1e86:	06c5f963          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1e8a:	00e78223          	sb	a4,4(a5)
    1e8e:	0056859b          	addiw	a1,a3,5
    1e92:	06c5f363          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1e96:	00e782a3          	sb	a4,5(a5)
    1e9a:	0066859b          	addiw	a1,a3,6
    1e9e:	04c5fd63          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1ea2:	00e78323          	sb	a4,6(a5)
    1ea6:	0076859b          	addiw	a1,a3,7
    1eaa:	04c5f763          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1eae:	00e783a3          	sb	a4,7(a5)
    1eb2:	0086859b          	addiw	a1,a3,8
    1eb6:	04c5f163          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1eba:	00e78423          	sb	a4,8(a5)
    1ebe:	0096859b          	addiw	a1,a3,9
    1ec2:	02c5fb63          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1ec6:	00e784a3          	sb	a4,9(a5)
    1eca:	00a6859b          	addiw	a1,a3,10
    1ece:	02c5f563          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1ed2:	00e78523          	sb	a4,10(a5)
    1ed6:	00b6859b          	addiw	a1,a3,11
    1eda:	00c5ff63          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1ede:	00e785a3          	sb	a4,11(a5)
    1ee2:	00c6859b          	addiw	a1,a3,12
    1ee6:	00c5f963          	bgeu	a1,a2,1ef8 <memset+0x17a>
    1eea:	00e78623          	sb	a4,12(a5)
    1eee:	26b5                	addiw	a3,a3,13
    1ef0:	00c6f463          	bgeu	a3,a2,1ef8 <memset+0x17a>
    1ef4:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1ef8:	8082                	ret
    1efa:	46ad                	li	a3,11
    1efc:	bd79                	j	1d9a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1efe:	480d                	li	a6,3
    1f00:	b701                	j	1e00 <memset+0x82>
    1f02:	8082                	ret
    1f04:	4805                	li	a6,1
    1f06:	bded                	j	1e00 <memset+0x82>
    1f08:	85aa                	mv	a1,a0
    1f0a:	4801                	li	a6,0
    1f0c:	bdd5                	j	1e00 <memset+0x82>
    1f0e:	87aa                	mv	a5,a0
    1f10:	4681                	li	a3,0
    1f12:	b7a1                	j	1e5a <memset+0xdc>
    1f14:	4809                	li	a6,2
    1f16:	b5ed                	j	1e00 <memset+0x82>
    1f18:	4811                	li	a6,4
    1f1a:	b5dd                	j	1e00 <memset+0x82>
    1f1c:	4815                	li	a6,5
    1f1e:	b5cd                	j	1e00 <memset+0x82>
    1f20:	4819                	li	a6,6
    1f22:	bdf9                	j	1e00 <memset+0x82>

0000000000001f24 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f24:	00054783          	lbu	a5,0(a0)
    1f28:	0005c703          	lbu	a4,0(a1)
    1f2c:	00e79863          	bne	a5,a4,1f3c <strcmp+0x18>
    1f30:	0505                	addi	a0,a0,1
    1f32:	0585                	addi	a1,a1,1
    1f34:	fbe5                	bnez	a5,1f24 <strcmp>
    1f36:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f38:	9d19                	subw	a0,a0,a4
    1f3a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f3c:	0007851b          	sext.w	a0,a5
    1f40:	bfe5                	j	1f38 <strcmp+0x14>

0000000000001f42 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f42:	ca15                	beqz	a2,1f76 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f44:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f48:	167d                	addi	a2,a2,-1
    1f4a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f4e:	eb99                	bnez	a5,1f64 <strncmp+0x22>
    1f50:	a815                	j	1f84 <strncmp+0x42>
    1f52:	00a68e63          	beq	a3,a0,1f6e <strncmp+0x2c>
    1f56:	0505                	addi	a0,a0,1
    1f58:	00f71b63          	bne	a4,a5,1f6e <strncmp+0x2c>
    1f5c:	00054783          	lbu	a5,0(a0)
    1f60:	cf89                	beqz	a5,1f7a <strncmp+0x38>
    1f62:	85b2                	mv	a1,a2
    1f64:	0005c703          	lbu	a4,0(a1)
    1f68:	00158613          	addi	a2,a1,1
    1f6c:	f37d                	bnez	a4,1f52 <strncmp+0x10>
		;
	return *l - *r;
    1f6e:	0007851b          	sext.w	a0,a5
    1f72:	9d19                	subw	a0,a0,a4
    1f74:	8082                	ret
		return 0;
    1f76:	4501                	li	a0,0
}
    1f78:	8082                	ret
	return *l - *r;
    1f7a:	0015c703          	lbu	a4,1(a1)
    1f7e:	4501                	li	a0,0
    1f80:	9d19                	subw	a0,a0,a4
    1f82:	8082                	ret
    1f84:	0005c703          	lbu	a4,0(a1)
    1f88:	4501                	li	a0,0
    1f8a:	b7e5                	j	1f72 <strncmp+0x30>

0000000000001f8c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f8c:	00757793          	andi	a5,a0,7
    1f90:	cf89                	beqz	a5,1faa <strlen+0x1e>
    1f92:	87aa                	mv	a5,a0
    1f94:	a029                	j	1f9e <strlen+0x12>
    1f96:	0785                	addi	a5,a5,1
    1f98:	0077f713          	andi	a4,a5,7
    1f9c:	cb01                	beqz	a4,1fac <strlen+0x20>
		if (!*s)
    1f9e:	0007c703          	lbu	a4,0(a5)
    1fa2:	fb75                	bnez	a4,1f96 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1fa4:	40a78533          	sub	a0,a5,a0
}
    1fa8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1faa:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fac:	6394                	ld	a3,0(a5)
    1fae:	00001597          	auipc	a1,0x1
    1fb2:	93a5b583          	ld	a1,-1734(a1) # 28e8 <enable_deadlock_detect+0x1be>
    1fb6:	00001617          	auipc	a2,0x1
    1fba:	93a63603          	ld	a2,-1734(a2) # 28f0 <enable_deadlock_detect+0x1c6>
    1fbe:	a019                	j	1fc4 <strlen+0x38>
    1fc0:	6794                	ld	a3,8(a5)
    1fc2:	07a1                	addi	a5,a5,8
    1fc4:	00b68733          	add	a4,a3,a1
    1fc8:	fff6c693          	not	a3,a3
    1fcc:	8f75                	and	a4,a4,a3
    1fce:	8f71                	and	a4,a4,a2
    1fd0:	db65                	beqz	a4,1fc0 <strlen+0x34>
	for (; *s; s++)
    1fd2:	0007c703          	lbu	a4,0(a5)
    1fd6:	d779                	beqz	a4,1fa4 <strlen+0x18>
    1fd8:	0017c703          	lbu	a4,1(a5)
    1fdc:	0785                	addi	a5,a5,1
    1fde:	d379                	beqz	a4,1fa4 <strlen+0x18>
    1fe0:	0017c703          	lbu	a4,1(a5)
    1fe4:	0785                	addi	a5,a5,1
    1fe6:	fb6d                	bnez	a4,1fd8 <strlen+0x4c>
    1fe8:	bf75                	j	1fa4 <strlen+0x18>

0000000000001fea <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fea:	00757713          	andi	a4,a0,7
{
    1fee:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1ff0:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1ff4:	cb19                	beqz	a4,200a <memchr+0x20>
    1ff6:	ce25                	beqz	a2,206e <memchr+0x84>
    1ff8:	0007c703          	lbu	a4,0(a5)
    1ffc:	04b70e63          	beq	a4,a1,2058 <memchr+0x6e>
    2000:	0785                	addi	a5,a5,1
    2002:	0077f713          	andi	a4,a5,7
    2006:	167d                	addi	a2,a2,-1
    2008:	f77d                	bnez	a4,1ff6 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    200a:	4501                	li	a0,0
	if (n && *s != c) {
    200c:	c235                	beqz	a2,2070 <memchr+0x86>
    200e:	0007c703          	lbu	a4,0(a5)
    2012:	04b70363          	beq	a4,a1,2058 <memchr+0x6e>
		size_t k = ONES * c;
    2016:	00001517          	auipc	a0,0x1
    201a:	8e253503          	ld	a0,-1822(a0) # 28f8 <enable_deadlock_detect+0x1ce>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    201e:	471d                	li	a4,7
		size_t k = ONES * c;
    2020:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2024:	02c77a63          	bgeu	a4,a2,2058 <memchr+0x6e>
    2028:	00001897          	auipc	a7,0x1
    202c:	8c08b883          	ld	a7,-1856(a7) # 28e8 <enable_deadlock_detect+0x1be>
    2030:	00001817          	auipc	a6,0x1
    2034:	8c083803          	ld	a6,-1856(a6) # 28f0 <enable_deadlock_detect+0x1c6>
    2038:	431d                	li	t1,7
    203a:	a029                	j	2044 <memchr+0x5a>
		     w++, n -= SS)
    203c:	1661                	addi	a2,a2,-8
    203e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2040:	02c37963          	bgeu	t1,a2,2072 <memchr+0x88>
    2044:	6398                	ld	a4,0(a5)
    2046:	8f29                	xor	a4,a4,a0
    2048:	011706b3          	add	a3,a4,a7
    204c:	fff74713          	not	a4,a4
    2050:	8f75                	and	a4,a4,a3
    2052:	01077733          	and	a4,a4,a6
    2056:	d37d                	beqz	a4,203c <memchr+0x52>
{
    2058:	853e                	mv	a0,a5
    205a:	97b2                	add	a5,a5,a2
    205c:	a021                	j	2064 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    205e:	0505                	addi	a0,a0,1
    2060:	00f50763          	beq	a0,a5,206e <memchr+0x84>
    2064:	00054703          	lbu	a4,0(a0)
    2068:	feb71be3          	bne	a4,a1,205e <memchr+0x74>
    206c:	8082                	ret
	return n ? (void *)s : 0;
    206e:	4501                	li	a0,0
}
    2070:	8082                	ret
	return n ? (void *)s : 0;
    2072:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2074:	f275                	bnez	a2,2058 <memchr+0x6e>
}
    2076:	8082                	ret

0000000000002078 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2078:	1101                	addi	sp,sp,-32
    207a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    207c:	862e                	mv	a2,a1
{
    207e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2080:	4581                	li	a1,0
{
    2082:	e426                	sd	s1,8(sp)
    2084:	ec06                	sd	ra,24(sp)
    2086:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2088:	f63ff0ef          	jal	ra,1fea <memchr>
	return p ? p - s : n;
    208c:	c519                	beqz	a0,209a <strnlen+0x22>
}
    208e:	60e2                	ld	ra,24(sp)
    2090:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2092:	8d05                	sub	a0,a0,s1
}
    2094:	64a2                	ld	s1,8(sp)
    2096:	6105                	addi	sp,sp,32
    2098:	8082                	ret
    209a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    209c:	8522                	mv	a0,s0
}
    209e:	6442                	ld	s0,16(sp)
    20a0:	64a2                	ld	s1,8(sp)
    20a2:	6105                	addi	sp,sp,32
    20a4:	8082                	ret

00000000000020a6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20a6:	00a5c7b3          	xor	a5,a1,a0
    20aa:	8b9d                	andi	a5,a5,7
    20ac:	eb95                	bnez	a5,20e0 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20ae:	0075f793          	andi	a5,a1,7
    20b2:	e7b1                	bnez	a5,20fe <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20b4:	6198                	ld	a4,0(a1)
    20b6:	00001617          	auipc	a2,0x1
    20ba:	83263603          	ld	a2,-1998(a2) # 28e8 <enable_deadlock_detect+0x1be>
    20be:	00001817          	auipc	a6,0x1
    20c2:	83283803          	ld	a6,-1998(a6) # 28f0 <enable_deadlock_detect+0x1c6>
    20c6:	a029                	j	20d0 <stpcpy+0x2a>
    20c8:	05a1                	addi	a1,a1,8
    20ca:	e118                	sd	a4,0(a0)
    20cc:	6198                	ld	a4,0(a1)
    20ce:	0521                	addi	a0,a0,8
    20d0:	00c707b3          	add	a5,a4,a2
    20d4:	fff74693          	not	a3,a4
    20d8:	8ff5                	and	a5,a5,a3
    20da:	0107f7b3          	and	a5,a5,a6
    20de:	d7ed                	beqz	a5,20c8 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    20e0:	0005c783          	lbu	a5,0(a1)
    20e4:	00f50023          	sb	a5,0(a0)
    20e8:	c785                	beqz	a5,2110 <stpcpy+0x6a>
    20ea:	0015c783          	lbu	a5,1(a1)
    20ee:	0505                	addi	a0,a0,1
    20f0:	0585                	addi	a1,a1,1
    20f2:	00f50023          	sb	a5,0(a0)
    20f6:	fbf5                	bnez	a5,20ea <stpcpy+0x44>
		;
	return d;
}
    20f8:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20fa:	0505                	addi	a0,a0,1
    20fc:	df45                	beqz	a4,20b4 <stpcpy+0xe>
			if (!(*d = *s))
    20fe:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2102:	0585                	addi	a1,a1,1
    2104:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2108:	00f50023          	sb	a5,0(a0)
    210c:	f7fd                	bnez	a5,20fa <stpcpy+0x54>
}
    210e:	8082                	ret
    2110:	8082                	ret

0000000000002112 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2112:	00a5c7b3          	xor	a5,a1,a0
    2116:	8b9d                	andi	a5,a5,7
    2118:	1a079863          	bnez	a5,22c8 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    211c:	0075f793          	andi	a5,a1,7
    2120:	16078463          	beqz	a5,2288 <stpncpy+0x176>
    2124:	ea01                	bnez	a2,2134 <stpncpy+0x22>
    2126:	a421                	j	232e <stpncpy+0x21c>
    2128:	167d                	addi	a2,a2,-1
    212a:	0505                	addi	a0,a0,1
    212c:	14070e63          	beqz	a4,2288 <stpncpy+0x176>
    2130:	1a060863          	beqz	a2,22e0 <stpncpy+0x1ce>
    2134:	0005c783          	lbu	a5,0(a1)
    2138:	0585                	addi	a1,a1,1
    213a:	0075f713          	andi	a4,a1,7
    213e:	00f50023          	sb	a5,0(a0)
    2142:	f3fd                	bnez	a5,2128 <stpncpy+0x16>
    2144:	4805                	li	a6,1
    2146:	1a061863          	bnez	a2,22f6 <stpncpy+0x1e4>
    214a:	40a007b3          	neg	a5,a0
    214e:	8b9d                	andi	a5,a5,7
    2150:	4681                	li	a3,0
    2152:	18061a63          	bnez	a2,22e6 <stpncpy+0x1d4>
    2156:	00778713          	addi	a4,a5,7
    215a:	45ad                	li	a1,11
    215c:	18b76363          	bltu	a4,a1,22e2 <stpncpy+0x1d0>
    2160:	1ae6eb63          	bltu	a3,a4,2316 <stpncpy+0x204>
    2164:	1a078363          	beqz	a5,230a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2168:	00050023          	sb	zero,0(a0)
    216c:	4685                	li	a3,1
    216e:	00150713          	addi	a4,a0,1
    2172:	18d78f63          	beq	a5,a3,2310 <stpncpy+0x1fe>
    2176:	000500a3          	sb	zero,1(a0)
    217a:	4689                	li	a3,2
    217c:	00250713          	addi	a4,a0,2
    2180:	18d78e63          	beq	a5,a3,231c <stpncpy+0x20a>
    2184:	00050123          	sb	zero,2(a0)
    2188:	468d                	li	a3,3
    218a:	00350713          	addi	a4,a0,3
    218e:	16d78c63          	beq	a5,a3,2306 <stpncpy+0x1f4>
    2192:	000501a3          	sb	zero,3(a0)
    2196:	4691                	li	a3,4
    2198:	00450713          	addi	a4,a0,4
    219c:	18d78263          	beq	a5,a3,2320 <stpncpy+0x20e>
    21a0:	00050223          	sb	zero,4(a0)
    21a4:	4695                	li	a3,5
    21a6:	00550713          	addi	a4,a0,5
    21aa:	16d78d63          	beq	a5,a3,2324 <stpncpy+0x212>
    21ae:	000502a3          	sb	zero,5(a0)
    21b2:	469d                	li	a3,7
    21b4:	00650713          	addi	a4,a0,6
    21b8:	16d79863          	bne	a5,a3,2328 <stpncpy+0x216>
    21bc:	00750713          	addi	a4,a0,7
    21c0:	00050323          	sb	zero,6(a0)
    21c4:	40f80833          	sub	a6,a6,a5
    21c8:	ff887593          	andi	a1,a6,-8
    21cc:	97aa                	add	a5,a5,a0
    21ce:	95be                	add	a1,a1,a5
    21d0:	0007b023          	sd	zero,0(a5)
    21d4:	07a1                	addi	a5,a5,8
    21d6:	feb79de3          	bne	a5,a1,21d0 <stpncpy+0xbe>
    21da:	ff887593          	andi	a1,a6,-8
    21de:	9ead                	addw	a3,a3,a1
    21e0:	00b707b3          	add	a5,a4,a1
    21e4:	12b80863          	beq	a6,a1,2314 <stpncpy+0x202>
    21e8:	00078023          	sb	zero,0(a5)
    21ec:	0016871b          	addiw	a4,a3,1
    21f0:	0ec77863          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    21f4:	000780a3          	sb	zero,1(a5)
    21f8:	0026871b          	addiw	a4,a3,2
    21fc:	0ec77263          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2200:	00078123          	sb	zero,2(a5)
    2204:	0036871b          	addiw	a4,a3,3
    2208:	0cc77c63          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    220c:	000781a3          	sb	zero,3(a5)
    2210:	0046871b          	addiw	a4,a3,4
    2214:	0cc77663          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2218:	00078223          	sb	zero,4(a5)
    221c:	0056871b          	addiw	a4,a3,5
    2220:	0cc77063          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2224:	000782a3          	sb	zero,5(a5)
    2228:	0066871b          	addiw	a4,a3,6
    222c:	0ac77a63          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2230:	00078323          	sb	zero,6(a5)
    2234:	0076871b          	addiw	a4,a3,7
    2238:	0ac77463          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    223c:	000783a3          	sb	zero,7(a5)
    2240:	0086871b          	addiw	a4,a3,8
    2244:	08c77e63          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2248:	00078423          	sb	zero,8(a5)
    224c:	0096871b          	addiw	a4,a3,9
    2250:	08c77863          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2254:	000784a3          	sb	zero,9(a5)
    2258:	00a6871b          	addiw	a4,a3,10
    225c:	08c77263          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2260:	00078523          	sb	zero,10(a5)
    2264:	00b6871b          	addiw	a4,a3,11
    2268:	06c77c63          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    226c:	000785a3          	sb	zero,11(a5)
    2270:	00c6871b          	addiw	a4,a3,12
    2274:	06c77663          	bgeu	a4,a2,22e0 <stpncpy+0x1ce>
    2278:	00078623          	sb	zero,12(a5)
    227c:	26b5                	addiw	a3,a3,13
    227e:	06c6f163          	bgeu	a3,a2,22e0 <stpncpy+0x1ce>
    2282:	000786a3          	sb	zero,13(a5)
    2286:	8082                	ret
			;
		if (!n || !*s)
    2288:	c645                	beqz	a2,2330 <stpncpy+0x21e>
    228a:	0005c783          	lbu	a5,0(a1)
    228e:	ea078be3          	beqz	a5,2144 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2292:	479d                	li	a5,7
    2294:	02c7ff63          	bgeu	a5,a2,22d2 <stpncpy+0x1c0>
    2298:	00000897          	auipc	a7,0x0
    229c:	6508b883          	ld	a7,1616(a7) # 28e8 <enable_deadlock_detect+0x1be>
    22a0:	00000817          	auipc	a6,0x0
    22a4:	65083803          	ld	a6,1616(a6) # 28f0 <enable_deadlock_detect+0x1c6>
    22a8:	431d                	li	t1,7
    22aa:	6198                	ld	a4,0(a1)
    22ac:	011707b3          	add	a5,a4,a7
    22b0:	fff74693          	not	a3,a4
    22b4:	8ff5                	and	a5,a5,a3
    22b6:	0107f7b3          	and	a5,a5,a6
    22ba:	ef81                	bnez	a5,22d2 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22bc:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22be:	1661                	addi	a2,a2,-8
    22c0:	05a1                	addi	a1,a1,8
    22c2:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22c4:	fec363e3          	bltu	t1,a2,22aa <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22c8:	e609                	bnez	a2,22d2 <stpncpy+0x1c0>
    22ca:	a08d                	j	232c <stpncpy+0x21a>
    22cc:	167d                	addi	a2,a2,-1
    22ce:	0505                	addi	a0,a0,1
    22d0:	ca01                	beqz	a2,22e0 <stpncpy+0x1ce>
    22d2:	0005c783          	lbu	a5,0(a1)
    22d6:	0585                	addi	a1,a1,1
    22d8:	00f50023          	sb	a5,0(a0)
    22dc:	fbe5                	bnez	a5,22cc <stpncpy+0x1ba>
		;
tail:
    22de:	b59d                	j	2144 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    22e0:	8082                	ret
    22e2:	472d                	li	a4,11
    22e4:	bdb5                	j	2160 <stpncpy+0x4e>
    22e6:	00778713          	addi	a4,a5,7
    22ea:	45ad                	li	a1,11
    22ec:	fff60693          	addi	a3,a2,-1
    22f0:	e6b778e3          	bgeu	a4,a1,2160 <stpncpy+0x4e>
    22f4:	b7fd                	j	22e2 <stpncpy+0x1d0>
    22f6:	40a007b3          	neg	a5,a0
    22fa:	8832                	mv	a6,a2
    22fc:	8b9d                	andi	a5,a5,7
    22fe:	4681                	li	a3,0
    2300:	e4060be3          	beqz	a2,2156 <stpncpy+0x44>
    2304:	b7cd                	j	22e6 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2306:	468d                	li	a3,3
    2308:	bd75                	j	21c4 <stpncpy+0xb2>
    230a:	872a                	mv	a4,a0
    230c:	4681                	li	a3,0
    230e:	bd5d                	j	21c4 <stpncpy+0xb2>
    2310:	4685                	li	a3,1
    2312:	bd4d                	j	21c4 <stpncpy+0xb2>
    2314:	8082                	ret
    2316:	87aa                	mv	a5,a0
    2318:	4681                	li	a3,0
    231a:	b5f9                	j	21e8 <stpncpy+0xd6>
    231c:	4689                	li	a3,2
    231e:	b55d                	j	21c4 <stpncpy+0xb2>
    2320:	4691                	li	a3,4
    2322:	b54d                	j	21c4 <stpncpy+0xb2>
    2324:	4695                	li	a3,5
    2326:	bd79                	j	21c4 <stpncpy+0xb2>
    2328:	4699                	li	a3,6
    232a:	bd69                	j	21c4 <stpncpy+0xb2>
    232c:	8082                	ret
    232e:	8082                	ret
    2330:	8082                	ret

0000000000002332 <basename>:

char *basename(char *s)
{
    2332:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2334:	c54d                	beqz	a0,23de <basename+0xac>
    2336:	00054783          	lbu	a5,0(a0)
		return ".";
    233a:	00000517          	auipc	a0,0x0
    233e:	5a650513          	addi	a0,a0,1446 # 28e0 <enable_deadlock_detect+0x1b6>
	if (!s || !*s)
    2342:	e391                	bnez	a5,2346 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2344:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2346:	0076f713          	andi	a4,a3,7
    234a:	87b6                	mv	a5,a3
    234c:	cf51                	beqz	a4,23e8 <basename+0xb6>
    234e:	0785                	addi	a5,a5,1
    2350:	0077f713          	andi	a4,a5,7
    2354:	c729                	beqz	a4,239e <basename+0x6c>
		if (!*s)
    2356:	0007c703          	lbu	a4,0(a5)
    235a:	fb75                	bnez	a4,234e <basename+0x1c>
	return s - a;
    235c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    235e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2360:	cf8d                	beqz	a5,239a <basename+0x68>
    2362:	00f68733          	add	a4,a3,a5
    2366:	02f00593          	li	a1,47
    236a:	a031                	j	2376 <basename+0x44>
		s[i] = 0;
    236c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2370:	17fd                	addi	a5,a5,-1
    2372:	177d                	addi	a4,a4,-1
    2374:	c39d                	beqz	a5,239a <basename+0x68>
    2376:	00074603          	lbu	a2,0(a4)
    237a:	feb609e3          	beq	a2,a1,236c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    237e:	02f00613          	li	a2,47
    2382:	a011                	j	2386 <basename+0x54>
    2384:	cb99                	beqz	a5,239a <basename+0x68>
    2386:	853e                	mv	a0,a5
    2388:	17fd                	addi	a5,a5,-1
    238a:	00f68733          	add	a4,a3,a5
    238e:	00074703          	lbu	a4,0(a4)
    2392:	fec719e3          	bne	a4,a2,2384 <basename+0x52>
	return s + i;
    2396:	9536                	add	a0,a0,a3
    2398:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    239a:	8536                	mv	a0,a3
    239c:	8082                	ret
    239e:	6390                	ld	a2,0(a5)
    23a0:	00000517          	auipc	a0,0x0
    23a4:	54853503          	ld	a0,1352(a0) # 28e8 <enable_deadlock_detect+0x1be>
    23a8:	00000597          	auipc	a1,0x0
    23ac:	5485b583          	ld	a1,1352(a1) # 28f0 <enable_deadlock_detect+0x1c6>
    23b0:	fff64713          	not	a4,a2
    23b4:	962a                	add	a2,a2,a0
    23b6:	8f71                	and	a4,a4,a2
    23b8:	8f6d                	and	a4,a4,a1
    23ba:	eb11                	bnez	a4,23ce <basename+0x9c>
    23bc:	6790                	ld	a2,8(a5)
    23be:	07a1                	addi	a5,a5,8
    23c0:	00a60733          	add	a4,a2,a0
    23c4:	fff64613          	not	a2,a2
    23c8:	8f71                	and	a4,a4,a2
    23ca:	8f6d                	and	a4,a4,a1
    23cc:	db65                	beqz	a4,23bc <basename+0x8a>
	for (; *s; s++)
    23ce:	0007c703          	lbu	a4,0(a5)
    23d2:	d749                	beqz	a4,235c <basename+0x2a>
    23d4:	0017c703          	lbu	a4,1(a5)
    23d8:	0785                	addi	a5,a5,1
    23da:	ff6d                	bnez	a4,23d4 <basename+0xa2>
    23dc:	b741                	j	235c <basename+0x2a>
		return ".";
    23de:	00000517          	auipc	a0,0x0
    23e2:	50250513          	addi	a0,a0,1282 # 28e0 <enable_deadlock_detect+0x1b6>
    23e6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23e8:	6290                	ld	a2,0(a3)
    23ea:	00000517          	auipc	a0,0x0
    23ee:	4fe53503          	ld	a0,1278(a0) # 28e8 <enable_deadlock_detect+0x1be>
    23f2:	00000597          	auipc	a1,0x0
    23f6:	4fe5b583          	ld	a1,1278(a1) # 28f0 <enable_deadlock_detect+0x1c6>
    23fa:	fff64713          	not	a4,a2
    23fe:	962a                	add	a2,a2,a0
    2400:	8f71                	and	a4,a4,a2
    2402:	8f6d                	and	a4,a4,a1
    2404:	df45                	beqz	a4,23bc <basename+0x8a>
    2406:	b7f9                	j	23d4 <basename+0xa2>

0000000000002408 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2408:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    240c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    240e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2412:	2501                	sext.w	a0,a0
    2414:	8082                	ret

0000000000002416 <close>:

int close(int fd)
{
	if (fd == 1) {
    2416:	4785                	li	a5,1
    2418:	00f50863          	beq	a0,a5,2428 <close+0x12>
	register long a7 __asm__("a7") = n;
    241c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2420:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2424:	2501                	sext.w	a0,a0
    2426:	8082                	ret
{
    2428:	1101                	addi	sp,sp,-32
    242a:	ec06                	sd	ra,24(sp)
    242c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    242e:	cdffe0ef          	jal	ra,110c <__write_buffer>
		__clear_buffer();
    2432:	d03fe0ef          	jal	ra,1134 <__clear_buffer>
    2436:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2438:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    243c:	00000073          	ecall
}
    2440:	60e2                	ld	ra,24(sp)
    2442:	2501                	sext.w	a0,a0
    2444:	6105                	addi	sp,sp,32
    2446:	8082                	ret

0000000000002448 <read>:
	register long a7 __asm__("a7") = n;
    2448:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    244c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2450:	8082                	ret

0000000000002452 <write>:
	register long a7 __asm__("a7") = n;
    2452:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2456:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    245a:	8082                	ret

000000000000245c <getpid>:
	register long a7 __asm__("a7") = n;
    245c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2460:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2464:	2501                	sext.w	a0,a0
    2466:	8082                	ret

0000000000002468 <getppid>:
	register long a7 __asm__("a7") = n;
    2468:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    246c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2470:	2501                	sext.w	a0,a0
    2472:	8082                	ret

0000000000002474 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2474:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2478:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    247c:	2501                	sext.w	a0,a0
    247e:	8082                	ret

0000000000002480 <fork>:
	register long a7 __asm__("a7") = n;
    2480:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2484:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2488:	2501                	sext.w	a0,a0
    248a:	8082                	ret

000000000000248c <exit>:

void exit(int code)
{
    248c:	1141                	addi	sp,sp,-16
    248e:	e406                	sd	ra,8(sp)
    2490:	e022                	sd	s0,0(sp)
    2492:	842a                	mv	s0,a0
	__write_buffer();
    2494:	c79fe0ef          	jal	ra,110c <__write_buffer>
	__clear_buffer();
    2498:	c9dfe0ef          	jal	ra,1134 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    249c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24a0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24a2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24a6:	60a2                	ld	ra,8(sp)
    24a8:	6402                	ld	s0,0(sp)
    24aa:	0141                	addi	sp,sp,16
    24ac:	8082                	ret

00000000000024ae <waitpid>:
	register long a7 __asm__("a7") = n;
    24ae:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24b2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24b6:	2501                	sext.w	a0,a0
    24b8:	8082                	ret

00000000000024ba <exec>:
	register long a7 __asm__("a7") = n;
    24ba:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24be:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24c2:	2501                	sext.w	a0,a0
    24c4:	8082                	ret

00000000000024c6 <get_mtime>:

int64 get_mtime()
{
    24c6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24c8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24cc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    24ce:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24d0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    24d4:	2501                	sext.w	a0,a0
    24d6:	ed01                	bnez	a0,24ee <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    24d8:	6722                	ld	a4,8(sp)
    24da:	3e800793          	li	a5,1000
    24de:	6682                	ld	a3,0(sp)
    24e0:	02f75733          	divu	a4,a4,a5
    24e4:	02d78533          	mul	a0,a5,a3
    24e8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24ea:	0141                	addi	sp,sp,16
    24ec:	8082                	ret
	return -1;
    24ee:	557d                	li	a0,-1
    24f0:	bfed                	j	24ea <get_mtime+0x24>

00000000000024f2 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24f2:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24f6:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24fa:	2501                	sext.w	a0,a0
    24fc:	8082                	ret

00000000000024fe <sleep>:

int sleep(unsigned long long time)
{
    24fe:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2500:	880a                	mv	a6,sp
{
    2502:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2504:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2508:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    250a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    250c:	00000073          	ecall
	if (err == 0) {
    2510:	2501                	sext.w	a0,a0
    2512:	ed31                	bnez	a0,256e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2514:	6722                	ld	a4,8(sp)
    2516:	3e800793          	li	a5,1000
    251a:	6682                	ld	a3,0(sp)
    251c:	02f75733          	divu	a4,a4,a5
    2520:	02d787b3          	mul	a5,a5,a3
    2524:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2526:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    252a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    252c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    252e:	00000073          	ecall
	if (err == 0) {
    2532:	2501                	sext.w	a0,a0
    2534:	e915                	bnez	a0,2568 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2536:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2538:	3e800693          	li	a3,1000
    253c:	a819                	j	2552 <sleep+0x54>
	__asm_syscall("r"(a7))
    253e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2542:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2546:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2548:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254a:	00000073          	ecall
	if (err == 0) {
    254e:	2501                	sext.w	a0,a0
    2550:	ed01                	bnez	a0,2568 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2552:	6722                	ld	a4,8(sp)
    2554:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2556:	07c00893          	li	a7,124
    255a:	02d75733          	divu	a4,a4,a3
    255e:	02f687b3          	mul	a5,a3,a5
    2562:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2564:	fcc7ede3          	bltu	a5,a2,253e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2568:	4501                	li	a0,0
    256a:	0141                	addi	sp,sp,16
    256c:	8082                	ret
    256e:	57fd                	li	a5,-1
    2570:	bf5d                	j	2526 <sleep+0x28>

0000000000002572 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2572:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2576:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    257a:	2501                	sext.w	a0,a0
    257c:	8082                	ret

000000000000257e <set_priority>:
	register long a7 __asm__("a7") = n;
    257e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2582:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2586:	2501                	sext.w	a0,a0
    2588:	8082                	ret

000000000000258a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    258a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    258e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2592:	2501                	sext.w	a0,a0
    2594:	8082                	ret

0000000000002596 <munmap>:
	register long a7 __asm__("a7") = n;
    2596:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    259e:	2501                	sext.w	a0,a0
    25a0:	8082                	ret

00000000000025a2 <wait>:

int wait(int *code)
{
    25a2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25a4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25a8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25aa:	00000073          	ecall
	return waitpid(-1, code);
}
    25ae:	2501                	sext.w	a0,a0
    25b0:	8082                	ret

00000000000025b2 <spawn>:
	register long a7 __asm__("a7") = n;
    25b2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25b6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25ba:	2501                	sext.w	a0,a0
    25bc:	8082                	ret

00000000000025be <pipe>:
	register long a7 __asm__("a7") = n;
    25be:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25c2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25c6:	2501                	sext.w	a0,a0
    25c8:	8082                	ret

00000000000025ca <mailread>:
	register long a7 __asm__("a7") = n;
    25ca:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ce:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    25d2:	2501                	sext.w	a0,a0
    25d4:	8082                	ret

00000000000025d6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    25d6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25da:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret

00000000000025e2 <fstat>:
	register long a7 __asm__("a7") = n;
    25e2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25ea:	2501                	sext.w	a0,a0
    25ec:	8082                	ret

00000000000025ee <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25ee:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25f0:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25f4:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25f6:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25fa:	2501                	sext.w	a0,a0
    25fc:	8082                	ret

00000000000025fe <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25fe:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2600:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2604:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2606:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret

000000000000260e <link>:

int link(char *old_path, char *new_path)
{
    260e:	87aa                	mv	a5,a0
    2610:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2612:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2616:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    261a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    261c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2620:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2622:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2626:	2501                	sext.w	a0,a0
    2628:	8082                	ret

000000000000262a <unlink>:

int unlink(char *path)
{
    262a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    262c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2630:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2634:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2636:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    263e:	00000797          	auipc	a5,0x0
    2642:	3fa7b783          	ld	a5,1018(a5) # 2a38 <_GLOBAL_OFFSET_TABLE_+0x8>
    2646:	439c                	lw	a5,0(a5)
    2648:	c799                	beqz	a5,2656 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    264a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    264e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2652:	2501                	sext.w	a0,a0
    2654:	8082                	ret
{
    2656:	1101                	addi	sp,sp,-32
    2658:	ec06                	sd	ra,24(sp)
    265a:	e42e                	sd	a1,8(sp)
    265c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    265e:	fe7fe0ef          	jal	ra,1644 <enable_thread_io_buffer>
    2662:	65a2                	ld	a1,8(sp)
    2664:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2666:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266a:	00000073          	ecall
}
    266e:	60e2                	ld	ra,24(sp)
    2670:	2501                	sext.w	a0,a0
    2672:	6105                	addi	sp,sp,32
    2674:	8082                	ret

0000000000002676 <gettid>:
	register long a7 __asm__("a7") = n;
    2676:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    267a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <waittid>:

int waittid(int tid)
{
    2682:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2684:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2688:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    268c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    268e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2690:	00e51e63          	bne	a0,a4,26ac <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2694:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2698:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    269c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26a0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26a2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26a6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26a8:	fee506e3          	beq	a0,a4,2694 <waittid+0x12>
	}
	return ret;
}
    26ac:	8082                	ret

00000000000026ae <mutex_create>:
	register long a7 __asm__("a7") = n;
    26ae:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26b2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26b4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26b8:	2501                	sext.w	a0,a0
    26ba:	8082                	ret

00000000000026bc <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26bc:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26c0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26c2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <mutex_lock>:
	register long a7 __asm__("a7") = n;
    26ca:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    26d6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    26da:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    26e2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    26e6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26ea:	2501                	sext.w	a0,a0
    26ec:	8082                	ret

00000000000026ee <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26ee:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26f2:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26f6:	2501                	sext.w	a0,a0
    26f8:	8082                	ret

00000000000026fa <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26fa:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26fe:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2702:	2501                	sext.w	a0,a0
    2704:	8082                	ret

0000000000002706 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2706:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    270a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    270e:	2501                	sext.w	a0,a0
    2710:	8082                	ret

0000000000002712 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2712:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2716:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    271a:	2501                	sext.w	a0,a0
    271c:	8082                	ret

000000000000271e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    271e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2722:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2726:	2501                	sext.w	a0,a0
    2728:	8082                	ret

000000000000272a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    272a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    272e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2732:	2501                	sext.w	a0,a0
    2734:	8082                	ret
