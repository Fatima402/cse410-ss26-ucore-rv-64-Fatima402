
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_ppid:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a011                	j	1004 <__start_main>

0000000000001002 <main>:
辅助测例，正常退出，不输出 FAIL 即可。
*/

int main()
{
	return getppid();
    1002:	a89d                	j	1078 <getppid>

0000000000001004 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1004:	1141                	addi	sp,sp,-16
    1006:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1008:	ffbff0ef          	jal	ra,1002 <main>
    100c:	090000ef          	jal	ra,109c <exit>
	return 0;
    1010:	60a2                	ld	ra,8(sp)
    1012:	4501                	li	a0,0
    1014:	0141                	addi	sp,sp,16
    1016:	8082                	ret

0000000000001018 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    1018:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    101c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    101e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    1022:	2501                	sext.w	a0,a0
    1024:	8082                	ret

0000000000001026 <close>:

int close(int fd)
{
	if (fd == 1) {
    1026:	4785                	li	a5,1
    1028:	00f50863          	beq	a0,a5,1038 <close+0x12>
	register long a7 __asm__("a7") = n;
    102c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1030:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    1034:	2501                	sext.w	a0,a0
    1036:	8082                	ret
{
    1038:	1101                	addi	sp,sp,-32
    103a:	ec06                	sd	ra,24(sp)
    103c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    103e:	330000ef          	jal	ra,136e <__write_buffer>
		__clear_buffer();
    1042:	354000ef          	jal	ra,1396 <__clear_buffer>
    1046:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    1048:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    104c:	00000073          	ecall
}
    1050:	60e2                	ld	ra,24(sp)
    1052:	2501                	sext.w	a0,a0
    1054:	6105                	addi	sp,sp,32
    1056:	8082                	ret

0000000000001058 <read>:
	register long a7 __asm__("a7") = n;
    1058:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    105c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    1060:	8082                	ret

0000000000001062 <write>:
	register long a7 __asm__("a7") = n;
    1062:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1066:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    106a:	8082                	ret

000000000000106c <getpid>:
	register long a7 __asm__("a7") = n;
    106c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    1070:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    1074:	2501                	sext.w	a0,a0
    1076:	8082                	ret

0000000000001078 <getppid>:
	register long a7 __asm__("a7") = n;
    1078:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    107c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    1080:	2501                	sext.w	a0,a0
    1082:	8082                	ret

0000000000001084 <sched_yield>:
	register long a7 __asm__("a7") = n;
    1084:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    1088:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    108c:	2501                	sext.w	a0,a0
    108e:	8082                	ret

0000000000001090 <fork>:
	register long a7 __asm__("a7") = n;
    1090:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    1094:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    1098:	2501                	sext.w	a0,a0
    109a:	8082                	ret

000000000000109c <exit>:

void exit(int code)
{
    109c:	1141                	addi	sp,sp,-16
    109e:	e406                	sd	ra,8(sp)
    10a0:	e022                	sd	s0,0(sp)
    10a2:	842a                	mv	s0,a0
	__write_buffer();
    10a4:	2ca000ef          	jal	ra,136e <__write_buffer>
	__clear_buffer();
    10a8:	2ee000ef          	jal	ra,1396 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    10ac:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    10b0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    10b2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    10b6:	60a2                	ld	ra,8(sp)
    10b8:	6402                	ld	s0,0(sp)
    10ba:	0141                	addi	sp,sp,16
    10bc:	8082                	ret

00000000000010be <waitpid>:
	register long a7 __asm__("a7") = n;
    10be:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10c2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    10c6:	2501                	sext.w	a0,a0
    10c8:	8082                	ret

00000000000010ca <exec>:
	register long a7 __asm__("a7") = n;
    10ca:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10ce:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    10d2:	2501                	sext.w	a0,a0
    10d4:	8082                	ret

00000000000010d6 <get_mtime>:

int64 get_mtime()
{
    10d6:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    10d8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    10dc:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    10de:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10e0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    10e4:	2501                	sext.w	a0,a0
    10e6:	ed01                	bnez	a0,10fe <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    10e8:	6722                	ld	a4,8(sp)
    10ea:	3e800793          	li	a5,1000
    10ee:	6682                	ld	a3,0(sp)
    10f0:	02f75733          	divu	a4,a4,a5
    10f4:	02d78533          	mul	a0,a5,a3
    10f8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    10fa:	0141                	addi	sp,sp,16
    10fc:	8082                	ret
	return -1;
    10fe:	557d                	li	a0,-1
    1100:	bfed                	j	10fa <get_mtime+0x24>

0000000000001102 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    1102:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1106:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    110a:	2501                	sext.w	a0,a0
    110c:	8082                	ret

000000000000110e <sleep>:

int sleep(unsigned long long time)
{
    110e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    1110:	880a                	mv	a6,sp
{
    1112:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    1114:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1118:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    111a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    111c:	00000073          	ecall
	if (err == 0) {
    1120:	2501                	sext.w	a0,a0
    1122:	ed31                	bnez	a0,117e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    1124:	6722                	ld	a4,8(sp)
    1126:	3e800793          	li	a5,1000
    112a:	6682                	ld	a3,0(sp)
    112c:	02f75733          	divu	a4,a4,a5
    1130:	02d787b3          	mul	a5,a5,a3
    1134:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    1136:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    113a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    113c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    113e:	00000073          	ecall
	if (err == 0) {
    1142:	2501                	sext.w	a0,a0
    1144:	e915                	bnez	a0,1178 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    1146:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    1148:	3e800693          	li	a3,1000
    114c:	a819                	j	1162 <sleep+0x54>
	__asm_syscall("r"(a7))
    114e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    1152:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1156:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1158:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    115a:	00000073          	ecall
	if (err == 0) {
    115e:	2501                	sext.w	a0,a0
    1160:	ed01                	bnez	a0,1178 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    1162:	6722                	ld	a4,8(sp)
    1164:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    1166:	07c00893          	li	a7,124
    116a:	02d75733          	divu	a4,a4,a3
    116e:	02f687b3          	mul	a5,a3,a5
    1172:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    1174:	fcc7ede3          	bltu	a5,a2,114e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    1178:	4501                	li	a0,0
    117a:	0141                	addi	sp,sp,16
    117c:	8082                	ret
    117e:	57fd                	li	a5,-1
    1180:	bf5d                	j	1136 <sleep+0x28>

0000000000001182 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    1182:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    1186:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    118a:	2501                	sext.w	a0,a0
    118c:	8082                	ret

000000000000118e <set_priority>:
	register long a7 __asm__("a7") = n;
    118e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    1192:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    1196:	2501                	sext.w	a0,a0
    1198:	8082                	ret

000000000000119a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    119a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    119e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    11a2:	2501                	sext.w	a0,a0
    11a4:	8082                	ret

00000000000011a6 <munmap>:
	register long a7 __asm__("a7") = n;
    11a6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11aa:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    11ae:	2501                	sext.w	a0,a0
    11b0:	8082                	ret

00000000000011b2 <wait>:

int wait(int *code)
{
    11b2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    11b4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    11b8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11ba:	00000073          	ecall
	return waitpid(-1, code);
}
    11be:	2501                	sext.w	a0,a0
    11c0:	8082                	ret

00000000000011c2 <spawn>:
	register long a7 __asm__("a7") = n;
    11c2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    11c6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    11ca:	2501                	sext.w	a0,a0
    11cc:	8082                	ret

00000000000011ce <pipe>:
	register long a7 __asm__("a7") = n;
    11ce:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    11d2:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    11d6:	2501                	sext.w	a0,a0
    11d8:	8082                	ret

00000000000011da <mailread>:
	register long a7 __asm__("a7") = n;
    11da:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11de:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    11e2:	2501                	sext.w	a0,a0
    11e4:	8082                	ret

00000000000011e6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    11e6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    11ea:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    11ee:	2501                	sext.w	a0,a0
    11f0:	8082                	ret

00000000000011f2 <fstat>:
	register long a7 __asm__("a7") = n;
    11f2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11f6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    11fa:	2501                	sext.w	a0,a0
    11fc:	8082                	ret

00000000000011fe <sys_linkat>:
	register long a4 __asm__("a4") = e;
    11fe:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    1200:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    1204:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1206:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    120a:	2501                	sext.w	a0,a0
    120c:	8082                	ret

000000000000120e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    120e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    1210:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    1214:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1216:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    121a:	2501                	sext.w	a0,a0
    121c:	8082                	ret

000000000000121e <link>:

int link(char *old_path, char *new_path)
{
    121e:	87aa                	mv	a5,a0
    1220:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    1222:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    1226:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    122a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    122c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    1230:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1232:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    1236:	2501                	sext.w	a0,a0
    1238:	8082                	ret

000000000000123a <unlink>:

int unlink(char *path)
{
    123a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    123c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    1240:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    1244:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1246:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    124a:	2501                	sext.w	a0,a0
    124c:	8082                	ret

000000000000124e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    124e:	00001797          	auipc	a5,0x1
    1252:	6527b783          	ld	a5,1618(a5) # 28a0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1256:	439c                	lw	a5,0(a5)
    1258:	c799                	beqz	a5,1266 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    125a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    125e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    1262:	2501                	sext.w	a0,a0
    1264:	8082                	ret
{
    1266:	1101                	addi	sp,sp,-32
    1268:	ec06                	sd	ra,24(sp)
    126a:	e42e                	sd	a1,8(sp)
    126c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    126e:	638000ef          	jal	ra,18a6 <enable_thread_io_buffer>
    1272:	65a2                	ld	a1,8(sp)
    1274:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    1276:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    127a:	00000073          	ecall
}
    127e:	60e2                	ld	ra,24(sp)
    1280:	2501                	sext.w	a0,a0
    1282:	6105                	addi	sp,sp,32
    1284:	8082                	ret

0000000000001286 <gettid>:
	register long a7 __asm__("a7") = n;
    1286:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    128a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    128e:	2501                	sext.w	a0,a0
    1290:	8082                	ret

0000000000001292 <waittid>:

int waittid(int tid)
{
    1292:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    1294:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    1298:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    129c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    129e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12a0:	00e51e63          	bne	a0,a4,12bc <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    12a4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    12a8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    12ac:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    12b0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    12b2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    12b6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12b8:	fee506e3          	beq	a0,a4,12a4 <waittid+0x12>
	}
	return ret;
}
    12bc:	8082                	ret

00000000000012be <mutex_create>:
	register long a7 __asm__("a7") = n;
    12be:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12c2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    12c4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    12c8:	2501                	sext.w	a0,a0
    12ca:	8082                	ret

00000000000012cc <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    12cc:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12d0:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    12d2:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    12d6:	2501                	sext.w	a0,a0
    12d8:	8082                	ret

00000000000012da <mutex_lock>:
	register long a7 __asm__("a7") = n;
    12da:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    12de:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    12e2:	2501                	sext.w	a0,a0
    12e4:	8082                	ret

00000000000012e6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    12e6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    12ea:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    12ee:	2501                	sext.w	a0,a0
    12f0:	8082                	ret

00000000000012f2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    12f2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    12f6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    12fa:	2501                	sext.w	a0,a0
    12fc:	8082                	ret

00000000000012fe <semaphore_up>:
	register long a7 __asm__("a7") = n;
    12fe:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    1302:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    1306:	2501                	sext.w	a0,a0
    1308:	8082                	ret

000000000000130a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    130a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    130e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    1312:	2501                	sext.w	a0,a0
    1314:	8082                	ret

0000000000001316 <condvar_create>:
	register long a7 __asm__("a7") = n;
    1316:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    131a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    131e:	2501                	sext.w	a0,a0
    1320:	8082                	ret

0000000000001322 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    1322:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    1326:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    132a:	2501                	sext.w	a0,a0
    132c:	8082                	ret

000000000000132e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    132e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1332:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    1336:	2501                	sext.w	a0,a0
    1338:	8082                	ret

000000000000133a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    133a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    133e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    1342:	2501                	sext.w	a0,a0
    1344:	8082                	ret

0000000000001346 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1346:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1348:	4605                	li	a2,1
    134a:	00f10593          	addi	a1,sp,15
    134e:	4501                	li	a0,0
{
    1350:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1352:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1356:	d03ff0ef          	jal	ra,1058 <read>
    135a:	4785                	li	a5,1
    135c:	00f51763          	bne	a0,a5,136a <getchar+0x24>
		return byte;
    1360:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1364:	60e2                	ld	ra,24(sp)
    1366:	6105                	addi	sp,sp,32
    1368:	8082                	ret
		return EOF;
    136a:	557d                	li	a0,-1
    136c:	bfe5                	j	1364 <getchar+0x1e>

000000000000136e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    136e:	00001517          	auipc	a0,0x1
    1372:	40252503          	lw	a0,1026(a0) # 2770 <buffer_len>
    1376:	e111                	bnez	a0,137a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1378:	8082                	ret
{
    137a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    137c:	862a                	mv	a2,a0
    137e:	00001597          	auipc	a1,0x1
    1382:	3fa58593          	addi	a1,a1,1018 # 2778 <buffer>
    1386:	4505                	li	a0,1
{
    1388:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    138a:	cd9ff0ef          	jal	ra,1062 <write>
}
    138e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1390:	2501                	sext.w	a0,a0
}
    1392:	0141                	addi	sp,sp,16
    1394:	8082                	ret

0000000000001396 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1396:	00001797          	auipc	a5,0x1
    139a:	3c07ad23          	sw	zero,986(a5) # 2770 <buffer_len>
}
    139e:	8082                	ret

00000000000013a0 <__fflush>:
	if (buffer_len == 0)
    13a0:	00001517          	auipc	a0,0x1
    13a4:	3d052503          	lw	a0,976(a0) # 2770 <buffer_len>
    13a8:	e511                	bnez	a0,13b4 <__fflush+0x14>
	buffer_len = 0;
    13aa:	00001797          	auipc	a5,0x1
    13ae:	3c07a323          	sw	zero,966(a5) # 2770 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13b2:	8082                	ret
{
    13b4:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13b6:	862a                	mv	a2,a0
    13b8:	00001597          	auipc	a1,0x1
    13bc:	3c058593          	addi	a1,a1,960 # 2778 <buffer>
    13c0:	4505                	li	a0,1
{
    13c2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13c4:	c9fff0ef          	jal	ra,1062 <write>
	return r >= 0 ? 0 : r;
    13c8:	0005079b          	sext.w	a5,a0
}
    13cc:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13ce:	0017a793          	slti	a5,a5,1
    13d2:	40f007bb          	negw	a5,a5
    13d6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13d8:	00001797          	auipc	a5,0x1
    13dc:	3807ac23          	sw	zero,920(a5) # 2770 <buffer_len>
	return r >= 0 ? 0 : r;
    13e0:	2501                	sext.w	a0,a0
}
    13e2:	0141                	addi	sp,sp,16
    13e4:	8082                	ret

00000000000013e6 <fflush>:

int fflush(int fd)
{
    13e6:	1101                	addi	sp,sp,-32
    13e8:	e822                	sd	s0,16(sp)
    13ea:	ec06                	sd	ra,24(sp)
    13ec:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13ee:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13f0:	4401                	li	s0,0
	if (fd == 1) {
    13f2:	00e50863          	beq	a0,a4,1402 <fflush+0x1c>
}
    13f6:	60e2                	ld	ra,24(sp)
    13f8:	8522                	mv	a0,s0
    13fa:	6442                	ld	s0,16(sp)
    13fc:	64a2                	ld	s1,8(sp)
    13fe:	6105                	addi	sp,sp,32
    1400:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1402:	00001497          	auipc	s1,0x1
    1406:	36e48493          	addi	s1,s1,878 # 2770 <buffer_len>
    140a:	1084a703          	lw	a4,264(s1)
    140e:	02a70e63          	beq	a4,a0,144a <fflush+0x64>
	if (buffer_len == 0)
    1412:	4080                	lw	s0,0(s1)
    1414:	c00d                	beqz	s0,1436 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1416:	8622                	mv	a2,s0
    1418:	00001597          	auipc	a1,0x1
    141c:	36058593          	addi	a1,a1,864 # 2778 <buffer>
    1420:	c43ff0ef          	jal	ra,1062 <write>
	return r >= 0 ? 0 : r;
    1424:	0005079b          	sext.w	a5,a0
    1428:	0017a793          	slti	a5,a5,1
    142c:	40f007bb          	negw	a5,a5
    1430:	8d7d                	and	a0,a0,a5
    1432:	0005041b          	sext.w	s0,a0
}
    1436:	60e2                	ld	ra,24(sp)
    1438:	8522                	mv	a0,s0
    143a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    143c:	00001797          	auipc	a5,0x1
    1440:	3207aa23          	sw	zero,820(a5) # 2770 <buffer_len>
}
    1444:	64a2                	ld	s1,8(sp)
    1446:	6105                	addi	sp,sp,32
    1448:	8082                	ret
			mutex_lock(buffer_lock);
    144a:	10c4a503          	lw	a0,268(s1)
    144e:	e8dff0ef          	jal	ra,12da <mutex_lock>
	if (buffer_len == 0)
    1452:	4080                	lw	s0,0(s1)
    1454:	e811                	bnez	s0,1468 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1456:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    145a:	00001797          	auipc	a5,0x1
    145e:	3007ab23          	sw	zero,790(a5) # 2770 <buffer_len>
			mutex_unlock(buffer_lock);
    1462:	e85ff0ef          	jal	ra,12e6 <mutex_unlock>
    1466:	bf41                	j	13f6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1468:	8622                	mv	a2,s0
    146a:	00001597          	auipc	a1,0x1
    146e:	30e58593          	addi	a1,a1,782 # 2778 <buffer>
    1472:	4505                	li	a0,1
    1474:	befff0ef          	jal	ra,1062 <write>
	return r >= 0 ? 0 : r;
    1478:	0005079b          	sext.w	a5,a0
    147c:	0017a793          	slti	a5,a5,1
    1480:	40f007bb          	negw	a5,a5
    1484:	8d7d                	and	a0,a0,a5
    1486:	0005041b          	sext.w	s0,a0
	return r;
    148a:	b7f1                	j	1456 <fflush+0x70>

000000000000148c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    148c:	7131                	addi	sp,sp,-192
    148e:	e0da                	sd	s6,64(sp)
    1490:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1492:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1494:	013c                	addi	a5,sp,136
{
    1496:	f0ca                	sd	s2,96(sp)
    1498:	ecce                	sd	s3,88(sp)
    149a:	e8d2                	sd	s4,80(sp)
    149c:	e4d6                	sd	s5,72(sp)
    149e:	fc86                	sd	ra,120(sp)
    14a0:	f8a2                	sd	s0,112(sp)
    14a2:	f4a6                	sd	s1,104(sp)
    14a4:	89aa                	mv	s3,a0
    14a6:	e52e                	sd	a1,136(sp)
    14a8:	e932                	sd	a2,144(sp)
    14aa:	ed36                	sd	a3,152(sp)
    14ac:	f13a                	sd	a4,160(sp)
    14ae:	f942                	sd	a6,176(sp)
    14b0:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14b2:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14b4:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14b8:	00001a17          	auipc	s4,0x1
    14bc:	2b8a0a13          	addi	s4,s4,696 # 2770 <buffer_len>
    14c0:	4a85                	li	s5,1
	buf[i++] = '0';
    14c2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14c6:	0009c783          	lbu	a5,0(s3)
    14ca:	18078663          	beqz	a5,1656 <printf+0x1ca>
    14ce:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14d0:	19278d63          	beq	a5,s2,166a <printf+0x1de>
    14d4:	0015c783          	lbu	a5,1(a1)
    14d8:	0585                	addi	a1,a1,1
    14da:	fbfd                	bnez	a5,14d0 <printf+0x44>
    14dc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14de:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14e2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14e6:	1b578863          	beq	a5,s5,1696 <printf+0x20a>
		len = out_unlocked(s, l);
    14ea:	85a2                	mv	a1,s0
    14ec:	854e                	mv	a0,s3
    14ee:	42a000ef          	jal	ra,1918 <out_unlocked>
		out(f, a, l);
		if (l)
    14f2:	1c041063          	bnez	s0,16b2 <printf+0x226>
			continue;
		if (s[1] == 0)
    14f6:	0014c783          	lbu	a5,1(s1)
    14fa:	14078e63          	beqz	a5,1656 <printf+0x1ca>
			break;
		switch (s[1]) {
    14fe:	07300713          	li	a4,115
    1502:	1ce78863          	beq	a5,a4,16d2 <printf+0x246>
    1506:	1af76863          	bltu	a4,a5,16b6 <printf+0x22a>
    150a:	06400713          	li	a4,100
    150e:	22e78063          	beq	a5,a4,172e <printf+0x2a2>
    1512:	07000713          	li	a4,112
    1516:	1ee79563          	bne	a5,a4,1700 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    151a:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    151c:	00001797          	auipc	a5,0x1
    1520:	36478793          	addi	a5,a5,868 # 2880 <digits>
	buf[i++] = '0';
    1524:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1528:	6298                	ld	a4,0(a3)
    152a:	06a1                	addi	a3,a3,8
    152c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    152e:	00471393          	slli	t2,a4,0x4
    1532:	00871293          	slli	t0,a4,0x8
    1536:	00c71f93          	slli	t6,a4,0xc
    153a:	01071f13          	slli	t5,a4,0x10
    153e:	01471e93          	slli	t4,a4,0x14
    1542:	01871e13          	slli	t3,a4,0x18
    1546:	01c71893          	slli	a7,a4,0x1c
    154a:	02471813          	slli	a6,a4,0x24
    154e:	02871513          	slli	a0,a4,0x28
    1552:	02c71593          	slli	a1,a4,0x2c
    1556:	03071613          	slli	a2,a4,0x30
    155a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    155e:	03c75413          	srli	s0,a4,0x3c
    1562:	01c7531b          	srliw	t1,a4,0x1c
    1566:	03c3d393          	srli	t2,t2,0x3c
    156a:	03c2d293          	srli	t0,t0,0x3c
    156e:	03cfdf93          	srli	t6,t6,0x3c
    1572:	03cf5f13          	srli	t5,t5,0x3c
    1576:	03cede93          	srli	t4,t4,0x3c
    157a:	03ce5e13          	srli	t3,t3,0x3c
    157e:	03c8d893          	srli	a7,a7,0x3c
    1582:	03c85813          	srli	a6,a6,0x3c
    1586:	9171                	srli	a0,a0,0x3c
    1588:	91f1                	srli	a1,a1,0x3c
    158a:	9271                	srli	a2,a2,0x3c
    158c:	92f1                	srli	a3,a3,0x3c
    158e:	95be                	add	a1,a1,a5
    1590:	963e                	add	a2,a2,a5
    1592:	96be                	add	a3,a3,a5
    1594:	943e                	add	s0,s0,a5
    1596:	93be                	add	t2,t2,a5
    1598:	92be                	add	t0,t0,a5
    159a:	9fbe                	add	t6,t6,a5
    159c:	9f3e                	add	t5,t5,a5
    159e:	9ebe                	add	t4,t4,a5
    15a0:	9e3e                	add	t3,t3,a5
    15a2:	98be                	add	a7,a7,a5
    15a4:	933e                	add	t1,t1,a5
    15a6:	983e                	add	a6,a6,a5
    15a8:	953e                	add	a0,a0,a5
    15aa:	0005c983          	lbu	s3,0(a1)
    15ae:	00044403          	lbu	s0,0(s0)
    15b2:	00064583          	lbu	a1,0(a2)
    15b6:	0003c383          	lbu	t2,0(t2)
    15ba:	0006c603          	lbu	a2,0(a3)
    15be:	0002c283          	lbu	t0,0(t0)
    15c2:	000fcf83          	lbu	t6,0(t6)
    15c6:	000f4f03          	lbu	t5,0(t5)
    15ca:	000ece83          	lbu	t4,0(t4)
    15ce:	000e4e03          	lbu	t3,0(t3)
    15d2:	0008c883          	lbu	a7,0(a7)
    15d6:	00034303          	lbu	t1,0(t1)
    15da:	00084803          	lbu	a6,0(a6)
    15de:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15e2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15e6:	92f1                	srli	a3,a3,0x3c
    15e8:	8b3d                	andi	a4,a4,15
    15ea:	96be                	add	a3,a3,a5
    15ec:	97ba                	add	a5,a5,a4
    15ee:	00810d23          	sb	s0,26(sp)
    15f2:	00710da3          	sb	t2,27(sp)
    15f6:	00510e23          	sb	t0,28(sp)
    15fa:	01f10ea3          	sb	t6,29(sp)
    15fe:	01e10f23          	sb	t5,30(sp)
    1602:	01d10fa3          	sb	t4,31(sp)
    1606:	03c10023          	sb	t3,32(sp)
    160a:	031100a3          	sb	a7,33(sp)
    160e:	02610123          	sb	t1,34(sp)
    1612:	030101a3          	sb	a6,35(sp)
    1616:	02a10223          	sb	a0,36(sp)
    161a:	033102a3          	sb	s3,37(sp)
    161e:	02b10323          	sb	a1,38(sp)
    1622:	02c103a3          	sb	a2,39(sp)
    1626:	0006c683          	lbu	a3,0(a3)
    162a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    162e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1632:	02d10423          	sb	a3,40(sp)
    1636:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    163a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    163e:	11578263          	beq	a5,s5,1742 <printf+0x2b6>
		len = out_unlocked(s, l);
    1642:	45c9                	li	a1,18
    1644:	0828                	addi	a0,sp,24
    1646:	2d2000ef          	jal	ra,1918 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    164a:	00248993          	addi	s3,s1,2
		if (!*s)
    164e:	0009c783          	lbu	a5,0(s3)
    1652:	e6079ee3          	bnez	a5,14ce <printf+0x42>
	}
	va_end(ap);
    1656:	70e6                	ld	ra,120(sp)
    1658:	7446                	ld	s0,112(sp)
    165a:	74a6                	ld	s1,104(sp)
    165c:	7906                	ld	s2,96(sp)
    165e:	69e6                	ld	s3,88(sp)
    1660:	6a46                	ld	s4,80(sp)
    1662:	6aa6                	ld	s5,72(sp)
    1664:	6b06                	ld	s6,64(sp)
    1666:	6129                	addi	sp,sp,192
    1668:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    166a:	0005c783          	lbu	a5,0(a1)
    166e:	84ae                	mv	s1,a1
    1670:	01278963          	beq	a5,s2,1682 <printf+0x1f6>
    1674:	b5ad                	j	14de <printf+0x52>
    1676:	0024c783          	lbu	a5,2(s1)
    167a:	0585                	addi	a1,a1,1
    167c:	0489                	addi	s1,s1,2
    167e:	e72790e3          	bne	a5,s2,14de <printf+0x52>
    1682:	0014c783          	lbu	a5,1(s1)
    1686:	ff2788e3          	beq	a5,s2,1676 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    168a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    168e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1692:	e5579ce3          	bne	a5,s5,14ea <printf+0x5e>
		mutex_lock(buffer_lock);
    1696:	10ca2503          	lw	a0,268(s4)
    169a:	c41ff0ef          	jal	ra,12da <mutex_lock>
		len = out_unlocked(s, l);
    169e:	85a2                	mv	a1,s0
    16a0:	854e                	mv	a0,s3
    16a2:	276000ef          	jal	ra,1918 <out_unlocked>
		mutex_unlock(buffer_lock);
    16a6:	10ca2503          	lw	a0,268(s4)
    16aa:	c3dff0ef          	jal	ra,12e6 <mutex_unlock>
		if (l)
    16ae:	e40404e3          	beqz	s0,14f6 <printf+0x6a>
    16b2:	89a6                	mv	s3,s1
    16b4:	bd09                	j	14c6 <printf+0x3a>
		switch (s[1]) {
    16b6:	07800713          	li	a4,120
    16ba:	04e79363          	bne	a5,a4,1700 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16be:	67c2                	ld	a5,16(sp)
    16c0:	45c1                	li	a1,16
		s += 2;
    16c2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16c6:	4388                	lw	a0,0(a5)
    16c8:	07a1                	addi	a5,a5,8
    16ca:	e83e                	sd	a5,16(sp)
    16cc:	5f8000ef          	jal	ra,1cc4 <printint.constprop.0>
		s += 2;
    16d0:	bfbd                	j	164e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16d2:	67c2                	ld	a5,16(sp)
    16d4:	6380                	ld	s0,0(a5)
    16d6:	07a1                	addi	a5,a5,8
    16d8:	e83e                	sd	a5,16(sp)
    16da:	1c040163          	beqz	s0,189c <printf+0x410>
			l = strnlen(a, 200);
    16de:	0c800593          	li	a1,200
    16e2:	8522                	mv	a0,s0
    16e4:	3f7000ef          	jal	ra,22da <strnlen>
	if (buffer_lock_enabled == 1) {
    16e8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16ec:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16f0:	19578663          	beq	a5,s5,187c <printf+0x3f0>
		len = out_unlocked(s, l);
    16f4:	8522                	mv	a0,s0
    16f6:	222000ef          	jal	ra,1918 <out_unlocked>
		s += 2;
    16fa:	00248993          	addi	s3,s1,2
    16fe:	bf81                	j	164e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1700:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1704:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1708:	0f578663          	beq	a5,s5,17f4 <printf+0x368>
		len = out_unlocked(s, l);
    170c:	0828                	addi	a0,sp,24
    170e:	316000ef          	jal	ra,1a24 <out_unlocked.constprop.0>
			putchar(s[1]);
    1712:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1716:	108a2783          	lw	a5,264(s4)
	char byte = c;
    171a:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    171e:	05578163          	beq	a5,s5,1760 <printf+0x2d4>
		len = out_unlocked(s, l);
    1722:	0828                	addi	a0,sp,24
    1724:	300000ef          	jal	ra,1a24 <out_unlocked.constprop.0>
		s += 2;
    1728:	00248993          	addi	s3,s1,2
    172c:	b70d                	j	164e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    172e:	67c2                	ld	a5,16(sp)
    1730:	45a9                	li	a1,10
		s += 2;
    1732:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1736:	4388                	lw	a0,0(a5)
    1738:	07a1                	addi	a5,a5,8
    173a:	e83e                	sd	a5,16(sp)
    173c:	588000ef          	jal	ra,1cc4 <printint.constprop.0>
		s += 2;
    1740:	b739                	j	164e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1742:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1746:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    174a:	b91ff0ef          	jal	ra,12da <mutex_lock>
		len = out_unlocked(s, l);
    174e:	45c9                	li	a1,18
    1750:	0828                	addi	a0,sp,24
    1752:	1c6000ef          	jal	ra,1918 <out_unlocked>
		mutex_unlock(buffer_lock);
    1756:	10ca2503          	lw	a0,268(s4)
    175a:	b8dff0ef          	jal	ra,12e6 <mutex_unlock>
		s += 2;
    175e:	bdc5                	j	164e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1760:	10ca2503          	lw	a0,268(s4)
    1764:	b77ff0ef          	jal	ra,12da <mutex_lock>
		buffer[buffer_len++] = c;
    1768:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    176c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1770:	0017861b          	addiw	a2,a5,1
    1774:	97d2                	add	a5,a5,s4
    1776:	00ca2023          	sw	a2,0(s4)
    177a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    177e:	00c6cc63          	blt	a3,a2,1796 <printf+0x30a>
    1782:	47a9                	li	a5,10
    1784:	06f40663          	beq	s0,a5,17f0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1788:	10ca2503          	lw	a0,268(s4)
		s += 2;
    178c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1790:	b57ff0ef          	jal	ra,12e6 <mutex_unlock>
		s += 2;
    1794:	bd6d                	j	164e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1796:	10000793          	li	a5,256
    179a:	00f61e63          	bne	a2,a5,17b6 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    179e:	00001597          	auipc	a1,0x1
    17a2:	fda58593          	addi	a1,a1,-38 # 2778 <buffer>
    17a6:	4505                	li	a0,1
    17a8:	8bbff0ef          	jal	ra,1062 <write>
	buffer_len = 0;
    17ac:	00001797          	auipc	a5,0x1
    17b0:	fc07a223          	sw	zero,-60(a5) # 2770 <buffer_len>
			if (r < 0) {
    17b4:	bfd1                	j	1788 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17b6:	8b7ff0ef          	jal	ra,106c <getpid>
    17ba:	842a                	mv	s0,a0
    17bc:	00001517          	auipc	a0,0x1
    17c0:	ebc50513          	addi	a0,a0,-324 # 2678 <basename+0xe4>
    17c4:	5d1000ef          	jal	ra,2594 <basename>
    17c8:	872a                	mv	a4,a0
    17ca:	00001617          	auipc	a2,0x1
    17ce:	eee60613          	addi	a2,a2,-274 # 26b8 <basename+0x124>
    17d2:	05400793          	li	a5,84
    17d6:	86a2                	mv	a3,s0
    17d8:	45fd                	li	a1,31
    17da:	00001517          	auipc	a0,0x1
    17de:	ee650513          	addi	a0,a0,-282 # 26c0 <basename+0x12c>
    17e2:	cabff0ef          	jal	ra,148c <printf>
    17e6:	557d                	li	a0,-1
    17e8:	8b5ff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    17ec:	000a2603          	lw	a2,0(s4)
    17f0:	de41                	beqz	a2,1788 <printf+0x2fc>
    17f2:	b775                	j	179e <printf+0x312>
		mutex_lock(buffer_lock);
    17f4:	10ca2503          	lw	a0,268(s4)
    17f8:	ae3ff0ef          	jal	ra,12da <mutex_lock>
		buffer[buffer_len++] = c;
    17fc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1800:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1804:	0017861b          	addiw	a2,a5,1
    1808:	97d2                	add	a5,a5,s4
    180a:	00ca2023          	sw	a2,0(s4)
    180e:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1812:	02c6d163          	bge	a3,a2,1834 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1816:	10000793          	li	a5,256
    181a:	02f61263          	bne	a2,a5,183e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    181e:	00001597          	auipc	a1,0x1
    1822:	f5a58593          	addi	a1,a1,-166 # 2778 <buffer>
    1826:	4505                	li	a0,1
    1828:	83bff0ef          	jal	ra,1062 <write>
	buffer_len = 0;
    182c:	00001797          	auipc	a5,0x1
    1830:	f407a223          	sw	zero,-188(a5) # 2770 <buffer_len>
		mutex_unlock(buffer_lock);
    1834:	10ca2503          	lw	a0,268(s4)
    1838:	aafff0ef          	jal	ra,12e6 <mutex_unlock>
    183c:	bdd9                	j	1712 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    183e:	82fff0ef          	jal	ra,106c <getpid>
    1842:	842a                	mv	s0,a0
    1844:	00001517          	auipc	a0,0x1
    1848:	e3450513          	addi	a0,a0,-460 # 2678 <basename+0xe4>
    184c:	549000ef          	jal	ra,2594 <basename>
    1850:	872a                	mv	a4,a0
    1852:	00001617          	auipc	a2,0x1
    1856:	e6660613          	addi	a2,a2,-410 # 26b8 <basename+0x124>
    185a:	05400793          	li	a5,84
    185e:	86a2                	mv	a3,s0
    1860:	45fd                	li	a1,31
    1862:	00001517          	auipc	a0,0x1
    1866:	e5e50513          	addi	a0,a0,-418 # 26c0 <basename+0x12c>
    186a:	c23ff0ef          	jal	ra,148c <printf>
    186e:	557d                	li	a0,-1
    1870:	82dff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    1874:	000a2603          	lw	a2,0(s4)
    1878:	de55                	beqz	a2,1834 <printf+0x3a8>
    187a:	b755                	j	181e <printf+0x392>
		mutex_lock(buffer_lock);
    187c:	10ca2503          	lw	a0,268(s4)
    1880:	e42e                	sd	a1,8(sp)
		s += 2;
    1882:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1886:	a55ff0ef          	jal	ra,12da <mutex_lock>
		len = out_unlocked(s, l);
    188a:	65a2                	ld	a1,8(sp)
    188c:	8522                	mv	a0,s0
    188e:	08a000ef          	jal	ra,1918 <out_unlocked>
		mutex_unlock(buffer_lock);
    1892:	10ca2503          	lw	a0,268(s4)
    1896:	a51ff0ef          	jal	ra,12e6 <mutex_unlock>
		s += 2;
    189a:	bb55                	j	164e <printf+0x1c2>
				a = "(null)";
    189c:	00001417          	auipc	s0,0x1
    18a0:	dd440413          	addi	s0,s0,-556 # 2670 <basename+0xdc>
    18a4:	bd2d                	j	16de <printf+0x252>

00000000000018a6 <enable_thread_io_buffer>:
{
    18a6:	1101                	addi	sp,sp,-32
    18a8:	e822                	sd	s0,16(sp)
    18aa:	ec06                	sd	ra,24(sp)
    18ac:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18ae:	00001417          	auipc	s0,0x1
    18b2:	ec240413          	addi	s0,s0,-318 # 2770 <buffer_len>
    18b6:	a09ff0ef          	jal	ra,12be <mutex_create>
    18ba:	10a42623          	sw	a0,268(s0)
    18be:	00054a63          	bltz	a0,18d2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18c2:	4785                	li	a5,1
}
    18c4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18c6:	10f42423          	sw	a5,264(s0)
}
    18ca:	6442                	ld	s0,16(sp)
    18cc:	64a2                	ld	s1,8(sp)
    18ce:	6105                	addi	sp,sp,32
    18d0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18d2:	f9aff0ef          	jal	ra,106c <getpid>
    18d6:	84aa                	mv	s1,a0
    18d8:	00001517          	auipc	a0,0x1
    18dc:	da050513          	addi	a0,a0,-608 # 2678 <basename+0xe4>
    18e0:	4b5000ef          	jal	ra,2594 <basename>
    18e4:	872a                	mv	a4,a0
    18e6:	04800793          	li	a5,72
    18ea:	86a6                	mv	a3,s1
    18ec:	00001517          	auipc	a0,0x1
    18f0:	e1450513          	addi	a0,a0,-492 # 2700 <basename+0x16c>
    18f4:	00001617          	auipc	a2,0x1
    18f8:	dc460613          	addi	a2,a2,-572 # 26b8 <basename+0x124>
    18fc:	45fd                	li	a1,31
    18fe:	b8fff0ef          	jal	ra,148c <printf>
    1902:	557d                	li	a0,-1
    1904:	f98ff0ef          	jal	ra,109c <exit>
	buffer_lock_enabled = 1;
    1908:	4785                	li	a5,1
}
    190a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    190c:	10f42423          	sw	a5,264(s0)
}
    1910:	6442                	ld	s0,16(sp)
    1912:	64a2                	ld	s1,8(sp)
    1914:	6105                	addi	sp,sp,32
    1916:	8082                	ret

0000000000001918 <out_unlocked>:
{
    1918:	7159                	addi	sp,sp,-112
    191a:	f486                	sd	ra,104(sp)
    191c:	f0a2                	sd	s0,96(sp)
    191e:	eca6                	sd	s1,88(sp)
    1920:	e8ca                	sd	s2,80(sp)
    1922:	e4ce                	sd	s3,72(sp)
    1924:	e0d2                	sd	s4,64(sp)
    1926:	fc56                	sd	s5,56(sp)
    1928:	f85a                	sd	s6,48(sp)
    192a:	f45e                	sd	s7,40(sp)
    192c:	f062                	sd	s8,32(sp)
    192e:	ec66                	sd	s9,24(sp)
    1930:	e86a                	sd	s10,16(sp)
    1932:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1934:	0e058663          	beqz	a1,1a20 <out_unlocked+0x108>
    1938:	842a                	mv	s0,a0
    193a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    193e:	4981                	li	s3,0
    1940:	00001d17          	auipc	s10,0x1
    1944:	e30d0d13          	addi	s10,s10,-464 # 2770 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1948:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    194c:	00001b17          	auipc	s6,0x1
    1950:	e2cb0b13          	addi	s6,s6,-468 # 2778 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1954:	10000a93          	li	s5,256
    1958:	00001c97          	auipc	s9,0x1
    195c:	d20c8c93          	addi	s9,s9,-736 # 2678 <basename+0xe4>
    1960:	00001c17          	auipc	s8,0x1
    1964:	d58c0c13          	addi	s8,s8,-680 # 26b8 <basename+0x124>
    1968:	00001b97          	auipc	s7,0x1
    196c:	d58b8b93          	addi	s7,s7,-680 # 26c0 <basename+0x12c>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1970:	4a29                	li	s4,10
    1972:	a031                	j	197e <out_unlocked+0x66>
    1974:	09468863          	beq	a3,s4,1a04 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1978:	0405                	addi	s0,s0,1
    197a:	04848163          	beq	s1,s0,19bc <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    197e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1982:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1986:	0017861b          	addiw	a2,a5,1
    198a:	97ea                	add	a5,a5,s10
    198c:	00cd2023          	sw	a2,0(s10)
    1990:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1994:	fec950e3          	bge	s2,a2,1974 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1998:	05561263          	bne	a2,s5,19dc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    199c:	85da                	mv	a1,s6
    199e:	4505                	li	a0,1
    19a0:	ec2ff0ef          	jal	ra,1062 <write>
    19a4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19a6:	00001797          	auipc	a5,0x1
    19aa:	dc07a523          	sw	zero,-566(a5) # 2770 <buffer_len>
			if (r < 0) {
    19ae:	06054763          	bltz	a0,1a1c <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19b2:	0405                	addi	s0,s0,1
			ret += r;
    19b4:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19b8:	fc8493e3          	bne	s1,s0,197e <out_unlocked+0x66>
}
    19bc:	70a6                	ld	ra,104(sp)
    19be:	7406                	ld	s0,96(sp)
    19c0:	64e6                	ld	s1,88(sp)
    19c2:	6946                	ld	s2,80(sp)
    19c4:	6a06                	ld	s4,64(sp)
    19c6:	7ae2                	ld	s5,56(sp)
    19c8:	7b42                	ld	s6,48(sp)
    19ca:	7ba2                	ld	s7,40(sp)
    19cc:	7c02                	ld	s8,32(sp)
    19ce:	6ce2                	ld	s9,24(sp)
    19d0:	6d42                	ld	s10,16(sp)
    19d2:	6da2                	ld	s11,8(sp)
    19d4:	854e                	mv	a0,s3
    19d6:	69a6                	ld	s3,72(sp)
    19d8:	6165                	addi	sp,sp,112
    19da:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19dc:	e90ff0ef          	jal	ra,106c <getpid>
    19e0:	8daa                	mv	s11,a0
    19e2:	8566                	mv	a0,s9
    19e4:	3b1000ef          	jal	ra,2594 <basename>
    19e8:	872a                	mv	a4,a0
    19ea:	8662                	mv	a2,s8
    19ec:	05400793          	li	a5,84
    19f0:	86ee                	mv	a3,s11
    19f2:	45fd                	li	a1,31
    19f4:	855e                	mv	a0,s7
    19f6:	a97ff0ef          	jal	ra,148c <printf>
    19fa:	557d                	li	a0,-1
    19fc:	ea0ff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    1a00:	000d2603          	lw	a2,0(s10)
    1a04:	da35                	beqz	a2,1978 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a06:	85da                	mv	a1,s6
    1a08:	4505                	li	a0,1
    1a0a:	e58ff0ef          	jal	ra,1062 <write>
    1a0e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a10:	00001797          	auipc	a5,0x1
    1a14:	d607a023          	sw	zero,-672(a5) # 2770 <buffer_len>
			if (r < 0) {
    1a18:	f8055de3          	bgez	a0,19b2 <out_unlocked+0x9a>
    1a1c:	89aa                	mv	s3,a0
    1a1e:	bf79                	j	19bc <out_unlocked+0xa4>
	int ret = 0;
    1a20:	4981                	li	s3,0
    1a22:	bf69                	j	19bc <out_unlocked+0xa4>

0000000000001a24 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a24:	1101                	addi	sp,sp,-32
    1a26:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a28:	00001497          	auipc	s1,0x1
    1a2c:	d4848493          	addi	s1,s1,-696 # 2770 <buffer_len>
    1a30:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a32:	ec06                	sd	ra,24(sp)
    1a34:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a36:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a3a:	0017861b          	addiw	a2,a5,1
    1a3e:	97a6                	add	a5,a5,s1
    1a40:	00e78423          	sb	a4,8(a5)
    1a44:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a46:	0ff00793          	li	a5,255
    1a4a:	00c7cc63          	blt	a5,a2,1a62 <out_unlocked.constprop.0+0x3e>
    1a4e:	47a9                	li	a5,10
    1a50:	06f70c63          	beq	a4,a5,1ac8 <out_unlocked.constprop.0+0xa4>
    1a54:	4601                	li	a2,0
}
    1a56:	60e2                	ld	ra,24(sp)
    1a58:	6442                	ld	s0,16(sp)
    1a5a:	64a2                	ld	s1,8(sp)
    1a5c:	8532                	mv	a0,a2
    1a5e:	6105                	addi	sp,sp,32
    1a60:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a62:	10000793          	li	a5,256
    1a66:	02f61563          	bne	a2,a5,1a90 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a6a:	00001597          	auipc	a1,0x1
    1a6e:	d0e58593          	addi	a1,a1,-754 # 2778 <buffer>
    1a72:	4505                	li	a0,1
    1a74:	deeff0ef          	jal	ra,1062 <write>
}
    1a78:	60e2                	ld	ra,24(sp)
    1a7a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a7c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a80:	00001797          	auipc	a5,0x1
    1a84:	ce07a823          	sw	zero,-784(a5) # 2770 <buffer_len>
}
    1a88:	64a2                	ld	s1,8(sp)
    1a8a:	8532                	mv	a0,a2
    1a8c:	6105                	addi	sp,sp,32
    1a8e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a90:	ddcff0ef          	jal	ra,106c <getpid>
    1a94:	842a                	mv	s0,a0
    1a96:	00001517          	auipc	a0,0x1
    1a9a:	be250513          	addi	a0,a0,-1054 # 2678 <basename+0xe4>
    1a9e:	2f7000ef          	jal	ra,2594 <basename>
    1aa2:	872a                	mv	a4,a0
    1aa4:	00001617          	auipc	a2,0x1
    1aa8:	c1460613          	addi	a2,a2,-1004 # 26b8 <basename+0x124>
    1aac:	05400793          	li	a5,84
    1ab0:	86a2                	mv	a3,s0
    1ab2:	45fd                	li	a1,31
    1ab4:	00001517          	auipc	a0,0x1
    1ab8:	c0c50513          	addi	a0,a0,-1012 # 26c0 <basename+0x12c>
    1abc:	9d1ff0ef          	jal	ra,148c <printf>
    1ac0:	557d                	li	a0,-1
    1ac2:	ddaff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    1ac6:	4090                	lw	a2,0(s1)
    1ac8:	d659                	beqz	a2,1a56 <out_unlocked.constprop.0+0x32>
    1aca:	b745                	j	1a6a <out_unlocked.constprop.0+0x46>

0000000000001acc <putchar>:
{
    1acc:	7139                	addi	sp,sp,-64
    1ace:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ad0:	00001497          	auipc	s1,0x1
    1ad4:	ca048493          	addi	s1,s1,-864 # 2770 <buffer_len>
    1ad8:	1084a703          	lw	a4,264(s1)
{
    1adc:	f822                	sd	s0,48(sp)
	char byte = c;
    1ade:	0ff57413          	zext.b	s0,a0
{
    1ae2:	fc06                	sd	ra,56(sp)
	char byte = c;
    1ae4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1ae8:	4785                	li	a5,1
    1aea:	00f70d63          	beq	a4,a5,1b04 <putchar+0x38>
		len = out_unlocked(s, l);
    1aee:	01f10513          	addi	a0,sp,31
    1af2:	f33ff0ef          	jal	ra,1a24 <out_unlocked.constprop.0>
}
    1af6:	70e2                	ld	ra,56(sp)
    1af8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1afa:	862a                	mv	a2,a0
}
    1afc:	74a2                	ld	s1,40(sp)
    1afe:	8532                	mv	a0,a2
    1b00:	6121                	addi	sp,sp,64
    1b02:	8082                	ret
		mutex_lock(buffer_lock);
    1b04:	10c4a503          	lw	a0,268(s1)
    1b08:	fd2ff0ef          	jal	ra,12da <mutex_lock>
		buffer[buffer_len++] = c;
    1b0c:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b0e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b12:	0017861b          	addiw	a2,a5,1
    1b16:	97a6                	add	a5,a5,s1
    1b18:	c090                	sw	a2,0(s1)
    1b1a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b1e:	02c6c263          	blt	a3,a2,1b42 <putchar+0x76>
    1b22:	47a9                	li	a5,10
    1b24:	06f40d63          	beq	s0,a5,1b9e <putchar+0xd2>
    1b28:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b2a:	10c4a503          	lw	a0,268(s1)
    1b2e:	e432                	sd	a2,8(sp)
    1b30:	fb6ff0ef          	jal	ra,12e6 <mutex_unlock>
    1b34:	6622                	ld	a2,8(sp)
}
    1b36:	70e2                	ld	ra,56(sp)
    1b38:	7442                	ld	s0,48(sp)
    1b3a:	74a2                	ld	s1,40(sp)
    1b3c:	8532                	mv	a0,a2
    1b3e:	6121                	addi	sp,sp,64
    1b40:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b42:	10000793          	li	a5,256
    1b46:	02f61063          	bne	a2,a5,1b66 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b4a:	00001597          	auipc	a1,0x1
    1b4e:	c2e58593          	addi	a1,a1,-978 # 2778 <buffer>
    1b52:	4505                	li	a0,1
    1b54:	d0eff0ef          	jal	ra,1062 <write>
    1b58:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b5c:	00001797          	auipc	a5,0x1
    1b60:	c007aa23          	sw	zero,-1004(a5) # 2770 <buffer_len>
			if (r < 0) {
    1b64:	b7d9                	j	1b2a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b66:	d06ff0ef          	jal	ra,106c <getpid>
    1b6a:	842a                	mv	s0,a0
    1b6c:	00001517          	auipc	a0,0x1
    1b70:	b0c50513          	addi	a0,a0,-1268 # 2678 <basename+0xe4>
    1b74:	221000ef          	jal	ra,2594 <basename>
    1b78:	872a                	mv	a4,a0
    1b7a:	00001617          	auipc	a2,0x1
    1b7e:	b3e60613          	addi	a2,a2,-1218 # 26b8 <basename+0x124>
    1b82:	05400793          	li	a5,84
    1b86:	86a2                	mv	a3,s0
    1b88:	45fd                	li	a1,31
    1b8a:	00001517          	auipc	a0,0x1
    1b8e:	b3650513          	addi	a0,a0,-1226 # 26c0 <basename+0x12c>
    1b92:	8fbff0ef          	jal	ra,148c <printf>
    1b96:	557d                	li	a0,-1
    1b98:	d04ff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    1b9c:	4090                	lw	a2,0(s1)
    1b9e:	d651                	beqz	a2,1b2a <putchar+0x5e>
    1ba0:	b76d                	j	1b4a <putchar+0x7e>

0000000000001ba2 <puts>:
{
    1ba2:	7139                	addi	sp,sp,-64
    1ba4:	f822                	sd	s0,48(sp)
    1ba6:	f426                	sd	s1,40(sp)
    1ba8:	fc06                	sd	ra,56(sp)
    1baa:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1bac:	00001417          	auipc	s0,0x1
    1bb0:	bc440413          	addi	s0,s0,-1084 # 2770 <buffer_len>
{
    1bb4:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bb6:	638000ef          	jal	ra,21ee <strlen>
	if (buffer_lock_enabled == 1) {
    1bba:	10842703          	lw	a4,264(s0)
    1bbe:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bc0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bc2:	04f70563          	beq	a4,a5,1c0c <puts+0x6a>
		len = out_unlocked(s, l);
    1bc6:	8526                	mv	a0,s1
    1bc8:	d51ff0ef          	jal	ra,1918 <out_unlocked>
    1bcc:	892a                	mv	s2,a0
    1bce:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bd0:	00095963          	bgez	s2,1be2 <puts+0x40>
}
    1bd4:	70e2                	ld	ra,56(sp)
    1bd6:	7442                	ld	s0,48(sp)
    1bd8:	7902                	ld	s2,32(sp)
    1bda:	8526                	mv	a0,s1
    1bdc:	74a2                	ld	s1,40(sp)
    1bde:	6121                	addi	sp,sp,64
    1be0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1be2:	10842703          	lw	a4,264(s0)
	char byte = c;
    1be6:	44a9                	li	s1,10
    1be8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bec:	4785                	li	a5,1
    1bee:	02f70e63          	beq	a4,a5,1c2a <puts+0x88>
		len = out_unlocked(s, l);
    1bf2:	01f10513          	addi	a0,sp,31
    1bf6:	e2fff0ef          	jal	ra,1a24 <out_unlocked.constprop.0>
}
    1bfa:	70e2                	ld	ra,56(sp)
    1bfc:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bfe:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c02:	7902                	ld	s2,32(sp)
    1c04:	8526                	mv	a0,s1
    1c06:	74a2                	ld	s1,40(sp)
    1c08:	6121                	addi	sp,sp,64
    1c0a:	8082                	ret
		mutex_lock(buffer_lock);
    1c0c:	e42a                	sd	a0,8(sp)
    1c0e:	10c42503          	lw	a0,268(s0)
    1c12:	ec8ff0ef          	jal	ra,12da <mutex_lock>
		len = out_unlocked(s, l);
    1c16:	65a2                	ld	a1,8(sp)
    1c18:	8526                	mv	a0,s1
    1c1a:	cffff0ef          	jal	ra,1918 <out_unlocked>
    1c1e:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c20:	10c42503          	lw	a0,268(s0)
    1c24:	ec2ff0ef          	jal	ra,12e6 <mutex_unlock>
    1c28:	b75d                	j	1bce <puts+0x2c>
		mutex_lock(buffer_lock);
    1c2a:	10c42503          	lw	a0,268(s0)
    1c2e:	eacff0ef          	jal	ra,12da <mutex_lock>
		buffer[buffer_len++] = c;
    1c32:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c34:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c38:	0017861b          	addiw	a2,a5,1
    1c3c:	97a2                	add	a5,a5,s0
    1c3e:	c010                	sw	a2,0(s0)
    1c40:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c44:	06c6dc63          	bge	a3,a2,1cbc <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c48:	10000793          	li	a5,256
    1c4c:	02f61c63          	bne	a2,a5,1c84 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c50:	00001597          	auipc	a1,0x1
    1c54:	b2858593          	addi	a1,a1,-1240 # 2778 <buffer>
    1c58:	4505                	li	a0,1
    1c5a:	c08ff0ef          	jal	ra,1062 <write>
			if (r < 0) {
    1c5e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c60:	00001797          	auipc	a5,0x1
    1c64:	b007a823          	sw	zero,-1264(a5) # 2770 <buffer_len>
			if (r < 0) {
    1c68:	04054c63          	bltz	a0,1cc0 <puts+0x11e>
			if (r < buffer_len) {
    1c6c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c6e:	10c42503          	lw	a0,268(s0)
    1c72:	e74ff0ef          	jal	ra,12e6 <mutex_unlock>
}
    1c76:	70e2                	ld	ra,56(sp)
    1c78:	7442                	ld	s0,48(sp)
    1c7a:	7902                	ld	s2,32(sp)
    1c7c:	8526                	mv	a0,s1
    1c7e:	74a2                	ld	s1,40(sp)
    1c80:	6121                	addi	sp,sp,64
    1c82:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c84:	be8ff0ef          	jal	ra,106c <getpid>
    1c88:	84aa                	mv	s1,a0
    1c8a:	00001517          	auipc	a0,0x1
    1c8e:	9ee50513          	addi	a0,a0,-1554 # 2678 <basename+0xe4>
    1c92:	103000ef          	jal	ra,2594 <basename>
    1c96:	872a                	mv	a4,a0
    1c98:	00001617          	auipc	a2,0x1
    1c9c:	a2060613          	addi	a2,a2,-1504 # 26b8 <basename+0x124>
    1ca0:	05400793          	li	a5,84
    1ca4:	86a6                	mv	a3,s1
    1ca6:	45fd                	li	a1,31
    1ca8:	00001517          	auipc	a0,0x1
    1cac:	a1850513          	addi	a0,a0,-1512 # 26c0 <basename+0x12c>
    1cb0:	fdcff0ef          	jal	ra,148c <printf>
    1cb4:	557d                	li	a0,-1
    1cb6:	be6ff0ef          	jal	ra,109c <exit>
	if (buffer_len == 0)
    1cba:	4010                	lw	a2,0(s0)
    1cbc:	da45                	beqz	a2,1c6c <puts+0xca>
    1cbe:	bf49                	j	1c50 <puts+0xae>
    1cc0:	54fd                	li	s1,-1
    1cc2:	b775                	j	1c6e <puts+0xcc>

0000000000001cc4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cc4:	715d                	addi	sp,sp,-80
    1cc6:	e486                	sd	ra,72(sp)
    1cc8:	e0a2                	sd	s0,64(sp)
    1cca:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1ccc:	14054363          	bltz	a0,1e12 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1cd0:	02b577bb          	remuw	a5,a0,a1
    1cd4:	00001617          	auipc	a2,0x1
    1cd8:	bac60613          	addi	a2,a2,-1108 # 2880 <digits>
	buf[16] = 0;
    1cdc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ce0:	0005871b          	sext.w	a4,a1
    1ce4:	1782                	slli	a5,a5,0x20
    1ce6:	9381                	srli	a5,a5,0x20
    1ce8:	97b2                	add	a5,a5,a2
    1cea:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cee:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1cf2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1cf6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1cf8:	0eb56763          	bltu	a0,a1,1de6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1cfc:	02e877bb          	remuw	a5,a6,a4
    1d00:	1782                	slli	a5,a5,0x20
    1d02:	9381                	srli	a5,a5,0x20
    1d04:	97b2                	add	a5,a5,a2
    1d06:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d0a:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d0e:	02f10323          	sb	a5,38(sp)
    1d12:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d14:	0ce86963          	bltu	a6,a4,1de6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d18:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d1c:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d20:	1582                	slli	a1,a1,0x20
    1d22:	9181                	srli	a1,a1,0x20
    1d24:	95b2                	add	a1,a1,a2
    1d26:	0005c583          	lbu	a1,0(a1)
    1d2a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d2e:	0007859b          	sext.w	a1,a5
    1d32:	16e6e563          	bltu	a3,a4,1e9c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d36:	02e7f6bb          	remuw	a3,a5,a4
    1d3a:	1682                	slli	a3,a3,0x20
    1d3c:	9281                	srli	a3,a3,0x20
    1d3e:	96b2                	add	a3,a3,a2
    1d40:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d44:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d48:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d4c:	16e5e163          	bltu	a1,a4,1eae <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d50:	02e876bb          	remuw	a3,a6,a4
    1d54:	1682                	slli	a3,a3,0x20
    1d56:	9281                	srli	a3,a3,0x20
    1d58:	96b2                	add	a3,a3,a2
    1d5a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d5e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d62:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d66:	14e86d63          	bltu	a6,a4,1ec0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d6a:	02e5f6bb          	remuw	a3,a1,a4
    1d6e:	1682                	slli	a3,a3,0x20
    1d70:	9281                	srli	a3,a3,0x20
    1d72:	96b2                	add	a3,a3,a2
    1d74:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d78:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d7c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d80:	10e5e563          	bltu	a1,a4,1e8a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d84:	02e876bb          	remuw	a3,a6,a4
    1d88:	1682                	slli	a3,a3,0x20
    1d8a:	9281                	srli	a3,a3,0x20
    1d8c:	96b2                	add	a3,a3,a2
    1d8e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d92:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d96:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1d9a:	14e86263          	bltu	a6,a4,1ede <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1d9e:	02e5f6bb          	remuw	a3,a1,a4
    1da2:	1682                	slli	a3,a3,0x20
    1da4:	9281                	srli	a3,a3,0x20
    1da6:	96b2                	add	a3,a3,a2
    1da8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dac:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1db0:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1db4:	14e5e463          	bltu	a1,a4,1efc <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1db8:	02e876bb          	remuw	a3,a6,a4
    1dbc:	1682                	slli	a3,a3,0x20
    1dbe:	9281                	srli	a3,a3,0x20
    1dc0:	96b2                	add	a3,a3,a2
    1dc2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dc6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1dca:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1dce:	14e86063          	bltu	a6,a4,1f0e <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1dd2:	1782                	slli	a5,a5,0x20
    1dd4:	9381                	srli	a5,a5,0x20
    1dd6:	97b2                	add	a5,a5,a2
    1dd8:	0007c703          	lbu	a4,0(a5)
    1ddc:	4799                	li	a5,6
    1dde:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1de2:	10054763          	bltz	a0,1ef0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1de6:	00001497          	auipc	s1,0x1
    1dea:	98a48493          	addi	s1,s1,-1654 # 2770 <buffer_len>
    1dee:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1df2:	0828                	addi	a0,sp,24
    1df4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1df6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1df8:	00f50433          	add	s0,a0,a5
    1dfc:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1dfe:	06e68463          	beq	a3,a4,1e66 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e02:	8522                	mv	a0,s0
    1e04:	b15ff0ef          	jal	ra,1918 <out_unlocked>
}
    1e08:	60a6                	ld	ra,72(sp)
    1e0a:	6406                	ld	s0,64(sp)
    1e0c:	74e2                	ld	s1,56(sp)
    1e0e:	6161                	addi	sp,sp,80
    1e10:	8082                	ret
		x = -xx;
    1e12:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e16:	02b877bb          	remuw	a5,a6,a1
    1e1a:	00001617          	auipc	a2,0x1
    1e1e:	a6660613          	addi	a2,a2,-1434 # 2880 <digits>
	buf[16] = 0;
    1e22:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e26:	0005871b          	sext.w	a4,a1
    1e2a:	1782                	slli	a5,a5,0x20
    1e2c:	9381                	srli	a5,a5,0x20
    1e2e:	97b2                	add	a5,a5,a2
    1e30:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e34:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e38:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e3c:	08b86b63          	bltu	a6,a1,1ed2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e40:	02e8f7bb          	remuw	a5,a7,a4
    1e44:	1782                	slli	a5,a5,0x20
    1e46:	9381                	srli	a5,a5,0x20
    1e48:	97b2                	add	a5,a5,a2
    1e4a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e4e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e52:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e56:	ece8f1e3          	bgeu	a7,a4,1d18 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e5a:	02d00793          	li	a5,45
    1e5e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e62:	47b5                	li	a5,13
    1e64:	b749                	j	1de6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e66:	10c4a503          	lw	a0,268(s1)
    1e6a:	e42e                	sd	a1,8(sp)
    1e6c:	c6eff0ef          	jal	ra,12da <mutex_lock>
		len = out_unlocked(s, l);
    1e70:	65a2                	ld	a1,8(sp)
    1e72:	8522                	mv	a0,s0
    1e74:	aa5ff0ef          	jal	ra,1918 <out_unlocked>
		mutex_unlock(buffer_lock);
    1e78:	10c4a503          	lw	a0,268(s1)
    1e7c:	c6aff0ef          	jal	ra,12e6 <mutex_unlock>
}
    1e80:	60a6                	ld	ra,72(sp)
    1e82:	6406                	ld	s0,64(sp)
    1e84:	74e2                	ld	s1,56(sp)
    1e86:	6161                	addi	sp,sp,80
    1e88:	8082                	ret
		buf[i--] = digits[x % base];
    1e8a:	47a9                	li	a5,10
	if (sign)
    1e8c:	f4055de3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e90:	02d00793          	li	a5,45
    1e94:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e98:	47a5                	li	a5,9
    1e9a:	b7b1                	j	1de6 <printint.constprop.0+0x122>
    1e9c:	47b5                	li	a5,13
	if (sign)
    1e9e:	f40554e3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea2:	02d00793          	li	a5,45
    1ea6:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1eaa:	47b1                	li	a5,12
    1eac:	bf2d                	j	1de6 <printint.constprop.0+0x122>
    1eae:	47b1                	li	a5,12
	if (sign)
    1eb0:	f2055be3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb4:	02d00793          	li	a5,45
    1eb8:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ebc:	47ad                	li	a5,11
    1ebe:	b725                	j	1de6 <printint.constprop.0+0x122>
    1ec0:	47ad                	li	a5,11
	if (sign)
    1ec2:	f20552e3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ec6:	02d00793          	li	a5,45
    1eca:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ece:	47a9                	li	a5,10
    1ed0:	bf19                	j	1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed2:	02d00793          	li	a5,45
    1ed6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1eda:	47b9                	li	a5,14
    1edc:	b729                	j	1de6 <printint.constprop.0+0x122>
    1ede:	47a5                	li	a5,9
	if (sign)
    1ee0:	f00553e3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee4:	02d00793          	li	a5,45
    1ee8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1eec:	47a1                	li	a5,8
    1eee:	bde5                	j	1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef0:	02d00793          	li	a5,45
    1ef4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ef8:	4795                	li	a5,5
    1efa:	b5f5                	j	1de6 <printint.constprop.0+0x122>
    1efc:	47a1                	li	a5,8
	if (sign)
    1efe:	ee0554e3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f02:	02d00793          	li	a5,45
    1f06:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f0a:	479d                	li	a5,7
    1f0c:	bde9                	j	1de6 <printint.constprop.0+0x122>
    1f0e:	479d                	li	a5,7
	if (sign)
    1f10:	ec055be3          	bgez	a0,1de6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f14:	02d00793          	li	a5,45
    1f18:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f1c:	4799                	li	a5,6
    1f1e:	b5e1                	j	1de6 <printint.constprop.0+0x122>

0000000000001f20 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f20:	02000793          	li	a5,32
    1f24:	00f50663          	beq	a0,a5,1f30 <isspace+0x10>
    1f28:	355d                	addiw	a0,a0,-9
    1f2a:	00553513          	sltiu	a0,a0,5
    1f2e:	8082                	ret
    1f30:	4505                	li	a0,1
}
    1f32:	8082                	ret

0000000000001f34 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f34:	fd05051b          	addiw	a0,a0,-48
}
    1f38:	00a53513          	sltiu	a0,a0,10
    1f3c:	8082                	ret

0000000000001f3e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f3e:	02000613          	li	a2,32
    1f42:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f44:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f48:	ff77869b          	addiw	a3,a5,-9
    1f4c:	04c78c63          	beq	a5,a2,1fa4 <atoi+0x66>
    1f50:	0007871b          	sext.w	a4,a5
    1f54:	04d5f863          	bgeu	a1,a3,1fa4 <atoi+0x66>
		s++;
	switch (*s) {
    1f58:	02b00693          	li	a3,43
    1f5c:	04d78963          	beq	a5,a3,1fae <atoi+0x70>
    1f60:	02d00693          	li	a3,45
    1f64:	06d78263          	beq	a5,a3,1fc8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f68:	fd07061b          	addiw	a2,a4,-48
    1f6c:	47a5                	li	a5,9
    1f6e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f70:	4e01                	li	t3,0
	while (isdigit(*s))
    1f72:	04c7e963          	bltu	a5,a2,1fc4 <atoi+0x86>
	int n = 0, neg = 0;
    1f76:	4501                	li	a0,0
	while (isdigit(*s))
    1f78:	4825                	li	a6,9
    1f7a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f7e:	0025179b          	slliw	a5,a0,0x2
    1f82:	9fa9                	addw	a5,a5,a0
    1f84:	fd07031b          	addiw	t1,a4,-48
    1f88:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f8c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f90:	0685                	addi	a3,a3,1
    1f92:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f96:	0006071b          	sext.w	a4,a2
    1f9a:	feb870e3          	bgeu	a6,a1,1f7a <atoi+0x3c>
	return neg ? n : -n;
    1f9e:	000e0563          	beqz	t3,1fa8 <atoi+0x6a>
}
    1fa2:	8082                	ret
		s++;
    1fa4:	0505                	addi	a0,a0,1
    1fa6:	bf79                	j	1f44 <atoi+0x6>
	return neg ? n : -n;
    1fa8:	4113053b          	subw	a0,t1,a7
    1fac:	8082                	ret
	while (isdigit(*s))
    1fae:	00154703          	lbu	a4,1(a0)
    1fb2:	47a5                	li	a5,9
		s++;
    1fb4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fb8:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fbc:	4e01                	li	t3,0
	while (isdigit(*s))
    1fbe:	2701                	sext.w	a4,a4
    1fc0:	fac7fbe3          	bgeu	a5,a2,1f76 <atoi+0x38>
    1fc4:	4501                	li	a0,0
}
    1fc6:	8082                	ret
	while (isdigit(*s))
    1fc8:	00154703          	lbu	a4,1(a0)
    1fcc:	47a5                	li	a5,9
		s++;
    1fce:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fd2:	fd07061b          	addiw	a2,a4,-48
    1fd6:	2701                	sext.w	a4,a4
    1fd8:	fec7e6e3          	bltu	a5,a2,1fc4 <atoi+0x86>
		neg = 1;
    1fdc:	4e05                	li	t3,1
    1fde:	bf61                	j	1f76 <atoi+0x38>

0000000000001fe0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fe0:	16060d63          	beqz	a2,215a <memset+0x17a>
    1fe4:	40a007b3          	neg	a5,a0
    1fe8:	8b9d                	andi	a5,a5,7
    1fea:	00778693          	addi	a3,a5,7
    1fee:	482d                	li	a6,11
    1ff0:	0ff5f713          	zext.b	a4,a1
    1ff4:	fff60593          	addi	a1,a2,-1
    1ff8:	1706e263          	bltu	a3,a6,215c <memset+0x17c>
    1ffc:	16d5ea63          	bltu	a1,a3,2170 <memset+0x190>
    2000:	16078563          	beqz	a5,216a <memset+0x18a>
    2004:	00e50023          	sb	a4,0(a0)
    2008:	4685                	li	a3,1
    200a:	00150593          	addi	a1,a0,1
    200e:	14d78c63          	beq	a5,a3,2166 <memset+0x186>
    2012:	00e500a3          	sb	a4,1(a0)
    2016:	4689                	li	a3,2
    2018:	00250593          	addi	a1,a0,2
    201c:	14d78d63          	beq	a5,a3,2176 <memset+0x196>
    2020:	00e50123          	sb	a4,2(a0)
    2024:	468d                	li	a3,3
    2026:	00350593          	addi	a1,a0,3
    202a:	12d78b63          	beq	a5,a3,2160 <memset+0x180>
    202e:	00e501a3          	sb	a4,3(a0)
    2032:	4691                	li	a3,4
    2034:	00450593          	addi	a1,a0,4
    2038:	14d78163          	beq	a5,a3,217a <memset+0x19a>
    203c:	00e50223          	sb	a4,4(a0)
    2040:	4695                	li	a3,5
    2042:	00550593          	addi	a1,a0,5
    2046:	12d78c63          	beq	a5,a3,217e <memset+0x19e>
    204a:	00e502a3          	sb	a4,5(a0)
    204e:	469d                	li	a3,7
    2050:	00650593          	addi	a1,a0,6
    2054:	12d79763          	bne	a5,a3,2182 <memset+0x1a2>
    2058:	00750593          	addi	a1,a0,7
    205c:	00e50323          	sb	a4,6(a0)
    2060:	481d                	li	a6,7
    2062:	00871693          	slli	a3,a4,0x8
    2066:	01071893          	slli	a7,a4,0x10
    206a:	8ed9                	or	a3,a3,a4
    206c:	01871313          	slli	t1,a4,0x18
    2070:	0116e6b3          	or	a3,a3,a7
    2074:	0066e6b3          	or	a3,a3,t1
    2078:	02071893          	slli	a7,a4,0x20
    207c:	02871e13          	slli	t3,a4,0x28
    2080:	0116e6b3          	or	a3,a3,a7
    2084:	40f60333          	sub	t1,a2,a5
    2088:	03071893          	slli	a7,a4,0x30
    208c:	01c6e6b3          	or	a3,a3,t3
    2090:	0116e6b3          	or	a3,a3,a7
    2094:	03871e13          	slli	t3,a4,0x38
    2098:	97aa                	add	a5,a5,a0
    209a:	ff837893          	andi	a7,t1,-8
    209e:	01c6e6b3          	or	a3,a3,t3
    20a2:	98be                	add	a7,a7,a5
    20a4:	e394                	sd	a3,0(a5)
    20a6:	07a1                	addi	a5,a5,8
    20a8:	ff179ee3          	bne	a5,a7,20a4 <memset+0xc4>
    20ac:	ff837893          	andi	a7,t1,-8
    20b0:	011587b3          	add	a5,a1,a7
    20b4:	010886bb          	addw	a3,a7,a6
    20b8:	0b130663          	beq	t1,a7,2164 <memset+0x184>
    20bc:	00e78023          	sb	a4,0(a5)
    20c0:	0016859b          	addiw	a1,a3,1
    20c4:	08c5fb63          	bgeu	a1,a2,215a <memset+0x17a>
    20c8:	00e780a3          	sb	a4,1(a5)
    20cc:	0026859b          	addiw	a1,a3,2
    20d0:	08c5f563          	bgeu	a1,a2,215a <memset+0x17a>
    20d4:	00e78123          	sb	a4,2(a5)
    20d8:	0036859b          	addiw	a1,a3,3
    20dc:	06c5ff63          	bgeu	a1,a2,215a <memset+0x17a>
    20e0:	00e781a3          	sb	a4,3(a5)
    20e4:	0046859b          	addiw	a1,a3,4
    20e8:	06c5f963          	bgeu	a1,a2,215a <memset+0x17a>
    20ec:	00e78223          	sb	a4,4(a5)
    20f0:	0056859b          	addiw	a1,a3,5
    20f4:	06c5f363          	bgeu	a1,a2,215a <memset+0x17a>
    20f8:	00e782a3          	sb	a4,5(a5)
    20fc:	0066859b          	addiw	a1,a3,6
    2100:	04c5fd63          	bgeu	a1,a2,215a <memset+0x17a>
    2104:	00e78323          	sb	a4,6(a5)
    2108:	0076859b          	addiw	a1,a3,7
    210c:	04c5f763          	bgeu	a1,a2,215a <memset+0x17a>
    2110:	00e783a3          	sb	a4,7(a5)
    2114:	0086859b          	addiw	a1,a3,8
    2118:	04c5f163          	bgeu	a1,a2,215a <memset+0x17a>
    211c:	00e78423          	sb	a4,8(a5)
    2120:	0096859b          	addiw	a1,a3,9
    2124:	02c5fb63          	bgeu	a1,a2,215a <memset+0x17a>
    2128:	00e784a3          	sb	a4,9(a5)
    212c:	00a6859b          	addiw	a1,a3,10
    2130:	02c5f563          	bgeu	a1,a2,215a <memset+0x17a>
    2134:	00e78523          	sb	a4,10(a5)
    2138:	00b6859b          	addiw	a1,a3,11
    213c:	00c5ff63          	bgeu	a1,a2,215a <memset+0x17a>
    2140:	00e785a3          	sb	a4,11(a5)
    2144:	00c6859b          	addiw	a1,a3,12
    2148:	00c5f963          	bgeu	a1,a2,215a <memset+0x17a>
    214c:	00e78623          	sb	a4,12(a5)
    2150:	26b5                	addiw	a3,a3,13
    2152:	00c6f463          	bgeu	a3,a2,215a <memset+0x17a>
    2156:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    215a:	8082                	ret
    215c:	46ad                	li	a3,11
    215e:	bd79                	j	1ffc <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2160:	480d                	li	a6,3
    2162:	b701                	j	2062 <memset+0x82>
    2164:	8082                	ret
    2166:	4805                	li	a6,1
    2168:	bded                	j	2062 <memset+0x82>
    216a:	85aa                	mv	a1,a0
    216c:	4801                	li	a6,0
    216e:	bdd5                	j	2062 <memset+0x82>
    2170:	87aa                	mv	a5,a0
    2172:	4681                	li	a3,0
    2174:	b7a1                	j	20bc <memset+0xdc>
    2176:	4809                	li	a6,2
    2178:	b5ed                	j	2062 <memset+0x82>
    217a:	4811                	li	a6,4
    217c:	b5dd                	j	2062 <memset+0x82>
    217e:	4815                	li	a6,5
    2180:	b5cd                	j	2062 <memset+0x82>
    2182:	4819                	li	a6,6
    2184:	bdf9                	j	2062 <memset+0x82>

0000000000002186 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2186:	00054783          	lbu	a5,0(a0)
    218a:	0005c703          	lbu	a4,0(a1)
    218e:	00e79863          	bne	a5,a4,219e <strcmp+0x18>
    2192:	0505                	addi	a0,a0,1
    2194:	0585                	addi	a1,a1,1
    2196:	fbe5                	bnez	a5,2186 <strcmp>
    2198:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    219a:	9d19                	subw	a0,a0,a4
    219c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    219e:	0007851b          	sext.w	a0,a5
    21a2:	bfe5                	j	219a <strcmp+0x14>

00000000000021a4 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21a4:	ca15                	beqz	a2,21d8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21a6:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21aa:	167d                	addi	a2,a2,-1
    21ac:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21b0:	eb99                	bnez	a5,21c6 <strncmp+0x22>
    21b2:	a815                	j	21e6 <strncmp+0x42>
    21b4:	00a68e63          	beq	a3,a0,21d0 <strncmp+0x2c>
    21b8:	0505                	addi	a0,a0,1
    21ba:	00f71b63          	bne	a4,a5,21d0 <strncmp+0x2c>
    21be:	00054783          	lbu	a5,0(a0)
    21c2:	cf89                	beqz	a5,21dc <strncmp+0x38>
    21c4:	85b2                	mv	a1,a2
    21c6:	0005c703          	lbu	a4,0(a1)
    21ca:	00158613          	addi	a2,a1,1
    21ce:	f37d                	bnez	a4,21b4 <strncmp+0x10>
		;
	return *l - *r;
    21d0:	0007851b          	sext.w	a0,a5
    21d4:	9d19                	subw	a0,a0,a4
    21d6:	8082                	ret
		return 0;
    21d8:	4501                	li	a0,0
}
    21da:	8082                	ret
	return *l - *r;
    21dc:	0015c703          	lbu	a4,1(a1)
    21e0:	4501                	li	a0,0
    21e2:	9d19                	subw	a0,a0,a4
    21e4:	8082                	ret
    21e6:	0005c703          	lbu	a4,0(a1)
    21ea:	4501                	li	a0,0
    21ec:	b7e5                	j	21d4 <strncmp+0x30>

00000000000021ee <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21ee:	00757793          	andi	a5,a0,7
    21f2:	cf89                	beqz	a5,220c <strlen+0x1e>
    21f4:	87aa                	mv	a5,a0
    21f6:	a029                	j	2200 <strlen+0x12>
    21f8:	0785                	addi	a5,a5,1
    21fa:	0077f713          	andi	a4,a5,7
    21fe:	cb01                	beqz	a4,220e <strlen+0x20>
		if (!*s)
    2200:	0007c703          	lbu	a4,0(a5)
    2204:	fb75                	bnez	a4,21f8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2206:	40a78533          	sub	a0,a5,a0
}
    220a:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    220c:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    220e:	6394                	ld	a3,0(a5)
    2210:	00000597          	auipc	a1,0x0
    2214:	5485b583          	ld	a1,1352(a1) # 2758 <basename+0x1c4>
    2218:	00000617          	auipc	a2,0x0
    221c:	54863603          	ld	a2,1352(a2) # 2760 <basename+0x1cc>
    2220:	a019                	j	2226 <strlen+0x38>
    2222:	6794                	ld	a3,8(a5)
    2224:	07a1                	addi	a5,a5,8
    2226:	00b68733          	add	a4,a3,a1
    222a:	fff6c693          	not	a3,a3
    222e:	8f75                	and	a4,a4,a3
    2230:	8f71                	and	a4,a4,a2
    2232:	db65                	beqz	a4,2222 <strlen+0x34>
	for (; *s; s++)
    2234:	0007c703          	lbu	a4,0(a5)
    2238:	d779                	beqz	a4,2206 <strlen+0x18>
    223a:	0017c703          	lbu	a4,1(a5)
    223e:	0785                	addi	a5,a5,1
    2240:	d379                	beqz	a4,2206 <strlen+0x18>
    2242:	0017c703          	lbu	a4,1(a5)
    2246:	0785                	addi	a5,a5,1
    2248:	fb6d                	bnez	a4,223a <strlen+0x4c>
    224a:	bf75                	j	2206 <strlen+0x18>

000000000000224c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    224c:	00757713          	andi	a4,a0,7
{
    2250:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2252:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2256:	cb19                	beqz	a4,226c <memchr+0x20>
    2258:	ce25                	beqz	a2,22d0 <memchr+0x84>
    225a:	0007c703          	lbu	a4,0(a5)
    225e:	04b70e63          	beq	a4,a1,22ba <memchr+0x6e>
    2262:	0785                	addi	a5,a5,1
    2264:	0077f713          	andi	a4,a5,7
    2268:	167d                	addi	a2,a2,-1
    226a:	f77d                	bnez	a4,2258 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    226c:	4501                	li	a0,0
	if (n && *s != c) {
    226e:	c235                	beqz	a2,22d2 <memchr+0x86>
    2270:	0007c703          	lbu	a4,0(a5)
    2274:	04b70363          	beq	a4,a1,22ba <memchr+0x6e>
		size_t k = ONES * c;
    2278:	00000517          	auipc	a0,0x0
    227c:	4f053503          	ld	a0,1264(a0) # 2768 <basename+0x1d4>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2280:	471d                	li	a4,7
		size_t k = ONES * c;
    2282:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2286:	02c77a63          	bgeu	a4,a2,22ba <memchr+0x6e>
    228a:	00000897          	auipc	a7,0x0
    228e:	4ce8b883          	ld	a7,1230(a7) # 2758 <basename+0x1c4>
    2292:	00000817          	auipc	a6,0x0
    2296:	4ce83803          	ld	a6,1230(a6) # 2760 <basename+0x1cc>
    229a:	431d                	li	t1,7
    229c:	a029                	j	22a6 <memchr+0x5a>
		     w++, n -= SS)
    229e:	1661                	addi	a2,a2,-8
    22a0:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22a2:	02c37963          	bgeu	t1,a2,22d4 <memchr+0x88>
    22a6:	6398                	ld	a4,0(a5)
    22a8:	8f29                	xor	a4,a4,a0
    22aa:	011706b3          	add	a3,a4,a7
    22ae:	fff74713          	not	a4,a4
    22b2:	8f75                	and	a4,a4,a3
    22b4:	01077733          	and	a4,a4,a6
    22b8:	d37d                	beqz	a4,229e <memchr+0x52>
{
    22ba:	853e                	mv	a0,a5
    22bc:	97b2                	add	a5,a5,a2
    22be:	a021                	j	22c6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22c0:	0505                	addi	a0,a0,1
    22c2:	00f50763          	beq	a0,a5,22d0 <memchr+0x84>
    22c6:	00054703          	lbu	a4,0(a0)
    22ca:	feb71be3          	bne	a4,a1,22c0 <memchr+0x74>
    22ce:	8082                	ret
	return n ? (void *)s : 0;
    22d0:	4501                	li	a0,0
}
    22d2:	8082                	ret
	return n ? (void *)s : 0;
    22d4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22d6:	f275                	bnez	a2,22ba <memchr+0x6e>
}
    22d8:	8082                	ret

00000000000022da <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22da:	1101                	addi	sp,sp,-32
    22dc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22de:	862e                	mv	a2,a1
{
    22e0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22e2:	4581                	li	a1,0
{
    22e4:	e426                	sd	s1,8(sp)
    22e6:	ec06                	sd	ra,24(sp)
    22e8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22ea:	f63ff0ef          	jal	ra,224c <memchr>
	return p ? p - s : n;
    22ee:	c519                	beqz	a0,22fc <strnlen+0x22>
}
    22f0:	60e2                	ld	ra,24(sp)
    22f2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22f4:	8d05                	sub	a0,a0,s1
}
    22f6:	64a2                	ld	s1,8(sp)
    22f8:	6105                	addi	sp,sp,32
    22fa:	8082                	ret
    22fc:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    22fe:	8522                	mv	a0,s0
}
    2300:	6442                	ld	s0,16(sp)
    2302:	64a2                	ld	s1,8(sp)
    2304:	6105                	addi	sp,sp,32
    2306:	8082                	ret

0000000000002308 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2308:	00a5c7b3          	xor	a5,a1,a0
    230c:	8b9d                	andi	a5,a5,7
    230e:	eb95                	bnez	a5,2342 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2310:	0075f793          	andi	a5,a1,7
    2314:	e7b1                	bnez	a5,2360 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2316:	6198                	ld	a4,0(a1)
    2318:	00000617          	auipc	a2,0x0
    231c:	44063603          	ld	a2,1088(a2) # 2758 <basename+0x1c4>
    2320:	00000817          	auipc	a6,0x0
    2324:	44083803          	ld	a6,1088(a6) # 2760 <basename+0x1cc>
    2328:	a029                	j	2332 <stpcpy+0x2a>
    232a:	05a1                	addi	a1,a1,8
    232c:	e118                	sd	a4,0(a0)
    232e:	6198                	ld	a4,0(a1)
    2330:	0521                	addi	a0,a0,8
    2332:	00c707b3          	add	a5,a4,a2
    2336:	fff74693          	not	a3,a4
    233a:	8ff5                	and	a5,a5,a3
    233c:	0107f7b3          	and	a5,a5,a6
    2340:	d7ed                	beqz	a5,232a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2342:	0005c783          	lbu	a5,0(a1)
    2346:	00f50023          	sb	a5,0(a0)
    234a:	c785                	beqz	a5,2372 <stpcpy+0x6a>
    234c:	0015c783          	lbu	a5,1(a1)
    2350:	0505                	addi	a0,a0,1
    2352:	0585                	addi	a1,a1,1
    2354:	00f50023          	sb	a5,0(a0)
    2358:	fbf5                	bnez	a5,234c <stpcpy+0x44>
		;
	return d;
}
    235a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    235c:	0505                	addi	a0,a0,1
    235e:	df45                	beqz	a4,2316 <stpcpy+0xe>
			if (!(*d = *s))
    2360:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2364:	0585                	addi	a1,a1,1
    2366:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    236a:	00f50023          	sb	a5,0(a0)
    236e:	f7fd                	bnez	a5,235c <stpcpy+0x54>
}
    2370:	8082                	ret
    2372:	8082                	ret

0000000000002374 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2374:	00a5c7b3          	xor	a5,a1,a0
    2378:	8b9d                	andi	a5,a5,7
    237a:	1a079863          	bnez	a5,252a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    237e:	0075f793          	andi	a5,a1,7
    2382:	16078463          	beqz	a5,24ea <stpncpy+0x176>
    2386:	ea01                	bnez	a2,2396 <stpncpy+0x22>
    2388:	a421                	j	2590 <stpncpy+0x21c>
    238a:	167d                	addi	a2,a2,-1
    238c:	0505                	addi	a0,a0,1
    238e:	14070e63          	beqz	a4,24ea <stpncpy+0x176>
    2392:	1a060863          	beqz	a2,2542 <stpncpy+0x1ce>
    2396:	0005c783          	lbu	a5,0(a1)
    239a:	0585                	addi	a1,a1,1
    239c:	0075f713          	andi	a4,a1,7
    23a0:	00f50023          	sb	a5,0(a0)
    23a4:	f3fd                	bnez	a5,238a <stpncpy+0x16>
    23a6:	4805                	li	a6,1
    23a8:	1a061863          	bnez	a2,2558 <stpncpy+0x1e4>
    23ac:	40a007b3          	neg	a5,a0
    23b0:	8b9d                	andi	a5,a5,7
    23b2:	4681                	li	a3,0
    23b4:	18061a63          	bnez	a2,2548 <stpncpy+0x1d4>
    23b8:	00778713          	addi	a4,a5,7
    23bc:	45ad                	li	a1,11
    23be:	18b76363          	bltu	a4,a1,2544 <stpncpy+0x1d0>
    23c2:	1ae6eb63          	bltu	a3,a4,2578 <stpncpy+0x204>
    23c6:	1a078363          	beqz	a5,256c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23ca:	00050023          	sb	zero,0(a0)
    23ce:	4685                	li	a3,1
    23d0:	00150713          	addi	a4,a0,1
    23d4:	18d78f63          	beq	a5,a3,2572 <stpncpy+0x1fe>
    23d8:	000500a3          	sb	zero,1(a0)
    23dc:	4689                	li	a3,2
    23de:	00250713          	addi	a4,a0,2
    23e2:	18d78e63          	beq	a5,a3,257e <stpncpy+0x20a>
    23e6:	00050123          	sb	zero,2(a0)
    23ea:	468d                	li	a3,3
    23ec:	00350713          	addi	a4,a0,3
    23f0:	16d78c63          	beq	a5,a3,2568 <stpncpy+0x1f4>
    23f4:	000501a3          	sb	zero,3(a0)
    23f8:	4691                	li	a3,4
    23fa:	00450713          	addi	a4,a0,4
    23fe:	18d78263          	beq	a5,a3,2582 <stpncpy+0x20e>
    2402:	00050223          	sb	zero,4(a0)
    2406:	4695                	li	a3,5
    2408:	00550713          	addi	a4,a0,5
    240c:	16d78d63          	beq	a5,a3,2586 <stpncpy+0x212>
    2410:	000502a3          	sb	zero,5(a0)
    2414:	469d                	li	a3,7
    2416:	00650713          	addi	a4,a0,6
    241a:	16d79863          	bne	a5,a3,258a <stpncpy+0x216>
    241e:	00750713          	addi	a4,a0,7
    2422:	00050323          	sb	zero,6(a0)
    2426:	40f80833          	sub	a6,a6,a5
    242a:	ff887593          	andi	a1,a6,-8
    242e:	97aa                	add	a5,a5,a0
    2430:	95be                	add	a1,a1,a5
    2432:	0007b023          	sd	zero,0(a5)
    2436:	07a1                	addi	a5,a5,8
    2438:	feb79de3          	bne	a5,a1,2432 <stpncpy+0xbe>
    243c:	ff887593          	andi	a1,a6,-8
    2440:	9ead                	addw	a3,a3,a1
    2442:	00b707b3          	add	a5,a4,a1
    2446:	12b80863          	beq	a6,a1,2576 <stpncpy+0x202>
    244a:	00078023          	sb	zero,0(a5)
    244e:	0016871b          	addiw	a4,a3,1
    2452:	0ec77863          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    2456:	000780a3          	sb	zero,1(a5)
    245a:	0026871b          	addiw	a4,a3,2
    245e:	0ec77263          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    2462:	00078123          	sb	zero,2(a5)
    2466:	0036871b          	addiw	a4,a3,3
    246a:	0cc77c63          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    246e:	000781a3          	sb	zero,3(a5)
    2472:	0046871b          	addiw	a4,a3,4
    2476:	0cc77663          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    247a:	00078223          	sb	zero,4(a5)
    247e:	0056871b          	addiw	a4,a3,5
    2482:	0cc77063          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    2486:	000782a3          	sb	zero,5(a5)
    248a:	0066871b          	addiw	a4,a3,6
    248e:	0ac77a63          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    2492:	00078323          	sb	zero,6(a5)
    2496:	0076871b          	addiw	a4,a3,7
    249a:	0ac77463          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    249e:	000783a3          	sb	zero,7(a5)
    24a2:	0086871b          	addiw	a4,a3,8
    24a6:	08c77e63          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    24aa:	00078423          	sb	zero,8(a5)
    24ae:	0096871b          	addiw	a4,a3,9
    24b2:	08c77863          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    24b6:	000784a3          	sb	zero,9(a5)
    24ba:	00a6871b          	addiw	a4,a3,10
    24be:	08c77263          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    24c2:	00078523          	sb	zero,10(a5)
    24c6:	00b6871b          	addiw	a4,a3,11
    24ca:	06c77c63          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    24ce:	000785a3          	sb	zero,11(a5)
    24d2:	00c6871b          	addiw	a4,a3,12
    24d6:	06c77663          	bgeu	a4,a2,2542 <stpncpy+0x1ce>
    24da:	00078623          	sb	zero,12(a5)
    24de:	26b5                	addiw	a3,a3,13
    24e0:	06c6f163          	bgeu	a3,a2,2542 <stpncpy+0x1ce>
    24e4:	000786a3          	sb	zero,13(a5)
    24e8:	8082                	ret
			;
		if (!n || !*s)
    24ea:	c645                	beqz	a2,2592 <stpncpy+0x21e>
    24ec:	0005c783          	lbu	a5,0(a1)
    24f0:	ea078be3          	beqz	a5,23a6 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24f4:	479d                	li	a5,7
    24f6:	02c7ff63          	bgeu	a5,a2,2534 <stpncpy+0x1c0>
    24fa:	00000897          	auipc	a7,0x0
    24fe:	25e8b883          	ld	a7,606(a7) # 2758 <basename+0x1c4>
    2502:	00000817          	auipc	a6,0x0
    2506:	25e83803          	ld	a6,606(a6) # 2760 <basename+0x1cc>
    250a:	431d                	li	t1,7
    250c:	6198                	ld	a4,0(a1)
    250e:	011707b3          	add	a5,a4,a7
    2512:	fff74693          	not	a3,a4
    2516:	8ff5                	and	a5,a5,a3
    2518:	0107f7b3          	and	a5,a5,a6
    251c:	ef81                	bnez	a5,2534 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    251e:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2520:	1661                	addi	a2,a2,-8
    2522:	05a1                	addi	a1,a1,8
    2524:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2526:	fec363e3          	bltu	t1,a2,250c <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    252a:	e609                	bnez	a2,2534 <stpncpy+0x1c0>
    252c:	a08d                	j	258e <stpncpy+0x21a>
    252e:	167d                	addi	a2,a2,-1
    2530:	0505                	addi	a0,a0,1
    2532:	ca01                	beqz	a2,2542 <stpncpy+0x1ce>
    2534:	0005c783          	lbu	a5,0(a1)
    2538:	0585                	addi	a1,a1,1
    253a:	00f50023          	sb	a5,0(a0)
    253e:	fbe5                	bnez	a5,252e <stpncpy+0x1ba>
		;
tail:
    2540:	b59d                	j	23a6 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2542:	8082                	ret
    2544:	472d                	li	a4,11
    2546:	bdb5                	j	23c2 <stpncpy+0x4e>
    2548:	00778713          	addi	a4,a5,7
    254c:	45ad                	li	a1,11
    254e:	fff60693          	addi	a3,a2,-1
    2552:	e6b778e3          	bgeu	a4,a1,23c2 <stpncpy+0x4e>
    2556:	b7fd                	j	2544 <stpncpy+0x1d0>
    2558:	40a007b3          	neg	a5,a0
    255c:	8832                	mv	a6,a2
    255e:	8b9d                	andi	a5,a5,7
    2560:	4681                	li	a3,0
    2562:	e4060be3          	beqz	a2,23b8 <stpncpy+0x44>
    2566:	b7cd                	j	2548 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2568:	468d                	li	a3,3
    256a:	bd75                	j	2426 <stpncpy+0xb2>
    256c:	872a                	mv	a4,a0
    256e:	4681                	li	a3,0
    2570:	bd5d                	j	2426 <stpncpy+0xb2>
    2572:	4685                	li	a3,1
    2574:	bd4d                	j	2426 <stpncpy+0xb2>
    2576:	8082                	ret
    2578:	87aa                	mv	a5,a0
    257a:	4681                	li	a3,0
    257c:	b5f9                	j	244a <stpncpy+0xd6>
    257e:	4689                	li	a3,2
    2580:	b55d                	j	2426 <stpncpy+0xb2>
    2582:	4691                	li	a3,4
    2584:	b54d                	j	2426 <stpncpy+0xb2>
    2586:	4695                	li	a3,5
    2588:	bd79                	j	2426 <stpncpy+0xb2>
    258a:	4699                	li	a3,6
    258c:	bd69                	j	2426 <stpncpy+0xb2>
    258e:	8082                	ret
    2590:	8082                	ret
    2592:	8082                	ret

0000000000002594 <basename>:

char *basename(char *s)
{
    2594:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2596:	c54d                	beqz	a0,2640 <basename+0xac>
    2598:	00054783          	lbu	a5,0(a0)
		return ".";
    259c:	00000517          	auipc	a0,0x0
    25a0:	1b450513          	addi	a0,a0,436 # 2750 <basename+0x1bc>
	if (!s || !*s)
    25a4:	e391                	bnez	a5,25a8 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25a6:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25a8:	0076f713          	andi	a4,a3,7
    25ac:	87b6                	mv	a5,a3
    25ae:	cf51                	beqz	a4,264a <basename+0xb6>
    25b0:	0785                	addi	a5,a5,1
    25b2:	0077f713          	andi	a4,a5,7
    25b6:	c729                	beqz	a4,2600 <basename+0x6c>
		if (!*s)
    25b8:	0007c703          	lbu	a4,0(a5)
    25bc:	fb75                	bnez	a4,25b0 <basename+0x1c>
	return s - a;
    25be:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25c0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25c2:	cf8d                	beqz	a5,25fc <basename+0x68>
    25c4:	00f68733          	add	a4,a3,a5
    25c8:	02f00593          	li	a1,47
    25cc:	a031                	j	25d8 <basename+0x44>
		s[i] = 0;
    25ce:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25d2:	17fd                	addi	a5,a5,-1
    25d4:	177d                	addi	a4,a4,-1
    25d6:	c39d                	beqz	a5,25fc <basename+0x68>
    25d8:	00074603          	lbu	a2,0(a4)
    25dc:	feb609e3          	beq	a2,a1,25ce <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25e0:	02f00613          	li	a2,47
    25e4:	a011                	j	25e8 <basename+0x54>
    25e6:	cb99                	beqz	a5,25fc <basename+0x68>
    25e8:	853e                	mv	a0,a5
    25ea:	17fd                	addi	a5,a5,-1
    25ec:	00f68733          	add	a4,a3,a5
    25f0:	00074703          	lbu	a4,0(a4)
    25f4:	fec719e3          	bne	a4,a2,25e6 <basename+0x52>
	return s + i;
    25f8:	9536                	add	a0,a0,a3
    25fa:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    25fc:	8536                	mv	a0,a3
    25fe:	8082                	ret
    2600:	6390                	ld	a2,0(a5)
    2602:	00000517          	auipc	a0,0x0
    2606:	15653503          	ld	a0,342(a0) # 2758 <basename+0x1c4>
    260a:	00000597          	auipc	a1,0x0
    260e:	1565b583          	ld	a1,342(a1) # 2760 <basename+0x1cc>
    2612:	fff64713          	not	a4,a2
    2616:	962a                	add	a2,a2,a0
    2618:	8f71                	and	a4,a4,a2
    261a:	8f6d                	and	a4,a4,a1
    261c:	eb11                	bnez	a4,2630 <basename+0x9c>
    261e:	6790                	ld	a2,8(a5)
    2620:	07a1                	addi	a5,a5,8
    2622:	00a60733          	add	a4,a2,a0
    2626:	fff64613          	not	a2,a2
    262a:	8f71                	and	a4,a4,a2
    262c:	8f6d                	and	a4,a4,a1
    262e:	db65                	beqz	a4,261e <basename+0x8a>
	for (; *s; s++)
    2630:	0007c703          	lbu	a4,0(a5)
    2634:	d749                	beqz	a4,25be <basename+0x2a>
    2636:	0017c703          	lbu	a4,1(a5)
    263a:	0785                	addi	a5,a5,1
    263c:	ff6d                	bnez	a4,2636 <basename+0xa2>
    263e:	b741                	j	25be <basename+0x2a>
		return ".";
    2640:	00000517          	auipc	a0,0x0
    2644:	11050513          	addi	a0,a0,272 # 2750 <basename+0x1bc>
    2648:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    264a:	6290                	ld	a2,0(a3)
    264c:	00000517          	auipc	a0,0x0
    2650:	10c53503          	ld	a0,268(a0) # 2758 <basename+0x1c4>
    2654:	00000597          	auipc	a1,0x0
    2658:	10c5b583          	ld	a1,268(a1) # 2760 <basename+0x1cc>
    265c:	fff64713          	not	a4,a2
    2660:	962a                	add	a2,a2,a0
    2662:	8f71                	and	a4,a4,a2
    2664:	8f6d                	and	a4,a4,a1
    2666:	df45                	beqz	a4,261e <basename+0x8a>
    2668:	b7f9                	j	2636 <basename+0xa2>
