
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch4_mmap1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a061                	j	1088 <__start_main>

0000000000001002 <main>:
/*
理想结果：程序触发访存异常，被杀死。不输出 error 就算过。
*/

int main()
{
    1002:	1101                	addi	sp,sp,-32
	uint64 start = 0x10000000;
	uint64 len = 4096;
	int prot = 1;
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1004:	577d                	li	a4,-1
    1006:	4681                	li	a3,0
    1008:	4605                	li	a2,1
    100a:	6585                	lui	a1,0x1
    100c:	10000537          	lui	a0,0x10000
{
    1010:	ec06                	sd	ra,24(sp)
    1012:	e822                	sd	s0,16(sp)
    1014:	e426                	sd	s1,8(sp)
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1016:	52c010ef          	jal	ra,2542 <mmap>
    101a:	e10d                	bnez	a0,103c <main+0x3a>
	uint8 *addr = (uint8 *)start;
	*addr = (uint8)start;
    101c:	100007b7          	lui	a5,0x10000
    1020:	00078023          	sb	zero,0(a5) # 10000000 <.got.plt+0xfffd630>
	puts("Should cause error, Test 04_1 fail!");
    1024:	00001517          	auipc	a0,0x1
    1028:	75450513          	addi	a0,a0,1876 # 2778 <enable_deadlock_detect+0x96>
    102c:	0cd000ef          	jal	ra,18f8 <puts>
	return 0;
    1030:	60e2                	ld	ra,24(sp)
    1032:	6442                	ld	s0,16(sp)
    1034:	64a2                	ld	s1,8(sp)
    1036:	4501                	li	a0,0
    1038:	6105                	addi	sp,sp,32
    103a:	8082                	ret
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    103c:	3d8010ef          	jal	ra,2414 <getpid>
    1040:	842a                	mv	s0,a0
    1042:	00001517          	auipc	a0,0x1
    1046:	6ae50513          	addi	a0,a0,1710 # 26f0 <enable_deadlock_detect+0xe>
    104a:	2a0010ef          	jal	ra,22ea <basename>
    104e:	84aa                	mv	s1,a0
    1050:	577d                	li	a4,-1
    1052:	4681                	li	a3,0
    1054:	4605                	li	a2,1
    1056:	6585                	lui	a1,0x1
    1058:	10000537          	lui	a0,0x10000
    105c:	4e6010ef          	jal	ra,2542 <mmap>
    1060:	88aa                	mv	a7,a0
    1062:	4801                	li	a6,0
    1064:	00001517          	auipc	a0,0x1
    1068:	6dc50513          	addi	a0,a0,1756 # 2740 <enable_deadlock_detect+0x5e>
    106c:	47bd                	li	a5,15
    106e:	8726                	mv	a4,s1
    1070:	86a2                	mv	a3,s0
    1072:	00001617          	auipc	a2,0x1
    1076:	6c660613          	addi	a2,a2,1734 # 2738 <enable_deadlock_detect+0x56>
    107a:	45fd                	li	a1,31
    107c:	166000ef          	jal	ra,11e2 <printf>
    1080:	557d                	li	a0,-1
    1082:	3c2010ef          	jal	ra,2444 <exit>
    1086:	bf59                	j	101c <main+0x1a>

0000000000001088 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1088:	1141                	addi	sp,sp,-16
    108a:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    108c:	f77ff0ef          	jal	ra,1002 <main>
    1090:	3b4010ef          	jal	ra,2444 <exit>
	return 0;
    1094:	60a2                	ld	ra,8(sp)
    1096:	4501                	li	a0,0
    1098:	0141                	addi	sp,sp,16
    109a:	8082                	ret

000000000000109c <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    109c:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    109e:	4605                	li	a2,1
    10a0:	00f10593          	addi	a1,sp,15
    10a4:	4501                	li	a0,0
{
    10a6:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10a8:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10ac:	354010ef          	jal	ra,2400 <read>
    10b0:	4785                	li	a5,1
    10b2:	00f51763          	bne	a0,a5,10c0 <getchar+0x24>
		return byte;
    10b6:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10ba:	60e2                	ld	ra,24(sp)
    10bc:	6105                	addi	sp,sp,32
    10be:	8082                	ret
		return EOF;
    10c0:	557d                	li	a0,-1
    10c2:	bfe5                	j	10ba <getchar+0x1e>

00000000000010c4 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10c4:	00001517          	auipc	a0,0x1
    10c8:	7d452503          	lw	a0,2004(a0) # 2898 <buffer_len>
    10cc:	e111                	bnez	a0,10d0 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10ce:	8082                	ret
{
    10d0:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10d2:	862a                	mv	a2,a0
    10d4:	00001597          	auipc	a1,0x1
    10d8:	7cc58593          	addi	a1,a1,1996 # 28a0 <buffer>
    10dc:	4505                	li	a0,1
{
    10de:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10e0:	32a010ef          	jal	ra,240a <write>
}
    10e4:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10e6:	2501                	sext.w	a0,a0
}
    10e8:	0141                	addi	sp,sp,16
    10ea:	8082                	ret

00000000000010ec <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10ec:	00001797          	auipc	a5,0x1
    10f0:	7a07a623          	sw	zero,1964(a5) # 2898 <buffer_len>
}
    10f4:	8082                	ret

00000000000010f6 <__fflush>:
	if (buffer_len == 0)
    10f6:	00001517          	auipc	a0,0x1
    10fa:	7a252503          	lw	a0,1954(a0) # 2898 <buffer_len>
    10fe:	e511                	bnez	a0,110a <__fflush+0x14>
	buffer_len = 0;
    1100:	00001797          	auipc	a5,0x1
    1104:	7807ac23          	sw	zero,1944(a5) # 2898 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1108:	8082                	ret
{
    110a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    110c:	862a                	mv	a2,a0
    110e:	00001597          	auipc	a1,0x1
    1112:	79258593          	addi	a1,a1,1938 # 28a0 <buffer>
    1116:	4505                	li	a0,1
{
    1118:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    111a:	2f0010ef          	jal	ra,240a <write>
	return r >= 0 ? 0 : r;
    111e:	0005079b          	sext.w	a5,a0
}
    1122:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1124:	0017a793          	slti	a5,a5,1
    1128:	40f007bb          	negw	a5,a5
    112c:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    112e:	00001797          	auipc	a5,0x1
    1132:	7607a523          	sw	zero,1898(a5) # 2898 <buffer_len>
	return r >= 0 ? 0 : r;
    1136:	2501                	sext.w	a0,a0
}
    1138:	0141                	addi	sp,sp,16
    113a:	8082                	ret

000000000000113c <fflush>:

int fflush(int fd)
{
    113c:	1101                	addi	sp,sp,-32
    113e:	e822                	sd	s0,16(sp)
    1140:	ec06                	sd	ra,24(sp)
    1142:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1144:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1146:	4401                	li	s0,0
	if (fd == 1) {
    1148:	00e50863          	beq	a0,a4,1158 <fflush+0x1c>
}
    114c:	60e2                	ld	ra,24(sp)
    114e:	8522                	mv	a0,s0
    1150:	6442                	ld	s0,16(sp)
    1152:	64a2                	ld	s1,8(sp)
    1154:	6105                	addi	sp,sp,32
    1156:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1158:	00001497          	auipc	s1,0x1
    115c:	74048493          	addi	s1,s1,1856 # 2898 <buffer_len>
    1160:	1084a703          	lw	a4,264(s1)
    1164:	02a70e63          	beq	a4,a0,11a0 <fflush+0x64>
	if (buffer_len == 0)
    1168:	4080                	lw	s0,0(s1)
    116a:	c00d                	beqz	s0,118c <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    116c:	8622                	mv	a2,s0
    116e:	00001597          	auipc	a1,0x1
    1172:	73258593          	addi	a1,a1,1842 # 28a0 <buffer>
    1176:	294010ef          	jal	ra,240a <write>
	return r >= 0 ? 0 : r;
    117a:	0005079b          	sext.w	a5,a0
    117e:	0017a793          	slti	a5,a5,1
    1182:	40f007bb          	negw	a5,a5
    1186:	8d7d                	and	a0,a0,a5
    1188:	0005041b          	sext.w	s0,a0
}
    118c:	60e2                	ld	ra,24(sp)
    118e:	8522                	mv	a0,s0
    1190:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1192:	00001797          	auipc	a5,0x1
    1196:	7007a323          	sw	zero,1798(a5) # 2898 <buffer_len>
}
    119a:	64a2                	ld	s1,8(sp)
    119c:	6105                	addi	sp,sp,32
    119e:	8082                	ret
			mutex_lock(buffer_lock);
    11a0:	10c4a503          	lw	a0,268(s1)
    11a4:	4de010ef          	jal	ra,2682 <mutex_lock>
	if (buffer_len == 0)
    11a8:	4080                	lw	s0,0(s1)
    11aa:	e811                	bnez	s0,11be <fflush+0x82>
			mutex_unlock(buffer_lock);
    11ac:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11b0:	00001797          	auipc	a5,0x1
    11b4:	6e07a423          	sw	zero,1768(a5) # 2898 <buffer_len>
			mutex_unlock(buffer_lock);
    11b8:	4d6010ef          	jal	ra,268e <mutex_unlock>
    11bc:	bf41                	j	114c <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11be:	8622                	mv	a2,s0
    11c0:	00001597          	auipc	a1,0x1
    11c4:	6e058593          	addi	a1,a1,1760 # 28a0 <buffer>
    11c8:	4505                	li	a0,1
    11ca:	240010ef          	jal	ra,240a <write>
	return r >= 0 ? 0 : r;
    11ce:	0005079b          	sext.w	a5,a0
    11d2:	0017a793          	slti	a5,a5,1
    11d6:	40f007bb          	negw	a5,a5
    11da:	8d7d                	and	a0,a0,a5
    11dc:	0005041b          	sext.w	s0,a0
	return r;
    11e0:	b7f1                	j	11ac <fflush+0x70>

00000000000011e2 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11e2:	7131                	addi	sp,sp,-192
    11e4:	e0da                	sd	s6,64(sp)
    11e6:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11e8:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11ea:	013c                	addi	a5,sp,136
{
    11ec:	f0ca                	sd	s2,96(sp)
    11ee:	ecce                	sd	s3,88(sp)
    11f0:	e8d2                	sd	s4,80(sp)
    11f2:	e4d6                	sd	s5,72(sp)
    11f4:	fc86                	sd	ra,120(sp)
    11f6:	f8a2                	sd	s0,112(sp)
    11f8:	f4a6                	sd	s1,104(sp)
    11fa:	89aa                	mv	s3,a0
    11fc:	e52e                	sd	a1,136(sp)
    11fe:	e932                	sd	a2,144(sp)
    1200:	ed36                	sd	a3,152(sp)
    1202:	f13a                	sd	a4,160(sp)
    1204:	f942                	sd	a6,176(sp)
    1206:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1208:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    120a:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    120e:	00001a17          	auipc	s4,0x1
    1212:	68aa0a13          	addi	s4,s4,1674 # 2898 <buffer_len>
    1216:	4a85                	li	s5,1
	buf[i++] = '0';
    1218:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    121c:	0009c783          	lbu	a5,0(s3)
    1220:	18078663          	beqz	a5,13ac <printf+0x1ca>
    1224:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1226:	19278d63          	beq	a5,s2,13c0 <printf+0x1de>
    122a:	0015c783          	lbu	a5,1(a1)
    122e:	0585                	addi	a1,a1,1
    1230:	fbfd                	bnez	a5,1226 <printf+0x44>
    1232:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1234:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1238:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    123c:	1b578863          	beq	a5,s5,13ec <printf+0x20a>
		len = out_unlocked(s, l);
    1240:	85a2                	mv	a1,s0
    1242:	854e                	mv	a0,s3
    1244:	42a000ef          	jal	ra,166e <out_unlocked>
		out(f, a, l);
		if (l)
    1248:	1c041063          	bnez	s0,1408 <printf+0x226>
			continue;
		if (s[1] == 0)
    124c:	0014c783          	lbu	a5,1(s1)
    1250:	14078e63          	beqz	a5,13ac <printf+0x1ca>
			break;
		switch (s[1]) {
    1254:	07300713          	li	a4,115
    1258:	1ce78863          	beq	a5,a4,1428 <printf+0x246>
    125c:	1af76863          	bltu	a4,a5,140c <printf+0x22a>
    1260:	06400713          	li	a4,100
    1264:	22e78063          	beq	a5,a4,1484 <printf+0x2a2>
    1268:	07000713          	li	a4,112
    126c:	1ee79563          	bne	a5,a4,1456 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1270:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1272:	00001797          	auipc	a5,0x1
    1276:	73678793          	addi	a5,a5,1846 # 29a8 <digits>
	buf[i++] = '0';
    127a:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    127e:	6298                	ld	a4,0(a3)
    1280:	06a1                	addi	a3,a3,8
    1282:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1284:	00471393          	slli	t2,a4,0x4
    1288:	00871293          	slli	t0,a4,0x8
    128c:	00c71f93          	slli	t6,a4,0xc
    1290:	01071f13          	slli	t5,a4,0x10
    1294:	01471e93          	slli	t4,a4,0x14
    1298:	01871e13          	slli	t3,a4,0x18
    129c:	01c71893          	slli	a7,a4,0x1c
    12a0:	02471813          	slli	a6,a4,0x24
    12a4:	02871513          	slli	a0,a4,0x28
    12a8:	02c71593          	slli	a1,a4,0x2c
    12ac:	03071613          	slli	a2,a4,0x30
    12b0:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12b4:	03c75413          	srli	s0,a4,0x3c
    12b8:	01c7531b          	srliw	t1,a4,0x1c
    12bc:	03c3d393          	srli	t2,t2,0x3c
    12c0:	03c2d293          	srli	t0,t0,0x3c
    12c4:	03cfdf93          	srli	t6,t6,0x3c
    12c8:	03cf5f13          	srli	t5,t5,0x3c
    12cc:	03cede93          	srli	t4,t4,0x3c
    12d0:	03ce5e13          	srli	t3,t3,0x3c
    12d4:	03c8d893          	srli	a7,a7,0x3c
    12d8:	03c85813          	srli	a6,a6,0x3c
    12dc:	9171                	srli	a0,a0,0x3c
    12de:	91f1                	srli	a1,a1,0x3c
    12e0:	9271                	srli	a2,a2,0x3c
    12e2:	92f1                	srli	a3,a3,0x3c
    12e4:	95be                	add	a1,a1,a5
    12e6:	963e                	add	a2,a2,a5
    12e8:	96be                	add	a3,a3,a5
    12ea:	943e                	add	s0,s0,a5
    12ec:	93be                	add	t2,t2,a5
    12ee:	92be                	add	t0,t0,a5
    12f0:	9fbe                	add	t6,t6,a5
    12f2:	9f3e                	add	t5,t5,a5
    12f4:	9ebe                	add	t4,t4,a5
    12f6:	9e3e                	add	t3,t3,a5
    12f8:	98be                	add	a7,a7,a5
    12fa:	933e                	add	t1,t1,a5
    12fc:	983e                	add	a6,a6,a5
    12fe:	953e                	add	a0,a0,a5
    1300:	0005c983          	lbu	s3,0(a1)
    1304:	00044403          	lbu	s0,0(s0)
    1308:	00064583          	lbu	a1,0(a2)
    130c:	0003c383          	lbu	t2,0(t2)
    1310:	0006c603          	lbu	a2,0(a3)
    1314:	0002c283          	lbu	t0,0(t0)
    1318:	000fcf83          	lbu	t6,0(t6)
    131c:	000f4f03          	lbu	t5,0(t5)
    1320:	000ece83          	lbu	t4,0(t4)
    1324:	000e4e03          	lbu	t3,0(t3)
    1328:	0008c883          	lbu	a7,0(a7)
    132c:	00034303          	lbu	t1,0(t1)
    1330:	00084803          	lbu	a6,0(a6)
    1334:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1338:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    133c:	92f1                	srli	a3,a3,0x3c
    133e:	8b3d                	andi	a4,a4,15
    1340:	96be                	add	a3,a3,a5
    1342:	97ba                	add	a5,a5,a4
    1344:	00810d23          	sb	s0,26(sp)
    1348:	00710da3          	sb	t2,27(sp)
    134c:	00510e23          	sb	t0,28(sp)
    1350:	01f10ea3          	sb	t6,29(sp)
    1354:	01e10f23          	sb	t5,30(sp)
    1358:	01d10fa3          	sb	t4,31(sp)
    135c:	03c10023          	sb	t3,32(sp)
    1360:	031100a3          	sb	a7,33(sp)
    1364:	02610123          	sb	t1,34(sp)
    1368:	030101a3          	sb	a6,35(sp)
    136c:	02a10223          	sb	a0,36(sp)
    1370:	033102a3          	sb	s3,37(sp)
    1374:	02b10323          	sb	a1,38(sp)
    1378:	02c103a3          	sb	a2,39(sp)
    137c:	0006c683          	lbu	a3,0(a3)
    1380:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1384:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1388:	02d10423          	sb	a3,40(sp)
    138c:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1390:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1394:	11578263          	beq	a5,s5,1498 <printf+0x2b6>
		len = out_unlocked(s, l);
    1398:	45c9                	li	a1,18
    139a:	0828                	addi	a0,sp,24
    139c:	2d2000ef          	jal	ra,166e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13a0:	00248993          	addi	s3,s1,2
		if (!*s)
    13a4:	0009c783          	lbu	a5,0(s3)
    13a8:	e6079ee3          	bnez	a5,1224 <printf+0x42>
	}
	va_end(ap);
    13ac:	70e6                	ld	ra,120(sp)
    13ae:	7446                	ld	s0,112(sp)
    13b0:	74a6                	ld	s1,104(sp)
    13b2:	7906                	ld	s2,96(sp)
    13b4:	69e6                	ld	s3,88(sp)
    13b6:	6a46                	ld	s4,80(sp)
    13b8:	6aa6                	ld	s5,72(sp)
    13ba:	6b06                	ld	s6,64(sp)
    13bc:	6129                	addi	sp,sp,192
    13be:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13c0:	0005c783          	lbu	a5,0(a1)
    13c4:	84ae                	mv	s1,a1
    13c6:	01278963          	beq	a5,s2,13d8 <printf+0x1f6>
    13ca:	b5ad                	j	1234 <printf+0x52>
    13cc:	0024c783          	lbu	a5,2(s1)
    13d0:	0585                	addi	a1,a1,1
    13d2:	0489                	addi	s1,s1,2
    13d4:	e72790e3          	bne	a5,s2,1234 <printf+0x52>
    13d8:	0014c783          	lbu	a5,1(s1)
    13dc:	ff2788e3          	beq	a5,s2,13cc <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13e0:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13e4:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13e8:	e5579ce3          	bne	a5,s5,1240 <printf+0x5e>
		mutex_lock(buffer_lock);
    13ec:	10ca2503          	lw	a0,268(s4)
    13f0:	292010ef          	jal	ra,2682 <mutex_lock>
		len = out_unlocked(s, l);
    13f4:	85a2                	mv	a1,s0
    13f6:	854e                	mv	a0,s3
    13f8:	276000ef          	jal	ra,166e <out_unlocked>
		mutex_unlock(buffer_lock);
    13fc:	10ca2503          	lw	a0,268(s4)
    1400:	28e010ef          	jal	ra,268e <mutex_unlock>
		if (l)
    1404:	e40404e3          	beqz	s0,124c <printf+0x6a>
    1408:	89a6                	mv	s3,s1
    140a:	bd09                	j	121c <printf+0x3a>
		switch (s[1]) {
    140c:	07800713          	li	a4,120
    1410:	04e79363          	bne	a5,a4,1456 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1414:	67c2                	ld	a5,16(sp)
    1416:	45c1                	li	a1,16
		s += 2;
    1418:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    141c:	4388                	lw	a0,0(a5)
    141e:	07a1                	addi	a5,a5,8
    1420:	e83e                	sd	a5,16(sp)
    1422:	5f8000ef          	jal	ra,1a1a <printint.constprop.0>
		s += 2;
    1426:	bfbd                	j	13a4 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1428:	67c2                	ld	a5,16(sp)
    142a:	6380                	ld	s0,0(a5)
    142c:	07a1                	addi	a5,a5,8
    142e:	e83e                	sd	a5,16(sp)
    1430:	1c040163          	beqz	s0,15f2 <printf+0x410>
			l = strnlen(a, 200);
    1434:	0c800593          	li	a1,200
    1438:	8522                	mv	a0,s0
    143a:	3f7000ef          	jal	ra,2030 <strnlen>
	if (buffer_lock_enabled == 1) {
    143e:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1442:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1446:	19578663          	beq	a5,s5,15d2 <printf+0x3f0>
		len = out_unlocked(s, l);
    144a:	8522                	mv	a0,s0
    144c:	222000ef          	jal	ra,166e <out_unlocked>
		s += 2;
    1450:	00248993          	addi	s3,s1,2
    1454:	bf81                	j	13a4 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1456:	108a2783          	lw	a5,264(s4)
	char byte = c;
    145a:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    145e:	0f578663          	beq	a5,s5,154a <printf+0x368>
		len = out_unlocked(s, l);
    1462:	0828                	addi	a0,sp,24
    1464:	316000ef          	jal	ra,177a <out_unlocked.constprop.0>
			putchar(s[1]);
    1468:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    146c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1470:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1474:	05578163          	beq	a5,s5,14b6 <printf+0x2d4>
		len = out_unlocked(s, l);
    1478:	0828                	addi	a0,sp,24
    147a:	300000ef          	jal	ra,177a <out_unlocked.constprop.0>
		s += 2;
    147e:	00248993          	addi	s3,s1,2
    1482:	b70d                	j	13a4 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1484:	67c2                	ld	a5,16(sp)
    1486:	45a9                	li	a1,10
		s += 2;
    1488:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    148c:	4388                	lw	a0,0(a5)
    148e:	07a1                	addi	a5,a5,8
    1490:	e83e                	sd	a5,16(sp)
    1492:	588000ef          	jal	ra,1a1a <printint.constprop.0>
		s += 2;
    1496:	b739                	j	13a4 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1498:	10ca2503          	lw	a0,268(s4)
		s += 2;
    149c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14a0:	1e2010ef          	jal	ra,2682 <mutex_lock>
		len = out_unlocked(s, l);
    14a4:	45c9                	li	a1,18
    14a6:	0828                	addi	a0,sp,24
    14a8:	1c6000ef          	jal	ra,166e <out_unlocked>
		mutex_unlock(buffer_lock);
    14ac:	10ca2503          	lw	a0,268(s4)
    14b0:	1de010ef          	jal	ra,268e <mutex_unlock>
		s += 2;
    14b4:	bdc5                	j	13a4 <printf+0x1c2>
		mutex_lock(buffer_lock);
    14b6:	10ca2503          	lw	a0,268(s4)
    14ba:	1c8010ef          	jal	ra,2682 <mutex_lock>
		buffer[buffer_len++] = c;
    14be:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14c2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14c6:	0017861b          	addiw	a2,a5,1
    14ca:	97d2                	add	a5,a5,s4
    14cc:	00ca2023          	sw	a2,0(s4)
    14d0:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14d4:	00c6cc63          	blt	a3,a2,14ec <printf+0x30a>
    14d8:	47a9                	li	a5,10
    14da:	06f40663          	beq	s0,a5,1546 <printf+0x364>
		mutex_unlock(buffer_lock);
    14de:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14e2:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14e6:	1a8010ef          	jal	ra,268e <mutex_unlock>
		s += 2;
    14ea:	bd6d                	j	13a4 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14ec:	10000793          	li	a5,256
    14f0:	00f61e63          	bne	a2,a5,150c <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14f4:	00001597          	auipc	a1,0x1
    14f8:	3ac58593          	addi	a1,a1,940 # 28a0 <buffer>
    14fc:	4505                	li	a0,1
    14fe:	70d000ef          	jal	ra,240a <write>
	buffer_len = 0;
    1502:	00001797          	auipc	a5,0x1
    1506:	3807ab23          	sw	zero,918(a5) # 2898 <buffer_len>
			if (r < 0) {
    150a:	bfd1                	j	14de <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    150c:	709000ef          	jal	ra,2414 <getpid>
    1510:	842a                	mv	s0,a0
    1512:	00001517          	auipc	a0,0x1
    1516:	29650513          	addi	a0,a0,662 # 27a8 <enable_deadlock_detect+0xc6>
    151a:	5d1000ef          	jal	ra,22ea <basename>
    151e:	872a                	mv	a4,a0
    1520:	00001617          	auipc	a2,0x1
    1524:	21860613          	addi	a2,a2,536 # 2738 <enable_deadlock_detect+0x56>
    1528:	05400793          	li	a5,84
    152c:	86a2                	mv	a3,s0
    152e:	45fd                	li	a1,31
    1530:	00001517          	auipc	a0,0x1
    1534:	2b850513          	addi	a0,a0,696 # 27e8 <enable_deadlock_detect+0x106>
    1538:	cabff0ef          	jal	ra,11e2 <printf>
    153c:	557d                	li	a0,-1
    153e:	707000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    1542:	000a2603          	lw	a2,0(s4)
    1546:	de41                	beqz	a2,14de <printf+0x2fc>
    1548:	b775                	j	14f4 <printf+0x312>
		mutex_lock(buffer_lock);
    154a:	10ca2503          	lw	a0,268(s4)
    154e:	134010ef          	jal	ra,2682 <mutex_lock>
		buffer[buffer_len++] = c;
    1552:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1556:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    155a:	0017861b          	addiw	a2,a5,1
    155e:	97d2                	add	a5,a5,s4
    1560:	00ca2023          	sw	a2,0(s4)
    1564:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1568:	02c6d163          	bge	a3,a2,158a <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    156c:	10000793          	li	a5,256
    1570:	02f61263          	bne	a2,a5,1594 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1574:	00001597          	auipc	a1,0x1
    1578:	32c58593          	addi	a1,a1,812 # 28a0 <buffer>
    157c:	4505                	li	a0,1
    157e:	68d000ef          	jal	ra,240a <write>
	buffer_len = 0;
    1582:	00001797          	auipc	a5,0x1
    1586:	3007ab23          	sw	zero,790(a5) # 2898 <buffer_len>
		mutex_unlock(buffer_lock);
    158a:	10ca2503          	lw	a0,268(s4)
    158e:	100010ef          	jal	ra,268e <mutex_unlock>
    1592:	bdd9                	j	1468 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1594:	681000ef          	jal	ra,2414 <getpid>
    1598:	842a                	mv	s0,a0
    159a:	00001517          	auipc	a0,0x1
    159e:	20e50513          	addi	a0,a0,526 # 27a8 <enable_deadlock_detect+0xc6>
    15a2:	549000ef          	jal	ra,22ea <basename>
    15a6:	872a                	mv	a4,a0
    15a8:	00001617          	auipc	a2,0x1
    15ac:	19060613          	addi	a2,a2,400 # 2738 <enable_deadlock_detect+0x56>
    15b0:	05400793          	li	a5,84
    15b4:	86a2                	mv	a3,s0
    15b6:	45fd                	li	a1,31
    15b8:	00001517          	auipc	a0,0x1
    15bc:	23050513          	addi	a0,a0,560 # 27e8 <enable_deadlock_detect+0x106>
    15c0:	c23ff0ef          	jal	ra,11e2 <printf>
    15c4:	557d                	li	a0,-1
    15c6:	67f000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    15ca:	000a2603          	lw	a2,0(s4)
    15ce:	de55                	beqz	a2,158a <printf+0x3a8>
    15d0:	b755                	j	1574 <printf+0x392>
		mutex_lock(buffer_lock);
    15d2:	10ca2503          	lw	a0,268(s4)
    15d6:	e42e                	sd	a1,8(sp)
		s += 2;
    15d8:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15dc:	0a6010ef          	jal	ra,2682 <mutex_lock>
		len = out_unlocked(s, l);
    15e0:	65a2                	ld	a1,8(sp)
    15e2:	8522                	mv	a0,s0
    15e4:	08a000ef          	jal	ra,166e <out_unlocked>
		mutex_unlock(buffer_lock);
    15e8:	10ca2503          	lw	a0,268(s4)
    15ec:	0a2010ef          	jal	ra,268e <mutex_unlock>
		s += 2;
    15f0:	bb55                	j	13a4 <printf+0x1c2>
				a = "(null)";
    15f2:	00001417          	auipc	s0,0x1
    15f6:	1ae40413          	addi	s0,s0,430 # 27a0 <enable_deadlock_detect+0xbe>
    15fa:	bd2d                	j	1434 <printf+0x252>

00000000000015fc <enable_thread_io_buffer>:
{
    15fc:	1101                	addi	sp,sp,-32
    15fe:	e822                	sd	s0,16(sp)
    1600:	ec06                	sd	ra,24(sp)
    1602:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1604:	00001417          	auipc	s0,0x1
    1608:	29440413          	addi	s0,s0,660 # 2898 <buffer_len>
    160c:	05a010ef          	jal	ra,2666 <mutex_create>
    1610:	10a42623          	sw	a0,268(s0)
    1614:	00054a63          	bltz	a0,1628 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1618:	4785                	li	a5,1
}
    161a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    161c:	10f42423          	sw	a5,264(s0)
}
    1620:	6442                	ld	s0,16(sp)
    1622:	64a2                	ld	s1,8(sp)
    1624:	6105                	addi	sp,sp,32
    1626:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1628:	5ed000ef          	jal	ra,2414 <getpid>
    162c:	84aa                	mv	s1,a0
    162e:	00001517          	auipc	a0,0x1
    1632:	17a50513          	addi	a0,a0,378 # 27a8 <enable_deadlock_detect+0xc6>
    1636:	4b5000ef          	jal	ra,22ea <basename>
    163a:	872a                	mv	a4,a0
    163c:	04800793          	li	a5,72
    1640:	86a6                	mv	a3,s1
    1642:	00001517          	auipc	a0,0x1
    1646:	1e650513          	addi	a0,a0,486 # 2828 <enable_deadlock_detect+0x146>
    164a:	00001617          	auipc	a2,0x1
    164e:	0ee60613          	addi	a2,a2,238 # 2738 <enable_deadlock_detect+0x56>
    1652:	45fd                	li	a1,31
    1654:	b8fff0ef          	jal	ra,11e2 <printf>
    1658:	557d                	li	a0,-1
    165a:	5eb000ef          	jal	ra,2444 <exit>
	buffer_lock_enabled = 1;
    165e:	4785                	li	a5,1
}
    1660:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1662:	10f42423          	sw	a5,264(s0)
}
    1666:	6442                	ld	s0,16(sp)
    1668:	64a2                	ld	s1,8(sp)
    166a:	6105                	addi	sp,sp,32
    166c:	8082                	ret

000000000000166e <out_unlocked>:
{
    166e:	7159                	addi	sp,sp,-112
    1670:	f486                	sd	ra,104(sp)
    1672:	f0a2                	sd	s0,96(sp)
    1674:	eca6                	sd	s1,88(sp)
    1676:	e8ca                	sd	s2,80(sp)
    1678:	e4ce                	sd	s3,72(sp)
    167a:	e0d2                	sd	s4,64(sp)
    167c:	fc56                	sd	s5,56(sp)
    167e:	f85a                	sd	s6,48(sp)
    1680:	f45e                	sd	s7,40(sp)
    1682:	f062                	sd	s8,32(sp)
    1684:	ec66                	sd	s9,24(sp)
    1686:	e86a                	sd	s10,16(sp)
    1688:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    168a:	0e058663          	beqz	a1,1776 <out_unlocked+0x108>
    168e:	842a                	mv	s0,a0
    1690:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1694:	4981                	li	s3,0
    1696:	00001d17          	auipc	s10,0x1
    169a:	202d0d13          	addi	s10,s10,514 # 2898 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    169e:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16a2:	00001b17          	auipc	s6,0x1
    16a6:	1feb0b13          	addi	s6,s6,510 # 28a0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16aa:	10000a93          	li	s5,256
    16ae:	00001c97          	auipc	s9,0x1
    16b2:	0fac8c93          	addi	s9,s9,250 # 27a8 <enable_deadlock_detect+0xc6>
    16b6:	00001c17          	auipc	s8,0x1
    16ba:	082c0c13          	addi	s8,s8,130 # 2738 <enable_deadlock_detect+0x56>
    16be:	00001b97          	auipc	s7,0x1
    16c2:	12ab8b93          	addi	s7,s7,298 # 27e8 <enable_deadlock_detect+0x106>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16c6:	4a29                	li	s4,10
    16c8:	a031                	j	16d4 <out_unlocked+0x66>
    16ca:	09468863          	beq	a3,s4,175a <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16ce:	0405                	addi	s0,s0,1
    16d0:	04848163          	beq	s1,s0,1712 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16d4:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16d8:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16dc:	0017861b          	addiw	a2,a5,1
    16e0:	97ea                	add	a5,a5,s10
    16e2:	00cd2023          	sw	a2,0(s10)
    16e6:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ea:	fec950e3          	bge	s2,a2,16ca <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16ee:	05561263          	bne	a2,s5,1732 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16f2:	85da                	mv	a1,s6
    16f4:	4505                	li	a0,1
    16f6:	515000ef          	jal	ra,240a <write>
    16fa:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16fc:	00001797          	auipc	a5,0x1
    1700:	1807ae23          	sw	zero,412(a5) # 2898 <buffer_len>
			if (r < 0) {
    1704:	06054763          	bltz	a0,1772 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1708:	0405                	addi	s0,s0,1
			ret += r;
    170a:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    170e:	fc8493e3          	bne	s1,s0,16d4 <out_unlocked+0x66>
}
    1712:	70a6                	ld	ra,104(sp)
    1714:	7406                	ld	s0,96(sp)
    1716:	64e6                	ld	s1,88(sp)
    1718:	6946                	ld	s2,80(sp)
    171a:	6a06                	ld	s4,64(sp)
    171c:	7ae2                	ld	s5,56(sp)
    171e:	7b42                	ld	s6,48(sp)
    1720:	7ba2                	ld	s7,40(sp)
    1722:	7c02                	ld	s8,32(sp)
    1724:	6ce2                	ld	s9,24(sp)
    1726:	6d42                	ld	s10,16(sp)
    1728:	6da2                	ld	s11,8(sp)
    172a:	854e                	mv	a0,s3
    172c:	69a6                	ld	s3,72(sp)
    172e:	6165                	addi	sp,sp,112
    1730:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1732:	4e3000ef          	jal	ra,2414 <getpid>
    1736:	8daa                	mv	s11,a0
    1738:	8566                	mv	a0,s9
    173a:	3b1000ef          	jal	ra,22ea <basename>
    173e:	872a                	mv	a4,a0
    1740:	8662                	mv	a2,s8
    1742:	05400793          	li	a5,84
    1746:	86ee                	mv	a3,s11
    1748:	45fd                	li	a1,31
    174a:	855e                	mv	a0,s7
    174c:	a97ff0ef          	jal	ra,11e2 <printf>
    1750:	557d                	li	a0,-1
    1752:	4f3000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    1756:	000d2603          	lw	a2,0(s10)
    175a:	da35                	beqz	a2,16ce <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    175c:	85da                	mv	a1,s6
    175e:	4505                	li	a0,1
    1760:	4ab000ef          	jal	ra,240a <write>
    1764:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1766:	00001797          	auipc	a5,0x1
    176a:	1207a923          	sw	zero,306(a5) # 2898 <buffer_len>
			if (r < 0) {
    176e:	f8055de3          	bgez	a0,1708 <out_unlocked+0x9a>
    1772:	89aa                	mv	s3,a0
    1774:	bf79                	j	1712 <out_unlocked+0xa4>
	int ret = 0;
    1776:	4981                	li	s3,0
    1778:	bf69                	j	1712 <out_unlocked+0xa4>

000000000000177a <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    177a:	1101                	addi	sp,sp,-32
    177c:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    177e:	00001497          	auipc	s1,0x1
    1782:	11a48493          	addi	s1,s1,282 # 2898 <buffer_len>
    1786:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1788:	ec06                	sd	ra,24(sp)
    178a:	e822                	sd	s0,16(sp)
		char c = s[i];
    178c:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1790:	0017861b          	addiw	a2,a5,1
    1794:	97a6                	add	a5,a5,s1
    1796:	00e78423          	sb	a4,8(a5)
    179a:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    179c:	0ff00793          	li	a5,255
    17a0:	00c7cc63          	blt	a5,a2,17b8 <out_unlocked.constprop.0+0x3e>
    17a4:	47a9                	li	a5,10
    17a6:	06f70c63          	beq	a4,a5,181e <out_unlocked.constprop.0+0xa4>
    17aa:	4601                	li	a2,0
}
    17ac:	60e2                	ld	ra,24(sp)
    17ae:	6442                	ld	s0,16(sp)
    17b0:	64a2                	ld	s1,8(sp)
    17b2:	8532                	mv	a0,a2
    17b4:	6105                	addi	sp,sp,32
    17b6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17b8:	10000793          	li	a5,256
    17bc:	02f61563          	bne	a2,a5,17e6 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17c0:	00001597          	auipc	a1,0x1
    17c4:	0e058593          	addi	a1,a1,224 # 28a0 <buffer>
    17c8:	4505                	li	a0,1
    17ca:	441000ef          	jal	ra,240a <write>
}
    17ce:	60e2                	ld	ra,24(sp)
    17d0:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17d2:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17d6:	00001797          	auipc	a5,0x1
    17da:	0c07a123          	sw	zero,194(a5) # 2898 <buffer_len>
}
    17de:	64a2                	ld	s1,8(sp)
    17e0:	8532                	mv	a0,a2
    17e2:	6105                	addi	sp,sp,32
    17e4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17e6:	42f000ef          	jal	ra,2414 <getpid>
    17ea:	842a                	mv	s0,a0
    17ec:	00001517          	auipc	a0,0x1
    17f0:	fbc50513          	addi	a0,a0,-68 # 27a8 <enable_deadlock_detect+0xc6>
    17f4:	2f7000ef          	jal	ra,22ea <basename>
    17f8:	872a                	mv	a4,a0
    17fa:	00001617          	auipc	a2,0x1
    17fe:	f3e60613          	addi	a2,a2,-194 # 2738 <enable_deadlock_detect+0x56>
    1802:	05400793          	li	a5,84
    1806:	86a2                	mv	a3,s0
    1808:	45fd                	li	a1,31
    180a:	00001517          	auipc	a0,0x1
    180e:	fde50513          	addi	a0,a0,-34 # 27e8 <enable_deadlock_detect+0x106>
    1812:	9d1ff0ef          	jal	ra,11e2 <printf>
    1816:	557d                	li	a0,-1
    1818:	42d000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    181c:	4090                	lw	a2,0(s1)
    181e:	d659                	beqz	a2,17ac <out_unlocked.constprop.0+0x32>
    1820:	b745                	j	17c0 <out_unlocked.constprop.0+0x46>

0000000000001822 <putchar>:
{
    1822:	7139                	addi	sp,sp,-64
    1824:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1826:	00001497          	auipc	s1,0x1
    182a:	07248493          	addi	s1,s1,114 # 2898 <buffer_len>
    182e:	1084a703          	lw	a4,264(s1)
{
    1832:	f822                	sd	s0,48(sp)
	char byte = c;
    1834:	0ff57413          	zext.b	s0,a0
{
    1838:	fc06                	sd	ra,56(sp)
	char byte = c;
    183a:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    183e:	4785                	li	a5,1
    1840:	00f70d63          	beq	a4,a5,185a <putchar+0x38>
		len = out_unlocked(s, l);
    1844:	01f10513          	addi	a0,sp,31
    1848:	f33ff0ef          	jal	ra,177a <out_unlocked.constprop.0>
}
    184c:	70e2                	ld	ra,56(sp)
    184e:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1850:	862a                	mv	a2,a0
}
    1852:	74a2                	ld	s1,40(sp)
    1854:	8532                	mv	a0,a2
    1856:	6121                	addi	sp,sp,64
    1858:	8082                	ret
		mutex_lock(buffer_lock);
    185a:	10c4a503          	lw	a0,268(s1)
    185e:	625000ef          	jal	ra,2682 <mutex_lock>
		buffer[buffer_len++] = c;
    1862:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1864:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1868:	0017861b          	addiw	a2,a5,1
    186c:	97a6                	add	a5,a5,s1
    186e:	c090                	sw	a2,0(s1)
    1870:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1874:	02c6c263          	blt	a3,a2,1898 <putchar+0x76>
    1878:	47a9                	li	a5,10
    187a:	06f40d63          	beq	s0,a5,18f4 <putchar+0xd2>
    187e:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1880:	10c4a503          	lw	a0,268(s1)
    1884:	e432                	sd	a2,8(sp)
    1886:	609000ef          	jal	ra,268e <mutex_unlock>
    188a:	6622                	ld	a2,8(sp)
}
    188c:	70e2                	ld	ra,56(sp)
    188e:	7442                	ld	s0,48(sp)
    1890:	74a2                	ld	s1,40(sp)
    1892:	8532                	mv	a0,a2
    1894:	6121                	addi	sp,sp,64
    1896:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1898:	10000793          	li	a5,256
    189c:	02f61063          	bne	a2,a5,18bc <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18a0:	00001597          	auipc	a1,0x1
    18a4:	00058593          	mv	a1,a1
    18a8:	4505                	li	a0,1
    18aa:	361000ef          	jal	ra,240a <write>
    18ae:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18b2:	00001797          	auipc	a5,0x1
    18b6:	fe07a323          	sw	zero,-26(a5) # 2898 <buffer_len>
			if (r < 0) {
    18ba:	b7d9                	j	1880 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18bc:	359000ef          	jal	ra,2414 <getpid>
    18c0:	842a                	mv	s0,a0
    18c2:	00001517          	auipc	a0,0x1
    18c6:	ee650513          	addi	a0,a0,-282 # 27a8 <enable_deadlock_detect+0xc6>
    18ca:	221000ef          	jal	ra,22ea <basename>
    18ce:	872a                	mv	a4,a0
    18d0:	00001617          	auipc	a2,0x1
    18d4:	e6860613          	addi	a2,a2,-408 # 2738 <enable_deadlock_detect+0x56>
    18d8:	05400793          	li	a5,84
    18dc:	86a2                	mv	a3,s0
    18de:	45fd                	li	a1,31
    18e0:	00001517          	auipc	a0,0x1
    18e4:	f0850513          	addi	a0,a0,-248 # 27e8 <enable_deadlock_detect+0x106>
    18e8:	8fbff0ef          	jal	ra,11e2 <printf>
    18ec:	557d                	li	a0,-1
    18ee:	357000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    18f2:	4090                	lw	a2,0(s1)
    18f4:	d651                	beqz	a2,1880 <putchar+0x5e>
    18f6:	b76d                	j	18a0 <putchar+0x7e>

00000000000018f8 <puts>:
{
    18f8:	7139                	addi	sp,sp,-64
    18fa:	f822                	sd	s0,48(sp)
    18fc:	f426                	sd	s1,40(sp)
    18fe:	fc06                	sd	ra,56(sp)
    1900:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1902:	00001417          	auipc	s0,0x1
    1906:	f9640413          	addi	s0,s0,-106 # 2898 <buffer_len>
{
    190a:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    190c:	638000ef          	jal	ra,1f44 <strlen>
	if (buffer_lock_enabled == 1) {
    1910:	10842703          	lw	a4,264(s0)
    1914:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1916:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1918:	04f70563          	beq	a4,a5,1962 <puts+0x6a>
		len = out_unlocked(s, l);
    191c:	8526                	mv	a0,s1
    191e:	d51ff0ef          	jal	ra,166e <out_unlocked>
    1922:	892a                	mv	s2,a0
    1924:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1926:	00095963          	bgez	s2,1938 <puts+0x40>
}
    192a:	70e2                	ld	ra,56(sp)
    192c:	7442                	ld	s0,48(sp)
    192e:	7902                	ld	s2,32(sp)
    1930:	8526                	mv	a0,s1
    1932:	74a2                	ld	s1,40(sp)
    1934:	6121                	addi	sp,sp,64
    1936:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1938:	10842703          	lw	a4,264(s0)
	char byte = c;
    193c:	44a9                	li	s1,10
    193e:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1942:	4785                	li	a5,1
    1944:	02f70e63          	beq	a4,a5,1980 <puts+0x88>
		len = out_unlocked(s, l);
    1948:	01f10513          	addi	a0,sp,31
    194c:	e2fff0ef          	jal	ra,177a <out_unlocked.constprop.0>
}
    1950:	70e2                	ld	ra,56(sp)
    1952:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1954:	41f5549b          	sraiw	s1,a0,0x1f
}
    1958:	7902                	ld	s2,32(sp)
    195a:	8526                	mv	a0,s1
    195c:	74a2                	ld	s1,40(sp)
    195e:	6121                	addi	sp,sp,64
    1960:	8082                	ret
		mutex_lock(buffer_lock);
    1962:	e42a                	sd	a0,8(sp)
    1964:	10c42503          	lw	a0,268(s0)
    1968:	51b000ef          	jal	ra,2682 <mutex_lock>
		len = out_unlocked(s, l);
    196c:	65a2                	ld	a1,8(sp)
    196e:	8526                	mv	a0,s1
    1970:	cffff0ef          	jal	ra,166e <out_unlocked>
    1974:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1976:	10c42503          	lw	a0,268(s0)
    197a:	515000ef          	jal	ra,268e <mutex_unlock>
    197e:	b75d                	j	1924 <puts+0x2c>
		mutex_lock(buffer_lock);
    1980:	10c42503          	lw	a0,268(s0)
    1984:	4ff000ef          	jal	ra,2682 <mutex_lock>
		buffer[buffer_len++] = c;
    1988:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    198a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    198e:	0017861b          	addiw	a2,a5,1
    1992:	97a2                	add	a5,a5,s0
    1994:	c010                	sw	a2,0(s0)
    1996:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    199a:	06c6dc63          	bge	a3,a2,1a12 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    199e:	10000793          	li	a5,256
    19a2:	02f61c63          	bne	a2,a5,19da <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19a6:	00001597          	auipc	a1,0x1
    19aa:	efa58593          	addi	a1,a1,-262 # 28a0 <buffer>
    19ae:	4505                	li	a0,1
    19b0:	25b000ef          	jal	ra,240a <write>
			if (r < 0) {
    19b4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19b6:	00001797          	auipc	a5,0x1
    19ba:	ee07a123          	sw	zero,-286(a5) # 2898 <buffer_len>
			if (r < 0) {
    19be:	04054c63          	bltz	a0,1a16 <puts+0x11e>
			if (r < buffer_len) {
    19c2:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19c4:	10c42503          	lw	a0,268(s0)
    19c8:	4c7000ef          	jal	ra,268e <mutex_unlock>
}
    19cc:	70e2                	ld	ra,56(sp)
    19ce:	7442                	ld	s0,48(sp)
    19d0:	7902                	ld	s2,32(sp)
    19d2:	8526                	mv	a0,s1
    19d4:	74a2                	ld	s1,40(sp)
    19d6:	6121                	addi	sp,sp,64
    19d8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19da:	23b000ef          	jal	ra,2414 <getpid>
    19de:	84aa                	mv	s1,a0
    19e0:	00001517          	auipc	a0,0x1
    19e4:	dc850513          	addi	a0,a0,-568 # 27a8 <enable_deadlock_detect+0xc6>
    19e8:	103000ef          	jal	ra,22ea <basename>
    19ec:	872a                	mv	a4,a0
    19ee:	00001617          	auipc	a2,0x1
    19f2:	d4a60613          	addi	a2,a2,-694 # 2738 <enable_deadlock_detect+0x56>
    19f6:	05400793          	li	a5,84
    19fa:	86a6                	mv	a3,s1
    19fc:	45fd                	li	a1,31
    19fe:	00001517          	auipc	a0,0x1
    1a02:	dea50513          	addi	a0,a0,-534 # 27e8 <enable_deadlock_detect+0x106>
    1a06:	fdcff0ef          	jal	ra,11e2 <printf>
    1a0a:	557d                	li	a0,-1
    1a0c:	239000ef          	jal	ra,2444 <exit>
	if (buffer_len == 0)
    1a10:	4010                	lw	a2,0(s0)
    1a12:	da45                	beqz	a2,19c2 <puts+0xca>
    1a14:	bf49                	j	19a6 <puts+0xae>
    1a16:	54fd                	li	s1,-1
    1a18:	b775                	j	19c4 <puts+0xcc>

0000000000001a1a <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a1a:	715d                	addi	sp,sp,-80
    1a1c:	e486                	sd	ra,72(sp)
    1a1e:	e0a2                	sd	s0,64(sp)
    1a20:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a22:	14054363          	bltz	a0,1b68 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a26:	02b577bb          	remuw	a5,a0,a1
    1a2a:	00001617          	auipc	a2,0x1
    1a2e:	f7e60613          	addi	a2,a2,-130 # 29a8 <digits>
	buf[16] = 0;
    1a32:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a36:	0005871b          	sext.w	a4,a1
    1a3a:	1782                	slli	a5,a5,0x20
    1a3c:	9381                	srli	a5,a5,0x20
    1a3e:	97b2                	add	a5,a5,a2
    1a40:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a44:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a48:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a4c:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a4e:	0eb56763          	bltu	a0,a1,1b3c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a52:	02e877bb          	remuw	a5,a6,a4
    1a56:	1782                	slli	a5,a5,0x20
    1a58:	9381                	srli	a5,a5,0x20
    1a5a:	97b2                	add	a5,a5,a2
    1a5c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a60:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a64:	02f10323          	sb	a5,38(sp)
    1a68:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a6a:	0ce86963          	bltu	a6,a4,1b3c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a6e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a72:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a76:	1582                	slli	a1,a1,0x20
    1a78:	9181                	srli	a1,a1,0x20
    1a7a:	95b2                	add	a1,a1,a2
    1a7c:	0005c583          	lbu	a1,0(a1)
    1a80:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a84:	0007859b          	sext.w	a1,a5
    1a88:	16e6e563          	bltu	a3,a4,1bf2 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a8c:	02e7f6bb          	remuw	a3,a5,a4
    1a90:	1682                	slli	a3,a3,0x20
    1a92:	9281                	srli	a3,a3,0x20
    1a94:	96b2                	add	a3,a3,a2
    1a96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a9a:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a9e:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1aa2:	16e5e163          	bltu	a1,a4,1c04 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1aa6:	02e876bb          	remuw	a3,a6,a4
    1aaa:	1682                	slli	a3,a3,0x20
    1aac:	9281                	srli	a3,a3,0x20
    1aae:	96b2                	add	a3,a3,a2
    1ab0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ab8:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1abc:	14e86d63          	bltu	a6,a4,1c16 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1ac0:	02e5f6bb          	remuw	a3,a1,a4
    1ac4:	1682                	slli	a3,a3,0x20
    1ac6:	9281                	srli	a3,a3,0x20
    1ac8:	96b2                	add	a3,a3,a2
    1aca:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ace:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ad2:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ad6:	10e5e563          	bltu	a1,a4,1be0 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ada:	02e876bb          	remuw	a3,a6,a4
    1ade:	1682                	slli	a3,a3,0x20
    1ae0:	9281                	srli	a3,a3,0x20
    1ae2:	96b2                	add	a3,a3,a2
    1ae4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae8:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1aec:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1af0:	14e86263          	bltu	a6,a4,1c34 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1af4:	02e5f6bb          	remuw	a3,a1,a4
    1af8:	1682                	slli	a3,a3,0x20
    1afa:	9281                	srli	a3,a3,0x20
    1afc:	96b2                	add	a3,a3,a2
    1afe:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b02:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b06:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b0a:	14e5e463          	bltu	a1,a4,1c52 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b0e:	02e876bb          	remuw	a3,a6,a4
    1b12:	1682                	slli	a3,a3,0x20
    1b14:	9281                	srli	a3,a3,0x20
    1b16:	96b2                	add	a3,a3,a2
    1b18:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b1c:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b20:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b24:	14e86063          	bltu	a6,a4,1c64 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b28:	1782                	slli	a5,a5,0x20
    1b2a:	9381                	srli	a5,a5,0x20
    1b2c:	97b2                	add	a5,a5,a2
    1b2e:	0007c703          	lbu	a4,0(a5)
    1b32:	4799                	li	a5,6
    1b34:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b38:	10054763          	bltz	a0,1c46 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b3c:	00001497          	auipc	s1,0x1
    1b40:	d5c48493          	addi	s1,s1,-676 # 2898 <buffer_len>
    1b44:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b48:	0828                	addi	a0,sp,24
    1b4a:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b4c:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b4e:	00f50433          	add	s0,a0,a5
    1b52:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b54:	06e68463          	beq	a3,a4,1bbc <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b58:	8522                	mv	a0,s0
    1b5a:	b15ff0ef          	jal	ra,166e <out_unlocked>
}
    1b5e:	60a6                	ld	ra,72(sp)
    1b60:	6406                	ld	s0,64(sp)
    1b62:	74e2                	ld	s1,56(sp)
    1b64:	6161                	addi	sp,sp,80
    1b66:	8082                	ret
		x = -xx;
    1b68:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b6c:	02b877bb          	remuw	a5,a6,a1
    1b70:	00001617          	auipc	a2,0x1
    1b74:	e3860613          	addi	a2,a2,-456 # 29a8 <digits>
	buf[16] = 0;
    1b78:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b7c:	0005871b          	sext.w	a4,a1
    1b80:	1782                	slli	a5,a5,0x20
    1b82:	9381                	srli	a5,a5,0x20
    1b84:	97b2                	add	a5,a5,a2
    1b86:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b8a:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b8e:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b92:	08b86b63          	bltu	a6,a1,1c28 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b96:	02e8f7bb          	remuw	a5,a7,a4
    1b9a:	1782                	slli	a5,a5,0x20
    1b9c:	9381                	srli	a5,a5,0x20
    1b9e:	97b2                	add	a5,a5,a2
    1ba0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ba4:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1ba8:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1bac:	ece8f1e3          	bgeu	a7,a4,1a6e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bb0:	02d00793          	li	a5,45
    1bb4:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1bb8:	47b5                	li	a5,13
    1bba:	b749                	j	1b3c <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1bbc:	10c4a503          	lw	a0,268(s1)
    1bc0:	e42e                	sd	a1,8(sp)
    1bc2:	2c1000ef          	jal	ra,2682 <mutex_lock>
		len = out_unlocked(s, l);
    1bc6:	65a2                	ld	a1,8(sp)
    1bc8:	8522                	mv	a0,s0
    1bca:	aa5ff0ef          	jal	ra,166e <out_unlocked>
		mutex_unlock(buffer_lock);
    1bce:	10c4a503          	lw	a0,268(s1)
    1bd2:	2bd000ef          	jal	ra,268e <mutex_unlock>
}
    1bd6:	60a6                	ld	ra,72(sp)
    1bd8:	6406                	ld	s0,64(sp)
    1bda:	74e2                	ld	s1,56(sp)
    1bdc:	6161                	addi	sp,sp,80
    1bde:	8082                	ret
		buf[i--] = digits[x % base];
    1be0:	47a9                	li	a5,10
	if (sign)
    1be2:	f4055de3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be6:	02d00793          	li	a5,45
    1bea:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bee:	47a5                	li	a5,9
    1bf0:	b7b1                	j	1b3c <printint.constprop.0+0x122>
    1bf2:	47b5                	li	a5,13
	if (sign)
    1bf4:	f40554e3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf8:	02d00793          	li	a5,45
    1bfc:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c00:	47b1                	li	a5,12
    1c02:	bf2d                	j	1b3c <printint.constprop.0+0x122>
    1c04:	47b1                	li	a5,12
	if (sign)
    1c06:	f2055be3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0a:	02d00793          	li	a5,45
    1c0e:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c12:	47ad                	li	a5,11
    1c14:	b725                	j	1b3c <printint.constprop.0+0x122>
    1c16:	47ad                	li	a5,11
	if (sign)
    1c18:	f20552e3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1c:	02d00793          	li	a5,45
    1c20:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c24:	47a9                	li	a5,10
    1c26:	bf19                	j	1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c28:	02d00793          	li	a5,45
    1c2c:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c30:	47b9                	li	a5,14
    1c32:	b729                	j	1b3c <printint.constprop.0+0x122>
    1c34:	47a5                	li	a5,9
	if (sign)
    1c36:	f00553e3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c3a:	02d00793          	li	a5,45
    1c3e:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c42:	47a1                	li	a5,8
    1c44:	bde5                	j	1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c46:	02d00793          	li	a5,45
    1c4a:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c4e:	4795                	li	a5,5
    1c50:	b5f5                	j	1b3c <printint.constprop.0+0x122>
    1c52:	47a1                	li	a5,8
	if (sign)
    1c54:	ee0554e3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c58:	02d00793          	li	a5,45
    1c5c:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c60:	479d                	li	a5,7
    1c62:	bde9                	j	1b3c <printint.constprop.0+0x122>
    1c64:	479d                	li	a5,7
	if (sign)
    1c66:	ec055be3          	bgez	a0,1b3c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c6a:	02d00793          	li	a5,45
    1c6e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c72:	4799                	li	a5,6
    1c74:	b5e1                	j	1b3c <printint.constprop.0+0x122>

0000000000001c76 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c76:	02000793          	li	a5,32
    1c7a:	00f50663          	beq	a0,a5,1c86 <isspace+0x10>
    1c7e:	355d                	addiw	a0,a0,-9
    1c80:	00553513          	sltiu	a0,a0,5
    1c84:	8082                	ret
    1c86:	4505                	li	a0,1
}
    1c88:	8082                	ret

0000000000001c8a <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c8a:	fd05051b          	addiw	a0,a0,-48
}
    1c8e:	00a53513          	sltiu	a0,a0,10
    1c92:	8082                	ret

0000000000001c94 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c94:	02000613          	li	a2,32
    1c98:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c9a:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c9e:	ff77869b          	addiw	a3,a5,-9
    1ca2:	04c78c63          	beq	a5,a2,1cfa <atoi+0x66>
    1ca6:	0007871b          	sext.w	a4,a5
    1caa:	04d5f863          	bgeu	a1,a3,1cfa <atoi+0x66>
		s++;
	switch (*s) {
    1cae:	02b00693          	li	a3,43
    1cb2:	04d78963          	beq	a5,a3,1d04 <atoi+0x70>
    1cb6:	02d00693          	li	a3,45
    1cba:	06d78263          	beq	a5,a3,1d1e <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1cbe:	fd07061b          	addiw	a2,a4,-48
    1cc2:	47a5                	li	a5,9
    1cc4:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cc6:	4e01                	li	t3,0
	while (isdigit(*s))
    1cc8:	04c7e963          	bltu	a5,a2,1d1a <atoi+0x86>
	int n = 0, neg = 0;
    1ccc:	4501                	li	a0,0
	while (isdigit(*s))
    1cce:	4825                	li	a6,9
    1cd0:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cd4:	0025179b          	slliw	a5,a0,0x2
    1cd8:	9fa9                	addw	a5,a5,a0
    1cda:	fd07031b          	addiw	t1,a4,-48
    1cde:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ce2:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ce6:	0685                	addi	a3,a3,1
    1ce8:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cec:	0006071b          	sext.w	a4,a2
    1cf0:	feb870e3          	bgeu	a6,a1,1cd0 <atoi+0x3c>
	return neg ? n : -n;
    1cf4:	000e0563          	beqz	t3,1cfe <atoi+0x6a>
}
    1cf8:	8082                	ret
		s++;
    1cfa:	0505                	addi	a0,a0,1
    1cfc:	bf79                	j	1c9a <atoi+0x6>
	return neg ? n : -n;
    1cfe:	4113053b          	subw	a0,t1,a7
    1d02:	8082                	ret
	while (isdigit(*s))
    1d04:	00154703          	lbu	a4,1(a0)
    1d08:	47a5                	li	a5,9
		s++;
    1d0a:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d0e:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d12:	4e01                	li	t3,0
	while (isdigit(*s))
    1d14:	2701                	sext.w	a4,a4
    1d16:	fac7fbe3          	bgeu	a5,a2,1ccc <atoi+0x38>
    1d1a:	4501                	li	a0,0
}
    1d1c:	8082                	ret
	while (isdigit(*s))
    1d1e:	00154703          	lbu	a4,1(a0)
    1d22:	47a5                	li	a5,9
		s++;
    1d24:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d28:	fd07061b          	addiw	a2,a4,-48
    1d2c:	2701                	sext.w	a4,a4
    1d2e:	fec7e6e3          	bltu	a5,a2,1d1a <atoi+0x86>
		neg = 1;
    1d32:	4e05                	li	t3,1
    1d34:	bf61                	j	1ccc <atoi+0x38>

0000000000001d36 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d36:	16060d63          	beqz	a2,1eb0 <memset+0x17a>
    1d3a:	40a007b3          	neg	a5,a0
    1d3e:	8b9d                	andi	a5,a5,7
    1d40:	00778693          	addi	a3,a5,7
    1d44:	482d                	li	a6,11
    1d46:	0ff5f713          	zext.b	a4,a1
    1d4a:	fff60593          	addi	a1,a2,-1
    1d4e:	1706e263          	bltu	a3,a6,1eb2 <memset+0x17c>
    1d52:	16d5ea63          	bltu	a1,a3,1ec6 <memset+0x190>
    1d56:	16078563          	beqz	a5,1ec0 <memset+0x18a>
    1d5a:	00e50023          	sb	a4,0(a0)
    1d5e:	4685                	li	a3,1
    1d60:	00150593          	addi	a1,a0,1
    1d64:	14d78c63          	beq	a5,a3,1ebc <memset+0x186>
    1d68:	00e500a3          	sb	a4,1(a0)
    1d6c:	4689                	li	a3,2
    1d6e:	00250593          	addi	a1,a0,2
    1d72:	14d78d63          	beq	a5,a3,1ecc <memset+0x196>
    1d76:	00e50123          	sb	a4,2(a0)
    1d7a:	468d                	li	a3,3
    1d7c:	00350593          	addi	a1,a0,3
    1d80:	12d78b63          	beq	a5,a3,1eb6 <memset+0x180>
    1d84:	00e501a3          	sb	a4,3(a0)
    1d88:	4691                	li	a3,4
    1d8a:	00450593          	addi	a1,a0,4
    1d8e:	14d78163          	beq	a5,a3,1ed0 <memset+0x19a>
    1d92:	00e50223          	sb	a4,4(a0)
    1d96:	4695                	li	a3,5
    1d98:	00550593          	addi	a1,a0,5
    1d9c:	12d78c63          	beq	a5,a3,1ed4 <memset+0x19e>
    1da0:	00e502a3          	sb	a4,5(a0)
    1da4:	469d                	li	a3,7
    1da6:	00650593          	addi	a1,a0,6
    1daa:	12d79763          	bne	a5,a3,1ed8 <memset+0x1a2>
    1dae:	00750593          	addi	a1,a0,7
    1db2:	00e50323          	sb	a4,6(a0)
    1db6:	481d                	li	a6,7
    1db8:	00871693          	slli	a3,a4,0x8
    1dbc:	01071893          	slli	a7,a4,0x10
    1dc0:	8ed9                	or	a3,a3,a4
    1dc2:	01871313          	slli	t1,a4,0x18
    1dc6:	0116e6b3          	or	a3,a3,a7
    1dca:	0066e6b3          	or	a3,a3,t1
    1dce:	02071893          	slli	a7,a4,0x20
    1dd2:	02871e13          	slli	t3,a4,0x28
    1dd6:	0116e6b3          	or	a3,a3,a7
    1dda:	40f60333          	sub	t1,a2,a5
    1dde:	03071893          	slli	a7,a4,0x30
    1de2:	01c6e6b3          	or	a3,a3,t3
    1de6:	0116e6b3          	or	a3,a3,a7
    1dea:	03871e13          	slli	t3,a4,0x38
    1dee:	97aa                	add	a5,a5,a0
    1df0:	ff837893          	andi	a7,t1,-8
    1df4:	01c6e6b3          	or	a3,a3,t3
    1df8:	98be                	add	a7,a7,a5
    1dfa:	e394                	sd	a3,0(a5)
    1dfc:	07a1                	addi	a5,a5,8
    1dfe:	ff179ee3          	bne	a5,a7,1dfa <memset+0xc4>
    1e02:	ff837893          	andi	a7,t1,-8
    1e06:	011587b3          	add	a5,a1,a7
    1e0a:	010886bb          	addw	a3,a7,a6
    1e0e:	0b130663          	beq	t1,a7,1eba <memset+0x184>
    1e12:	00e78023          	sb	a4,0(a5)
    1e16:	0016859b          	addiw	a1,a3,1
    1e1a:	08c5fb63          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e1e:	00e780a3          	sb	a4,1(a5)
    1e22:	0026859b          	addiw	a1,a3,2
    1e26:	08c5f563          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e2a:	00e78123          	sb	a4,2(a5)
    1e2e:	0036859b          	addiw	a1,a3,3
    1e32:	06c5ff63          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e36:	00e781a3          	sb	a4,3(a5)
    1e3a:	0046859b          	addiw	a1,a3,4
    1e3e:	06c5f963          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e42:	00e78223          	sb	a4,4(a5)
    1e46:	0056859b          	addiw	a1,a3,5
    1e4a:	06c5f363          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e4e:	00e782a3          	sb	a4,5(a5)
    1e52:	0066859b          	addiw	a1,a3,6
    1e56:	04c5fd63          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e5a:	00e78323          	sb	a4,6(a5)
    1e5e:	0076859b          	addiw	a1,a3,7
    1e62:	04c5f763          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e66:	00e783a3          	sb	a4,7(a5)
    1e6a:	0086859b          	addiw	a1,a3,8
    1e6e:	04c5f163          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e72:	00e78423          	sb	a4,8(a5)
    1e76:	0096859b          	addiw	a1,a3,9
    1e7a:	02c5fb63          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e7e:	00e784a3          	sb	a4,9(a5)
    1e82:	00a6859b          	addiw	a1,a3,10
    1e86:	02c5f563          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e8a:	00e78523          	sb	a4,10(a5)
    1e8e:	00b6859b          	addiw	a1,a3,11
    1e92:	00c5ff63          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1e96:	00e785a3          	sb	a4,11(a5)
    1e9a:	00c6859b          	addiw	a1,a3,12
    1e9e:	00c5f963          	bgeu	a1,a2,1eb0 <memset+0x17a>
    1ea2:	00e78623          	sb	a4,12(a5)
    1ea6:	26b5                	addiw	a3,a3,13
    1ea8:	00c6f463          	bgeu	a3,a2,1eb0 <memset+0x17a>
    1eac:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1eb0:	8082                	ret
    1eb2:	46ad                	li	a3,11
    1eb4:	bd79                	j	1d52 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1eb6:	480d                	li	a6,3
    1eb8:	b701                	j	1db8 <memset+0x82>
    1eba:	8082                	ret
    1ebc:	4805                	li	a6,1
    1ebe:	bded                	j	1db8 <memset+0x82>
    1ec0:	85aa                	mv	a1,a0
    1ec2:	4801                	li	a6,0
    1ec4:	bdd5                	j	1db8 <memset+0x82>
    1ec6:	87aa                	mv	a5,a0
    1ec8:	4681                	li	a3,0
    1eca:	b7a1                	j	1e12 <memset+0xdc>
    1ecc:	4809                	li	a6,2
    1ece:	b5ed                	j	1db8 <memset+0x82>
    1ed0:	4811                	li	a6,4
    1ed2:	b5dd                	j	1db8 <memset+0x82>
    1ed4:	4815                	li	a6,5
    1ed6:	b5cd                	j	1db8 <memset+0x82>
    1ed8:	4819                	li	a6,6
    1eda:	bdf9                	j	1db8 <memset+0x82>

0000000000001edc <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1edc:	00054783          	lbu	a5,0(a0)
    1ee0:	0005c703          	lbu	a4,0(a1)
    1ee4:	00e79863          	bne	a5,a4,1ef4 <strcmp+0x18>
    1ee8:	0505                	addi	a0,a0,1
    1eea:	0585                	addi	a1,a1,1
    1eec:	fbe5                	bnez	a5,1edc <strcmp>
    1eee:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1ef0:	9d19                	subw	a0,a0,a4
    1ef2:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1ef4:	0007851b          	sext.w	a0,a5
    1ef8:	bfe5                	j	1ef0 <strcmp+0x14>

0000000000001efa <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1efa:	ca15                	beqz	a2,1f2e <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1efc:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f00:	167d                	addi	a2,a2,-1
    1f02:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f06:	eb99                	bnez	a5,1f1c <strncmp+0x22>
    1f08:	a815                	j	1f3c <strncmp+0x42>
    1f0a:	00a68e63          	beq	a3,a0,1f26 <strncmp+0x2c>
    1f0e:	0505                	addi	a0,a0,1
    1f10:	00f71b63          	bne	a4,a5,1f26 <strncmp+0x2c>
    1f14:	00054783          	lbu	a5,0(a0)
    1f18:	cf89                	beqz	a5,1f32 <strncmp+0x38>
    1f1a:	85b2                	mv	a1,a2
    1f1c:	0005c703          	lbu	a4,0(a1)
    1f20:	00158613          	addi	a2,a1,1
    1f24:	f37d                	bnez	a4,1f0a <strncmp+0x10>
		;
	return *l - *r;
    1f26:	0007851b          	sext.w	a0,a5
    1f2a:	9d19                	subw	a0,a0,a4
    1f2c:	8082                	ret
		return 0;
    1f2e:	4501                	li	a0,0
}
    1f30:	8082                	ret
	return *l - *r;
    1f32:	0015c703          	lbu	a4,1(a1)
    1f36:	4501                	li	a0,0
    1f38:	9d19                	subw	a0,a0,a4
    1f3a:	8082                	ret
    1f3c:	0005c703          	lbu	a4,0(a1)
    1f40:	4501                	li	a0,0
    1f42:	b7e5                	j	1f2a <strncmp+0x30>

0000000000001f44 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f44:	00757793          	andi	a5,a0,7
    1f48:	cf89                	beqz	a5,1f62 <strlen+0x1e>
    1f4a:	87aa                	mv	a5,a0
    1f4c:	a029                	j	1f56 <strlen+0x12>
    1f4e:	0785                	addi	a5,a5,1
    1f50:	0077f713          	andi	a4,a5,7
    1f54:	cb01                	beqz	a4,1f64 <strlen+0x20>
		if (!*s)
    1f56:	0007c703          	lbu	a4,0(a5)
    1f5a:	fb75                	bnez	a4,1f4e <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f5c:	40a78533          	sub	a0,a5,a0
}
    1f60:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f62:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f64:	6394                	ld	a3,0(a5)
    1f66:	00001597          	auipc	a1,0x1
    1f6a:	91a5b583          	ld	a1,-1766(a1) # 2880 <enable_deadlock_detect+0x19e>
    1f6e:	00001617          	auipc	a2,0x1
    1f72:	91a63603          	ld	a2,-1766(a2) # 2888 <enable_deadlock_detect+0x1a6>
    1f76:	a019                	j	1f7c <strlen+0x38>
    1f78:	6794                	ld	a3,8(a5)
    1f7a:	07a1                	addi	a5,a5,8
    1f7c:	00b68733          	add	a4,a3,a1
    1f80:	fff6c693          	not	a3,a3
    1f84:	8f75                	and	a4,a4,a3
    1f86:	8f71                	and	a4,a4,a2
    1f88:	db65                	beqz	a4,1f78 <strlen+0x34>
	for (; *s; s++)
    1f8a:	0007c703          	lbu	a4,0(a5)
    1f8e:	d779                	beqz	a4,1f5c <strlen+0x18>
    1f90:	0017c703          	lbu	a4,1(a5)
    1f94:	0785                	addi	a5,a5,1
    1f96:	d379                	beqz	a4,1f5c <strlen+0x18>
    1f98:	0017c703          	lbu	a4,1(a5)
    1f9c:	0785                	addi	a5,a5,1
    1f9e:	fb6d                	bnez	a4,1f90 <strlen+0x4c>
    1fa0:	bf75                	j	1f5c <strlen+0x18>

0000000000001fa2 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fa2:	00757713          	andi	a4,a0,7
{
    1fa6:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1fa8:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fac:	cb19                	beqz	a4,1fc2 <memchr+0x20>
    1fae:	ce25                	beqz	a2,2026 <memchr+0x84>
    1fb0:	0007c703          	lbu	a4,0(a5)
    1fb4:	04b70e63          	beq	a4,a1,2010 <memchr+0x6e>
    1fb8:	0785                	addi	a5,a5,1
    1fba:	0077f713          	andi	a4,a5,7
    1fbe:	167d                	addi	a2,a2,-1
    1fc0:	f77d                	bnez	a4,1fae <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1fc2:	4501                	li	a0,0
	if (n && *s != c) {
    1fc4:	c235                	beqz	a2,2028 <memchr+0x86>
    1fc6:	0007c703          	lbu	a4,0(a5)
    1fca:	04b70363          	beq	a4,a1,2010 <memchr+0x6e>
		size_t k = ONES * c;
    1fce:	00001517          	auipc	a0,0x1
    1fd2:	8c253503          	ld	a0,-1854(a0) # 2890 <enable_deadlock_detect+0x1ae>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fd6:	471d                	li	a4,7
		size_t k = ONES * c;
    1fd8:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fdc:	02c77a63          	bgeu	a4,a2,2010 <memchr+0x6e>
    1fe0:	00001897          	auipc	a7,0x1
    1fe4:	8a08b883          	ld	a7,-1888(a7) # 2880 <enable_deadlock_detect+0x19e>
    1fe8:	00001817          	auipc	a6,0x1
    1fec:	8a083803          	ld	a6,-1888(a6) # 2888 <enable_deadlock_detect+0x1a6>
    1ff0:	431d                	li	t1,7
    1ff2:	a029                	j	1ffc <memchr+0x5a>
		     w++, n -= SS)
    1ff4:	1661                	addi	a2,a2,-8
    1ff6:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1ff8:	02c37963          	bgeu	t1,a2,202a <memchr+0x88>
    1ffc:	6398                	ld	a4,0(a5)
    1ffe:	8f29                	xor	a4,a4,a0
    2000:	011706b3          	add	a3,a4,a7
    2004:	fff74713          	not	a4,a4
    2008:	8f75                	and	a4,a4,a3
    200a:	01077733          	and	a4,a4,a6
    200e:	d37d                	beqz	a4,1ff4 <memchr+0x52>
{
    2010:	853e                	mv	a0,a5
    2012:	97b2                	add	a5,a5,a2
    2014:	a021                	j	201c <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2016:	0505                	addi	a0,a0,1
    2018:	00f50763          	beq	a0,a5,2026 <memchr+0x84>
    201c:	00054703          	lbu	a4,0(a0)
    2020:	feb71be3          	bne	a4,a1,2016 <memchr+0x74>
    2024:	8082                	ret
	return n ? (void *)s : 0;
    2026:	4501                	li	a0,0
}
    2028:	8082                	ret
	return n ? (void *)s : 0;
    202a:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    202c:	f275                	bnez	a2,2010 <memchr+0x6e>
}
    202e:	8082                	ret

0000000000002030 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2030:	1101                	addi	sp,sp,-32
    2032:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2034:	862e                	mv	a2,a1
{
    2036:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2038:	4581                	li	a1,0
{
    203a:	e426                	sd	s1,8(sp)
    203c:	ec06                	sd	ra,24(sp)
    203e:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2040:	f63ff0ef          	jal	ra,1fa2 <memchr>
	return p ? p - s : n;
    2044:	c519                	beqz	a0,2052 <strnlen+0x22>
}
    2046:	60e2                	ld	ra,24(sp)
    2048:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    204a:	8d05                	sub	a0,a0,s1
}
    204c:	64a2                	ld	s1,8(sp)
    204e:	6105                	addi	sp,sp,32
    2050:	8082                	ret
    2052:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2054:	8522                	mv	a0,s0
}
    2056:	6442                	ld	s0,16(sp)
    2058:	64a2                	ld	s1,8(sp)
    205a:	6105                	addi	sp,sp,32
    205c:	8082                	ret

000000000000205e <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    205e:	00a5c7b3          	xor	a5,a1,a0
    2062:	8b9d                	andi	a5,a5,7
    2064:	eb95                	bnez	a5,2098 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2066:	0075f793          	andi	a5,a1,7
    206a:	e7b1                	bnez	a5,20b6 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    206c:	6198                	ld	a4,0(a1)
    206e:	00001617          	auipc	a2,0x1
    2072:	81263603          	ld	a2,-2030(a2) # 2880 <enable_deadlock_detect+0x19e>
    2076:	00001817          	auipc	a6,0x1
    207a:	81283803          	ld	a6,-2030(a6) # 2888 <enable_deadlock_detect+0x1a6>
    207e:	a029                	j	2088 <stpcpy+0x2a>
    2080:	05a1                	addi	a1,a1,8
    2082:	e118                	sd	a4,0(a0)
    2084:	6198                	ld	a4,0(a1)
    2086:	0521                	addi	a0,a0,8
    2088:	00c707b3          	add	a5,a4,a2
    208c:	fff74693          	not	a3,a4
    2090:	8ff5                	and	a5,a5,a3
    2092:	0107f7b3          	and	a5,a5,a6
    2096:	d7ed                	beqz	a5,2080 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2098:	0005c783          	lbu	a5,0(a1)
    209c:	00f50023          	sb	a5,0(a0)
    20a0:	c785                	beqz	a5,20c8 <stpcpy+0x6a>
    20a2:	0015c783          	lbu	a5,1(a1)
    20a6:	0505                	addi	a0,a0,1
    20a8:	0585                	addi	a1,a1,1
    20aa:	00f50023          	sb	a5,0(a0)
    20ae:	fbf5                	bnez	a5,20a2 <stpcpy+0x44>
		;
	return d;
}
    20b0:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20b2:	0505                	addi	a0,a0,1
    20b4:	df45                	beqz	a4,206c <stpcpy+0xe>
			if (!(*d = *s))
    20b6:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20ba:	0585                	addi	a1,a1,1
    20bc:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20c0:	00f50023          	sb	a5,0(a0)
    20c4:	f7fd                	bnez	a5,20b2 <stpcpy+0x54>
}
    20c6:	8082                	ret
    20c8:	8082                	ret

00000000000020ca <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20ca:	00a5c7b3          	xor	a5,a1,a0
    20ce:	8b9d                	andi	a5,a5,7
    20d0:	1a079863          	bnez	a5,2280 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20d4:	0075f793          	andi	a5,a1,7
    20d8:	16078463          	beqz	a5,2240 <stpncpy+0x176>
    20dc:	ea01                	bnez	a2,20ec <stpncpy+0x22>
    20de:	a421                	j	22e6 <stpncpy+0x21c>
    20e0:	167d                	addi	a2,a2,-1
    20e2:	0505                	addi	a0,a0,1
    20e4:	14070e63          	beqz	a4,2240 <stpncpy+0x176>
    20e8:	1a060863          	beqz	a2,2298 <stpncpy+0x1ce>
    20ec:	0005c783          	lbu	a5,0(a1)
    20f0:	0585                	addi	a1,a1,1
    20f2:	0075f713          	andi	a4,a1,7
    20f6:	00f50023          	sb	a5,0(a0)
    20fa:	f3fd                	bnez	a5,20e0 <stpncpy+0x16>
    20fc:	4805                	li	a6,1
    20fe:	1a061863          	bnez	a2,22ae <stpncpy+0x1e4>
    2102:	40a007b3          	neg	a5,a0
    2106:	8b9d                	andi	a5,a5,7
    2108:	4681                	li	a3,0
    210a:	18061a63          	bnez	a2,229e <stpncpy+0x1d4>
    210e:	00778713          	addi	a4,a5,7
    2112:	45ad                	li	a1,11
    2114:	18b76363          	bltu	a4,a1,229a <stpncpy+0x1d0>
    2118:	1ae6eb63          	bltu	a3,a4,22ce <stpncpy+0x204>
    211c:	1a078363          	beqz	a5,22c2 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2120:	00050023          	sb	zero,0(a0)
    2124:	4685                	li	a3,1
    2126:	00150713          	addi	a4,a0,1
    212a:	18d78f63          	beq	a5,a3,22c8 <stpncpy+0x1fe>
    212e:	000500a3          	sb	zero,1(a0)
    2132:	4689                	li	a3,2
    2134:	00250713          	addi	a4,a0,2
    2138:	18d78e63          	beq	a5,a3,22d4 <stpncpy+0x20a>
    213c:	00050123          	sb	zero,2(a0)
    2140:	468d                	li	a3,3
    2142:	00350713          	addi	a4,a0,3
    2146:	16d78c63          	beq	a5,a3,22be <stpncpy+0x1f4>
    214a:	000501a3          	sb	zero,3(a0)
    214e:	4691                	li	a3,4
    2150:	00450713          	addi	a4,a0,4
    2154:	18d78263          	beq	a5,a3,22d8 <stpncpy+0x20e>
    2158:	00050223          	sb	zero,4(a0)
    215c:	4695                	li	a3,5
    215e:	00550713          	addi	a4,a0,5
    2162:	16d78d63          	beq	a5,a3,22dc <stpncpy+0x212>
    2166:	000502a3          	sb	zero,5(a0)
    216a:	469d                	li	a3,7
    216c:	00650713          	addi	a4,a0,6
    2170:	16d79863          	bne	a5,a3,22e0 <stpncpy+0x216>
    2174:	00750713          	addi	a4,a0,7
    2178:	00050323          	sb	zero,6(a0)
    217c:	40f80833          	sub	a6,a6,a5
    2180:	ff887593          	andi	a1,a6,-8
    2184:	97aa                	add	a5,a5,a0
    2186:	95be                	add	a1,a1,a5
    2188:	0007b023          	sd	zero,0(a5)
    218c:	07a1                	addi	a5,a5,8
    218e:	feb79de3          	bne	a5,a1,2188 <stpncpy+0xbe>
    2192:	ff887593          	andi	a1,a6,-8
    2196:	9ead                	addw	a3,a3,a1
    2198:	00b707b3          	add	a5,a4,a1
    219c:	12b80863          	beq	a6,a1,22cc <stpncpy+0x202>
    21a0:	00078023          	sb	zero,0(a5)
    21a4:	0016871b          	addiw	a4,a3,1
    21a8:	0ec77863          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21ac:	000780a3          	sb	zero,1(a5)
    21b0:	0026871b          	addiw	a4,a3,2
    21b4:	0ec77263          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21b8:	00078123          	sb	zero,2(a5)
    21bc:	0036871b          	addiw	a4,a3,3
    21c0:	0cc77c63          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21c4:	000781a3          	sb	zero,3(a5)
    21c8:	0046871b          	addiw	a4,a3,4
    21cc:	0cc77663          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21d0:	00078223          	sb	zero,4(a5)
    21d4:	0056871b          	addiw	a4,a3,5
    21d8:	0cc77063          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21dc:	000782a3          	sb	zero,5(a5)
    21e0:	0066871b          	addiw	a4,a3,6
    21e4:	0ac77a63          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21e8:	00078323          	sb	zero,6(a5)
    21ec:	0076871b          	addiw	a4,a3,7
    21f0:	0ac77463          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    21f4:	000783a3          	sb	zero,7(a5)
    21f8:	0086871b          	addiw	a4,a3,8
    21fc:	08c77e63          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    2200:	00078423          	sb	zero,8(a5)
    2204:	0096871b          	addiw	a4,a3,9
    2208:	08c77863          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    220c:	000784a3          	sb	zero,9(a5)
    2210:	00a6871b          	addiw	a4,a3,10
    2214:	08c77263          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    2218:	00078523          	sb	zero,10(a5)
    221c:	00b6871b          	addiw	a4,a3,11
    2220:	06c77c63          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    2224:	000785a3          	sb	zero,11(a5)
    2228:	00c6871b          	addiw	a4,a3,12
    222c:	06c77663          	bgeu	a4,a2,2298 <stpncpy+0x1ce>
    2230:	00078623          	sb	zero,12(a5)
    2234:	26b5                	addiw	a3,a3,13
    2236:	06c6f163          	bgeu	a3,a2,2298 <stpncpy+0x1ce>
    223a:	000786a3          	sb	zero,13(a5)
    223e:	8082                	ret
			;
		if (!n || !*s)
    2240:	c645                	beqz	a2,22e8 <stpncpy+0x21e>
    2242:	0005c783          	lbu	a5,0(a1)
    2246:	ea078be3          	beqz	a5,20fc <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    224a:	479d                	li	a5,7
    224c:	02c7ff63          	bgeu	a5,a2,228a <stpncpy+0x1c0>
    2250:	00000897          	auipc	a7,0x0
    2254:	6308b883          	ld	a7,1584(a7) # 2880 <enable_deadlock_detect+0x19e>
    2258:	00000817          	auipc	a6,0x0
    225c:	63083803          	ld	a6,1584(a6) # 2888 <enable_deadlock_detect+0x1a6>
    2260:	431d                	li	t1,7
    2262:	6198                	ld	a4,0(a1)
    2264:	011707b3          	add	a5,a4,a7
    2268:	fff74693          	not	a3,a4
    226c:	8ff5                	and	a5,a5,a3
    226e:	0107f7b3          	and	a5,a5,a6
    2272:	ef81                	bnez	a5,228a <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2274:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2276:	1661                	addi	a2,a2,-8
    2278:	05a1                	addi	a1,a1,8
    227a:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    227c:	fec363e3          	bltu	t1,a2,2262 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2280:	e609                	bnez	a2,228a <stpncpy+0x1c0>
    2282:	a08d                	j	22e4 <stpncpy+0x21a>
    2284:	167d                	addi	a2,a2,-1
    2286:	0505                	addi	a0,a0,1
    2288:	ca01                	beqz	a2,2298 <stpncpy+0x1ce>
    228a:	0005c783          	lbu	a5,0(a1)
    228e:	0585                	addi	a1,a1,1
    2290:	00f50023          	sb	a5,0(a0)
    2294:	fbe5                	bnez	a5,2284 <stpncpy+0x1ba>
		;
tail:
    2296:	b59d                	j	20fc <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2298:	8082                	ret
    229a:	472d                	li	a4,11
    229c:	bdb5                	j	2118 <stpncpy+0x4e>
    229e:	00778713          	addi	a4,a5,7
    22a2:	45ad                	li	a1,11
    22a4:	fff60693          	addi	a3,a2,-1
    22a8:	e6b778e3          	bgeu	a4,a1,2118 <stpncpy+0x4e>
    22ac:	b7fd                	j	229a <stpncpy+0x1d0>
    22ae:	40a007b3          	neg	a5,a0
    22b2:	8832                	mv	a6,a2
    22b4:	8b9d                	andi	a5,a5,7
    22b6:	4681                	li	a3,0
    22b8:	e4060be3          	beqz	a2,210e <stpncpy+0x44>
    22bc:	b7cd                	j	229e <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22be:	468d                	li	a3,3
    22c0:	bd75                	j	217c <stpncpy+0xb2>
    22c2:	872a                	mv	a4,a0
    22c4:	4681                	li	a3,0
    22c6:	bd5d                	j	217c <stpncpy+0xb2>
    22c8:	4685                	li	a3,1
    22ca:	bd4d                	j	217c <stpncpy+0xb2>
    22cc:	8082                	ret
    22ce:	87aa                	mv	a5,a0
    22d0:	4681                	li	a3,0
    22d2:	b5f9                	j	21a0 <stpncpy+0xd6>
    22d4:	4689                	li	a3,2
    22d6:	b55d                	j	217c <stpncpy+0xb2>
    22d8:	4691                	li	a3,4
    22da:	b54d                	j	217c <stpncpy+0xb2>
    22dc:	4695                	li	a3,5
    22de:	bd79                	j	217c <stpncpy+0xb2>
    22e0:	4699                	li	a3,6
    22e2:	bd69                	j	217c <stpncpy+0xb2>
    22e4:	8082                	ret
    22e6:	8082                	ret
    22e8:	8082                	ret

00000000000022ea <basename>:

char *basename(char *s)
{
    22ea:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22ec:	c54d                	beqz	a0,2396 <basename+0xac>
    22ee:	00054783          	lbu	a5,0(a0)
		return ".";
    22f2:	00000517          	auipc	a0,0x0
    22f6:	58650513          	addi	a0,a0,1414 # 2878 <enable_deadlock_detect+0x196>
	if (!s || !*s)
    22fa:	e391                	bnez	a5,22fe <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22fc:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22fe:	0076f713          	andi	a4,a3,7
    2302:	87b6                	mv	a5,a3
    2304:	cf51                	beqz	a4,23a0 <basename+0xb6>
    2306:	0785                	addi	a5,a5,1
    2308:	0077f713          	andi	a4,a5,7
    230c:	c729                	beqz	a4,2356 <basename+0x6c>
		if (!*s)
    230e:	0007c703          	lbu	a4,0(a5)
    2312:	fb75                	bnez	a4,2306 <basename+0x1c>
	return s - a;
    2314:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2316:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2318:	cf8d                	beqz	a5,2352 <basename+0x68>
    231a:	00f68733          	add	a4,a3,a5
    231e:	02f00593          	li	a1,47
    2322:	a031                	j	232e <basename+0x44>
		s[i] = 0;
    2324:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2328:	17fd                	addi	a5,a5,-1
    232a:	177d                	addi	a4,a4,-1
    232c:	c39d                	beqz	a5,2352 <basename+0x68>
    232e:	00074603          	lbu	a2,0(a4)
    2332:	feb609e3          	beq	a2,a1,2324 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2336:	02f00613          	li	a2,47
    233a:	a011                	j	233e <basename+0x54>
    233c:	cb99                	beqz	a5,2352 <basename+0x68>
    233e:	853e                	mv	a0,a5
    2340:	17fd                	addi	a5,a5,-1
    2342:	00f68733          	add	a4,a3,a5
    2346:	00074703          	lbu	a4,0(a4)
    234a:	fec719e3          	bne	a4,a2,233c <basename+0x52>
	return s + i;
    234e:	9536                	add	a0,a0,a3
    2350:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2352:	8536                	mv	a0,a3
    2354:	8082                	ret
    2356:	6390                	ld	a2,0(a5)
    2358:	00000517          	auipc	a0,0x0
    235c:	52853503          	ld	a0,1320(a0) # 2880 <enable_deadlock_detect+0x19e>
    2360:	00000597          	auipc	a1,0x0
    2364:	5285b583          	ld	a1,1320(a1) # 2888 <enable_deadlock_detect+0x1a6>
    2368:	fff64713          	not	a4,a2
    236c:	962a                	add	a2,a2,a0
    236e:	8f71                	and	a4,a4,a2
    2370:	8f6d                	and	a4,a4,a1
    2372:	eb11                	bnez	a4,2386 <basename+0x9c>
    2374:	6790                	ld	a2,8(a5)
    2376:	07a1                	addi	a5,a5,8
    2378:	00a60733          	add	a4,a2,a0
    237c:	fff64613          	not	a2,a2
    2380:	8f71                	and	a4,a4,a2
    2382:	8f6d                	and	a4,a4,a1
    2384:	db65                	beqz	a4,2374 <basename+0x8a>
	for (; *s; s++)
    2386:	0007c703          	lbu	a4,0(a5)
    238a:	d749                	beqz	a4,2314 <basename+0x2a>
    238c:	0017c703          	lbu	a4,1(a5)
    2390:	0785                	addi	a5,a5,1
    2392:	ff6d                	bnez	a4,238c <basename+0xa2>
    2394:	b741                	j	2314 <basename+0x2a>
		return ".";
    2396:	00000517          	auipc	a0,0x0
    239a:	4e250513          	addi	a0,a0,1250 # 2878 <enable_deadlock_detect+0x196>
    239e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23a0:	6290                	ld	a2,0(a3)
    23a2:	00000517          	auipc	a0,0x0
    23a6:	4de53503          	ld	a0,1246(a0) # 2880 <enable_deadlock_detect+0x19e>
    23aa:	00000597          	auipc	a1,0x0
    23ae:	4de5b583          	ld	a1,1246(a1) # 2888 <enable_deadlock_detect+0x1a6>
    23b2:	fff64713          	not	a4,a2
    23b6:	962a                	add	a2,a2,a0
    23b8:	8f71                	and	a4,a4,a2
    23ba:	8f6d                	and	a4,a4,a1
    23bc:	df45                	beqz	a4,2374 <basename+0x8a>
    23be:	b7f9                	j	238c <basename+0xa2>

00000000000023c0 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23c0:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23c4:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23c6:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23ca:	2501                	sext.w	a0,a0
    23cc:	8082                	ret

00000000000023ce <close>:

int close(int fd)
{
	if (fd == 1) {
    23ce:	4785                	li	a5,1
    23d0:	00f50863          	beq	a0,a5,23e0 <close+0x12>
	register long a7 __asm__("a7") = n;
    23d4:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23d8:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23dc:	2501                	sext.w	a0,a0
    23de:	8082                	ret
{
    23e0:	1101                	addi	sp,sp,-32
    23e2:	ec06                	sd	ra,24(sp)
    23e4:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23e6:	cdffe0ef          	jal	ra,10c4 <__write_buffer>
		__clear_buffer();
    23ea:	d03fe0ef          	jal	ra,10ec <__clear_buffer>
    23ee:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23f0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23f4:	00000073          	ecall
}
    23f8:	60e2                	ld	ra,24(sp)
    23fa:	2501                	sext.w	a0,a0
    23fc:	6105                	addi	sp,sp,32
    23fe:	8082                	ret

0000000000002400 <read>:
	register long a7 __asm__("a7") = n;
    2400:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2404:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2408:	8082                	ret

000000000000240a <write>:
	register long a7 __asm__("a7") = n;
    240a:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    240e:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2412:	8082                	ret

0000000000002414 <getpid>:
	register long a7 __asm__("a7") = n;
    2414:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2418:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    241c:	2501                	sext.w	a0,a0
    241e:	8082                	ret

0000000000002420 <getppid>:
	register long a7 __asm__("a7") = n;
    2420:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2424:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2428:	2501                	sext.w	a0,a0
    242a:	8082                	ret

000000000000242c <sched_yield>:
	register long a7 __asm__("a7") = n;
    242c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2430:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2434:	2501                	sext.w	a0,a0
    2436:	8082                	ret

0000000000002438 <fork>:
	register long a7 __asm__("a7") = n;
    2438:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    243c:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2440:	2501                	sext.w	a0,a0
    2442:	8082                	ret

0000000000002444 <exit>:

void exit(int code)
{
    2444:	1141                	addi	sp,sp,-16
    2446:	e406                	sd	ra,8(sp)
    2448:	e022                	sd	s0,0(sp)
    244a:	842a                	mv	s0,a0
	__write_buffer();
    244c:	c79fe0ef          	jal	ra,10c4 <__write_buffer>
	__clear_buffer();
    2450:	c9dfe0ef          	jal	ra,10ec <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2454:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2458:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    245a:	00000073          	ecall
	syscall(SYS_exit, code);
}
    245e:	60a2                	ld	ra,8(sp)
    2460:	6402                	ld	s0,0(sp)
    2462:	0141                	addi	sp,sp,16
    2464:	8082                	ret

0000000000002466 <waitpid>:
	register long a7 __asm__("a7") = n;
    2466:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    246a:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    246e:	2501                	sext.w	a0,a0
    2470:	8082                	ret

0000000000002472 <exec>:
	register long a7 __asm__("a7") = n;
    2472:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2476:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    247a:	2501                	sext.w	a0,a0
    247c:	8082                	ret

000000000000247e <get_mtime>:

int64 get_mtime()
{
    247e:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2480:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2484:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2486:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2488:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    248c:	2501                	sext.w	a0,a0
    248e:	ed01                	bnez	a0,24a6 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2490:	6722                	ld	a4,8(sp)
    2492:	3e800793          	li	a5,1000
    2496:	6682                	ld	a3,0(sp)
    2498:	02f75733          	divu	a4,a4,a5
    249c:	02d78533          	mul	a0,a5,a3
    24a0:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24a2:	0141                	addi	sp,sp,16
    24a4:	8082                	ret
	return -1;
    24a6:	557d                	li	a0,-1
    24a8:	bfed                	j	24a2 <get_mtime+0x24>

00000000000024aa <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24aa:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ae:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24b2:	2501                	sext.w	a0,a0
    24b4:	8082                	ret

00000000000024b6 <sleep>:

int sleep(unsigned long long time)
{
    24b6:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24b8:	880a                	mv	a6,sp
{
    24ba:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24bc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c4:	00000073          	ecall
	if (err == 0) {
    24c8:	2501                	sext.w	a0,a0
    24ca:	ed31                	bnez	a0,2526 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24cc:	6722                	ld	a4,8(sp)
    24ce:	3e800793          	li	a5,1000
    24d2:	6682                	ld	a3,0(sp)
    24d4:	02f75733          	divu	a4,a4,a5
    24d8:	02d787b3          	mul	a5,a5,a3
    24dc:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24de:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24e2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24e4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e6:	00000073          	ecall
	if (err == 0) {
    24ea:	2501                	sext.w	a0,a0
    24ec:	e915                	bnez	a0,2520 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24ee:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24f0:	3e800693          	li	a3,1000
    24f4:	a819                	j	250a <sleep+0x54>
	__asm_syscall("r"(a7))
    24f6:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24fa:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24fe:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2500:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2502:	00000073          	ecall
	if (err == 0) {
    2506:	2501                	sext.w	a0,a0
    2508:	ed01                	bnez	a0,2520 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    250a:	6722                	ld	a4,8(sp)
    250c:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    250e:	07c00893          	li	a7,124
    2512:	02d75733          	divu	a4,a4,a3
    2516:	02f687b3          	mul	a5,a3,a5
    251a:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    251c:	fcc7ede3          	bltu	a5,a2,24f6 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2520:	4501                	li	a0,0
    2522:	0141                	addi	sp,sp,16
    2524:	8082                	ret
    2526:	57fd                	li	a5,-1
    2528:	bf5d                	j	24de <sleep+0x28>

000000000000252a <sys_task_info>:
	register long a7 __asm__("a7") = n;
    252a:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    252e:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2532:	2501                	sext.w	a0,a0
    2534:	8082                	ret

0000000000002536 <set_priority>:
	register long a7 __asm__("a7") = n;
    2536:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    253a:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    253e:	2501                	sext.w	a0,a0
    2540:	8082                	ret

0000000000002542 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2542:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2546:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    254a:	2501                	sext.w	a0,a0
    254c:	8082                	ret

000000000000254e <munmap>:
	register long a7 __asm__("a7") = n;
    254e:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2552:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2556:	2501                	sext.w	a0,a0
    2558:	8082                	ret

000000000000255a <wait>:

int wait(int *code)
{
    255a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    255c:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2560:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2562:	00000073          	ecall
	return waitpid(-1, code);
}
    2566:	2501                	sext.w	a0,a0
    2568:	8082                	ret

000000000000256a <spawn>:
	register long a7 __asm__("a7") = n;
    256a:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    256e:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2572:	2501                	sext.w	a0,a0
    2574:	8082                	ret

0000000000002576 <pipe>:
	register long a7 __asm__("a7") = n;
    2576:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    257a:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <mailread>:
	register long a7 __asm__("a7") = n;
    2582:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2586:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    258a:	2501                	sext.w	a0,a0
    258c:	8082                	ret

000000000000258e <mailwrite>:
	register long a7 __asm__("a7") = n;
    258e:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2592:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2596:	2501                	sext.w	a0,a0
    2598:	8082                	ret

000000000000259a <fstat>:
	register long a7 __asm__("a7") = n;
    259a:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259e:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25a6:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25a8:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25ac:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25ae:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25b2:	2501                	sext.w	a0,a0
    25b4:	8082                	ret

00000000000025b6 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25b6:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25b8:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25bc:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25be:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25c2:	2501                	sext.w	a0,a0
    25c4:	8082                	ret

00000000000025c6 <link>:

int link(char *old_path, char *new_path)
{
    25c6:	87aa                	mv	a5,a0
    25c8:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25ca:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25ce:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25d2:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25d4:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25d8:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25da:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret

00000000000025e2 <unlink>:

int unlink(char *path)
{
    25e2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25e4:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25e8:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25ec:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ee:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25f2:	2501                	sext.w	a0,a0
    25f4:	8082                	ret

00000000000025f6 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25f6:	00000797          	auipc	a5,0x0
    25fa:	3d27b783          	ld	a5,978(a5) # 29c8 <_GLOBAL_OFFSET_TABLE_+0x8>
    25fe:	439c                	lw	a5,0(a5)
    2600:	c799                	beqz	a5,260e <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2602:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2606:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret
{
    260e:	1101                	addi	sp,sp,-32
    2610:	ec06                	sd	ra,24(sp)
    2612:	e42e                	sd	a1,8(sp)
    2614:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2616:	fe7fe0ef          	jal	ra,15fc <enable_thread_io_buffer>
    261a:	65a2                	ld	a1,8(sp)
    261c:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    261e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2622:	00000073          	ecall
}
    2626:	60e2                	ld	ra,24(sp)
    2628:	2501                	sext.w	a0,a0
    262a:	6105                	addi	sp,sp,32
    262c:	8082                	ret

000000000000262e <gettid>:
	register long a7 __asm__("a7") = n;
    262e:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2632:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2636:	2501                	sext.w	a0,a0
    2638:	8082                	ret

000000000000263a <waittid>:

int waittid(int tid)
{
    263a:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    263c:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2640:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2644:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2646:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2648:	00e51e63          	bne	a0,a4,2664 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    264c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2650:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2654:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2658:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    265a:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    265e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2660:	fee506e3          	beq	a0,a4,264c <waittid+0x12>
	}
	return ret;
}
    2664:	8082                	ret

0000000000002666 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2666:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    266a:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    266c:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2674:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2678:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    267a:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2682:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2686:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    268e:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2696:	2501                	sext.w	a0,a0
    2698:	8082                	ret

000000000000269a <semaphore_create>:
	register long a7 __asm__("a7") = n;
    269a:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    269e:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26a6:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26aa:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26b2:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26b6:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <condvar_create>:
	register long a7 __asm__("a7") = n;
    26be:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26c2:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26ca:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26d6:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26da:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26e2:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26e6:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26ea:	2501                	sext.w	a0,a0
    26ec:	8082                	ret
