
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch4_mmap3:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	ac01                	j	1210 <__start_main>

0000000000001002 <main>:
/*
理想结果：对于错误的 mmap 返回 -1，最终输出 Test 04_4 test OK!
*/

int main()
{
    1002:	1101                	addi	sp,sp,-32
	uint64 start = 0x10000000;
	uint64 len = 4096;
	int prot = 3;
	assert_eq(mmap((void *)start, len, prot, MAP_ANONYMOUS, -1), 0);
    1004:	577d                	li	a4,-1
    1006:	4681                	li	a3,0
    1008:	460d                	li	a2,3
    100a:	6585                	lui	a1,0x1
    100c:	10000537          	lui	a0,0x10000
{
    1010:	ec06                	sd	ra,24(sp)
    1012:	e822                	sd	s0,16(sp)
    1014:	e426                	sd	s1,8(sp)
	assert_eq(mmap((void *)start, len, prot, MAP_ANONYMOUS, -1), 0);
    1016:	6b4010ef          	jal	ra,26ca <mmap>
    101a:	1a051563          	bnez	a0,11c4 <main+0x1c2>
	assert_eq(mmap((void *)(start - len), len + 1, prot, MAP_ANONYMOUS, -1),
    101e:	6405                	lui	s0,0x1
    1020:	577d                	li	a4,-1
    1022:	4681                	li	a3,0
    1024:	460d                	li	a2,3
    1026:	00140593          	addi	a1,s0,1 # 1001 <_start+0x1>
    102a:	0ffff537          	lui	a0,0xffff
    102e:	69c010ef          	jal	ra,26ca <mmap>
    1032:	57fd                	li	a5,-1
    1034:	04f50963          	beq	a0,a5,1086 <main+0x84>
    1038:	564010ef          	jal	ra,259c <getpid>
    103c:	84aa                	mv	s1,a0
    103e:	00002517          	auipc	a0,0x2
    1042:	83a50513          	addi	a0,a0,-1990 # 2878 <enable_deadlock_detect+0xe>
    1046:	42c010ef          	jal	ra,2472 <basename>
    104a:	87aa                	mv	a5,a0
    104c:	00140593          	addi	a1,s0,1
    1050:	577d                	li	a4,-1
    1052:	4681                	li	a3,0
    1054:	460d                	li	a2,3
    1056:	0ffff537          	lui	a0,0xffff
    105a:	843e                	mv	s0,a5
    105c:	66e010ef          	jal	ra,26ca <mmap>
    1060:	882a                	mv	a6,a0
    1062:	58fd                	li	a7,-1
    1064:	00002517          	auipc	a0,0x2
    1068:	86450513          	addi	a0,a0,-1948 # 28c8 <enable_deadlock_detect+0x5e>
    106c:	47c1                	li	a5,16
    106e:	8722                	mv	a4,s0
    1070:	86a6                	mv	a3,s1
    1072:	00002617          	auipc	a2,0x2
    1076:	84e60613          	addi	a2,a2,-1970 # 28c0 <enable_deadlock_detect+0x56>
    107a:	45fd                	li	a1,31
    107c:	2ee000ef          	jal	ra,136a <printf>
    1080:	557d                	li	a0,-1
    1082:	54a010ef          	jal	ra,25cc <exit>
		  -1);
	assert_eq(mmap((void *)(start + len + 1), len, prot, MAP_ANONYMOUS, -1),
    1086:	10001437          	lui	s0,0x10001
    108a:	577d                	li	a4,-1
    108c:	4681                	li	a3,0
    108e:	460d                	li	a2,3
    1090:	6585                	lui	a1,0x1
    1092:	00140513          	addi	a0,s0,1 # 10001001 <.got.plt+0xfffe4b9>
    1096:	634010ef          	jal	ra,26ca <mmap>
    109a:	57fd                	li	a5,-1
    109c:	04f50863          	beq	a0,a5,10ec <main+0xea>
    10a0:	4fc010ef          	jal	ra,259c <getpid>
    10a4:	84aa                	mv	s1,a0
    10a6:	00001517          	auipc	a0,0x1
    10aa:	7d250513          	addi	a0,a0,2002 # 2878 <enable_deadlock_detect+0xe>
    10ae:	3c4010ef          	jal	ra,2472 <basename>
    10b2:	87aa                	mv	a5,a0
    10b4:	577d                	li	a4,-1
    10b6:	4681                	li	a3,0
    10b8:	460d                	li	a2,3
    10ba:	6585                	lui	a1,0x1
    10bc:	00140513          	addi	a0,s0,1
    10c0:	843e                	mv	s0,a5
    10c2:	608010ef          	jal	ra,26ca <mmap>
    10c6:	882a                	mv	a6,a0
    10c8:	58fd                	li	a7,-1
    10ca:	00001517          	auipc	a0,0x1
    10ce:	7fe50513          	addi	a0,a0,2046 # 28c8 <enable_deadlock_detect+0x5e>
    10d2:	47c9                	li	a5,18
    10d4:	8722                	mv	a4,s0
    10d6:	86a6                	mv	a3,s1
    10d8:	00001617          	auipc	a2,0x1
    10dc:	7e860613          	addi	a2,a2,2024 # 28c0 <enable_deadlock_detect+0x56>
    10e0:	45fd                	li	a1,31
    10e2:	288000ef          	jal	ra,136a <printf>
    10e6:	557d                	li	a0,-1
    10e8:	4e4010ef          	jal	ra,25cc <exit>
		  -1);
	assert_eq(mmap((void *)(start + len), len, 0, MAP_ANONYMOUS, -1), -1);
    10ec:	577d                	li	a4,-1
    10ee:	4681                	li	a3,0
    10f0:	4601                	li	a2,0
    10f2:	6585                	lui	a1,0x1
    10f4:	10001537          	lui	a0,0x10001
    10f8:	5d2010ef          	jal	ra,26ca <mmap>
    10fc:	57fd                	li	a5,-1
    10fe:	04f50763          	beq	a0,a5,114c <main+0x14a>
    1102:	49a010ef          	jal	ra,259c <getpid>
    1106:	842a                	mv	s0,a0
    1108:	00001517          	auipc	a0,0x1
    110c:	77050513          	addi	a0,a0,1904 # 2878 <enable_deadlock_detect+0xe>
    1110:	362010ef          	jal	ra,2472 <basename>
    1114:	84aa                	mv	s1,a0
    1116:	577d                	li	a4,-1
    1118:	4681                	li	a3,0
    111a:	4601                	li	a2,0
    111c:	6585                	lui	a1,0x1
    111e:	10001537          	lui	a0,0x10001
    1122:	5a8010ef          	jal	ra,26ca <mmap>
    1126:	882a                	mv	a6,a0
    1128:	58fd                	li	a7,-1
    112a:	00001517          	auipc	a0,0x1
    112e:	79e50513          	addi	a0,a0,1950 # 28c8 <enable_deadlock_detect+0x5e>
    1132:	47d1                	li	a5,20
    1134:	8726                	mv	a4,s1
    1136:	86a2                	mv	a3,s0
    1138:	00001617          	auipc	a2,0x1
    113c:	78860613          	addi	a2,a2,1928 # 28c0 <enable_deadlock_detect+0x56>
    1140:	45fd                	li	a1,31
    1142:	228000ef          	jal	ra,136a <printf>
    1146:	557d                	li	a0,-1
    1148:	484010ef          	jal	ra,25cc <exit>
	assert_eq(mmap((void *)(start + len), len, prot | 8, MAP_ANONYMOUS, -1),
    114c:	577d                	li	a4,-1
    114e:	4681                	li	a3,0
    1150:	462d                	li	a2,11
    1152:	6585                	lui	a1,0x1
    1154:	10001537          	lui	a0,0x10001
    1158:	572010ef          	jal	ra,26ca <mmap>
    115c:	57fd                	li	a5,-1
    115e:	04f50763          	beq	a0,a5,11ac <main+0x1aa>
    1162:	43a010ef          	jal	ra,259c <getpid>
    1166:	842a                	mv	s0,a0
    1168:	00001517          	auipc	a0,0x1
    116c:	71050513          	addi	a0,a0,1808 # 2878 <enable_deadlock_detect+0xe>
    1170:	302010ef          	jal	ra,2472 <basename>
    1174:	84aa                	mv	s1,a0
    1176:	577d                	li	a4,-1
    1178:	4681                	li	a3,0
    117a:	462d                	li	a2,11
    117c:	6585                	lui	a1,0x1
    117e:	10001537          	lui	a0,0x10001
    1182:	548010ef          	jal	ra,26ca <mmap>
    1186:	882a                	mv	a6,a0
    1188:	58fd                	li	a7,-1
    118a:	00001517          	auipc	a0,0x1
    118e:	73e50513          	addi	a0,a0,1854 # 28c8 <enable_deadlock_detect+0x5e>
    1192:	47d5                	li	a5,21
    1194:	8726                	mv	a4,s1
    1196:	86a2                	mv	a3,s0
    1198:	00001617          	auipc	a2,0x1
    119c:	72860613          	addi	a2,a2,1832 # 28c0 <enable_deadlock_detect+0x56>
    11a0:	45fd                	li	a1,31
    11a2:	1c8000ef          	jal	ra,136a <printf>
    11a6:	557d                	li	a0,-1
    11a8:	424010ef          	jal	ra,25cc <exit>
		  -1);
	puts("Test 04_3 test OK!");
    11ac:	00001517          	auipc	a0,0x1
    11b0:	75450513          	addi	a0,a0,1876 # 2900 <enable_deadlock_detect+0x96>
    11b4:	0cd000ef          	jal	ra,1a80 <puts>
	return 0;
    11b8:	60e2                	ld	ra,24(sp)
    11ba:	6442                	ld	s0,16(sp)
    11bc:	64a2                	ld	s1,8(sp)
    11be:	4501                	li	a0,0
    11c0:	6105                	addi	sp,sp,32
    11c2:	8082                	ret
	assert_eq(mmap((void *)start, len, prot, MAP_ANONYMOUS, -1), 0);
    11c4:	3d8010ef          	jal	ra,259c <getpid>
    11c8:	842a                	mv	s0,a0
    11ca:	00001517          	auipc	a0,0x1
    11ce:	6ae50513          	addi	a0,a0,1710 # 2878 <enable_deadlock_detect+0xe>
    11d2:	2a0010ef          	jal	ra,2472 <basename>
    11d6:	84aa                	mv	s1,a0
    11d8:	577d                	li	a4,-1
    11da:	4681                	li	a3,0
    11dc:	460d                	li	a2,3
    11de:	6585                	lui	a1,0x1
    11e0:	10000537          	lui	a0,0x10000
    11e4:	4e6010ef          	jal	ra,26ca <mmap>
    11e8:	882a                	mv	a6,a0
    11ea:	4881                	li	a7,0
    11ec:	00001517          	auipc	a0,0x1
    11f0:	6dc50513          	addi	a0,a0,1756 # 28c8 <enable_deadlock_detect+0x5e>
    11f4:	47bd                	li	a5,15
    11f6:	8726                	mv	a4,s1
    11f8:	86a2                	mv	a3,s0
    11fa:	00001617          	auipc	a2,0x1
    11fe:	6c660613          	addi	a2,a2,1734 # 28c0 <enable_deadlock_detect+0x56>
    1202:	45fd                	li	a1,31
    1204:	166000ef          	jal	ra,136a <printf>
    1208:	557d                	li	a0,-1
    120a:	3c2010ef          	jal	ra,25cc <exit>
    120e:	bd01                	j	101e <main+0x1c>

0000000000001210 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1210:	1141                	addi	sp,sp,-16
    1212:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1214:	defff0ef          	jal	ra,1002 <main>
    1218:	3b4010ef          	jal	ra,25cc <exit>
	return 0;
    121c:	60a2                	ld	ra,8(sp)
    121e:	4501                	li	a0,0
    1220:	0141                	addi	sp,sp,16
    1222:	8082                	ret

0000000000001224 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1224:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1226:	4605                	li	a2,1
    1228:	00f10593          	addi	a1,sp,15
    122c:	4501                	li	a0,0
{
    122e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1230:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1234:	354010ef          	jal	ra,2588 <read>
    1238:	4785                	li	a5,1
    123a:	00f51763          	bne	a0,a5,1248 <getchar+0x24>
		return byte;
    123e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1242:	60e2                	ld	ra,24(sp)
    1244:	6105                	addi	sp,sp,32
    1246:	8082                	ret
		return EOF;
    1248:	557d                	li	a0,-1
    124a:	bfe5                	j	1242 <getchar+0x1e>

000000000000124c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    124c:	00001517          	auipc	a0,0x1
    1250:	7c452503          	lw	a0,1988(a0) # 2a10 <buffer_len>
    1254:	e111                	bnez	a0,1258 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1256:	8082                	ret
{
    1258:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    125a:	862a                	mv	a2,a0
    125c:	00001597          	auipc	a1,0x1
    1260:	7bc58593          	addi	a1,a1,1980 # 2a18 <buffer>
    1264:	4505                	li	a0,1
{
    1266:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1268:	32a010ef          	jal	ra,2592 <write>
}
    126c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    126e:	2501                	sext.w	a0,a0
}
    1270:	0141                	addi	sp,sp,16
    1272:	8082                	ret

0000000000001274 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1274:	00001797          	auipc	a5,0x1
    1278:	7807ae23          	sw	zero,1948(a5) # 2a10 <buffer_len>
}
    127c:	8082                	ret

000000000000127e <__fflush>:
	if (buffer_len == 0)
    127e:	00001517          	auipc	a0,0x1
    1282:	79252503          	lw	a0,1938(a0) # 2a10 <buffer_len>
    1286:	e511                	bnez	a0,1292 <__fflush+0x14>
	buffer_len = 0;
    1288:	00001797          	auipc	a5,0x1
    128c:	7807a423          	sw	zero,1928(a5) # 2a10 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1290:	8082                	ret
{
    1292:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1294:	862a                	mv	a2,a0
    1296:	00001597          	auipc	a1,0x1
    129a:	78258593          	addi	a1,a1,1922 # 2a18 <buffer>
    129e:	4505                	li	a0,1
{
    12a0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12a2:	2f0010ef          	jal	ra,2592 <write>
	return r >= 0 ? 0 : r;
    12a6:	0005079b          	sext.w	a5,a0
}
    12aa:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12ac:	0017a793          	slti	a5,a5,1
    12b0:	40f007bb          	negw	a5,a5
    12b4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    12b6:	00001797          	auipc	a5,0x1
    12ba:	7407ad23          	sw	zero,1882(a5) # 2a10 <buffer_len>
	return r >= 0 ? 0 : r;
    12be:	2501                	sext.w	a0,a0
}
    12c0:	0141                	addi	sp,sp,16
    12c2:	8082                	ret

00000000000012c4 <fflush>:

int fflush(int fd)
{
    12c4:	1101                	addi	sp,sp,-32
    12c6:	e822                	sd	s0,16(sp)
    12c8:	ec06                	sd	ra,24(sp)
    12ca:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    12cc:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    12ce:	4401                	li	s0,0
	if (fd == 1) {
    12d0:	00e50863          	beq	a0,a4,12e0 <fflush+0x1c>
}
    12d4:	60e2                	ld	ra,24(sp)
    12d6:	8522                	mv	a0,s0
    12d8:	6442                	ld	s0,16(sp)
    12da:	64a2                	ld	s1,8(sp)
    12dc:	6105                	addi	sp,sp,32
    12de:	8082                	ret
		if (buffer_lock_enabled == 1) {
    12e0:	00001497          	auipc	s1,0x1
    12e4:	73048493          	addi	s1,s1,1840 # 2a10 <buffer_len>
    12e8:	1084a703          	lw	a4,264(s1)
    12ec:	02a70e63          	beq	a4,a0,1328 <fflush+0x64>
	if (buffer_len == 0)
    12f0:	4080                	lw	s0,0(s1)
    12f2:	c00d                	beqz	s0,1314 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    12f4:	8622                	mv	a2,s0
    12f6:	00001597          	auipc	a1,0x1
    12fa:	72258593          	addi	a1,a1,1826 # 2a18 <buffer>
    12fe:	294010ef          	jal	ra,2592 <write>
	return r >= 0 ? 0 : r;
    1302:	0005079b          	sext.w	a5,a0
    1306:	0017a793          	slti	a5,a5,1
    130a:	40f007bb          	negw	a5,a5
    130e:	8d7d                	and	a0,a0,a5
    1310:	0005041b          	sext.w	s0,a0
}
    1314:	60e2                	ld	ra,24(sp)
    1316:	8522                	mv	a0,s0
    1318:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    131a:	00001797          	auipc	a5,0x1
    131e:	6e07ab23          	sw	zero,1782(a5) # 2a10 <buffer_len>
}
    1322:	64a2                	ld	s1,8(sp)
    1324:	6105                	addi	sp,sp,32
    1326:	8082                	ret
			mutex_lock(buffer_lock);
    1328:	10c4a503          	lw	a0,268(s1)
    132c:	4de010ef          	jal	ra,280a <mutex_lock>
	if (buffer_len == 0)
    1330:	4080                	lw	s0,0(s1)
    1332:	e811                	bnez	s0,1346 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1334:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1338:	00001797          	auipc	a5,0x1
    133c:	6c07ac23          	sw	zero,1752(a5) # 2a10 <buffer_len>
			mutex_unlock(buffer_lock);
    1340:	4d6010ef          	jal	ra,2816 <mutex_unlock>
    1344:	bf41                	j	12d4 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1346:	8622                	mv	a2,s0
    1348:	00001597          	auipc	a1,0x1
    134c:	6d058593          	addi	a1,a1,1744 # 2a18 <buffer>
    1350:	4505                	li	a0,1
    1352:	240010ef          	jal	ra,2592 <write>
	return r >= 0 ? 0 : r;
    1356:	0005079b          	sext.w	a5,a0
    135a:	0017a793          	slti	a5,a5,1
    135e:	40f007bb          	negw	a5,a5
    1362:	8d7d                	and	a0,a0,a5
    1364:	0005041b          	sext.w	s0,a0
	return r;
    1368:	b7f1                	j	1334 <fflush+0x70>

000000000000136a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    136a:	7131                	addi	sp,sp,-192
    136c:	e0da                	sd	s6,64(sp)
    136e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1370:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1372:	013c                	addi	a5,sp,136
{
    1374:	f0ca                	sd	s2,96(sp)
    1376:	ecce                	sd	s3,88(sp)
    1378:	e8d2                	sd	s4,80(sp)
    137a:	e4d6                	sd	s5,72(sp)
    137c:	fc86                	sd	ra,120(sp)
    137e:	f8a2                	sd	s0,112(sp)
    1380:	f4a6                	sd	s1,104(sp)
    1382:	89aa                	mv	s3,a0
    1384:	e52e                	sd	a1,136(sp)
    1386:	e932                	sd	a2,144(sp)
    1388:	ed36                	sd	a3,152(sp)
    138a:	f13a                	sd	a4,160(sp)
    138c:	f942                	sd	a6,176(sp)
    138e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1390:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1392:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1396:	00001a17          	auipc	s4,0x1
    139a:	67aa0a13          	addi	s4,s4,1658 # 2a10 <buffer_len>
    139e:	4a85                	li	s5,1
	buf[i++] = '0';
    13a0:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13a4:	0009c783          	lbu	a5,0(s3)
    13a8:	18078663          	beqz	a5,1534 <printf+0x1ca>
    13ac:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13ae:	19278d63          	beq	a5,s2,1548 <printf+0x1de>
    13b2:	0015c783          	lbu	a5,1(a1)
    13b6:	0585                	addi	a1,a1,1
    13b8:	fbfd                	bnez	a5,13ae <printf+0x44>
    13ba:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    13bc:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    13c0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13c4:	1b578863          	beq	a5,s5,1574 <printf+0x20a>
		len = out_unlocked(s, l);
    13c8:	85a2                	mv	a1,s0
    13ca:	854e                	mv	a0,s3
    13cc:	42a000ef          	jal	ra,17f6 <out_unlocked>
		out(f, a, l);
		if (l)
    13d0:	1c041063          	bnez	s0,1590 <printf+0x226>
			continue;
		if (s[1] == 0)
    13d4:	0014c783          	lbu	a5,1(s1)
    13d8:	14078e63          	beqz	a5,1534 <printf+0x1ca>
			break;
		switch (s[1]) {
    13dc:	07300713          	li	a4,115
    13e0:	1ce78863          	beq	a5,a4,15b0 <printf+0x246>
    13e4:	1af76863          	bltu	a4,a5,1594 <printf+0x22a>
    13e8:	06400713          	li	a4,100
    13ec:	22e78063          	beq	a5,a4,160c <printf+0x2a2>
    13f0:	07000713          	li	a4,112
    13f4:	1ee79563          	bne	a5,a4,15de <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    13f8:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13fa:	00001797          	auipc	a5,0x1
    13fe:	72678793          	addi	a5,a5,1830 # 2b20 <digits>
	buf[i++] = '0';
    1402:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1406:	6298                	ld	a4,0(a3)
    1408:	06a1                	addi	a3,a3,8
    140a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    140c:	00471393          	slli	t2,a4,0x4
    1410:	00871293          	slli	t0,a4,0x8
    1414:	00c71f93          	slli	t6,a4,0xc
    1418:	01071f13          	slli	t5,a4,0x10
    141c:	01471e93          	slli	t4,a4,0x14
    1420:	01871e13          	slli	t3,a4,0x18
    1424:	01c71893          	slli	a7,a4,0x1c
    1428:	02471813          	slli	a6,a4,0x24
    142c:	02871513          	slli	a0,a4,0x28
    1430:	02c71593          	slli	a1,a4,0x2c
    1434:	03071613          	slli	a2,a4,0x30
    1438:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    143c:	03c75413          	srli	s0,a4,0x3c
    1440:	01c7531b          	srliw	t1,a4,0x1c
    1444:	03c3d393          	srli	t2,t2,0x3c
    1448:	03c2d293          	srli	t0,t0,0x3c
    144c:	03cfdf93          	srli	t6,t6,0x3c
    1450:	03cf5f13          	srli	t5,t5,0x3c
    1454:	03cede93          	srli	t4,t4,0x3c
    1458:	03ce5e13          	srli	t3,t3,0x3c
    145c:	03c8d893          	srli	a7,a7,0x3c
    1460:	03c85813          	srli	a6,a6,0x3c
    1464:	9171                	srli	a0,a0,0x3c
    1466:	91f1                	srli	a1,a1,0x3c
    1468:	9271                	srli	a2,a2,0x3c
    146a:	92f1                	srli	a3,a3,0x3c
    146c:	95be                	add	a1,a1,a5
    146e:	963e                	add	a2,a2,a5
    1470:	96be                	add	a3,a3,a5
    1472:	943e                	add	s0,s0,a5
    1474:	93be                	add	t2,t2,a5
    1476:	92be                	add	t0,t0,a5
    1478:	9fbe                	add	t6,t6,a5
    147a:	9f3e                	add	t5,t5,a5
    147c:	9ebe                	add	t4,t4,a5
    147e:	9e3e                	add	t3,t3,a5
    1480:	98be                	add	a7,a7,a5
    1482:	933e                	add	t1,t1,a5
    1484:	983e                	add	a6,a6,a5
    1486:	953e                	add	a0,a0,a5
    1488:	0005c983          	lbu	s3,0(a1)
    148c:	00044403          	lbu	s0,0(s0)
    1490:	00064583          	lbu	a1,0(a2)
    1494:	0003c383          	lbu	t2,0(t2)
    1498:	0006c603          	lbu	a2,0(a3)
    149c:	0002c283          	lbu	t0,0(t0)
    14a0:	000fcf83          	lbu	t6,0(t6)
    14a4:	000f4f03          	lbu	t5,0(t5)
    14a8:	000ece83          	lbu	t4,0(t4)
    14ac:	000e4e03          	lbu	t3,0(t3)
    14b0:	0008c883          	lbu	a7,0(a7)
    14b4:	00034303          	lbu	t1,0(t1)
    14b8:	00084803          	lbu	a6,0(a6)
    14bc:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    14c0:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14c4:	92f1                	srli	a3,a3,0x3c
    14c6:	8b3d                	andi	a4,a4,15
    14c8:	96be                	add	a3,a3,a5
    14ca:	97ba                	add	a5,a5,a4
    14cc:	00810d23          	sb	s0,26(sp)
    14d0:	00710da3          	sb	t2,27(sp)
    14d4:	00510e23          	sb	t0,28(sp)
    14d8:	01f10ea3          	sb	t6,29(sp)
    14dc:	01e10f23          	sb	t5,30(sp)
    14e0:	01d10fa3          	sb	t4,31(sp)
    14e4:	03c10023          	sb	t3,32(sp)
    14e8:	031100a3          	sb	a7,33(sp)
    14ec:	02610123          	sb	t1,34(sp)
    14f0:	030101a3          	sb	a6,35(sp)
    14f4:	02a10223          	sb	a0,36(sp)
    14f8:	033102a3          	sb	s3,37(sp)
    14fc:	02b10323          	sb	a1,38(sp)
    1500:	02c103a3          	sb	a2,39(sp)
    1504:	0006c683          	lbu	a3,0(a3)
    1508:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    150c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1510:	02d10423          	sb	a3,40(sp)
    1514:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1518:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    151c:	11578263          	beq	a5,s5,1620 <printf+0x2b6>
		len = out_unlocked(s, l);
    1520:	45c9                	li	a1,18
    1522:	0828                	addi	a0,sp,24
    1524:	2d2000ef          	jal	ra,17f6 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1528:	00248993          	addi	s3,s1,2
		if (!*s)
    152c:	0009c783          	lbu	a5,0(s3)
    1530:	e6079ee3          	bnez	a5,13ac <printf+0x42>
	}
	va_end(ap);
    1534:	70e6                	ld	ra,120(sp)
    1536:	7446                	ld	s0,112(sp)
    1538:	74a6                	ld	s1,104(sp)
    153a:	7906                	ld	s2,96(sp)
    153c:	69e6                	ld	s3,88(sp)
    153e:	6a46                	ld	s4,80(sp)
    1540:	6aa6                	ld	s5,72(sp)
    1542:	6b06                	ld	s6,64(sp)
    1544:	6129                	addi	sp,sp,192
    1546:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1548:	0005c783          	lbu	a5,0(a1)
    154c:	84ae                	mv	s1,a1
    154e:	01278963          	beq	a5,s2,1560 <printf+0x1f6>
    1552:	b5ad                	j	13bc <printf+0x52>
    1554:	0024c783          	lbu	a5,2(s1)
    1558:	0585                	addi	a1,a1,1
    155a:	0489                	addi	s1,s1,2
    155c:	e72790e3          	bne	a5,s2,13bc <printf+0x52>
    1560:	0014c783          	lbu	a5,1(s1)
    1564:	ff2788e3          	beq	a5,s2,1554 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1568:	108a2783          	lw	a5,264(s4)
		l = z - a;
    156c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1570:	e5579ce3          	bne	a5,s5,13c8 <printf+0x5e>
		mutex_lock(buffer_lock);
    1574:	10ca2503          	lw	a0,268(s4)
    1578:	292010ef          	jal	ra,280a <mutex_lock>
		len = out_unlocked(s, l);
    157c:	85a2                	mv	a1,s0
    157e:	854e                	mv	a0,s3
    1580:	276000ef          	jal	ra,17f6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1584:	10ca2503          	lw	a0,268(s4)
    1588:	28e010ef          	jal	ra,2816 <mutex_unlock>
		if (l)
    158c:	e40404e3          	beqz	s0,13d4 <printf+0x6a>
    1590:	89a6                	mv	s3,s1
    1592:	bd09                	j	13a4 <printf+0x3a>
		switch (s[1]) {
    1594:	07800713          	li	a4,120
    1598:	04e79363          	bne	a5,a4,15de <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    159c:	67c2                	ld	a5,16(sp)
    159e:	45c1                	li	a1,16
		s += 2;
    15a0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15a4:	4388                	lw	a0,0(a5)
    15a6:	07a1                	addi	a5,a5,8
    15a8:	e83e                	sd	a5,16(sp)
    15aa:	5f8000ef          	jal	ra,1ba2 <printint.constprop.0>
		s += 2;
    15ae:	bfbd                	j	152c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    15b0:	67c2                	ld	a5,16(sp)
    15b2:	6380                	ld	s0,0(a5)
    15b4:	07a1                	addi	a5,a5,8
    15b6:	e83e                	sd	a5,16(sp)
    15b8:	1c040163          	beqz	s0,177a <printf+0x410>
			l = strnlen(a, 200);
    15bc:	0c800593          	li	a1,200
    15c0:	8522                	mv	a0,s0
    15c2:	3f7000ef          	jal	ra,21b8 <strnlen>
	if (buffer_lock_enabled == 1) {
    15c6:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    15ca:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    15ce:	19578663          	beq	a5,s5,175a <printf+0x3f0>
		len = out_unlocked(s, l);
    15d2:	8522                	mv	a0,s0
    15d4:	222000ef          	jal	ra,17f6 <out_unlocked>
		s += 2;
    15d8:	00248993          	addi	s3,s1,2
    15dc:	bf81                	j	152c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    15de:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15e2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    15e6:	0f578663          	beq	a5,s5,16d2 <printf+0x368>
		len = out_unlocked(s, l);
    15ea:	0828                	addi	a0,sp,24
    15ec:	316000ef          	jal	ra,1902 <out_unlocked.constprop.0>
			putchar(s[1]);
    15f0:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    15f4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15f8:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    15fc:	05578163          	beq	a5,s5,163e <printf+0x2d4>
		len = out_unlocked(s, l);
    1600:	0828                	addi	a0,sp,24
    1602:	300000ef          	jal	ra,1902 <out_unlocked.constprop.0>
		s += 2;
    1606:	00248993          	addi	s3,s1,2
    160a:	b70d                	j	152c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    160c:	67c2                	ld	a5,16(sp)
    160e:	45a9                	li	a1,10
		s += 2;
    1610:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1614:	4388                	lw	a0,0(a5)
    1616:	07a1                	addi	a5,a5,8
    1618:	e83e                	sd	a5,16(sp)
    161a:	588000ef          	jal	ra,1ba2 <printint.constprop.0>
		s += 2;
    161e:	b739                	j	152c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1620:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1624:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1628:	1e2010ef          	jal	ra,280a <mutex_lock>
		len = out_unlocked(s, l);
    162c:	45c9                	li	a1,18
    162e:	0828                	addi	a0,sp,24
    1630:	1c6000ef          	jal	ra,17f6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1634:	10ca2503          	lw	a0,268(s4)
    1638:	1de010ef          	jal	ra,2816 <mutex_unlock>
		s += 2;
    163c:	bdc5                	j	152c <printf+0x1c2>
		mutex_lock(buffer_lock);
    163e:	10ca2503          	lw	a0,268(s4)
    1642:	1c8010ef          	jal	ra,280a <mutex_lock>
		buffer[buffer_len++] = c;
    1646:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    164a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    164e:	0017861b          	addiw	a2,a5,1
    1652:	97d2                	add	a5,a5,s4
    1654:	00ca2023          	sw	a2,0(s4)
    1658:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    165c:	00c6cc63          	blt	a3,a2,1674 <printf+0x30a>
    1660:	47a9                	li	a5,10
    1662:	06f40663          	beq	s0,a5,16ce <printf+0x364>
		mutex_unlock(buffer_lock);
    1666:	10ca2503          	lw	a0,268(s4)
		s += 2;
    166a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    166e:	1a8010ef          	jal	ra,2816 <mutex_unlock>
		s += 2;
    1672:	bd6d                	j	152c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1674:	10000793          	li	a5,256
    1678:	00f61e63          	bne	a2,a5,1694 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    167c:	00001597          	auipc	a1,0x1
    1680:	39c58593          	addi	a1,a1,924 # 2a18 <buffer>
    1684:	4505                	li	a0,1
    1686:	70d000ef          	jal	ra,2592 <write>
	buffer_len = 0;
    168a:	00001797          	auipc	a5,0x1
    168e:	3807a323          	sw	zero,902(a5) # 2a10 <buffer_len>
			if (r < 0) {
    1692:	bfd1                	j	1666 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1694:	709000ef          	jal	ra,259c <getpid>
    1698:	842a                	mv	s0,a0
    169a:	00001517          	auipc	a0,0x1
    169e:	28650513          	addi	a0,a0,646 # 2920 <enable_deadlock_detect+0xb6>
    16a2:	5d1000ef          	jal	ra,2472 <basename>
    16a6:	872a                	mv	a4,a0
    16a8:	00001617          	auipc	a2,0x1
    16ac:	21860613          	addi	a2,a2,536 # 28c0 <enable_deadlock_detect+0x56>
    16b0:	05400793          	li	a5,84
    16b4:	86a2                	mv	a3,s0
    16b6:	45fd                	li	a1,31
    16b8:	00001517          	auipc	a0,0x1
    16bc:	2a850513          	addi	a0,a0,680 # 2960 <enable_deadlock_detect+0xf6>
    16c0:	cabff0ef          	jal	ra,136a <printf>
    16c4:	557d                	li	a0,-1
    16c6:	707000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    16ca:	000a2603          	lw	a2,0(s4)
    16ce:	de41                	beqz	a2,1666 <printf+0x2fc>
    16d0:	b775                	j	167c <printf+0x312>
		mutex_lock(buffer_lock);
    16d2:	10ca2503          	lw	a0,268(s4)
    16d6:	134010ef          	jal	ra,280a <mutex_lock>
		buffer[buffer_len++] = c;
    16da:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16de:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16e2:	0017861b          	addiw	a2,a5,1
    16e6:	97d2                	add	a5,a5,s4
    16e8:	00ca2023          	sw	a2,0(s4)
    16ec:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16f0:	02c6d163          	bge	a3,a2,1712 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    16f4:	10000793          	li	a5,256
    16f8:	02f61263          	bne	a2,a5,171c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    16fc:	00001597          	auipc	a1,0x1
    1700:	31c58593          	addi	a1,a1,796 # 2a18 <buffer>
    1704:	4505                	li	a0,1
    1706:	68d000ef          	jal	ra,2592 <write>
	buffer_len = 0;
    170a:	00001797          	auipc	a5,0x1
    170e:	3007a323          	sw	zero,774(a5) # 2a10 <buffer_len>
		mutex_unlock(buffer_lock);
    1712:	10ca2503          	lw	a0,268(s4)
    1716:	100010ef          	jal	ra,2816 <mutex_unlock>
    171a:	bdd9                	j	15f0 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    171c:	681000ef          	jal	ra,259c <getpid>
    1720:	842a                	mv	s0,a0
    1722:	00001517          	auipc	a0,0x1
    1726:	1fe50513          	addi	a0,a0,510 # 2920 <enable_deadlock_detect+0xb6>
    172a:	549000ef          	jal	ra,2472 <basename>
    172e:	872a                	mv	a4,a0
    1730:	00001617          	auipc	a2,0x1
    1734:	19060613          	addi	a2,a2,400 # 28c0 <enable_deadlock_detect+0x56>
    1738:	05400793          	li	a5,84
    173c:	86a2                	mv	a3,s0
    173e:	45fd                	li	a1,31
    1740:	00001517          	auipc	a0,0x1
    1744:	22050513          	addi	a0,a0,544 # 2960 <enable_deadlock_detect+0xf6>
    1748:	c23ff0ef          	jal	ra,136a <printf>
    174c:	557d                	li	a0,-1
    174e:	67f000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    1752:	000a2603          	lw	a2,0(s4)
    1756:	de55                	beqz	a2,1712 <printf+0x3a8>
    1758:	b755                	j	16fc <printf+0x392>
		mutex_lock(buffer_lock);
    175a:	10ca2503          	lw	a0,268(s4)
    175e:	e42e                	sd	a1,8(sp)
		s += 2;
    1760:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1764:	0a6010ef          	jal	ra,280a <mutex_lock>
		len = out_unlocked(s, l);
    1768:	65a2                	ld	a1,8(sp)
    176a:	8522                	mv	a0,s0
    176c:	08a000ef          	jal	ra,17f6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1770:	10ca2503          	lw	a0,268(s4)
    1774:	0a2010ef          	jal	ra,2816 <mutex_unlock>
		s += 2;
    1778:	bb55                	j	152c <printf+0x1c2>
				a = "(null)";
    177a:	00001417          	auipc	s0,0x1
    177e:	19e40413          	addi	s0,s0,414 # 2918 <enable_deadlock_detect+0xae>
    1782:	bd2d                	j	15bc <printf+0x252>

0000000000001784 <enable_thread_io_buffer>:
{
    1784:	1101                	addi	sp,sp,-32
    1786:	e822                	sd	s0,16(sp)
    1788:	ec06                	sd	ra,24(sp)
    178a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    178c:	00001417          	auipc	s0,0x1
    1790:	28440413          	addi	s0,s0,644 # 2a10 <buffer_len>
    1794:	05a010ef          	jal	ra,27ee <mutex_create>
    1798:	10a42623          	sw	a0,268(s0)
    179c:	00054a63          	bltz	a0,17b0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17a0:	4785                	li	a5,1
}
    17a2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17a4:	10f42423          	sw	a5,264(s0)
}
    17a8:	6442                	ld	s0,16(sp)
    17aa:	64a2                	ld	s1,8(sp)
    17ac:	6105                	addi	sp,sp,32
    17ae:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    17b0:	5ed000ef          	jal	ra,259c <getpid>
    17b4:	84aa                	mv	s1,a0
    17b6:	00001517          	auipc	a0,0x1
    17ba:	16a50513          	addi	a0,a0,362 # 2920 <enable_deadlock_detect+0xb6>
    17be:	4b5000ef          	jal	ra,2472 <basename>
    17c2:	872a                	mv	a4,a0
    17c4:	04800793          	li	a5,72
    17c8:	86a6                	mv	a3,s1
    17ca:	00001517          	auipc	a0,0x1
    17ce:	1d650513          	addi	a0,a0,470 # 29a0 <enable_deadlock_detect+0x136>
    17d2:	00001617          	auipc	a2,0x1
    17d6:	0ee60613          	addi	a2,a2,238 # 28c0 <enable_deadlock_detect+0x56>
    17da:	45fd                	li	a1,31
    17dc:	b8fff0ef          	jal	ra,136a <printf>
    17e0:	557d                	li	a0,-1
    17e2:	5eb000ef          	jal	ra,25cc <exit>
	buffer_lock_enabled = 1;
    17e6:	4785                	li	a5,1
}
    17e8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17ea:	10f42423          	sw	a5,264(s0)
}
    17ee:	6442                	ld	s0,16(sp)
    17f0:	64a2                	ld	s1,8(sp)
    17f2:	6105                	addi	sp,sp,32
    17f4:	8082                	ret

00000000000017f6 <out_unlocked>:
{
    17f6:	7159                	addi	sp,sp,-112
    17f8:	f486                	sd	ra,104(sp)
    17fa:	f0a2                	sd	s0,96(sp)
    17fc:	eca6                	sd	s1,88(sp)
    17fe:	e8ca                	sd	s2,80(sp)
    1800:	e4ce                	sd	s3,72(sp)
    1802:	e0d2                	sd	s4,64(sp)
    1804:	fc56                	sd	s5,56(sp)
    1806:	f85a                	sd	s6,48(sp)
    1808:	f45e                	sd	s7,40(sp)
    180a:	f062                	sd	s8,32(sp)
    180c:	ec66                	sd	s9,24(sp)
    180e:	e86a                	sd	s10,16(sp)
    1810:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1812:	0e058663          	beqz	a1,18fe <out_unlocked+0x108>
    1816:	842a                	mv	s0,a0
    1818:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    181c:	4981                	li	s3,0
    181e:	00001d17          	auipc	s10,0x1
    1822:	1f2d0d13          	addi	s10,s10,498 # 2a10 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1826:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    182a:	00001b17          	auipc	s6,0x1
    182e:	1eeb0b13          	addi	s6,s6,494 # 2a18 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1832:	10000a93          	li	s5,256
    1836:	00001c97          	auipc	s9,0x1
    183a:	0eac8c93          	addi	s9,s9,234 # 2920 <enable_deadlock_detect+0xb6>
    183e:	00001c17          	auipc	s8,0x1
    1842:	082c0c13          	addi	s8,s8,130 # 28c0 <enable_deadlock_detect+0x56>
    1846:	00001b97          	auipc	s7,0x1
    184a:	11ab8b93          	addi	s7,s7,282 # 2960 <enable_deadlock_detect+0xf6>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    184e:	4a29                	li	s4,10
    1850:	a031                	j	185c <out_unlocked+0x66>
    1852:	09468863          	beq	a3,s4,18e2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1856:	0405                	addi	s0,s0,1
    1858:	04848163          	beq	s1,s0,189a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    185c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1860:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1864:	0017861b          	addiw	a2,a5,1
    1868:	97ea                	add	a5,a5,s10
    186a:	00cd2023          	sw	a2,0(s10)
    186e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1872:	fec950e3          	bge	s2,a2,1852 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1876:	05561263          	bne	a2,s5,18ba <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    187a:	85da                	mv	a1,s6
    187c:	4505                	li	a0,1
    187e:	515000ef          	jal	ra,2592 <write>
    1882:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1884:	00001797          	auipc	a5,0x1
    1888:	1807a623          	sw	zero,396(a5) # 2a10 <buffer_len>
			if (r < 0) {
    188c:	06054763          	bltz	a0,18fa <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1890:	0405                	addi	s0,s0,1
			ret += r;
    1892:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1896:	fc8493e3          	bne	s1,s0,185c <out_unlocked+0x66>
}
    189a:	70a6                	ld	ra,104(sp)
    189c:	7406                	ld	s0,96(sp)
    189e:	64e6                	ld	s1,88(sp)
    18a0:	6946                	ld	s2,80(sp)
    18a2:	6a06                	ld	s4,64(sp)
    18a4:	7ae2                	ld	s5,56(sp)
    18a6:	7b42                	ld	s6,48(sp)
    18a8:	7ba2                	ld	s7,40(sp)
    18aa:	7c02                	ld	s8,32(sp)
    18ac:	6ce2                	ld	s9,24(sp)
    18ae:	6d42                	ld	s10,16(sp)
    18b0:	6da2                	ld	s11,8(sp)
    18b2:	854e                	mv	a0,s3
    18b4:	69a6                	ld	s3,72(sp)
    18b6:	6165                	addi	sp,sp,112
    18b8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18ba:	4e3000ef          	jal	ra,259c <getpid>
    18be:	8daa                	mv	s11,a0
    18c0:	8566                	mv	a0,s9
    18c2:	3b1000ef          	jal	ra,2472 <basename>
    18c6:	872a                	mv	a4,a0
    18c8:	8662                	mv	a2,s8
    18ca:	05400793          	li	a5,84
    18ce:	86ee                	mv	a3,s11
    18d0:	45fd                	li	a1,31
    18d2:	855e                	mv	a0,s7
    18d4:	a97ff0ef          	jal	ra,136a <printf>
    18d8:	557d                	li	a0,-1
    18da:	4f3000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    18de:	000d2603          	lw	a2,0(s10)
    18e2:	da35                	beqz	a2,1856 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    18e4:	85da                	mv	a1,s6
    18e6:	4505                	li	a0,1
    18e8:	4ab000ef          	jal	ra,2592 <write>
    18ec:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18ee:	00001797          	auipc	a5,0x1
    18f2:	1207a123          	sw	zero,290(a5) # 2a10 <buffer_len>
			if (r < 0) {
    18f6:	f8055de3          	bgez	a0,1890 <out_unlocked+0x9a>
    18fa:	89aa                	mv	s3,a0
    18fc:	bf79                	j	189a <out_unlocked+0xa4>
	int ret = 0;
    18fe:	4981                	li	s3,0
    1900:	bf69                	j	189a <out_unlocked+0xa4>

0000000000001902 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1902:	1101                	addi	sp,sp,-32
    1904:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1906:	00001497          	auipc	s1,0x1
    190a:	10a48493          	addi	s1,s1,266 # 2a10 <buffer_len>
    190e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1910:	ec06                	sd	ra,24(sp)
    1912:	e822                	sd	s0,16(sp)
		char c = s[i];
    1914:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1918:	0017861b          	addiw	a2,a5,1
    191c:	97a6                	add	a5,a5,s1
    191e:	00e78423          	sb	a4,8(a5)
    1922:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1924:	0ff00793          	li	a5,255
    1928:	00c7cc63          	blt	a5,a2,1940 <out_unlocked.constprop.0+0x3e>
    192c:	47a9                	li	a5,10
    192e:	06f70c63          	beq	a4,a5,19a6 <out_unlocked.constprop.0+0xa4>
    1932:	4601                	li	a2,0
}
    1934:	60e2                	ld	ra,24(sp)
    1936:	6442                	ld	s0,16(sp)
    1938:	64a2                	ld	s1,8(sp)
    193a:	8532                	mv	a0,a2
    193c:	6105                	addi	sp,sp,32
    193e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1940:	10000793          	li	a5,256
    1944:	02f61563          	bne	a2,a5,196e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1948:	00001597          	auipc	a1,0x1
    194c:	0d058593          	addi	a1,a1,208 # 2a18 <buffer>
    1950:	4505                	li	a0,1
    1952:	441000ef          	jal	ra,2592 <write>
}
    1956:	60e2                	ld	ra,24(sp)
    1958:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    195a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    195e:	00001797          	auipc	a5,0x1
    1962:	0a07a923          	sw	zero,178(a5) # 2a10 <buffer_len>
}
    1966:	64a2                	ld	s1,8(sp)
    1968:	8532                	mv	a0,a2
    196a:	6105                	addi	sp,sp,32
    196c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    196e:	42f000ef          	jal	ra,259c <getpid>
    1972:	842a                	mv	s0,a0
    1974:	00001517          	auipc	a0,0x1
    1978:	fac50513          	addi	a0,a0,-84 # 2920 <enable_deadlock_detect+0xb6>
    197c:	2f7000ef          	jal	ra,2472 <basename>
    1980:	872a                	mv	a4,a0
    1982:	00001617          	auipc	a2,0x1
    1986:	f3e60613          	addi	a2,a2,-194 # 28c0 <enable_deadlock_detect+0x56>
    198a:	05400793          	li	a5,84
    198e:	86a2                	mv	a3,s0
    1990:	45fd                	li	a1,31
    1992:	00001517          	auipc	a0,0x1
    1996:	fce50513          	addi	a0,a0,-50 # 2960 <enable_deadlock_detect+0xf6>
    199a:	9d1ff0ef          	jal	ra,136a <printf>
    199e:	557d                	li	a0,-1
    19a0:	42d000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    19a4:	4090                	lw	a2,0(s1)
    19a6:	d659                	beqz	a2,1934 <out_unlocked.constprop.0+0x32>
    19a8:	b745                	j	1948 <out_unlocked.constprop.0+0x46>

00000000000019aa <putchar>:
{
    19aa:	7139                	addi	sp,sp,-64
    19ac:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19ae:	00001497          	auipc	s1,0x1
    19b2:	06248493          	addi	s1,s1,98 # 2a10 <buffer_len>
    19b6:	1084a703          	lw	a4,264(s1)
{
    19ba:	f822                	sd	s0,48(sp)
	char byte = c;
    19bc:	0ff57413          	zext.b	s0,a0
{
    19c0:	fc06                	sd	ra,56(sp)
	char byte = c;
    19c2:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    19c6:	4785                	li	a5,1
    19c8:	00f70d63          	beq	a4,a5,19e2 <putchar+0x38>
		len = out_unlocked(s, l);
    19cc:	01f10513          	addi	a0,sp,31
    19d0:	f33ff0ef          	jal	ra,1902 <out_unlocked.constprop.0>
}
    19d4:	70e2                	ld	ra,56(sp)
    19d6:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    19d8:	862a                	mv	a2,a0
}
    19da:	74a2                	ld	s1,40(sp)
    19dc:	8532                	mv	a0,a2
    19de:	6121                	addi	sp,sp,64
    19e0:	8082                	ret
		mutex_lock(buffer_lock);
    19e2:	10c4a503          	lw	a0,268(s1)
    19e6:	625000ef          	jal	ra,280a <mutex_lock>
		buffer[buffer_len++] = c;
    19ea:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19ec:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19f0:	0017861b          	addiw	a2,a5,1
    19f4:	97a6                	add	a5,a5,s1
    19f6:	c090                	sw	a2,0(s1)
    19f8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19fc:	02c6c263          	blt	a3,a2,1a20 <putchar+0x76>
    1a00:	47a9                	li	a5,10
    1a02:	06f40d63          	beq	s0,a5,1a7c <putchar+0xd2>
    1a06:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a08:	10c4a503          	lw	a0,268(s1)
    1a0c:	e432                	sd	a2,8(sp)
    1a0e:	609000ef          	jal	ra,2816 <mutex_unlock>
    1a12:	6622                	ld	a2,8(sp)
}
    1a14:	70e2                	ld	ra,56(sp)
    1a16:	7442                	ld	s0,48(sp)
    1a18:	74a2                	ld	s1,40(sp)
    1a1a:	8532                	mv	a0,a2
    1a1c:	6121                	addi	sp,sp,64
    1a1e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a20:	10000793          	li	a5,256
    1a24:	02f61063          	bne	a2,a5,1a44 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a28:	00001597          	auipc	a1,0x1
    1a2c:	ff058593          	addi	a1,a1,-16 # 2a18 <buffer>
    1a30:	4505                	li	a0,1
    1a32:	361000ef          	jal	ra,2592 <write>
    1a36:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a3a:	00001797          	auipc	a5,0x1
    1a3e:	fc07ab23          	sw	zero,-42(a5) # 2a10 <buffer_len>
			if (r < 0) {
    1a42:	b7d9                	j	1a08 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a44:	359000ef          	jal	ra,259c <getpid>
    1a48:	842a                	mv	s0,a0
    1a4a:	00001517          	auipc	a0,0x1
    1a4e:	ed650513          	addi	a0,a0,-298 # 2920 <enable_deadlock_detect+0xb6>
    1a52:	221000ef          	jal	ra,2472 <basename>
    1a56:	872a                	mv	a4,a0
    1a58:	00001617          	auipc	a2,0x1
    1a5c:	e6860613          	addi	a2,a2,-408 # 28c0 <enable_deadlock_detect+0x56>
    1a60:	05400793          	li	a5,84
    1a64:	86a2                	mv	a3,s0
    1a66:	45fd                	li	a1,31
    1a68:	00001517          	auipc	a0,0x1
    1a6c:	ef850513          	addi	a0,a0,-264 # 2960 <enable_deadlock_detect+0xf6>
    1a70:	8fbff0ef          	jal	ra,136a <printf>
    1a74:	557d                	li	a0,-1
    1a76:	357000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    1a7a:	4090                	lw	a2,0(s1)
    1a7c:	d651                	beqz	a2,1a08 <putchar+0x5e>
    1a7e:	b76d                	j	1a28 <putchar+0x7e>

0000000000001a80 <puts>:
{
    1a80:	7139                	addi	sp,sp,-64
    1a82:	f822                	sd	s0,48(sp)
    1a84:	f426                	sd	s1,40(sp)
    1a86:	fc06                	sd	ra,56(sp)
    1a88:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a8a:	00001417          	auipc	s0,0x1
    1a8e:	f8640413          	addi	s0,s0,-122 # 2a10 <buffer_len>
{
    1a92:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a94:	638000ef          	jal	ra,20cc <strlen>
	if (buffer_lock_enabled == 1) {
    1a98:	10842703          	lw	a4,264(s0)
    1a9c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a9e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1aa0:	04f70563          	beq	a4,a5,1aea <puts+0x6a>
		len = out_unlocked(s, l);
    1aa4:	8526                	mv	a0,s1
    1aa6:	d51ff0ef          	jal	ra,17f6 <out_unlocked>
    1aaa:	892a                	mv	s2,a0
    1aac:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aae:	00095963          	bgez	s2,1ac0 <puts+0x40>
}
    1ab2:	70e2                	ld	ra,56(sp)
    1ab4:	7442                	ld	s0,48(sp)
    1ab6:	7902                	ld	s2,32(sp)
    1ab8:	8526                	mv	a0,s1
    1aba:	74a2                	ld	s1,40(sp)
    1abc:	6121                	addi	sp,sp,64
    1abe:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1ac0:	10842703          	lw	a4,264(s0)
	char byte = c;
    1ac4:	44a9                	li	s1,10
    1ac6:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1aca:	4785                	li	a5,1
    1acc:	02f70e63          	beq	a4,a5,1b08 <puts+0x88>
		len = out_unlocked(s, l);
    1ad0:	01f10513          	addi	a0,sp,31
    1ad4:	e2fff0ef          	jal	ra,1902 <out_unlocked.constprop.0>
}
    1ad8:	70e2                	ld	ra,56(sp)
    1ada:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1adc:	41f5549b          	sraiw	s1,a0,0x1f
}
    1ae0:	7902                	ld	s2,32(sp)
    1ae2:	8526                	mv	a0,s1
    1ae4:	74a2                	ld	s1,40(sp)
    1ae6:	6121                	addi	sp,sp,64
    1ae8:	8082                	ret
		mutex_lock(buffer_lock);
    1aea:	e42a                	sd	a0,8(sp)
    1aec:	10c42503          	lw	a0,268(s0)
    1af0:	51b000ef          	jal	ra,280a <mutex_lock>
		len = out_unlocked(s, l);
    1af4:	65a2                	ld	a1,8(sp)
    1af6:	8526                	mv	a0,s1
    1af8:	cffff0ef          	jal	ra,17f6 <out_unlocked>
    1afc:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1afe:	10c42503          	lw	a0,268(s0)
    1b02:	515000ef          	jal	ra,2816 <mutex_unlock>
    1b06:	b75d                	j	1aac <puts+0x2c>
		mutex_lock(buffer_lock);
    1b08:	10c42503          	lw	a0,268(s0)
    1b0c:	4ff000ef          	jal	ra,280a <mutex_lock>
		buffer[buffer_len++] = c;
    1b10:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b12:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b16:	0017861b          	addiw	a2,a5,1
    1b1a:	97a2                	add	a5,a5,s0
    1b1c:	c010                	sw	a2,0(s0)
    1b1e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b22:	06c6dc63          	bge	a3,a2,1b9a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b26:	10000793          	li	a5,256
    1b2a:	02f61c63          	bne	a2,a5,1b62 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b2e:	00001597          	auipc	a1,0x1
    1b32:	eea58593          	addi	a1,a1,-278 # 2a18 <buffer>
    1b36:	4505                	li	a0,1
    1b38:	25b000ef          	jal	ra,2592 <write>
			if (r < 0) {
    1b3c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b3e:	00001797          	auipc	a5,0x1
    1b42:	ec07a923          	sw	zero,-302(a5) # 2a10 <buffer_len>
			if (r < 0) {
    1b46:	04054c63          	bltz	a0,1b9e <puts+0x11e>
			if (r < buffer_len) {
    1b4a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b4c:	10c42503          	lw	a0,268(s0)
    1b50:	4c7000ef          	jal	ra,2816 <mutex_unlock>
}
    1b54:	70e2                	ld	ra,56(sp)
    1b56:	7442                	ld	s0,48(sp)
    1b58:	7902                	ld	s2,32(sp)
    1b5a:	8526                	mv	a0,s1
    1b5c:	74a2                	ld	s1,40(sp)
    1b5e:	6121                	addi	sp,sp,64
    1b60:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b62:	23b000ef          	jal	ra,259c <getpid>
    1b66:	84aa                	mv	s1,a0
    1b68:	00001517          	auipc	a0,0x1
    1b6c:	db850513          	addi	a0,a0,-584 # 2920 <enable_deadlock_detect+0xb6>
    1b70:	103000ef          	jal	ra,2472 <basename>
    1b74:	872a                	mv	a4,a0
    1b76:	00001617          	auipc	a2,0x1
    1b7a:	d4a60613          	addi	a2,a2,-694 # 28c0 <enable_deadlock_detect+0x56>
    1b7e:	05400793          	li	a5,84
    1b82:	86a6                	mv	a3,s1
    1b84:	45fd                	li	a1,31
    1b86:	00001517          	auipc	a0,0x1
    1b8a:	dda50513          	addi	a0,a0,-550 # 2960 <enable_deadlock_detect+0xf6>
    1b8e:	fdcff0ef          	jal	ra,136a <printf>
    1b92:	557d                	li	a0,-1
    1b94:	239000ef          	jal	ra,25cc <exit>
	if (buffer_len == 0)
    1b98:	4010                	lw	a2,0(s0)
    1b9a:	da45                	beqz	a2,1b4a <puts+0xca>
    1b9c:	bf49                	j	1b2e <puts+0xae>
    1b9e:	54fd                	li	s1,-1
    1ba0:	b775                	j	1b4c <puts+0xcc>

0000000000001ba2 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ba2:	715d                	addi	sp,sp,-80
    1ba4:	e486                	sd	ra,72(sp)
    1ba6:	e0a2                	sd	s0,64(sp)
    1ba8:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1baa:	14054363          	bltz	a0,1cf0 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bae:	02b577bb          	remuw	a5,a0,a1
    1bb2:	00001617          	auipc	a2,0x1
    1bb6:	f6e60613          	addi	a2,a2,-146 # 2b20 <digits>
	buf[16] = 0;
    1bba:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bbe:	0005871b          	sext.w	a4,a1
    1bc2:	1782                	slli	a5,a5,0x20
    1bc4:	9381                	srli	a5,a5,0x20
    1bc6:	97b2                	add	a5,a5,a2
    1bc8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bcc:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1bd0:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1bd4:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1bd6:	0eb56763          	bltu	a0,a1,1cc4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bda:	02e877bb          	remuw	a5,a6,a4
    1bde:	1782                	slli	a5,a5,0x20
    1be0:	9381                	srli	a5,a5,0x20
    1be2:	97b2                	add	a5,a5,a2
    1be4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1be8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1bec:	02f10323          	sb	a5,38(sp)
    1bf0:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1bf2:	0ce86963          	bltu	a6,a4,1cc4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1bf6:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1bfa:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1bfe:	1582                	slli	a1,a1,0x20
    1c00:	9181                	srli	a1,a1,0x20
    1c02:	95b2                	add	a1,a1,a2
    1c04:	0005c583          	lbu	a1,0(a1)
    1c08:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c0c:	0007859b          	sext.w	a1,a5
    1c10:	16e6e563          	bltu	a3,a4,1d7a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c14:	02e7f6bb          	remuw	a3,a5,a4
    1c18:	1682                	slli	a3,a3,0x20
    1c1a:	9281                	srli	a3,a3,0x20
    1c1c:	96b2                	add	a3,a3,a2
    1c1e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c22:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c26:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c2a:	16e5e163          	bltu	a1,a4,1d8c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c2e:	02e876bb          	remuw	a3,a6,a4
    1c32:	1682                	slli	a3,a3,0x20
    1c34:	9281                	srli	a3,a3,0x20
    1c36:	96b2                	add	a3,a3,a2
    1c38:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c3c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c40:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c44:	14e86d63          	bltu	a6,a4,1d9e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c48:	02e5f6bb          	remuw	a3,a1,a4
    1c4c:	1682                	slli	a3,a3,0x20
    1c4e:	9281                	srli	a3,a3,0x20
    1c50:	96b2                	add	a3,a3,a2
    1c52:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c56:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c5a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1c5e:	10e5e563          	bltu	a1,a4,1d68 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1c62:	02e876bb          	remuw	a3,a6,a4
    1c66:	1682                	slli	a3,a3,0x20
    1c68:	9281                	srli	a3,a3,0x20
    1c6a:	96b2                	add	a3,a3,a2
    1c6c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c70:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c74:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c78:	14e86263          	bltu	a6,a4,1dbc <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c7c:	02e5f6bb          	remuw	a3,a1,a4
    1c80:	1682                	slli	a3,a3,0x20
    1c82:	9281                	srli	a3,a3,0x20
    1c84:	96b2                	add	a3,a3,a2
    1c86:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c8a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c8e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c92:	14e5e463          	bltu	a1,a4,1dda <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1c96:	02e876bb          	remuw	a3,a6,a4
    1c9a:	1682                	slli	a3,a3,0x20
    1c9c:	9281                	srli	a3,a3,0x20
    1c9e:	96b2                	add	a3,a3,a2
    1ca0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ca4:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ca8:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cac:	14e86063          	bltu	a6,a4,1dec <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1cb0:	1782                	slli	a5,a5,0x20
    1cb2:	9381                	srli	a5,a5,0x20
    1cb4:	97b2                	add	a5,a5,a2
    1cb6:	0007c703          	lbu	a4,0(a5)
    1cba:	4799                	li	a5,6
    1cbc:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1cc0:	10054763          	bltz	a0,1dce <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1cc4:	00001497          	auipc	s1,0x1
    1cc8:	d4c48493          	addi	s1,s1,-692 # 2a10 <buffer_len>
    1ccc:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1cd0:	0828                	addi	a0,sp,24
    1cd2:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1cd4:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1cd6:	00f50433          	add	s0,a0,a5
    1cda:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1cdc:	06e68463          	beq	a3,a4,1d44 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1ce0:	8522                	mv	a0,s0
    1ce2:	b15ff0ef          	jal	ra,17f6 <out_unlocked>
}
    1ce6:	60a6                	ld	ra,72(sp)
    1ce8:	6406                	ld	s0,64(sp)
    1cea:	74e2                	ld	s1,56(sp)
    1cec:	6161                	addi	sp,sp,80
    1cee:	8082                	ret
		x = -xx;
    1cf0:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1cf4:	02b877bb          	remuw	a5,a6,a1
    1cf8:	00001617          	auipc	a2,0x1
    1cfc:	e2860613          	addi	a2,a2,-472 # 2b20 <digits>
	buf[16] = 0;
    1d00:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d04:	0005871b          	sext.w	a4,a1
    1d08:	1782                	slli	a5,a5,0x20
    1d0a:	9381                	srli	a5,a5,0x20
    1d0c:	97b2                	add	a5,a5,a2
    1d0e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d12:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d16:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d1a:	08b86b63          	bltu	a6,a1,1db0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d1e:	02e8f7bb          	remuw	a5,a7,a4
    1d22:	1782                	slli	a5,a5,0x20
    1d24:	9381                	srli	a5,a5,0x20
    1d26:	97b2                	add	a5,a5,a2
    1d28:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d2c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d30:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d34:	ece8f1e3          	bgeu	a7,a4,1bf6 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d38:	02d00793          	li	a5,45
    1d3c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d40:	47b5                	li	a5,13
    1d42:	b749                	j	1cc4 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d44:	10c4a503          	lw	a0,268(s1)
    1d48:	e42e                	sd	a1,8(sp)
    1d4a:	2c1000ef          	jal	ra,280a <mutex_lock>
		len = out_unlocked(s, l);
    1d4e:	65a2                	ld	a1,8(sp)
    1d50:	8522                	mv	a0,s0
    1d52:	aa5ff0ef          	jal	ra,17f6 <out_unlocked>
		mutex_unlock(buffer_lock);
    1d56:	10c4a503          	lw	a0,268(s1)
    1d5a:	2bd000ef          	jal	ra,2816 <mutex_unlock>
}
    1d5e:	60a6                	ld	ra,72(sp)
    1d60:	6406                	ld	s0,64(sp)
    1d62:	74e2                	ld	s1,56(sp)
    1d64:	6161                	addi	sp,sp,80
    1d66:	8082                	ret
		buf[i--] = digits[x % base];
    1d68:	47a9                	li	a5,10
	if (sign)
    1d6a:	f4055de3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d6e:	02d00793          	li	a5,45
    1d72:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d76:	47a5                	li	a5,9
    1d78:	b7b1                	j	1cc4 <printint.constprop.0+0x122>
    1d7a:	47b5                	li	a5,13
	if (sign)
    1d7c:	f40554e3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d80:	02d00793          	li	a5,45
    1d84:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d88:	47b1                	li	a5,12
    1d8a:	bf2d                	j	1cc4 <printint.constprop.0+0x122>
    1d8c:	47b1                	li	a5,12
	if (sign)
    1d8e:	f2055be3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d92:	02d00793          	li	a5,45
    1d96:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d9a:	47ad                	li	a5,11
    1d9c:	b725                	j	1cc4 <printint.constprop.0+0x122>
    1d9e:	47ad                	li	a5,11
	if (sign)
    1da0:	f20552e3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1da4:	02d00793          	li	a5,45
    1da8:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1dac:	47a9                	li	a5,10
    1dae:	bf19                	j	1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1db0:	02d00793          	li	a5,45
    1db4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1db8:	47b9                	li	a5,14
    1dba:	b729                	j	1cc4 <printint.constprop.0+0x122>
    1dbc:	47a5                	li	a5,9
	if (sign)
    1dbe:	f00553e3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dc2:	02d00793          	li	a5,45
    1dc6:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1dca:	47a1                	li	a5,8
    1dcc:	bde5                	j	1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dce:	02d00793          	li	a5,45
    1dd2:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1dd6:	4795                	li	a5,5
    1dd8:	b5f5                	j	1cc4 <printint.constprop.0+0x122>
    1dda:	47a1                	li	a5,8
	if (sign)
    1ddc:	ee0554e3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de0:	02d00793          	li	a5,45
    1de4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1de8:	479d                	li	a5,7
    1dea:	bde9                	j	1cc4 <printint.constprop.0+0x122>
    1dec:	479d                	li	a5,7
	if (sign)
    1dee:	ec055be3          	bgez	a0,1cc4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1df2:	02d00793          	li	a5,45
    1df6:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1dfa:	4799                	li	a5,6
    1dfc:	b5e1                	j	1cc4 <printint.constprop.0+0x122>

0000000000001dfe <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1dfe:	02000793          	li	a5,32
    1e02:	00f50663          	beq	a0,a5,1e0e <isspace+0x10>
    1e06:	355d                	addiw	a0,a0,-9
    1e08:	00553513          	sltiu	a0,a0,5
    1e0c:	8082                	ret
    1e0e:	4505                	li	a0,1
}
    1e10:	8082                	ret

0000000000001e12 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e12:	fd05051b          	addiw	a0,a0,-48
}
    1e16:	00a53513          	sltiu	a0,a0,10
    1e1a:	8082                	ret

0000000000001e1c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e1c:	02000613          	li	a2,32
    1e20:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e22:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e26:	ff77869b          	addiw	a3,a5,-9
    1e2a:	04c78c63          	beq	a5,a2,1e82 <atoi+0x66>
    1e2e:	0007871b          	sext.w	a4,a5
    1e32:	04d5f863          	bgeu	a1,a3,1e82 <atoi+0x66>
		s++;
	switch (*s) {
    1e36:	02b00693          	li	a3,43
    1e3a:	04d78963          	beq	a5,a3,1e8c <atoi+0x70>
    1e3e:	02d00693          	li	a3,45
    1e42:	06d78263          	beq	a5,a3,1ea6 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e46:	fd07061b          	addiw	a2,a4,-48
    1e4a:	47a5                	li	a5,9
    1e4c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e4e:	4e01                	li	t3,0
	while (isdigit(*s))
    1e50:	04c7e963          	bltu	a5,a2,1ea2 <atoi+0x86>
	int n = 0, neg = 0;
    1e54:	4501                	li	a0,0
	while (isdigit(*s))
    1e56:	4825                	li	a6,9
    1e58:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1e5c:	0025179b          	slliw	a5,a0,0x2
    1e60:	9fa9                	addw	a5,a5,a0
    1e62:	fd07031b          	addiw	t1,a4,-48
    1e66:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1e6a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1e6e:	0685                	addi	a3,a3,1
    1e70:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e74:	0006071b          	sext.w	a4,a2
    1e78:	feb870e3          	bgeu	a6,a1,1e58 <atoi+0x3c>
	return neg ? n : -n;
    1e7c:	000e0563          	beqz	t3,1e86 <atoi+0x6a>
}
    1e80:	8082                	ret
		s++;
    1e82:	0505                	addi	a0,a0,1
    1e84:	bf79                	j	1e22 <atoi+0x6>
	return neg ? n : -n;
    1e86:	4113053b          	subw	a0,t1,a7
    1e8a:	8082                	ret
	while (isdigit(*s))
    1e8c:	00154703          	lbu	a4,1(a0)
    1e90:	47a5                	li	a5,9
		s++;
    1e92:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e96:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e9a:	4e01                	li	t3,0
	while (isdigit(*s))
    1e9c:	2701                	sext.w	a4,a4
    1e9e:	fac7fbe3          	bgeu	a5,a2,1e54 <atoi+0x38>
    1ea2:	4501                	li	a0,0
}
    1ea4:	8082                	ret
	while (isdigit(*s))
    1ea6:	00154703          	lbu	a4,1(a0)
    1eaa:	47a5                	li	a5,9
		s++;
    1eac:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1eb0:	fd07061b          	addiw	a2,a4,-48
    1eb4:	2701                	sext.w	a4,a4
    1eb6:	fec7e6e3          	bltu	a5,a2,1ea2 <atoi+0x86>
		neg = 1;
    1eba:	4e05                	li	t3,1
    1ebc:	bf61                	j	1e54 <atoi+0x38>

0000000000001ebe <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ebe:	16060d63          	beqz	a2,2038 <memset+0x17a>
    1ec2:	40a007b3          	neg	a5,a0
    1ec6:	8b9d                	andi	a5,a5,7
    1ec8:	00778693          	addi	a3,a5,7
    1ecc:	482d                	li	a6,11
    1ece:	0ff5f713          	zext.b	a4,a1
    1ed2:	fff60593          	addi	a1,a2,-1
    1ed6:	1706e263          	bltu	a3,a6,203a <memset+0x17c>
    1eda:	16d5ea63          	bltu	a1,a3,204e <memset+0x190>
    1ede:	16078563          	beqz	a5,2048 <memset+0x18a>
    1ee2:	00e50023          	sb	a4,0(a0)
    1ee6:	4685                	li	a3,1
    1ee8:	00150593          	addi	a1,a0,1
    1eec:	14d78c63          	beq	a5,a3,2044 <memset+0x186>
    1ef0:	00e500a3          	sb	a4,1(a0)
    1ef4:	4689                	li	a3,2
    1ef6:	00250593          	addi	a1,a0,2
    1efa:	14d78d63          	beq	a5,a3,2054 <memset+0x196>
    1efe:	00e50123          	sb	a4,2(a0)
    1f02:	468d                	li	a3,3
    1f04:	00350593          	addi	a1,a0,3
    1f08:	12d78b63          	beq	a5,a3,203e <memset+0x180>
    1f0c:	00e501a3          	sb	a4,3(a0)
    1f10:	4691                	li	a3,4
    1f12:	00450593          	addi	a1,a0,4
    1f16:	14d78163          	beq	a5,a3,2058 <memset+0x19a>
    1f1a:	00e50223          	sb	a4,4(a0)
    1f1e:	4695                	li	a3,5
    1f20:	00550593          	addi	a1,a0,5
    1f24:	12d78c63          	beq	a5,a3,205c <memset+0x19e>
    1f28:	00e502a3          	sb	a4,5(a0)
    1f2c:	469d                	li	a3,7
    1f2e:	00650593          	addi	a1,a0,6
    1f32:	12d79763          	bne	a5,a3,2060 <memset+0x1a2>
    1f36:	00750593          	addi	a1,a0,7
    1f3a:	00e50323          	sb	a4,6(a0)
    1f3e:	481d                	li	a6,7
    1f40:	00871693          	slli	a3,a4,0x8
    1f44:	01071893          	slli	a7,a4,0x10
    1f48:	8ed9                	or	a3,a3,a4
    1f4a:	01871313          	slli	t1,a4,0x18
    1f4e:	0116e6b3          	or	a3,a3,a7
    1f52:	0066e6b3          	or	a3,a3,t1
    1f56:	02071893          	slli	a7,a4,0x20
    1f5a:	02871e13          	slli	t3,a4,0x28
    1f5e:	0116e6b3          	or	a3,a3,a7
    1f62:	40f60333          	sub	t1,a2,a5
    1f66:	03071893          	slli	a7,a4,0x30
    1f6a:	01c6e6b3          	or	a3,a3,t3
    1f6e:	0116e6b3          	or	a3,a3,a7
    1f72:	03871e13          	slli	t3,a4,0x38
    1f76:	97aa                	add	a5,a5,a0
    1f78:	ff837893          	andi	a7,t1,-8
    1f7c:	01c6e6b3          	or	a3,a3,t3
    1f80:	98be                	add	a7,a7,a5
    1f82:	e394                	sd	a3,0(a5)
    1f84:	07a1                	addi	a5,a5,8
    1f86:	ff179ee3          	bne	a5,a7,1f82 <memset+0xc4>
    1f8a:	ff837893          	andi	a7,t1,-8
    1f8e:	011587b3          	add	a5,a1,a7
    1f92:	010886bb          	addw	a3,a7,a6
    1f96:	0b130663          	beq	t1,a7,2042 <memset+0x184>
    1f9a:	00e78023          	sb	a4,0(a5)
    1f9e:	0016859b          	addiw	a1,a3,1
    1fa2:	08c5fb63          	bgeu	a1,a2,2038 <memset+0x17a>
    1fa6:	00e780a3          	sb	a4,1(a5)
    1faa:	0026859b          	addiw	a1,a3,2
    1fae:	08c5f563          	bgeu	a1,a2,2038 <memset+0x17a>
    1fb2:	00e78123          	sb	a4,2(a5)
    1fb6:	0036859b          	addiw	a1,a3,3
    1fba:	06c5ff63          	bgeu	a1,a2,2038 <memset+0x17a>
    1fbe:	00e781a3          	sb	a4,3(a5)
    1fc2:	0046859b          	addiw	a1,a3,4
    1fc6:	06c5f963          	bgeu	a1,a2,2038 <memset+0x17a>
    1fca:	00e78223          	sb	a4,4(a5)
    1fce:	0056859b          	addiw	a1,a3,5
    1fd2:	06c5f363          	bgeu	a1,a2,2038 <memset+0x17a>
    1fd6:	00e782a3          	sb	a4,5(a5)
    1fda:	0066859b          	addiw	a1,a3,6
    1fde:	04c5fd63          	bgeu	a1,a2,2038 <memset+0x17a>
    1fe2:	00e78323          	sb	a4,6(a5)
    1fe6:	0076859b          	addiw	a1,a3,7
    1fea:	04c5f763          	bgeu	a1,a2,2038 <memset+0x17a>
    1fee:	00e783a3          	sb	a4,7(a5)
    1ff2:	0086859b          	addiw	a1,a3,8
    1ff6:	04c5f163          	bgeu	a1,a2,2038 <memset+0x17a>
    1ffa:	00e78423          	sb	a4,8(a5)
    1ffe:	0096859b          	addiw	a1,a3,9
    2002:	02c5fb63          	bgeu	a1,a2,2038 <memset+0x17a>
    2006:	00e784a3          	sb	a4,9(a5)
    200a:	00a6859b          	addiw	a1,a3,10
    200e:	02c5f563          	bgeu	a1,a2,2038 <memset+0x17a>
    2012:	00e78523          	sb	a4,10(a5)
    2016:	00b6859b          	addiw	a1,a3,11
    201a:	00c5ff63          	bgeu	a1,a2,2038 <memset+0x17a>
    201e:	00e785a3          	sb	a4,11(a5)
    2022:	00c6859b          	addiw	a1,a3,12
    2026:	00c5f963          	bgeu	a1,a2,2038 <memset+0x17a>
    202a:	00e78623          	sb	a4,12(a5)
    202e:	26b5                	addiw	a3,a3,13
    2030:	00c6f463          	bgeu	a3,a2,2038 <memset+0x17a>
    2034:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2038:	8082                	ret
    203a:	46ad                	li	a3,11
    203c:	bd79                	j	1eda <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    203e:	480d                	li	a6,3
    2040:	b701                	j	1f40 <memset+0x82>
    2042:	8082                	ret
    2044:	4805                	li	a6,1
    2046:	bded                	j	1f40 <memset+0x82>
    2048:	85aa                	mv	a1,a0
    204a:	4801                	li	a6,0
    204c:	bdd5                	j	1f40 <memset+0x82>
    204e:	87aa                	mv	a5,a0
    2050:	4681                	li	a3,0
    2052:	b7a1                	j	1f9a <memset+0xdc>
    2054:	4809                	li	a6,2
    2056:	b5ed                	j	1f40 <memset+0x82>
    2058:	4811                	li	a6,4
    205a:	b5dd                	j	1f40 <memset+0x82>
    205c:	4815                	li	a6,5
    205e:	b5cd                	j	1f40 <memset+0x82>
    2060:	4819                	li	a6,6
    2062:	bdf9                	j	1f40 <memset+0x82>

0000000000002064 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2064:	00054783          	lbu	a5,0(a0)
    2068:	0005c703          	lbu	a4,0(a1)
    206c:	00e79863          	bne	a5,a4,207c <strcmp+0x18>
    2070:	0505                	addi	a0,a0,1
    2072:	0585                	addi	a1,a1,1
    2074:	fbe5                	bnez	a5,2064 <strcmp>
    2076:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2078:	9d19                	subw	a0,a0,a4
    207a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    207c:	0007851b          	sext.w	a0,a5
    2080:	bfe5                	j	2078 <strcmp+0x14>

0000000000002082 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2082:	ca15                	beqz	a2,20b6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2084:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2088:	167d                	addi	a2,a2,-1
    208a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    208e:	eb99                	bnez	a5,20a4 <strncmp+0x22>
    2090:	a815                	j	20c4 <strncmp+0x42>
    2092:	00a68e63          	beq	a3,a0,20ae <strncmp+0x2c>
    2096:	0505                	addi	a0,a0,1
    2098:	00f71b63          	bne	a4,a5,20ae <strncmp+0x2c>
    209c:	00054783          	lbu	a5,0(a0)
    20a0:	cf89                	beqz	a5,20ba <strncmp+0x38>
    20a2:	85b2                	mv	a1,a2
    20a4:	0005c703          	lbu	a4,0(a1)
    20a8:	00158613          	addi	a2,a1,1
    20ac:	f37d                	bnez	a4,2092 <strncmp+0x10>
		;
	return *l - *r;
    20ae:	0007851b          	sext.w	a0,a5
    20b2:	9d19                	subw	a0,a0,a4
    20b4:	8082                	ret
		return 0;
    20b6:	4501                	li	a0,0
}
    20b8:	8082                	ret
	return *l - *r;
    20ba:	0015c703          	lbu	a4,1(a1)
    20be:	4501                	li	a0,0
    20c0:	9d19                	subw	a0,a0,a4
    20c2:	8082                	ret
    20c4:	0005c703          	lbu	a4,0(a1)
    20c8:	4501                	li	a0,0
    20ca:	b7e5                	j	20b2 <strncmp+0x30>

00000000000020cc <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    20cc:	00757793          	andi	a5,a0,7
    20d0:	cf89                	beqz	a5,20ea <strlen+0x1e>
    20d2:	87aa                	mv	a5,a0
    20d4:	a029                	j	20de <strlen+0x12>
    20d6:	0785                	addi	a5,a5,1
    20d8:	0077f713          	andi	a4,a5,7
    20dc:	cb01                	beqz	a4,20ec <strlen+0x20>
		if (!*s)
    20de:	0007c703          	lbu	a4,0(a5)
    20e2:	fb75                	bnez	a4,20d6 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    20e4:	40a78533          	sub	a0,a5,a0
}
    20e8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    20ea:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    20ec:	6394                	ld	a3,0(a5)
    20ee:	00001597          	auipc	a1,0x1
    20f2:	90a5b583          	ld	a1,-1782(a1) # 29f8 <enable_deadlock_detect+0x18e>
    20f6:	00001617          	auipc	a2,0x1
    20fa:	90a63603          	ld	a2,-1782(a2) # 2a00 <enable_deadlock_detect+0x196>
    20fe:	a019                	j	2104 <strlen+0x38>
    2100:	6794                	ld	a3,8(a5)
    2102:	07a1                	addi	a5,a5,8
    2104:	00b68733          	add	a4,a3,a1
    2108:	fff6c693          	not	a3,a3
    210c:	8f75                	and	a4,a4,a3
    210e:	8f71                	and	a4,a4,a2
    2110:	db65                	beqz	a4,2100 <strlen+0x34>
	for (; *s; s++)
    2112:	0007c703          	lbu	a4,0(a5)
    2116:	d779                	beqz	a4,20e4 <strlen+0x18>
    2118:	0017c703          	lbu	a4,1(a5)
    211c:	0785                	addi	a5,a5,1
    211e:	d379                	beqz	a4,20e4 <strlen+0x18>
    2120:	0017c703          	lbu	a4,1(a5)
    2124:	0785                	addi	a5,a5,1
    2126:	fb6d                	bnez	a4,2118 <strlen+0x4c>
    2128:	bf75                	j	20e4 <strlen+0x18>

000000000000212a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    212a:	00757713          	andi	a4,a0,7
{
    212e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2130:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2134:	cb19                	beqz	a4,214a <memchr+0x20>
    2136:	ce25                	beqz	a2,21ae <memchr+0x84>
    2138:	0007c703          	lbu	a4,0(a5)
    213c:	04b70e63          	beq	a4,a1,2198 <memchr+0x6e>
    2140:	0785                	addi	a5,a5,1
    2142:	0077f713          	andi	a4,a5,7
    2146:	167d                	addi	a2,a2,-1
    2148:	f77d                	bnez	a4,2136 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    214a:	4501                	li	a0,0
	if (n && *s != c) {
    214c:	c235                	beqz	a2,21b0 <memchr+0x86>
    214e:	0007c703          	lbu	a4,0(a5)
    2152:	04b70363          	beq	a4,a1,2198 <memchr+0x6e>
		size_t k = ONES * c;
    2156:	00001517          	auipc	a0,0x1
    215a:	8b253503          	ld	a0,-1870(a0) # 2a08 <enable_deadlock_detect+0x19e>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    215e:	471d                	li	a4,7
		size_t k = ONES * c;
    2160:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2164:	02c77a63          	bgeu	a4,a2,2198 <memchr+0x6e>
    2168:	00001897          	auipc	a7,0x1
    216c:	8908b883          	ld	a7,-1904(a7) # 29f8 <enable_deadlock_detect+0x18e>
    2170:	00001817          	auipc	a6,0x1
    2174:	89083803          	ld	a6,-1904(a6) # 2a00 <enable_deadlock_detect+0x196>
    2178:	431d                	li	t1,7
    217a:	a029                	j	2184 <memchr+0x5a>
		     w++, n -= SS)
    217c:	1661                	addi	a2,a2,-8
    217e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2180:	02c37963          	bgeu	t1,a2,21b2 <memchr+0x88>
    2184:	6398                	ld	a4,0(a5)
    2186:	8f29                	xor	a4,a4,a0
    2188:	011706b3          	add	a3,a4,a7
    218c:	fff74713          	not	a4,a4
    2190:	8f75                	and	a4,a4,a3
    2192:	01077733          	and	a4,a4,a6
    2196:	d37d                	beqz	a4,217c <memchr+0x52>
{
    2198:	853e                	mv	a0,a5
    219a:	97b2                	add	a5,a5,a2
    219c:	a021                	j	21a4 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    219e:	0505                	addi	a0,a0,1
    21a0:	00f50763          	beq	a0,a5,21ae <memchr+0x84>
    21a4:	00054703          	lbu	a4,0(a0)
    21a8:	feb71be3          	bne	a4,a1,219e <memchr+0x74>
    21ac:	8082                	ret
	return n ? (void *)s : 0;
    21ae:	4501                	li	a0,0
}
    21b0:	8082                	ret
	return n ? (void *)s : 0;
    21b2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    21b4:	f275                	bnez	a2,2198 <memchr+0x6e>
}
    21b6:	8082                	ret

00000000000021b8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    21b8:	1101                	addi	sp,sp,-32
    21ba:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    21bc:	862e                	mv	a2,a1
{
    21be:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    21c0:	4581                	li	a1,0
{
    21c2:	e426                	sd	s1,8(sp)
    21c4:	ec06                	sd	ra,24(sp)
    21c6:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    21c8:	f63ff0ef          	jal	ra,212a <memchr>
	return p ? p - s : n;
    21cc:	c519                	beqz	a0,21da <strnlen+0x22>
}
    21ce:	60e2                	ld	ra,24(sp)
    21d0:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    21d2:	8d05                	sub	a0,a0,s1
}
    21d4:	64a2                	ld	s1,8(sp)
    21d6:	6105                	addi	sp,sp,32
    21d8:	8082                	ret
    21da:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    21dc:	8522                	mv	a0,s0
}
    21de:	6442                	ld	s0,16(sp)
    21e0:	64a2                	ld	s1,8(sp)
    21e2:	6105                	addi	sp,sp,32
    21e4:	8082                	ret

00000000000021e6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    21e6:	00a5c7b3          	xor	a5,a1,a0
    21ea:	8b9d                	andi	a5,a5,7
    21ec:	eb95                	bnez	a5,2220 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    21ee:	0075f793          	andi	a5,a1,7
    21f2:	e7b1                	bnez	a5,223e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    21f4:	6198                	ld	a4,0(a1)
    21f6:	00001617          	auipc	a2,0x1
    21fa:	80263603          	ld	a2,-2046(a2) # 29f8 <enable_deadlock_detect+0x18e>
    21fe:	00001817          	auipc	a6,0x1
    2202:	80283803          	ld	a6,-2046(a6) # 2a00 <enable_deadlock_detect+0x196>
    2206:	a029                	j	2210 <stpcpy+0x2a>
    2208:	05a1                	addi	a1,a1,8
    220a:	e118                	sd	a4,0(a0)
    220c:	6198                	ld	a4,0(a1)
    220e:	0521                	addi	a0,a0,8
    2210:	00c707b3          	add	a5,a4,a2
    2214:	fff74693          	not	a3,a4
    2218:	8ff5                	and	a5,a5,a3
    221a:	0107f7b3          	and	a5,a5,a6
    221e:	d7ed                	beqz	a5,2208 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2220:	0005c783          	lbu	a5,0(a1)
    2224:	00f50023          	sb	a5,0(a0)
    2228:	c785                	beqz	a5,2250 <stpcpy+0x6a>
    222a:	0015c783          	lbu	a5,1(a1)
    222e:	0505                	addi	a0,a0,1
    2230:	0585                	addi	a1,a1,1
    2232:	00f50023          	sb	a5,0(a0)
    2236:	fbf5                	bnez	a5,222a <stpcpy+0x44>
		;
	return d;
}
    2238:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    223a:	0505                	addi	a0,a0,1
    223c:	df45                	beqz	a4,21f4 <stpcpy+0xe>
			if (!(*d = *s))
    223e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2242:	0585                	addi	a1,a1,1
    2244:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2248:	00f50023          	sb	a5,0(a0)
    224c:	f7fd                	bnez	a5,223a <stpcpy+0x54>
}
    224e:	8082                	ret
    2250:	8082                	ret

0000000000002252 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2252:	00a5c7b3          	xor	a5,a1,a0
    2256:	8b9d                	andi	a5,a5,7
    2258:	1a079863          	bnez	a5,2408 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    225c:	0075f793          	andi	a5,a1,7
    2260:	16078463          	beqz	a5,23c8 <stpncpy+0x176>
    2264:	ea01                	bnez	a2,2274 <stpncpy+0x22>
    2266:	a421                	j	246e <stpncpy+0x21c>
    2268:	167d                	addi	a2,a2,-1
    226a:	0505                	addi	a0,a0,1
    226c:	14070e63          	beqz	a4,23c8 <stpncpy+0x176>
    2270:	1a060863          	beqz	a2,2420 <stpncpy+0x1ce>
    2274:	0005c783          	lbu	a5,0(a1)
    2278:	0585                	addi	a1,a1,1
    227a:	0075f713          	andi	a4,a1,7
    227e:	00f50023          	sb	a5,0(a0)
    2282:	f3fd                	bnez	a5,2268 <stpncpy+0x16>
    2284:	4805                	li	a6,1
    2286:	1a061863          	bnez	a2,2436 <stpncpy+0x1e4>
    228a:	40a007b3          	neg	a5,a0
    228e:	8b9d                	andi	a5,a5,7
    2290:	4681                	li	a3,0
    2292:	18061a63          	bnez	a2,2426 <stpncpy+0x1d4>
    2296:	00778713          	addi	a4,a5,7
    229a:	45ad                	li	a1,11
    229c:	18b76363          	bltu	a4,a1,2422 <stpncpy+0x1d0>
    22a0:	1ae6eb63          	bltu	a3,a4,2456 <stpncpy+0x204>
    22a4:	1a078363          	beqz	a5,244a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22a8:	00050023          	sb	zero,0(a0)
    22ac:	4685                	li	a3,1
    22ae:	00150713          	addi	a4,a0,1
    22b2:	18d78f63          	beq	a5,a3,2450 <stpncpy+0x1fe>
    22b6:	000500a3          	sb	zero,1(a0)
    22ba:	4689                	li	a3,2
    22bc:	00250713          	addi	a4,a0,2
    22c0:	18d78e63          	beq	a5,a3,245c <stpncpy+0x20a>
    22c4:	00050123          	sb	zero,2(a0)
    22c8:	468d                	li	a3,3
    22ca:	00350713          	addi	a4,a0,3
    22ce:	16d78c63          	beq	a5,a3,2446 <stpncpy+0x1f4>
    22d2:	000501a3          	sb	zero,3(a0)
    22d6:	4691                	li	a3,4
    22d8:	00450713          	addi	a4,a0,4
    22dc:	18d78263          	beq	a5,a3,2460 <stpncpy+0x20e>
    22e0:	00050223          	sb	zero,4(a0)
    22e4:	4695                	li	a3,5
    22e6:	00550713          	addi	a4,a0,5
    22ea:	16d78d63          	beq	a5,a3,2464 <stpncpy+0x212>
    22ee:	000502a3          	sb	zero,5(a0)
    22f2:	469d                	li	a3,7
    22f4:	00650713          	addi	a4,a0,6
    22f8:	16d79863          	bne	a5,a3,2468 <stpncpy+0x216>
    22fc:	00750713          	addi	a4,a0,7
    2300:	00050323          	sb	zero,6(a0)
    2304:	40f80833          	sub	a6,a6,a5
    2308:	ff887593          	andi	a1,a6,-8
    230c:	97aa                	add	a5,a5,a0
    230e:	95be                	add	a1,a1,a5
    2310:	0007b023          	sd	zero,0(a5)
    2314:	07a1                	addi	a5,a5,8
    2316:	feb79de3          	bne	a5,a1,2310 <stpncpy+0xbe>
    231a:	ff887593          	andi	a1,a6,-8
    231e:	9ead                	addw	a3,a3,a1
    2320:	00b707b3          	add	a5,a4,a1
    2324:	12b80863          	beq	a6,a1,2454 <stpncpy+0x202>
    2328:	00078023          	sb	zero,0(a5)
    232c:	0016871b          	addiw	a4,a3,1
    2330:	0ec77863          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2334:	000780a3          	sb	zero,1(a5)
    2338:	0026871b          	addiw	a4,a3,2
    233c:	0ec77263          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2340:	00078123          	sb	zero,2(a5)
    2344:	0036871b          	addiw	a4,a3,3
    2348:	0cc77c63          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    234c:	000781a3          	sb	zero,3(a5)
    2350:	0046871b          	addiw	a4,a3,4
    2354:	0cc77663          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2358:	00078223          	sb	zero,4(a5)
    235c:	0056871b          	addiw	a4,a3,5
    2360:	0cc77063          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2364:	000782a3          	sb	zero,5(a5)
    2368:	0066871b          	addiw	a4,a3,6
    236c:	0ac77a63          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2370:	00078323          	sb	zero,6(a5)
    2374:	0076871b          	addiw	a4,a3,7
    2378:	0ac77463          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    237c:	000783a3          	sb	zero,7(a5)
    2380:	0086871b          	addiw	a4,a3,8
    2384:	08c77e63          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2388:	00078423          	sb	zero,8(a5)
    238c:	0096871b          	addiw	a4,a3,9
    2390:	08c77863          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    2394:	000784a3          	sb	zero,9(a5)
    2398:	00a6871b          	addiw	a4,a3,10
    239c:	08c77263          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    23a0:	00078523          	sb	zero,10(a5)
    23a4:	00b6871b          	addiw	a4,a3,11
    23a8:	06c77c63          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    23ac:	000785a3          	sb	zero,11(a5)
    23b0:	00c6871b          	addiw	a4,a3,12
    23b4:	06c77663          	bgeu	a4,a2,2420 <stpncpy+0x1ce>
    23b8:	00078623          	sb	zero,12(a5)
    23bc:	26b5                	addiw	a3,a3,13
    23be:	06c6f163          	bgeu	a3,a2,2420 <stpncpy+0x1ce>
    23c2:	000786a3          	sb	zero,13(a5)
    23c6:	8082                	ret
			;
		if (!n || !*s)
    23c8:	c645                	beqz	a2,2470 <stpncpy+0x21e>
    23ca:	0005c783          	lbu	a5,0(a1)
    23ce:	ea078be3          	beqz	a5,2284 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    23d2:	479d                	li	a5,7
    23d4:	02c7ff63          	bgeu	a5,a2,2412 <stpncpy+0x1c0>
    23d8:	00000897          	auipc	a7,0x0
    23dc:	6208b883          	ld	a7,1568(a7) # 29f8 <enable_deadlock_detect+0x18e>
    23e0:	00000817          	auipc	a6,0x0
    23e4:	62083803          	ld	a6,1568(a6) # 2a00 <enable_deadlock_detect+0x196>
    23e8:	431d                	li	t1,7
    23ea:	6198                	ld	a4,0(a1)
    23ec:	011707b3          	add	a5,a4,a7
    23f0:	fff74693          	not	a3,a4
    23f4:	8ff5                	and	a5,a5,a3
    23f6:	0107f7b3          	and	a5,a5,a6
    23fa:	ef81                	bnez	a5,2412 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    23fc:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    23fe:	1661                	addi	a2,a2,-8
    2400:	05a1                	addi	a1,a1,8
    2402:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2404:	fec363e3          	bltu	t1,a2,23ea <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2408:	e609                	bnez	a2,2412 <stpncpy+0x1c0>
    240a:	a08d                	j	246c <stpncpy+0x21a>
    240c:	167d                	addi	a2,a2,-1
    240e:	0505                	addi	a0,a0,1
    2410:	ca01                	beqz	a2,2420 <stpncpy+0x1ce>
    2412:	0005c783          	lbu	a5,0(a1)
    2416:	0585                	addi	a1,a1,1
    2418:	00f50023          	sb	a5,0(a0)
    241c:	fbe5                	bnez	a5,240c <stpncpy+0x1ba>
		;
tail:
    241e:	b59d                	j	2284 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2420:	8082                	ret
    2422:	472d                	li	a4,11
    2424:	bdb5                	j	22a0 <stpncpy+0x4e>
    2426:	00778713          	addi	a4,a5,7
    242a:	45ad                	li	a1,11
    242c:	fff60693          	addi	a3,a2,-1
    2430:	e6b778e3          	bgeu	a4,a1,22a0 <stpncpy+0x4e>
    2434:	b7fd                	j	2422 <stpncpy+0x1d0>
    2436:	40a007b3          	neg	a5,a0
    243a:	8832                	mv	a6,a2
    243c:	8b9d                	andi	a5,a5,7
    243e:	4681                	li	a3,0
    2440:	e4060be3          	beqz	a2,2296 <stpncpy+0x44>
    2444:	b7cd                	j	2426 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2446:	468d                	li	a3,3
    2448:	bd75                	j	2304 <stpncpy+0xb2>
    244a:	872a                	mv	a4,a0
    244c:	4681                	li	a3,0
    244e:	bd5d                	j	2304 <stpncpy+0xb2>
    2450:	4685                	li	a3,1
    2452:	bd4d                	j	2304 <stpncpy+0xb2>
    2454:	8082                	ret
    2456:	87aa                	mv	a5,a0
    2458:	4681                	li	a3,0
    245a:	b5f9                	j	2328 <stpncpy+0xd6>
    245c:	4689                	li	a3,2
    245e:	b55d                	j	2304 <stpncpy+0xb2>
    2460:	4691                	li	a3,4
    2462:	b54d                	j	2304 <stpncpy+0xb2>
    2464:	4695                	li	a3,5
    2466:	bd79                	j	2304 <stpncpy+0xb2>
    2468:	4699                	li	a3,6
    246a:	bd69                	j	2304 <stpncpy+0xb2>
    246c:	8082                	ret
    246e:	8082                	ret
    2470:	8082                	ret

0000000000002472 <basename>:

char *basename(char *s)
{
    2472:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2474:	c54d                	beqz	a0,251e <basename+0xac>
    2476:	00054783          	lbu	a5,0(a0)
		return ".";
    247a:	00000517          	auipc	a0,0x0
    247e:	57650513          	addi	a0,a0,1398 # 29f0 <enable_deadlock_detect+0x186>
	if (!s || !*s)
    2482:	e391                	bnez	a5,2486 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2484:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2486:	0076f713          	andi	a4,a3,7
    248a:	87b6                	mv	a5,a3
    248c:	cf51                	beqz	a4,2528 <basename+0xb6>
    248e:	0785                	addi	a5,a5,1
    2490:	0077f713          	andi	a4,a5,7
    2494:	c729                	beqz	a4,24de <basename+0x6c>
		if (!*s)
    2496:	0007c703          	lbu	a4,0(a5)
    249a:	fb75                	bnez	a4,248e <basename+0x1c>
	return s - a;
    249c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    249e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24a0:	cf8d                	beqz	a5,24da <basename+0x68>
    24a2:	00f68733          	add	a4,a3,a5
    24a6:	02f00593          	li	a1,47
    24aa:	a031                	j	24b6 <basename+0x44>
		s[i] = 0;
    24ac:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    24b0:	17fd                	addi	a5,a5,-1
    24b2:	177d                	addi	a4,a4,-1
    24b4:	c39d                	beqz	a5,24da <basename+0x68>
    24b6:	00074603          	lbu	a2,0(a4)
    24ba:	feb609e3          	beq	a2,a1,24ac <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    24be:	02f00613          	li	a2,47
    24c2:	a011                	j	24c6 <basename+0x54>
    24c4:	cb99                	beqz	a5,24da <basename+0x68>
    24c6:	853e                	mv	a0,a5
    24c8:	17fd                	addi	a5,a5,-1
    24ca:	00f68733          	add	a4,a3,a5
    24ce:	00074703          	lbu	a4,0(a4)
    24d2:	fec719e3          	bne	a4,a2,24c4 <basename+0x52>
	return s + i;
    24d6:	9536                	add	a0,a0,a3
    24d8:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24da:	8536                	mv	a0,a3
    24dc:	8082                	ret
    24de:	6390                	ld	a2,0(a5)
    24e0:	00000517          	auipc	a0,0x0
    24e4:	51853503          	ld	a0,1304(a0) # 29f8 <enable_deadlock_detect+0x18e>
    24e8:	00000597          	auipc	a1,0x0
    24ec:	5185b583          	ld	a1,1304(a1) # 2a00 <enable_deadlock_detect+0x196>
    24f0:	fff64713          	not	a4,a2
    24f4:	962a                	add	a2,a2,a0
    24f6:	8f71                	and	a4,a4,a2
    24f8:	8f6d                	and	a4,a4,a1
    24fa:	eb11                	bnez	a4,250e <basename+0x9c>
    24fc:	6790                	ld	a2,8(a5)
    24fe:	07a1                	addi	a5,a5,8
    2500:	00a60733          	add	a4,a2,a0
    2504:	fff64613          	not	a2,a2
    2508:	8f71                	and	a4,a4,a2
    250a:	8f6d                	and	a4,a4,a1
    250c:	db65                	beqz	a4,24fc <basename+0x8a>
	for (; *s; s++)
    250e:	0007c703          	lbu	a4,0(a5)
    2512:	d749                	beqz	a4,249c <basename+0x2a>
    2514:	0017c703          	lbu	a4,1(a5)
    2518:	0785                	addi	a5,a5,1
    251a:	ff6d                	bnez	a4,2514 <basename+0xa2>
    251c:	b741                	j	249c <basename+0x2a>
		return ".";
    251e:	00000517          	auipc	a0,0x0
    2522:	4d250513          	addi	a0,a0,1234 # 29f0 <enable_deadlock_detect+0x186>
    2526:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2528:	6290                	ld	a2,0(a3)
    252a:	00000517          	auipc	a0,0x0
    252e:	4ce53503          	ld	a0,1230(a0) # 29f8 <enable_deadlock_detect+0x18e>
    2532:	00000597          	auipc	a1,0x0
    2536:	4ce5b583          	ld	a1,1230(a1) # 2a00 <enable_deadlock_detect+0x196>
    253a:	fff64713          	not	a4,a2
    253e:	962a                	add	a2,a2,a0
    2540:	8f71                	and	a4,a4,a2
    2542:	8f6d                	and	a4,a4,a1
    2544:	df45                	beqz	a4,24fc <basename+0x8a>
    2546:	b7f9                	j	2514 <basename+0xa2>

0000000000002548 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2548:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    254c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    254e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2552:	2501                	sext.w	a0,a0
    2554:	8082                	ret

0000000000002556 <close>:

int close(int fd)
{
	if (fd == 1) {
    2556:	4785                	li	a5,1
    2558:	00f50863          	beq	a0,a5,2568 <close+0x12>
	register long a7 __asm__("a7") = n;
    255c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2560:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2564:	2501                	sext.w	a0,a0
    2566:	8082                	ret
{
    2568:	1101                	addi	sp,sp,-32
    256a:	ec06                	sd	ra,24(sp)
    256c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    256e:	cdffe0ef          	jal	ra,124c <__write_buffer>
		__clear_buffer();
    2572:	d03fe0ef          	jal	ra,1274 <__clear_buffer>
    2576:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2578:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    257c:	00000073          	ecall
}
    2580:	60e2                	ld	ra,24(sp)
    2582:	2501                	sext.w	a0,a0
    2584:	6105                	addi	sp,sp,32
    2586:	8082                	ret

0000000000002588 <read>:
	register long a7 __asm__("a7") = n;
    2588:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    258c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2590:	8082                	ret

0000000000002592 <write>:
	register long a7 __asm__("a7") = n;
    2592:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2596:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    259a:	8082                	ret

000000000000259c <getpid>:
	register long a7 __asm__("a7") = n;
    259c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25a0:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25a4:	2501                	sext.w	a0,a0
    25a6:	8082                	ret

00000000000025a8 <getppid>:
	register long a7 __asm__("a7") = n;
    25a8:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25ac:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    25b0:	2501                	sext.w	a0,a0
    25b2:	8082                	ret

00000000000025b4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    25b4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25b8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    25bc:	2501                	sext.w	a0,a0
    25be:	8082                	ret

00000000000025c0 <fork>:
	register long a7 __asm__("a7") = n;
    25c0:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    25c4:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret

00000000000025cc <exit>:

void exit(int code)
{
    25cc:	1141                	addi	sp,sp,-16
    25ce:	e406                	sd	ra,8(sp)
    25d0:	e022                	sd	s0,0(sp)
    25d2:	842a                	mv	s0,a0
	__write_buffer();
    25d4:	c79fe0ef          	jal	ra,124c <__write_buffer>
	__clear_buffer();
    25d8:	c9dfe0ef          	jal	ra,1274 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    25dc:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    25e0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    25e2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    25e6:	60a2                	ld	ra,8(sp)
    25e8:	6402                	ld	s0,0(sp)
    25ea:	0141                	addi	sp,sp,16
    25ec:	8082                	ret

00000000000025ee <waitpid>:
	register long a7 __asm__("a7") = n;
    25ee:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25f2:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    25f6:	2501                	sext.w	a0,a0
    25f8:	8082                	ret

00000000000025fa <exec>:
	register long a7 __asm__("a7") = n;
    25fa:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fe:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2602:	2501                	sext.w	a0,a0
    2604:	8082                	ret

0000000000002606 <get_mtime>:

int64 get_mtime()
{
    2606:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2608:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    260c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    260e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2610:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2614:	2501                	sext.w	a0,a0
    2616:	ed01                	bnez	a0,262e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2618:	6722                	ld	a4,8(sp)
    261a:	3e800793          	li	a5,1000
    261e:	6682                	ld	a3,0(sp)
    2620:	02f75733          	divu	a4,a4,a5
    2624:	02d78533          	mul	a0,a5,a3
    2628:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    262a:	0141                	addi	sp,sp,16
    262c:	8082                	ret
	return -1;
    262e:	557d                	li	a0,-1
    2630:	bfed                	j	262a <get_mtime+0x24>

0000000000002632 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2632:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2636:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <sleep>:

int sleep(unsigned long long time)
{
    263e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2640:	880a                	mv	a6,sp
{
    2642:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2644:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2648:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    264a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    264c:	00000073          	ecall
	if (err == 0) {
    2650:	2501                	sext.w	a0,a0
    2652:	ed31                	bnez	a0,26ae <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2654:	6722                	ld	a4,8(sp)
    2656:	3e800793          	li	a5,1000
    265a:	6682                	ld	a3,0(sp)
    265c:	02f75733          	divu	a4,a4,a5
    2660:	02d787b3          	mul	a5,a5,a3
    2664:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2666:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    266a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    266c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    266e:	00000073          	ecall
	if (err == 0) {
    2672:	2501                	sext.w	a0,a0
    2674:	e915                	bnez	a0,26a8 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2676:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2678:	3e800693          	li	a3,1000
    267c:	a819                	j	2692 <sleep+0x54>
	__asm_syscall("r"(a7))
    267e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2682:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2686:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2688:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268a:	00000073          	ecall
	if (err == 0) {
    268e:	2501                	sext.w	a0,a0
    2690:	ed01                	bnez	a0,26a8 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2692:	6722                	ld	a4,8(sp)
    2694:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2696:	07c00893          	li	a7,124
    269a:	02d75733          	divu	a4,a4,a3
    269e:	02f687b3          	mul	a5,a3,a5
    26a2:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26a4:	fcc7ede3          	bltu	a5,a2,267e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26a8:	4501                	li	a0,0
    26aa:	0141                	addi	sp,sp,16
    26ac:	8082                	ret
    26ae:	57fd                	li	a5,-1
    26b0:	bf5d                	j	2666 <sleep+0x28>

00000000000026b2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    26b2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    26b6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <set_priority>:
	register long a7 __asm__("a7") = n;
    26be:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    26c2:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    26ca:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26ce:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <munmap>:
	register long a7 __asm__("a7") = n;
    26d6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26da:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <wait>:

int wait(int *code)
{
    26e2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26e4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    26e8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ea:	00000073          	ecall
	return waitpid(-1, code);
}
    26ee:	2501                	sext.w	a0,a0
    26f0:	8082                	ret

00000000000026f2 <spawn>:
	register long a7 __asm__("a7") = n;
    26f2:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    26f6:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret

00000000000026fe <pipe>:
	register long a7 __asm__("a7") = n;
    26fe:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2702:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2706:	2501                	sext.w	a0,a0
    2708:	8082                	ret

000000000000270a <mailread>:
	register long a7 __asm__("a7") = n;
    270a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    270e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2712:	2501                	sext.w	a0,a0
    2714:	8082                	ret

0000000000002716 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2716:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    271a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    271e:	2501                	sext.w	a0,a0
    2720:	8082                	ret

0000000000002722 <fstat>:
	register long a7 __asm__("a7") = n;
    2722:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2726:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    272a:	2501                	sext.w	a0,a0
    272c:	8082                	ret

000000000000272e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    272e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2730:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2734:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2736:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    273a:	2501                	sext.w	a0,a0
    273c:	8082                	ret

000000000000273e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    273e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2740:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2744:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2746:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <link>:

int link(char *old_path, char *new_path)
{
    274e:	87aa                	mv	a5,a0
    2750:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2752:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2756:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    275a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    275c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2760:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2762:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2766:	2501                	sext.w	a0,a0
    2768:	8082                	ret

000000000000276a <unlink>:

int unlink(char *path)
{
    276a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    276c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2770:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2774:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2776:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    277a:	2501                	sext.w	a0,a0
    277c:	8082                	ret

000000000000277e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    277e:	00000797          	auipc	a5,0x0
    2782:	3c27b783          	ld	a5,962(a5) # 2b40 <_GLOBAL_OFFSET_TABLE_+0x8>
    2786:	439c                	lw	a5,0(a5)
    2788:	c799                	beqz	a5,2796 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    278a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    278e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2792:	2501                	sext.w	a0,a0
    2794:	8082                	ret
{
    2796:	1101                	addi	sp,sp,-32
    2798:	ec06                	sd	ra,24(sp)
    279a:	e42e                	sd	a1,8(sp)
    279c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    279e:	fe7fe0ef          	jal	ra,1784 <enable_thread_io_buffer>
    27a2:	65a2                	ld	a1,8(sp)
    27a4:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27a6:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27aa:	00000073          	ecall
}
    27ae:	60e2                	ld	ra,24(sp)
    27b0:	2501                	sext.w	a0,a0
    27b2:	6105                	addi	sp,sp,32
    27b4:	8082                	ret

00000000000027b6 <gettid>:
	register long a7 __asm__("a7") = n;
    27b6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    27ba:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    27be:	2501                	sext.w	a0,a0
    27c0:	8082                	ret

00000000000027c2 <waittid>:

int waittid(int tid)
{
    27c2:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    27c4:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    27c8:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    27cc:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    27ce:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27d0:	00e51e63          	bne	a0,a4,27ec <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    27d4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    27d8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    27dc:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    27e0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    27e2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    27e6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27e8:	fee506e3          	beq	a0,a4,27d4 <waittid+0x12>
	}
	return ret;
}
    27ec:	8082                	ret

00000000000027ee <mutex_create>:
	register long a7 __asm__("a7") = n;
    27ee:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    27f2:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    27f4:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    27f8:	2501                	sext.w	a0,a0
    27fa:	8082                	ret

00000000000027fc <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    27fc:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2800:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2802:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2806:	2501                	sext.w	a0,a0
    2808:	8082                	ret

000000000000280a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    280a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    280e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2812:	2501                	sext.w	a0,a0
    2814:	8082                	ret

0000000000002816 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2816:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    281a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    281e:	2501                	sext.w	a0,a0
    2820:	8082                	ret

0000000000002822 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2822:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2826:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    282a:	2501                	sext.w	a0,a0
    282c:	8082                	ret

000000000000282e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    282e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2832:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2836:	2501                	sext.w	a0,a0
    2838:	8082                	ret

000000000000283a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    283a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    283e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2842:	2501                	sext.w	a0,a0
    2844:	8082                	ret

0000000000002846 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2846:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    284a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    284e:	2501                	sext.w	a0,a0
    2850:	8082                	ret

0000000000002852 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2852:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2856:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    285a:	2501                	sext.w	a0,a0
    285c:	8082                	ret

000000000000285e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    285e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2862:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2866:	2501                	sext.w	a0,a0
    2868:	8082                	ret

000000000000286a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    286a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    286e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2872:	2501                	sext.w	a0,a0
    2874:	8082                	ret
