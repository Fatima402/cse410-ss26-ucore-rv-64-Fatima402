
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_setprio:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a26d                	j	11aa <__start_main>

0000000000001002 <main>:

/// 正确输出：（无报错信息）
/// Test set_priority OK!

int main()
{
    1002:	1101                	addi	sp,sp,-32
	assert_eq(set_priority(10), 10);
    1004:	4529                	li	a0,10
{
    1006:	ec06                	sd	ra,24(sp)
    1008:	e822                	sd	s0,16(sp)
    100a:	e426                	sd	s1,8(sp)
    100c:	e04a                	sd	s2,0(sp)
	assert_eq(set_priority(10), 10);
    100e:	64a010ef          	jal	ra,2658 <set_priority>
    1012:	47a9                	li	a5,10
    1014:	04f50263          	beq	a0,a5,1058 <main+0x56>
    1018:	51e010ef          	jal	ra,2536 <getpid>
    101c:	842a                	mv	s0,a0
    101e:	00001517          	auipc	a0,0x1
    1022:	7f250513          	addi	a0,a0,2034 # 2810 <enable_deadlock_detect+0xc>
    1026:	3e6010ef          	jal	ra,240c <basename>
    102a:	84aa                	mv	s1,a0
    102c:	4529                	li	a0,10
    102e:	62a010ef          	jal	ra,2658 <set_priority>
    1032:	882a                	mv	a6,a0
    1034:	48a9                	li	a7,10
    1036:	00002517          	auipc	a0,0x2
    103a:	82a50513          	addi	a0,a0,-2006 # 2860 <enable_deadlock_detect+0x5c>
    103e:	47ad                	li	a5,11
    1040:	8726                	mv	a4,s1
    1042:	86a2                	mv	a3,s0
    1044:	00002617          	auipc	a2,0x2
    1048:	81460613          	addi	a2,a2,-2028 # 2858 <enable_deadlock_detect+0x54>
    104c:	45fd                	li	a1,31
    104e:	2b6000ef          	jal	ra,1304 <printf>
    1052:	557d                	li	a0,-1
    1054:	512010ef          	jal	ra,2566 <exit>
	assert_eq(set_priority(INT_MAX), INT_MAX);
    1058:	80000437          	lui	s0,0x80000
    105c:	fff44513          	not	a0,s0
    1060:	5f8010ef          	jal	ra,2658 <set_priority>
    1064:	fff44413          	not	s0,s0
    1068:	04850263          	beq	a0,s0,10ac <main+0xaa>
    106c:	4ca010ef          	jal	ra,2536 <getpid>
    1070:	84aa                	mv	s1,a0
    1072:	00001517          	auipc	a0,0x1
    1076:	79e50513          	addi	a0,a0,1950 # 2810 <enable_deadlock_detect+0xc>
    107a:	392010ef          	jal	ra,240c <basename>
    107e:	892a                	mv	s2,a0
    1080:	8522                	mv	a0,s0
    1082:	5d6010ef          	jal	ra,2658 <set_priority>
    1086:	882a                	mv	a6,a0
    1088:	88a2                	mv	a7,s0
    108a:	00001517          	auipc	a0,0x1
    108e:	7d650513          	addi	a0,a0,2006 # 2860 <enable_deadlock_detect+0x5c>
    1092:	47b1                	li	a5,12
    1094:	874a                	mv	a4,s2
    1096:	86a6                	mv	a3,s1
    1098:	00001617          	auipc	a2,0x1
    109c:	7c060613          	addi	a2,a2,1984 # 2858 <enable_deadlock_detect+0x54>
    10a0:	45fd                	li	a1,31
    10a2:	262000ef          	jal	ra,1304 <printf>
    10a6:	557d                	li	a0,-1
    10a8:	4be010ef          	jal	ra,2566 <exit>
	assert_eq(set_priority(0), -1);
    10ac:	4501                	li	a0,0
    10ae:	5aa010ef          	jal	ra,2658 <set_priority>
    10b2:	57fd                	li	a5,-1
    10b4:	04f50263          	beq	a0,a5,10f8 <main+0xf6>
    10b8:	47e010ef          	jal	ra,2536 <getpid>
    10bc:	842a                	mv	s0,a0
    10be:	00001517          	auipc	a0,0x1
    10c2:	75250513          	addi	a0,a0,1874 # 2810 <enable_deadlock_detect+0xc>
    10c6:	346010ef          	jal	ra,240c <basename>
    10ca:	84aa                	mv	s1,a0
    10cc:	4501                	li	a0,0
    10ce:	58a010ef          	jal	ra,2658 <set_priority>
    10d2:	882a                	mv	a6,a0
    10d4:	58fd                	li	a7,-1
    10d6:	00001517          	auipc	a0,0x1
    10da:	78a50513          	addi	a0,a0,1930 # 2860 <enable_deadlock_detect+0x5c>
    10de:	47b5                	li	a5,13
    10e0:	8726                	mv	a4,s1
    10e2:	86a2                	mv	a3,s0
    10e4:	00001617          	auipc	a2,0x1
    10e8:	77460613          	addi	a2,a2,1908 # 2858 <enable_deadlock_detect+0x54>
    10ec:	45fd                	li	a1,31
    10ee:	216000ef          	jal	ra,1304 <printf>
    10f2:	557d                	li	a0,-1
    10f4:	472010ef          	jal	ra,2566 <exit>
	assert_eq(set_priority(1), -1);
    10f8:	4505                	li	a0,1
    10fa:	55e010ef          	jal	ra,2658 <set_priority>
    10fe:	57fd                	li	a5,-1
    1100:	04f50263          	beq	a0,a5,1144 <main+0x142>
    1104:	432010ef          	jal	ra,2536 <getpid>
    1108:	842a                	mv	s0,a0
    110a:	00001517          	auipc	a0,0x1
    110e:	70650513          	addi	a0,a0,1798 # 2810 <enable_deadlock_detect+0xc>
    1112:	2fa010ef          	jal	ra,240c <basename>
    1116:	84aa                	mv	s1,a0
    1118:	4505                	li	a0,1
    111a:	53e010ef          	jal	ra,2658 <set_priority>
    111e:	882a                	mv	a6,a0
    1120:	58fd                	li	a7,-1
    1122:	00001517          	auipc	a0,0x1
    1126:	73e50513          	addi	a0,a0,1854 # 2860 <enable_deadlock_detect+0x5c>
    112a:	47b9                	li	a5,14
    112c:	8726                	mv	a4,s1
    112e:	86a2                	mv	a3,s0
    1130:	00001617          	auipc	a2,0x1
    1134:	72860613          	addi	a2,a2,1832 # 2858 <enable_deadlock_detect+0x54>
    1138:	45fd                	li	a1,31
    113a:	1ca000ef          	jal	ra,1304 <printf>
    113e:	557d                	li	a0,-1
    1140:	426010ef          	jal	ra,2566 <exit>
	assert_eq(set_priority(-10), -1);
    1144:	5559                	li	a0,-10
    1146:	512010ef          	jal	ra,2658 <set_priority>
    114a:	57fd                	li	a5,-1
    114c:	04f50263          	beq	a0,a5,1190 <main+0x18e>
    1150:	3e6010ef          	jal	ra,2536 <getpid>
    1154:	842a                	mv	s0,a0
    1156:	00001517          	auipc	a0,0x1
    115a:	6ba50513          	addi	a0,a0,1722 # 2810 <enable_deadlock_detect+0xc>
    115e:	2ae010ef          	jal	ra,240c <basename>
    1162:	84aa                	mv	s1,a0
    1164:	5559                	li	a0,-10
    1166:	4f2010ef          	jal	ra,2658 <set_priority>
    116a:	882a                	mv	a6,a0
    116c:	58fd                	li	a7,-1
    116e:	00001517          	auipc	a0,0x1
    1172:	6f250513          	addi	a0,a0,1778 # 2860 <enable_deadlock_detect+0x5c>
    1176:	47bd                	li	a5,15
    1178:	8726                	mv	a4,s1
    117a:	86a2                	mv	a3,s0
    117c:	00001617          	auipc	a2,0x1
    1180:	6dc60613          	addi	a2,a2,1756 # 2858 <enable_deadlock_detect+0x54>
    1184:	45fd                	li	a1,31
    1186:	17e000ef          	jal	ra,1304 <printf>
    118a:	557d                	li	a0,-1
    118c:	3da010ef          	jal	ra,2566 <exit>
	puts("Test set_priority OK!");
    1190:	00001517          	auipc	a0,0x1
    1194:	70850513          	addi	a0,a0,1800 # 2898 <enable_deadlock_detect+0x94>
    1198:	083000ef          	jal	ra,1a1a <puts>
	return 0;
}
    119c:	60e2                	ld	ra,24(sp)
    119e:	6442                	ld	s0,16(sp)
    11a0:	64a2                	ld	s1,8(sp)
    11a2:	6902                	ld	s2,0(sp)
    11a4:	4501                	li	a0,0
    11a6:	6105                	addi	sp,sp,32
    11a8:	8082                	ret

00000000000011aa <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    11aa:	1141                	addi	sp,sp,-16
    11ac:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    11ae:	e55ff0ef          	jal	ra,1002 <main>
    11b2:	3b4010ef          	jal	ra,2566 <exit>
	return 0;
    11b6:	60a2                	ld	ra,8(sp)
    11b8:	4501                	li	a0,0
    11ba:	0141                	addi	sp,sp,16
    11bc:	8082                	ret

00000000000011be <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    11be:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    11c0:	4605                	li	a2,1
    11c2:	00f10593          	addi	a1,sp,15
    11c6:	4501                	li	a0,0
{
    11c8:	ec06                	sd	ra,24(sp)
	char byte = 0;
    11ca:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    11ce:	354010ef          	jal	ra,2522 <read>
    11d2:	4785                	li	a5,1
    11d4:	00f51763          	bne	a0,a5,11e2 <getchar+0x24>
		return byte;
    11d8:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    11dc:	60e2                	ld	ra,24(sp)
    11de:	6105                	addi	sp,sp,32
    11e0:	8082                	ret
		return EOF;
    11e2:	557d                	li	a0,-1
    11e4:	bfe5                	j	11dc <getchar+0x1e>

00000000000011e6 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    11e6:	00001517          	auipc	a0,0x1
    11ea:	7c252503          	lw	a0,1986(a0) # 29a8 <buffer_len>
    11ee:	e111                	bnez	a0,11f2 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    11f0:	8082                	ret
{
    11f2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11f4:	862a                	mv	a2,a0
    11f6:	00001597          	auipc	a1,0x1
    11fa:	7ba58593          	addi	a1,a1,1978 # 29b0 <buffer>
    11fe:	4505                	li	a0,1
{
    1200:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1202:	32a010ef          	jal	ra,252c <write>
}
    1206:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1208:	2501                	sext.w	a0,a0
}
    120a:	0141                	addi	sp,sp,16
    120c:	8082                	ret

000000000000120e <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    120e:	00001797          	auipc	a5,0x1
    1212:	7807ad23          	sw	zero,1946(a5) # 29a8 <buffer_len>
}
    1216:	8082                	ret

0000000000001218 <__fflush>:
	if (buffer_len == 0)
    1218:	00001517          	auipc	a0,0x1
    121c:	79052503          	lw	a0,1936(a0) # 29a8 <buffer_len>
    1220:	e511                	bnez	a0,122c <__fflush+0x14>
	buffer_len = 0;
    1222:	00001797          	auipc	a5,0x1
    1226:	7807a323          	sw	zero,1926(a5) # 29a8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    122a:	8082                	ret
{
    122c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    122e:	862a                	mv	a2,a0
    1230:	00001597          	auipc	a1,0x1
    1234:	78058593          	addi	a1,a1,1920 # 29b0 <buffer>
    1238:	4505                	li	a0,1
{
    123a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    123c:	2f0010ef          	jal	ra,252c <write>
	return r >= 0 ? 0 : r;
    1240:	0005079b          	sext.w	a5,a0
}
    1244:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1246:	0017a793          	slti	a5,a5,1
    124a:	40f007bb          	negw	a5,a5
    124e:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1250:	00001797          	auipc	a5,0x1
    1254:	7407ac23          	sw	zero,1880(a5) # 29a8 <buffer_len>
	return r >= 0 ? 0 : r;
    1258:	2501                	sext.w	a0,a0
}
    125a:	0141                	addi	sp,sp,16
    125c:	8082                	ret

000000000000125e <fflush>:

int fflush(int fd)
{
    125e:	1101                	addi	sp,sp,-32
    1260:	e822                	sd	s0,16(sp)
    1262:	ec06                	sd	ra,24(sp)
    1264:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1266:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1268:	4401                	li	s0,0
	if (fd == 1) {
    126a:	00e50863          	beq	a0,a4,127a <fflush+0x1c>
}
    126e:	60e2                	ld	ra,24(sp)
    1270:	8522                	mv	a0,s0
    1272:	6442                	ld	s0,16(sp)
    1274:	64a2                	ld	s1,8(sp)
    1276:	6105                	addi	sp,sp,32
    1278:	8082                	ret
		if (buffer_lock_enabled == 1) {
    127a:	00001497          	auipc	s1,0x1
    127e:	72e48493          	addi	s1,s1,1838 # 29a8 <buffer_len>
    1282:	1084a703          	lw	a4,264(s1)
    1286:	02a70e63          	beq	a4,a0,12c2 <fflush+0x64>
	if (buffer_len == 0)
    128a:	4080                	lw	s0,0(s1)
    128c:	c00d                	beqz	s0,12ae <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    128e:	8622                	mv	a2,s0
    1290:	00001597          	auipc	a1,0x1
    1294:	72058593          	addi	a1,a1,1824 # 29b0 <buffer>
    1298:	294010ef          	jal	ra,252c <write>
	return r >= 0 ? 0 : r;
    129c:	0005079b          	sext.w	a5,a0
    12a0:	0017a793          	slti	a5,a5,1
    12a4:	40f007bb          	negw	a5,a5
    12a8:	8d7d                	and	a0,a0,a5
    12aa:	0005041b          	sext.w	s0,a0
}
    12ae:	60e2                	ld	ra,24(sp)
    12b0:	8522                	mv	a0,s0
    12b2:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    12b4:	00001797          	auipc	a5,0x1
    12b8:	6e07aa23          	sw	zero,1780(a5) # 29a8 <buffer_len>
}
    12bc:	64a2                	ld	s1,8(sp)
    12be:	6105                	addi	sp,sp,32
    12c0:	8082                	ret
			mutex_lock(buffer_lock);
    12c2:	10c4a503          	lw	a0,268(s1)
    12c6:	4de010ef          	jal	ra,27a4 <mutex_lock>
	if (buffer_len == 0)
    12ca:	4080                	lw	s0,0(s1)
    12cc:	e811                	bnez	s0,12e0 <fflush+0x82>
			mutex_unlock(buffer_lock);
    12ce:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    12d2:	00001797          	auipc	a5,0x1
    12d6:	6c07ab23          	sw	zero,1750(a5) # 29a8 <buffer_len>
			mutex_unlock(buffer_lock);
    12da:	4d6010ef          	jal	ra,27b0 <mutex_unlock>
    12de:	bf41                	j	126e <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    12e0:	8622                	mv	a2,s0
    12e2:	00001597          	auipc	a1,0x1
    12e6:	6ce58593          	addi	a1,a1,1742 # 29b0 <buffer>
    12ea:	4505                	li	a0,1
    12ec:	240010ef          	jal	ra,252c <write>
	return r >= 0 ? 0 : r;
    12f0:	0005079b          	sext.w	a5,a0
    12f4:	0017a793          	slti	a5,a5,1
    12f8:	40f007bb          	negw	a5,a5
    12fc:	8d7d                	and	a0,a0,a5
    12fe:	0005041b          	sext.w	s0,a0
	return r;
    1302:	b7f1                	j	12ce <fflush+0x70>

0000000000001304 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1304:	7131                	addi	sp,sp,-192
    1306:	e0da                	sd	s6,64(sp)
    1308:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    130a:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    130c:	013c                	addi	a5,sp,136
{
    130e:	f0ca                	sd	s2,96(sp)
    1310:	ecce                	sd	s3,88(sp)
    1312:	e8d2                	sd	s4,80(sp)
    1314:	e4d6                	sd	s5,72(sp)
    1316:	fc86                	sd	ra,120(sp)
    1318:	f8a2                	sd	s0,112(sp)
    131a:	f4a6                	sd	s1,104(sp)
    131c:	89aa                	mv	s3,a0
    131e:	e52e                	sd	a1,136(sp)
    1320:	e932                	sd	a2,144(sp)
    1322:	ed36                	sd	a3,152(sp)
    1324:	f13a                	sd	a4,160(sp)
    1326:	f942                	sd	a6,176(sp)
    1328:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    132a:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    132c:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1330:	00001a17          	auipc	s4,0x1
    1334:	678a0a13          	addi	s4,s4,1656 # 29a8 <buffer_len>
    1338:	4a85                	li	s5,1
	buf[i++] = '0';
    133a:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    133e:	0009c783          	lbu	a5,0(s3)
    1342:	18078663          	beqz	a5,14ce <printf+0x1ca>
    1346:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1348:	19278d63          	beq	a5,s2,14e2 <printf+0x1de>
    134c:	0015c783          	lbu	a5,1(a1)
    1350:	0585                	addi	a1,a1,1
    1352:	fbfd                	bnez	a5,1348 <printf+0x44>
    1354:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1356:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    135a:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    135e:	1b578863          	beq	a5,s5,150e <printf+0x20a>
		len = out_unlocked(s, l);
    1362:	85a2                	mv	a1,s0
    1364:	854e                	mv	a0,s3
    1366:	42a000ef          	jal	ra,1790 <out_unlocked>
		out(f, a, l);
		if (l)
    136a:	1c041063          	bnez	s0,152a <printf+0x226>
			continue;
		if (s[1] == 0)
    136e:	0014c783          	lbu	a5,1(s1)
    1372:	14078e63          	beqz	a5,14ce <printf+0x1ca>
			break;
		switch (s[1]) {
    1376:	07300713          	li	a4,115
    137a:	1ce78863          	beq	a5,a4,154a <printf+0x246>
    137e:	1af76863          	bltu	a4,a5,152e <printf+0x22a>
    1382:	06400713          	li	a4,100
    1386:	22e78063          	beq	a5,a4,15a6 <printf+0x2a2>
    138a:	07000713          	li	a4,112
    138e:	1ee79563          	bne	a5,a4,1578 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1392:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1394:	00001797          	auipc	a5,0x1
    1398:	72478793          	addi	a5,a5,1828 # 2ab8 <digits>
	buf[i++] = '0';
    139c:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    13a0:	6298                	ld	a4,0(a3)
    13a2:	06a1                	addi	a3,a3,8
    13a4:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13a6:	00471393          	slli	t2,a4,0x4
    13aa:	00871293          	slli	t0,a4,0x8
    13ae:	00c71f93          	slli	t6,a4,0xc
    13b2:	01071f13          	slli	t5,a4,0x10
    13b6:	01471e93          	slli	t4,a4,0x14
    13ba:	01871e13          	slli	t3,a4,0x18
    13be:	01c71893          	slli	a7,a4,0x1c
    13c2:	02471813          	slli	a6,a4,0x24
    13c6:	02871513          	slli	a0,a4,0x28
    13ca:	02c71593          	slli	a1,a4,0x2c
    13ce:	03071613          	slli	a2,a4,0x30
    13d2:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13d6:	03c75413          	srli	s0,a4,0x3c
    13da:	01c7531b          	srliw	t1,a4,0x1c
    13de:	03c3d393          	srli	t2,t2,0x3c
    13e2:	03c2d293          	srli	t0,t0,0x3c
    13e6:	03cfdf93          	srli	t6,t6,0x3c
    13ea:	03cf5f13          	srli	t5,t5,0x3c
    13ee:	03cede93          	srli	t4,t4,0x3c
    13f2:	03ce5e13          	srli	t3,t3,0x3c
    13f6:	03c8d893          	srli	a7,a7,0x3c
    13fa:	03c85813          	srli	a6,a6,0x3c
    13fe:	9171                	srli	a0,a0,0x3c
    1400:	91f1                	srli	a1,a1,0x3c
    1402:	9271                	srli	a2,a2,0x3c
    1404:	92f1                	srli	a3,a3,0x3c
    1406:	95be                	add	a1,a1,a5
    1408:	963e                	add	a2,a2,a5
    140a:	96be                	add	a3,a3,a5
    140c:	943e                	add	s0,s0,a5
    140e:	93be                	add	t2,t2,a5
    1410:	92be                	add	t0,t0,a5
    1412:	9fbe                	add	t6,t6,a5
    1414:	9f3e                	add	t5,t5,a5
    1416:	9ebe                	add	t4,t4,a5
    1418:	9e3e                	add	t3,t3,a5
    141a:	98be                	add	a7,a7,a5
    141c:	933e                	add	t1,t1,a5
    141e:	983e                	add	a6,a6,a5
    1420:	953e                	add	a0,a0,a5
    1422:	0005c983          	lbu	s3,0(a1)
    1426:	00044403          	lbu	s0,0(s0) # ffffffff80000000 <.got.plt+0xffffffff7fffd520>
    142a:	00064583          	lbu	a1,0(a2)
    142e:	0003c383          	lbu	t2,0(t2)
    1432:	0006c603          	lbu	a2,0(a3)
    1436:	0002c283          	lbu	t0,0(t0)
    143a:	000fcf83          	lbu	t6,0(t6)
    143e:	000f4f03          	lbu	t5,0(t5)
    1442:	000ece83          	lbu	t4,0(t4)
    1446:	000e4e03          	lbu	t3,0(t3)
    144a:	0008c883          	lbu	a7,0(a7)
    144e:	00034303          	lbu	t1,0(t1)
    1452:	00084803          	lbu	a6,0(a6)
    1456:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    145a:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    145e:	92f1                	srli	a3,a3,0x3c
    1460:	8b3d                	andi	a4,a4,15
    1462:	96be                	add	a3,a3,a5
    1464:	97ba                	add	a5,a5,a4
    1466:	00810d23          	sb	s0,26(sp)
    146a:	00710da3          	sb	t2,27(sp)
    146e:	00510e23          	sb	t0,28(sp)
    1472:	01f10ea3          	sb	t6,29(sp)
    1476:	01e10f23          	sb	t5,30(sp)
    147a:	01d10fa3          	sb	t4,31(sp)
    147e:	03c10023          	sb	t3,32(sp)
    1482:	031100a3          	sb	a7,33(sp)
    1486:	02610123          	sb	t1,34(sp)
    148a:	030101a3          	sb	a6,35(sp)
    148e:	02a10223          	sb	a0,36(sp)
    1492:	033102a3          	sb	s3,37(sp)
    1496:	02b10323          	sb	a1,38(sp)
    149a:	02c103a3          	sb	a2,39(sp)
    149e:	0006c683          	lbu	a3,0(a3)
    14a2:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    14a6:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14aa:	02d10423          	sb	a3,40(sp)
    14ae:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    14b2:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    14b6:	11578263          	beq	a5,s5,15ba <printf+0x2b6>
		len = out_unlocked(s, l);
    14ba:	45c9                	li	a1,18
    14bc:	0828                	addi	a0,sp,24
    14be:	2d2000ef          	jal	ra,1790 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    14c2:	00248993          	addi	s3,s1,2
		if (!*s)
    14c6:	0009c783          	lbu	a5,0(s3)
    14ca:	e6079ee3          	bnez	a5,1346 <printf+0x42>
	}
	va_end(ap);
    14ce:	70e6                	ld	ra,120(sp)
    14d0:	7446                	ld	s0,112(sp)
    14d2:	74a6                	ld	s1,104(sp)
    14d4:	7906                	ld	s2,96(sp)
    14d6:	69e6                	ld	s3,88(sp)
    14d8:	6a46                	ld	s4,80(sp)
    14da:	6aa6                	ld	s5,72(sp)
    14dc:	6b06                	ld	s6,64(sp)
    14de:	6129                	addi	sp,sp,192
    14e0:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    14e2:	0005c783          	lbu	a5,0(a1)
    14e6:	84ae                	mv	s1,a1
    14e8:	01278963          	beq	a5,s2,14fa <printf+0x1f6>
    14ec:	b5ad                	j	1356 <printf+0x52>
    14ee:	0024c783          	lbu	a5,2(s1)
    14f2:	0585                	addi	a1,a1,1
    14f4:	0489                	addi	s1,s1,2
    14f6:	e72790e3          	bne	a5,s2,1356 <printf+0x52>
    14fa:	0014c783          	lbu	a5,1(s1)
    14fe:	ff2788e3          	beq	a5,s2,14ee <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1502:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1506:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    150a:	e5579ce3          	bne	a5,s5,1362 <printf+0x5e>
		mutex_lock(buffer_lock);
    150e:	10ca2503          	lw	a0,268(s4)
    1512:	292010ef          	jal	ra,27a4 <mutex_lock>
		len = out_unlocked(s, l);
    1516:	85a2                	mv	a1,s0
    1518:	854e                	mv	a0,s3
    151a:	276000ef          	jal	ra,1790 <out_unlocked>
		mutex_unlock(buffer_lock);
    151e:	10ca2503          	lw	a0,268(s4)
    1522:	28e010ef          	jal	ra,27b0 <mutex_unlock>
		if (l)
    1526:	e40404e3          	beqz	s0,136e <printf+0x6a>
    152a:	89a6                	mv	s3,s1
    152c:	bd09                	j	133e <printf+0x3a>
		switch (s[1]) {
    152e:	07800713          	li	a4,120
    1532:	04e79363          	bne	a5,a4,1578 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1536:	67c2                	ld	a5,16(sp)
    1538:	45c1                	li	a1,16
		s += 2;
    153a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    153e:	4388                	lw	a0,0(a5)
    1540:	07a1                	addi	a5,a5,8
    1542:	e83e                	sd	a5,16(sp)
    1544:	5f8000ef          	jal	ra,1b3c <printint.constprop.0>
		s += 2;
    1548:	bfbd                	j	14c6 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    154a:	67c2                	ld	a5,16(sp)
    154c:	6380                	ld	s0,0(a5)
    154e:	07a1                	addi	a5,a5,8
    1550:	e83e                	sd	a5,16(sp)
    1552:	1c040163          	beqz	s0,1714 <printf+0x410>
			l = strnlen(a, 200);
    1556:	0c800593          	li	a1,200
    155a:	8522                	mv	a0,s0
    155c:	3f7000ef          	jal	ra,2152 <strnlen>
	if (buffer_lock_enabled == 1) {
    1560:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1564:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1568:	19578663          	beq	a5,s5,16f4 <printf+0x3f0>
		len = out_unlocked(s, l);
    156c:	8522                	mv	a0,s0
    156e:	222000ef          	jal	ra,1790 <out_unlocked>
		s += 2;
    1572:	00248993          	addi	s3,s1,2
    1576:	bf81                	j	14c6 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1578:	108a2783          	lw	a5,264(s4)
	char byte = c;
    157c:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1580:	0f578663          	beq	a5,s5,166c <printf+0x368>
		len = out_unlocked(s, l);
    1584:	0828                	addi	a0,sp,24
    1586:	316000ef          	jal	ra,189c <out_unlocked.constprop.0>
			putchar(s[1]);
    158a:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    158e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1592:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1596:	05578163          	beq	a5,s5,15d8 <printf+0x2d4>
		len = out_unlocked(s, l);
    159a:	0828                	addi	a0,sp,24
    159c:	300000ef          	jal	ra,189c <out_unlocked.constprop.0>
		s += 2;
    15a0:	00248993          	addi	s3,s1,2
    15a4:	b70d                	j	14c6 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    15a6:	67c2                	ld	a5,16(sp)
    15a8:	45a9                	li	a1,10
		s += 2;
    15aa:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    15ae:	4388                	lw	a0,0(a5)
    15b0:	07a1                	addi	a5,a5,8
    15b2:	e83e                	sd	a5,16(sp)
    15b4:	588000ef          	jal	ra,1b3c <printint.constprop.0>
		s += 2;
    15b8:	b739                	j	14c6 <printf+0x1c2>
		mutex_lock(buffer_lock);
    15ba:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15be:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15c2:	1e2010ef          	jal	ra,27a4 <mutex_lock>
		len = out_unlocked(s, l);
    15c6:	45c9                	li	a1,18
    15c8:	0828                	addi	a0,sp,24
    15ca:	1c6000ef          	jal	ra,1790 <out_unlocked>
		mutex_unlock(buffer_lock);
    15ce:	10ca2503          	lw	a0,268(s4)
    15d2:	1de010ef          	jal	ra,27b0 <mutex_unlock>
		s += 2;
    15d6:	bdc5                	j	14c6 <printf+0x1c2>
		mutex_lock(buffer_lock);
    15d8:	10ca2503          	lw	a0,268(s4)
    15dc:	1c8010ef          	jal	ra,27a4 <mutex_lock>
		buffer[buffer_len++] = c;
    15e0:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15e4:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15e8:	0017861b          	addiw	a2,a5,1
    15ec:	97d2                	add	a5,a5,s4
    15ee:	00ca2023          	sw	a2,0(s4)
    15f2:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15f6:	00c6cc63          	blt	a3,a2,160e <printf+0x30a>
    15fa:	47a9                	li	a5,10
    15fc:	06f40663          	beq	s0,a5,1668 <printf+0x364>
		mutex_unlock(buffer_lock);
    1600:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1604:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1608:	1a8010ef          	jal	ra,27b0 <mutex_unlock>
		s += 2;
    160c:	bd6d                	j	14c6 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    160e:	10000793          	li	a5,256
    1612:	00f61e63          	bne	a2,a5,162e <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1616:	00001597          	auipc	a1,0x1
    161a:	39a58593          	addi	a1,a1,922 # 29b0 <buffer>
    161e:	4505                	li	a0,1
    1620:	70d000ef          	jal	ra,252c <write>
	buffer_len = 0;
    1624:	00001797          	auipc	a5,0x1
    1628:	3807a223          	sw	zero,900(a5) # 29a8 <buffer_len>
			if (r < 0) {
    162c:	bfd1                	j	1600 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    162e:	709000ef          	jal	ra,2536 <getpid>
    1632:	842a                	mv	s0,a0
    1634:	00001517          	auipc	a0,0x1
    1638:	28450513          	addi	a0,a0,644 # 28b8 <enable_deadlock_detect+0xb4>
    163c:	5d1000ef          	jal	ra,240c <basename>
    1640:	872a                	mv	a4,a0
    1642:	00001617          	auipc	a2,0x1
    1646:	21660613          	addi	a2,a2,534 # 2858 <enable_deadlock_detect+0x54>
    164a:	05400793          	li	a5,84
    164e:	86a2                	mv	a3,s0
    1650:	45fd                	li	a1,31
    1652:	00001517          	auipc	a0,0x1
    1656:	2a650513          	addi	a0,a0,678 # 28f8 <enable_deadlock_detect+0xf4>
    165a:	cabff0ef          	jal	ra,1304 <printf>
    165e:	557d                	li	a0,-1
    1660:	707000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    1664:	000a2603          	lw	a2,0(s4)
    1668:	de41                	beqz	a2,1600 <printf+0x2fc>
    166a:	b775                	j	1616 <printf+0x312>
		mutex_lock(buffer_lock);
    166c:	10ca2503          	lw	a0,268(s4)
    1670:	134010ef          	jal	ra,27a4 <mutex_lock>
		buffer[buffer_len++] = c;
    1674:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1678:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    167c:	0017861b          	addiw	a2,a5,1
    1680:	97d2                	add	a5,a5,s4
    1682:	00ca2023          	sw	a2,0(s4)
    1686:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168a:	02c6d163          	bge	a3,a2,16ac <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    168e:	10000793          	li	a5,256
    1692:	02f61263          	bne	a2,a5,16b6 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1696:	00001597          	auipc	a1,0x1
    169a:	31a58593          	addi	a1,a1,794 # 29b0 <buffer>
    169e:	4505                	li	a0,1
    16a0:	68d000ef          	jal	ra,252c <write>
	buffer_len = 0;
    16a4:	00001797          	auipc	a5,0x1
    16a8:	3007a223          	sw	zero,772(a5) # 29a8 <buffer_len>
		mutex_unlock(buffer_lock);
    16ac:	10ca2503          	lw	a0,268(s4)
    16b0:	100010ef          	jal	ra,27b0 <mutex_unlock>
    16b4:	bdd9                	j	158a <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    16b6:	681000ef          	jal	ra,2536 <getpid>
    16ba:	842a                	mv	s0,a0
    16bc:	00001517          	auipc	a0,0x1
    16c0:	1fc50513          	addi	a0,a0,508 # 28b8 <enable_deadlock_detect+0xb4>
    16c4:	549000ef          	jal	ra,240c <basename>
    16c8:	872a                	mv	a4,a0
    16ca:	00001617          	auipc	a2,0x1
    16ce:	18e60613          	addi	a2,a2,398 # 2858 <enable_deadlock_detect+0x54>
    16d2:	05400793          	li	a5,84
    16d6:	86a2                	mv	a3,s0
    16d8:	45fd                	li	a1,31
    16da:	00001517          	auipc	a0,0x1
    16de:	21e50513          	addi	a0,a0,542 # 28f8 <enable_deadlock_detect+0xf4>
    16e2:	c23ff0ef          	jal	ra,1304 <printf>
    16e6:	557d                	li	a0,-1
    16e8:	67f000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    16ec:	000a2603          	lw	a2,0(s4)
    16f0:	de55                	beqz	a2,16ac <printf+0x3a8>
    16f2:	b755                	j	1696 <printf+0x392>
		mutex_lock(buffer_lock);
    16f4:	10ca2503          	lw	a0,268(s4)
    16f8:	e42e                	sd	a1,8(sp)
		s += 2;
    16fa:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16fe:	0a6010ef          	jal	ra,27a4 <mutex_lock>
		len = out_unlocked(s, l);
    1702:	65a2                	ld	a1,8(sp)
    1704:	8522                	mv	a0,s0
    1706:	08a000ef          	jal	ra,1790 <out_unlocked>
		mutex_unlock(buffer_lock);
    170a:	10ca2503          	lw	a0,268(s4)
    170e:	0a2010ef          	jal	ra,27b0 <mutex_unlock>
		s += 2;
    1712:	bb55                	j	14c6 <printf+0x1c2>
				a = "(null)";
    1714:	00001417          	auipc	s0,0x1
    1718:	19c40413          	addi	s0,s0,412 # 28b0 <enable_deadlock_detect+0xac>
    171c:	bd2d                	j	1556 <printf+0x252>

000000000000171e <enable_thread_io_buffer>:
{
    171e:	1101                	addi	sp,sp,-32
    1720:	e822                	sd	s0,16(sp)
    1722:	ec06                	sd	ra,24(sp)
    1724:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1726:	00001417          	auipc	s0,0x1
    172a:	28240413          	addi	s0,s0,642 # 29a8 <buffer_len>
    172e:	05a010ef          	jal	ra,2788 <mutex_create>
    1732:	10a42623          	sw	a0,268(s0)
    1736:	00054a63          	bltz	a0,174a <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    173a:	4785                	li	a5,1
}
    173c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    173e:	10f42423          	sw	a5,264(s0)
}
    1742:	6442                	ld	s0,16(sp)
    1744:	64a2                	ld	s1,8(sp)
    1746:	6105                	addi	sp,sp,32
    1748:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    174a:	5ed000ef          	jal	ra,2536 <getpid>
    174e:	84aa                	mv	s1,a0
    1750:	00001517          	auipc	a0,0x1
    1754:	16850513          	addi	a0,a0,360 # 28b8 <enable_deadlock_detect+0xb4>
    1758:	4b5000ef          	jal	ra,240c <basename>
    175c:	872a                	mv	a4,a0
    175e:	04800793          	li	a5,72
    1762:	86a6                	mv	a3,s1
    1764:	00001517          	auipc	a0,0x1
    1768:	1d450513          	addi	a0,a0,468 # 2938 <enable_deadlock_detect+0x134>
    176c:	00001617          	auipc	a2,0x1
    1770:	0ec60613          	addi	a2,a2,236 # 2858 <enable_deadlock_detect+0x54>
    1774:	45fd                	li	a1,31
    1776:	b8fff0ef          	jal	ra,1304 <printf>
    177a:	557d                	li	a0,-1
    177c:	5eb000ef          	jal	ra,2566 <exit>
	buffer_lock_enabled = 1;
    1780:	4785                	li	a5,1
}
    1782:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1784:	10f42423          	sw	a5,264(s0)
}
    1788:	6442                	ld	s0,16(sp)
    178a:	64a2                	ld	s1,8(sp)
    178c:	6105                	addi	sp,sp,32
    178e:	8082                	ret

0000000000001790 <out_unlocked>:
{
    1790:	7159                	addi	sp,sp,-112
    1792:	f486                	sd	ra,104(sp)
    1794:	f0a2                	sd	s0,96(sp)
    1796:	eca6                	sd	s1,88(sp)
    1798:	e8ca                	sd	s2,80(sp)
    179a:	e4ce                	sd	s3,72(sp)
    179c:	e0d2                	sd	s4,64(sp)
    179e:	fc56                	sd	s5,56(sp)
    17a0:	f85a                	sd	s6,48(sp)
    17a2:	f45e                	sd	s7,40(sp)
    17a4:	f062                	sd	s8,32(sp)
    17a6:	ec66                	sd	s9,24(sp)
    17a8:	e86a                	sd	s10,16(sp)
    17aa:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    17ac:	0e058663          	beqz	a1,1898 <out_unlocked+0x108>
    17b0:	842a                	mv	s0,a0
    17b2:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    17b6:	4981                	li	s3,0
    17b8:	00001d17          	auipc	s10,0x1
    17bc:	1f0d0d13          	addi	s10,s10,496 # 29a8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17c0:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    17c4:	00001b17          	auipc	s6,0x1
    17c8:	1ecb0b13          	addi	s6,s6,492 # 29b0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    17cc:	10000a93          	li	s5,256
    17d0:	00001c97          	auipc	s9,0x1
    17d4:	0e8c8c93          	addi	s9,s9,232 # 28b8 <enable_deadlock_detect+0xb4>
    17d8:	00001c17          	auipc	s8,0x1
    17dc:	080c0c13          	addi	s8,s8,128 # 2858 <enable_deadlock_detect+0x54>
    17e0:	00001b97          	auipc	s7,0x1
    17e4:	118b8b93          	addi	s7,s7,280 # 28f8 <enable_deadlock_detect+0xf4>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17e8:	4a29                	li	s4,10
    17ea:	a031                	j	17f6 <out_unlocked+0x66>
    17ec:	09468863          	beq	a3,s4,187c <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    17f0:	0405                	addi	s0,s0,1
    17f2:	04848163          	beq	s1,s0,1834 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    17f6:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    17fa:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    17fe:	0017861b          	addiw	a2,a5,1
    1802:	97ea                	add	a5,a5,s10
    1804:	00cd2023          	sw	a2,0(s10)
    1808:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    180c:	fec950e3          	bge	s2,a2,17ec <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1810:	05561263          	bne	a2,s5,1854 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1814:	85da                	mv	a1,s6
    1816:	4505                	li	a0,1
    1818:	515000ef          	jal	ra,252c <write>
    181c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    181e:	00001797          	auipc	a5,0x1
    1822:	1807a523          	sw	zero,394(a5) # 29a8 <buffer_len>
			if (r < 0) {
    1826:	06054763          	bltz	a0,1894 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    182a:	0405                	addi	s0,s0,1
			ret += r;
    182c:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1830:	fc8493e3          	bne	s1,s0,17f6 <out_unlocked+0x66>
}
    1834:	70a6                	ld	ra,104(sp)
    1836:	7406                	ld	s0,96(sp)
    1838:	64e6                	ld	s1,88(sp)
    183a:	6946                	ld	s2,80(sp)
    183c:	6a06                	ld	s4,64(sp)
    183e:	7ae2                	ld	s5,56(sp)
    1840:	7b42                	ld	s6,48(sp)
    1842:	7ba2                	ld	s7,40(sp)
    1844:	7c02                	ld	s8,32(sp)
    1846:	6ce2                	ld	s9,24(sp)
    1848:	6d42                	ld	s10,16(sp)
    184a:	6da2                	ld	s11,8(sp)
    184c:	854e                	mv	a0,s3
    184e:	69a6                	ld	s3,72(sp)
    1850:	6165                	addi	sp,sp,112
    1852:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1854:	4e3000ef          	jal	ra,2536 <getpid>
    1858:	8daa                	mv	s11,a0
    185a:	8566                	mv	a0,s9
    185c:	3b1000ef          	jal	ra,240c <basename>
    1860:	872a                	mv	a4,a0
    1862:	8662                	mv	a2,s8
    1864:	05400793          	li	a5,84
    1868:	86ee                	mv	a3,s11
    186a:	45fd                	li	a1,31
    186c:	855e                	mv	a0,s7
    186e:	a97ff0ef          	jal	ra,1304 <printf>
    1872:	557d                	li	a0,-1
    1874:	4f3000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    1878:	000d2603          	lw	a2,0(s10)
    187c:	da35                	beqz	a2,17f0 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    187e:	85da                	mv	a1,s6
    1880:	4505                	li	a0,1
    1882:	4ab000ef          	jal	ra,252c <write>
    1886:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1888:	00001797          	auipc	a5,0x1
    188c:	1207a023          	sw	zero,288(a5) # 29a8 <buffer_len>
			if (r < 0) {
    1890:	f8055de3          	bgez	a0,182a <out_unlocked+0x9a>
    1894:	89aa                	mv	s3,a0
    1896:	bf79                	j	1834 <out_unlocked+0xa4>
	int ret = 0;
    1898:	4981                	li	s3,0
    189a:	bf69                	j	1834 <out_unlocked+0xa4>

000000000000189c <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    189c:	1101                	addi	sp,sp,-32
    189e:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    18a0:	00001497          	auipc	s1,0x1
    18a4:	10848493          	addi	s1,s1,264 # 29a8 <buffer_len>
    18a8:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    18aa:	ec06                	sd	ra,24(sp)
    18ac:	e822                	sd	s0,16(sp)
		char c = s[i];
    18ae:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    18b2:	0017861b          	addiw	a2,a5,1
    18b6:	97a6                	add	a5,a5,s1
    18b8:	00e78423          	sb	a4,8(a5)
    18bc:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18be:	0ff00793          	li	a5,255
    18c2:	00c7cc63          	blt	a5,a2,18da <out_unlocked.constprop.0+0x3e>
    18c6:	47a9                	li	a5,10
    18c8:	06f70c63          	beq	a4,a5,1940 <out_unlocked.constprop.0+0xa4>
    18cc:	4601                	li	a2,0
}
    18ce:	60e2                	ld	ra,24(sp)
    18d0:	6442                	ld	s0,16(sp)
    18d2:	64a2                	ld	s1,8(sp)
    18d4:	8532                	mv	a0,a2
    18d6:	6105                	addi	sp,sp,32
    18d8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18da:	10000793          	li	a5,256
    18de:	02f61563          	bne	a2,a5,1908 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    18e2:	00001597          	auipc	a1,0x1
    18e6:	0ce58593          	addi	a1,a1,206 # 29b0 <buffer>
    18ea:	4505                	li	a0,1
    18ec:	441000ef          	jal	ra,252c <write>
}
    18f0:	60e2                	ld	ra,24(sp)
    18f2:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    18f4:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18f8:	00001797          	auipc	a5,0x1
    18fc:	0a07a823          	sw	zero,176(a5) # 29a8 <buffer_len>
}
    1900:	64a2                	ld	s1,8(sp)
    1902:	8532                	mv	a0,a2
    1904:	6105                	addi	sp,sp,32
    1906:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1908:	42f000ef          	jal	ra,2536 <getpid>
    190c:	842a                	mv	s0,a0
    190e:	00001517          	auipc	a0,0x1
    1912:	faa50513          	addi	a0,a0,-86 # 28b8 <enable_deadlock_detect+0xb4>
    1916:	2f7000ef          	jal	ra,240c <basename>
    191a:	872a                	mv	a4,a0
    191c:	00001617          	auipc	a2,0x1
    1920:	f3c60613          	addi	a2,a2,-196 # 2858 <enable_deadlock_detect+0x54>
    1924:	05400793          	li	a5,84
    1928:	86a2                	mv	a3,s0
    192a:	45fd                	li	a1,31
    192c:	00001517          	auipc	a0,0x1
    1930:	fcc50513          	addi	a0,a0,-52 # 28f8 <enable_deadlock_detect+0xf4>
    1934:	9d1ff0ef          	jal	ra,1304 <printf>
    1938:	557d                	li	a0,-1
    193a:	42d000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    193e:	4090                	lw	a2,0(s1)
    1940:	d659                	beqz	a2,18ce <out_unlocked.constprop.0+0x32>
    1942:	b745                	j	18e2 <out_unlocked.constprop.0+0x46>

0000000000001944 <putchar>:
{
    1944:	7139                	addi	sp,sp,-64
    1946:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1948:	00001497          	auipc	s1,0x1
    194c:	06048493          	addi	s1,s1,96 # 29a8 <buffer_len>
    1950:	1084a703          	lw	a4,264(s1)
{
    1954:	f822                	sd	s0,48(sp)
	char byte = c;
    1956:	0ff57413          	zext.b	s0,a0
{
    195a:	fc06                	sd	ra,56(sp)
	char byte = c;
    195c:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1960:	4785                	li	a5,1
    1962:	00f70d63          	beq	a4,a5,197c <putchar+0x38>
		len = out_unlocked(s, l);
    1966:	01f10513          	addi	a0,sp,31
    196a:	f33ff0ef          	jal	ra,189c <out_unlocked.constprop.0>
}
    196e:	70e2                	ld	ra,56(sp)
    1970:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1972:	862a                	mv	a2,a0
}
    1974:	74a2                	ld	s1,40(sp)
    1976:	8532                	mv	a0,a2
    1978:	6121                	addi	sp,sp,64
    197a:	8082                	ret
		mutex_lock(buffer_lock);
    197c:	10c4a503          	lw	a0,268(s1)
    1980:	625000ef          	jal	ra,27a4 <mutex_lock>
		buffer[buffer_len++] = c;
    1984:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1986:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    198a:	0017861b          	addiw	a2,a5,1
    198e:	97a6                	add	a5,a5,s1
    1990:	c090                	sw	a2,0(s1)
    1992:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1996:	02c6c263          	blt	a3,a2,19ba <putchar+0x76>
    199a:	47a9                	li	a5,10
    199c:	06f40d63          	beq	s0,a5,1a16 <putchar+0xd2>
    19a0:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    19a2:	10c4a503          	lw	a0,268(s1)
    19a6:	e432                	sd	a2,8(sp)
    19a8:	609000ef          	jal	ra,27b0 <mutex_unlock>
    19ac:	6622                	ld	a2,8(sp)
}
    19ae:	70e2                	ld	ra,56(sp)
    19b0:	7442                	ld	s0,48(sp)
    19b2:	74a2                	ld	s1,40(sp)
    19b4:	8532                	mv	a0,a2
    19b6:	6121                	addi	sp,sp,64
    19b8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19ba:	10000793          	li	a5,256
    19be:	02f61063          	bne	a2,a5,19de <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    19c2:	00001597          	auipc	a1,0x1
    19c6:	fee58593          	addi	a1,a1,-18 # 29b0 <buffer>
    19ca:	4505                	li	a0,1
    19cc:	361000ef          	jal	ra,252c <write>
    19d0:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19d4:	00001797          	auipc	a5,0x1
    19d8:	fc07aa23          	sw	zero,-44(a5) # 29a8 <buffer_len>
			if (r < 0) {
    19dc:	b7d9                	j	19a2 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    19de:	359000ef          	jal	ra,2536 <getpid>
    19e2:	842a                	mv	s0,a0
    19e4:	00001517          	auipc	a0,0x1
    19e8:	ed450513          	addi	a0,a0,-300 # 28b8 <enable_deadlock_detect+0xb4>
    19ec:	221000ef          	jal	ra,240c <basename>
    19f0:	872a                	mv	a4,a0
    19f2:	00001617          	auipc	a2,0x1
    19f6:	e6660613          	addi	a2,a2,-410 # 2858 <enable_deadlock_detect+0x54>
    19fa:	05400793          	li	a5,84
    19fe:	86a2                	mv	a3,s0
    1a00:	45fd                	li	a1,31
    1a02:	00001517          	auipc	a0,0x1
    1a06:	ef650513          	addi	a0,a0,-266 # 28f8 <enable_deadlock_detect+0xf4>
    1a0a:	8fbff0ef          	jal	ra,1304 <printf>
    1a0e:	557d                	li	a0,-1
    1a10:	357000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    1a14:	4090                	lw	a2,0(s1)
    1a16:	d651                	beqz	a2,19a2 <putchar+0x5e>
    1a18:	b76d                	j	19c2 <putchar+0x7e>

0000000000001a1a <puts>:
{
    1a1a:	7139                	addi	sp,sp,-64
    1a1c:	f822                	sd	s0,48(sp)
    1a1e:	f426                	sd	s1,40(sp)
    1a20:	fc06                	sd	ra,56(sp)
    1a22:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a24:	00001417          	auipc	s0,0x1
    1a28:	f8440413          	addi	s0,s0,-124 # 29a8 <buffer_len>
{
    1a2c:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a2e:	638000ef          	jal	ra,2066 <strlen>
	if (buffer_lock_enabled == 1) {
    1a32:	10842703          	lw	a4,264(s0)
    1a36:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a38:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1a3a:	04f70563          	beq	a4,a5,1a84 <puts+0x6a>
		len = out_unlocked(s, l);
    1a3e:	8526                	mv	a0,s1
    1a40:	d51ff0ef          	jal	ra,1790 <out_unlocked>
    1a44:	892a                	mv	s2,a0
    1a46:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a48:	00095963          	bgez	s2,1a5a <puts+0x40>
}
    1a4c:	70e2                	ld	ra,56(sp)
    1a4e:	7442                	ld	s0,48(sp)
    1a50:	7902                	ld	s2,32(sp)
    1a52:	8526                	mv	a0,s1
    1a54:	74a2                	ld	s1,40(sp)
    1a56:	6121                	addi	sp,sp,64
    1a58:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a5a:	10842703          	lw	a4,264(s0)
	char byte = c;
    1a5e:	44a9                	li	s1,10
    1a60:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1a64:	4785                	li	a5,1
    1a66:	02f70e63          	beq	a4,a5,1aa2 <puts+0x88>
		len = out_unlocked(s, l);
    1a6a:	01f10513          	addi	a0,sp,31
    1a6e:	e2fff0ef          	jal	ra,189c <out_unlocked.constprop.0>
}
    1a72:	70e2                	ld	ra,56(sp)
    1a74:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a76:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a7a:	7902                	ld	s2,32(sp)
    1a7c:	8526                	mv	a0,s1
    1a7e:	74a2                	ld	s1,40(sp)
    1a80:	6121                	addi	sp,sp,64
    1a82:	8082                	ret
		mutex_lock(buffer_lock);
    1a84:	e42a                	sd	a0,8(sp)
    1a86:	10c42503          	lw	a0,268(s0)
    1a8a:	51b000ef          	jal	ra,27a4 <mutex_lock>
		len = out_unlocked(s, l);
    1a8e:	65a2                	ld	a1,8(sp)
    1a90:	8526                	mv	a0,s1
    1a92:	cffff0ef          	jal	ra,1790 <out_unlocked>
    1a96:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a98:	10c42503          	lw	a0,268(s0)
    1a9c:	515000ef          	jal	ra,27b0 <mutex_unlock>
    1aa0:	b75d                	j	1a46 <puts+0x2c>
		mutex_lock(buffer_lock);
    1aa2:	10c42503          	lw	a0,268(s0)
    1aa6:	4ff000ef          	jal	ra,27a4 <mutex_lock>
		buffer[buffer_len++] = c;
    1aaa:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1aac:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1ab0:	0017861b          	addiw	a2,a5,1
    1ab4:	97a2                	add	a5,a5,s0
    1ab6:	c010                	sw	a2,0(s0)
    1ab8:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1abc:	06c6dc63          	bge	a3,a2,1b34 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1ac0:	10000793          	li	a5,256
    1ac4:	02f61c63          	bne	a2,a5,1afc <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1ac8:	00001597          	auipc	a1,0x1
    1acc:	ee858593          	addi	a1,a1,-280 # 29b0 <buffer>
    1ad0:	4505                	li	a0,1
    1ad2:	25b000ef          	jal	ra,252c <write>
			if (r < 0) {
    1ad6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1ad8:	00001797          	auipc	a5,0x1
    1adc:	ec07a823          	sw	zero,-304(a5) # 29a8 <buffer_len>
			if (r < 0) {
    1ae0:	04054c63          	bltz	a0,1b38 <puts+0x11e>
			if (r < buffer_len) {
    1ae4:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1ae6:	10c42503          	lw	a0,268(s0)
    1aea:	4c7000ef          	jal	ra,27b0 <mutex_unlock>
}
    1aee:	70e2                	ld	ra,56(sp)
    1af0:	7442                	ld	s0,48(sp)
    1af2:	7902                	ld	s2,32(sp)
    1af4:	8526                	mv	a0,s1
    1af6:	74a2                	ld	s1,40(sp)
    1af8:	6121                	addi	sp,sp,64
    1afa:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1afc:	23b000ef          	jal	ra,2536 <getpid>
    1b00:	84aa                	mv	s1,a0
    1b02:	00001517          	auipc	a0,0x1
    1b06:	db650513          	addi	a0,a0,-586 # 28b8 <enable_deadlock_detect+0xb4>
    1b0a:	103000ef          	jal	ra,240c <basename>
    1b0e:	872a                	mv	a4,a0
    1b10:	00001617          	auipc	a2,0x1
    1b14:	d4860613          	addi	a2,a2,-696 # 2858 <enable_deadlock_detect+0x54>
    1b18:	05400793          	li	a5,84
    1b1c:	86a6                	mv	a3,s1
    1b1e:	45fd                	li	a1,31
    1b20:	00001517          	auipc	a0,0x1
    1b24:	dd850513          	addi	a0,a0,-552 # 28f8 <enable_deadlock_detect+0xf4>
    1b28:	fdcff0ef          	jal	ra,1304 <printf>
    1b2c:	557d                	li	a0,-1
    1b2e:	239000ef          	jal	ra,2566 <exit>
	if (buffer_len == 0)
    1b32:	4010                	lw	a2,0(s0)
    1b34:	da45                	beqz	a2,1ae4 <puts+0xca>
    1b36:	bf49                	j	1ac8 <puts+0xae>
    1b38:	54fd                	li	s1,-1
    1b3a:	b775                	j	1ae6 <puts+0xcc>

0000000000001b3c <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1b3c:	715d                	addi	sp,sp,-80
    1b3e:	e486                	sd	ra,72(sp)
    1b40:	e0a2                	sd	s0,64(sp)
    1b42:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1b44:	14054363          	bltz	a0,1c8a <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1b48:	02b577bb          	remuw	a5,a0,a1
    1b4c:	00001617          	auipc	a2,0x1
    1b50:	f6c60613          	addi	a2,a2,-148 # 2ab8 <digits>
	buf[16] = 0;
    1b54:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b58:	0005871b          	sext.w	a4,a1
    1b5c:	1782                	slli	a5,a5,0x20
    1b5e:	9381                	srli	a5,a5,0x20
    1b60:	97b2                	add	a5,a5,a2
    1b62:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b66:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b6a:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b6e:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b70:	0eb56763          	bltu	a0,a1,1c5e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b74:	02e877bb          	remuw	a5,a6,a4
    1b78:	1782                	slli	a5,a5,0x20
    1b7a:	9381                	srli	a5,a5,0x20
    1b7c:	97b2                	add	a5,a5,a2
    1b7e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b82:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b86:	02f10323          	sb	a5,38(sp)
    1b8a:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b8c:	0ce86963          	bltu	a6,a4,1c5e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b90:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b94:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b98:	1582                	slli	a1,a1,0x20
    1b9a:	9181                	srli	a1,a1,0x20
    1b9c:	95b2                	add	a1,a1,a2
    1b9e:	0005c583          	lbu	a1,0(a1)
    1ba2:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1ba6:	0007859b          	sext.w	a1,a5
    1baa:	16e6e563          	bltu	a3,a4,1d14 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1bae:	02e7f6bb          	remuw	a3,a5,a4
    1bb2:	1682                	slli	a3,a3,0x20
    1bb4:	9281                	srli	a3,a3,0x20
    1bb6:	96b2                	add	a3,a3,a2
    1bb8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bbc:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1bc0:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1bc4:	16e5e163          	bltu	a1,a4,1d26 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1bc8:	02e876bb          	remuw	a3,a6,a4
    1bcc:	1682                	slli	a3,a3,0x20
    1bce:	9281                	srli	a3,a3,0x20
    1bd0:	96b2                	add	a3,a3,a2
    1bd2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bd6:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1bda:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1bde:	14e86d63          	bltu	a6,a4,1d38 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1be2:	02e5f6bb          	remuw	a3,a1,a4
    1be6:	1682                	slli	a3,a3,0x20
    1be8:	9281                	srli	a3,a3,0x20
    1bea:	96b2                	add	a3,a3,a2
    1bec:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bf0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bf4:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1bf8:	10e5e563          	bltu	a1,a4,1d02 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1bfc:	02e876bb          	remuw	a3,a6,a4
    1c00:	1682                	slli	a3,a3,0x20
    1c02:	9281                	srli	a3,a3,0x20
    1c04:	96b2                	add	a3,a3,a2
    1c06:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c0a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c0e:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c12:	14e86263          	bltu	a6,a4,1d56 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c16:	02e5f6bb          	remuw	a3,a1,a4
    1c1a:	1682                	slli	a3,a3,0x20
    1c1c:	9281                	srli	a3,a3,0x20
    1c1e:	96b2                	add	a3,a3,a2
    1c20:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c24:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c28:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c2c:	14e5e463          	bltu	a1,a4,1d74 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1c30:	02e876bb          	remuw	a3,a6,a4
    1c34:	1682                	slli	a3,a3,0x20
    1c36:	9281                	srli	a3,a3,0x20
    1c38:	96b2                	add	a3,a3,a2
    1c3a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c3e:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1c42:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1c46:	14e86063          	bltu	a6,a4,1d86 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1c4a:	1782                	slli	a5,a5,0x20
    1c4c:	9381                	srli	a5,a5,0x20
    1c4e:	97b2                	add	a5,a5,a2
    1c50:	0007c703          	lbu	a4,0(a5)
    1c54:	4799                	li	a5,6
    1c56:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c5a:	10054763          	bltz	a0,1d68 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1c5e:	00001497          	auipc	s1,0x1
    1c62:	d4a48493          	addi	s1,s1,-694 # 29a8 <buffer_len>
    1c66:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c6a:	0828                	addi	a0,sp,24
    1c6c:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c6e:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c70:	00f50433          	add	s0,a0,a5
    1c74:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c76:	06e68463          	beq	a3,a4,1cde <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c7a:	8522                	mv	a0,s0
    1c7c:	b15ff0ef          	jal	ra,1790 <out_unlocked>
}
    1c80:	60a6                	ld	ra,72(sp)
    1c82:	6406                	ld	s0,64(sp)
    1c84:	74e2                	ld	s1,56(sp)
    1c86:	6161                	addi	sp,sp,80
    1c88:	8082                	ret
		x = -xx;
    1c8a:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c8e:	02b877bb          	remuw	a5,a6,a1
    1c92:	00001617          	auipc	a2,0x1
    1c96:	e2660613          	addi	a2,a2,-474 # 2ab8 <digits>
	buf[16] = 0;
    1c9a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c9e:	0005871b          	sext.w	a4,a1
    1ca2:	1782                	slli	a5,a5,0x20
    1ca4:	9381                	srli	a5,a5,0x20
    1ca6:	97b2                	add	a5,a5,a2
    1ca8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cac:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1cb0:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1cb4:	08b86b63          	bltu	a6,a1,1d4a <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1cb8:	02e8f7bb          	remuw	a5,a7,a4
    1cbc:	1782                	slli	a5,a5,0x20
    1cbe:	9381                	srli	a5,a5,0x20
    1cc0:	97b2                	add	a5,a5,a2
    1cc2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cc6:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1cca:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1cce:	ece8f1e3          	bgeu	a7,a4,1b90 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1cd2:	02d00793          	li	a5,45
    1cd6:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1cda:	47b5                	li	a5,13
    1cdc:	b749                	j	1c5e <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1cde:	10c4a503          	lw	a0,268(s1)
    1ce2:	e42e                	sd	a1,8(sp)
    1ce4:	2c1000ef          	jal	ra,27a4 <mutex_lock>
		len = out_unlocked(s, l);
    1ce8:	65a2                	ld	a1,8(sp)
    1cea:	8522                	mv	a0,s0
    1cec:	aa5ff0ef          	jal	ra,1790 <out_unlocked>
		mutex_unlock(buffer_lock);
    1cf0:	10c4a503          	lw	a0,268(s1)
    1cf4:	2bd000ef          	jal	ra,27b0 <mutex_unlock>
}
    1cf8:	60a6                	ld	ra,72(sp)
    1cfa:	6406                	ld	s0,64(sp)
    1cfc:	74e2                	ld	s1,56(sp)
    1cfe:	6161                	addi	sp,sp,80
    1d00:	8082                	ret
		buf[i--] = digits[x % base];
    1d02:	47a9                	li	a5,10
	if (sign)
    1d04:	f4055de3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d08:	02d00793          	li	a5,45
    1d0c:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d10:	47a5                	li	a5,9
    1d12:	b7b1                	j	1c5e <printint.constprop.0+0x122>
    1d14:	47b5                	li	a5,13
	if (sign)
    1d16:	f40554e3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d1a:	02d00793          	li	a5,45
    1d1e:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d22:	47b1                	li	a5,12
    1d24:	bf2d                	j	1c5e <printint.constprop.0+0x122>
    1d26:	47b1                	li	a5,12
	if (sign)
    1d28:	f2055be3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d2c:	02d00793          	li	a5,45
    1d30:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d34:	47ad                	li	a5,11
    1d36:	b725                	j	1c5e <printint.constprop.0+0x122>
    1d38:	47ad                	li	a5,11
	if (sign)
    1d3a:	f20552e3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d3e:	02d00793          	li	a5,45
    1d42:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1d46:	47a9                	li	a5,10
    1d48:	bf19                	j	1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d4a:	02d00793          	li	a5,45
    1d4e:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1d52:	47b9                	li	a5,14
    1d54:	b729                	j	1c5e <printint.constprop.0+0x122>
    1d56:	47a5                	li	a5,9
	if (sign)
    1d58:	f00553e3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d5c:	02d00793          	li	a5,45
    1d60:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1d64:	47a1                	li	a5,8
    1d66:	bde5                	j	1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d68:	02d00793          	li	a5,45
    1d6c:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d70:	4795                	li	a5,5
    1d72:	b5f5                	j	1c5e <printint.constprop.0+0x122>
    1d74:	47a1                	li	a5,8
	if (sign)
    1d76:	ee0554e3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d7a:	02d00793          	li	a5,45
    1d7e:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d82:	479d                	li	a5,7
    1d84:	bde9                	j	1c5e <printint.constprop.0+0x122>
    1d86:	479d                	li	a5,7
	if (sign)
    1d88:	ec055be3          	bgez	a0,1c5e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d8c:	02d00793          	li	a5,45
    1d90:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d94:	4799                	li	a5,6
    1d96:	b5e1                	j	1c5e <printint.constprop.0+0x122>

0000000000001d98 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d98:	02000793          	li	a5,32
    1d9c:	00f50663          	beq	a0,a5,1da8 <isspace+0x10>
    1da0:	355d                	addiw	a0,a0,-9
    1da2:	00553513          	sltiu	a0,a0,5
    1da6:	8082                	ret
    1da8:	4505                	li	a0,1
}
    1daa:	8082                	ret

0000000000001dac <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1dac:	fd05051b          	addiw	a0,a0,-48
}
    1db0:	00a53513          	sltiu	a0,a0,10
    1db4:	8082                	ret

0000000000001db6 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1db6:	02000613          	li	a2,32
    1dba:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1dbc:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1dc0:	ff77869b          	addiw	a3,a5,-9
    1dc4:	04c78c63          	beq	a5,a2,1e1c <atoi+0x66>
    1dc8:	0007871b          	sext.w	a4,a5
    1dcc:	04d5f863          	bgeu	a1,a3,1e1c <atoi+0x66>
		s++;
	switch (*s) {
    1dd0:	02b00693          	li	a3,43
    1dd4:	04d78963          	beq	a5,a3,1e26 <atoi+0x70>
    1dd8:	02d00693          	li	a3,45
    1ddc:	06d78263          	beq	a5,a3,1e40 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1de0:	fd07061b          	addiw	a2,a4,-48
    1de4:	47a5                	li	a5,9
    1de6:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1de8:	4e01                	li	t3,0
	while (isdigit(*s))
    1dea:	04c7e963          	bltu	a5,a2,1e3c <atoi+0x86>
	int n = 0, neg = 0;
    1dee:	4501                	li	a0,0
	while (isdigit(*s))
    1df0:	4825                	li	a6,9
    1df2:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1df6:	0025179b          	slliw	a5,a0,0x2
    1dfa:	9fa9                	addw	a5,a5,a0
    1dfc:	fd07031b          	addiw	t1,a4,-48
    1e00:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1e04:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1e08:	0685                	addi	a3,a3,1
    1e0a:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e0e:	0006071b          	sext.w	a4,a2
    1e12:	feb870e3          	bgeu	a6,a1,1df2 <atoi+0x3c>
	return neg ? n : -n;
    1e16:	000e0563          	beqz	t3,1e20 <atoi+0x6a>
}
    1e1a:	8082                	ret
		s++;
    1e1c:	0505                	addi	a0,a0,1
    1e1e:	bf79                	j	1dbc <atoi+0x6>
	return neg ? n : -n;
    1e20:	4113053b          	subw	a0,t1,a7
    1e24:	8082                	ret
	while (isdigit(*s))
    1e26:	00154703          	lbu	a4,1(a0)
    1e2a:	47a5                	li	a5,9
		s++;
    1e2c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e30:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e34:	4e01                	li	t3,0
	while (isdigit(*s))
    1e36:	2701                	sext.w	a4,a4
    1e38:	fac7fbe3          	bgeu	a5,a2,1dee <atoi+0x38>
    1e3c:	4501                	li	a0,0
}
    1e3e:	8082                	ret
	while (isdigit(*s))
    1e40:	00154703          	lbu	a4,1(a0)
    1e44:	47a5                	li	a5,9
		s++;
    1e46:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e4a:	fd07061b          	addiw	a2,a4,-48
    1e4e:	2701                	sext.w	a4,a4
    1e50:	fec7e6e3          	bltu	a5,a2,1e3c <atoi+0x86>
		neg = 1;
    1e54:	4e05                	li	t3,1
    1e56:	bf61                	j	1dee <atoi+0x38>

0000000000001e58 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e58:	16060d63          	beqz	a2,1fd2 <memset+0x17a>
    1e5c:	40a007b3          	neg	a5,a0
    1e60:	8b9d                	andi	a5,a5,7
    1e62:	00778693          	addi	a3,a5,7
    1e66:	482d                	li	a6,11
    1e68:	0ff5f713          	zext.b	a4,a1
    1e6c:	fff60593          	addi	a1,a2,-1
    1e70:	1706e263          	bltu	a3,a6,1fd4 <memset+0x17c>
    1e74:	16d5ea63          	bltu	a1,a3,1fe8 <memset+0x190>
    1e78:	16078563          	beqz	a5,1fe2 <memset+0x18a>
    1e7c:	00e50023          	sb	a4,0(a0)
    1e80:	4685                	li	a3,1
    1e82:	00150593          	addi	a1,a0,1
    1e86:	14d78c63          	beq	a5,a3,1fde <memset+0x186>
    1e8a:	00e500a3          	sb	a4,1(a0)
    1e8e:	4689                	li	a3,2
    1e90:	00250593          	addi	a1,a0,2
    1e94:	14d78d63          	beq	a5,a3,1fee <memset+0x196>
    1e98:	00e50123          	sb	a4,2(a0)
    1e9c:	468d                	li	a3,3
    1e9e:	00350593          	addi	a1,a0,3
    1ea2:	12d78b63          	beq	a5,a3,1fd8 <memset+0x180>
    1ea6:	00e501a3          	sb	a4,3(a0)
    1eaa:	4691                	li	a3,4
    1eac:	00450593          	addi	a1,a0,4
    1eb0:	14d78163          	beq	a5,a3,1ff2 <memset+0x19a>
    1eb4:	00e50223          	sb	a4,4(a0)
    1eb8:	4695                	li	a3,5
    1eba:	00550593          	addi	a1,a0,5
    1ebe:	12d78c63          	beq	a5,a3,1ff6 <memset+0x19e>
    1ec2:	00e502a3          	sb	a4,5(a0)
    1ec6:	469d                	li	a3,7
    1ec8:	00650593          	addi	a1,a0,6
    1ecc:	12d79763          	bne	a5,a3,1ffa <memset+0x1a2>
    1ed0:	00750593          	addi	a1,a0,7
    1ed4:	00e50323          	sb	a4,6(a0)
    1ed8:	481d                	li	a6,7
    1eda:	00871693          	slli	a3,a4,0x8
    1ede:	01071893          	slli	a7,a4,0x10
    1ee2:	8ed9                	or	a3,a3,a4
    1ee4:	01871313          	slli	t1,a4,0x18
    1ee8:	0116e6b3          	or	a3,a3,a7
    1eec:	0066e6b3          	or	a3,a3,t1
    1ef0:	02071893          	slli	a7,a4,0x20
    1ef4:	02871e13          	slli	t3,a4,0x28
    1ef8:	0116e6b3          	or	a3,a3,a7
    1efc:	40f60333          	sub	t1,a2,a5
    1f00:	03071893          	slli	a7,a4,0x30
    1f04:	01c6e6b3          	or	a3,a3,t3
    1f08:	0116e6b3          	or	a3,a3,a7
    1f0c:	03871e13          	slli	t3,a4,0x38
    1f10:	97aa                	add	a5,a5,a0
    1f12:	ff837893          	andi	a7,t1,-8
    1f16:	01c6e6b3          	or	a3,a3,t3
    1f1a:	98be                	add	a7,a7,a5
    1f1c:	e394                	sd	a3,0(a5)
    1f1e:	07a1                	addi	a5,a5,8
    1f20:	ff179ee3          	bne	a5,a7,1f1c <memset+0xc4>
    1f24:	ff837893          	andi	a7,t1,-8
    1f28:	011587b3          	add	a5,a1,a7
    1f2c:	010886bb          	addw	a3,a7,a6
    1f30:	0b130663          	beq	t1,a7,1fdc <memset+0x184>
    1f34:	00e78023          	sb	a4,0(a5)
    1f38:	0016859b          	addiw	a1,a3,1
    1f3c:	08c5fb63          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f40:	00e780a3          	sb	a4,1(a5)
    1f44:	0026859b          	addiw	a1,a3,2
    1f48:	08c5f563          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f4c:	00e78123          	sb	a4,2(a5)
    1f50:	0036859b          	addiw	a1,a3,3
    1f54:	06c5ff63          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f58:	00e781a3          	sb	a4,3(a5)
    1f5c:	0046859b          	addiw	a1,a3,4
    1f60:	06c5f963          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f64:	00e78223          	sb	a4,4(a5)
    1f68:	0056859b          	addiw	a1,a3,5
    1f6c:	06c5f363          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f70:	00e782a3          	sb	a4,5(a5)
    1f74:	0066859b          	addiw	a1,a3,6
    1f78:	04c5fd63          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f7c:	00e78323          	sb	a4,6(a5)
    1f80:	0076859b          	addiw	a1,a3,7
    1f84:	04c5f763          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f88:	00e783a3          	sb	a4,7(a5)
    1f8c:	0086859b          	addiw	a1,a3,8
    1f90:	04c5f163          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1f94:	00e78423          	sb	a4,8(a5)
    1f98:	0096859b          	addiw	a1,a3,9
    1f9c:	02c5fb63          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1fa0:	00e784a3          	sb	a4,9(a5)
    1fa4:	00a6859b          	addiw	a1,a3,10
    1fa8:	02c5f563          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1fac:	00e78523          	sb	a4,10(a5)
    1fb0:	00b6859b          	addiw	a1,a3,11
    1fb4:	00c5ff63          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1fb8:	00e785a3          	sb	a4,11(a5)
    1fbc:	00c6859b          	addiw	a1,a3,12
    1fc0:	00c5f963          	bgeu	a1,a2,1fd2 <memset+0x17a>
    1fc4:	00e78623          	sb	a4,12(a5)
    1fc8:	26b5                	addiw	a3,a3,13
    1fca:	00c6f463          	bgeu	a3,a2,1fd2 <memset+0x17a>
    1fce:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1fd2:	8082                	ret
    1fd4:	46ad                	li	a3,11
    1fd6:	bd79                	j	1e74 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fd8:	480d                	li	a6,3
    1fda:	b701                	j	1eda <memset+0x82>
    1fdc:	8082                	ret
    1fde:	4805                	li	a6,1
    1fe0:	bded                	j	1eda <memset+0x82>
    1fe2:	85aa                	mv	a1,a0
    1fe4:	4801                	li	a6,0
    1fe6:	bdd5                	j	1eda <memset+0x82>
    1fe8:	87aa                	mv	a5,a0
    1fea:	4681                	li	a3,0
    1fec:	b7a1                	j	1f34 <memset+0xdc>
    1fee:	4809                	li	a6,2
    1ff0:	b5ed                	j	1eda <memset+0x82>
    1ff2:	4811                	li	a6,4
    1ff4:	b5dd                	j	1eda <memset+0x82>
    1ff6:	4815                	li	a6,5
    1ff8:	b5cd                	j	1eda <memset+0x82>
    1ffa:	4819                	li	a6,6
    1ffc:	bdf9                	j	1eda <memset+0x82>

0000000000001ffe <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ffe:	00054783          	lbu	a5,0(a0)
    2002:	0005c703          	lbu	a4,0(a1)
    2006:	00e79863          	bne	a5,a4,2016 <strcmp+0x18>
    200a:	0505                	addi	a0,a0,1
    200c:	0585                	addi	a1,a1,1
    200e:	fbe5                	bnez	a5,1ffe <strcmp>
    2010:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2012:	9d19                	subw	a0,a0,a4
    2014:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    2016:	0007851b          	sext.w	a0,a5
    201a:	bfe5                	j	2012 <strcmp+0x14>

000000000000201c <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    201c:	ca15                	beqz	a2,2050 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    201e:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2022:	167d                	addi	a2,a2,-1
    2024:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2028:	eb99                	bnez	a5,203e <strncmp+0x22>
    202a:	a815                	j	205e <strncmp+0x42>
    202c:	00a68e63          	beq	a3,a0,2048 <strncmp+0x2c>
    2030:	0505                	addi	a0,a0,1
    2032:	00f71b63          	bne	a4,a5,2048 <strncmp+0x2c>
    2036:	00054783          	lbu	a5,0(a0)
    203a:	cf89                	beqz	a5,2054 <strncmp+0x38>
    203c:	85b2                	mv	a1,a2
    203e:	0005c703          	lbu	a4,0(a1)
    2042:	00158613          	addi	a2,a1,1
    2046:	f37d                	bnez	a4,202c <strncmp+0x10>
		;
	return *l - *r;
    2048:	0007851b          	sext.w	a0,a5
    204c:	9d19                	subw	a0,a0,a4
    204e:	8082                	ret
		return 0;
    2050:	4501                	li	a0,0
}
    2052:	8082                	ret
	return *l - *r;
    2054:	0015c703          	lbu	a4,1(a1)
    2058:	4501                	li	a0,0
    205a:	9d19                	subw	a0,a0,a4
    205c:	8082                	ret
    205e:	0005c703          	lbu	a4,0(a1)
    2062:	4501                	li	a0,0
    2064:	b7e5                	j	204c <strncmp+0x30>

0000000000002066 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2066:	00757793          	andi	a5,a0,7
    206a:	cf89                	beqz	a5,2084 <strlen+0x1e>
    206c:	87aa                	mv	a5,a0
    206e:	a029                	j	2078 <strlen+0x12>
    2070:	0785                	addi	a5,a5,1
    2072:	0077f713          	andi	a4,a5,7
    2076:	cb01                	beqz	a4,2086 <strlen+0x20>
		if (!*s)
    2078:	0007c703          	lbu	a4,0(a5)
    207c:	fb75                	bnez	a4,2070 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    207e:	40a78533          	sub	a0,a5,a0
}
    2082:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2084:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2086:	6394                	ld	a3,0(a5)
    2088:	00001597          	auipc	a1,0x1
    208c:	9085b583          	ld	a1,-1784(a1) # 2990 <enable_deadlock_detect+0x18c>
    2090:	00001617          	auipc	a2,0x1
    2094:	90863603          	ld	a2,-1784(a2) # 2998 <enable_deadlock_detect+0x194>
    2098:	a019                	j	209e <strlen+0x38>
    209a:	6794                	ld	a3,8(a5)
    209c:	07a1                	addi	a5,a5,8
    209e:	00b68733          	add	a4,a3,a1
    20a2:	fff6c693          	not	a3,a3
    20a6:	8f75                	and	a4,a4,a3
    20a8:	8f71                	and	a4,a4,a2
    20aa:	db65                	beqz	a4,209a <strlen+0x34>
	for (; *s; s++)
    20ac:	0007c703          	lbu	a4,0(a5)
    20b0:	d779                	beqz	a4,207e <strlen+0x18>
    20b2:	0017c703          	lbu	a4,1(a5)
    20b6:	0785                	addi	a5,a5,1
    20b8:	d379                	beqz	a4,207e <strlen+0x18>
    20ba:	0017c703          	lbu	a4,1(a5)
    20be:	0785                	addi	a5,a5,1
    20c0:	fb6d                	bnez	a4,20b2 <strlen+0x4c>
    20c2:	bf75                	j	207e <strlen+0x18>

00000000000020c4 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    20c4:	00757713          	andi	a4,a0,7
{
    20c8:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    20ca:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    20ce:	cb19                	beqz	a4,20e4 <memchr+0x20>
    20d0:	ce25                	beqz	a2,2148 <memchr+0x84>
    20d2:	0007c703          	lbu	a4,0(a5)
    20d6:	04b70e63          	beq	a4,a1,2132 <memchr+0x6e>
    20da:	0785                	addi	a5,a5,1
    20dc:	0077f713          	andi	a4,a5,7
    20e0:	167d                	addi	a2,a2,-1
    20e2:	f77d                	bnez	a4,20d0 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    20e4:	4501                	li	a0,0
	if (n && *s != c) {
    20e6:	c235                	beqz	a2,214a <memchr+0x86>
    20e8:	0007c703          	lbu	a4,0(a5)
    20ec:	04b70363          	beq	a4,a1,2132 <memchr+0x6e>
		size_t k = ONES * c;
    20f0:	00001517          	auipc	a0,0x1
    20f4:	8b053503          	ld	a0,-1872(a0) # 29a0 <enable_deadlock_detect+0x19c>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20f8:	471d                	li	a4,7
		size_t k = ONES * c;
    20fa:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20fe:	02c77a63          	bgeu	a4,a2,2132 <memchr+0x6e>
    2102:	00001897          	auipc	a7,0x1
    2106:	88e8b883          	ld	a7,-1906(a7) # 2990 <enable_deadlock_detect+0x18c>
    210a:	00001817          	auipc	a6,0x1
    210e:	88e83803          	ld	a6,-1906(a6) # 2998 <enable_deadlock_detect+0x194>
    2112:	431d                	li	t1,7
    2114:	a029                	j	211e <memchr+0x5a>
		     w++, n -= SS)
    2116:	1661                	addi	a2,a2,-8
    2118:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    211a:	02c37963          	bgeu	t1,a2,214c <memchr+0x88>
    211e:	6398                	ld	a4,0(a5)
    2120:	8f29                	xor	a4,a4,a0
    2122:	011706b3          	add	a3,a4,a7
    2126:	fff74713          	not	a4,a4
    212a:	8f75                	and	a4,a4,a3
    212c:	01077733          	and	a4,a4,a6
    2130:	d37d                	beqz	a4,2116 <memchr+0x52>
{
    2132:	853e                	mv	a0,a5
    2134:	97b2                	add	a5,a5,a2
    2136:	a021                	j	213e <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2138:	0505                	addi	a0,a0,1
    213a:	00f50763          	beq	a0,a5,2148 <memchr+0x84>
    213e:	00054703          	lbu	a4,0(a0)
    2142:	feb71be3          	bne	a4,a1,2138 <memchr+0x74>
    2146:	8082                	ret
	return n ? (void *)s : 0;
    2148:	4501                	li	a0,0
}
    214a:	8082                	ret
	return n ? (void *)s : 0;
    214c:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    214e:	f275                	bnez	a2,2132 <memchr+0x6e>
}
    2150:	8082                	ret

0000000000002152 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2152:	1101                	addi	sp,sp,-32
    2154:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2156:	862e                	mv	a2,a1
{
    2158:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    215a:	4581                	li	a1,0
{
    215c:	e426                	sd	s1,8(sp)
    215e:	ec06                	sd	ra,24(sp)
    2160:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2162:	f63ff0ef          	jal	ra,20c4 <memchr>
	return p ? p - s : n;
    2166:	c519                	beqz	a0,2174 <strnlen+0x22>
}
    2168:	60e2                	ld	ra,24(sp)
    216a:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    216c:	8d05                	sub	a0,a0,s1
}
    216e:	64a2                	ld	s1,8(sp)
    2170:	6105                	addi	sp,sp,32
    2172:	8082                	ret
    2174:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2176:	8522                	mv	a0,s0
}
    2178:	6442                	ld	s0,16(sp)
    217a:	64a2                	ld	s1,8(sp)
    217c:	6105                	addi	sp,sp,32
    217e:	8082                	ret

0000000000002180 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2180:	00a5c7b3          	xor	a5,a1,a0
    2184:	8b9d                	andi	a5,a5,7
    2186:	eb95                	bnez	a5,21ba <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2188:	0075f793          	andi	a5,a1,7
    218c:	e7b1                	bnez	a5,21d8 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    218e:	6198                	ld	a4,0(a1)
    2190:	00001617          	auipc	a2,0x1
    2194:	80063603          	ld	a2,-2048(a2) # 2990 <enable_deadlock_detect+0x18c>
    2198:	00001817          	auipc	a6,0x1
    219c:	80083803          	ld	a6,-2048(a6) # 2998 <enable_deadlock_detect+0x194>
    21a0:	a029                	j	21aa <stpcpy+0x2a>
    21a2:	05a1                	addi	a1,a1,8
    21a4:	e118                	sd	a4,0(a0)
    21a6:	6198                	ld	a4,0(a1)
    21a8:	0521                	addi	a0,a0,8
    21aa:	00c707b3          	add	a5,a4,a2
    21ae:	fff74693          	not	a3,a4
    21b2:	8ff5                	and	a5,a5,a3
    21b4:	0107f7b3          	and	a5,a5,a6
    21b8:	d7ed                	beqz	a5,21a2 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    21ba:	0005c783          	lbu	a5,0(a1)
    21be:	00f50023          	sb	a5,0(a0)
    21c2:	c785                	beqz	a5,21ea <stpcpy+0x6a>
    21c4:	0015c783          	lbu	a5,1(a1)
    21c8:	0505                	addi	a0,a0,1
    21ca:	0585                	addi	a1,a1,1
    21cc:	00f50023          	sb	a5,0(a0)
    21d0:	fbf5                	bnez	a5,21c4 <stpcpy+0x44>
		;
	return d;
}
    21d2:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    21d4:	0505                	addi	a0,a0,1
    21d6:	df45                	beqz	a4,218e <stpcpy+0xe>
			if (!(*d = *s))
    21d8:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    21dc:	0585                	addi	a1,a1,1
    21de:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    21e2:	00f50023          	sb	a5,0(a0)
    21e6:	f7fd                	bnez	a5,21d4 <stpcpy+0x54>
}
    21e8:	8082                	ret
    21ea:	8082                	ret

00000000000021ec <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    21ec:	00a5c7b3          	xor	a5,a1,a0
    21f0:	8b9d                	andi	a5,a5,7
    21f2:	1a079863          	bnez	a5,23a2 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    21f6:	0075f793          	andi	a5,a1,7
    21fa:	16078463          	beqz	a5,2362 <stpncpy+0x176>
    21fe:	ea01                	bnez	a2,220e <stpncpy+0x22>
    2200:	a421                	j	2408 <stpncpy+0x21c>
    2202:	167d                	addi	a2,a2,-1
    2204:	0505                	addi	a0,a0,1
    2206:	14070e63          	beqz	a4,2362 <stpncpy+0x176>
    220a:	1a060863          	beqz	a2,23ba <stpncpy+0x1ce>
    220e:	0005c783          	lbu	a5,0(a1)
    2212:	0585                	addi	a1,a1,1
    2214:	0075f713          	andi	a4,a1,7
    2218:	00f50023          	sb	a5,0(a0)
    221c:	f3fd                	bnez	a5,2202 <stpncpy+0x16>
    221e:	4805                	li	a6,1
    2220:	1a061863          	bnez	a2,23d0 <stpncpy+0x1e4>
    2224:	40a007b3          	neg	a5,a0
    2228:	8b9d                	andi	a5,a5,7
    222a:	4681                	li	a3,0
    222c:	18061a63          	bnez	a2,23c0 <stpncpy+0x1d4>
    2230:	00778713          	addi	a4,a5,7
    2234:	45ad                	li	a1,11
    2236:	18b76363          	bltu	a4,a1,23bc <stpncpy+0x1d0>
    223a:	1ae6eb63          	bltu	a3,a4,23f0 <stpncpy+0x204>
    223e:	1a078363          	beqz	a5,23e4 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2242:	00050023          	sb	zero,0(a0)
    2246:	4685                	li	a3,1
    2248:	00150713          	addi	a4,a0,1
    224c:	18d78f63          	beq	a5,a3,23ea <stpncpy+0x1fe>
    2250:	000500a3          	sb	zero,1(a0)
    2254:	4689                	li	a3,2
    2256:	00250713          	addi	a4,a0,2
    225a:	18d78e63          	beq	a5,a3,23f6 <stpncpy+0x20a>
    225e:	00050123          	sb	zero,2(a0)
    2262:	468d                	li	a3,3
    2264:	00350713          	addi	a4,a0,3
    2268:	16d78c63          	beq	a5,a3,23e0 <stpncpy+0x1f4>
    226c:	000501a3          	sb	zero,3(a0)
    2270:	4691                	li	a3,4
    2272:	00450713          	addi	a4,a0,4
    2276:	18d78263          	beq	a5,a3,23fa <stpncpy+0x20e>
    227a:	00050223          	sb	zero,4(a0)
    227e:	4695                	li	a3,5
    2280:	00550713          	addi	a4,a0,5
    2284:	16d78d63          	beq	a5,a3,23fe <stpncpy+0x212>
    2288:	000502a3          	sb	zero,5(a0)
    228c:	469d                	li	a3,7
    228e:	00650713          	addi	a4,a0,6
    2292:	16d79863          	bne	a5,a3,2402 <stpncpy+0x216>
    2296:	00750713          	addi	a4,a0,7
    229a:	00050323          	sb	zero,6(a0)
    229e:	40f80833          	sub	a6,a6,a5
    22a2:	ff887593          	andi	a1,a6,-8
    22a6:	97aa                	add	a5,a5,a0
    22a8:	95be                	add	a1,a1,a5
    22aa:	0007b023          	sd	zero,0(a5)
    22ae:	07a1                	addi	a5,a5,8
    22b0:	feb79de3          	bne	a5,a1,22aa <stpncpy+0xbe>
    22b4:	ff887593          	andi	a1,a6,-8
    22b8:	9ead                	addw	a3,a3,a1
    22ba:	00b707b3          	add	a5,a4,a1
    22be:	12b80863          	beq	a6,a1,23ee <stpncpy+0x202>
    22c2:	00078023          	sb	zero,0(a5)
    22c6:	0016871b          	addiw	a4,a3,1
    22ca:	0ec77863          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    22ce:	000780a3          	sb	zero,1(a5)
    22d2:	0026871b          	addiw	a4,a3,2
    22d6:	0ec77263          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    22da:	00078123          	sb	zero,2(a5)
    22de:	0036871b          	addiw	a4,a3,3
    22e2:	0cc77c63          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    22e6:	000781a3          	sb	zero,3(a5)
    22ea:	0046871b          	addiw	a4,a3,4
    22ee:	0cc77663          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    22f2:	00078223          	sb	zero,4(a5)
    22f6:	0056871b          	addiw	a4,a3,5
    22fa:	0cc77063          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    22fe:	000782a3          	sb	zero,5(a5)
    2302:	0066871b          	addiw	a4,a3,6
    2306:	0ac77a63          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    230a:	00078323          	sb	zero,6(a5)
    230e:	0076871b          	addiw	a4,a3,7
    2312:	0ac77463          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    2316:	000783a3          	sb	zero,7(a5)
    231a:	0086871b          	addiw	a4,a3,8
    231e:	08c77e63          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    2322:	00078423          	sb	zero,8(a5)
    2326:	0096871b          	addiw	a4,a3,9
    232a:	08c77863          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    232e:	000784a3          	sb	zero,9(a5)
    2332:	00a6871b          	addiw	a4,a3,10
    2336:	08c77263          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    233a:	00078523          	sb	zero,10(a5)
    233e:	00b6871b          	addiw	a4,a3,11
    2342:	06c77c63          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    2346:	000785a3          	sb	zero,11(a5)
    234a:	00c6871b          	addiw	a4,a3,12
    234e:	06c77663          	bgeu	a4,a2,23ba <stpncpy+0x1ce>
    2352:	00078623          	sb	zero,12(a5)
    2356:	26b5                	addiw	a3,a3,13
    2358:	06c6f163          	bgeu	a3,a2,23ba <stpncpy+0x1ce>
    235c:	000786a3          	sb	zero,13(a5)
    2360:	8082                	ret
			;
		if (!n || !*s)
    2362:	c645                	beqz	a2,240a <stpncpy+0x21e>
    2364:	0005c783          	lbu	a5,0(a1)
    2368:	ea078be3          	beqz	a5,221e <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    236c:	479d                	li	a5,7
    236e:	02c7ff63          	bgeu	a5,a2,23ac <stpncpy+0x1c0>
    2372:	00000897          	auipc	a7,0x0
    2376:	61e8b883          	ld	a7,1566(a7) # 2990 <enable_deadlock_detect+0x18c>
    237a:	00000817          	auipc	a6,0x0
    237e:	61e83803          	ld	a6,1566(a6) # 2998 <enable_deadlock_detect+0x194>
    2382:	431d                	li	t1,7
    2384:	6198                	ld	a4,0(a1)
    2386:	011707b3          	add	a5,a4,a7
    238a:	fff74693          	not	a3,a4
    238e:	8ff5                	and	a5,a5,a3
    2390:	0107f7b3          	and	a5,a5,a6
    2394:	ef81                	bnez	a5,23ac <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2396:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2398:	1661                	addi	a2,a2,-8
    239a:	05a1                	addi	a1,a1,8
    239c:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    239e:	fec363e3          	bltu	t1,a2,2384 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    23a2:	e609                	bnez	a2,23ac <stpncpy+0x1c0>
    23a4:	a08d                	j	2406 <stpncpy+0x21a>
    23a6:	167d                	addi	a2,a2,-1
    23a8:	0505                	addi	a0,a0,1
    23aa:	ca01                	beqz	a2,23ba <stpncpy+0x1ce>
    23ac:	0005c783          	lbu	a5,0(a1)
    23b0:	0585                	addi	a1,a1,1
    23b2:	00f50023          	sb	a5,0(a0)
    23b6:	fbe5                	bnez	a5,23a6 <stpncpy+0x1ba>
		;
tail:
    23b8:	b59d                	j	221e <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    23ba:	8082                	ret
    23bc:	472d                	li	a4,11
    23be:	bdb5                	j	223a <stpncpy+0x4e>
    23c0:	00778713          	addi	a4,a5,7
    23c4:	45ad                	li	a1,11
    23c6:	fff60693          	addi	a3,a2,-1
    23ca:	e6b778e3          	bgeu	a4,a1,223a <stpncpy+0x4e>
    23ce:	b7fd                	j	23bc <stpncpy+0x1d0>
    23d0:	40a007b3          	neg	a5,a0
    23d4:	8832                	mv	a6,a2
    23d6:	8b9d                	andi	a5,a5,7
    23d8:	4681                	li	a3,0
    23da:	e4060be3          	beqz	a2,2230 <stpncpy+0x44>
    23de:	b7cd                	j	23c0 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23e0:	468d                	li	a3,3
    23e2:	bd75                	j	229e <stpncpy+0xb2>
    23e4:	872a                	mv	a4,a0
    23e6:	4681                	li	a3,0
    23e8:	bd5d                	j	229e <stpncpy+0xb2>
    23ea:	4685                	li	a3,1
    23ec:	bd4d                	j	229e <stpncpy+0xb2>
    23ee:	8082                	ret
    23f0:	87aa                	mv	a5,a0
    23f2:	4681                	li	a3,0
    23f4:	b5f9                	j	22c2 <stpncpy+0xd6>
    23f6:	4689                	li	a3,2
    23f8:	b55d                	j	229e <stpncpy+0xb2>
    23fa:	4691                	li	a3,4
    23fc:	b54d                	j	229e <stpncpy+0xb2>
    23fe:	4695                	li	a3,5
    2400:	bd79                	j	229e <stpncpy+0xb2>
    2402:	4699                	li	a3,6
    2404:	bd69                	j	229e <stpncpy+0xb2>
    2406:	8082                	ret
    2408:	8082                	ret
    240a:	8082                	ret

000000000000240c <basename>:

char *basename(char *s)
{
    240c:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    240e:	c54d                	beqz	a0,24b8 <basename+0xac>
    2410:	00054783          	lbu	a5,0(a0)
		return ".";
    2414:	00000517          	auipc	a0,0x0
    2418:	57450513          	addi	a0,a0,1396 # 2988 <enable_deadlock_detect+0x184>
	if (!s || !*s)
    241c:	e391                	bnez	a5,2420 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    241e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2420:	0076f713          	andi	a4,a3,7
    2424:	87b6                	mv	a5,a3
    2426:	cf51                	beqz	a4,24c2 <basename+0xb6>
    2428:	0785                	addi	a5,a5,1
    242a:	0077f713          	andi	a4,a5,7
    242e:	c729                	beqz	a4,2478 <basename+0x6c>
		if (!*s)
    2430:	0007c703          	lbu	a4,0(a5)
    2434:	fb75                	bnez	a4,2428 <basename+0x1c>
	return s - a;
    2436:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2438:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    243a:	cf8d                	beqz	a5,2474 <basename+0x68>
    243c:	00f68733          	add	a4,a3,a5
    2440:	02f00593          	li	a1,47
    2444:	a031                	j	2450 <basename+0x44>
		s[i] = 0;
    2446:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    244a:	17fd                	addi	a5,a5,-1
    244c:	177d                	addi	a4,a4,-1
    244e:	c39d                	beqz	a5,2474 <basename+0x68>
    2450:	00074603          	lbu	a2,0(a4)
    2454:	feb609e3          	beq	a2,a1,2446 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2458:	02f00613          	li	a2,47
    245c:	a011                	j	2460 <basename+0x54>
    245e:	cb99                	beqz	a5,2474 <basename+0x68>
    2460:	853e                	mv	a0,a5
    2462:	17fd                	addi	a5,a5,-1
    2464:	00f68733          	add	a4,a3,a5
    2468:	00074703          	lbu	a4,0(a4)
    246c:	fec719e3          	bne	a4,a2,245e <basename+0x52>
	return s + i;
    2470:	9536                	add	a0,a0,a3
    2472:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2474:	8536                	mv	a0,a3
    2476:	8082                	ret
    2478:	6390                	ld	a2,0(a5)
    247a:	00000517          	auipc	a0,0x0
    247e:	51653503          	ld	a0,1302(a0) # 2990 <enable_deadlock_detect+0x18c>
    2482:	00000597          	auipc	a1,0x0
    2486:	5165b583          	ld	a1,1302(a1) # 2998 <enable_deadlock_detect+0x194>
    248a:	fff64713          	not	a4,a2
    248e:	962a                	add	a2,a2,a0
    2490:	8f71                	and	a4,a4,a2
    2492:	8f6d                	and	a4,a4,a1
    2494:	eb11                	bnez	a4,24a8 <basename+0x9c>
    2496:	6790                	ld	a2,8(a5)
    2498:	07a1                	addi	a5,a5,8
    249a:	00a60733          	add	a4,a2,a0
    249e:	fff64613          	not	a2,a2
    24a2:	8f71                	and	a4,a4,a2
    24a4:	8f6d                	and	a4,a4,a1
    24a6:	db65                	beqz	a4,2496 <basename+0x8a>
	for (; *s; s++)
    24a8:	0007c703          	lbu	a4,0(a5)
    24ac:	d749                	beqz	a4,2436 <basename+0x2a>
    24ae:	0017c703          	lbu	a4,1(a5)
    24b2:	0785                	addi	a5,a5,1
    24b4:	ff6d                	bnez	a4,24ae <basename+0xa2>
    24b6:	b741                	j	2436 <basename+0x2a>
		return ".";
    24b8:	00000517          	auipc	a0,0x0
    24bc:	4d050513          	addi	a0,a0,1232 # 2988 <enable_deadlock_detect+0x184>
    24c0:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24c2:	6290                	ld	a2,0(a3)
    24c4:	00000517          	auipc	a0,0x0
    24c8:	4cc53503          	ld	a0,1228(a0) # 2990 <enable_deadlock_detect+0x18c>
    24cc:	00000597          	auipc	a1,0x0
    24d0:	4cc5b583          	ld	a1,1228(a1) # 2998 <enable_deadlock_detect+0x194>
    24d4:	fff64713          	not	a4,a2
    24d8:	962a                	add	a2,a2,a0
    24da:	8f71                	and	a4,a4,a2
    24dc:	8f6d                	and	a4,a4,a1
    24de:	df45                	beqz	a4,2496 <basename+0x8a>
    24e0:	b7f9                	j	24ae <basename+0xa2>

00000000000024e2 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    24e2:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    24e6:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24e8:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    24ec:	2501                	sext.w	a0,a0
    24ee:	8082                	ret

00000000000024f0 <close>:

int close(int fd)
{
	if (fd == 1) {
    24f0:	4785                	li	a5,1
    24f2:	00f50863          	beq	a0,a5,2502 <close+0x12>
	register long a7 __asm__("a7") = n;
    24f6:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24fa:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    24fe:	2501                	sext.w	a0,a0
    2500:	8082                	ret
{
    2502:	1101                	addi	sp,sp,-32
    2504:	ec06                	sd	ra,24(sp)
    2506:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2508:	cdffe0ef          	jal	ra,11e6 <__write_buffer>
		__clear_buffer();
    250c:	d03fe0ef          	jal	ra,120e <__clear_buffer>
    2510:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2512:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2516:	00000073          	ecall
}
    251a:	60e2                	ld	ra,24(sp)
    251c:	2501                	sext.w	a0,a0
    251e:	6105                	addi	sp,sp,32
    2520:	8082                	ret

0000000000002522 <read>:
	register long a7 __asm__("a7") = n;
    2522:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2526:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    252a:	8082                	ret

000000000000252c <write>:
	register long a7 __asm__("a7") = n;
    252c:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2530:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2534:	8082                	ret

0000000000002536 <getpid>:
	register long a7 __asm__("a7") = n;
    2536:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    253a:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    253e:	2501                	sext.w	a0,a0
    2540:	8082                	ret

0000000000002542 <getppid>:
	register long a7 __asm__("a7") = n;
    2542:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2546:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    254a:	2501                	sext.w	a0,a0
    254c:	8082                	ret

000000000000254e <sched_yield>:
	register long a7 __asm__("a7") = n;
    254e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2552:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2556:	2501                	sext.w	a0,a0
    2558:	8082                	ret

000000000000255a <fork>:
	register long a7 __asm__("a7") = n;
    255a:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    255e:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2562:	2501                	sext.w	a0,a0
    2564:	8082                	ret

0000000000002566 <exit>:

void exit(int code)
{
    2566:	1141                	addi	sp,sp,-16
    2568:	e406                	sd	ra,8(sp)
    256a:	e022                	sd	s0,0(sp)
    256c:	842a                	mv	s0,a0
	__write_buffer();
    256e:	c79fe0ef          	jal	ra,11e6 <__write_buffer>
	__clear_buffer();
    2572:	c9dfe0ef          	jal	ra,120e <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2576:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    257a:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    257c:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2580:	60a2                	ld	ra,8(sp)
    2582:	6402                	ld	s0,0(sp)
    2584:	0141                	addi	sp,sp,16
    2586:	8082                	ret

0000000000002588 <waitpid>:
	register long a7 __asm__("a7") = n;
    2588:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258c:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2590:	2501                	sext.w	a0,a0
    2592:	8082                	ret

0000000000002594 <exec>:
	register long a7 __asm__("a7") = n;
    2594:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2598:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    259c:	2501                	sext.w	a0,a0
    259e:	8082                	ret

00000000000025a0 <get_mtime>:

int64 get_mtime()
{
    25a0:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    25a2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25a6:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    25a8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25aa:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    25ae:	2501                	sext.w	a0,a0
    25b0:	ed01                	bnez	a0,25c8 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    25b2:	6722                	ld	a4,8(sp)
    25b4:	3e800793          	li	a5,1000
    25b8:	6682                	ld	a3,0(sp)
    25ba:	02f75733          	divu	a4,a4,a5
    25be:	02d78533          	mul	a0,a5,a3
    25c2:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    25c4:	0141                	addi	sp,sp,16
    25c6:	8082                	ret
	return -1;
    25c8:	557d                	li	a0,-1
    25ca:	bfed                	j	25c4 <get_mtime+0x24>

00000000000025cc <sys_get_time>:
	register long a7 __asm__("a7") = n;
    25cc:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25d0:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    25d4:	2501                	sext.w	a0,a0
    25d6:	8082                	ret

00000000000025d8 <sleep>:

int sleep(unsigned long long time)
{
    25d8:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    25da:	880a                	mv	a6,sp
{
    25dc:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    25de:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25e2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25e4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e6:	00000073          	ecall
	if (err == 0) {
    25ea:	2501                	sext.w	a0,a0
    25ec:	ed31                	bnez	a0,2648 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    25ee:	6722                	ld	a4,8(sp)
    25f0:	3e800793          	li	a5,1000
    25f4:	6682                	ld	a3,0(sp)
    25f6:	02f75733          	divu	a4,a4,a5
    25fa:	02d787b3          	mul	a5,a5,a3
    25fe:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2600:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2604:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2606:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2608:	00000073          	ecall
	if (err == 0) {
    260c:	2501                	sext.w	a0,a0
    260e:	e915                	bnez	a0,2642 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2610:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2612:	3e800693          	li	a3,1000
    2616:	a819                	j	262c <sleep+0x54>
	__asm_syscall("r"(a7))
    2618:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    261c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2620:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2622:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2624:	00000073          	ecall
	if (err == 0) {
    2628:	2501                	sext.w	a0,a0
    262a:	ed01                	bnez	a0,2642 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    262c:	6722                	ld	a4,8(sp)
    262e:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2630:	07c00893          	li	a7,124
    2634:	02d75733          	divu	a4,a4,a3
    2638:	02f687b3          	mul	a5,a3,a5
    263c:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    263e:	fcc7ede3          	bltu	a5,a2,2618 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2642:	4501                	li	a0,0
    2644:	0141                	addi	sp,sp,16
    2646:	8082                	ret
    2648:	57fd                	li	a5,-1
    264a:	bf5d                	j	2600 <sleep+0x28>

000000000000264c <sys_task_info>:
	register long a7 __asm__("a7") = n;
    264c:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2650:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2654:	2501                	sext.w	a0,a0
    2656:	8082                	ret

0000000000002658 <set_priority>:
	register long a7 __asm__("a7") = n;
    2658:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    265c:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2660:	2501                	sext.w	a0,a0
    2662:	8082                	ret

0000000000002664 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2664:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2668:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    266c:	2501                	sext.w	a0,a0
    266e:	8082                	ret

0000000000002670 <munmap>:
	register long a7 __asm__("a7") = n;
    2670:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2674:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2678:	2501                	sext.w	a0,a0
    267a:	8082                	ret

000000000000267c <wait>:

int wait(int *code)
{
    267c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    267e:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2682:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2684:	00000073          	ecall
	return waitpid(-1, code);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <spawn>:
	register long a7 __asm__("a7") = n;
    268c:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2690:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret

0000000000002698 <pipe>:
	register long a7 __asm__("a7") = n;
    2698:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    269c:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    26a0:	2501                	sext.w	a0,a0
    26a2:	8082                	ret

00000000000026a4 <mailread>:
	register long a7 __asm__("a7") = n;
    26a4:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26a8:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <mailwrite>:
	register long a7 __asm__("a7") = n;
    26b0:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26b4:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    26b8:	2501                	sext.w	a0,a0
    26ba:	8082                	ret

00000000000026bc <fstat>:
	register long a7 __asm__("a7") = n;
    26bc:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c0:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    26c4:	2501                	sext.w	a0,a0
    26c6:	8082                	ret

00000000000026c8 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    26c8:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    26ca:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    26ce:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26d0:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    26d4:	2501                	sext.w	a0,a0
    26d6:	8082                	ret

00000000000026d8 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    26d8:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    26da:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    26de:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26e0:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    26e4:	2501                	sext.w	a0,a0
    26e6:	8082                	ret

00000000000026e8 <link>:

int link(char *old_path, char *new_path)
{
    26e8:	87aa                	mv	a5,a0
    26ea:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    26ec:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    26f0:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    26f4:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    26f6:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    26fa:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26fc:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2700:	2501                	sext.w	a0,a0
    2702:	8082                	ret

0000000000002704 <unlink>:

int unlink(char *path)
{
    2704:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2706:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    270a:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    270e:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2710:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2718:	00000797          	auipc	a5,0x0
    271c:	3c07b783          	ld	a5,960(a5) # 2ad8 <_GLOBAL_OFFSET_TABLE_+0x8>
    2720:	439c                	lw	a5,0(a5)
    2722:	c799                	beqz	a5,2730 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2724:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2728:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    272c:	2501                	sext.w	a0,a0
    272e:	8082                	ret
{
    2730:	1101                	addi	sp,sp,-32
    2732:	ec06                	sd	ra,24(sp)
    2734:	e42e                	sd	a1,8(sp)
    2736:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2738:	fe7fe0ef          	jal	ra,171e <enable_thread_io_buffer>
    273c:	65a2                	ld	a1,8(sp)
    273e:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2740:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2744:	00000073          	ecall
}
    2748:	60e2                	ld	ra,24(sp)
    274a:	2501                	sext.w	a0,a0
    274c:	6105                	addi	sp,sp,32
    274e:	8082                	ret

0000000000002750 <gettid>:
	register long a7 __asm__("a7") = n;
    2750:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2754:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2758:	2501                	sext.w	a0,a0
    275a:	8082                	ret

000000000000275c <waittid>:

int waittid(int tid)
{
    275c:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    275e:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2762:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2766:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2768:	2501                	sext.w	a0,a0
	while (ret == -2) {
    276a:	00e51e63          	bne	a0,a4,2786 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    276e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2772:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2776:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    277a:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    277c:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2780:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2782:	fee506e3          	beq	a0,a4,276e <waittid+0x12>
	}
	return ret;
}
    2786:	8082                	ret

0000000000002788 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2788:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    278c:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    278e:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2792:	2501                	sext.w	a0,a0
    2794:	8082                	ret

0000000000002796 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2796:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    279a:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    279c:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    27a0:	2501                	sext.w	a0,a0
    27a2:	8082                	ret

00000000000027a4 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    27a4:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    27a8:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    27ac:	2501                	sext.w	a0,a0
    27ae:	8082                	ret

00000000000027b0 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    27b0:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    27b4:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    27b8:	2501                	sext.w	a0,a0
    27ba:	8082                	ret

00000000000027bc <semaphore_create>:
	register long a7 __asm__("a7") = n;
    27bc:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    27c0:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    27c4:	2501                	sext.w	a0,a0
    27c6:	8082                	ret

00000000000027c8 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    27c8:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    27cc:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    27d0:	2501                	sext.w	a0,a0
    27d2:	8082                	ret

00000000000027d4 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    27d4:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    27d8:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    27dc:	2501                	sext.w	a0,a0
    27de:	8082                	ret

00000000000027e0 <condvar_create>:
	register long a7 __asm__("a7") = n;
    27e0:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    27e4:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    27e8:	2501                	sext.w	a0,a0
    27ea:	8082                	ret

00000000000027ec <condvar_signal>:
	register long a7 __asm__("a7") = n;
    27ec:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    27f0:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    27f4:	2501                	sext.w	a0,a0
    27f6:	8082                	ret

00000000000027f8 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    27f8:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27fc:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2800:	2501                	sext.w	a0,a0
    2802:	8082                	ret

0000000000002804 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2804:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2808:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    280c:	2501                	sext.w	a0,a0
    280e:	8082                	ret
