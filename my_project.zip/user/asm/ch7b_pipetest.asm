
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch7b_pipetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	ac89                	j	1252 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

char STR[] = "hello pipe!";

int main()
{
    1002:	711d                	addi	sp,sp,-96
	// create pipe
	uint64 pipe_fd[2];
	int ret = pipe((void *)&pipe_fd);
    1004:	0028                	addi	a0,sp,8
{
    1006:	ec86                	sd	ra,88(sp)
    1008:	e8a2                	sd	s0,80(sp)
    100a:	e4a6                	sd	s1,72(sp)
    100c:	e0ca                	sd	s2,64(sp)
	int ret = pipe((void *)&pipe_fd);
    100e:	732010ef          	jal	ra,2740 <pipe>
	assert_eq(ret, 0);
    1012:	16051863          	bnez	a0,1182 <main+0x180>
	printf("[parent] read end = %p, write end = %p\n", pipe_fd[0],
    1016:	6642                	ld	a2,16(sp)
    1018:	65a2                	ld	a1,8(sp)
    101a:	00002517          	auipc	a0,0x2
    101e:	92650513          	addi	a0,a0,-1754 # 2940 <enable_deadlock_detect+0x94>
    1022:	38a000ef          	jal	ra,13ac <printf>
	       pipe_fd[1]);
	int pid = fork();
    1026:	5dc010ef          	jal	ra,2602 <fork>
	if (pid == 0) {
    102a:	ed3d                	bnez	a0,10a8 <main+0xa6>
		// child process, read from parent
		// close write_end
		close(pipe_fd[1]);
    102c:	4542                	lw	a0,16(sp)
		puts("[child] close write end");
		char buffer[32 + 1];
		int len_read = read(pipe_fd[0], buffer, 32);
    102e:	0824                	addi	s1,sp,24
		close(pipe_fd[1]);
    1030:	568010ef          	jal	ra,2598 <close>
		puts("[child] close write end");
    1034:	00002517          	auipc	a0,0x2
    1038:	93450513          	addi	a0,a0,-1740 # 2968 <enable_deadlock_detect+0xbc>
    103c:	287000ef          	jal	ra,1ac2 <puts>
		int len_read = read(pipe_fd[0], buffer, 32);
    1040:	4522                	lw	a0,8(sp)
    1042:	85a6                	mv	a1,s1
    1044:	02000613          	li	a2,32
    1048:	582010ef          	jal	ra,25ca <read>
    104c:	842a                	mv	s0,a0
		puts("[chile] read over");
    104e:	00002517          	auipc	a0,0x2
    1052:	93250513          	addi	a0,a0,-1742 # 2980 <enable_deadlock_detect+0xd4>
    1056:	26d000ef          	jal	ra,1ac2 <puts>
		buffer[len_read] = 0;
    105a:	2401                	sext.w	s0,s0
    105c:	04040793          	addi	a5,s0,64
    1060:	00278433          	add	s0,a5,sp
		assert_eq(strncmp(buffer, STR, strlen(STR)), 0);
    1064:	00002517          	auipc	a0,0x2
    1068:	bac50513          	addi	a0,a0,-1108 # 2c10 <STR>
		buffer[len_read] = 0;
    106c:	fc040c23          	sb	zero,-40(s0)
		assert_eq(strncmp(buffer, STR, strlen(STR)), 0);
    1070:	09e010ef          	jal	ra,210e <strlen>
    1074:	862a                	mv	a2,a0
    1076:	00002597          	auipc	a1,0x2
    107a:	b9a58593          	addi	a1,a1,-1126 # 2c10 <STR>
    107e:	8526                	mv	a0,s1
    1080:	044010ef          	jal	ra,20c4 <strncmp>
    1084:	12051d63          	bnez	a0,11be <main+0x1bc>
		puts("Read OK, child process exited!");
    1088:	00002517          	auipc	a0,0x2
    108c:	91050513          	addi	a0,a0,-1776 # 2998 <enable_deadlock_detect+0xec>
    1090:	233000ef          	jal	ra,1ac2 <puts>
		exit(0);
    1094:	4501                	li	a0,0
    1096:	578010ef          	jal	ra,260e <exit>
		wait(&exit_code);
		assert_eq(exit_code, 0);
		puts("pipetest passed!");
	}
	return 0;
}
    109a:	60e6                	ld	ra,88(sp)
    109c:	6446                	ld	s0,80(sp)
    109e:	64a6                	ld	s1,72(sp)
    10a0:	6906                	ld	s2,64(sp)
    10a2:	4501                	li	a0,0
    10a4:	6125                	addi	sp,sp,96
    10a6:	8082                	ret
		close(pipe_fd[0]);
    10a8:	4522                	lw	a0,8(sp)
    10aa:	4ee010ef          	jal	ra,2598 <close>
		printf("[parent] close read end\n");
    10ae:	00002517          	auipc	a0,0x2
    10b2:	90a50513          	addi	a0,a0,-1782 # 29b8 <enable_deadlock_detect+0x10c>
    10b6:	2f6000ef          	jal	ra,13ac <printf>
		assert_eq(write(pipe_fd[1], STR, strlen(STR)), strlen(STR));
    10ba:	4442                	lw	s0,16(sp)
    10bc:	00002517          	auipc	a0,0x2
    10c0:	b5450513          	addi	a0,a0,-1196 # 2c10 <STR>
    10c4:	04a010ef          	jal	ra,210e <strlen>
    10c8:	862a                	mv	a2,a0
    10ca:	00002597          	auipc	a1,0x2
    10ce:	b4658593          	addi	a1,a1,-1210 # 2c10 <STR>
    10d2:	8522                	mv	a0,s0
    10d4:	500010ef          	jal	ra,25d4 <write>
    10d8:	842a                	mv	s0,a0
    10da:	00002517          	auipc	a0,0x2
    10de:	b3650513          	addi	a0,a0,-1226 # 2c10 <STR>
    10e2:	02c010ef          	jal	ra,210e <strlen>
    10e6:	02a41963          	bne	s0,a0,1118 <main+0x116>
		printf("[parent] write over\n");
    10ea:	00002517          	auipc	a0,0x2
    10ee:	8ee50513          	addi	a0,a0,-1810 # 29d8 <enable_deadlock_detect+0x12c>
    10f2:	2ba000ef          	jal	ra,13ac <printf>
		close(pipe_fd[1]);
    10f6:	4542                	lw	a0,16(sp)
    10f8:	4a0010ef          	jal	ra,2598 <close>
		wait(&exit_code);
    10fc:	0828                	addi	a0,sp,24
		int exit_code = 0;
    10fe:	cc02                	sw	zero,24(sp)
		wait(&exit_code);
    1100:	624010ef          	jal	ra,2724 <wait>
		assert_eq(exit_code, 0);
    1104:	47e2                	lw	a5,24(sp)
    1106:	10079863          	bnez	a5,1216 <main+0x214>
		puts("pipetest passed!");
    110a:	00002517          	auipc	a0,0x2
    110e:	8e650513          	addi	a0,a0,-1818 # 29f0 <enable_deadlock_detect+0x144>
    1112:	1b1000ef          	jal	ra,1ac2 <puts>
    1116:	b751                	j	109a <main+0x98>
		assert_eq(write(pipe_fd[1], STR, strlen(STR)), strlen(STR));
    1118:	4c6010ef          	jal	ra,25de <getpid>
    111c:	842a                	mv	s0,a0
    111e:	00001517          	auipc	a0,0x1
    1122:	79a50513          	addi	a0,a0,1946 # 28b8 <enable_deadlock_detect+0xc>
    1126:	38e010ef          	jal	ra,24b4 <basename>
    112a:	4942                	lw	s2,16(sp)
    112c:	84aa                	mv	s1,a0
    112e:	00002517          	auipc	a0,0x2
    1132:	ae250513          	addi	a0,a0,-1310 # 2c10 <STR>
    1136:	7d9000ef          	jal	ra,210e <strlen>
    113a:	862a                	mv	a2,a0
    113c:	00002597          	auipc	a1,0x2
    1140:	ad458593          	addi	a1,a1,-1324 # 2c10 <STR>
    1144:	854a                	mv	a0,s2
    1146:	48e010ef          	jal	ra,25d4 <write>
    114a:	892a                	mv	s2,a0
    114c:	00002517          	auipc	a0,0x2
    1150:	ac450513          	addi	a0,a0,-1340 # 2c10 <STR>
    1154:	7bb000ef          	jal	ra,210e <strlen>
    1158:	88aa                	mv	a7,a0
    115a:	884a                	mv	a6,s2
    115c:	00001517          	auipc	a0,0x1
    1160:	7ac50513          	addi	a0,a0,1964 # 2908 <enable_deadlock_detect+0x5c>
    1164:	02300793          	li	a5,35
    1168:	8726                	mv	a4,s1
    116a:	86a2                	mv	a3,s0
    116c:	00001617          	auipc	a2,0x1
    1170:	79460613          	addi	a2,a2,1940 # 2900 <enable_deadlock_detect+0x54>
    1174:	45fd                	li	a1,31
    1176:	236000ef          	jal	ra,13ac <printf>
    117a:	557d                	li	a0,-1
    117c:	492010ef          	jal	ra,260e <exit>
    1180:	b7ad                	j	10ea <main+0xe8>
	assert_eq(ret, 0);
    1182:	842a                	mv	s0,a0
    1184:	45a010ef          	jal	ra,25de <getpid>
    1188:	84aa                	mv	s1,a0
    118a:	00001517          	auipc	a0,0x1
    118e:	72e50513          	addi	a0,a0,1838 # 28b8 <enable_deadlock_detect+0xc>
    1192:	322010ef          	jal	ra,24b4 <basename>
    1196:	872a                	mv	a4,a0
    1198:	4881                	li	a7,0
    119a:	00001517          	auipc	a0,0x1
    119e:	76e50513          	addi	a0,a0,1902 # 2908 <enable_deadlock_detect+0x5c>
    11a2:	8822                	mv	a6,s0
    11a4:	47b9                	li	a5,14
    11a6:	86a6                	mv	a3,s1
    11a8:	00001617          	auipc	a2,0x1
    11ac:	75860613          	addi	a2,a2,1880 # 2900 <enable_deadlock_detect+0x54>
    11b0:	45fd                	li	a1,31
    11b2:	1fa000ef          	jal	ra,13ac <printf>
    11b6:	557d                	li	a0,-1
    11b8:	456010ef          	jal	ra,260e <exit>
    11bc:	bda9                	j	1016 <main+0x14>
		assert_eq(strncmp(buffer, STR, strlen(STR)), 0);
    11be:	420010ef          	jal	ra,25de <getpid>
    11c2:	842a                	mv	s0,a0
    11c4:	00001517          	auipc	a0,0x1
    11c8:	6f450513          	addi	a0,a0,1780 # 28b8 <enable_deadlock_detect+0xc>
    11cc:	2e8010ef          	jal	ra,24b4 <basename>
    11d0:	892a                	mv	s2,a0
    11d2:	00002517          	auipc	a0,0x2
    11d6:	a3e50513          	addi	a0,a0,-1474 # 2c10 <STR>
    11da:	735000ef          	jal	ra,210e <strlen>
    11de:	862a                	mv	a2,a0
    11e0:	00002597          	auipc	a1,0x2
    11e4:	a3058593          	addi	a1,a1,-1488 # 2c10 <STR>
    11e8:	8526                	mv	a0,s1
    11ea:	6db000ef          	jal	ra,20c4 <strncmp>
    11ee:	882a                	mv	a6,a0
    11f0:	4881                	li	a7,0
    11f2:	00001517          	auipc	a0,0x1
    11f6:	71650513          	addi	a0,a0,1814 # 2908 <enable_deadlock_detect+0x5c>
    11fa:	47ed                	li	a5,27
    11fc:	874a                	mv	a4,s2
    11fe:	86a2                	mv	a3,s0
    1200:	00001617          	auipc	a2,0x1
    1204:	70060613          	addi	a2,a2,1792 # 2900 <enable_deadlock_detect+0x54>
    1208:	45fd                	li	a1,31
    120a:	1a2000ef          	jal	ra,13ac <printf>
    120e:	557d                	li	a0,-1
    1210:	3fe010ef          	jal	ra,260e <exit>
    1214:	bd95                	j	1088 <main+0x86>
		assert_eq(exit_code, 0);
    1216:	3c8010ef          	jal	ra,25de <getpid>
    121a:	842a                	mv	s0,a0
    121c:	00001517          	auipc	a0,0x1
    1220:	69c50513          	addi	a0,a0,1692 # 28b8 <enable_deadlock_detect+0xc>
    1224:	290010ef          	jal	ra,24b4 <basename>
    1228:	4862                	lw	a6,24(sp)
    122a:	872a                	mv	a4,a0
    122c:	4881                	li	a7,0
    122e:	00001517          	auipc	a0,0x1
    1232:	6da50513          	addi	a0,a0,1754 # 2908 <enable_deadlock_detect+0x5c>
    1236:	02900793          	li	a5,41
    123a:	86a2                	mv	a3,s0
    123c:	00001617          	auipc	a2,0x1
    1240:	6c460613          	addi	a2,a2,1732 # 2900 <enable_deadlock_detect+0x54>
    1244:	45fd                	li	a1,31
    1246:	166000ef          	jal	ra,13ac <printf>
    124a:	557d                	li	a0,-1
    124c:	3c2010ef          	jal	ra,260e <exit>
    1250:	bd6d                	j	110a <main+0x108>

0000000000001252 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1252:	1141                	addi	sp,sp,-16
    1254:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1256:	dadff0ef          	jal	ra,1002 <main>
    125a:	3b4010ef          	jal	ra,260e <exit>
	return 0;
    125e:	60a2                	ld	ra,8(sp)
    1260:	4501                	li	a0,0
    1262:	0141                	addi	sp,sp,16
    1264:	8082                	ret

0000000000001266 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1266:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1268:	4605                	li	a2,1
    126a:	00f10593          	addi	a1,sp,15
    126e:	4501                	li	a0,0
{
    1270:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1272:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1276:	354010ef          	jal	ra,25ca <read>
    127a:	4785                	li	a5,1
    127c:	00f51763          	bne	a0,a5,128a <getchar+0x24>
		return byte;
    1280:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1284:	60e2                	ld	ra,24(sp)
    1286:	6105                	addi	sp,sp,32
    1288:	8082                	ret
		return EOF;
    128a:	557d                	li	a0,-1
    128c:	bfe5                	j	1284 <getchar+0x1e>

000000000000128e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    128e:	00002517          	auipc	a0,0x2
    1292:	87252503          	lw	a0,-1934(a0) # 2b00 <buffer_len>
    1296:	e111                	bnez	a0,129a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1298:	8082                	ret
{
    129a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    129c:	862a                	mv	a2,a0
    129e:	00002597          	auipc	a1,0x2
    12a2:	86a58593          	addi	a1,a1,-1942 # 2b08 <buffer>
    12a6:	4505                	li	a0,1
{
    12a8:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12aa:	32a010ef          	jal	ra,25d4 <write>
}
    12ae:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12b0:	2501                	sext.w	a0,a0
}
    12b2:	0141                	addi	sp,sp,16
    12b4:	8082                	ret

00000000000012b6 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    12b6:	00002797          	auipc	a5,0x2
    12ba:	8407a523          	sw	zero,-1974(a5) # 2b00 <buffer_len>
}
    12be:	8082                	ret

00000000000012c0 <__fflush>:
	if (buffer_len == 0)
    12c0:	00002517          	auipc	a0,0x2
    12c4:	84052503          	lw	a0,-1984(a0) # 2b00 <buffer_len>
    12c8:	e511                	bnez	a0,12d4 <__fflush+0x14>
	buffer_len = 0;
    12ca:	00002797          	auipc	a5,0x2
    12ce:	8207ab23          	sw	zero,-1994(a5) # 2b00 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    12d2:	8082                	ret
{
    12d4:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12d6:	862a                	mv	a2,a0
    12d8:	00002597          	auipc	a1,0x2
    12dc:	83058593          	addi	a1,a1,-2000 # 2b08 <buffer>
    12e0:	4505                	li	a0,1
{
    12e2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12e4:	2f0010ef          	jal	ra,25d4 <write>
	return r >= 0 ? 0 : r;
    12e8:	0005079b          	sext.w	a5,a0
}
    12ec:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12ee:	0017a793          	slti	a5,a5,1
    12f2:	40f007bb          	negw	a5,a5
    12f6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    12f8:	00002797          	auipc	a5,0x2
    12fc:	8007a423          	sw	zero,-2040(a5) # 2b00 <buffer_len>
	return r >= 0 ? 0 : r;
    1300:	2501                	sext.w	a0,a0
}
    1302:	0141                	addi	sp,sp,16
    1304:	8082                	ret

0000000000001306 <fflush>:

int fflush(int fd)
{
    1306:	1101                	addi	sp,sp,-32
    1308:	e822                	sd	s0,16(sp)
    130a:	ec06                	sd	ra,24(sp)
    130c:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    130e:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1310:	4401                	li	s0,0
	if (fd == 1) {
    1312:	00e50863          	beq	a0,a4,1322 <fflush+0x1c>
}
    1316:	60e2                	ld	ra,24(sp)
    1318:	8522                	mv	a0,s0
    131a:	6442                	ld	s0,16(sp)
    131c:	64a2                	ld	s1,8(sp)
    131e:	6105                	addi	sp,sp,32
    1320:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1322:	00001497          	auipc	s1,0x1
    1326:	7de48493          	addi	s1,s1,2014 # 2b00 <buffer_len>
    132a:	1084a703          	lw	a4,264(s1)
    132e:	02a70e63          	beq	a4,a0,136a <fflush+0x64>
	if (buffer_len == 0)
    1332:	4080                	lw	s0,0(s1)
    1334:	c00d                	beqz	s0,1356 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1336:	8622                	mv	a2,s0
    1338:	00001597          	auipc	a1,0x1
    133c:	7d058593          	addi	a1,a1,2000 # 2b08 <buffer>
    1340:	294010ef          	jal	ra,25d4 <write>
	return r >= 0 ? 0 : r;
    1344:	0005079b          	sext.w	a5,a0
    1348:	0017a793          	slti	a5,a5,1
    134c:	40f007bb          	negw	a5,a5
    1350:	8d7d                	and	a0,a0,a5
    1352:	0005041b          	sext.w	s0,a0
}
    1356:	60e2                	ld	ra,24(sp)
    1358:	8522                	mv	a0,s0
    135a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    135c:	00001797          	auipc	a5,0x1
    1360:	7a07a223          	sw	zero,1956(a5) # 2b00 <buffer_len>
}
    1364:	64a2                	ld	s1,8(sp)
    1366:	6105                	addi	sp,sp,32
    1368:	8082                	ret
			mutex_lock(buffer_lock);
    136a:	10c4a503          	lw	a0,268(s1)
    136e:	4de010ef          	jal	ra,284c <mutex_lock>
	if (buffer_len == 0)
    1372:	4080                	lw	s0,0(s1)
    1374:	e811                	bnez	s0,1388 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1376:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    137a:	00001797          	auipc	a5,0x1
    137e:	7807a323          	sw	zero,1926(a5) # 2b00 <buffer_len>
			mutex_unlock(buffer_lock);
    1382:	4d6010ef          	jal	ra,2858 <mutex_unlock>
    1386:	bf41                	j	1316 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1388:	8622                	mv	a2,s0
    138a:	00001597          	auipc	a1,0x1
    138e:	77e58593          	addi	a1,a1,1918 # 2b08 <buffer>
    1392:	4505                	li	a0,1
    1394:	240010ef          	jal	ra,25d4 <write>
	return r >= 0 ? 0 : r;
    1398:	0005079b          	sext.w	a5,a0
    139c:	0017a793          	slti	a5,a5,1
    13a0:	40f007bb          	negw	a5,a5
    13a4:	8d7d                	and	a0,a0,a5
    13a6:	0005041b          	sext.w	s0,a0
	return r;
    13aa:	b7f1                	j	1376 <fflush+0x70>

00000000000013ac <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    13ac:	7131                	addi	sp,sp,-192
    13ae:	e0da                	sd	s6,64(sp)
    13b0:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    13b2:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    13b4:	013c                	addi	a5,sp,136
{
    13b6:	f0ca                	sd	s2,96(sp)
    13b8:	ecce                	sd	s3,88(sp)
    13ba:	e8d2                	sd	s4,80(sp)
    13bc:	e4d6                	sd	s5,72(sp)
    13be:	fc86                	sd	ra,120(sp)
    13c0:	f8a2                	sd	s0,112(sp)
    13c2:	f4a6                	sd	s1,104(sp)
    13c4:	89aa                	mv	s3,a0
    13c6:	e52e                	sd	a1,136(sp)
    13c8:	e932                	sd	a2,144(sp)
    13ca:	ed36                	sd	a3,152(sp)
    13cc:	f13a                	sd	a4,160(sp)
    13ce:	f942                	sd	a6,176(sp)
    13d0:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    13d2:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    13d4:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    13d8:	00001a17          	auipc	s4,0x1
    13dc:	728a0a13          	addi	s4,s4,1832 # 2b00 <buffer_len>
    13e0:	4a85                	li	s5,1
	buf[i++] = '0';
    13e2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13e6:	0009c783          	lbu	a5,0(s3)
    13ea:	18078663          	beqz	a5,1576 <printf+0x1ca>
    13ee:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13f0:	19278d63          	beq	a5,s2,158a <printf+0x1de>
    13f4:	0015c783          	lbu	a5,1(a1)
    13f8:	0585                	addi	a1,a1,1
    13fa:	fbfd                	bnez	a5,13f0 <printf+0x44>
    13fc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    13fe:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1402:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1406:	1b578863          	beq	a5,s5,15b6 <printf+0x20a>
		len = out_unlocked(s, l);
    140a:	85a2                	mv	a1,s0
    140c:	854e                	mv	a0,s3
    140e:	42a000ef          	jal	ra,1838 <out_unlocked>
		out(f, a, l);
		if (l)
    1412:	1c041063          	bnez	s0,15d2 <printf+0x226>
			continue;
		if (s[1] == 0)
    1416:	0014c783          	lbu	a5,1(s1)
    141a:	14078e63          	beqz	a5,1576 <printf+0x1ca>
			break;
		switch (s[1]) {
    141e:	07300713          	li	a4,115
    1422:	1ce78863          	beq	a5,a4,15f2 <printf+0x246>
    1426:	1af76863          	bltu	a4,a5,15d6 <printf+0x22a>
    142a:	06400713          	li	a4,100
    142e:	22e78063          	beq	a5,a4,164e <printf+0x2a2>
    1432:	07000713          	li	a4,112
    1436:	1ee79563          	bne	a5,a4,1620 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    143a:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    143c:	00001797          	auipc	a5,0x1
    1440:	7e478793          	addi	a5,a5,2020 # 2c20 <digits>
	buf[i++] = '0';
    1444:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1448:	6298                	ld	a4,0(a3)
    144a:	06a1                	addi	a3,a3,8
    144c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    144e:	00471393          	slli	t2,a4,0x4
    1452:	00871293          	slli	t0,a4,0x8
    1456:	00c71f93          	slli	t6,a4,0xc
    145a:	01071f13          	slli	t5,a4,0x10
    145e:	01471e93          	slli	t4,a4,0x14
    1462:	01871e13          	slli	t3,a4,0x18
    1466:	01c71893          	slli	a7,a4,0x1c
    146a:	02471813          	slli	a6,a4,0x24
    146e:	02871513          	slli	a0,a4,0x28
    1472:	02c71593          	slli	a1,a4,0x2c
    1476:	03071613          	slli	a2,a4,0x30
    147a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    147e:	03c75413          	srli	s0,a4,0x3c
    1482:	01c7531b          	srliw	t1,a4,0x1c
    1486:	03c3d393          	srli	t2,t2,0x3c
    148a:	03c2d293          	srli	t0,t0,0x3c
    148e:	03cfdf93          	srli	t6,t6,0x3c
    1492:	03cf5f13          	srli	t5,t5,0x3c
    1496:	03cede93          	srli	t4,t4,0x3c
    149a:	03ce5e13          	srli	t3,t3,0x3c
    149e:	03c8d893          	srli	a7,a7,0x3c
    14a2:	03c85813          	srli	a6,a6,0x3c
    14a6:	9171                	srli	a0,a0,0x3c
    14a8:	91f1                	srli	a1,a1,0x3c
    14aa:	9271                	srli	a2,a2,0x3c
    14ac:	92f1                	srli	a3,a3,0x3c
    14ae:	95be                	add	a1,a1,a5
    14b0:	963e                	add	a2,a2,a5
    14b2:	96be                	add	a3,a3,a5
    14b4:	943e                	add	s0,s0,a5
    14b6:	93be                	add	t2,t2,a5
    14b8:	92be                	add	t0,t0,a5
    14ba:	9fbe                	add	t6,t6,a5
    14bc:	9f3e                	add	t5,t5,a5
    14be:	9ebe                	add	t4,t4,a5
    14c0:	9e3e                	add	t3,t3,a5
    14c2:	98be                	add	a7,a7,a5
    14c4:	933e                	add	t1,t1,a5
    14c6:	983e                	add	a6,a6,a5
    14c8:	953e                	add	a0,a0,a5
    14ca:	0005c983          	lbu	s3,0(a1)
    14ce:	00044403          	lbu	s0,0(s0)
    14d2:	00064583          	lbu	a1,0(a2)
    14d6:	0003c383          	lbu	t2,0(t2)
    14da:	0006c603          	lbu	a2,0(a3)
    14de:	0002c283          	lbu	t0,0(t0)
    14e2:	000fcf83          	lbu	t6,0(t6)
    14e6:	000f4f03          	lbu	t5,0(t5)
    14ea:	000ece83          	lbu	t4,0(t4)
    14ee:	000e4e03          	lbu	t3,0(t3)
    14f2:	0008c883          	lbu	a7,0(a7)
    14f6:	00034303          	lbu	t1,0(t1)
    14fa:	00084803          	lbu	a6,0(a6)
    14fe:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1502:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1506:	92f1                	srli	a3,a3,0x3c
    1508:	8b3d                	andi	a4,a4,15
    150a:	96be                	add	a3,a3,a5
    150c:	97ba                	add	a5,a5,a4
    150e:	00810d23          	sb	s0,26(sp)
    1512:	00710da3          	sb	t2,27(sp)
    1516:	00510e23          	sb	t0,28(sp)
    151a:	01f10ea3          	sb	t6,29(sp)
    151e:	01e10f23          	sb	t5,30(sp)
    1522:	01d10fa3          	sb	t4,31(sp)
    1526:	03c10023          	sb	t3,32(sp)
    152a:	031100a3          	sb	a7,33(sp)
    152e:	02610123          	sb	t1,34(sp)
    1532:	030101a3          	sb	a6,35(sp)
    1536:	02a10223          	sb	a0,36(sp)
    153a:	033102a3          	sb	s3,37(sp)
    153e:	02b10323          	sb	a1,38(sp)
    1542:	02c103a3          	sb	a2,39(sp)
    1546:	0006c683          	lbu	a3,0(a3)
    154a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    154e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1552:	02d10423          	sb	a3,40(sp)
    1556:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    155a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    155e:	11578263          	beq	a5,s5,1662 <printf+0x2b6>
		len = out_unlocked(s, l);
    1562:	45c9                	li	a1,18
    1564:	0828                	addi	a0,sp,24
    1566:	2d2000ef          	jal	ra,1838 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    156a:	00248993          	addi	s3,s1,2
		if (!*s)
    156e:	0009c783          	lbu	a5,0(s3)
    1572:	e6079ee3          	bnez	a5,13ee <printf+0x42>
	}
	va_end(ap);
    1576:	70e6                	ld	ra,120(sp)
    1578:	7446                	ld	s0,112(sp)
    157a:	74a6                	ld	s1,104(sp)
    157c:	7906                	ld	s2,96(sp)
    157e:	69e6                	ld	s3,88(sp)
    1580:	6a46                	ld	s4,80(sp)
    1582:	6aa6                	ld	s5,72(sp)
    1584:	6b06                	ld	s6,64(sp)
    1586:	6129                	addi	sp,sp,192
    1588:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    158a:	0005c783          	lbu	a5,0(a1)
    158e:	84ae                	mv	s1,a1
    1590:	01278963          	beq	a5,s2,15a2 <printf+0x1f6>
    1594:	b5ad                	j	13fe <printf+0x52>
    1596:	0024c783          	lbu	a5,2(s1)
    159a:	0585                	addi	a1,a1,1
    159c:	0489                	addi	s1,s1,2
    159e:	e72790e3          	bne	a5,s2,13fe <printf+0x52>
    15a2:	0014c783          	lbu	a5,1(s1)
    15a6:	ff2788e3          	beq	a5,s2,1596 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    15aa:	108a2783          	lw	a5,264(s4)
		l = z - a;
    15ae:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    15b2:	e5579ce3          	bne	a5,s5,140a <printf+0x5e>
		mutex_lock(buffer_lock);
    15b6:	10ca2503          	lw	a0,268(s4)
    15ba:	292010ef          	jal	ra,284c <mutex_lock>
		len = out_unlocked(s, l);
    15be:	85a2                	mv	a1,s0
    15c0:	854e                	mv	a0,s3
    15c2:	276000ef          	jal	ra,1838 <out_unlocked>
		mutex_unlock(buffer_lock);
    15c6:	10ca2503          	lw	a0,268(s4)
    15ca:	28e010ef          	jal	ra,2858 <mutex_unlock>
		if (l)
    15ce:	e40404e3          	beqz	s0,1416 <printf+0x6a>
    15d2:	89a6                	mv	s3,s1
    15d4:	bd09                	j	13e6 <printf+0x3a>
		switch (s[1]) {
    15d6:	07800713          	li	a4,120
    15da:	04e79363          	bne	a5,a4,1620 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    15de:	67c2                	ld	a5,16(sp)
    15e0:	45c1                	li	a1,16
		s += 2;
    15e2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15e6:	4388                	lw	a0,0(a5)
    15e8:	07a1                	addi	a5,a5,8
    15ea:	e83e                	sd	a5,16(sp)
    15ec:	5f8000ef          	jal	ra,1be4 <printint.constprop.0>
		s += 2;
    15f0:	bfbd                	j	156e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    15f2:	67c2                	ld	a5,16(sp)
    15f4:	6380                	ld	s0,0(a5)
    15f6:	07a1                	addi	a5,a5,8
    15f8:	e83e                	sd	a5,16(sp)
    15fa:	1c040163          	beqz	s0,17bc <printf+0x410>
			l = strnlen(a, 200);
    15fe:	0c800593          	li	a1,200
    1602:	8522                	mv	a0,s0
    1604:	3f7000ef          	jal	ra,21fa <strnlen>
	if (buffer_lock_enabled == 1) {
    1608:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    160c:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1610:	19578663          	beq	a5,s5,179c <printf+0x3f0>
		len = out_unlocked(s, l);
    1614:	8522                	mv	a0,s0
    1616:	222000ef          	jal	ra,1838 <out_unlocked>
		s += 2;
    161a:	00248993          	addi	s3,s1,2
    161e:	bf81                	j	156e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1620:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1624:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1628:	0f578663          	beq	a5,s5,1714 <printf+0x368>
		len = out_unlocked(s, l);
    162c:	0828                	addi	a0,sp,24
    162e:	316000ef          	jal	ra,1944 <out_unlocked.constprop.0>
			putchar(s[1]);
    1632:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1636:	108a2783          	lw	a5,264(s4)
	char byte = c;
    163a:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    163e:	05578163          	beq	a5,s5,1680 <printf+0x2d4>
		len = out_unlocked(s, l);
    1642:	0828                	addi	a0,sp,24
    1644:	300000ef          	jal	ra,1944 <out_unlocked.constprop.0>
		s += 2;
    1648:	00248993          	addi	s3,s1,2
    164c:	b70d                	j	156e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    164e:	67c2                	ld	a5,16(sp)
    1650:	45a9                	li	a1,10
		s += 2;
    1652:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1656:	4388                	lw	a0,0(a5)
    1658:	07a1                	addi	a5,a5,8
    165a:	e83e                	sd	a5,16(sp)
    165c:	588000ef          	jal	ra,1be4 <printint.constprop.0>
		s += 2;
    1660:	b739                	j	156e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1662:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1666:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    166a:	1e2010ef          	jal	ra,284c <mutex_lock>
		len = out_unlocked(s, l);
    166e:	45c9                	li	a1,18
    1670:	0828                	addi	a0,sp,24
    1672:	1c6000ef          	jal	ra,1838 <out_unlocked>
		mutex_unlock(buffer_lock);
    1676:	10ca2503          	lw	a0,268(s4)
    167a:	1de010ef          	jal	ra,2858 <mutex_unlock>
		s += 2;
    167e:	bdc5                	j	156e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1680:	10ca2503          	lw	a0,268(s4)
    1684:	1c8010ef          	jal	ra,284c <mutex_lock>
		buffer[buffer_len++] = c;
    1688:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1690:	0017861b          	addiw	a2,a5,1
    1694:	97d2                	add	a5,a5,s4
    1696:	00ca2023          	sw	a2,0(s4)
    169a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    169e:	00c6cc63          	blt	a3,a2,16b6 <printf+0x30a>
    16a2:	47a9                	li	a5,10
    16a4:	06f40663          	beq	s0,a5,1710 <printf+0x364>
		mutex_unlock(buffer_lock);
    16a8:	10ca2503          	lw	a0,268(s4)
		s += 2;
    16ac:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    16b0:	1a8010ef          	jal	ra,2858 <mutex_unlock>
		s += 2;
    16b4:	bd6d                	j	156e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    16b6:	10000793          	li	a5,256
    16ba:	00f61e63          	bne	a2,a5,16d6 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    16be:	00001597          	auipc	a1,0x1
    16c2:	44a58593          	addi	a1,a1,1098 # 2b08 <buffer>
    16c6:	4505                	li	a0,1
    16c8:	70d000ef          	jal	ra,25d4 <write>
	buffer_len = 0;
    16cc:	00001797          	auipc	a5,0x1
    16d0:	4207aa23          	sw	zero,1076(a5) # 2b00 <buffer_len>
			if (r < 0) {
    16d4:	bfd1                	j	16a8 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    16d6:	709000ef          	jal	ra,25de <getpid>
    16da:	842a                	mv	s0,a0
    16dc:	00001517          	auipc	a0,0x1
    16e0:	33450513          	addi	a0,a0,820 # 2a10 <enable_deadlock_detect+0x164>
    16e4:	5d1000ef          	jal	ra,24b4 <basename>
    16e8:	872a                	mv	a4,a0
    16ea:	00001617          	auipc	a2,0x1
    16ee:	21660613          	addi	a2,a2,534 # 2900 <enable_deadlock_detect+0x54>
    16f2:	05400793          	li	a5,84
    16f6:	86a2                	mv	a3,s0
    16f8:	45fd                	li	a1,31
    16fa:	00001517          	auipc	a0,0x1
    16fe:	35650513          	addi	a0,a0,854 # 2a50 <enable_deadlock_detect+0x1a4>
    1702:	cabff0ef          	jal	ra,13ac <printf>
    1706:	557d                	li	a0,-1
    1708:	707000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    170c:	000a2603          	lw	a2,0(s4)
    1710:	de41                	beqz	a2,16a8 <printf+0x2fc>
    1712:	b775                	j	16be <printf+0x312>
		mutex_lock(buffer_lock);
    1714:	10ca2503          	lw	a0,268(s4)
    1718:	134010ef          	jal	ra,284c <mutex_lock>
		buffer[buffer_len++] = c;
    171c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1720:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1724:	0017861b          	addiw	a2,a5,1
    1728:	97d2                	add	a5,a5,s4
    172a:	00ca2023          	sw	a2,0(s4)
    172e:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1732:	02c6d163          	bge	a3,a2,1754 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1736:	10000793          	li	a5,256
    173a:	02f61263          	bne	a2,a5,175e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    173e:	00001597          	auipc	a1,0x1
    1742:	3ca58593          	addi	a1,a1,970 # 2b08 <buffer>
    1746:	4505                	li	a0,1
    1748:	68d000ef          	jal	ra,25d4 <write>
	buffer_len = 0;
    174c:	00001797          	auipc	a5,0x1
    1750:	3a07aa23          	sw	zero,948(a5) # 2b00 <buffer_len>
		mutex_unlock(buffer_lock);
    1754:	10ca2503          	lw	a0,268(s4)
    1758:	100010ef          	jal	ra,2858 <mutex_unlock>
    175c:	bdd9                	j	1632 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    175e:	681000ef          	jal	ra,25de <getpid>
    1762:	842a                	mv	s0,a0
    1764:	00001517          	auipc	a0,0x1
    1768:	2ac50513          	addi	a0,a0,684 # 2a10 <enable_deadlock_detect+0x164>
    176c:	549000ef          	jal	ra,24b4 <basename>
    1770:	872a                	mv	a4,a0
    1772:	00001617          	auipc	a2,0x1
    1776:	18e60613          	addi	a2,a2,398 # 2900 <enable_deadlock_detect+0x54>
    177a:	05400793          	li	a5,84
    177e:	86a2                	mv	a3,s0
    1780:	45fd                	li	a1,31
    1782:	00001517          	auipc	a0,0x1
    1786:	2ce50513          	addi	a0,a0,718 # 2a50 <enable_deadlock_detect+0x1a4>
    178a:	c23ff0ef          	jal	ra,13ac <printf>
    178e:	557d                	li	a0,-1
    1790:	67f000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    1794:	000a2603          	lw	a2,0(s4)
    1798:	de55                	beqz	a2,1754 <printf+0x3a8>
    179a:	b755                	j	173e <printf+0x392>
		mutex_lock(buffer_lock);
    179c:	10ca2503          	lw	a0,268(s4)
    17a0:	e42e                	sd	a1,8(sp)
		s += 2;
    17a2:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    17a6:	0a6010ef          	jal	ra,284c <mutex_lock>
		len = out_unlocked(s, l);
    17aa:	65a2                	ld	a1,8(sp)
    17ac:	8522                	mv	a0,s0
    17ae:	08a000ef          	jal	ra,1838 <out_unlocked>
		mutex_unlock(buffer_lock);
    17b2:	10ca2503          	lw	a0,268(s4)
    17b6:	0a2010ef          	jal	ra,2858 <mutex_unlock>
		s += 2;
    17ba:	bb55                	j	156e <printf+0x1c2>
				a = "(null)";
    17bc:	00001417          	auipc	s0,0x1
    17c0:	24c40413          	addi	s0,s0,588 # 2a08 <enable_deadlock_detect+0x15c>
    17c4:	bd2d                	j	15fe <printf+0x252>

00000000000017c6 <enable_thread_io_buffer>:
{
    17c6:	1101                	addi	sp,sp,-32
    17c8:	e822                	sd	s0,16(sp)
    17ca:	ec06                	sd	ra,24(sp)
    17cc:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    17ce:	00001417          	auipc	s0,0x1
    17d2:	33240413          	addi	s0,s0,818 # 2b00 <buffer_len>
    17d6:	05a010ef          	jal	ra,2830 <mutex_create>
    17da:	10a42623          	sw	a0,268(s0)
    17de:	00054a63          	bltz	a0,17f2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17e2:	4785                	li	a5,1
}
    17e4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17e6:	10f42423          	sw	a5,264(s0)
}
    17ea:	6442                	ld	s0,16(sp)
    17ec:	64a2                	ld	s1,8(sp)
    17ee:	6105                	addi	sp,sp,32
    17f0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    17f2:	5ed000ef          	jal	ra,25de <getpid>
    17f6:	84aa                	mv	s1,a0
    17f8:	00001517          	auipc	a0,0x1
    17fc:	21850513          	addi	a0,a0,536 # 2a10 <enable_deadlock_detect+0x164>
    1800:	4b5000ef          	jal	ra,24b4 <basename>
    1804:	872a                	mv	a4,a0
    1806:	04800793          	li	a5,72
    180a:	86a6                	mv	a3,s1
    180c:	00001517          	auipc	a0,0x1
    1810:	28450513          	addi	a0,a0,644 # 2a90 <enable_deadlock_detect+0x1e4>
    1814:	00001617          	auipc	a2,0x1
    1818:	0ec60613          	addi	a2,a2,236 # 2900 <enable_deadlock_detect+0x54>
    181c:	45fd                	li	a1,31
    181e:	b8fff0ef          	jal	ra,13ac <printf>
    1822:	557d                	li	a0,-1
    1824:	5eb000ef          	jal	ra,260e <exit>
	buffer_lock_enabled = 1;
    1828:	4785                	li	a5,1
}
    182a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    182c:	10f42423          	sw	a5,264(s0)
}
    1830:	6442                	ld	s0,16(sp)
    1832:	64a2                	ld	s1,8(sp)
    1834:	6105                	addi	sp,sp,32
    1836:	8082                	ret

0000000000001838 <out_unlocked>:
{
    1838:	7159                	addi	sp,sp,-112
    183a:	f486                	sd	ra,104(sp)
    183c:	f0a2                	sd	s0,96(sp)
    183e:	eca6                	sd	s1,88(sp)
    1840:	e8ca                	sd	s2,80(sp)
    1842:	e4ce                	sd	s3,72(sp)
    1844:	e0d2                	sd	s4,64(sp)
    1846:	fc56                	sd	s5,56(sp)
    1848:	f85a                	sd	s6,48(sp)
    184a:	f45e                	sd	s7,40(sp)
    184c:	f062                	sd	s8,32(sp)
    184e:	ec66                	sd	s9,24(sp)
    1850:	e86a                	sd	s10,16(sp)
    1852:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1854:	0e058663          	beqz	a1,1940 <out_unlocked+0x108>
    1858:	842a                	mv	s0,a0
    185a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    185e:	4981                	li	s3,0
    1860:	00001d17          	auipc	s10,0x1
    1864:	2a0d0d13          	addi	s10,s10,672 # 2b00 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1868:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    186c:	00001b17          	auipc	s6,0x1
    1870:	29cb0b13          	addi	s6,s6,668 # 2b08 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1874:	10000a93          	li	s5,256
    1878:	00001c97          	auipc	s9,0x1
    187c:	198c8c93          	addi	s9,s9,408 # 2a10 <enable_deadlock_detect+0x164>
    1880:	00001c17          	auipc	s8,0x1
    1884:	080c0c13          	addi	s8,s8,128 # 2900 <enable_deadlock_detect+0x54>
    1888:	00001b97          	auipc	s7,0x1
    188c:	1c8b8b93          	addi	s7,s7,456 # 2a50 <enable_deadlock_detect+0x1a4>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1890:	4a29                	li	s4,10
    1892:	a031                	j	189e <out_unlocked+0x66>
    1894:	09468863          	beq	a3,s4,1924 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1898:	0405                	addi	s0,s0,1
    189a:	04848163          	beq	s1,s0,18dc <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    189e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    18a2:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    18a6:	0017861b          	addiw	a2,a5,1
    18aa:	97ea                	add	a5,a5,s10
    18ac:	00cd2023          	sw	a2,0(s10)
    18b0:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b4:	fec950e3          	bge	s2,a2,1894 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    18b8:	05561263          	bne	a2,s5,18fc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    18bc:	85da                	mv	a1,s6
    18be:	4505                	li	a0,1
    18c0:	515000ef          	jal	ra,25d4 <write>
    18c4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18c6:	00001797          	auipc	a5,0x1
    18ca:	2207ad23          	sw	zero,570(a5) # 2b00 <buffer_len>
			if (r < 0) {
    18ce:	06054763          	bltz	a0,193c <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    18d2:	0405                	addi	s0,s0,1
			ret += r;
    18d4:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    18d8:	fc8493e3          	bne	s1,s0,189e <out_unlocked+0x66>
}
    18dc:	70a6                	ld	ra,104(sp)
    18de:	7406                	ld	s0,96(sp)
    18e0:	64e6                	ld	s1,88(sp)
    18e2:	6946                	ld	s2,80(sp)
    18e4:	6a06                	ld	s4,64(sp)
    18e6:	7ae2                	ld	s5,56(sp)
    18e8:	7b42                	ld	s6,48(sp)
    18ea:	7ba2                	ld	s7,40(sp)
    18ec:	7c02                	ld	s8,32(sp)
    18ee:	6ce2                	ld	s9,24(sp)
    18f0:	6d42                	ld	s10,16(sp)
    18f2:	6da2                	ld	s11,8(sp)
    18f4:	854e                	mv	a0,s3
    18f6:	69a6                	ld	s3,72(sp)
    18f8:	6165                	addi	sp,sp,112
    18fa:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18fc:	4e3000ef          	jal	ra,25de <getpid>
    1900:	8daa                	mv	s11,a0
    1902:	8566                	mv	a0,s9
    1904:	3b1000ef          	jal	ra,24b4 <basename>
    1908:	872a                	mv	a4,a0
    190a:	8662                	mv	a2,s8
    190c:	05400793          	li	a5,84
    1910:	86ee                	mv	a3,s11
    1912:	45fd                	li	a1,31
    1914:	855e                	mv	a0,s7
    1916:	a97ff0ef          	jal	ra,13ac <printf>
    191a:	557d                	li	a0,-1
    191c:	4f3000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    1920:	000d2603          	lw	a2,0(s10)
    1924:	da35                	beqz	a2,1898 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1926:	85da                	mv	a1,s6
    1928:	4505                	li	a0,1
    192a:	4ab000ef          	jal	ra,25d4 <write>
    192e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1930:	00001797          	auipc	a5,0x1
    1934:	1c07a823          	sw	zero,464(a5) # 2b00 <buffer_len>
			if (r < 0) {
    1938:	f8055de3          	bgez	a0,18d2 <out_unlocked+0x9a>
    193c:	89aa                	mv	s3,a0
    193e:	bf79                	j	18dc <out_unlocked+0xa4>
	int ret = 0;
    1940:	4981                	li	s3,0
    1942:	bf69                	j	18dc <out_unlocked+0xa4>

0000000000001944 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1944:	1101                	addi	sp,sp,-32
    1946:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1948:	00001497          	auipc	s1,0x1
    194c:	1b848493          	addi	s1,s1,440 # 2b00 <buffer_len>
    1950:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1952:	ec06                	sd	ra,24(sp)
    1954:	e822                	sd	s0,16(sp)
		char c = s[i];
    1956:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    195a:	0017861b          	addiw	a2,a5,1
    195e:	97a6                	add	a5,a5,s1
    1960:	00e78423          	sb	a4,8(a5)
    1964:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1966:	0ff00793          	li	a5,255
    196a:	00c7cc63          	blt	a5,a2,1982 <out_unlocked.constprop.0+0x3e>
    196e:	47a9                	li	a5,10
    1970:	06f70c63          	beq	a4,a5,19e8 <out_unlocked.constprop.0+0xa4>
    1974:	4601                	li	a2,0
}
    1976:	60e2                	ld	ra,24(sp)
    1978:	6442                	ld	s0,16(sp)
    197a:	64a2                	ld	s1,8(sp)
    197c:	8532                	mv	a0,a2
    197e:	6105                	addi	sp,sp,32
    1980:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1982:	10000793          	li	a5,256
    1986:	02f61563          	bne	a2,a5,19b0 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    198a:	00001597          	auipc	a1,0x1
    198e:	17e58593          	addi	a1,a1,382 # 2b08 <buffer>
    1992:	4505                	li	a0,1
    1994:	441000ef          	jal	ra,25d4 <write>
}
    1998:	60e2                	ld	ra,24(sp)
    199a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    199c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19a0:	00001797          	auipc	a5,0x1
    19a4:	1607a023          	sw	zero,352(a5) # 2b00 <buffer_len>
}
    19a8:	64a2                	ld	s1,8(sp)
    19aa:	8532                	mv	a0,a2
    19ac:	6105                	addi	sp,sp,32
    19ae:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19b0:	42f000ef          	jal	ra,25de <getpid>
    19b4:	842a                	mv	s0,a0
    19b6:	00001517          	auipc	a0,0x1
    19ba:	05a50513          	addi	a0,a0,90 # 2a10 <enable_deadlock_detect+0x164>
    19be:	2f7000ef          	jal	ra,24b4 <basename>
    19c2:	872a                	mv	a4,a0
    19c4:	00001617          	auipc	a2,0x1
    19c8:	f3c60613          	addi	a2,a2,-196 # 2900 <enable_deadlock_detect+0x54>
    19cc:	05400793          	li	a5,84
    19d0:	86a2                	mv	a3,s0
    19d2:	45fd                	li	a1,31
    19d4:	00001517          	auipc	a0,0x1
    19d8:	07c50513          	addi	a0,a0,124 # 2a50 <enable_deadlock_detect+0x1a4>
    19dc:	9d1ff0ef          	jal	ra,13ac <printf>
    19e0:	557d                	li	a0,-1
    19e2:	42d000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    19e6:	4090                	lw	a2,0(s1)
    19e8:	d659                	beqz	a2,1976 <out_unlocked.constprop.0+0x32>
    19ea:	b745                	j	198a <out_unlocked.constprop.0+0x46>

00000000000019ec <putchar>:
{
    19ec:	7139                	addi	sp,sp,-64
    19ee:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19f0:	00001497          	auipc	s1,0x1
    19f4:	11048493          	addi	s1,s1,272 # 2b00 <buffer_len>
    19f8:	1084a703          	lw	a4,264(s1)
{
    19fc:	f822                	sd	s0,48(sp)
	char byte = c;
    19fe:	0ff57413          	zext.b	s0,a0
{
    1a02:	fc06                	sd	ra,56(sp)
	char byte = c;
    1a04:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1a08:	4785                	li	a5,1
    1a0a:	00f70d63          	beq	a4,a5,1a24 <putchar+0x38>
		len = out_unlocked(s, l);
    1a0e:	01f10513          	addi	a0,sp,31
    1a12:	f33ff0ef          	jal	ra,1944 <out_unlocked.constprop.0>
}
    1a16:	70e2                	ld	ra,56(sp)
    1a18:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1a1a:	862a                	mv	a2,a0
}
    1a1c:	74a2                	ld	s1,40(sp)
    1a1e:	8532                	mv	a0,a2
    1a20:	6121                	addi	sp,sp,64
    1a22:	8082                	ret
		mutex_lock(buffer_lock);
    1a24:	10c4a503          	lw	a0,268(s1)
    1a28:	625000ef          	jal	ra,284c <mutex_lock>
		buffer[buffer_len++] = c;
    1a2c:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a2e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a32:	0017861b          	addiw	a2,a5,1
    1a36:	97a6                	add	a5,a5,s1
    1a38:	c090                	sw	a2,0(s1)
    1a3a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a3e:	02c6c263          	blt	a3,a2,1a62 <putchar+0x76>
    1a42:	47a9                	li	a5,10
    1a44:	06f40d63          	beq	s0,a5,1abe <putchar+0xd2>
    1a48:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a4a:	10c4a503          	lw	a0,268(s1)
    1a4e:	e432                	sd	a2,8(sp)
    1a50:	609000ef          	jal	ra,2858 <mutex_unlock>
    1a54:	6622                	ld	a2,8(sp)
}
    1a56:	70e2                	ld	ra,56(sp)
    1a58:	7442                	ld	s0,48(sp)
    1a5a:	74a2                	ld	s1,40(sp)
    1a5c:	8532                	mv	a0,a2
    1a5e:	6121                	addi	sp,sp,64
    1a60:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a62:	10000793          	li	a5,256
    1a66:	02f61063          	bne	a2,a5,1a86 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a6a:	00001597          	auipc	a1,0x1
    1a6e:	09e58593          	addi	a1,a1,158 # 2b08 <buffer>
    1a72:	4505                	li	a0,1
    1a74:	361000ef          	jal	ra,25d4 <write>
    1a78:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a7c:	00001797          	auipc	a5,0x1
    1a80:	0807a223          	sw	zero,132(a5) # 2b00 <buffer_len>
			if (r < 0) {
    1a84:	b7d9                	j	1a4a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a86:	359000ef          	jal	ra,25de <getpid>
    1a8a:	842a                	mv	s0,a0
    1a8c:	00001517          	auipc	a0,0x1
    1a90:	f8450513          	addi	a0,a0,-124 # 2a10 <enable_deadlock_detect+0x164>
    1a94:	221000ef          	jal	ra,24b4 <basename>
    1a98:	872a                	mv	a4,a0
    1a9a:	00001617          	auipc	a2,0x1
    1a9e:	e6660613          	addi	a2,a2,-410 # 2900 <enable_deadlock_detect+0x54>
    1aa2:	05400793          	li	a5,84
    1aa6:	86a2                	mv	a3,s0
    1aa8:	45fd                	li	a1,31
    1aaa:	00001517          	auipc	a0,0x1
    1aae:	fa650513          	addi	a0,a0,-90 # 2a50 <enable_deadlock_detect+0x1a4>
    1ab2:	8fbff0ef          	jal	ra,13ac <printf>
    1ab6:	557d                	li	a0,-1
    1ab8:	357000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    1abc:	4090                	lw	a2,0(s1)
    1abe:	d651                	beqz	a2,1a4a <putchar+0x5e>
    1ac0:	b76d                	j	1a6a <putchar+0x7e>

0000000000001ac2 <puts>:
{
    1ac2:	7139                	addi	sp,sp,-64
    1ac4:	f822                	sd	s0,48(sp)
    1ac6:	f426                	sd	s1,40(sp)
    1ac8:	fc06                	sd	ra,56(sp)
    1aca:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1acc:	00001417          	auipc	s0,0x1
    1ad0:	03440413          	addi	s0,s0,52 # 2b00 <buffer_len>
{
    1ad4:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ad6:	638000ef          	jal	ra,210e <strlen>
	if (buffer_lock_enabled == 1) {
    1ada:	10842703          	lw	a4,264(s0)
    1ade:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ae0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1ae2:	04f70563          	beq	a4,a5,1b2c <puts+0x6a>
		len = out_unlocked(s, l);
    1ae6:	8526                	mv	a0,s1
    1ae8:	d51ff0ef          	jal	ra,1838 <out_unlocked>
    1aec:	892a                	mv	s2,a0
    1aee:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1af0:	00095963          	bgez	s2,1b02 <puts+0x40>
}
    1af4:	70e2                	ld	ra,56(sp)
    1af6:	7442                	ld	s0,48(sp)
    1af8:	7902                	ld	s2,32(sp)
    1afa:	8526                	mv	a0,s1
    1afc:	74a2                	ld	s1,40(sp)
    1afe:	6121                	addi	sp,sp,64
    1b00:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1b02:	10842703          	lw	a4,264(s0)
	char byte = c;
    1b06:	44a9                	li	s1,10
    1b08:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1b0c:	4785                	li	a5,1
    1b0e:	02f70e63          	beq	a4,a5,1b4a <puts+0x88>
		len = out_unlocked(s, l);
    1b12:	01f10513          	addi	a0,sp,31
    1b16:	e2fff0ef          	jal	ra,1944 <out_unlocked.constprop.0>
}
    1b1a:	70e2                	ld	ra,56(sp)
    1b1c:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b1e:	41f5549b          	sraiw	s1,a0,0x1f
}
    1b22:	7902                	ld	s2,32(sp)
    1b24:	8526                	mv	a0,s1
    1b26:	74a2                	ld	s1,40(sp)
    1b28:	6121                	addi	sp,sp,64
    1b2a:	8082                	ret
		mutex_lock(buffer_lock);
    1b2c:	e42a                	sd	a0,8(sp)
    1b2e:	10c42503          	lw	a0,268(s0)
    1b32:	51b000ef          	jal	ra,284c <mutex_lock>
		len = out_unlocked(s, l);
    1b36:	65a2                	ld	a1,8(sp)
    1b38:	8526                	mv	a0,s1
    1b3a:	cffff0ef          	jal	ra,1838 <out_unlocked>
    1b3e:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b40:	10c42503          	lw	a0,268(s0)
    1b44:	515000ef          	jal	ra,2858 <mutex_unlock>
    1b48:	b75d                	j	1aee <puts+0x2c>
		mutex_lock(buffer_lock);
    1b4a:	10c42503          	lw	a0,268(s0)
    1b4e:	4ff000ef          	jal	ra,284c <mutex_lock>
		buffer[buffer_len++] = c;
    1b52:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b54:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b58:	0017861b          	addiw	a2,a5,1
    1b5c:	97a2                	add	a5,a5,s0
    1b5e:	c010                	sw	a2,0(s0)
    1b60:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b64:	06c6dc63          	bge	a3,a2,1bdc <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b68:	10000793          	li	a5,256
    1b6c:	02f61c63          	bne	a2,a5,1ba4 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b70:	00001597          	auipc	a1,0x1
    1b74:	f9858593          	addi	a1,a1,-104 # 2b08 <buffer>
    1b78:	4505                	li	a0,1
    1b7a:	25b000ef          	jal	ra,25d4 <write>
			if (r < 0) {
    1b7e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b80:	00001797          	auipc	a5,0x1
    1b84:	f807a023          	sw	zero,-128(a5) # 2b00 <buffer_len>
			if (r < 0) {
    1b88:	04054c63          	bltz	a0,1be0 <puts+0x11e>
			if (r < buffer_len) {
    1b8c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b8e:	10c42503          	lw	a0,268(s0)
    1b92:	4c7000ef          	jal	ra,2858 <mutex_unlock>
}
    1b96:	70e2                	ld	ra,56(sp)
    1b98:	7442                	ld	s0,48(sp)
    1b9a:	7902                	ld	s2,32(sp)
    1b9c:	8526                	mv	a0,s1
    1b9e:	74a2                	ld	s1,40(sp)
    1ba0:	6121                	addi	sp,sp,64
    1ba2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1ba4:	23b000ef          	jal	ra,25de <getpid>
    1ba8:	84aa                	mv	s1,a0
    1baa:	00001517          	auipc	a0,0x1
    1bae:	e6650513          	addi	a0,a0,-410 # 2a10 <enable_deadlock_detect+0x164>
    1bb2:	103000ef          	jal	ra,24b4 <basename>
    1bb6:	872a                	mv	a4,a0
    1bb8:	00001617          	auipc	a2,0x1
    1bbc:	d4860613          	addi	a2,a2,-696 # 2900 <enable_deadlock_detect+0x54>
    1bc0:	05400793          	li	a5,84
    1bc4:	86a6                	mv	a3,s1
    1bc6:	45fd                	li	a1,31
    1bc8:	00001517          	auipc	a0,0x1
    1bcc:	e8850513          	addi	a0,a0,-376 # 2a50 <enable_deadlock_detect+0x1a4>
    1bd0:	fdcff0ef          	jal	ra,13ac <printf>
    1bd4:	557d                	li	a0,-1
    1bd6:	239000ef          	jal	ra,260e <exit>
	if (buffer_len == 0)
    1bda:	4010                	lw	a2,0(s0)
    1bdc:	da45                	beqz	a2,1b8c <puts+0xca>
    1bde:	bf49                	j	1b70 <puts+0xae>
    1be0:	54fd                	li	s1,-1
    1be2:	b775                	j	1b8e <puts+0xcc>

0000000000001be4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1be4:	715d                	addi	sp,sp,-80
    1be6:	e486                	sd	ra,72(sp)
    1be8:	e0a2                	sd	s0,64(sp)
    1bea:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1bec:	14054363          	bltz	a0,1d32 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bf0:	02b577bb          	remuw	a5,a0,a1
    1bf4:	00001617          	auipc	a2,0x1
    1bf8:	02c60613          	addi	a2,a2,44 # 2c20 <digits>
	buf[16] = 0;
    1bfc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c00:	0005871b          	sext.w	a4,a1
    1c04:	1782                	slli	a5,a5,0x20
    1c06:	9381                	srli	a5,a5,0x20
    1c08:	97b2                	add	a5,a5,a2
    1c0a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c0e:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1c12:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1c16:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1c18:	0eb56763          	bltu	a0,a1,1d06 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c1c:	02e877bb          	remuw	a5,a6,a4
    1c20:	1782                	slli	a5,a5,0x20
    1c22:	9381                	srli	a5,a5,0x20
    1c24:	97b2                	add	a5,a5,a2
    1c26:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c2a:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1c2e:	02f10323          	sb	a5,38(sp)
    1c32:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1c34:	0ce86963          	bltu	a6,a4,1d06 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c38:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c3c:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c40:	1582                	slli	a1,a1,0x20
    1c42:	9181                	srli	a1,a1,0x20
    1c44:	95b2                	add	a1,a1,a2
    1c46:	0005c583          	lbu	a1,0(a1)
    1c4a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c4e:	0007859b          	sext.w	a1,a5
    1c52:	16e6e563          	bltu	a3,a4,1dbc <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c56:	02e7f6bb          	remuw	a3,a5,a4
    1c5a:	1682                	slli	a3,a3,0x20
    1c5c:	9281                	srli	a3,a3,0x20
    1c5e:	96b2                	add	a3,a3,a2
    1c60:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c64:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c68:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c6c:	16e5e163          	bltu	a1,a4,1dce <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c70:	02e876bb          	remuw	a3,a6,a4
    1c74:	1682                	slli	a3,a3,0x20
    1c76:	9281                	srli	a3,a3,0x20
    1c78:	96b2                	add	a3,a3,a2
    1c7a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c7e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c82:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c86:	14e86d63          	bltu	a6,a4,1de0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c8a:	02e5f6bb          	remuw	a3,a1,a4
    1c8e:	1682                	slli	a3,a3,0x20
    1c90:	9281                	srli	a3,a3,0x20
    1c92:	96b2                	add	a3,a3,a2
    1c94:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c98:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c9c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ca0:	10e5e563          	bltu	a1,a4,1daa <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ca4:	02e876bb          	remuw	a3,a6,a4
    1ca8:	1682                	slli	a3,a3,0x20
    1caa:	9281                	srli	a3,a3,0x20
    1cac:	96b2                	add	a3,a3,a2
    1cae:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cb2:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cb6:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1cba:	14e86263          	bltu	a6,a4,1dfe <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1cbe:	02e5f6bb          	remuw	a3,a1,a4
    1cc2:	1682                	slli	a3,a3,0x20
    1cc4:	9281                	srli	a3,a3,0x20
    1cc6:	96b2                	add	a3,a3,a2
    1cc8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ccc:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1cd0:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1cd4:	14e5e463          	bltu	a1,a4,1e1c <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1cd8:	02e876bb          	remuw	a3,a6,a4
    1cdc:	1682                	slli	a3,a3,0x20
    1cde:	9281                	srli	a3,a3,0x20
    1ce0:	96b2                	add	a3,a3,a2
    1ce2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ce6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1cea:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cee:	14e86063          	bltu	a6,a4,1e2e <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1cf2:	1782                	slli	a5,a5,0x20
    1cf4:	9381                	srli	a5,a5,0x20
    1cf6:	97b2                	add	a5,a5,a2
    1cf8:	0007c703          	lbu	a4,0(a5)
    1cfc:	4799                	li	a5,6
    1cfe:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1d02:	10054763          	bltz	a0,1e10 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1d06:	00001497          	auipc	s1,0x1
    1d0a:	dfa48493          	addi	s1,s1,-518 # 2b00 <buffer_len>
    1d0e:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1d12:	0828                	addi	a0,sp,24
    1d14:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1d16:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1d18:	00f50433          	add	s0,a0,a5
    1d1c:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1d1e:	06e68463          	beq	a3,a4,1d86 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1d22:	8522                	mv	a0,s0
    1d24:	b15ff0ef          	jal	ra,1838 <out_unlocked>
}
    1d28:	60a6                	ld	ra,72(sp)
    1d2a:	6406                	ld	s0,64(sp)
    1d2c:	74e2                	ld	s1,56(sp)
    1d2e:	6161                	addi	sp,sp,80
    1d30:	8082                	ret
		x = -xx;
    1d32:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d36:	02b877bb          	remuw	a5,a6,a1
    1d3a:	00001617          	auipc	a2,0x1
    1d3e:	ee660613          	addi	a2,a2,-282 # 2c20 <digits>
	buf[16] = 0;
    1d42:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d46:	0005871b          	sext.w	a4,a1
    1d4a:	1782                	slli	a5,a5,0x20
    1d4c:	9381                	srli	a5,a5,0x20
    1d4e:	97b2                	add	a5,a5,a2
    1d50:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d54:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d58:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d5c:	08b86b63          	bltu	a6,a1,1df2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d60:	02e8f7bb          	remuw	a5,a7,a4
    1d64:	1782                	slli	a5,a5,0x20
    1d66:	9381                	srli	a5,a5,0x20
    1d68:	97b2                	add	a5,a5,a2
    1d6a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d6e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d72:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d76:	ece8f1e3          	bgeu	a7,a4,1c38 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d7a:	02d00793          	li	a5,45
    1d7e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d82:	47b5                	li	a5,13
    1d84:	b749                	j	1d06 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d86:	10c4a503          	lw	a0,268(s1)
    1d8a:	e42e                	sd	a1,8(sp)
    1d8c:	2c1000ef          	jal	ra,284c <mutex_lock>
		len = out_unlocked(s, l);
    1d90:	65a2                	ld	a1,8(sp)
    1d92:	8522                	mv	a0,s0
    1d94:	aa5ff0ef          	jal	ra,1838 <out_unlocked>
		mutex_unlock(buffer_lock);
    1d98:	10c4a503          	lw	a0,268(s1)
    1d9c:	2bd000ef          	jal	ra,2858 <mutex_unlock>
}
    1da0:	60a6                	ld	ra,72(sp)
    1da2:	6406                	ld	s0,64(sp)
    1da4:	74e2                	ld	s1,56(sp)
    1da6:	6161                	addi	sp,sp,80
    1da8:	8082                	ret
		buf[i--] = digits[x % base];
    1daa:	47a9                	li	a5,10
	if (sign)
    1dac:	f4055de3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1db0:	02d00793          	li	a5,45
    1db4:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1db8:	47a5                	li	a5,9
    1dba:	b7b1                	j	1d06 <printint.constprop.0+0x122>
    1dbc:	47b5                	li	a5,13
	if (sign)
    1dbe:	f40554e3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dc2:	02d00793          	li	a5,45
    1dc6:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1dca:	47b1                	li	a5,12
    1dcc:	bf2d                	j	1d06 <printint.constprop.0+0x122>
    1dce:	47b1                	li	a5,12
	if (sign)
    1dd0:	f2055be3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dd4:	02d00793          	li	a5,45
    1dd8:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ddc:	47ad                	li	a5,11
    1dde:	b725                	j	1d06 <printint.constprop.0+0x122>
    1de0:	47ad                	li	a5,11
	if (sign)
    1de2:	f20552e3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de6:	02d00793          	li	a5,45
    1dea:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1dee:	47a9                	li	a5,10
    1df0:	bf19                	j	1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1df2:	02d00793          	li	a5,45
    1df6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1dfa:	47b9                	li	a5,14
    1dfc:	b729                	j	1d06 <printint.constprop.0+0x122>
    1dfe:	47a5                	li	a5,9
	if (sign)
    1e00:	f00553e3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e04:	02d00793          	li	a5,45
    1e08:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1e0c:	47a1                	li	a5,8
    1e0e:	bde5                	j	1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e10:	02d00793          	li	a5,45
    1e14:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1e18:	4795                	li	a5,5
    1e1a:	b5f5                	j	1d06 <printint.constprop.0+0x122>
    1e1c:	47a1                	li	a5,8
	if (sign)
    1e1e:	ee0554e3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e22:	02d00793          	li	a5,45
    1e26:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1e2a:	479d                	li	a5,7
    1e2c:	bde9                	j	1d06 <printint.constprop.0+0x122>
    1e2e:	479d                	li	a5,7
	if (sign)
    1e30:	ec055be3          	bgez	a0,1d06 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e34:	02d00793          	li	a5,45
    1e38:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e3c:	4799                	li	a5,6
    1e3e:	b5e1                	j	1d06 <printint.constprop.0+0x122>

0000000000001e40 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e40:	02000793          	li	a5,32
    1e44:	00f50663          	beq	a0,a5,1e50 <isspace+0x10>
    1e48:	355d                	addiw	a0,a0,-9
    1e4a:	00553513          	sltiu	a0,a0,5
    1e4e:	8082                	ret
    1e50:	4505                	li	a0,1
}
    1e52:	8082                	ret

0000000000001e54 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e54:	fd05051b          	addiw	a0,a0,-48
}
    1e58:	00a53513          	sltiu	a0,a0,10
    1e5c:	8082                	ret

0000000000001e5e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e5e:	02000613          	li	a2,32
    1e62:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e64:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e68:	ff77869b          	addiw	a3,a5,-9
    1e6c:	04c78c63          	beq	a5,a2,1ec4 <atoi+0x66>
    1e70:	0007871b          	sext.w	a4,a5
    1e74:	04d5f863          	bgeu	a1,a3,1ec4 <atoi+0x66>
		s++;
	switch (*s) {
    1e78:	02b00693          	li	a3,43
    1e7c:	04d78963          	beq	a5,a3,1ece <atoi+0x70>
    1e80:	02d00693          	li	a3,45
    1e84:	06d78263          	beq	a5,a3,1ee8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e88:	fd07061b          	addiw	a2,a4,-48
    1e8c:	47a5                	li	a5,9
    1e8e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e90:	4e01                	li	t3,0
	while (isdigit(*s))
    1e92:	04c7e963          	bltu	a5,a2,1ee4 <atoi+0x86>
	int n = 0, neg = 0;
    1e96:	4501                	li	a0,0
	while (isdigit(*s))
    1e98:	4825                	li	a6,9
    1e9a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1e9e:	0025179b          	slliw	a5,a0,0x2
    1ea2:	9fa9                	addw	a5,a5,a0
    1ea4:	fd07031b          	addiw	t1,a4,-48
    1ea8:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1eac:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1eb0:	0685                	addi	a3,a3,1
    1eb2:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1eb6:	0006071b          	sext.w	a4,a2
    1eba:	feb870e3          	bgeu	a6,a1,1e9a <atoi+0x3c>
	return neg ? n : -n;
    1ebe:	000e0563          	beqz	t3,1ec8 <atoi+0x6a>
}
    1ec2:	8082                	ret
		s++;
    1ec4:	0505                	addi	a0,a0,1
    1ec6:	bf79                	j	1e64 <atoi+0x6>
	return neg ? n : -n;
    1ec8:	4113053b          	subw	a0,t1,a7
    1ecc:	8082                	ret
	while (isdigit(*s))
    1ece:	00154703          	lbu	a4,1(a0)
    1ed2:	47a5                	li	a5,9
		s++;
    1ed4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ed8:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1edc:	4e01                	li	t3,0
	while (isdigit(*s))
    1ede:	2701                	sext.w	a4,a4
    1ee0:	fac7fbe3          	bgeu	a5,a2,1e96 <atoi+0x38>
    1ee4:	4501                	li	a0,0
}
    1ee6:	8082                	ret
	while (isdigit(*s))
    1ee8:	00154703          	lbu	a4,1(a0)
    1eec:	47a5                	li	a5,9
		s++;
    1eee:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ef2:	fd07061b          	addiw	a2,a4,-48
    1ef6:	2701                	sext.w	a4,a4
    1ef8:	fec7e6e3          	bltu	a5,a2,1ee4 <atoi+0x86>
		neg = 1;
    1efc:	4e05                	li	t3,1
    1efe:	bf61                	j	1e96 <atoi+0x38>

0000000000001f00 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f00:	16060d63          	beqz	a2,207a <memset+0x17a>
    1f04:	40a007b3          	neg	a5,a0
    1f08:	8b9d                	andi	a5,a5,7
    1f0a:	00778693          	addi	a3,a5,7
    1f0e:	482d                	li	a6,11
    1f10:	0ff5f713          	zext.b	a4,a1
    1f14:	fff60593          	addi	a1,a2,-1
    1f18:	1706e263          	bltu	a3,a6,207c <memset+0x17c>
    1f1c:	16d5ea63          	bltu	a1,a3,2090 <memset+0x190>
    1f20:	16078563          	beqz	a5,208a <memset+0x18a>
    1f24:	00e50023          	sb	a4,0(a0)
    1f28:	4685                	li	a3,1
    1f2a:	00150593          	addi	a1,a0,1
    1f2e:	14d78c63          	beq	a5,a3,2086 <memset+0x186>
    1f32:	00e500a3          	sb	a4,1(a0)
    1f36:	4689                	li	a3,2
    1f38:	00250593          	addi	a1,a0,2
    1f3c:	14d78d63          	beq	a5,a3,2096 <memset+0x196>
    1f40:	00e50123          	sb	a4,2(a0)
    1f44:	468d                	li	a3,3
    1f46:	00350593          	addi	a1,a0,3
    1f4a:	12d78b63          	beq	a5,a3,2080 <memset+0x180>
    1f4e:	00e501a3          	sb	a4,3(a0)
    1f52:	4691                	li	a3,4
    1f54:	00450593          	addi	a1,a0,4
    1f58:	14d78163          	beq	a5,a3,209a <memset+0x19a>
    1f5c:	00e50223          	sb	a4,4(a0)
    1f60:	4695                	li	a3,5
    1f62:	00550593          	addi	a1,a0,5
    1f66:	12d78c63          	beq	a5,a3,209e <memset+0x19e>
    1f6a:	00e502a3          	sb	a4,5(a0)
    1f6e:	469d                	li	a3,7
    1f70:	00650593          	addi	a1,a0,6
    1f74:	12d79763          	bne	a5,a3,20a2 <memset+0x1a2>
    1f78:	00750593          	addi	a1,a0,7
    1f7c:	00e50323          	sb	a4,6(a0)
    1f80:	481d                	li	a6,7
    1f82:	00871693          	slli	a3,a4,0x8
    1f86:	01071893          	slli	a7,a4,0x10
    1f8a:	8ed9                	or	a3,a3,a4
    1f8c:	01871313          	slli	t1,a4,0x18
    1f90:	0116e6b3          	or	a3,a3,a7
    1f94:	0066e6b3          	or	a3,a3,t1
    1f98:	02071893          	slli	a7,a4,0x20
    1f9c:	02871e13          	slli	t3,a4,0x28
    1fa0:	0116e6b3          	or	a3,a3,a7
    1fa4:	40f60333          	sub	t1,a2,a5
    1fa8:	03071893          	slli	a7,a4,0x30
    1fac:	01c6e6b3          	or	a3,a3,t3
    1fb0:	0116e6b3          	or	a3,a3,a7
    1fb4:	03871e13          	slli	t3,a4,0x38
    1fb8:	97aa                	add	a5,a5,a0
    1fba:	ff837893          	andi	a7,t1,-8
    1fbe:	01c6e6b3          	or	a3,a3,t3
    1fc2:	98be                	add	a7,a7,a5
    1fc4:	e394                	sd	a3,0(a5)
    1fc6:	07a1                	addi	a5,a5,8
    1fc8:	ff179ee3          	bne	a5,a7,1fc4 <memset+0xc4>
    1fcc:	ff837893          	andi	a7,t1,-8
    1fd0:	011587b3          	add	a5,a1,a7
    1fd4:	010886bb          	addw	a3,a7,a6
    1fd8:	0b130663          	beq	t1,a7,2084 <memset+0x184>
    1fdc:	00e78023          	sb	a4,0(a5)
    1fe0:	0016859b          	addiw	a1,a3,1
    1fe4:	08c5fb63          	bgeu	a1,a2,207a <memset+0x17a>
    1fe8:	00e780a3          	sb	a4,1(a5)
    1fec:	0026859b          	addiw	a1,a3,2
    1ff0:	08c5f563          	bgeu	a1,a2,207a <memset+0x17a>
    1ff4:	00e78123          	sb	a4,2(a5)
    1ff8:	0036859b          	addiw	a1,a3,3
    1ffc:	06c5ff63          	bgeu	a1,a2,207a <memset+0x17a>
    2000:	00e781a3          	sb	a4,3(a5)
    2004:	0046859b          	addiw	a1,a3,4
    2008:	06c5f963          	bgeu	a1,a2,207a <memset+0x17a>
    200c:	00e78223          	sb	a4,4(a5)
    2010:	0056859b          	addiw	a1,a3,5
    2014:	06c5f363          	bgeu	a1,a2,207a <memset+0x17a>
    2018:	00e782a3          	sb	a4,5(a5)
    201c:	0066859b          	addiw	a1,a3,6
    2020:	04c5fd63          	bgeu	a1,a2,207a <memset+0x17a>
    2024:	00e78323          	sb	a4,6(a5)
    2028:	0076859b          	addiw	a1,a3,7
    202c:	04c5f763          	bgeu	a1,a2,207a <memset+0x17a>
    2030:	00e783a3          	sb	a4,7(a5)
    2034:	0086859b          	addiw	a1,a3,8
    2038:	04c5f163          	bgeu	a1,a2,207a <memset+0x17a>
    203c:	00e78423          	sb	a4,8(a5)
    2040:	0096859b          	addiw	a1,a3,9
    2044:	02c5fb63          	bgeu	a1,a2,207a <memset+0x17a>
    2048:	00e784a3          	sb	a4,9(a5)
    204c:	00a6859b          	addiw	a1,a3,10
    2050:	02c5f563          	bgeu	a1,a2,207a <memset+0x17a>
    2054:	00e78523          	sb	a4,10(a5)
    2058:	00b6859b          	addiw	a1,a3,11
    205c:	00c5ff63          	bgeu	a1,a2,207a <memset+0x17a>
    2060:	00e785a3          	sb	a4,11(a5)
    2064:	00c6859b          	addiw	a1,a3,12
    2068:	00c5f963          	bgeu	a1,a2,207a <memset+0x17a>
    206c:	00e78623          	sb	a4,12(a5)
    2070:	26b5                	addiw	a3,a3,13
    2072:	00c6f463          	bgeu	a3,a2,207a <memset+0x17a>
    2076:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    207a:	8082                	ret
    207c:	46ad                	li	a3,11
    207e:	bd79                	j	1f1c <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2080:	480d                	li	a6,3
    2082:	b701                	j	1f82 <memset+0x82>
    2084:	8082                	ret
    2086:	4805                	li	a6,1
    2088:	bded                	j	1f82 <memset+0x82>
    208a:	85aa                	mv	a1,a0
    208c:	4801                	li	a6,0
    208e:	bdd5                	j	1f82 <memset+0x82>
    2090:	87aa                	mv	a5,a0
    2092:	4681                	li	a3,0
    2094:	b7a1                	j	1fdc <memset+0xdc>
    2096:	4809                	li	a6,2
    2098:	b5ed                	j	1f82 <memset+0x82>
    209a:	4811                	li	a6,4
    209c:	b5dd                	j	1f82 <memset+0x82>
    209e:	4815                	li	a6,5
    20a0:	b5cd                	j	1f82 <memset+0x82>
    20a2:	4819                	li	a6,6
    20a4:	bdf9                	j	1f82 <memset+0x82>

00000000000020a6 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    20a6:	00054783          	lbu	a5,0(a0)
    20aa:	0005c703          	lbu	a4,0(a1)
    20ae:	00e79863          	bne	a5,a4,20be <strcmp+0x18>
    20b2:	0505                	addi	a0,a0,1
    20b4:	0585                	addi	a1,a1,1
    20b6:	fbe5                	bnez	a5,20a6 <strcmp>
    20b8:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    20ba:	9d19                	subw	a0,a0,a4
    20bc:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    20be:	0007851b          	sext.w	a0,a5
    20c2:	bfe5                	j	20ba <strcmp+0x14>

00000000000020c4 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    20c4:	ca15                	beqz	a2,20f8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20c6:	00054783          	lbu	a5,0(a0)
	if (!n--)
    20ca:	167d                	addi	a2,a2,-1
    20cc:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20d0:	eb99                	bnez	a5,20e6 <strncmp+0x22>
    20d2:	a815                	j	2106 <strncmp+0x42>
    20d4:	00a68e63          	beq	a3,a0,20f0 <strncmp+0x2c>
    20d8:	0505                	addi	a0,a0,1
    20da:	00f71b63          	bne	a4,a5,20f0 <strncmp+0x2c>
    20de:	00054783          	lbu	a5,0(a0)
    20e2:	cf89                	beqz	a5,20fc <strncmp+0x38>
    20e4:	85b2                	mv	a1,a2
    20e6:	0005c703          	lbu	a4,0(a1)
    20ea:	00158613          	addi	a2,a1,1
    20ee:	f37d                	bnez	a4,20d4 <strncmp+0x10>
		;
	return *l - *r;
    20f0:	0007851b          	sext.w	a0,a5
    20f4:	9d19                	subw	a0,a0,a4
    20f6:	8082                	ret
		return 0;
    20f8:	4501                	li	a0,0
}
    20fa:	8082                	ret
	return *l - *r;
    20fc:	0015c703          	lbu	a4,1(a1)
    2100:	4501                	li	a0,0
    2102:	9d19                	subw	a0,a0,a4
    2104:	8082                	ret
    2106:	0005c703          	lbu	a4,0(a1)
    210a:	4501                	li	a0,0
    210c:	b7e5                	j	20f4 <strncmp+0x30>

000000000000210e <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    210e:	00757793          	andi	a5,a0,7
    2112:	cf89                	beqz	a5,212c <strlen+0x1e>
    2114:	87aa                	mv	a5,a0
    2116:	a029                	j	2120 <strlen+0x12>
    2118:	0785                	addi	a5,a5,1
    211a:	0077f713          	andi	a4,a5,7
    211e:	cb01                	beqz	a4,212e <strlen+0x20>
		if (!*s)
    2120:	0007c703          	lbu	a4,0(a5)
    2124:	fb75                	bnez	a4,2118 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2126:	40a78533          	sub	a0,a5,a0
}
    212a:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    212c:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    212e:	6394                	ld	a3,0(a5)
    2130:	00001597          	auipc	a1,0x1
    2134:	9b85b583          	ld	a1,-1608(a1) # 2ae8 <enable_deadlock_detect+0x23c>
    2138:	00001617          	auipc	a2,0x1
    213c:	9b863603          	ld	a2,-1608(a2) # 2af0 <enable_deadlock_detect+0x244>
    2140:	a019                	j	2146 <strlen+0x38>
    2142:	6794                	ld	a3,8(a5)
    2144:	07a1                	addi	a5,a5,8
    2146:	00b68733          	add	a4,a3,a1
    214a:	fff6c693          	not	a3,a3
    214e:	8f75                	and	a4,a4,a3
    2150:	8f71                	and	a4,a4,a2
    2152:	db65                	beqz	a4,2142 <strlen+0x34>
	for (; *s; s++)
    2154:	0007c703          	lbu	a4,0(a5)
    2158:	d779                	beqz	a4,2126 <strlen+0x18>
    215a:	0017c703          	lbu	a4,1(a5)
    215e:	0785                	addi	a5,a5,1
    2160:	d379                	beqz	a4,2126 <strlen+0x18>
    2162:	0017c703          	lbu	a4,1(a5)
    2166:	0785                	addi	a5,a5,1
    2168:	fb6d                	bnez	a4,215a <strlen+0x4c>
    216a:	bf75                	j	2126 <strlen+0x18>

000000000000216c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    216c:	00757713          	andi	a4,a0,7
{
    2170:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2172:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2176:	cb19                	beqz	a4,218c <memchr+0x20>
    2178:	ce25                	beqz	a2,21f0 <memchr+0x84>
    217a:	0007c703          	lbu	a4,0(a5)
    217e:	04b70e63          	beq	a4,a1,21da <memchr+0x6e>
    2182:	0785                	addi	a5,a5,1
    2184:	0077f713          	andi	a4,a5,7
    2188:	167d                	addi	a2,a2,-1
    218a:	f77d                	bnez	a4,2178 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    218c:	4501                	li	a0,0
	if (n && *s != c) {
    218e:	c235                	beqz	a2,21f2 <memchr+0x86>
    2190:	0007c703          	lbu	a4,0(a5)
    2194:	04b70363          	beq	a4,a1,21da <memchr+0x6e>
		size_t k = ONES * c;
    2198:	00001517          	auipc	a0,0x1
    219c:	96053503          	ld	a0,-1696(a0) # 2af8 <enable_deadlock_detect+0x24c>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21a0:	471d                	li	a4,7
		size_t k = ONES * c;
    21a2:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21a6:	02c77a63          	bgeu	a4,a2,21da <memchr+0x6e>
    21aa:	00001897          	auipc	a7,0x1
    21ae:	93e8b883          	ld	a7,-1730(a7) # 2ae8 <enable_deadlock_detect+0x23c>
    21b2:	00001817          	auipc	a6,0x1
    21b6:	93e83803          	ld	a6,-1730(a6) # 2af0 <enable_deadlock_detect+0x244>
    21ba:	431d                	li	t1,7
    21bc:	a029                	j	21c6 <memchr+0x5a>
		     w++, n -= SS)
    21be:	1661                	addi	a2,a2,-8
    21c0:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21c2:	02c37963          	bgeu	t1,a2,21f4 <memchr+0x88>
    21c6:	6398                	ld	a4,0(a5)
    21c8:	8f29                	xor	a4,a4,a0
    21ca:	011706b3          	add	a3,a4,a7
    21ce:	fff74713          	not	a4,a4
    21d2:	8f75                	and	a4,a4,a3
    21d4:	01077733          	and	a4,a4,a6
    21d8:	d37d                	beqz	a4,21be <memchr+0x52>
{
    21da:	853e                	mv	a0,a5
    21dc:	97b2                	add	a5,a5,a2
    21de:	a021                	j	21e6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21e0:	0505                	addi	a0,a0,1
    21e2:	00f50763          	beq	a0,a5,21f0 <memchr+0x84>
    21e6:	00054703          	lbu	a4,0(a0)
    21ea:	feb71be3          	bne	a4,a1,21e0 <memchr+0x74>
    21ee:	8082                	ret
	return n ? (void *)s : 0;
    21f0:	4501                	li	a0,0
}
    21f2:	8082                	ret
	return n ? (void *)s : 0;
    21f4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    21f6:	f275                	bnez	a2,21da <memchr+0x6e>
}
    21f8:	8082                	ret

00000000000021fa <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    21fa:	1101                	addi	sp,sp,-32
    21fc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    21fe:	862e                	mv	a2,a1
{
    2200:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2202:	4581                	li	a1,0
{
    2204:	e426                	sd	s1,8(sp)
    2206:	ec06                	sd	ra,24(sp)
    2208:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    220a:	f63ff0ef          	jal	ra,216c <memchr>
	return p ? p - s : n;
    220e:	c519                	beqz	a0,221c <strnlen+0x22>
}
    2210:	60e2                	ld	ra,24(sp)
    2212:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2214:	8d05                	sub	a0,a0,s1
}
    2216:	64a2                	ld	s1,8(sp)
    2218:	6105                	addi	sp,sp,32
    221a:	8082                	ret
    221c:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    221e:	8522                	mv	a0,s0
}
    2220:	6442                	ld	s0,16(sp)
    2222:	64a2                	ld	s1,8(sp)
    2224:	6105                	addi	sp,sp,32
    2226:	8082                	ret

0000000000002228 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2228:	00a5c7b3          	xor	a5,a1,a0
    222c:	8b9d                	andi	a5,a5,7
    222e:	eb95                	bnez	a5,2262 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2230:	0075f793          	andi	a5,a1,7
    2234:	e7b1                	bnez	a5,2280 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2236:	6198                	ld	a4,0(a1)
    2238:	00001617          	auipc	a2,0x1
    223c:	8b063603          	ld	a2,-1872(a2) # 2ae8 <enable_deadlock_detect+0x23c>
    2240:	00001817          	auipc	a6,0x1
    2244:	8b083803          	ld	a6,-1872(a6) # 2af0 <enable_deadlock_detect+0x244>
    2248:	a029                	j	2252 <stpcpy+0x2a>
    224a:	05a1                	addi	a1,a1,8
    224c:	e118                	sd	a4,0(a0)
    224e:	6198                	ld	a4,0(a1)
    2250:	0521                	addi	a0,a0,8
    2252:	00c707b3          	add	a5,a4,a2
    2256:	fff74693          	not	a3,a4
    225a:	8ff5                	and	a5,a5,a3
    225c:	0107f7b3          	and	a5,a5,a6
    2260:	d7ed                	beqz	a5,224a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2262:	0005c783          	lbu	a5,0(a1)
    2266:	00f50023          	sb	a5,0(a0)
    226a:	c785                	beqz	a5,2292 <stpcpy+0x6a>
    226c:	0015c783          	lbu	a5,1(a1)
    2270:	0505                	addi	a0,a0,1
    2272:	0585                	addi	a1,a1,1
    2274:	00f50023          	sb	a5,0(a0)
    2278:	fbf5                	bnez	a5,226c <stpcpy+0x44>
		;
	return d;
}
    227a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    227c:	0505                	addi	a0,a0,1
    227e:	df45                	beqz	a4,2236 <stpcpy+0xe>
			if (!(*d = *s))
    2280:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2284:	0585                	addi	a1,a1,1
    2286:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    228a:	00f50023          	sb	a5,0(a0)
    228e:	f7fd                	bnez	a5,227c <stpcpy+0x54>
}
    2290:	8082                	ret
    2292:	8082                	ret

0000000000002294 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2294:	00a5c7b3          	xor	a5,a1,a0
    2298:	8b9d                	andi	a5,a5,7
    229a:	1a079863          	bnez	a5,244a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    229e:	0075f793          	andi	a5,a1,7
    22a2:	16078463          	beqz	a5,240a <stpncpy+0x176>
    22a6:	ea01                	bnez	a2,22b6 <stpncpy+0x22>
    22a8:	a421                	j	24b0 <stpncpy+0x21c>
    22aa:	167d                	addi	a2,a2,-1
    22ac:	0505                	addi	a0,a0,1
    22ae:	14070e63          	beqz	a4,240a <stpncpy+0x176>
    22b2:	1a060863          	beqz	a2,2462 <stpncpy+0x1ce>
    22b6:	0005c783          	lbu	a5,0(a1)
    22ba:	0585                	addi	a1,a1,1
    22bc:	0075f713          	andi	a4,a1,7
    22c0:	00f50023          	sb	a5,0(a0)
    22c4:	f3fd                	bnez	a5,22aa <stpncpy+0x16>
    22c6:	4805                	li	a6,1
    22c8:	1a061863          	bnez	a2,2478 <stpncpy+0x1e4>
    22cc:	40a007b3          	neg	a5,a0
    22d0:	8b9d                	andi	a5,a5,7
    22d2:	4681                	li	a3,0
    22d4:	18061a63          	bnez	a2,2468 <stpncpy+0x1d4>
    22d8:	00778713          	addi	a4,a5,7
    22dc:	45ad                	li	a1,11
    22de:	18b76363          	bltu	a4,a1,2464 <stpncpy+0x1d0>
    22e2:	1ae6eb63          	bltu	a3,a4,2498 <stpncpy+0x204>
    22e6:	1a078363          	beqz	a5,248c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22ea:	00050023          	sb	zero,0(a0)
    22ee:	4685                	li	a3,1
    22f0:	00150713          	addi	a4,a0,1
    22f4:	18d78f63          	beq	a5,a3,2492 <stpncpy+0x1fe>
    22f8:	000500a3          	sb	zero,1(a0)
    22fc:	4689                	li	a3,2
    22fe:	00250713          	addi	a4,a0,2
    2302:	18d78e63          	beq	a5,a3,249e <stpncpy+0x20a>
    2306:	00050123          	sb	zero,2(a0)
    230a:	468d                	li	a3,3
    230c:	00350713          	addi	a4,a0,3
    2310:	16d78c63          	beq	a5,a3,2488 <stpncpy+0x1f4>
    2314:	000501a3          	sb	zero,3(a0)
    2318:	4691                	li	a3,4
    231a:	00450713          	addi	a4,a0,4
    231e:	18d78263          	beq	a5,a3,24a2 <stpncpy+0x20e>
    2322:	00050223          	sb	zero,4(a0)
    2326:	4695                	li	a3,5
    2328:	00550713          	addi	a4,a0,5
    232c:	16d78d63          	beq	a5,a3,24a6 <stpncpy+0x212>
    2330:	000502a3          	sb	zero,5(a0)
    2334:	469d                	li	a3,7
    2336:	00650713          	addi	a4,a0,6
    233a:	16d79863          	bne	a5,a3,24aa <stpncpy+0x216>
    233e:	00750713          	addi	a4,a0,7
    2342:	00050323          	sb	zero,6(a0)
    2346:	40f80833          	sub	a6,a6,a5
    234a:	ff887593          	andi	a1,a6,-8
    234e:	97aa                	add	a5,a5,a0
    2350:	95be                	add	a1,a1,a5
    2352:	0007b023          	sd	zero,0(a5)
    2356:	07a1                	addi	a5,a5,8
    2358:	feb79de3          	bne	a5,a1,2352 <stpncpy+0xbe>
    235c:	ff887593          	andi	a1,a6,-8
    2360:	9ead                	addw	a3,a3,a1
    2362:	00b707b3          	add	a5,a4,a1
    2366:	12b80863          	beq	a6,a1,2496 <stpncpy+0x202>
    236a:	00078023          	sb	zero,0(a5)
    236e:	0016871b          	addiw	a4,a3,1
    2372:	0ec77863          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    2376:	000780a3          	sb	zero,1(a5)
    237a:	0026871b          	addiw	a4,a3,2
    237e:	0ec77263          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    2382:	00078123          	sb	zero,2(a5)
    2386:	0036871b          	addiw	a4,a3,3
    238a:	0cc77c63          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    238e:	000781a3          	sb	zero,3(a5)
    2392:	0046871b          	addiw	a4,a3,4
    2396:	0cc77663          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    239a:	00078223          	sb	zero,4(a5)
    239e:	0056871b          	addiw	a4,a3,5
    23a2:	0cc77063          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23a6:	000782a3          	sb	zero,5(a5)
    23aa:	0066871b          	addiw	a4,a3,6
    23ae:	0ac77a63          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23b2:	00078323          	sb	zero,6(a5)
    23b6:	0076871b          	addiw	a4,a3,7
    23ba:	0ac77463          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23be:	000783a3          	sb	zero,7(a5)
    23c2:	0086871b          	addiw	a4,a3,8
    23c6:	08c77e63          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23ca:	00078423          	sb	zero,8(a5)
    23ce:	0096871b          	addiw	a4,a3,9
    23d2:	08c77863          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23d6:	000784a3          	sb	zero,9(a5)
    23da:	00a6871b          	addiw	a4,a3,10
    23de:	08c77263          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23e2:	00078523          	sb	zero,10(a5)
    23e6:	00b6871b          	addiw	a4,a3,11
    23ea:	06c77c63          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23ee:	000785a3          	sb	zero,11(a5)
    23f2:	00c6871b          	addiw	a4,a3,12
    23f6:	06c77663          	bgeu	a4,a2,2462 <stpncpy+0x1ce>
    23fa:	00078623          	sb	zero,12(a5)
    23fe:	26b5                	addiw	a3,a3,13
    2400:	06c6f163          	bgeu	a3,a2,2462 <stpncpy+0x1ce>
    2404:	000786a3          	sb	zero,13(a5)
    2408:	8082                	ret
			;
		if (!n || !*s)
    240a:	c645                	beqz	a2,24b2 <stpncpy+0x21e>
    240c:	0005c783          	lbu	a5,0(a1)
    2410:	ea078be3          	beqz	a5,22c6 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2414:	479d                	li	a5,7
    2416:	02c7ff63          	bgeu	a5,a2,2454 <stpncpy+0x1c0>
    241a:	00000897          	auipc	a7,0x0
    241e:	6ce8b883          	ld	a7,1742(a7) # 2ae8 <enable_deadlock_detect+0x23c>
    2422:	00000817          	auipc	a6,0x0
    2426:	6ce83803          	ld	a6,1742(a6) # 2af0 <enable_deadlock_detect+0x244>
    242a:	431d                	li	t1,7
    242c:	6198                	ld	a4,0(a1)
    242e:	011707b3          	add	a5,a4,a7
    2432:	fff74693          	not	a3,a4
    2436:	8ff5                	and	a5,a5,a3
    2438:	0107f7b3          	and	a5,a5,a6
    243c:	ef81                	bnez	a5,2454 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    243e:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2440:	1661                	addi	a2,a2,-8
    2442:	05a1                	addi	a1,a1,8
    2444:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2446:	fec363e3          	bltu	t1,a2,242c <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    244a:	e609                	bnez	a2,2454 <stpncpy+0x1c0>
    244c:	a08d                	j	24ae <stpncpy+0x21a>
    244e:	167d                	addi	a2,a2,-1
    2450:	0505                	addi	a0,a0,1
    2452:	ca01                	beqz	a2,2462 <stpncpy+0x1ce>
    2454:	0005c783          	lbu	a5,0(a1)
    2458:	0585                	addi	a1,a1,1
    245a:	00f50023          	sb	a5,0(a0)
    245e:	fbe5                	bnez	a5,244e <stpncpy+0x1ba>
		;
tail:
    2460:	b59d                	j	22c6 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2462:	8082                	ret
    2464:	472d                	li	a4,11
    2466:	bdb5                	j	22e2 <stpncpy+0x4e>
    2468:	00778713          	addi	a4,a5,7
    246c:	45ad                	li	a1,11
    246e:	fff60693          	addi	a3,a2,-1
    2472:	e6b778e3          	bgeu	a4,a1,22e2 <stpncpy+0x4e>
    2476:	b7fd                	j	2464 <stpncpy+0x1d0>
    2478:	40a007b3          	neg	a5,a0
    247c:	8832                	mv	a6,a2
    247e:	8b9d                	andi	a5,a5,7
    2480:	4681                	li	a3,0
    2482:	e4060be3          	beqz	a2,22d8 <stpncpy+0x44>
    2486:	b7cd                	j	2468 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2488:	468d                	li	a3,3
    248a:	bd75                	j	2346 <stpncpy+0xb2>
    248c:	872a                	mv	a4,a0
    248e:	4681                	li	a3,0
    2490:	bd5d                	j	2346 <stpncpy+0xb2>
    2492:	4685                	li	a3,1
    2494:	bd4d                	j	2346 <stpncpy+0xb2>
    2496:	8082                	ret
    2498:	87aa                	mv	a5,a0
    249a:	4681                	li	a3,0
    249c:	b5f9                	j	236a <stpncpy+0xd6>
    249e:	4689                	li	a3,2
    24a0:	b55d                	j	2346 <stpncpy+0xb2>
    24a2:	4691                	li	a3,4
    24a4:	b54d                	j	2346 <stpncpy+0xb2>
    24a6:	4695                	li	a3,5
    24a8:	bd79                	j	2346 <stpncpy+0xb2>
    24aa:	4699                	li	a3,6
    24ac:	bd69                	j	2346 <stpncpy+0xb2>
    24ae:	8082                	ret
    24b0:	8082                	ret
    24b2:	8082                	ret

00000000000024b4 <basename>:

char *basename(char *s)
{
    24b4:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    24b6:	c54d                	beqz	a0,2560 <basename+0xac>
    24b8:	00054783          	lbu	a5,0(a0)
		return ".";
    24bc:	00000517          	auipc	a0,0x0
    24c0:	62450513          	addi	a0,a0,1572 # 2ae0 <enable_deadlock_detect+0x234>
	if (!s || !*s)
    24c4:	e391                	bnez	a5,24c8 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    24c6:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    24c8:	0076f713          	andi	a4,a3,7
    24cc:	87b6                	mv	a5,a3
    24ce:	cf51                	beqz	a4,256a <basename+0xb6>
    24d0:	0785                	addi	a5,a5,1
    24d2:	0077f713          	andi	a4,a5,7
    24d6:	c729                	beqz	a4,2520 <basename+0x6c>
		if (!*s)
    24d8:	0007c703          	lbu	a4,0(a5)
    24dc:	fb75                	bnez	a4,24d0 <basename+0x1c>
	return s - a;
    24de:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24e0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24e2:	cf8d                	beqz	a5,251c <basename+0x68>
    24e4:	00f68733          	add	a4,a3,a5
    24e8:	02f00593          	li	a1,47
    24ec:	a031                	j	24f8 <basename+0x44>
		s[i] = 0;
    24ee:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    24f2:	17fd                	addi	a5,a5,-1
    24f4:	177d                	addi	a4,a4,-1
    24f6:	c39d                	beqz	a5,251c <basename+0x68>
    24f8:	00074603          	lbu	a2,0(a4)
    24fc:	feb609e3          	beq	a2,a1,24ee <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2500:	02f00613          	li	a2,47
    2504:	a011                	j	2508 <basename+0x54>
    2506:	cb99                	beqz	a5,251c <basename+0x68>
    2508:	853e                	mv	a0,a5
    250a:	17fd                	addi	a5,a5,-1
    250c:	00f68733          	add	a4,a3,a5
    2510:	00074703          	lbu	a4,0(a4)
    2514:	fec719e3          	bne	a4,a2,2506 <basename+0x52>
	return s + i;
    2518:	9536                	add	a0,a0,a3
    251a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    251c:	8536                	mv	a0,a3
    251e:	8082                	ret
    2520:	6390                	ld	a2,0(a5)
    2522:	00000517          	auipc	a0,0x0
    2526:	5c653503          	ld	a0,1478(a0) # 2ae8 <enable_deadlock_detect+0x23c>
    252a:	00000597          	auipc	a1,0x0
    252e:	5c65b583          	ld	a1,1478(a1) # 2af0 <enable_deadlock_detect+0x244>
    2532:	fff64713          	not	a4,a2
    2536:	962a                	add	a2,a2,a0
    2538:	8f71                	and	a4,a4,a2
    253a:	8f6d                	and	a4,a4,a1
    253c:	eb11                	bnez	a4,2550 <basename+0x9c>
    253e:	6790                	ld	a2,8(a5)
    2540:	07a1                	addi	a5,a5,8
    2542:	00a60733          	add	a4,a2,a0
    2546:	fff64613          	not	a2,a2
    254a:	8f71                	and	a4,a4,a2
    254c:	8f6d                	and	a4,a4,a1
    254e:	db65                	beqz	a4,253e <basename+0x8a>
	for (; *s; s++)
    2550:	0007c703          	lbu	a4,0(a5)
    2554:	d749                	beqz	a4,24de <basename+0x2a>
    2556:	0017c703          	lbu	a4,1(a5)
    255a:	0785                	addi	a5,a5,1
    255c:	ff6d                	bnez	a4,2556 <basename+0xa2>
    255e:	b741                	j	24de <basename+0x2a>
		return ".";
    2560:	00000517          	auipc	a0,0x0
    2564:	58050513          	addi	a0,a0,1408 # 2ae0 <enable_deadlock_detect+0x234>
    2568:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    256a:	6290                	ld	a2,0(a3)
    256c:	00000517          	auipc	a0,0x0
    2570:	57c53503          	ld	a0,1404(a0) # 2ae8 <enable_deadlock_detect+0x23c>
    2574:	00000597          	auipc	a1,0x0
    2578:	57c5b583          	ld	a1,1404(a1) # 2af0 <enable_deadlock_detect+0x244>
    257c:	fff64713          	not	a4,a2
    2580:	962a                	add	a2,a2,a0
    2582:	8f71                	and	a4,a4,a2
    2584:	8f6d                	and	a4,a4,a1
    2586:	df45                	beqz	a4,253e <basename+0x8a>
    2588:	b7f9                	j	2556 <basename+0xa2>

000000000000258a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    258a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    258e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2590:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2594:	2501                	sext.w	a0,a0
    2596:	8082                	ret

0000000000002598 <close>:

int close(int fd)
{
	if (fd == 1) {
    2598:	4785                	li	a5,1
    259a:	00f50863          	beq	a0,a5,25aa <close+0x12>
	register long a7 __asm__("a7") = n;
    259e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25a2:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    25a6:	2501                	sext.w	a0,a0
    25a8:	8082                	ret
{
    25aa:	1101                	addi	sp,sp,-32
    25ac:	ec06                	sd	ra,24(sp)
    25ae:	e42a                	sd	a0,8(sp)
		__write_buffer();
    25b0:	cdffe0ef          	jal	ra,128e <__write_buffer>
		__clear_buffer();
    25b4:	d03fe0ef          	jal	ra,12b6 <__clear_buffer>
    25b8:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    25ba:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25be:	00000073          	ecall
}
    25c2:	60e2                	ld	ra,24(sp)
    25c4:	2501                	sext.w	a0,a0
    25c6:	6105                	addi	sp,sp,32
    25c8:	8082                	ret

00000000000025ca <read>:
	register long a7 __asm__("a7") = n;
    25ca:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ce:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    25d2:	8082                	ret

00000000000025d4 <write>:
	register long a7 __asm__("a7") = n;
    25d4:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d8:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    25dc:	8082                	ret

00000000000025de <getpid>:
	register long a7 __asm__("a7") = n;
    25de:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25e2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25e6:	2501                	sext.w	a0,a0
    25e8:	8082                	ret

00000000000025ea <getppid>:
	register long a7 __asm__("a7") = n;
    25ea:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25ee:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    25f2:	2501                	sext.w	a0,a0
    25f4:	8082                	ret

00000000000025f6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    25f6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25fa:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <fork>:
	register long a7 __asm__("a7") = n;
    2602:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2606:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret

000000000000260e <exit>:

void exit(int code)
{
    260e:	1141                	addi	sp,sp,-16
    2610:	e406                	sd	ra,8(sp)
    2612:	e022                	sd	s0,0(sp)
    2614:	842a                	mv	s0,a0
	__write_buffer();
    2616:	c79fe0ef          	jal	ra,128e <__write_buffer>
	__clear_buffer();
    261a:	c9dfe0ef          	jal	ra,12b6 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    261e:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2622:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2624:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2628:	60a2                	ld	ra,8(sp)
    262a:	6402                	ld	s0,0(sp)
    262c:	0141                	addi	sp,sp,16
    262e:	8082                	ret

0000000000002630 <waitpid>:
	register long a7 __asm__("a7") = n;
    2630:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2634:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2638:	2501                	sext.w	a0,a0
    263a:	8082                	ret

000000000000263c <exec>:
	register long a7 __asm__("a7") = n;
    263c:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2640:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2644:	2501                	sext.w	a0,a0
    2646:	8082                	ret

0000000000002648 <get_mtime>:

int64 get_mtime()
{
    2648:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    264a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    264e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2650:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2652:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2656:	2501                	sext.w	a0,a0
    2658:	ed01                	bnez	a0,2670 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    265a:	6722                	ld	a4,8(sp)
    265c:	3e800793          	li	a5,1000
    2660:	6682                	ld	a3,0(sp)
    2662:	02f75733          	divu	a4,a4,a5
    2666:	02d78533          	mul	a0,a5,a3
    266a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    266c:	0141                	addi	sp,sp,16
    266e:	8082                	ret
	return -1;
    2670:	557d                	li	a0,-1
    2672:	bfed                	j	266c <get_mtime+0x24>

0000000000002674 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2674:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2678:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <sleep>:

int sleep(unsigned long long time)
{
    2680:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2682:	880a                	mv	a6,sp
{
    2684:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2686:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    268a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    268c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268e:	00000073          	ecall
	if (err == 0) {
    2692:	2501                	sext.w	a0,a0
    2694:	ed31                	bnez	a0,26f0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2696:	6722                	ld	a4,8(sp)
    2698:	3e800793          	li	a5,1000
    269c:	6682                	ld	a3,0(sp)
    269e:	02f75733          	divu	a4,a4,a5
    26a2:	02d787b3          	mul	a5,a5,a3
    26a6:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    26a8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26ac:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26ae:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b0:	00000073          	ecall
	if (err == 0) {
    26b4:	2501                	sext.w	a0,a0
    26b6:	e915                	bnez	a0,26ea <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    26b8:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    26ba:	3e800693          	li	a3,1000
    26be:	a819                	j	26d4 <sleep+0x54>
	__asm_syscall("r"(a7))
    26c0:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26c4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26c8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26ca:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26cc:	00000073          	ecall
	if (err == 0) {
    26d0:	2501                	sext.w	a0,a0
    26d2:	ed01                	bnez	a0,26ea <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    26d4:	6722                	ld	a4,8(sp)
    26d6:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    26d8:	07c00893          	li	a7,124
    26dc:	02d75733          	divu	a4,a4,a3
    26e0:	02f687b3          	mul	a5,a3,a5
    26e4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26e6:	fcc7ede3          	bltu	a5,a2,26c0 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26ea:	4501                	li	a0,0
    26ec:	0141                	addi	sp,sp,16
    26ee:	8082                	ret
    26f0:	57fd                	li	a5,-1
    26f2:	bf5d                	j	26a8 <sleep+0x28>

00000000000026f4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    26f4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    26f8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    26fc:	2501                	sext.w	a0,a0
    26fe:	8082                	ret

0000000000002700 <set_priority>:
	register long a7 __asm__("a7") = n;
    2700:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    270c:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2710:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <munmap>:
	register long a7 __asm__("a7") = n;
    2718:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    271c:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2720:	2501                	sext.w	a0,a0
    2722:	8082                	ret

0000000000002724 <wait>:

int wait(int *code)
{
    2724:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2726:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    272a:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    272c:	00000073          	ecall
	return waitpid(-1, code);
}
    2730:	2501                	sext.w	a0,a0
    2732:	8082                	ret

0000000000002734 <spawn>:
	register long a7 __asm__("a7") = n;
    2734:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2738:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    273c:	2501                	sext.w	a0,a0
    273e:	8082                	ret

0000000000002740 <pipe>:
	register long a7 __asm__("a7") = n;
    2740:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2744:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2748:	2501                	sext.w	a0,a0
    274a:	8082                	ret

000000000000274c <mailread>:
	register long a7 __asm__("a7") = n;
    274c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2750:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2754:	2501                	sext.w	a0,a0
    2756:	8082                	ret

0000000000002758 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2758:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    275c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2760:	2501                	sext.w	a0,a0
    2762:	8082                	ret

0000000000002764 <fstat>:
	register long a7 __asm__("a7") = n;
    2764:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2768:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    276c:	2501                	sext.w	a0,a0
    276e:	8082                	ret

0000000000002770 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2770:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2772:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2776:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2778:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    277c:	2501                	sext.w	a0,a0
    277e:	8082                	ret

0000000000002780 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2780:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2782:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2786:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2788:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    278c:	2501                	sext.w	a0,a0
    278e:	8082                	ret

0000000000002790 <link>:

int link(char *old_path, char *new_path)
{
    2790:	87aa                	mv	a5,a0
    2792:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2794:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2798:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    279c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    279e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    27a2:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27a4:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    27a8:	2501                	sext.w	a0,a0
    27aa:	8082                	ret

00000000000027ac <unlink>:

int unlink(char *path)
{
    27ac:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27ae:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    27b2:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    27b6:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27b8:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    27bc:	2501                	sext.w	a0,a0
    27be:	8082                	ret

00000000000027c0 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    27c0:	00000797          	auipc	a5,0x0
    27c4:	4807b783          	ld	a5,1152(a5) # 2c40 <_GLOBAL_OFFSET_TABLE_+0x8>
    27c8:	439c                	lw	a5,0(a5)
    27ca:	c799                	beqz	a5,27d8 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    27cc:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27d0:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    27d4:	2501                	sext.w	a0,a0
    27d6:	8082                	ret
{
    27d8:	1101                	addi	sp,sp,-32
    27da:	ec06                	sd	ra,24(sp)
    27dc:	e42e                	sd	a1,8(sp)
    27de:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27e0:	fe7fe0ef          	jal	ra,17c6 <enable_thread_io_buffer>
    27e4:	65a2                	ld	a1,8(sp)
    27e6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27e8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ec:	00000073          	ecall
}
    27f0:	60e2                	ld	ra,24(sp)
    27f2:	2501                	sext.w	a0,a0
    27f4:	6105                	addi	sp,sp,32
    27f6:	8082                	ret

00000000000027f8 <gettid>:
	register long a7 __asm__("a7") = n;
    27f8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    27fc:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2800:	2501                	sext.w	a0,a0
    2802:	8082                	ret

0000000000002804 <waittid>:

int waittid(int tid)
{
    2804:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2806:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    280a:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    280e:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2810:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2812:	00e51e63          	bne	a0,a4,282e <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2816:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    281a:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    281e:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2822:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2824:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2828:	2501                	sext.w	a0,a0
	while (ret == -2) {
    282a:	fee506e3          	beq	a0,a4,2816 <waittid+0x12>
	}
	return ret;
}
    282e:	8082                	ret

0000000000002830 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2830:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2834:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2836:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    283a:	2501                	sext.w	a0,a0
    283c:	8082                	ret

000000000000283e <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    283e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2842:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2844:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2848:	2501                	sext.w	a0,a0
    284a:	8082                	ret

000000000000284c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    284c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2850:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2854:	2501                	sext.w	a0,a0
    2856:	8082                	ret

0000000000002858 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2858:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    285c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2860:	2501                	sext.w	a0,a0
    2862:	8082                	ret

0000000000002864 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2864:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2868:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    286c:	2501                	sext.w	a0,a0
    286e:	8082                	ret

0000000000002870 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2870:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2874:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2878:	2501                	sext.w	a0,a0
    287a:	8082                	ret

000000000000287c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    287c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2880:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2884:	2501                	sext.w	a0,a0
    2886:	8082                	ret

0000000000002888 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2888:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    288c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2890:	2501                	sext.w	a0,a0
    2892:	8082                	ret

0000000000002894 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2894:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2898:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    289c:	2501                	sext.w	a0,a0
    289e:	8082                	ret

00000000000028a0 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    28a0:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28a4:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    28a8:	2501                	sext.w	a0,a0
    28aa:	8082                	ret

00000000000028ac <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    28ac:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    28b0:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    28b4:	2501                	sext.w	a0,a0
    28b6:	8082                	ret
