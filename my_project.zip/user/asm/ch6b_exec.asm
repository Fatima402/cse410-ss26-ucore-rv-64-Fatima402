
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_exec:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a081                	j	1040 <__start_main>

0000000000001002 <main>:
#include <stdlib.h>
#include <unistd.h>

int main()
{
	char *_argv[] = {
    1002:	00002797          	auipc	a5,0x2
    1006:	8fe78793          	addi	a5,a5,-1794 # 2900 <buffer_lock+0x4>
    100a:	0007b883          	ld	a7,0(a5)
    100e:	0087b803          	ld	a6,8(a5)
    1012:	6b90                	ld	a2,16(a5)
    1014:	6f94                	ld	a3,24(a5)
    1016:	7398                	ld	a4,32(a5)
    1018:	779c                	ld	a5,40(a5)
{
    101a:	7139                	addi	sp,sp,-64
		"(*o*)", "(>.<)", "(O.O)", "(QwQ)", "orz", "没有了呀"
	};
	exec("ch6b_args", _argv);
    101c:	858a                	mv	a1,sp
    101e:	00001517          	auipc	a0,0x1
    1022:	68a50513          	addi	a0,a0,1674 # 26a8 <basename+0xd8>
{
    1026:	fc06                	sd	ra,56(sp)
	char *_argv[] = {
    1028:	e046                	sd	a7,0(sp)
    102a:	e442                	sd	a6,8(sp)
    102c:	e832                	sd	a2,16(sp)
    102e:	ec36                	sd	a3,24(sp)
    1030:	f03a                	sd	a4,32(sp)
    1032:	f43e                	sd	a5,40(sp)
	exec("ch6b_args", _argv);
    1034:	0d2000ef          	jal	ra,1106 <exec>
	return 0;
    1038:	70e2                	ld	ra,56(sp)
    103a:	4501                	li	a0,0
    103c:	6121                	addi	sp,sp,64
    103e:	8082                	ret

0000000000001040 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1040:	1141                	addi	sp,sp,-16
    1042:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1044:	fbfff0ef          	jal	ra,1002 <main>
    1048:	090000ef          	jal	ra,10d8 <exit>
	return 0;
    104c:	60a2                	ld	ra,8(sp)
    104e:	4501                	li	a0,0
    1050:	0141                	addi	sp,sp,16
    1052:	8082                	ret

0000000000001054 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    1054:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    1058:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    105a:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    105e:	2501                	sext.w	a0,a0
    1060:	8082                	ret

0000000000001062 <close>:

int close(int fd)
{
	if (fd == 1) {
    1062:	4785                	li	a5,1
    1064:	00f50863          	beq	a0,a5,1074 <close+0x12>
	register long a7 __asm__("a7") = n;
    1068:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    106c:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    1070:	2501                	sext.w	a0,a0
    1072:	8082                	ret
{
    1074:	1101                	addi	sp,sp,-32
    1076:	ec06                	sd	ra,24(sp)
    1078:	e42a                	sd	a0,8(sp)
		__write_buffer();
    107a:	330000ef          	jal	ra,13aa <__write_buffer>
		__clear_buffer();
    107e:	354000ef          	jal	ra,13d2 <__clear_buffer>
    1082:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    1084:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1088:	00000073          	ecall
}
    108c:	60e2                	ld	ra,24(sp)
    108e:	2501                	sext.w	a0,a0
    1090:	6105                	addi	sp,sp,32
    1092:	8082                	ret

0000000000001094 <read>:
	register long a7 __asm__("a7") = n;
    1094:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1098:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    109c:	8082                	ret

000000000000109e <write>:
	register long a7 __asm__("a7") = n;
    109e:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    10a2:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    10a6:	8082                	ret

00000000000010a8 <getpid>:
	register long a7 __asm__("a7") = n;
    10a8:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    10ac:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    10b0:	2501                	sext.w	a0,a0
    10b2:	8082                	ret

00000000000010b4 <getppid>:
	register long a7 __asm__("a7") = n;
    10b4:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    10b8:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    10bc:	2501                	sext.w	a0,a0
    10be:	8082                	ret

00000000000010c0 <sched_yield>:
	register long a7 __asm__("a7") = n;
    10c0:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    10c4:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    10c8:	2501                	sext.w	a0,a0
    10ca:	8082                	ret

00000000000010cc <fork>:
	register long a7 __asm__("a7") = n;
    10cc:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    10d0:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    10d4:	2501                	sext.w	a0,a0
    10d6:	8082                	ret

00000000000010d8 <exit>:

void exit(int code)
{
    10d8:	1141                	addi	sp,sp,-16
    10da:	e406                	sd	ra,8(sp)
    10dc:	e022                	sd	s0,0(sp)
    10de:	842a                	mv	s0,a0
	__write_buffer();
    10e0:	2ca000ef          	jal	ra,13aa <__write_buffer>
	__clear_buffer();
    10e4:	2ee000ef          	jal	ra,13d2 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    10e8:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    10ec:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    10ee:	00000073          	ecall
	syscall(SYS_exit, code);
}
    10f2:	60a2                	ld	ra,8(sp)
    10f4:	6402                	ld	s0,0(sp)
    10f6:	0141                	addi	sp,sp,16
    10f8:	8082                	ret

00000000000010fa <waitpid>:
	register long a7 __asm__("a7") = n;
    10fa:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10fe:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    1102:	2501                	sext.w	a0,a0
    1104:	8082                	ret

0000000000001106 <exec>:
	register long a7 __asm__("a7") = n;
    1106:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    110a:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    110e:	2501                	sext.w	a0,a0
    1110:	8082                	ret

0000000000001112 <get_mtime>:

int64 get_mtime()
{
    1112:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    1114:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1118:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    111a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    111c:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    1120:	2501                	sext.w	a0,a0
    1122:	ed01                	bnez	a0,113a <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    1124:	6722                	ld	a4,8(sp)
    1126:	3e800793          	li	a5,1000
    112a:	6682                	ld	a3,0(sp)
    112c:	02f75733          	divu	a4,a4,a5
    1130:	02d78533          	mul	a0,a5,a3
    1134:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    1136:	0141                	addi	sp,sp,16
    1138:	8082                	ret
	return -1;
    113a:	557d                	li	a0,-1
    113c:	bfed                	j	1136 <get_mtime+0x24>

000000000000113e <sys_get_time>:
	register long a7 __asm__("a7") = n;
    113e:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1142:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    1146:	2501                	sext.w	a0,a0
    1148:	8082                	ret

000000000000114a <sleep>:

int sleep(unsigned long long time)
{
    114a:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    114c:	880a                	mv	a6,sp
{
    114e:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    1150:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1154:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1156:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1158:	00000073          	ecall
	if (err == 0) {
    115c:	2501                	sext.w	a0,a0
    115e:	ed31                	bnez	a0,11ba <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    1160:	6722                	ld	a4,8(sp)
    1162:	3e800793          	li	a5,1000
    1166:	6682                	ld	a3,0(sp)
    1168:	02f75733          	divu	a4,a4,a5
    116c:	02d787b3          	mul	a5,a5,a3
    1170:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    1172:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1176:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1178:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    117a:	00000073          	ecall
	if (err == 0) {
    117e:	2501                	sext.w	a0,a0
    1180:	e915                	bnez	a0,11b4 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    1182:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    1184:	3e800693          	li	a3,1000
    1188:	a819                	j	119e <sleep+0x54>
	__asm_syscall("r"(a7))
    118a:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    118e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1192:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1194:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1196:	00000073          	ecall
	if (err == 0) {
    119a:	2501                	sext.w	a0,a0
    119c:	ed01                	bnez	a0,11b4 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    119e:	6722                	ld	a4,8(sp)
    11a0:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    11a2:	07c00893          	li	a7,124
    11a6:	02d75733          	divu	a4,a4,a3
    11aa:	02f687b3          	mul	a5,a3,a5
    11ae:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    11b0:	fcc7ede3          	bltu	a5,a2,118a <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    11b4:	4501                	li	a0,0
    11b6:	0141                	addi	sp,sp,16
    11b8:	8082                	ret
    11ba:	57fd                	li	a5,-1
    11bc:	bf5d                	j	1172 <sleep+0x28>

00000000000011be <sys_task_info>:
	register long a7 __asm__("a7") = n;
    11be:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    11c2:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    11c6:	2501                	sext.w	a0,a0
    11c8:	8082                	ret

00000000000011ca <set_priority>:
	register long a7 __asm__("a7") = n;
    11ca:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    11ce:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    11d2:	2501                	sext.w	a0,a0
    11d4:	8082                	ret

00000000000011d6 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    11d6:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    11da:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    11de:	2501                	sext.w	a0,a0
    11e0:	8082                	ret

00000000000011e2 <munmap>:
	register long a7 __asm__("a7") = n;
    11e2:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11e6:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    11ea:	2501                	sext.w	a0,a0
    11ec:	8082                	ret

00000000000011ee <wait>:

int wait(int *code)
{
    11ee:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    11f0:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    11f4:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11f6:	00000073          	ecall
	return waitpid(-1, code);
}
    11fa:	2501                	sext.w	a0,a0
    11fc:	8082                	ret

00000000000011fe <spawn>:
	register long a7 __asm__("a7") = n;
    11fe:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    1202:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    1206:	2501                	sext.w	a0,a0
    1208:	8082                	ret

000000000000120a <pipe>:
	register long a7 __asm__("a7") = n;
    120a:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    120e:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    1212:	2501                	sext.w	a0,a0
    1214:	8082                	ret

0000000000001216 <mailread>:
	register long a7 __asm__("a7") = n;
    1216:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    121a:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    121e:	2501                	sext.w	a0,a0
    1220:	8082                	ret

0000000000001222 <mailwrite>:
	register long a7 __asm__("a7") = n;
    1222:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1226:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    122a:	2501                	sext.w	a0,a0
    122c:	8082                	ret

000000000000122e <fstat>:
	register long a7 __asm__("a7") = n;
    122e:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1232:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    1236:	2501                	sext.w	a0,a0
    1238:	8082                	ret

000000000000123a <sys_linkat>:
	register long a4 __asm__("a4") = e;
    123a:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    123c:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    1240:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1242:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    1246:	2501                	sext.w	a0,a0
    1248:	8082                	ret

000000000000124a <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    124a:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    124c:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    1250:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1252:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    1256:	2501                	sext.w	a0,a0
    1258:	8082                	ret

000000000000125a <link>:

int link(char *old_path, char *new_path)
{
    125a:	87aa                	mv	a5,a0
    125c:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    125e:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    1262:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    1266:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    1268:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    126c:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    126e:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    1272:	2501                	sext.w	a0,a0
    1274:	8082                	ret

0000000000001276 <unlink>:

int unlink(char *path)
{
    1276:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    1278:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    127c:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    1280:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1282:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    1286:	2501                	sext.w	a0,a0
    1288:	8082                	ret

000000000000128a <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    128a:	00001797          	auipc	a5,0x1
    128e:	6c67b783          	ld	a5,1734(a5) # 2950 <_GLOBAL_OFFSET_TABLE_+0x8>
    1292:	439c                	lw	a5,0(a5)
    1294:	c799                	beqz	a5,12a2 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    1296:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    129a:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    129e:	2501                	sext.w	a0,a0
    12a0:	8082                	ret
{
    12a2:	1101                	addi	sp,sp,-32
    12a4:	ec06                	sd	ra,24(sp)
    12a6:	e42e                	sd	a1,8(sp)
    12a8:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    12aa:	638000ef          	jal	ra,18e2 <enable_thread_io_buffer>
    12ae:	65a2                	ld	a1,8(sp)
    12b0:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    12b2:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    12b6:	00000073          	ecall
}
    12ba:	60e2                	ld	ra,24(sp)
    12bc:	2501                	sext.w	a0,a0
    12be:	6105                	addi	sp,sp,32
    12c0:	8082                	ret

00000000000012c2 <gettid>:
	register long a7 __asm__("a7") = n;
    12c2:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    12c6:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    12ca:	2501                	sext.w	a0,a0
    12cc:	8082                	ret

00000000000012ce <waittid>:

int waittid(int tid)
{
    12ce:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    12d0:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    12d4:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    12d8:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    12da:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12dc:	00e51e63          	bne	a0,a4,12f8 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    12e0:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    12e4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    12e8:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    12ec:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    12ee:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    12f2:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12f4:	fee506e3          	beq	a0,a4,12e0 <waittid+0x12>
	}
	return ret;
}
    12f8:	8082                	ret

00000000000012fa <mutex_create>:
	register long a7 __asm__("a7") = n;
    12fa:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12fe:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    1300:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    1304:	2501                	sext.w	a0,a0
    1306:	8082                	ret

0000000000001308 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    1308:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    130c:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    130e:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    1312:	2501                	sext.w	a0,a0
    1314:	8082                	ret

0000000000001316 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    1316:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    131a:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    131e:	2501                	sext.w	a0,a0
    1320:	8082                	ret

0000000000001322 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    1322:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    1326:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    132a:	2501                	sext.w	a0,a0
    132c:	8082                	ret

000000000000132e <semaphore_create>:
	register long a7 __asm__("a7") = n;
    132e:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    1332:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    1336:	2501                	sext.w	a0,a0
    1338:	8082                	ret

000000000000133a <semaphore_up>:
	register long a7 __asm__("a7") = n;
    133a:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    133e:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    1342:	2501                	sext.w	a0,a0
    1344:	8082                	ret

0000000000001346 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    1346:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    134a:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    134e:	2501                	sext.w	a0,a0
    1350:	8082                	ret

0000000000001352 <condvar_create>:
	register long a7 __asm__("a7") = n;
    1352:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    1356:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    135a:	2501                	sext.w	a0,a0
    135c:	8082                	ret

000000000000135e <condvar_signal>:
	register long a7 __asm__("a7") = n;
    135e:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    1362:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    1366:	2501                	sext.w	a0,a0
    1368:	8082                	ret

000000000000136a <condvar_wait>:
	register long a7 __asm__("a7") = n;
    136a:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    136e:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    1372:	2501                	sext.w	a0,a0
    1374:	8082                	ret

0000000000001376 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    1376:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    137a:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    137e:	2501                	sext.w	a0,a0
    1380:	8082                	ret

0000000000001382 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1382:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1384:	4605                	li	a2,1
    1386:	00f10593          	addi	a1,sp,15
    138a:	4501                	li	a0,0
{
    138c:	ec06                	sd	ra,24(sp)
	char byte = 0;
    138e:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1392:	d03ff0ef          	jal	ra,1094 <read>
    1396:	4785                	li	a5,1
    1398:	00f51763          	bne	a0,a5,13a6 <getchar+0x24>
		return byte;
    139c:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    13a0:	60e2                	ld	ra,24(sp)
    13a2:	6105                	addi	sp,sp,32
    13a4:	8082                	ret
		return EOF;
    13a6:	557d                	li	a0,-1
    13a8:	bfe5                	j	13a0 <getchar+0x1e>

00000000000013aa <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    13aa:	00001517          	auipc	a0,0x1
    13ae:	44652503          	lw	a0,1094(a0) # 27f0 <buffer_len>
    13b2:	e111                	bnez	a0,13b6 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    13b4:	8082                	ret
{
    13b6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13b8:	862a                	mv	a2,a0
    13ba:	00001597          	auipc	a1,0x1
    13be:	43e58593          	addi	a1,a1,1086 # 27f8 <buffer>
    13c2:	4505                	li	a0,1
{
    13c4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13c6:	cd9ff0ef          	jal	ra,109e <write>
}
    13ca:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13cc:	2501                	sext.w	a0,a0
}
    13ce:	0141                	addi	sp,sp,16
    13d0:	8082                	ret

00000000000013d2 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    13d2:	00001797          	auipc	a5,0x1
    13d6:	4007af23          	sw	zero,1054(a5) # 27f0 <buffer_len>
}
    13da:	8082                	ret

00000000000013dc <__fflush>:
	if (buffer_len == 0)
    13dc:	00001517          	auipc	a0,0x1
    13e0:	41452503          	lw	a0,1044(a0) # 27f0 <buffer_len>
    13e4:	e511                	bnez	a0,13f0 <__fflush+0x14>
	buffer_len = 0;
    13e6:	00001797          	auipc	a5,0x1
    13ea:	4007a523          	sw	zero,1034(a5) # 27f0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13ee:	8082                	ret
{
    13f0:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13f2:	862a                	mv	a2,a0
    13f4:	00001597          	auipc	a1,0x1
    13f8:	40458593          	addi	a1,a1,1028 # 27f8 <buffer>
    13fc:	4505                	li	a0,1
{
    13fe:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1400:	c9fff0ef          	jal	ra,109e <write>
	return r >= 0 ? 0 : r;
    1404:	0005079b          	sext.w	a5,a0
}
    1408:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    140a:	0017a793          	slti	a5,a5,1
    140e:	40f007bb          	negw	a5,a5
    1412:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1414:	00001797          	auipc	a5,0x1
    1418:	3c07ae23          	sw	zero,988(a5) # 27f0 <buffer_len>
	return r >= 0 ? 0 : r;
    141c:	2501                	sext.w	a0,a0
}
    141e:	0141                	addi	sp,sp,16
    1420:	8082                	ret

0000000000001422 <fflush>:

int fflush(int fd)
{
    1422:	1101                	addi	sp,sp,-32
    1424:	e822                	sd	s0,16(sp)
    1426:	ec06                	sd	ra,24(sp)
    1428:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    142a:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    142c:	4401                	li	s0,0
	if (fd == 1) {
    142e:	00e50863          	beq	a0,a4,143e <fflush+0x1c>
}
    1432:	60e2                	ld	ra,24(sp)
    1434:	8522                	mv	a0,s0
    1436:	6442                	ld	s0,16(sp)
    1438:	64a2                	ld	s1,8(sp)
    143a:	6105                	addi	sp,sp,32
    143c:	8082                	ret
		if (buffer_lock_enabled == 1) {
    143e:	00001497          	auipc	s1,0x1
    1442:	3b248493          	addi	s1,s1,946 # 27f0 <buffer_len>
    1446:	1084a703          	lw	a4,264(s1)
    144a:	02a70e63          	beq	a4,a0,1486 <fflush+0x64>
	if (buffer_len == 0)
    144e:	4080                	lw	s0,0(s1)
    1450:	c00d                	beqz	s0,1472 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1452:	8622                	mv	a2,s0
    1454:	00001597          	auipc	a1,0x1
    1458:	3a458593          	addi	a1,a1,932 # 27f8 <buffer>
    145c:	c43ff0ef          	jal	ra,109e <write>
	return r >= 0 ? 0 : r;
    1460:	0005079b          	sext.w	a5,a0
    1464:	0017a793          	slti	a5,a5,1
    1468:	40f007bb          	negw	a5,a5
    146c:	8d7d                	and	a0,a0,a5
    146e:	0005041b          	sext.w	s0,a0
}
    1472:	60e2                	ld	ra,24(sp)
    1474:	8522                	mv	a0,s0
    1476:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1478:	00001797          	auipc	a5,0x1
    147c:	3607ac23          	sw	zero,888(a5) # 27f0 <buffer_len>
}
    1480:	64a2                	ld	s1,8(sp)
    1482:	6105                	addi	sp,sp,32
    1484:	8082                	ret
			mutex_lock(buffer_lock);
    1486:	10c4a503          	lw	a0,268(s1)
    148a:	e8dff0ef          	jal	ra,1316 <mutex_lock>
	if (buffer_len == 0)
    148e:	4080                	lw	s0,0(s1)
    1490:	e811                	bnez	s0,14a4 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1492:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1496:	00001797          	auipc	a5,0x1
    149a:	3407ad23          	sw	zero,858(a5) # 27f0 <buffer_len>
			mutex_unlock(buffer_lock);
    149e:	e85ff0ef          	jal	ra,1322 <mutex_unlock>
    14a2:	bf41                	j	1432 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    14a4:	8622                	mv	a2,s0
    14a6:	00001597          	auipc	a1,0x1
    14aa:	35258593          	addi	a1,a1,850 # 27f8 <buffer>
    14ae:	4505                	li	a0,1
    14b0:	befff0ef          	jal	ra,109e <write>
	return r >= 0 ? 0 : r;
    14b4:	0005079b          	sext.w	a5,a0
    14b8:	0017a793          	slti	a5,a5,1
    14bc:	40f007bb          	negw	a5,a5
    14c0:	8d7d                	and	a0,a0,a5
    14c2:	0005041b          	sext.w	s0,a0
	return r;
    14c6:	b7f1                	j	1492 <fflush+0x70>

00000000000014c8 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    14c8:	7131                	addi	sp,sp,-192
    14ca:	e0da                	sd	s6,64(sp)
    14cc:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    14ce:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    14d0:	013c                	addi	a5,sp,136
{
    14d2:	f0ca                	sd	s2,96(sp)
    14d4:	ecce                	sd	s3,88(sp)
    14d6:	e8d2                	sd	s4,80(sp)
    14d8:	e4d6                	sd	s5,72(sp)
    14da:	fc86                	sd	ra,120(sp)
    14dc:	f8a2                	sd	s0,112(sp)
    14de:	f4a6                	sd	s1,104(sp)
    14e0:	89aa                	mv	s3,a0
    14e2:	e52e                	sd	a1,136(sp)
    14e4:	e932                	sd	a2,144(sp)
    14e6:	ed36                	sd	a3,152(sp)
    14e8:	f13a                	sd	a4,160(sp)
    14ea:	f942                	sd	a6,176(sp)
    14ec:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14ee:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14f0:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14f4:	00001a17          	auipc	s4,0x1
    14f8:	2fca0a13          	addi	s4,s4,764 # 27f0 <buffer_len>
    14fc:	4a85                	li	s5,1
	buf[i++] = '0';
    14fe:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1502:	0009c783          	lbu	a5,0(s3)
    1506:	18078663          	beqz	a5,1692 <printf+0x1ca>
    150a:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    150c:	19278d63          	beq	a5,s2,16a6 <printf+0x1de>
    1510:	0015c783          	lbu	a5,1(a1)
    1514:	0585                	addi	a1,a1,1
    1516:	fbfd                	bnez	a5,150c <printf+0x44>
    1518:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    151a:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    151e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1522:	1b578863          	beq	a5,s5,16d2 <printf+0x20a>
		len = out_unlocked(s, l);
    1526:	85a2                	mv	a1,s0
    1528:	854e                	mv	a0,s3
    152a:	42a000ef          	jal	ra,1954 <out_unlocked>
		out(f, a, l);
		if (l)
    152e:	1c041063          	bnez	s0,16ee <printf+0x226>
			continue;
		if (s[1] == 0)
    1532:	0014c783          	lbu	a5,1(s1)
    1536:	14078e63          	beqz	a5,1692 <printf+0x1ca>
			break;
		switch (s[1]) {
    153a:	07300713          	li	a4,115
    153e:	1ce78863          	beq	a5,a4,170e <printf+0x246>
    1542:	1af76863          	bltu	a4,a5,16f2 <printf+0x22a>
    1546:	06400713          	li	a4,100
    154a:	22e78063          	beq	a5,a4,176a <printf+0x2a2>
    154e:	07000713          	li	a4,112
    1552:	1ee79563          	bne	a5,a4,173c <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1556:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1558:	00001797          	auipc	a5,0x1
    155c:	3d878793          	addi	a5,a5,984 # 2930 <digits>
	buf[i++] = '0';
    1560:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1564:	6298                	ld	a4,0(a3)
    1566:	06a1                	addi	a3,a3,8
    1568:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    156a:	00471393          	slli	t2,a4,0x4
    156e:	00871293          	slli	t0,a4,0x8
    1572:	00c71f93          	slli	t6,a4,0xc
    1576:	01071f13          	slli	t5,a4,0x10
    157a:	01471e93          	slli	t4,a4,0x14
    157e:	01871e13          	slli	t3,a4,0x18
    1582:	01c71893          	slli	a7,a4,0x1c
    1586:	02471813          	slli	a6,a4,0x24
    158a:	02871513          	slli	a0,a4,0x28
    158e:	02c71593          	slli	a1,a4,0x2c
    1592:	03071613          	slli	a2,a4,0x30
    1596:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    159a:	03c75413          	srli	s0,a4,0x3c
    159e:	01c7531b          	srliw	t1,a4,0x1c
    15a2:	03c3d393          	srli	t2,t2,0x3c
    15a6:	03c2d293          	srli	t0,t0,0x3c
    15aa:	03cfdf93          	srli	t6,t6,0x3c
    15ae:	03cf5f13          	srli	t5,t5,0x3c
    15b2:	03cede93          	srli	t4,t4,0x3c
    15b6:	03ce5e13          	srli	t3,t3,0x3c
    15ba:	03c8d893          	srli	a7,a7,0x3c
    15be:	03c85813          	srli	a6,a6,0x3c
    15c2:	9171                	srli	a0,a0,0x3c
    15c4:	91f1                	srli	a1,a1,0x3c
    15c6:	9271                	srli	a2,a2,0x3c
    15c8:	92f1                	srli	a3,a3,0x3c
    15ca:	95be                	add	a1,a1,a5
    15cc:	963e                	add	a2,a2,a5
    15ce:	96be                	add	a3,a3,a5
    15d0:	943e                	add	s0,s0,a5
    15d2:	93be                	add	t2,t2,a5
    15d4:	92be                	add	t0,t0,a5
    15d6:	9fbe                	add	t6,t6,a5
    15d8:	9f3e                	add	t5,t5,a5
    15da:	9ebe                	add	t4,t4,a5
    15dc:	9e3e                	add	t3,t3,a5
    15de:	98be                	add	a7,a7,a5
    15e0:	933e                	add	t1,t1,a5
    15e2:	983e                	add	a6,a6,a5
    15e4:	953e                	add	a0,a0,a5
    15e6:	0005c983          	lbu	s3,0(a1)
    15ea:	00044403          	lbu	s0,0(s0)
    15ee:	00064583          	lbu	a1,0(a2)
    15f2:	0003c383          	lbu	t2,0(t2)
    15f6:	0006c603          	lbu	a2,0(a3)
    15fa:	0002c283          	lbu	t0,0(t0)
    15fe:	000fcf83          	lbu	t6,0(t6)
    1602:	000f4f03          	lbu	t5,0(t5)
    1606:	000ece83          	lbu	t4,0(t4)
    160a:	000e4e03          	lbu	t3,0(t3)
    160e:	0008c883          	lbu	a7,0(a7)
    1612:	00034303          	lbu	t1,0(t1)
    1616:	00084803          	lbu	a6,0(a6)
    161a:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    161e:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1622:	92f1                	srli	a3,a3,0x3c
    1624:	8b3d                	andi	a4,a4,15
    1626:	96be                	add	a3,a3,a5
    1628:	97ba                	add	a5,a5,a4
    162a:	00810d23          	sb	s0,26(sp)
    162e:	00710da3          	sb	t2,27(sp)
    1632:	00510e23          	sb	t0,28(sp)
    1636:	01f10ea3          	sb	t6,29(sp)
    163a:	01e10f23          	sb	t5,30(sp)
    163e:	01d10fa3          	sb	t4,31(sp)
    1642:	03c10023          	sb	t3,32(sp)
    1646:	031100a3          	sb	a7,33(sp)
    164a:	02610123          	sb	t1,34(sp)
    164e:	030101a3          	sb	a6,35(sp)
    1652:	02a10223          	sb	a0,36(sp)
    1656:	033102a3          	sb	s3,37(sp)
    165a:	02b10323          	sb	a1,38(sp)
    165e:	02c103a3          	sb	a2,39(sp)
    1662:	0006c683          	lbu	a3,0(a3)
    1666:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    166a:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    166e:	02d10423          	sb	a3,40(sp)
    1672:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1676:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    167a:	11578263          	beq	a5,s5,177e <printf+0x2b6>
		len = out_unlocked(s, l);
    167e:	45c9                	li	a1,18
    1680:	0828                	addi	a0,sp,24
    1682:	2d2000ef          	jal	ra,1954 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1686:	00248993          	addi	s3,s1,2
		if (!*s)
    168a:	0009c783          	lbu	a5,0(s3)
    168e:	e6079ee3          	bnez	a5,150a <printf+0x42>
	}
	va_end(ap);
    1692:	70e6                	ld	ra,120(sp)
    1694:	7446                	ld	s0,112(sp)
    1696:	74a6                	ld	s1,104(sp)
    1698:	7906                	ld	s2,96(sp)
    169a:	69e6                	ld	s3,88(sp)
    169c:	6a46                	ld	s4,80(sp)
    169e:	6aa6                	ld	s5,72(sp)
    16a0:	6b06                	ld	s6,64(sp)
    16a2:	6129                	addi	sp,sp,192
    16a4:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    16a6:	0005c783          	lbu	a5,0(a1)
    16aa:	84ae                	mv	s1,a1
    16ac:	01278963          	beq	a5,s2,16be <printf+0x1f6>
    16b0:	b5ad                	j	151a <printf+0x52>
    16b2:	0024c783          	lbu	a5,2(s1)
    16b6:	0585                	addi	a1,a1,1
    16b8:	0489                	addi	s1,s1,2
    16ba:	e72790e3          	bne	a5,s2,151a <printf+0x52>
    16be:	0014c783          	lbu	a5,1(s1)
    16c2:	ff2788e3          	beq	a5,s2,16b2 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    16c6:	108a2783          	lw	a5,264(s4)
		l = z - a;
    16ca:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    16ce:	e5579ce3          	bne	a5,s5,1526 <printf+0x5e>
		mutex_lock(buffer_lock);
    16d2:	10ca2503          	lw	a0,268(s4)
    16d6:	c41ff0ef          	jal	ra,1316 <mutex_lock>
		len = out_unlocked(s, l);
    16da:	85a2                	mv	a1,s0
    16dc:	854e                	mv	a0,s3
    16de:	276000ef          	jal	ra,1954 <out_unlocked>
		mutex_unlock(buffer_lock);
    16e2:	10ca2503          	lw	a0,268(s4)
    16e6:	c3dff0ef          	jal	ra,1322 <mutex_unlock>
		if (l)
    16ea:	e40404e3          	beqz	s0,1532 <printf+0x6a>
    16ee:	89a6                	mv	s3,s1
    16f0:	bd09                	j	1502 <printf+0x3a>
		switch (s[1]) {
    16f2:	07800713          	li	a4,120
    16f6:	04e79363          	bne	a5,a4,173c <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16fa:	67c2                	ld	a5,16(sp)
    16fc:	45c1                	li	a1,16
		s += 2;
    16fe:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1702:	4388                	lw	a0,0(a5)
    1704:	07a1                	addi	a5,a5,8
    1706:	e83e                	sd	a5,16(sp)
    1708:	5f8000ef          	jal	ra,1d00 <printint.constprop.0>
		s += 2;
    170c:	bfbd                	j	168a <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    170e:	67c2                	ld	a5,16(sp)
    1710:	6380                	ld	s0,0(a5)
    1712:	07a1                	addi	a5,a5,8
    1714:	e83e                	sd	a5,16(sp)
    1716:	1c040163          	beqz	s0,18d8 <printf+0x410>
			l = strnlen(a, 200);
    171a:	0c800593          	li	a1,200
    171e:	8522                	mv	a0,s0
    1720:	3f7000ef          	jal	ra,2316 <strnlen>
	if (buffer_lock_enabled == 1) {
    1724:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1728:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    172c:	19578663          	beq	a5,s5,18b8 <printf+0x3f0>
		len = out_unlocked(s, l);
    1730:	8522                	mv	a0,s0
    1732:	222000ef          	jal	ra,1954 <out_unlocked>
		s += 2;
    1736:	00248993          	addi	s3,s1,2
    173a:	bf81                	j	168a <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    173c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1740:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1744:	0f578663          	beq	a5,s5,1830 <printf+0x368>
		len = out_unlocked(s, l);
    1748:	0828                	addi	a0,sp,24
    174a:	316000ef          	jal	ra,1a60 <out_unlocked.constprop.0>
			putchar(s[1]);
    174e:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1752:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1756:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    175a:	05578163          	beq	a5,s5,179c <printf+0x2d4>
		len = out_unlocked(s, l);
    175e:	0828                	addi	a0,sp,24
    1760:	300000ef          	jal	ra,1a60 <out_unlocked.constprop.0>
		s += 2;
    1764:	00248993          	addi	s3,s1,2
    1768:	b70d                	j	168a <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    176a:	67c2                	ld	a5,16(sp)
    176c:	45a9                	li	a1,10
		s += 2;
    176e:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1772:	4388                	lw	a0,0(a5)
    1774:	07a1                	addi	a5,a5,8
    1776:	e83e                	sd	a5,16(sp)
    1778:	588000ef          	jal	ra,1d00 <printint.constprop.0>
		s += 2;
    177c:	b739                	j	168a <printf+0x1c2>
		mutex_lock(buffer_lock);
    177e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1782:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1786:	b91ff0ef          	jal	ra,1316 <mutex_lock>
		len = out_unlocked(s, l);
    178a:	45c9                	li	a1,18
    178c:	0828                	addi	a0,sp,24
    178e:	1c6000ef          	jal	ra,1954 <out_unlocked>
		mutex_unlock(buffer_lock);
    1792:	10ca2503          	lw	a0,268(s4)
    1796:	b8dff0ef          	jal	ra,1322 <mutex_unlock>
		s += 2;
    179a:	bdc5                	j	168a <printf+0x1c2>
		mutex_lock(buffer_lock);
    179c:	10ca2503          	lw	a0,268(s4)
    17a0:	b77ff0ef          	jal	ra,1316 <mutex_lock>
		buffer[buffer_len++] = c;
    17a4:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17a8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    17ac:	0017861b          	addiw	a2,a5,1
    17b0:	97d2                	add	a5,a5,s4
    17b2:	00ca2023          	sw	a2,0(s4)
    17b6:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17ba:	00c6cc63          	blt	a3,a2,17d2 <printf+0x30a>
    17be:	47a9                	li	a5,10
    17c0:	06f40663          	beq	s0,a5,182c <printf+0x364>
		mutex_unlock(buffer_lock);
    17c4:	10ca2503          	lw	a0,268(s4)
		s += 2;
    17c8:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    17cc:	b57ff0ef          	jal	ra,1322 <mutex_unlock>
		s += 2;
    17d0:	bd6d                	j	168a <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    17d2:	10000793          	li	a5,256
    17d6:	00f61e63          	bne	a2,a5,17f2 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    17da:	00001597          	auipc	a1,0x1
    17de:	01e58593          	addi	a1,a1,30 # 27f8 <buffer>
    17e2:	4505                	li	a0,1
    17e4:	8bbff0ef          	jal	ra,109e <write>
	buffer_len = 0;
    17e8:	00001797          	auipc	a5,0x1
    17ec:	0007a423          	sw	zero,8(a5) # 27f0 <buffer_len>
			if (r < 0) {
    17f0:	bfd1                	j	17c4 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17f2:	8b7ff0ef          	jal	ra,10a8 <getpid>
    17f6:	842a                	mv	s0,a0
    17f8:	00001517          	auipc	a0,0x1
    17fc:	f0050513          	addi	a0,a0,-256 # 26f8 <basename+0x128>
    1800:	5d1000ef          	jal	ra,25d0 <basename>
    1804:	872a                	mv	a4,a0
    1806:	00001617          	auipc	a2,0x1
    180a:	f3260613          	addi	a2,a2,-206 # 2738 <basename+0x168>
    180e:	05400793          	li	a5,84
    1812:	86a2                	mv	a3,s0
    1814:	45fd                	li	a1,31
    1816:	00001517          	auipc	a0,0x1
    181a:	f2a50513          	addi	a0,a0,-214 # 2740 <basename+0x170>
    181e:	cabff0ef          	jal	ra,14c8 <printf>
    1822:	557d                	li	a0,-1
    1824:	8b5ff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    1828:	000a2603          	lw	a2,0(s4)
    182c:	de41                	beqz	a2,17c4 <printf+0x2fc>
    182e:	b775                	j	17da <printf+0x312>
		mutex_lock(buffer_lock);
    1830:	10ca2503          	lw	a0,268(s4)
    1834:	ae3ff0ef          	jal	ra,1316 <mutex_lock>
		buffer[buffer_len++] = c;
    1838:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    183c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1840:	0017861b          	addiw	a2,a5,1
    1844:	97d2                	add	a5,a5,s4
    1846:	00ca2023          	sw	a2,0(s4)
    184a:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    184e:	02c6d163          	bge	a3,a2,1870 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1852:	10000793          	li	a5,256
    1856:	02f61263          	bne	a2,a5,187a <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    185a:	00001597          	auipc	a1,0x1
    185e:	f9e58593          	addi	a1,a1,-98 # 27f8 <buffer>
    1862:	4505                	li	a0,1
    1864:	83bff0ef          	jal	ra,109e <write>
	buffer_len = 0;
    1868:	00001797          	auipc	a5,0x1
    186c:	f807a423          	sw	zero,-120(a5) # 27f0 <buffer_len>
		mutex_unlock(buffer_lock);
    1870:	10ca2503          	lw	a0,268(s4)
    1874:	aafff0ef          	jal	ra,1322 <mutex_unlock>
    1878:	bdd9                	j	174e <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    187a:	82fff0ef          	jal	ra,10a8 <getpid>
    187e:	842a                	mv	s0,a0
    1880:	00001517          	auipc	a0,0x1
    1884:	e7850513          	addi	a0,a0,-392 # 26f8 <basename+0x128>
    1888:	549000ef          	jal	ra,25d0 <basename>
    188c:	872a                	mv	a4,a0
    188e:	00001617          	auipc	a2,0x1
    1892:	eaa60613          	addi	a2,a2,-342 # 2738 <basename+0x168>
    1896:	05400793          	li	a5,84
    189a:	86a2                	mv	a3,s0
    189c:	45fd                	li	a1,31
    189e:	00001517          	auipc	a0,0x1
    18a2:	ea250513          	addi	a0,a0,-350 # 2740 <basename+0x170>
    18a6:	c23ff0ef          	jal	ra,14c8 <printf>
    18aa:	557d                	li	a0,-1
    18ac:	82dff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    18b0:	000a2603          	lw	a2,0(s4)
    18b4:	de55                	beqz	a2,1870 <printf+0x3a8>
    18b6:	b755                	j	185a <printf+0x392>
		mutex_lock(buffer_lock);
    18b8:	10ca2503          	lw	a0,268(s4)
    18bc:	e42e                	sd	a1,8(sp)
		s += 2;
    18be:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    18c2:	a55ff0ef          	jal	ra,1316 <mutex_lock>
		len = out_unlocked(s, l);
    18c6:	65a2                	ld	a1,8(sp)
    18c8:	8522                	mv	a0,s0
    18ca:	08a000ef          	jal	ra,1954 <out_unlocked>
		mutex_unlock(buffer_lock);
    18ce:	10ca2503          	lw	a0,268(s4)
    18d2:	a51ff0ef          	jal	ra,1322 <mutex_unlock>
		s += 2;
    18d6:	bb55                	j	168a <printf+0x1c2>
				a = "(null)";
    18d8:	00001417          	auipc	s0,0x1
    18dc:	e1840413          	addi	s0,s0,-488 # 26f0 <basename+0x120>
    18e0:	bd2d                	j	171a <printf+0x252>

00000000000018e2 <enable_thread_io_buffer>:
{
    18e2:	1101                	addi	sp,sp,-32
    18e4:	e822                	sd	s0,16(sp)
    18e6:	ec06                	sd	ra,24(sp)
    18e8:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18ea:	00001417          	auipc	s0,0x1
    18ee:	f0640413          	addi	s0,s0,-250 # 27f0 <buffer_len>
    18f2:	a09ff0ef          	jal	ra,12fa <mutex_create>
    18f6:	10a42623          	sw	a0,268(s0)
    18fa:	00054a63          	bltz	a0,190e <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18fe:	4785                	li	a5,1
}
    1900:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1902:	10f42423          	sw	a5,264(s0)
}
    1906:	6442                	ld	s0,16(sp)
    1908:	64a2                	ld	s1,8(sp)
    190a:	6105                	addi	sp,sp,32
    190c:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    190e:	f9aff0ef          	jal	ra,10a8 <getpid>
    1912:	84aa                	mv	s1,a0
    1914:	00001517          	auipc	a0,0x1
    1918:	de450513          	addi	a0,a0,-540 # 26f8 <basename+0x128>
    191c:	4b5000ef          	jal	ra,25d0 <basename>
    1920:	872a                	mv	a4,a0
    1922:	04800793          	li	a5,72
    1926:	86a6                	mv	a3,s1
    1928:	00001517          	auipc	a0,0x1
    192c:	e5850513          	addi	a0,a0,-424 # 2780 <basename+0x1b0>
    1930:	00001617          	auipc	a2,0x1
    1934:	e0860613          	addi	a2,a2,-504 # 2738 <basename+0x168>
    1938:	45fd                	li	a1,31
    193a:	b8fff0ef          	jal	ra,14c8 <printf>
    193e:	557d                	li	a0,-1
    1940:	f98ff0ef          	jal	ra,10d8 <exit>
	buffer_lock_enabled = 1;
    1944:	4785                	li	a5,1
}
    1946:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1948:	10f42423          	sw	a5,264(s0)
}
    194c:	6442                	ld	s0,16(sp)
    194e:	64a2                	ld	s1,8(sp)
    1950:	6105                	addi	sp,sp,32
    1952:	8082                	ret

0000000000001954 <out_unlocked>:
{
    1954:	7159                	addi	sp,sp,-112
    1956:	f486                	sd	ra,104(sp)
    1958:	f0a2                	sd	s0,96(sp)
    195a:	eca6                	sd	s1,88(sp)
    195c:	e8ca                	sd	s2,80(sp)
    195e:	e4ce                	sd	s3,72(sp)
    1960:	e0d2                	sd	s4,64(sp)
    1962:	fc56                	sd	s5,56(sp)
    1964:	f85a                	sd	s6,48(sp)
    1966:	f45e                	sd	s7,40(sp)
    1968:	f062                	sd	s8,32(sp)
    196a:	ec66                	sd	s9,24(sp)
    196c:	e86a                	sd	s10,16(sp)
    196e:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1970:	0e058663          	beqz	a1,1a5c <out_unlocked+0x108>
    1974:	842a                	mv	s0,a0
    1976:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    197a:	4981                	li	s3,0
    197c:	00001d17          	auipc	s10,0x1
    1980:	e74d0d13          	addi	s10,s10,-396 # 27f0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1984:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1988:	00001b17          	auipc	s6,0x1
    198c:	e70b0b13          	addi	s6,s6,-400 # 27f8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1990:	10000a93          	li	s5,256
    1994:	00001c97          	auipc	s9,0x1
    1998:	d64c8c93          	addi	s9,s9,-668 # 26f8 <basename+0x128>
    199c:	00001c17          	auipc	s8,0x1
    19a0:	d9cc0c13          	addi	s8,s8,-612 # 2738 <basename+0x168>
    19a4:	00001b97          	auipc	s7,0x1
    19a8:	d9cb8b93          	addi	s7,s7,-612 # 2740 <basename+0x170>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19ac:	4a29                	li	s4,10
    19ae:	a031                	j	19ba <out_unlocked+0x66>
    19b0:	09468863          	beq	a3,s4,1a40 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    19b4:	0405                	addi	s0,s0,1
    19b6:	04848163          	beq	s1,s0,19f8 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    19ba:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    19be:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    19c2:	0017861b          	addiw	a2,a5,1
    19c6:	97ea                	add	a5,a5,s10
    19c8:	00cd2023          	sw	a2,0(s10)
    19cc:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d0:	fec950e3          	bge	s2,a2,19b0 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    19d4:	05561263          	bne	a2,s5,1a18 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    19d8:	85da                	mv	a1,s6
    19da:	4505                	li	a0,1
    19dc:	ec2ff0ef          	jal	ra,109e <write>
    19e0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19e2:	00001797          	auipc	a5,0x1
    19e6:	e007a723          	sw	zero,-498(a5) # 27f0 <buffer_len>
			if (r < 0) {
    19ea:	06054763          	bltz	a0,1a58 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19ee:	0405                	addi	s0,s0,1
			ret += r;
    19f0:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19f4:	fc8493e3          	bne	s1,s0,19ba <out_unlocked+0x66>
}
    19f8:	70a6                	ld	ra,104(sp)
    19fa:	7406                	ld	s0,96(sp)
    19fc:	64e6                	ld	s1,88(sp)
    19fe:	6946                	ld	s2,80(sp)
    1a00:	6a06                	ld	s4,64(sp)
    1a02:	7ae2                	ld	s5,56(sp)
    1a04:	7b42                	ld	s6,48(sp)
    1a06:	7ba2                	ld	s7,40(sp)
    1a08:	7c02                	ld	s8,32(sp)
    1a0a:	6ce2                	ld	s9,24(sp)
    1a0c:	6d42                	ld	s10,16(sp)
    1a0e:	6da2                	ld	s11,8(sp)
    1a10:	854e                	mv	a0,s3
    1a12:	69a6                	ld	s3,72(sp)
    1a14:	6165                	addi	sp,sp,112
    1a16:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a18:	e90ff0ef          	jal	ra,10a8 <getpid>
    1a1c:	8daa                	mv	s11,a0
    1a1e:	8566                	mv	a0,s9
    1a20:	3b1000ef          	jal	ra,25d0 <basename>
    1a24:	872a                	mv	a4,a0
    1a26:	8662                	mv	a2,s8
    1a28:	05400793          	li	a5,84
    1a2c:	86ee                	mv	a3,s11
    1a2e:	45fd                	li	a1,31
    1a30:	855e                	mv	a0,s7
    1a32:	a97ff0ef          	jal	ra,14c8 <printf>
    1a36:	557d                	li	a0,-1
    1a38:	ea0ff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    1a3c:	000d2603          	lw	a2,0(s10)
    1a40:	da35                	beqz	a2,19b4 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a42:	85da                	mv	a1,s6
    1a44:	4505                	li	a0,1
    1a46:	e58ff0ef          	jal	ra,109e <write>
    1a4a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a4c:	00001797          	auipc	a5,0x1
    1a50:	da07a223          	sw	zero,-604(a5) # 27f0 <buffer_len>
			if (r < 0) {
    1a54:	f8055de3          	bgez	a0,19ee <out_unlocked+0x9a>
    1a58:	89aa                	mv	s3,a0
    1a5a:	bf79                	j	19f8 <out_unlocked+0xa4>
	int ret = 0;
    1a5c:	4981                	li	s3,0
    1a5e:	bf69                	j	19f8 <out_unlocked+0xa4>

0000000000001a60 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a60:	1101                	addi	sp,sp,-32
    1a62:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a64:	00001497          	auipc	s1,0x1
    1a68:	d8c48493          	addi	s1,s1,-628 # 27f0 <buffer_len>
    1a6c:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a6e:	ec06                	sd	ra,24(sp)
    1a70:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a72:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a76:	0017861b          	addiw	a2,a5,1
    1a7a:	97a6                	add	a5,a5,s1
    1a7c:	00e78423          	sb	a4,8(a5)
    1a80:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a82:	0ff00793          	li	a5,255
    1a86:	00c7cc63          	blt	a5,a2,1a9e <out_unlocked.constprop.0+0x3e>
    1a8a:	47a9                	li	a5,10
    1a8c:	06f70c63          	beq	a4,a5,1b04 <out_unlocked.constprop.0+0xa4>
    1a90:	4601                	li	a2,0
}
    1a92:	60e2                	ld	ra,24(sp)
    1a94:	6442                	ld	s0,16(sp)
    1a96:	64a2                	ld	s1,8(sp)
    1a98:	8532                	mv	a0,a2
    1a9a:	6105                	addi	sp,sp,32
    1a9c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a9e:	10000793          	li	a5,256
    1aa2:	02f61563          	bne	a2,a5,1acc <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1aa6:	00001597          	auipc	a1,0x1
    1aaa:	d5258593          	addi	a1,a1,-686 # 27f8 <buffer>
    1aae:	4505                	li	a0,1
    1ab0:	deeff0ef          	jal	ra,109e <write>
}
    1ab4:	60e2                	ld	ra,24(sp)
    1ab6:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1ab8:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1abc:	00001797          	auipc	a5,0x1
    1ac0:	d207aa23          	sw	zero,-716(a5) # 27f0 <buffer_len>
}
    1ac4:	64a2                	ld	s1,8(sp)
    1ac6:	8532                	mv	a0,a2
    1ac8:	6105                	addi	sp,sp,32
    1aca:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1acc:	ddcff0ef          	jal	ra,10a8 <getpid>
    1ad0:	842a                	mv	s0,a0
    1ad2:	00001517          	auipc	a0,0x1
    1ad6:	c2650513          	addi	a0,a0,-986 # 26f8 <basename+0x128>
    1ada:	2f7000ef          	jal	ra,25d0 <basename>
    1ade:	872a                	mv	a4,a0
    1ae0:	00001617          	auipc	a2,0x1
    1ae4:	c5860613          	addi	a2,a2,-936 # 2738 <basename+0x168>
    1ae8:	05400793          	li	a5,84
    1aec:	86a2                	mv	a3,s0
    1aee:	45fd                	li	a1,31
    1af0:	00001517          	auipc	a0,0x1
    1af4:	c5050513          	addi	a0,a0,-944 # 2740 <basename+0x170>
    1af8:	9d1ff0ef          	jal	ra,14c8 <printf>
    1afc:	557d                	li	a0,-1
    1afe:	ddaff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    1b02:	4090                	lw	a2,0(s1)
    1b04:	d659                	beqz	a2,1a92 <out_unlocked.constprop.0+0x32>
    1b06:	b745                	j	1aa6 <out_unlocked.constprop.0+0x46>

0000000000001b08 <putchar>:
{
    1b08:	7139                	addi	sp,sp,-64
    1b0a:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1b0c:	00001497          	auipc	s1,0x1
    1b10:	ce448493          	addi	s1,s1,-796 # 27f0 <buffer_len>
    1b14:	1084a703          	lw	a4,264(s1)
{
    1b18:	f822                	sd	s0,48(sp)
	char byte = c;
    1b1a:	0ff57413          	zext.b	s0,a0
{
    1b1e:	fc06                	sd	ra,56(sp)
	char byte = c;
    1b20:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1b24:	4785                	li	a5,1
    1b26:	00f70d63          	beq	a4,a5,1b40 <putchar+0x38>
		len = out_unlocked(s, l);
    1b2a:	01f10513          	addi	a0,sp,31
    1b2e:	f33ff0ef          	jal	ra,1a60 <out_unlocked.constprop.0>
}
    1b32:	70e2                	ld	ra,56(sp)
    1b34:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1b36:	862a                	mv	a2,a0
}
    1b38:	74a2                	ld	s1,40(sp)
    1b3a:	8532                	mv	a0,a2
    1b3c:	6121                	addi	sp,sp,64
    1b3e:	8082                	ret
		mutex_lock(buffer_lock);
    1b40:	10c4a503          	lw	a0,268(s1)
    1b44:	fd2ff0ef          	jal	ra,1316 <mutex_lock>
		buffer[buffer_len++] = c;
    1b48:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b4a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b4e:	0017861b          	addiw	a2,a5,1
    1b52:	97a6                	add	a5,a5,s1
    1b54:	c090                	sw	a2,0(s1)
    1b56:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b5a:	02c6c263          	blt	a3,a2,1b7e <putchar+0x76>
    1b5e:	47a9                	li	a5,10
    1b60:	06f40d63          	beq	s0,a5,1bda <putchar+0xd2>
    1b64:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b66:	10c4a503          	lw	a0,268(s1)
    1b6a:	e432                	sd	a2,8(sp)
    1b6c:	fb6ff0ef          	jal	ra,1322 <mutex_unlock>
    1b70:	6622                	ld	a2,8(sp)
}
    1b72:	70e2                	ld	ra,56(sp)
    1b74:	7442                	ld	s0,48(sp)
    1b76:	74a2                	ld	s1,40(sp)
    1b78:	8532                	mv	a0,a2
    1b7a:	6121                	addi	sp,sp,64
    1b7c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b7e:	10000793          	li	a5,256
    1b82:	02f61063          	bne	a2,a5,1ba2 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b86:	00001597          	auipc	a1,0x1
    1b8a:	c7258593          	addi	a1,a1,-910 # 27f8 <buffer>
    1b8e:	4505                	li	a0,1
    1b90:	d0eff0ef          	jal	ra,109e <write>
    1b94:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b98:	00001797          	auipc	a5,0x1
    1b9c:	c407ac23          	sw	zero,-936(a5) # 27f0 <buffer_len>
			if (r < 0) {
    1ba0:	b7d9                	j	1b66 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1ba2:	d06ff0ef          	jal	ra,10a8 <getpid>
    1ba6:	842a                	mv	s0,a0
    1ba8:	00001517          	auipc	a0,0x1
    1bac:	b5050513          	addi	a0,a0,-1200 # 26f8 <basename+0x128>
    1bb0:	221000ef          	jal	ra,25d0 <basename>
    1bb4:	872a                	mv	a4,a0
    1bb6:	00001617          	auipc	a2,0x1
    1bba:	b8260613          	addi	a2,a2,-1150 # 2738 <basename+0x168>
    1bbe:	05400793          	li	a5,84
    1bc2:	86a2                	mv	a3,s0
    1bc4:	45fd                	li	a1,31
    1bc6:	00001517          	auipc	a0,0x1
    1bca:	b7a50513          	addi	a0,a0,-1158 # 2740 <basename+0x170>
    1bce:	8fbff0ef          	jal	ra,14c8 <printf>
    1bd2:	557d                	li	a0,-1
    1bd4:	d04ff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    1bd8:	4090                	lw	a2,0(s1)
    1bda:	d651                	beqz	a2,1b66 <putchar+0x5e>
    1bdc:	b76d                	j	1b86 <putchar+0x7e>

0000000000001bde <puts>:
{
    1bde:	7139                	addi	sp,sp,-64
    1be0:	f822                	sd	s0,48(sp)
    1be2:	f426                	sd	s1,40(sp)
    1be4:	fc06                	sd	ra,56(sp)
    1be6:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1be8:	00001417          	auipc	s0,0x1
    1bec:	c0840413          	addi	s0,s0,-1016 # 27f0 <buffer_len>
{
    1bf0:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bf2:	638000ef          	jal	ra,222a <strlen>
	if (buffer_lock_enabled == 1) {
    1bf6:	10842703          	lw	a4,264(s0)
    1bfa:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bfc:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bfe:	04f70563          	beq	a4,a5,1c48 <puts+0x6a>
		len = out_unlocked(s, l);
    1c02:	8526                	mv	a0,s1
    1c04:	d51ff0ef          	jal	ra,1954 <out_unlocked>
    1c08:	892a                	mv	s2,a0
    1c0a:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c0c:	00095963          	bgez	s2,1c1e <puts+0x40>
}
    1c10:	70e2                	ld	ra,56(sp)
    1c12:	7442                	ld	s0,48(sp)
    1c14:	7902                	ld	s2,32(sp)
    1c16:	8526                	mv	a0,s1
    1c18:	74a2                	ld	s1,40(sp)
    1c1a:	6121                	addi	sp,sp,64
    1c1c:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1c1e:	10842703          	lw	a4,264(s0)
	char byte = c;
    1c22:	44a9                	li	s1,10
    1c24:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1c28:	4785                	li	a5,1
    1c2a:	02f70e63          	beq	a4,a5,1c66 <puts+0x88>
		len = out_unlocked(s, l);
    1c2e:	01f10513          	addi	a0,sp,31
    1c32:	e2fff0ef          	jal	ra,1a60 <out_unlocked.constprop.0>
}
    1c36:	70e2                	ld	ra,56(sp)
    1c38:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c3a:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c3e:	7902                	ld	s2,32(sp)
    1c40:	8526                	mv	a0,s1
    1c42:	74a2                	ld	s1,40(sp)
    1c44:	6121                	addi	sp,sp,64
    1c46:	8082                	ret
		mutex_lock(buffer_lock);
    1c48:	e42a                	sd	a0,8(sp)
    1c4a:	10c42503          	lw	a0,268(s0)
    1c4e:	ec8ff0ef          	jal	ra,1316 <mutex_lock>
		len = out_unlocked(s, l);
    1c52:	65a2                	ld	a1,8(sp)
    1c54:	8526                	mv	a0,s1
    1c56:	cffff0ef          	jal	ra,1954 <out_unlocked>
    1c5a:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c5c:	10c42503          	lw	a0,268(s0)
    1c60:	ec2ff0ef          	jal	ra,1322 <mutex_unlock>
    1c64:	b75d                	j	1c0a <puts+0x2c>
		mutex_lock(buffer_lock);
    1c66:	10c42503          	lw	a0,268(s0)
    1c6a:	eacff0ef          	jal	ra,1316 <mutex_lock>
		buffer[buffer_len++] = c;
    1c6e:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c70:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c74:	0017861b          	addiw	a2,a5,1
    1c78:	97a2                	add	a5,a5,s0
    1c7a:	c010                	sw	a2,0(s0)
    1c7c:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c80:	06c6dc63          	bge	a3,a2,1cf8 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c84:	10000793          	li	a5,256
    1c88:	02f61c63          	bne	a2,a5,1cc0 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c8c:	00001597          	auipc	a1,0x1
    1c90:	b6c58593          	addi	a1,a1,-1172 # 27f8 <buffer>
    1c94:	4505                	li	a0,1
    1c96:	c08ff0ef          	jal	ra,109e <write>
			if (r < 0) {
    1c9a:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c9c:	00001797          	auipc	a5,0x1
    1ca0:	b407aa23          	sw	zero,-1196(a5) # 27f0 <buffer_len>
			if (r < 0) {
    1ca4:	04054c63          	bltz	a0,1cfc <puts+0x11e>
			if (r < buffer_len) {
    1ca8:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1caa:	10c42503          	lw	a0,268(s0)
    1cae:	e74ff0ef          	jal	ra,1322 <mutex_unlock>
}
    1cb2:	70e2                	ld	ra,56(sp)
    1cb4:	7442                	ld	s0,48(sp)
    1cb6:	7902                	ld	s2,32(sp)
    1cb8:	8526                	mv	a0,s1
    1cba:	74a2                	ld	s1,40(sp)
    1cbc:	6121                	addi	sp,sp,64
    1cbe:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1cc0:	be8ff0ef          	jal	ra,10a8 <getpid>
    1cc4:	84aa                	mv	s1,a0
    1cc6:	00001517          	auipc	a0,0x1
    1cca:	a3250513          	addi	a0,a0,-1486 # 26f8 <basename+0x128>
    1cce:	103000ef          	jal	ra,25d0 <basename>
    1cd2:	872a                	mv	a4,a0
    1cd4:	00001617          	auipc	a2,0x1
    1cd8:	a6460613          	addi	a2,a2,-1436 # 2738 <basename+0x168>
    1cdc:	05400793          	li	a5,84
    1ce0:	86a6                	mv	a3,s1
    1ce2:	45fd                	li	a1,31
    1ce4:	00001517          	auipc	a0,0x1
    1ce8:	a5c50513          	addi	a0,a0,-1444 # 2740 <basename+0x170>
    1cec:	fdcff0ef          	jal	ra,14c8 <printf>
    1cf0:	557d                	li	a0,-1
    1cf2:	be6ff0ef          	jal	ra,10d8 <exit>
	if (buffer_len == 0)
    1cf6:	4010                	lw	a2,0(s0)
    1cf8:	da45                	beqz	a2,1ca8 <puts+0xca>
    1cfa:	bf49                	j	1c8c <puts+0xae>
    1cfc:	54fd                	li	s1,-1
    1cfe:	b775                	j	1caa <puts+0xcc>

0000000000001d00 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1d00:	715d                	addi	sp,sp,-80
    1d02:	e486                	sd	ra,72(sp)
    1d04:	e0a2                	sd	s0,64(sp)
    1d06:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1d08:	14054363          	bltz	a0,1e4e <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1d0c:	02b577bb          	remuw	a5,a0,a1
    1d10:	00001617          	auipc	a2,0x1
    1d14:	c2060613          	addi	a2,a2,-992 # 2930 <digits>
	buf[16] = 0;
    1d18:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d1c:	0005871b          	sext.w	a4,a1
    1d20:	1782                	slli	a5,a5,0x20
    1d22:	9381                	srli	a5,a5,0x20
    1d24:	97b2                	add	a5,a5,a2
    1d26:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d2a:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1d2e:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1d32:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1d34:	0eb56763          	bltu	a0,a1,1e22 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d38:	02e877bb          	remuw	a5,a6,a4
    1d3c:	1782                	slli	a5,a5,0x20
    1d3e:	9381                	srli	a5,a5,0x20
    1d40:	97b2                	add	a5,a5,a2
    1d42:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d46:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d4a:	02f10323          	sb	a5,38(sp)
    1d4e:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d50:	0ce86963          	bltu	a6,a4,1e22 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d54:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d58:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d5c:	1582                	slli	a1,a1,0x20
    1d5e:	9181                	srli	a1,a1,0x20
    1d60:	95b2                	add	a1,a1,a2
    1d62:	0005c583          	lbu	a1,0(a1)
    1d66:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d6a:	0007859b          	sext.w	a1,a5
    1d6e:	16e6e563          	bltu	a3,a4,1ed8 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d72:	02e7f6bb          	remuw	a3,a5,a4
    1d76:	1682                	slli	a3,a3,0x20
    1d78:	9281                	srli	a3,a3,0x20
    1d7a:	96b2                	add	a3,a3,a2
    1d7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d80:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d84:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d88:	16e5e163          	bltu	a1,a4,1eea <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d8c:	02e876bb          	remuw	a3,a6,a4
    1d90:	1682                	slli	a3,a3,0x20
    1d92:	9281                	srli	a3,a3,0x20
    1d94:	96b2                	add	a3,a3,a2
    1d96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d9a:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d9e:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1da2:	14e86d63          	bltu	a6,a4,1efc <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1da6:	02e5f6bb          	remuw	a3,a1,a4
    1daa:	1682                	slli	a3,a3,0x20
    1dac:	9281                	srli	a3,a3,0x20
    1dae:	96b2                	add	a3,a3,a2
    1db0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1db4:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1db8:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1dbc:	10e5e563          	bltu	a1,a4,1ec6 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1dc0:	02e876bb          	remuw	a3,a6,a4
    1dc4:	1682                	slli	a3,a3,0x20
    1dc6:	9281                	srli	a3,a3,0x20
    1dc8:	96b2                	add	a3,a3,a2
    1dca:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dce:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1dd2:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1dd6:	14e86263          	bltu	a6,a4,1f1a <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1dda:	02e5f6bb          	remuw	a3,a1,a4
    1dde:	1682                	slli	a3,a3,0x20
    1de0:	9281                	srli	a3,a3,0x20
    1de2:	96b2                	add	a3,a3,a2
    1de4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1de8:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1dec:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1df0:	14e5e463          	bltu	a1,a4,1f38 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1df4:	02e876bb          	remuw	a3,a6,a4
    1df8:	1682                	slli	a3,a3,0x20
    1dfa:	9281                	srli	a3,a3,0x20
    1dfc:	96b2                	add	a3,a3,a2
    1dfe:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1e02:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1e06:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1e0a:	14e86063          	bltu	a6,a4,1f4a <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1e0e:	1782                	slli	a5,a5,0x20
    1e10:	9381                	srli	a5,a5,0x20
    1e12:	97b2                	add	a5,a5,a2
    1e14:	0007c703          	lbu	a4,0(a5)
    1e18:	4799                	li	a5,6
    1e1a:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1e1e:	10054763          	bltz	a0,1f2c <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1e22:	00001497          	auipc	s1,0x1
    1e26:	9ce48493          	addi	s1,s1,-1586 # 27f0 <buffer_len>
    1e2a:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1e2e:	0828                	addi	a0,sp,24
    1e30:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1e32:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1e34:	00f50433          	add	s0,a0,a5
    1e38:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1e3a:	06e68463          	beq	a3,a4,1ea2 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e3e:	8522                	mv	a0,s0
    1e40:	b15ff0ef          	jal	ra,1954 <out_unlocked>
}
    1e44:	60a6                	ld	ra,72(sp)
    1e46:	6406                	ld	s0,64(sp)
    1e48:	74e2                	ld	s1,56(sp)
    1e4a:	6161                	addi	sp,sp,80
    1e4c:	8082                	ret
		x = -xx;
    1e4e:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e52:	02b877bb          	remuw	a5,a6,a1
    1e56:	00001617          	auipc	a2,0x1
    1e5a:	ada60613          	addi	a2,a2,-1318 # 2930 <digits>
	buf[16] = 0;
    1e5e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e62:	0005871b          	sext.w	a4,a1
    1e66:	1782                	slli	a5,a5,0x20
    1e68:	9381                	srli	a5,a5,0x20
    1e6a:	97b2                	add	a5,a5,a2
    1e6c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e70:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e74:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e78:	08b86b63          	bltu	a6,a1,1f0e <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e7c:	02e8f7bb          	remuw	a5,a7,a4
    1e80:	1782                	slli	a5,a5,0x20
    1e82:	9381                	srli	a5,a5,0x20
    1e84:	97b2                	add	a5,a5,a2
    1e86:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e8a:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e8e:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e92:	ece8f1e3          	bgeu	a7,a4,1d54 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e96:	02d00793          	li	a5,45
    1e9a:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e9e:	47b5                	li	a5,13
    1ea0:	b749                	j	1e22 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1ea2:	10c4a503          	lw	a0,268(s1)
    1ea6:	e42e                	sd	a1,8(sp)
    1ea8:	c6eff0ef          	jal	ra,1316 <mutex_lock>
		len = out_unlocked(s, l);
    1eac:	65a2                	ld	a1,8(sp)
    1eae:	8522                	mv	a0,s0
    1eb0:	aa5ff0ef          	jal	ra,1954 <out_unlocked>
		mutex_unlock(buffer_lock);
    1eb4:	10c4a503          	lw	a0,268(s1)
    1eb8:	c6aff0ef          	jal	ra,1322 <mutex_unlock>
}
    1ebc:	60a6                	ld	ra,72(sp)
    1ebe:	6406                	ld	s0,64(sp)
    1ec0:	74e2                	ld	s1,56(sp)
    1ec2:	6161                	addi	sp,sp,80
    1ec4:	8082                	ret
		buf[i--] = digits[x % base];
    1ec6:	47a9                	li	a5,10
	if (sign)
    1ec8:	f4055de3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ecc:	02d00793          	li	a5,45
    1ed0:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1ed4:	47a5                	li	a5,9
    1ed6:	b7b1                	j	1e22 <printint.constprop.0+0x122>
    1ed8:	47b5                	li	a5,13
	if (sign)
    1eda:	f40554e3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ede:	02d00793          	li	a5,45
    1ee2:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1ee6:	47b1                	li	a5,12
    1ee8:	bf2d                	j	1e22 <printint.constprop.0+0x122>
    1eea:	47b1                	li	a5,12
	if (sign)
    1eec:	f2055be3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef0:	02d00793          	li	a5,45
    1ef4:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ef8:	47ad                	li	a5,11
    1efa:	b725                	j	1e22 <printint.constprop.0+0x122>
    1efc:	47ad                	li	a5,11
	if (sign)
    1efe:	f20552e3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f02:	02d00793          	li	a5,45
    1f06:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1f0a:	47a9                	li	a5,10
    1f0c:	bf19                	j	1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f0e:	02d00793          	li	a5,45
    1f12:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1f16:	47b9                	li	a5,14
    1f18:	b729                	j	1e22 <printint.constprop.0+0x122>
    1f1a:	47a5                	li	a5,9
	if (sign)
    1f1c:	f00553e3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f20:	02d00793          	li	a5,45
    1f24:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1f28:	47a1                	li	a5,8
    1f2a:	bde5                	j	1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f2c:	02d00793          	li	a5,45
    1f30:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1f34:	4795                	li	a5,5
    1f36:	b5f5                	j	1e22 <printint.constprop.0+0x122>
    1f38:	47a1                	li	a5,8
	if (sign)
    1f3a:	ee0554e3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f3e:	02d00793          	li	a5,45
    1f42:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f46:	479d                	li	a5,7
    1f48:	bde9                	j	1e22 <printint.constprop.0+0x122>
    1f4a:	479d                	li	a5,7
	if (sign)
    1f4c:	ec055be3          	bgez	a0,1e22 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f50:	02d00793          	li	a5,45
    1f54:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f58:	4799                	li	a5,6
    1f5a:	b5e1                	j	1e22 <printint.constprop.0+0x122>

0000000000001f5c <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f5c:	02000793          	li	a5,32
    1f60:	00f50663          	beq	a0,a5,1f6c <isspace+0x10>
    1f64:	355d                	addiw	a0,a0,-9
    1f66:	00553513          	sltiu	a0,a0,5
    1f6a:	8082                	ret
    1f6c:	4505                	li	a0,1
}
    1f6e:	8082                	ret

0000000000001f70 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f70:	fd05051b          	addiw	a0,a0,-48
}
    1f74:	00a53513          	sltiu	a0,a0,10
    1f78:	8082                	ret

0000000000001f7a <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f7a:	02000613          	li	a2,32
    1f7e:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f80:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f84:	ff77869b          	addiw	a3,a5,-9
    1f88:	04c78c63          	beq	a5,a2,1fe0 <atoi+0x66>
    1f8c:	0007871b          	sext.w	a4,a5
    1f90:	04d5f863          	bgeu	a1,a3,1fe0 <atoi+0x66>
		s++;
	switch (*s) {
    1f94:	02b00693          	li	a3,43
    1f98:	04d78963          	beq	a5,a3,1fea <atoi+0x70>
    1f9c:	02d00693          	li	a3,45
    1fa0:	06d78263          	beq	a5,a3,2004 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1fa4:	fd07061b          	addiw	a2,a4,-48
    1fa8:	47a5                	li	a5,9
    1faa:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1fac:	4e01                	li	t3,0
	while (isdigit(*s))
    1fae:	04c7e963          	bltu	a5,a2,2000 <atoi+0x86>
	int n = 0, neg = 0;
    1fb2:	4501                	li	a0,0
	while (isdigit(*s))
    1fb4:	4825                	li	a6,9
    1fb6:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1fba:	0025179b          	slliw	a5,a0,0x2
    1fbe:	9fa9                	addw	a5,a5,a0
    1fc0:	fd07031b          	addiw	t1,a4,-48
    1fc4:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1fc8:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1fcc:	0685                	addi	a3,a3,1
    1fce:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1fd2:	0006071b          	sext.w	a4,a2
    1fd6:	feb870e3          	bgeu	a6,a1,1fb6 <atoi+0x3c>
	return neg ? n : -n;
    1fda:	000e0563          	beqz	t3,1fe4 <atoi+0x6a>
}
    1fde:	8082                	ret
		s++;
    1fe0:	0505                	addi	a0,a0,1
    1fe2:	bf79                	j	1f80 <atoi+0x6>
	return neg ? n : -n;
    1fe4:	4113053b          	subw	a0,t1,a7
    1fe8:	8082                	ret
	while (isdigit(*s))
    1fea:	00154703          	lbu	a4,1(a0)
    1fee:	47a5                	li	a5,9
		s++;
    1ff0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ff4:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1ff8:	4e01                	li	t3,0
	while (isdigit(*s))
    1ffa:	2701                	sext.w	a4,a4
    1ffc:	fac7fbe3          	bgeu	a5,a2,1fb2 <atoi+0x38>
    2000:	4501                	li	a0,0
}
    2002:	8082                	ret
	while (isdigit(*s))
    2004:	00154703          	lbu	a4,1(a0)
    2008:	47a5                	li	a5,9
		s++;
    200a:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    200e:	fd07061b          	addiw	a2,a4,-48
    2012:	2701                	sext.w	a4,a4
    2014:	fec7e6e3          	bltu	a5,a2,2000 <atoi+0x86>
		neg = 1;
    2018:	4e05                	li	t3,1
    201a:	bf61                	j	1fb2 <atoi+0x38>

000000000000201c <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    201c:	16060d63          	beqz	a2,2196 <memset+0x17a>
    2020:	40a007b3          	neg	a5,a0
    2024:	8b9d                	andi	a5,a5,7
    2026:	00778693          	addi	a3,a5,7
    202a:	482d                	li	a6,11
    202c:	0ff5f713          	zext.b	a4,a1
    2030:	fff60593          	addi	a1,a2,-1
    2034:	1706e263          	bltu	a3,a6,2198 <memset+0x17c>
    2038:	16d5ea63          	bltu	a1,a3,21ac <memset+0x190>
    203c:	16078563          	beqz	a5,21a6 <memset+0x18a>
    2040:	00e50023          	sb	a4,0(a0)
    2044:	4685                	li	a3,1
    2046:	00150593          	addi	a1,a0,1
    204a:	14d78c63          	beq	a5,a3,21a2 <memset+0x186>
    204e:	00e500a3          	sb	a4,1(a0)
    2052:	4689                	li	a3,2
    2054:	00250593          	addi	a1,a0,2
    2058:	14d78d63          	beq	a5,a3,21b2 <memset+0x196>
    205c:	00e50123          	sb	a4,2(a0)
    2060:	468d                	li	a3,3
    2062:	00350593          	addi	a1,a0,3
    2066:	12d78b63          	beq	a5,a3,219c <memset+0x180>
    206a:	00e501a3          	sb	a4,3(a0)
    206e:	4691                	li	a3,4
    2070:	00450593          	addi	a1,a0,4
    2074:	14d78163          	beq	a5,a3,21b6 <memset+0x19a>
    2078:	00e50223          	sb	a4,4(a0)
    207c:	4695                	li	a3,5
    207e:	00550593          	addi	a1,a0,5
    2082:	12d78c63          	beq	a5,a3,21ba <memset+0x19e>
    2086:	00e502a3          	sb	a4,5(a0)
    208a:	469d                	li	a3,7
    208c:	00650593          	addi	a1,a0,6
    2090:	12d79763          	bne	a5,a3,21be <memset+0x1a2>
    2094:	00750593          	addi	a1,a0,7
    2098:	00e50323          	sb	a4,6(a0)
    209c:	481d                	li	a6,7
    209e:	00871693          	slli	a3,a4,0x8
    20a2:	01071893          	slli	a7,a4,0x10
    20a6:	8ed9                	or	a3,a3,a4
    20a8:	01871313          	slli	t1,a4,0x18
    20ac:	0116e6b3          	or	a3,a3,a7
    20b0:	0066e6b3          	or	a3,a3,t1
    20b4:	02071893          	slli	a7,a4,0x20
    20b8:	02871e13          	slli	t3,a4,0x28
    20bc:	0116e6b3          	or	a3,a3,a7
    20c0:	40f60333          	sub	t1,a2,a5
    20c4:	03071893          	slli	a7,a4,0x30
    20c8:	01c6e6b3          	or	a3,a3,t3
    20cc:	0116e6b3          	or	a3,a3,a7
    20d0:	03871e13          	slli	t3,a4,0x38
    20d4:	97aa                	add	a5,a5,a0
    20d6:	ff837893          	andi	a7,t1,-8
    20da:	01c6e6b3          	or	a3,a3,t3
    20de:	98be                	add	a7,a7,a5
    20e0:	e394                	sd	a3,0(a5)
    20e2:	07a1                	addi	a5,a5,8
    20e4:	ff179ee3          	bne	a5,a7,20e0 <memset+0xc4>
    20e8:	ff837893          	andi	a7,t1,-8
    20ec:	011587b3          	add	a5,a1,a7
    20f0:	010886bb          	addw	a3,a7,a6
    20f4:	0b130663          	beq	t1,a7,21a0 <memset+0x184>
    20f8:	00e78023          	sb	a4,0(a5)
    20fc:	0016859b          	addiw	a1,a3,1
    2100:	08c5fb63          	bgeu	a1,a2,2196 <memset+0x17a>
    2104:	00e780a3          	sb	a4,1(a5)
    2108:	0026859b          	addiw	a1,a3,2
    210c:	08c5f563          	bgeu	a1,a2,2196 <memset+0x17a>
    2110:	00e78123          	sb	a4,2(a5)
    2114:	0036859b          	addiw	a1,a3,3
    2118:	06c5ff63          	bgeu	a1,a2,2196 <memset+0x17a>
    211c:	00e781a3          	sb	a4,3(a5)
    2120:	0046859b          	addiw	a1,a3,4
    2124:	06c5f963          	bgeu	a1,a2,2196 <memset+0x17a>
    2128:	00e78223          	sb	a4,4(a5)
    212c:	0056859b          	addiw	a1,a3,5
    2130:	06c5f363          	bgeu	a1,a2,2196 <memset+0x17a>
    2134:	00e782a3          	sb	a4,5(a5)
    2138:	0066859b          	addiw	a1,a3,6
    213c:	04c5fd63          	bgeu	a1,a2,2196 <memset+0x17a>
    2140:	00e78323          	sb	a4,6(a5)
    2144:	0076859b          	addiw	a1,a3,7
    2148:	04c5f763          	bgeu	a1,a2,2196 <memset+0x17a>
    214c:	00e783a3          	sb	a4,7(a5)
    2150:	0086859b          	addiw	a1,a3,8
    2154:	04c5f163          	bgeu	a1,a2,2196 <memset+0x17a>
    2158:	00e78423          	sb	a4,8(a5)
    215c:	0096859b          	addiw	a1,a3,9
    2160:	02c5fb63          	bgeu	a1,a2,2196 <memset+0x17a>
    2164:	00e784a3          	sb	a4,9(a5)
    2168:	00a6859b          	addiw	a1,a3,10
    216c:	02c5f563          	bgeu	a1,a2,2196 <memset+0x17a>
    2170:	00e78523          	sb	a4,10(a5)
    2174:	00b6859b          	addiw	a1,a3,11
    2178:	00c5ff63          	bgeu	a1,a2,2196 <memset+0x17a>
    217c:	00e785a3          	sb	a4,11(a5)
    2180:	00c6859b          	addiw	a1,a3,12
    2184:	00c5f963          	bgeu	a1,a2,2196 <memset+0x17a>
    2188:	00e78623          	sb	a4,12(a5)
    218c:	26b5                	addiw	a3,a3,13
    218e:	00c6f463          	bgeu	a3,a2,2196 <memset+0x17a>
    2192:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2196:	8082                	ret
    2198:	46ad                	li	a3,11
    219a:	bd79                	j	2038 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    219c:	480d                	li	a6,3
    219e:	b701                	j	209e <memset+0x82>
    21a0:	8082                	ret
    21a2:	4805                	li	a6,1
    21a4:	bded                	j	209e <memset+0x82>
    21a6:	85aa                	mv	a1,a0
    21a8:	4801                	li	a6,0
    21aa:	bdd5                	j	209e <memset+0x82>
    21ac:	87aa                	mv	a5,a0
    21ae:	4681                	li	a3,0
    21b0:	b7a1                	j	20f8 <memset+0xdc>
    21b2:	4809                	li	a6,2
    21b4:	b5ed                	j	209e <memset+0x82>
    21b6:	4811                	li	a6,4
    21b8:	b5dd                	j	209e <memset+0x82>
    21ba:	4815                	li	a6,5
    21bc:	b5cd                	j	209e <memset+0x82>
    21be:	4819                	li	a6,6
    21c0:	bdf9                	j	209e <memset+0x82>

00000000000021c2 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    21c2:	00054783          	lbu	a5,0(a0)
    21c6:	0005c703          	lbu	a4,0(a1)
    21ca:	00e79863          	bne	a5,a4,21da <strcmp+0x18>
    21ce:	0505                	addi	a0,a0,1
    21d0:	0585                	addi	a1,a1,1
    21d2:	fbe5                	bnez	a5,21c2 <strcmp>
    21d4:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    21d6:	9d19                	subw	a0,a0,a4
    21d8:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    21da:	0007851b          	sext.w	a0,a5
    21de:	bfe5                	j	21d6 <strcmp+0x14>

00000000000021e0 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21e0:	ca15                	beqz	a2,2214 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21e2:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21e6:	167d                	addi	a2,a2,-1
    21e8:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21ec:	eb99                	bnez	a5,2202 <strncmp+0x22>
    21ee:	a815                	j	2222 <strncmp+0x42>
    21f0:	00a68e63          	beq	a3,a0,220c <strncmp+0x2c>
    21f4:	0505                	addi	a0,a0,1
    21f6:	00f71b63          	bne	a4,a5,220c <strncmp+0x2c>
    21fa:	00054783          	lbu	a5,0(a0)
    21fe:	cf89                	beqz	a5,2218 <strncmp+0x38>
    2200:	85b2                	mv	a1,a2
    2202:	0005c703          	lbu	a4,0(a1)
    2206:	00158613          	addi	a2,a1,1
    220a:	f37d                	bnez	a4,21f0 <strncmp+0x10>
		;
	return *l - *r;
    220c:	0007851b          	sext.w	a0,a5
    2210:	9d19                	subw	a0,a0,a4
    2212:	8082                	ret
		return 0;
    2214:	4501                	li	a0,0
}
    2216:	8082                	ret
	return *l - *r;
    2218:	0015c703          	lbu	a4,1(a1)
    221c:	4501                	li	a0,0
    221e:	9d19                	subw	a0,a0,a4
    2220:	8082                	ret
    2222:	0005c703          	lbu	a4,0(a1)
    2226:	4501                	li	a0,0
    2228:	b7e5                	j	2210 <strncmp+0x30>

000000000000222a <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    222a:	00757793          	andi	a5,a0,7
    222e:	cf89                	beqz	a5,2248 <strlen+0x1e>
    2230:	87aa                	mv	a5,a0
    2232:	a029                	j	223c <strlen+0x12>
    2234:	0785                	addi	a5,a5,1
    2236:	0077f713          	andi	a4,a5,7
    223a:	cb01                	beqz	a4,224a <strlen+0x20>
		if (!*s)
    223c:	0007c703          	lbu	a4,0(a5)
    2240:	fb75                	bnez	a4,2234 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2242:	40a78533          	sub	a0,a5,a0
}
    2246:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2248:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    224a:	6394                	ld	a3,0(a5)
    224c:	00000597          	auipc	a1,0x0
    2250:	58c5b583          	ld	a1,1420(a1) # 27d8 <basename+0x208>
    2254:	00000617          	auipc	a2,0x0
    2258:	58c63603          	ld	a2,1420(a2) # 27e0 <basename+0x210>
    225c:	a019                	j	2262 <strlen+0x38>
    225e:	6794                	ld	a3,8(a5)
    2260:	07a1                	addi	a5,a5,8
    2262:	00b68733          	add	a4,a3,a1
    2266:	fff6c693          	not	a3,a3
    226a:	8f75                	and	a4,a4,a3
    226c:	8f71                	and	a4,a4,a2
    226e:	db65                	beqz	a4,225e <strlen+0x34>
	for (; *s; s++)
    2270:	0007c703          	lbu	a4,0(a5)
    2274:	d779                	beqz	a4,2242 <strlen+0x18>
    2276:	0017c703          	lbu	a4,1(a5)
    227a:	0785                	addi	a5,a5,1
    227c:	d379                	beqz	a4,2242 <strlen+0x18>
    227e:	0017c703          	lbu	a4,1(a5)
    2282:	0785                	addi	a5,a5,1
    2284:	fb6d                	bnez	a4,2276 <strlen+0x4c>
    2286:	bf75                	j	2242 <strlen+0x18>

0000000000002288 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2288:	00757713          	andi	a4,a0,7
{
    228c:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    228e:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2292:	cb19                	beqz	a4,22a8 <memchr+0x20>
    2294:	ce25                	beqz	a2,230c <memchr+0x84>
    2296:	0007c703          	lbu	a4,0(a5)
    229a:	04b70e63          	beq	a4,a1,22f6 <memchr+0x6e>
    229e:	0785                	addi	a5,a5,1
    22a0:	0077f713          	andi	a4,a5,7
    22a4:	167d                	addi	a2,a2,-1
    22a6:	f77d                	bnez	a4,2294 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    22a8:	4501                	li	a0,0
	if (n && *s != c) {
    22aa:	c235                	beqz	a2,230e <memchr+0x86>
    22ac:	0007c703          	lbu	a4,0(a5)
    22b0:	04b70363          	beq	a4,a1,22f6 <memchr+0x6e>
		size_t k = ONES * c;
    22b4:	00000517          	auipc	a0,0x0
    22b8:	53453503          	ld	a0,1332(a0) # 27e8 <basename+0x218>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22bc:	471d                	li	a4,7
		size_t k = ONES * c;
    22be:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22c2:	02c77a63          	bgeu	a4,a2,22f6 <memchr+0x6e>
    22c6:	00000897          	auipc	a7,0x0
    22ca:	5128b883          	ld	a7,1298(a7) # 27d8 <basename+0x208>
    22ce:	00000817          	auipc	a6,0x0
    22d2:	51283803          	ld	a6,1298(a6) # 27e0 <basename+0x210>
    22d6:	431d                	li	t1,7
    22d8:	a029                	j	22e2 <memchr+0x5a>
		     w++, n -= SS)
    22da:	1661                	addi	a2,a2,-8
    22dc:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22de:	02c37963          	bgeu	t1,a2,2310 <memchr+0x88>
    22e2:	6398                	ld	a4,0(a5)
    22e4:	8f29                	xor	a4,a4,a0
    22e6:	011706b3          	add	a3,a4,a7
    22ea:	fff74713          	not	a4,a4
    22ee:	8f75                	and	a4,a4,a3
    22f0:	01077733          	and	a4,a4,a6
    22f4:	d37d                	beqz	a4,22da <memchr+0x52>
{
    22f6:	853e                	mv	a0,a5
    22f8:	97b2                	add	a5,a5,a2
    22fa:	a021                	j	2302 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22fc:	0505                	addi	a0,a0,1
    22fe:	00f50763          	beq	a0,a5,230c <memchr+0x84>
    2302:	00054703          	lbu	a4,0(a0)
    2306:	feb71be3          	bne	a4,a1,22fc <memchr+0x74>
    230a:	8082                	ret
	return n ? (void *)s : 0;
    230c:	4501                	li	a0,0
}
    230e:	8082                	ret
	return n ? (void *)s : 0;
    2310:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2312:	f275                	bnez	a2,22f6 <memchr+0x6e>
}
    2314:	8082                	ret

0000000000002316 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2316:	1101                	addi	sp,sp,-32
    2318:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    231a:	862e                	mv	a2,a1
{
    231c:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    231e:	4581                	li	a1,0
{
    2320:	e426                	sd	s1,8(sp)
    2322:	ec06                	sd	ra,24(sp)
    2324:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2326:	f63ff0ef          	jal	ra,2288 <memchr>
	return p ? p - s : n;
    232a:	c519                	beqz	a0,2338 <strnlen+0x22>
}
    232c:	60e2                	ld	ra,24(sp)
    232e:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2330:	8d05                	sub	a0,a0,s1
}
    2332:	64a2                	ld	s1,8(sp)
    2334:	6105                	addi	sp,sp,32
    2336:	8082                	ret
    2338:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    233a:	8522                	mv	a0,s0
}
    233c:	6442                	ld	s0,16(sp)
    233e:	64a2                	ld	s1,8(sp)
    2340:	6105                	addi	sp,sp,32
    2342:	8082                	ret

0000000000002344 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2344:	00a5c7b3          	xor	a5,a1,a0
    2348:	8b9d                	andi	a5,a5,7
    234a:	eb95                	bnez	a5,237e <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    234c:	0075f793          	andi	a5,a1,7
    2350:	e7b1                	bnez	a5,239c <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2352:	6198                	ld	a4,0(a1)
    2354:	00000617          	auipc	a2,0x0
    2358:	48463603          	ld	a2,1156(a2) # 27d8 <basename+0x208>
    235c:	00000817          	auipc	a6,0x0
    2360:	48483803          	ld	a6,1156(a6) # 27e0 <basename+0x210>
    2364:	a029                	j	236e <stpcpy+0x2a>
    2366:	05a1                	addi	a1,a1,8
    2368:	e118                	sd	a4,0(a0)
    236a:	6198                	ld	a4,0(a1)
    236c:	0521                	addi	a0,a0,8
    236e:	00c707b3          	add	a5,a4,a2
    2372:	fff74693          	not	a3,a4
    2376:	8ff5                	and	a5,a5,a3
    2378:	0107f7b3          	and	a5,a5,a6
    237c:	d7ed                	beqz	a5,2366 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    237e:	0005c783          	lbu	a5,0(a1)
    2382:	00f50023          	sb	a5,0(a0)
    2386:	c785                	beqz	a5,23ae <stpcpy+0x6a>
    2388:	0015c783          	lbu	a5,1(a1)
    238c:	0505                	addi	a0,a0,1
    238e:	0585                	addi	a1,a1,1
    2390:	00f50023          	sb	a5,0(a0)
    2394:	fbf5                	bnez	a5,2388 <stpcpy+0x44>
		;
	return d;
}
    2396:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2398:	0505                	addi	a0,a0,1
    239a:	df45                	beqz	a4,2352 <stpcpy+0xe>
			if (!(*d = *s))
    239c:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    23a0:	0585                	addi	a1,a1,1
    23a2:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    23a6:	00f50023          	sb	a5,0(a0)
    23aa:	f7fd                	bnez	a5,2398 <stpcpy+0x54>
}
    23ac:	8082                	ret
    23ae:	8082                	ret

00000000000023b0 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    23b0:	00a5c7b3          	xor	a5,a1,a0
    23b4:	8b9d                	andi	a5,a5,7
    23b6:	1a079863          	bnez	a5,2566 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    23ba:	0075f793          	andi	a5,a1,7
    23be:	16078463          	beqz	a5,2526 <stpncpy+0x176>
    23c2:	ea01                	bnez	a2,23d2 <stpncpy+0x22>
    23c4:	a421                	j	25cc <stpncpy+0x21c>
    23c6:	167d                	addi	a2,a2,-1
    23c8:	0505                	addi	a0,a0,1
    23ca:	14070e63          	beqz	a4,2526 <stpncpy+0x176>
    23ce:	1a060863          	beqz	a2,257e <stpncpy+0x1ce>
    23d2:	0005c783          	lbu	a5,0(a1)
    23d6:	0585                	addi	a1,a1,1
    23d8:	0075f713          	andi	a4,a1,7
    23dc:	00f50023          	sb	a5,0(a0)
    23e0:	f3fd                	bnez	a5,23c6 <stpncpy+0x16>
    23e2:	4805                	li	a6,1
    23e4:	1a061863          	bnez	a2,2594 <stpncpy+0x1e4>
    23e8:	40a007b3          	neg	a5,a0
    23ec:	8b9d                	andi	a5,a5,7
    23ee:	4681                	li	a3,0
    23f0:	18061a63          	bnez	a2,2584 <stpncpy+0x1d4>
    23f4:	00778713          	addi	a4,a5,7
    23f8:	45ad                	li	a1,11
    23fa:	18b76363          	bltu	a4,a1,2580 <stpncpy+0x1d0>
    23fe:	1ae6eb63          	bltu	a3,a4,25b4 <stpncpy+0x204>
    2402:	1a078363          	beqz	a5,25a8 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2406:	00050023          	sb	zero,0(a0)
    240a:	4685                	li	a3,1
    240c:	00150713          	addi	a4,a0,1
    2410:	18d78f63          	beq	a5,a3,25ae <stpncpy+0x1fe>
    2414:	000500a3          	sb	zero,1(a0)
    2418:	4689                	li	a3,2
    241a:	00250713          	addi	a4,a0,2
    241e:	18d78e63          	beq	a5,a3,25ba <stpncpy+0x20a>
    2422:	00050123          	sb	zero,2(a0)
    2426:	468d                	li	a3,3
    2428:	00350713          	addi	a4,a0,3
    242c:	16d78c63          	beq	a5,a3,25a4 <stpncpy+0x1f4>
    2430:	000501a3          	sb	zero,3(a0)
    2434:	4691                	li	a3,4
    2436:	00450713          	addi	a4,a0,4
    243a:	18d78263          	beq	a5,a3,25be <stpncpy+0x20e>
    243e:	00050223          	sb	zero,4(a0)
    2442:	4695                	li	a3,5
    2444:	00550713          	addi	a4,a0,5
    2448:	16d78d63          	beq	a5,a3,25c2 <stpncpy+0x212>
    244c:	000502a3          	sb	zero,5(a0)
    2450:	469d                	li	a3,7
    2452:	00650713          	addi	a4,a0,6
    2456:	16d79863          	bne	a5,a3,25c6 <stpncpy+0x216>
    245a:	00750713          	addi	a4,a0,7
    245e:	00050323          	sb	zero,6(a0)
    2462:	40f80833          	sub	a6,a6,a5
    2466:	ff887593          	andi	a1,a6,-8
    246a:	97aa                	add	a5,a5,a0
    246c:	95be                	add	a1,a1,a5
    246e:	0007b023          	sd	zero,0(a5)
    2472:	07a1                	addi	a5,a5,8
    2474:	feb79de3          	bne	a5,a1,246e <stpncpy+0xbe>
    2478:	ff887593          	andi	a1,a6,-8
    247c:	9ead                	addw	a3,a3,a1
    247e:	00b707b3          	add	a5,a4,a1
    2482:	12b80863          	beq	a6,a1,25b2 <stpncpy+0x202>
    2486:	00078023          	sb	zero,0(a5)
    248a:	0016871b          	addiw	a4,a3,1
    248e:	0ec77863          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    2492:	000780a3          	sb	zero,1(a5)
    2496:	0026871b          	addiw	a4,a3,2
    249a:	0ec77263          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    249e:	00078123          	sb	zero,2(a5)
    24a2:	0036871b          	addiw	a4,a3,3
    24a6:	0cc77c63          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24aa:	000781a3          	sb	zero,3(a5)
    24ae:	0046871b          	addiw	a4,a3,4
    24b2:	0cc77663          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24b6:	00078223          	sb	zero,4(a5)
    24ba:	0056871b          	addiw	a4,a3,5
    24be:	0cc77063          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24c2:	000782a3          	sb	zero,5(a5)
    24c6:	0066871b          	addiw	a4,a3,6
    24ca:	0ac77a63          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24ce:	00078323          	sb	zero,6(a5)
    24d2:	0076871b          	addiw	a4,a3,7
    24d6:	0ac77463          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24da:	000783a3          	sb	zero,7(a5)
    24de:	0086871b          	addiw	a4,a3,8
    24e2:	08c77e63          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24e6:	00078423          	sb	zero,8(a5)
    24ea:	0096871b          	addiw	a4,a3,9
    24ee:	08c77863          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24f2:	000784a3          	sb	zero,9(a5)
    24f6:	00a6871b          	addiw	a4,a3,10
    24fa:	08c77263          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    24fe:	00078523          	sb	zero,10(a5)
    2502:	00b6871b          	addiw	a4,a3,11
    2506:	06c77c63          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    250a:	000785a3          	sb	zero,11(a5)
    250e:	00c6871b          	addiw	a4,a3,12
    2512:	06c77663          	bgeu	a4,a2,257e <stpncpy+0x1ce>
    2516:	00078623          	sb	zero,12(a5)
    251a:	26b5                	addiw	a3,a3,13
    251c:	06c6f163          	bgeu	a3,a2,257e <stpncpy+0x1ce>
    2520:	000786a3          	sb	zero,13(a5)
    2524:	8082                	ret
			;
		if (!n || !*s)
    2526:	c645                	beqz	a2,25ce <stpncpy+0x21e>
    2528:	0005c783          	lbu	a5,0(a1)
    252c:	ea078be3          	beqz	a5,23e2 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2530:	479d                	li	a5,7
    2532:	02c7ff63          	bgeu	a5,a2,2570 <stpncpy+0x1c0>
    2536:	00000897          	auipc	a7,0x0
    253a:	2a28b883          	ld	a7,674(a7) # 27d8 <basename+0x208>
    253e:	00000817          	auipc	a6,0x0
    2542:	2a283803          	ld	a6,674(a6) # 27e0 <basename+0x210>
    2546:	431d                	li	t1,7
    2548:	6198                	ld	a4,0(a1)
    254a:	011707b3          	add	a5,a4,a7
    254e:	fff74693          	not	a3,a4
    2552:	8ff5                	and	a5,a5,a3
    2554:	0107f7b3          	and	a5,a5,a6
    2558:	ef81                	bnez	a5,2570 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    255a:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    255c:	1661                	addi	a2,a2,-8
    255e:	05a1                	addi	a1,a1,8
    2560:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2562:	fec363e3          	bltu	t1,a2,2548 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2566:	e609                	bnez	a2,2570 <stpncpy+0x1c0>
    2568:	a08d                	j	25ca <stpncpy+0x21a>
    256a:	167d                	addi	a2,a2,-1
    256c:	0505                	addi	a0,a0,1
    256e:	ca01                	beqz	a2,257e <stpncpy+0x1ce>
    2570:	0005c783          	lbu	a5,0(a1)
    2574:	0585                	addi	a1,a1,1
    2576:	00f50023          	sb	a5,0(a0)
    257a:	fbe5                	bnez	a5,256a <stpncpy+0x1ba>
		;
tail:
    257c:	b59d                	j	23e2 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    257e:	8082                	ret
    2580:	472d                	li	a4,11
    2582:	bdb5                	j	23fe <stpncpy+0x4e>
    2584:	00778713          	addi	a4,a5,7
    2588:	45ad                	li	a1,11
    258a:	fff60693          	addi	a3,a2,-1
    258e:	e6b778e3          	bgeu	a4,a1,23fe <stpncpy+0x4e>
    2592:	b7fd                	j	2580 <stpncpy+0x1d0>
    2594:	40a007b3          	neg	a5,a0
    2598:	8832                	mv	a6,a2
    259a:	8b9d                	andi	a5,a5,7
    259c:	4681                	li	a3,0
    259e:	e4060be3          	beqz	a2,23f4 <stpncpy+0x44>
    25a2:	b7cd                	j	2584 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    25a4:	468d                	li	a3,3
    25a6:	bd75                	j	2462 <stpncpy+0xb2>
    25a8:	872a                	mv	a4,a0
    25aa:	4681                	li	a3,0
    25ac:	bd5d                	j	2462 <stpncpy+0xb2>
    25ae:	4685                	li	a3,1
    25b0:	bd4d                	j	2462 <stpncpy+0xb2>
    25b2:	8082                	ret
    25b4:	87aa                	mv	a5,a0
    25b6:	4681                	li	a3,0
    25b8:	b5f9                	j	2486 <stpncpy+0xd6>
    25ba:	4689                	li	a3,2
    25bc:	b55d                	j	2462 <stpncpy+0xb2>
    25be:	4691                	li	a3,4
    25c0:	b54d                	j	2462 <stpncpy+0xb2>
    25c2:	4695                	li	a3,5
    25c4:	bd79                	j	2462 <stpncpy+0xb2>
    25c6:	4699                	li	a3,6
    25c8:	bd69                	j	2462 <stpncpy+0xb2>
    25ca:	8082                	ret
    25cc:	8082                	ret
    25ce:	8082                	ret

00000000000025d0 <basename>:

char *basename(char *s)
{
    25d0:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    25d2:	c54d                	beqz	a0,267c <basename+0xac>
    25d4:	00054783          	lbu	a5,0(a0)
		return ".";
    25d8:	00000517          	auipc	a0,0x0
    25dc:	1f850513          	addi	a0,a0,504 # 27d0 <basename+0x200>
	if (!s || !*s)
    25e0:	e391                	bnez	a5,25e4 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25e2:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25e4:	0076f713          	andi	a4,a3,7
    25e8:	87b6                	mv	a5,a3
    25ea:	cf51                	beqz	a4,2686 <basename+0xb6>
    25ec:	0785                	addi	a5,a5,1
    25ee:	0077f713          	andi	a4,a5,7
    25f2:	c729                	beqz	a4,263c <basename+0x6c>
		if (!*s)
    25f4:	0007c703          	lbu	a4,0(a5)
    25f8:	fb75                	bnez	a4,25ec <basename+0x1c>
	return s - a;
    25fa:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25fc:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25fe:	cf8d                	beqz	a5,2638 <basename+0x68>
    2600:	00f68733          	add	a4,a3,a5
    2604:	02f00593          	li	a1,47
    2608:	a031                	j	2614 <basename+0x44>
		s[i] = 0;
    260a:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    260e:	17fd                	addi	a5,a5,-1
    2610:	177d                	addi	a4,a4,-1
    2612:	c39d                	beqz	a5,2638 <basename+0x68>
    2614:	00074603          	lbu	a2,0(a4)
    2618:	feb609e3          	beq	a2,a1,260a <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    261c:	02f00613          	li	a2,47
    2620:	a011                	j	2624 <basename+0x54>
    2622:	cb99                	beqz	a5,2638 <basename+0x68>
    2624:	853e                	mv	a0,a5
    2626:	17fd                	addi	a5,a5,-1
    2628:	00f68733          	add	a4,a3,a5
    262c:	00074703          	lbu	a4,0(a4)
    2630:	fec719e3          	bne	a4,a2,2622 <basename+0x52>
	return s + i;
    2634:	9536                	add	a0,a0,a3
    2636:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2638:	8536                	mv	a0,a3
    263a:	8082                	ret
    263c:	6390                	ld	a2,0(a5)
    263e:	00000517          	auipc	a0,0x0
    2642:	19a53503          	ld	a0,410(a0) # 27d8 <basename+0x208>
    2646:	00000597          	auipc	a1,0x0
    264a:	19a5b583          	ld	a1,410(a1) # 27e0 <basename+0x210>
    264e:	fff64713          	not	a4,a2
    2652:	962a                	add	a2,a2,a0
    2654:	8f71                	and	a4,a4,a2
    2656:	8f6d                	and	a4,a4,a1
    2658:	eb11                	bnez	a4,266c <basename+0x9c>
    265a:	6790                	ld	a2,8(a5)
    265c:	07a1                	addi	a5,a5,8
    265e:	00a60733          	add	a4,a2,a0
    2662:	fff64613          	not	a2,a2
    2666:	8f71                	and	a4,a4,a2
    2668:	8f6d                	and	a4,a4,a1
    266a:	db65                	beqz	a4,265a <basename+0x8a>
	for (; *s; s++)
    266c:	0007c703          	lbu	a4,0(a5)
    2670:	d749                	beqz	a4,25fa <basename+0x2a>
    2672:	0017c703          	lbu	a4,1(a5)
    2676:	0785                	addi	a5,a5,1
    2678:	ff6d                	bnez	a4,2672 <basename+0xa2>
    267a:	b741                	j	25fa <basename+0x2a>
		return ".";
    267c:	00000517          	auipc	a0,0x0
    2680:	15450513          	addi	a0,a0,340 # 27d0 <basename+0x200>
    2684:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2686:	6290                	ld	a2,0(a3)
    2688:	00000517          	auipc	a0,0x0
    268c:	15053503          	ld	a0,336(a0) # 27d8 <basename+0x208>
    2690:	00000597          	auipc	a1,0x0
    2694:	1505b583          	ld	a1,336(a1) # 27e0 <basename+0x210>
    2698:	fff64713          	not	a4,a2
    269c:	962a                	add	a2,a2,a0
    269e:	8f71                	and	a4,a4,a2
    26a0:	8f6d                	and	a4,a4,a1
    26a2:	df45                	beqz	a4,265a <basename+0x8a>
    26a4:	b7f9                	j	2672 <basename+0xa2>
