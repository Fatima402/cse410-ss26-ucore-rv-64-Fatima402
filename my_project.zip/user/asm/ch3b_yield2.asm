
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch3b_yield2:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0ad                	j	106a <__start_main>

0000000000001002 <main>:
/*
理想结果：三个程序交替输出 ABC
*/

int main()
{
    1002:	7139                	addi	sp,sp,-64
    1004:	f426                	sd	s1,40(sp)
	for (int i = 0; i < HEIGHT; ++i) {
		char buf[WIDTH + 1];
		for (int j = 0; j < WIDTH; ++j)
			buf[j] = 'B';
    1006:	6491                	lui	s1,0x4
{
    1008:	f822                	sd	s0,48(sp)
    100a:	f04a                	sd	s2,32(sp)
    100c:	ec4e                	sd	s3,24(sp)
    100e:	e852                	sd	s4,16(sp)
    1010:	fc06                	sd	ra,56(sp)
	for (int i = 0; i < HEIGHT; ++i) {
    1012:	4401                	li	s0,0
    1014:	8a0a                	mv	s4,sp
			buf[j] = 'B';
    1016:	00001997          	auipc	s3,0x1
    101a:	7ca9b983          	ld	s3,1994(s3) # 27e0 <enable_deadlock_detect+0x11c>
    101e:	24248493          	addi	s1,s1,578 # 4242 <.got.plt+0x1902>
		buf[WIDTH] = 0;
		printf("%s [%d/%d]\n", buf, i + 1, HEIGHT);
    1022:	00001917          	auipc	s2,0x1
    1026:	6ae90913          	addi	s2,s2,1710 # 26d0 <enable_deadlock_detect+0xc>
    102a:	2405                	addiw	s0,s0,1
    102c:	4695                	li	a3,5
    102e:	8622                	mv	a2,s0
    1030:	85d2                	mv	a1,s4
    1032:	854a                	mv	a0,s2
			buf[j] = 'B';
    1034:	e04e                	sd	s3,0(sp)
    1036:	00911423          	sh	s1,8(sp)
		buf[WIDTH] = 0;
    103a:	00010523          	sb	zero,10(sp)
		printf("%s [%d/%d]\n", buf, i + 1, HEIGHT);
    103e:	186000ef          	jal	ra,11c4 <printf>
		sched_yield();
    1042:	3cc010ef          	jal	ra,240e <sched_yield>
	for (int i = 0; i < HEIGHT; ++i) {
    1046:	4795                	li	a5,5
    1048:	fef411e3          	bne	s0,a5,102a <main+0x28>
	}
	puts("Test write B OK!");
    104c:	00001517          	auipc	a0,0x1
    1050:	69450513          	addi	a0,a0,1684 # 26e0 <enable_deadlock_detect+0x1c>
    1054:	087000ef          	jal	ra,18da <puts>
	return 0;
    1058:	70e2                	ld	ra,56(sp)
    105a:	7442                	ld	s0,48(sp)
    105c:	74a2                	ld	s1,40(sp)
    105e:	7902                	ld	s2,32(sp)
    1060:	69e2                	ld	s3,24(sp)
    1062:	6a42                	ld	s4,16(sp)
    1064:	4501                	li	a0,0
    1066:	6121                	addi	sp,sp,64
    1068:	8082                	ret

000000000000106a <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    106a:	1141                	addi	sp,sp,-16
    106c:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    106e:	f95ff0ef          	jal	ra,1002 <main>
    1072:	3b4010ef          	jal	ra,2426 <exit>
	return 0;
    1076:	60a2                	ld	ra,8(sp)
    1078:	4501                	li	a0,0
    107a:	0141                	addi	sp,sp,16
    107c:	8082                	ret

000000000000107e <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    107e:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1080:	4605                	li	a2,1
    1082:	00f10593          	addi	a1,sp,15
    1086:	4501                	li	a0,0
{
    1088:	ec06                	sd	ra,24(sp)
	char byte = 0;
    108a:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    108e:	354010ef          	jal	ra,23e2 <read>
    1092:	4785                	li	a5,1
    1094:	00f51763          	bne	a0,a5,10a2 <getchar+0x24>
		return byte;
    1098:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    109c:	60e2                	ld	ra,24(sp)
    109e:	6105                	addi	sp,sp,32
    10a0:	8082                	ret
		return EOF;
    10a2:	557d                	li	a0,-1
    10a4:	bfe5                	j	109c <getchar+0x1e>

00000000000010a6 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10a6:	00001517          	auipc	a0,0x1
    10aa:	75a52503          	lw	a0,1882(a0) # 2800 <buffer_len>
    10ae:	e111                	bnez	a0,10b2 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10b0:	8082                	ret
{
    10b2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10b4:	862a                	mv	a2,a0
    10b6:	00001597          	auipc	a1,0x1
    10ba:	75258593          	addi	a1,a1,1874 # 2808 <buffer>
    10be:	4505                	li	a0,1
{
    10c0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10c2:	32a010ef          	jal	ra,23ec <write>
}
    10c6:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10c8:	2501                	sext.w	a0,a0
}
    10ca:	0141                	addi	sp,sp,16
    10cc:	8082                	ret

00000000000010ce <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10ce:	00001797          	auipc	a5,0x1
    10d2:	7207a923          	sw	zero,1842(a5) # 2800 <buffer_len>
}
    10d6:	8082                	ret

00000000000010d8 <__fflush>:
	if (buffer_len == 0)
    10d8:	00001517          	auipc	a0,0x1
    10dc:	72852503          	lw	a0,1832(a0) # 2800 <buffer_len>
    10e0:	e511                	bnez	a0,10ec <__fflush+0x14>
	buffer_len = 0;
    10e2:	00001797          	auipc	a5,0x1
    10e6:	7007af23          	sw	zero,1822(a5) # 2800 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10ea:	8082                	ret
{
    10ec:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ee:	862a                	mv	a2,a0
    10f0:	00001597          	auipc	a1,0x1
    10f4:	71858593          	addi	a1,a1,1816 # 2808 <buffer>
    10f8:	4505                	li	a0,1
{
    10fa:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10fc:	2f0010ef          	jal	ra,23ec <write>
	return r >= 0 ? 0 : r;
    1100:	0005079b          	sext.w	a5,a0
}
    1104:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1106:	0017a793          	slti	a5,a5,1
    110a:	40f007bb          	negw	a5,a5
    110e:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1110:	00001797          	auipc	a5,0x1
    1114:	6e07a823          	sw	zero,1776(a5) # 2800 <buffer_len>
	return r >= 0 ? 0 : r;
    1118:	2501                	sext.w	a0,a0
}
    111a:	0141                	addi	sp,sp,16
    111c:	8082                	ret

000000000000111e <fflush>:

int fflush(int fd)
{
    111e:	1101                	addi	sp,sp,-32
    1120:	e822                	sd	s0,16(sp)
    1122:	ec06                	sd	ra,24(sp)
    1124:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1126:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1128:	4401                	li	s0,0
	if (fd == 1) {
    112a:	00e50863          	beq	a0,a4,113a <fflush+0x1c>
}
    112e:	60e2                	ld	ra,24(sp)
    1130:	8522                	mv	a0,s0
    1132:	6442                	ld	s0,16(sp)
    1134:	64a2                	ld	s1,8(sp)
    1136:	6105                	addi	sp,sp,32
    1138:	8082                	ret
		if (buffer_lock_enabled == 1) {
    113a:	00001497          	auipc	s1,0x1
    113e:	6c648493          	addi	s1,s1,1734 # 2800 <buffer_len>
    1142:	1084a703          	lw	a4,264(s1)
    1146:	02a70e63          	beq	a4,a0,1182 <fflush+0x64>
	if (buffer_len == 0)
    114a:	4080                	lw	s0,0(s1)
    114c:	c00d                	beqz	s0,116e <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    114e:	8622                	mv	a2,s0
    1150:	00001597          	auipc	a1,0x1
    1154:	6b858593          	addi	a1,a1,1720 # 2808 <buffer>
    1158:	294010ef          	jal	ra,23ec <write>
	return r >= 0 ? 0 : r;
    115c:	0005079b          	sext.w	a5,a0
    1160:	0017a793          	slti	a5,a5,1
    1164:	40f007bb          	negw	a5,a5
    1168:	8d7d                	and	a0,a0,a5
    116a:	0005041b          	sext.w	s0,a0
}
    116e:	60e2                	ld	ra,24(sp)
    1170:	8522                	mv	a0,s0
    1172:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1174:	00001797          	auipc	a5,0x1
    1178:	6807a623          	sw	zero,1676(a5) # 2800 <buffer_len>
}
    117c:	64a2                	ld	s1,8(sp)
    117e:	6105                	addi	sp,sp,32
    1180:	8082                	ret
			mutex_lock(buffer_lock);
    1182:	10c4a503          	lw	a0,268(s1)
    1186:	4de010ef          	jal	ra,2664 <mutex_lock>
	if (buffer_len == 0)
    118a:	4080                	lw	s0,0(s1)
    118c:	e811                	bnez	s0,11a0 <fflush+0x82>
			mutex_unlock(buffer_lock);
    118e:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1192:	00001797          	auipc	a5,0x1
    1196:	6607a723          	sw	zero,1646(a5) # 2800 <buffer_len>
			mutex_unlock(buffer_lock);
    119a:	4d6010ef          	jal	ra,2670 <mutex_unlock>
    119e:	bf41                	j	112e <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11a0:	8622                	mv	a2,s0
    11a2:	00001597          	auipc	a1,0x1
    11a6:	66658593          	addi	a1,a1,1638 # 2808 <buffer>
    11aa:	4505                	li	a0,1
    11ac:	240010ef          	jal	ra,23ec <write>
	return r >= 0 ? 0 : r;
    11b0:	0005079b          	sext.w	a5,a0
    11b4:	0017a793          	slti	a5,a5,1
    11b8:	40f007bb          	negw	a5,a5
    11bc:	8d7d                	and	a0,a0,a5
    11be:	0005041b          	sext.w	s0,a0
	return r;
    11c2:	b7f1                	j	118e <fflush+0x70>

00000000000011c4 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11c4:	7131                	addi	sp,sp,-192
    11c6:	e0da                	sd	s6,64(sp)
    11c8:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11ca:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11cc:	013c                	addi	a5,sp,136
{
    11ce:	f0ca                	sd	s2,96(sp)
    11d0:	ecce                	sd	s3,88(sp)
    11d2:	e8d2                	sd	s4,80(sp)
    11d4:	e4d6                	sd	s5,72(sp)
    11d6:	fc86                	sd	ra,120(sp)
    11d8:	f8a2                	sd	s0,112(sp)
    11da:	f4a6                	sd	s1,104(sp)
    11dc:	89aa                	mv	s3,a0
    11de:	e52e                	sd	a1,136(sp)
    11e0:	e932                	sd	a2,144(sp)
    11e2:	ed36                	sd	a3,152(sp)
    11e4:	f13a                	sd	a4,160(sp)
    11e6:	f942                	sd	a6,176(sp)
    11e8:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11ea:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11ec:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11f0:	00001a17          	auipc	s4,0x1
    11f4:	610a0a13          	addi	s4,s4,1552 # 2800 <buffer_len>
    11f8:	4a85                	li	s5,1
	buf[i++] = '0';
    11fa:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11fe:	0009c783          	lbu	a5,0(s3)
    1202:	18078663          	beqz	a5,138e <printf+0x1ca>
    1206:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1208:	19278d63          	beq	a5,s2,13a2 <printf+0x1de>
    120c:	0015c783          	lbu	a5,1(a1)
    1210:	0585                	addi	a1,a1,1
    1212:	fbfd                	bnez	a5,1208 <printf+0x44>
    1214:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1216:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    121a:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    121e:	1b578863          	beq	a5,s5,13ce <printf+0x20a>
		len = out_unlocked(s, l);
    1222:	85a2                	mv	a1,s0
    1224:	854e                	mv	a0,s3
    1226:	42a000ef          	jal	ra,1650 <out_unlocked>
		out(f, a, l);
		if (l)
    122a:	1c041063          	bnez	s0,13ea <printf+0x226>
			continue;
		if (s[1] == 0)
    122e:	0014c783          	lbu	a5,1(s1)
    1232:	14078e63          	beqz	a5,138e <printf+0x1ca>
			break;
		switch (s[1]) {
    1236:	07300713          	li	a4,115
    123a:	1ce78863          	beq	a5,a4,140a <printf+0x246>
    123e:	1af76863          	bltu	a4,a5,13ee <printf+0x22a>
    1242:	06400713          	li	a4,100
    1246:	22e78063          	beq	a5,a4,1466 <printf+0x2a2>
    124a:	07000713          	li	a4,112
    124e:	1ee79563          	bne	a5,a4,1438 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1252:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1254:	00001797          	auipc	a5,0x1
    1258:	6c478793          	addi	a5,a5,1732 # 2918 <digits>
	buf[i++] = '0';
    125c:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1260:	6298                	ld	a4,0(a3)
    1262:	06a1                	addi	a3,a3,8
    1264:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1266:	00471393          	slli	t2,a4,0x4
    126a:	00871293          	slli	t0,a4,0x8
    126e:	00c71f93          	slli	t6,a4,0xc
    1272:	01071f13          	slli	t5,a4,0x10
    1276:	01471e93          	slli	t4,a4,0x14
    127a:	01871e13          	slli	t3,a4,0x18
    127e:	01c71893          	slli	a7,a4,0x1c
    1282:	02471813          	slli	a6,a4,0x24
    1286:	02871513          	slli	a0,a4,0x28
    128a:	02c71593          	slli	a1,a4,0x2c
    128e:	03071613          	slli	a2,a4,0x30
    1292:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1296:	03c75413          	srli	s0,a4,0x3c
    129a:	01c7531b          	srliw	t1,a4,0x1c
    129e:	03c3d393          	srli	t2,t2,0x3c
    12a2:	03c2d293          	srli	t0,t0,0x3c
    12a6:	03cfdf93          	srli	t6,t6,0x3c
    12aa:	03cf5f13          	srli	t5,t5,0x3c
    12ae:	03cede93          	srli	t4,t4,0x3c
    12b2:	03ce5e13          	srli	t3,t3,0x3c
    12b6:	03c8d893          	srli	a7,a7,0x3c
    12ba:	03c85813          	srli	a6,a6,0x3c
    12be:	9171                	srli	a0,a0,0x3c
    12c0:	91f1                	srli	a1,a1,0x3c
    12c2:	9271                	srli	a2,a2,0x3c
    12c4:	92f1                	srli	a3,a3,0x3c
    12c6:	95be                	add	a1,a1,a5
    12c8:	963e                	add	a2,a2,a5
    12ca:	96be                	add	a3,a3,a5
    12cc:	943e                	add	s0,s0,a5
    12ce:	93be                	add	t2,t2,a5
    12d0:	92be                	add	t0,t0,a5
    12d2:	9fbe                	add	t6,t6,a5
    12d4:	9f3e                	add	t5,t5,a5
    12d6:	9ebe                	add	t4,t4,a5
    12d8:	9e3e                	add	t3,t3,a5
    12da:	98be                	add	a7,a7,a5
    12dc:	933e                	add	t1,t1,a5
    12de:	983e                	add	a6,a6,a5
    12e0:	953e                	add	a0,a0,a5
    12e2:	0005c983          	lbu	s3,0(a1)
    12e6:	00044403          	lbu	s0,0(s0)
    12ea:	00064583          	lbu	a1,0(a2)
    12ee:	0003c383          	lbu	t2,0(t2)
    12f2:	0006c603          	lbu	a2,0(a3)
    12f6:	0002c283          	lbu	t0,0(t0)
    12fa:	000fcf83          	lbu	t6,0(t6)
    12fe:	000f4f03          	lbu	t5,0(t5)
    1302:	000ece83          	lbu	t4,0(t4)
    1306:	000e4e03          	lbu	t3,0(t3)
    130a:	0008c883          	lbu	a7,0(a7)
    130e:	00034303          	lbu	t1,0(t1)
    1312:	00084803          	lbu	a6,0(a6)
    1316:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    131a:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    131e:	92f1                	srli	a3,a3,0x3c
    1320:	8b3d                	andi	a4,a4,15
    1322:	96be                	add	a3,a3,a5
    1324:	97ba                	add	a5,a5,a4
    1326:	00810d23          	sb	s0,26(sp)
    132a:	00710da3          	sb	t2,27(sp)
    132e:	00510e23          	sb	t0,28(sp)
    1332:	01f10ea3          	sb	t6,29(sp)
    1336:	01e10f23          	sb	t5,30(sp)
    133a:	01d10fa3          	sb	t4,31(sp)
    133e:	03c10023          	sb	t3,32(sp)
    1342:	031100a3          	sb	a7,33(sp)
    1346:	02610123          	sb	t1,34(sp)
    134a:	030101a3          	sb	a6,35(sp)
    134e:	02a10223          	sb	a0,36(sp)
    1352:	033102a3          	sb	s3,37(sp)
    1356:	02b10323          	sb	a1,38(sp)
    135a:	02c103a3          	sb	a2,39(sp)
    135e:	0006c683          	lbu	a3,0(a3)
    1362:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1366:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    136a:	02d10423          	sb	a3,40(sp)
    136e:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1372:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1376:	11578263          	beq	a5,s5,147a <printf+0x2b6>
		len = out_unlocked(s, l);
    137a:	45c9                	li	a1,18
    137c:	0828                	addi	a0,sp,24
    137e:	2d2000ef          	jal	ra,1650 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1382:	00248993          	addi	s3,s1,2
		if (!*s)
    1386:	0009c783          	lbu	a5,0(s3)
    138a:	e6079ee3          	bnez	a5,1206 <printf+0x42>
	}
	va_end(ap);
    138e:	70e6                	ld	ra,120(sp)
    1390:	7446                	ld	s0,112(sp)
    1392:	74a6                	ld	s1,104(sp)
    1394:	7906                	ld	s2,96(sp)
    1396:	69e6                	ld	s3,88(sp)
    1398:	6a46                	ld	s4,80(sp)
    139a:	6aa6                	ld	s5,72(sp)
    139c:	6b06                	ld	s6,64(sp)
    139e:	6129                	addi	sp,sp,192
    13a0:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13a2:	0005c783          	lbu	a5,0(a1)
    13a6:	84ae                	mv	s1,a1
    13a8:	01278963          	beq	a5,s2,13ba <printf+0x1f6>
    13ac:	b5ad                	j	1216 <printf+0x52>
    13ae:	0024c783          	lbu	a5,2(s1)
    13b2:	0585                	addi	a1,a1,1
    13b4:	0489                	addi	s1,s1,2
    13b6:	e72790e3          	bne	a5,s2,1216 <printf+0x52>
    13ba:	0014c783          	lbu	a5,1(s1)
    13be:	ff2788e3          	beq	a5,s2,13ae <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13c2:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13c6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13ca:	e5579ce3          	bne	a5,s5,1222 <printf+0x5e>
		mutex_lock(buffer_lock);
    13ce:	10ca2503          	lw	a0,268(s4)
    13d2:	292010ef          	jal	ra,2664 <mutex_lock>
		len = out_unlocked(s, l);
    13d6:	85a2                	mv	a1,s0
    13d8:	854e                	mv	a0,s3
    13da:	276000ef          	jal	ra,1650 <out_unlocked>
		mutex_unlock(buffer_lock);
    13de:	10ca2503          	lw	a0,268(s4)
    13e2:	28e010ef          	jal	ra,2670 <mutex_unlock>
		if (l)
    13e6:	e40404e3          	beqz	s0,122e <printf+0x6a>
    13ea:	89a6                	mv	s3,s1
    13ec:	bd09                	j	11fe <printf+0x3a>
		switch (s[1]) {
    13ee:	07800713          	li	a4,120
    13f2:	04e79363          	bne	a5,a4,1438 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13f6:	67c2                	ld	a5,16(sp)
    13f8:	45c1                	li	a1,16
		s += 2;
    13fa:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13fe:	4388                	lw	a0,0(a5)
    1400:	07a1                	addi	a5,a5,8
    1402:	e83e                	sd	a5,16(sp)
    1404:	5f8000ef          	jal	ra,19fc <printint.constprop.0>
		s += 2;
    1408:	bfbd                	j	1386 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    140a:	67c2                	ld	a5,16(sp)
    140c:	6380                	ld	s0,0(a5)
    140e:	07a1                	addi	a5,a5,8
    1410:	e83e                	sd	a5,16(sp)
    1412:	1c040163          	beqz	s0,15d4 <printf+0x410>
			l = strnlen(a, 200);
    1416:	0c800593          	li	a1,200
    141a:	8522                	mv	a0,s0
    141c:	3f7000ef          	jal	ra,2012 <strnlen>
	if (buffer_lock_enabled == 1) {
    1420:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1424:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1428:	19578663          	beq	a5,s5,15b4 <printf+0x3f0>
		len = out_unlocked(s, l);
    142c:	8522                	mv	a0,s0
    142e:	222000ef          	jal	ra,1650 <out_unlocked>
		s += 2;
    1432:	00248993          	addi	s3,s1,2
    1436:	bf81                	j	1386 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1438:	108a2783          	lw	a5,264(s4)
	char byte = c;
    143c:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1440:	0f578663          	beq	a5,s5,152c <printf+0x368>
		len = out_unlocked(s, l);
    1444:	0828                	addi	a0,sp,24
    1446:	316000ef          	jal	ra,175c <out_unlocked.constprop.0>
			putchar(s[1]);
    144a:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    144e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1452:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1456:	05578163          	beq	a5,s5,1498 <printf+0x2d4>
		len = out_unlocked(s, l);
    145a:	0828                	addi	a0,sp,24
    145c:	300000ef          	jal	ra,175c <out_unlocked.constprop.0>
		s += 2;
    1460:	00248993          	addi	s3,s1,2
    1464:	b70d                	j	1386 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1466:	67c2                	ld	a5,16(sp)
    1468:	45a9                	li	a1,10
		s += 2;
    146a:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    146e:	4388                	lw	a0,0(a5)
    1470:	07a1                	addi	a5,a5,8
    1472:	e83e                	sd	a5,16(sp)
    1474:	588000ef          	jal	ra,19fc <printint.constprop.0>
		s += 2;
    1478:	b739                	j	1386 <printf+0x1c2>
		mutex_lock(buffer_lock);
    147a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    147e:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1482:	1e2010ef          	jal	ra,2664 <mutex_lock>
		len = out_unlocked(s, l);
    1486:	45c9                	li	a1,18
    1488:	0828                	addi	a0,sp,24
    148a:	1c6000ef          	jal	ra,1650 <out_unlocked>
		mutex_unlock(buffer_lock);
    148e:	10ca2503          	lw	a0,268(s4)
    1492:	1de010ef          	jal	ra,2670 <mutex_unlock>
		s += 2;
    1496:	bdc5                	j	1386 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1498:	10ca2503          	lw	a0,268(s4)
    149c:	1c8010ef          	jal	ra,2664 <mutex_lock>
		buffer[buffer_len++] = c;
    14a0:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14a4:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14a8:	0017861b          	addiw	a2,a5,1
    14ac:	97d2                	add	a5,a5,s4
    14ae:	00ca2023          	sw	a2,0(s4)
    14b2:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14b6:	00c6cc63          	blt	a3,a2,14ce <printf+0x30a>
    14ba:	47a9                	li	a5,10
    14bc:	06f40663          	beq	s0,a5,1528 <printf+0x364>
		mutex_unlock(buffer_lock);
    14c0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14c4:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14c8:	1a8010ef          	jal	ra,2670 <mutex_unlock>
		s += 2;
    14cc:	bd6d                	j	1386 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14ce:	10000793          	li	a5,256
    14d2:	00f61e63          	bne	a2,a5,14ee <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14d6:	00001597          	auipc	a1,0x1
    14da:	33258593          	addi	a1,a1,818 # 2808 <buffer>
    14de:	4505                	li	a0,1
    14e0:	70d000ef          	jal	ra,23ec <write>
	buffer_len = 0;
    14e4:	00001797          	auipc	a5,0x1
    14e8:	3007ae23          	sw	zero,796(a5) # 2800 <buffer_len>
			if (r < 0) {
    14ec:	bfd1                	j	14c0 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14ee:	709000ef          	jal	ra,23f6 <getpid>
    14f2:	842a                	mv	s0,a0
    14f4:	00001517          	auipc	a0,0x1
    14f8:	20c50513          	addi	a0,a0,524 # 2700 <enable_deadlock_detect+0x3c>
    14fc:	5d1000ef          	jal	ra,22cc <basename>
    1500:	872a                	mv	a4,a0
    1502:	00001617          	auipc	a2,0x1
    1506:	23e60613          	addi	a2,a2,574 # 2740 <enable_deadlock_detect+0x7c>
    150a:	05400793          	li	a5,84
    150e:	86a2                	mv	a3,s0
    1510:	45fd                	li	a1,31
    1512:	00001517          	auipc	a0,0x1
    1516:	23650513          	addi	a0,a0,566 # 2748 <enable_deadlock_detect+0x84>
    151a:	cabff0ef          	jal	ra,11c4 <printf>
    151e:	557d                	li	a0,-1
    1520:	707000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    1524:	000a2603          	lw	a2,0(s4)
    1528:	de41                	beqz	a2,14c0 <printf+0x2fc>
    152a:	b775                	j	14d6 <printf+0x312>
		mutex_lock(buffer_lock);
    152c:	10ca2503          	lw	a0,268(s4)
    1530:	134010ef          	jal	ra,2664 <mutex_lock>
		buffer[buffer_len++] = c;
    1534:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1538:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    153c:	0017861b          	addiw	a2,a5,1
    1540:	97d2                	add	a5,a5,s4
    1542:	00ca2023          	sw	a2,0(s4)
    1546:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    154a:	02c6d163          	bge	a3,a2,156c <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    154e:	10000793          	li	a5,256
    1552:	02f61263          	bne	a2,a5,1576 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1556:	00001597          	auipc	a1,0x1
    155a:	2b258593          	addi	a1,a1,690 # 2808 <buffer>
    155e:	4505                	li	a0,1
    1560:	68d000ef          	jal	ra,23ec <write>
	buffer_len = 0;
    1564:	00001797          	auipc	a5,0x1
    1568:	2807ae23          	sw	zero,668(a5) # 2800 <buffer_len>
		mutex_unlock(buffer_lock);
    156c:	10ca2503          	lw	a0,268(s4)
    1570:	100010ef          	jal	ra,2670 <mutex_unlock>
    1574:	bdd9                	j	144a <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1576:	681000ef          	jal	ra,23f6 <getpid>
    157a:	842a                	mv	s0,a0
    157c:	00001517          	auipc	a0,0x1
    1580:	18450513          	addi	a0,a0,388 # 2700 <enable_deadlock_detect+0x3c>
    1584:	549000ef          	jal	ra,22cc <basename>
    1588:	872a                	mv	a4,a0
    158a:	00001617          	auipc	a2,0x1
    158e:	1b660613          	addi	a2,a2,438 # 2740 <enable_deadlock_detect+0x7c>
    1592:	05400793          	li	a5,84
    1596:	86a2                	mv	a3,s0
    1598:	45fd                	li	a1,31
    159a:	00001517          	auipc	a0,0x1
    159e:	1ae50513          	addi	a0,a0,430 # 2748 <enable_deadlock_detect+0x84>
    15a2:	c23ff0ef          	jal	ra,11c4 <printf>
    15a6:	557d                	li	a0,-1
    15a8:	67f000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    15ac:	000a2603          	lw	a2,0(s4)
    15b0:	de55                	beqz	a2,156c <printf+0x3a8>
    15b2:	b755                	j	1556 <printf+0x392>
		mutex_lock(buffer_lock);
    15b4:	10ca2503          	lw	a0,268(s4)
    15b8:	e42e                	sd	a1,8(sp)
		s += 2;
    15ba:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15be:	0a6010ef          	jal	ra,2664 <mutex_lock>
		len = out_unlocked(s, l);
    15c2:	65a2                	ld	a1,8(sp)
    15c4:	8522                	mv	a0,s0
    15c6:	08a000ef          	jal	ra,1650 <out_unlocked>
		mutex_unlock(buffer_lock);
    15ca:	10ca2503          	lw	a0,268(s4)
    15ce:	0a2010ef          	jal	ra,2670 <mutex_unlock>
		s += 2;
    15d2:	bb55                	j	1386 <printf+0x1c2>
				a = "(null)";
    15d4:	00001417          	auipc	s0,0x1
    15d8:	12440413          	addi	s0,s0,292 # 26f8 <enable_deadlock_detect+0x34>
    15dc:	bd2d                	j	1416 <printf+0x252>

00000000000015de <enable_thread_io_buffer>:
{
    15de:	1101                	addi	sp,sp,-32
    15e0:	e822                	sd	s0,16(sp)
    15e2:	ec06                	sd	ra,24(sp)
    15e4:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15e6:	00001417          	auipc	s0,0x1
    15ea:	21a40413          	addi	s0,s0,538 # 2800 <buffer_len>
    15ee:	05a010ef          	jal	ra,2648 <mutex_create>
    15f2:	10a42623          	sw	a0,268(s0)
    15f6:	00054a63          	bltz	a0,160a <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15fa:	4785                	li	a5,1
}
    15fc:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15fe:	10f42423          	sw	a5,264(s0)
}
    1602:	6442                	ld	s0,16(sp)
    1604:	64a2                	ld	s1,8(sp)
    1606:	6105                	addi	sp,sp,32
    1608:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    160a:	5ed000ef          	jal	ra,23f6 <getpid>
    160e:	84aa                	mv	s1,a0
    1610:	00001517          	auipc	a0,0x1
    1614:	0f050513          	addi	a0,a0,240 # 2700 <enable_deadlock_detect+0x3c>
    1618:	4b5000ef          	jal	ra,22cc <basename>
    161c:	872a                	mv	a4,a0
    161e:	04800793          	li	a5,72
    1622:	86a6                	mv	a3,s1
    1624:	00001517          	auipc	a0,0x1
    1628:	16450513          	addi	a0,a0,356 # 2788 <enable_deadlock_detect+0xc4>
    162c:	00001617          	auipc	a2,0x1
    1630:	11460613          	addi	a2,a2,276 # 2740 <enable_deadlock_detect+0x7c>
    1634:	45fd                	li	a1,31
    1636:	b8fff0ef          	jal	ra,11c4 <printf>
    163a:	557d                	li	a0,-1
    163c:	5eb000ef          	jal	ra,2426 <exit>
	buffer_lock_enabled = 1;
    1640:	4785                	li	a5,1
}
    1642:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1644:	10f42423          	sw	a5,264(s0)
}
    1648:	6442                	ld	s0,16(sp)
    164a:	64a2                	ld	s1,8(sp)
    164c:	6105                	addi	sp,sp,32
    164e:	8082                	ret

0000000000001650 <out_unlocked>:
{
    1650:	7159                	addi	sp,sp,-112
    1652:	f486                	sd	ra,104(sp)
    1654:	f0a2                	sd	s0,96(sp)
    1656:	eca6                	sd	s1,88(sp)
    1658:	e8ca                	sd	s2,80(sp)
    165a:	e4ce                	sd	s3,72(sp)
    165c:	e0d2                	sd	s4,64(sp)
    165e:	fc56                	sd	s5,56(sp)
    1660:	f85a                	sd	s6,48(sp)
    1662:	f45e                	sd	s7,40(sp)
    1664:	f062                	sd	s8,32(sp)
    1666:	ec66                	sd	s9,24(sp)
    1668:	e86a                	sd	s10,16(sp)
    166a:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    166c:	0e058663          	beqz	a1,1758 <out_unlocked+0x108>
    1670:	842a                	mv	s0,a0
    1672:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1676:	4981                	li	s3,0
    1678:	00001d17          	auipc	s10,0x1
    167c:	188d0d13          	addi	s10,s10,392 # 2800 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1680:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1684:	00001b17          	auipc	s6,0x1
    1688:	184b0b13          	addi	s6,s6,388 # 2808 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    168c:	10000a93          	li	s5,256
    1690:	00001c97          	auipc	s9,0x1
    1694:	070c8c93          	addi	s9,s9,112 # 2700 <enable_deadlock_detect+0x3c>
    1698:	00001c17          	auipc	s8,0x1
    169c:	0a8c0c13          	addi	s8,s8,168 # 2740 <enable_deadlock_detect+0x7c>
    16a0:	00001b97          	auipc	s7,0x1
    16a4:	0a8b8b93          	addi	s7,s7,168 # 2748 <enable_deadlock_detect+0x84>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16a8:	4a29                	li	s4,10
    16aa:	a031                	j	16b6 <out_unlocked+0x66>
    16ac:	09468863          	beq	a3,s4,173c <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16b0:	0405                	addi	s0,s0,1
    16b2:	04848163          	beq	s1,s0,16f4 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16b6:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16ba:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16be:	0017861b          	addiw	a2,a5,1
    16c2:	97ea                	add	a5,a5,s10
    16c4:	00cd2023          	sw	a2,0(s10)
    16c8:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16cc:	fec950e3          	bge	s2,a2,16ac <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16d0:	05561263          	bne	a2,s5,1714 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16d4:	85da                	mv	a1,s6
    16d6:	4505                	li	a0,1
    16d8:	515000ef          	jal	ra,23ec <write>
    16dc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16de:	00001797          	auipc	a5,0x1
    16e2:	1207a123          	sw	zero,290(a5) # 2800 <buffer_len>
			if (r < 0) {
    16e6:	06054763          	bltz	a0,1754 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16ea:	0405                	addi	s0,s0,1
			ret += r;
    16ec:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16f0:	fc8493e3          	bne	s1,s0,16b6 <out_unlocked+0x66>
}
    16f4:	70a6                	ld	ra,104(sp)
    16f6:	7406                	ld	s0,96(sp)
    16f8:	64e6                	ld	s1,88(sp)
    16fa:	6946                	ld	s2,80(sp)
    16fc:	6a06                	ld	s4,64(sp)
    16fe:	7ae2                	ld	s5,56(sp)
    1700:	7b42                	ld	s6,48(sp)
    1702:	7ba2                	ld	s7,40(sp)
    1704:	7c02                	ld	s8,32(sp)
    1706:	6ce2                	ld	s9,24(sp)
    1708:	6d42                	ld	s10,16(sp)
    170a:	6da2                	ld	s11,8(sp)
    170c:	854e                	mv	a0,s3
    170e:	69a6                	ld	s3,72(sp)
    1710:	6165                	addi	sp,sp,112
    1712:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1714:	4e3000ef          	jal	ra,23f6 <getpid>
    1718:	8daa                	mv	s11,a0
    171a:	8566                	mv	a0,s9
    171c:	3b1000ef          	jal	ra,22cc <basename>
    1720:	872a                	mv	a4,a0
    1722:	8662                	mv	a2,s8
    1724:	05400793          	li	a5,84
    1728:	86ee                	mv	a3,s11
    172a:	45fd                	li	a1,31
    172c:	855e                	mv	a0,s7
    172e:	a97ff0ef          	jal	ra,11c4 <printf>
    1732:	557d                	li	a0,-1
    1734:	4f3000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    1738:	000d2603          	lw	a2,0(s10)
    173c:	da35                	beqz	a2,16b0 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    173e:	85da                	mv	a1,s6
    1740:	4505                	li	a0,1
    1742:	4ab000ef          	jal	ra,23ec <write>
    1746:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1748:	00001797          	auipc	a5,0x1
    174c:	0a07ac23          	sw	zero,184(a5) # 2800 <buffer_len>
			if (r < 0) {
    1750:	f8055de3          	bgez	a0,16ea <out_unlocked+0x9a>
    1754:	89aa                	mv	s3,a0
    1756:	bf79                	j	16f4 <out_unlocked+0xa4>
	int ret = 0;
    1758:	4981                	li	s3,0
    175a:	bf69                	j	16f4 <out_unlocked+0xa4>

000000000000175c <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    175c:	1101                	addi	sp,sp,-32
    175e:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1760:	00001497          	auipc	s1,0x1
    1764:	0a048493          	addi	s1,s1,160 # 2800 <buffer_len>
    1768:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    176a:	ec06                	sd	ra,24(sp)
    176c:	e822                	sd	s0,16(sp)
		char c = s[i];
    176e:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1772:	0017861b          	addiw	a2,a5,1
    1776:	97a6                	add	a5,a5,s1
    1778:	00e78423          	sb	a4,8(a5)
    177c:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    177e:	0ff00793          	li	a5,255
    1782:	00c7cc63          	blt	a5,a2,179a <out_unlocked.constprop.0+0x3e>
    1786:	47a9                	li	a5,10
    1788:	06f70c63          	beq	a4,a5,1800 <out_unlocked.constprop.0+0xa4>
    178c:	4601                	li	a2,0
}
    178e:	60e2                	ld	ra,24(sp)
    1790:	6442                	ld	s0,16(sp)
    1792:	64a2                	ld	s1,8(sp)
    1794:	8532                	mv	a0,a2
    1796:	6105                	addi	sp,sp,32
    1798:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    179a:	10000793          	li	a5,256
    179e:	02f61563          	bne	a2,a5,17c8 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17a2:	00001597          	auipc	a1,0x1
    17a6:	06658593          	addi	a1,a1,102 # 2808 <buffer>
    17aa:	4505                	li	a0,1
    17ac:	441000ef          	jal	ra,23ec <write>
}
    17b0:	60e2                	ld	ra,24(sp)
    17b2:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17b4:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17b8:	00001797          	auipc	a5,0x1
    17bc:	0407a423          	sw	zero,72(a5) # 2800 <buffer_len>
}
    17c0:	64a2                	ld	s1,8(sp)
    17c2:	8532                	mv	a0,a2
    17c4:	6105                	addi	sp,sp,32
    17c6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17c8:	42f000ef          	jal	ra,23f6 <getpid>
    17cc:	842a                	mv	s0,a0
    17ce:	00001517          	auipc	a0,0x1
    17d2:	f3250513          	addi	a0,a0,-206 # 2700 <enable_deadlock_detect+0x3c>
    17d6:	2f7000ef          	jal	ra,22cc <basename>
    17da:	872a                	mv	a4,a0
    17dc:	00001617          	auipc	a2,0x1
    17e0:	f6460613          	addi	a2,a2,-156 # 2740 <enable_deadlock_detect+0x7c>
    17e4:	05400793          	li	a5,84
    17e8:	86a2                	mv	a3,s0
    17ea:	45fd                	li	a1,31
    17ec:	00001517          	auipc	a0,0x1
    17f0:	f5c50513          	addi	a0,a0,-164 # 2748 <enable_deadlock_detect+0x84>
    17f4:	9d1ff0ef          	jal	ra,11c4 <printf>
    17f8:	557d                	li	a0,-1
    17fa:	42d000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    17fe:	4090                	lw	a2,0(s1)
    1800:	d659                	beqz	a2,178e <out_unlocked.constprop.0+0x32>
    1802:	b745                	j	17a2 <out_unlocked.constprop.0+0x46>

0000000000001804 <putchar>:
{
    1804:	7139                	addi	sp,sp,-64
    1806:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1808:	00001497          	auipc	s1,0x1
    180c:	ff848493          	addi	s1,s1,-8 # 2800 <buffer_len>
    1810:	1084a703          	lw	a4,264(s1)
{
    1814:	f822                	sd	s0,48(sp)
	char byte = c;
    1816:	0ff57413          	zext.b	s0,a0
{
    181a:	fc06                	sd	ra,56(sp)
	char byte = c;
    181c:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1820:	4785                	li	a5,1
    1822:	00f70d63          	beq	a4,a5,183c <putchar+0x38>
		len = out_unlocked(s, l);
    1826:	01f10513          	addi	a0,sp,31
    182a:	f33ff0ef          	jal	ra,175c <out_unlocked.constprop.0>
}
    182e:	70e2                	ld	ra,56(sp)
    1830:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1832:	862a                	mv	a2,a0
}
    1834:	74a2                	ld	s1,40(sp)
    1836:	8532                	mv	a0,a2
    1838:	6121                	addi	sp,sp,64
    183a:	8082                	ret
		mutex_lock(buffer_lock);
    183c:	10c4a503          	lw	a0,268(s1)
    1840:	625000ef          	jal	ra,2664 <mutex_lock>
		buffer[buffer_len++] = c;
    1844:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1846:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    184a:	0017861b          	addiw	a2,a5,1
    184e:	97a6                	add	a5,a5,s1
    1850:	c090                	sw	a2,0(s1)
    1852:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1856:	02c6c263          	blt	a3,a2,187a <putchar+0x76>
    185a:	47a9                	li	a5,10
    185c:	06f40d63          	beq	s0,a5,18d6 <putchar+0xd2>
    1860:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1862:	10c4a503          	lw	a0,268(s1)
    1866:	e432                	sd	a2,8(sp)
    1868:	609000ef          	jal	ra,2670 <mutex_unlock>
    186c:	6622                	ld	a2,8(sp)
}
    186e:	70e2                	ld	ra,56(sp)
    1870:	7442                	ld	s0,48(sp)
    1872:	74a2                	ld	s1,40(sp)
    1874:	8532                	mv	a0,a2
    1876:	6121                	addi	sp,sp,64
    1878:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    187a:	10000793          	li	a5,256
    187e:	02f61063          	bne	a2,a5,189e <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1882:	00001597          	auipc	a1,0x1
    1886:	f8658593          	addi	a1,a1,-122 # 2808 <buffer>
    188a:	4505                	li	a0,1
    188c:	361000ef          	jal	ra,23ec <write>
    1890:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1894:	00001797          	auipc	a5,0x1
    1898:	f607a623          	sw	zero,-148(a5) # 2800 <buffer_len>
			if (r < 0) {
    189c:	b7d9                	j	1862 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    189e:	359000ef          	jal	ra,23f6 <getpid>
    18a2:	842a                	mv	s0,a0
    18a4:	00001517          	auipc	a0,0x1
    18a8:	e5c50513          	addi	a0,a0,-420 # 2700 <enable_deadlock_detect+0x3c>
    18ac:	221000ef          	jal	ra,22cc <basename>
    18b0:	872a                	mv	a4,a0
    18b2:	00001617          	auipc	a2,0x1
    18b6:	e8e60613          	addi	a2,a2,-370 # 2740 <enable_deadlock_detect+0x7c>
    18ba:	05400793          	li	a5,84
    18be:	86a2                	mv	a3,s0
    18c0:	45fd                	li	a1,31
    18c2:	00001517          	auipc	a0,0x1
    18c6:	e8650513          	addi	a0,a0,-378 # 2748 <enable_deadlock_detect+0x84>
    18ca:	8fbff0ef          	jal	ra,11c4 <printf>
    18ce:	557d                	li	a0,-1
    18d0:	357000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    18d4:	4090                	lw	a2,0(s1)
    18d6:	d651                	beqz	a2,1862 <putchar+0x5e>
    18d8:	b76d                	j	1882 <putchar+0x7e>

00000000000018da <puts>:
{
    18da:	7139                	addi	sp,sp,-64
    18dc:	f822                	sd	s0,48(sp)
    18de:	f426                	sd	s1,40(sp)
    18e0:	fc06                	sd	ra,56(sp)
    18e2:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18e4:	00001417          	auipc	s0,0x1
    18e8:	f1c40413          	addi	s0,s0,-228 # 2800 <buffer_len>
{
    18ec:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ee:	638000ef          	jal	ra,1f26 <strlen>
	if (buffer_lock_enabled == 1) {
    18f2:	10842703          	lw	a4,264(s0)
    18f6:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18f8:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18fa:	04f70563          	beq	a4,a5,1944 <puts+0x6a>
		len = out_unlocked(s, l);
    18fe:	8526                	mv	a0,s1
    1900:	d51ff0ef          	jal	ra,1650 <out_unlocked>
    1904:	892a                	mv	s2,a0
    1906:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1908:	00095963          	bgez	s2,191a <puts+0x40>
}
    190c:	70e2                	ld	ra,56(sp)
    190e:	7442                	ld	s0,48(sp)
    1910:	7902                	ld	s2,32(sp)
    1912:	8526                	mv	a0,s1
    1914:	74a2                	ld	s1,40(sp)
    1916:	6121                	addi	sp,sp,64
    1918:	8082                	ret
	if (buffer_lock_enabled == 1) {
    191a:	10842703          	lw	a4,264(s0)
	char byte = c;
    191e:	44a9                	li	s1,10
    1920:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1924:	4785                	li	a5,1
    1926:	02f70e63          	beq	a4,a5,1962 <puts+0x88>
		len = out_unlocked(s, l);
    192a:	01f10513          	addi	a0,sp,31
    192e:	e2fff0ef          	jal	ra,175c <out_unlocked.constprop.0>
}
    1932:	70e2                	ld	ra,56(sp)
    1934:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1936:	41f5549b          	sraiw	s1,a0,0x1f
}
    193a:	7902                	ld	s2,32(sp)
    193c:	8526                	mv	a0,s1
    193e:	74a2                	ld	s1,40(sp)
    1940:	6121                	addi	sp,sp,64
    1942:	8082                	ret
		mutex_lock(buffer_lock);
    1944:	e42a                	sd	a0,8(sp)
    1946:	10c42503          	lw	a0,268(s0)
    194a:	51b000ef          	jal	ra,2664 <mutex_lock>
		len = out_unlocked(s, l);
    194e:	65a2                	ld	a1,8(sp)
    1950:	8526                	mv	a0,s1
    1952:	cffff0ef          	jal	ra,1650 <out_unlocked>
    1956:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1958:	10c42503          	lw	a0,268(s0)
    195c:	515000ef          	jal	ra,2670 <mutex_unlock>
    1960:	b75d                	j	1906 <puts+0x2c>
		mutex_lock(buffer_lock);
    1962:	10c42503          	lw	a0,268(s0)
    1966:	4ff000ef          	jal	ra,2664 <mutex_lock>
		buffer[buffer_len++] = c;
    196a:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    196c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1970:	0017861b          	addiw	a2,a5,1
    1974:	97a2                	add	a5,a5,s0
    1976:	c010                	sw	a2,0(s0)
    1978:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    197c:	06c6dc63          	bge	a3,a2,19f4 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1980:	10000793          	li	a5,256
    1984:	02f61c63          	bne	a2,a5,19bc <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1988:	00001597          	auipc	a1,0x1
    198c:	e8058593          	addi	a1,a1,-384 # 2808 <buffer>
    1990:	4505                	li	a0,1
    1992:	25b000ef          	jal	ra,23ec <write>
			if (r < 0) {
    1996:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1998:	00001797          	auipc	a5,0x1
    199c:	e607a423          	sw	zero,-408(a5) # 2800 <buffer_len>
			if (r < 0) {
    19a0:	04054c63          	bltz	a0,19f8 <puts+0x11e>
			if (r < buffer_len) {
    19a4:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19a6:	10c42503          	lw	a0,268(s0)
    19aa:	4c7000ef          	jal	ra,2670 <mutex_unlock>
}
    19ae:	70e2                	ld	ra,56(sp)
    19b0:	7442                	ld	s0,48(sp)
    19b2:	7902                	ld	s2,32(sp)
    19b4:	8526                	mv	a0,s1
    19b6:	74a2                	ld	s1,40(sp)
    19b8:	6121                	addi	sp,sp,64
    19ba:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19bc:	23b000ef          	jal	ra,23f6 <getpid>
    19c0:	84aa                	mv	s1,a0
    19c2:	00001517          	auipc	a0,0x1
    19c6:	d3e50513          	addi	a0,a0,-706 # 2700 <enable_deadlock_detect+0x3c>
    19ca:	103000ef          	jal	ra,22cc <basename>
    19ce:	872a                	mv	a4,a0
    19d0:	00001617          	auipc	a2,0x1
    19d4:	d7060613          	addi	a2,a2,-656 # 2740 <enable_deadlock_detect+0x7c>
    19d8:	05400793          	li	a5,84
    19dc:	86a6                	mv	a3,s1
    19de:	45fd                	li	a1,31
    19e0:	00001517          	auipc	a0,0x1
    19e4:	d6850513          	addi	a0,a0,-664 # 2748 <enable_deadlock_detect+0x84>
    19e8:	fdcff0ef          	jal	ra,11c4 <printf>
    19ec:	557d                	li	a0,-1
    19ee:	239000ef          	jal	ra,2426 <exit>
	if (buffer_len == 0)
    19f2:	4010                	lw	a2,0(s0)
    19f4:	da45                	beqz	a2,19a4 <puts+0xca>
    19f6:	bf49                	j	1988 <puts+0xae>
    19f8:	54fd                	li	s1,-1
    19fa:	b775                	j	19a6 <puts+0xcc>

00000000000019fc <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19fc:	715d                	addi	sp,sp,-80
    19fe:	e486                	sd	ra,72(sp)
    1a00:	e0a2                	sd	s0,64(sp)
    1a02:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a04:	14054363          	bltz	a0,1b4a <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a08:	02b577bb          	remuw	a5,a0,a1
    1a0c:	00001617          	auipc	a2,0x1
    1a10:	f0c60613          	addi	a2,a2,-244 # 2918 <digits>
	buf[16] = 0;
    1a14:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a18:	0005871b          	sext.w	a4,a1
    1a1c:	1782                	slli	a5,a5,0x20
    1a1e:	9381                	srli	a5,a5,0x20
    1a20:	97b2                	add	a5,a5,a2
    1a22:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a26:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a2a:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a2e:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a30:	0eb56763          	bltu	a0,a1,1b1e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a34:	02e877bb          	remuw	a5,a6,a4
    1a38:	1782                	slli	a5,a5,0x20
    1a3a:	9381                	srli	a5,a5,0x20
    1a3c:	97b2                	add	a5,a5,a2
    1a3e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a42:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a46:	02f10323          	sb	a5,38(sp)
    1a4a:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a4c:	0ce86963          	bltu	a6,a4,1b1e <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a50:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a54:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a58:	1582                	slli	a1,a1,0x20
    1a5a:	9181                	srli	a1,a1,0x20
    1a5c:	95b2                	add	a1,a1,a2
    1a5e:	0005c583          	lbu	a1,0(a1)
    1a62:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a66:	0007859b          	sext.w	a1,a5
    1a6a:	16e6e563          	bltu	a3,a4,1bd4 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a6e:	02e7f6bb          	remuw	a3,a5,a4
    1a72:	1682                	slli	a3,a3,0x20
    1a74:	9281                	srli	a3,a3,0x20
    1a76:	96b2                	add	a3,a3,a2
    1a78:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a7c:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a80:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a84:	16e5e163          	bltu	a1,a4,1be6 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a88:	02e876bb          	remuw	a3,a6,a4
    1a8c:	1682                	slli	a3,a3,0x20
    1a8e:	9281                	srli	a3,a3,0x20
    1a90:	96b2                	add	a3,a3,a2
    1a92:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a96:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a9a:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a9e:	14e86d63          	bltu	a6,a4,1bf8 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1aa2:	02e5f6bb          	remuw	a3,a1,a4
    1aa6:	1682                	slli	a3,a3,0x20
    1aa8:	9281                	srli	a3,a3,0x20
    1aaa:	96b2                	add	a3,a3,a2
    1aac:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab0:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ab4:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ab8:	10e5e563          	bltu	a1,a4,1bc2 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1abc:	02e876bb          	remuw	a3,a6,a4
    1ac0:	1682                	slli	a3,a3,0x20
    1ac2:	9281                	srli	a3,a3,0x20
    1ac4:	96b2                	add	a3,a3,a2
    1ac6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aca:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ace:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ad2:	14e86263          	bltu	a6,a4,1c16 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1ad6:	02e5f6bb          	remuw	a3,a1,a4
    1ada:	1682                	slli	a3,a3,0x20
    1adc:	9281                	srli	a3,a3,0x20
    1ade:	96b2                	add	a3,a3,a2
    1ae0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae4:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ae8:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1aec:	14e5e463          	bltu	a1,a4,1c34 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1af0:	02e876bb          	remuw	a3,a6,a4
    1af4:	1682                	slli	a3,a3,0x20
    1af6:	9281                	srli	a3,a3,0x20
    1af8:	96b2                	add	a3,a3,a2
    1afa:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1afe:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b02:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b06:	14e86063          	bltu	a6,a4,1c46 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b0a:	1782                	slli	a5,a5,0x20
    1b0c:	9381                	srli	a5,a5,0x20
    1b0e:	97b2                	add	a5,a5,a2
    1b10:	0007c703          	lbu	a4,0(a5)
    1b14:	4799                	li	a5,6
    1b16:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b1a:	10054763          	bltz	a0,1c28 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b1e:	00001497          	auipc	s1,0x1
    1b22:	ce248493          	addi	s1,s1,-798 # 2800 <buffer_len>
    1b26:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b2a:	0828                	addi	a0,sp,24
    1b2c:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b2e:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b30:	00f50433          	add	s0,a0,a5
    1b34:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b36:	06e68463          	beq	a3,a4,1b9e <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b3a:	8522                	mv	a0,s0
    1b3c:	b15ff0ef          	jal	ra,1650 <out_unlocked>
}
    1b40:	60a6                	ld	ra,72(sp)
    1b42:	6406                	ld	s0,64(sp)
    1b44:	74e2                	ld	s1,56(sp)
    1b46:	6161                	addi	sp,sp,80
    1b48:	8082                	ret
		x = -xx;
    1b4a:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b4e:	02b877bb          	remuw	a5,a6,a1
    1b52:	00001617          	auipc	a2,0x1
    1b56:	dc660613          	addi	a2,a2,-570 # 2918 <digits>
	buf[16] = 0;
    1b5a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b5e:	0005871b          	sext.w	a4,a1
    1b62:	1782                	slli	a5,a5,0x20
    1b64:	9381                	srli	a5,a5,0x20
    1b66:	97b2                	add	a5,a5,a2
    1b68:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b6c:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b70:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b74:	08b86b63          	bltu	a6,a1,1c0a <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b78:	02e8f7bb          	remuw	a5,a7,a4
    1b7c:	1782                	slli	a5,a5,0x20
    1b7e:	9381                	srli	a5,a5,0x20
    1b80:	97b2                	add	a5,a5,a2
    1b82:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b86:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b8a:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b8e:	ece8f1e3          	bgeu	a7,a4,1a50 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b92:	02d00793          	li	a5,45
    1b96:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b9a:	47b5                	li	a5,13
    1b9c:	b749                	j	1b1e <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b9e:	10c4a503          	lw	a0,268(s1)
    1ba2:	e42e                	sd	a1,8(sp)
    1ba4:	2c1000ef          	jal	ra,2664 <mutex_lock>
		len = out_unlocked(s, l);
    1ba8:	65a2                	ld	a1,8(sp)
    1baa:	8522                	mv	a0,s0
    1bac:	aa5ff0ef          	jal	ra,1650 <out_unlocked>
		mutex_unlock(buffer_lock);
    1bb0:	10c4a503          	lw	a0,268(s1)
    1bb4:	2bd000ef          	jal	ra,2670 <mutex_unlock>
}
    1bb8:	60a6                	ld	ra,72(sp)
    1bba:	6406                	ld	s0,64(sp)
    1bbc:	74e2                	ld	s1,56(sp)
    1bbe:	6161                	addi	sp,sp,80
    1bc0:	8082                	ret
		buf[i--] = digits[x % base];
    1bc2:	47a9                	li	a5,10
	if (sign)
    1bc4:	f4055de3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bc8:	02d00793          	li	a5,45
    1bcc:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bd0:	47a5                	li	a5,9
    1bd2:	b7b1                	j	1b1e <printint.constprop.0+0x122>
    1bd4:	47b5                	li	a5,13
	if (sign)
    1bd6:	f40554e3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bda:	02d00793          	li	a5,45
    1bde:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1be2:	47b1                	li	a5,12
    1be4:	bf2d                	j	1b1e <printint.constprop.0+0x122>
    1be6:	47b1                	li	a5,12
	if (sign)
    1be8:	f2055be3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bec:	02d00793          	li	a5,45
    1bf0:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bf4:	47ad                	li	a5,11
    1bf6:	b725                	j	1b1e <printint.constprop.0+0x122>
    1bf8:	47ad                	li	a5,11
	if (sign)
    1bfa:	f20552e3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bfe:	02d00793          	li	a5,45
    1c02:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c06:	47a9                	li	a5,10
    1c08:	bf19                	j	1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0a:	02d00793          	li	a5,45
    1c0e:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c12:	47b9                	li	a5,14
    1c14:	b729                	j	1b1e <printint.constprop.0+0x122>
    1c16:	47a5                	li	a5,9
	if (sign)
    1c18:	f00553e3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1c:	02d00793          	li	a5,45
    1c20:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c24:	47a1                	li	a5,8
    1c26:	bde5                	j	1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c28:	02d00793          	li	a5,45
    1c2c:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c30:	4795                	li	a5,5
    1c32:	b5f5                	j	1b1e <printint.constprop.0+0x122>
    1c34:	47a1                	li	a5,8
	if (sign)
    1c36:	ee0554e3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c3a:	02d00793          	li	a5,45
    1c3e:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c42:	479d                	li	a5,7
    1c44:	bde9                	j	1b1e <printint.constprop.0+0x122>
    1c46:	479d                	li	a5,7
	if (sign)
    1c48:	ec055be3          	bgez	a0,1b1e <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c4c:	02d00793          	li	a5,45
    1c50:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c54:	4799                	li	a5,6
    1c56:	b5e1                	j	1b1e <printint.constprop.0+0x122>

0000000000001c58 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c58:	02000793          	li	a5,32
    1c5c:	00f50663          	beq	a0,a5,1c68 <isspace+0x10>
    1c60:	355d                	addiw	a0,a0,-9
    1c62:	00553513          	sltiu	a0,a0,5
    1c66:	8082                	ret
    1c68:	4505                	li	a0,1
}
    1c6a:	8082                	ret

0000000000001c6c <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c6c:	fd05051b          	addiw	a0,a0,-48
}
    1c70:	00a53513          	sltiu	a0,a0,10
    1c74:	8082                	ret

0000000000001c76 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c76:	02000613          	li	a2,32
    1c7a:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c7c:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c80:	ff77869b          	addiw	a3,a5,-9
    1c84:	04c78c63          	beq	a5,a2,1cdc <atoi+0x66>
    1c88:	0007871b          	sext.w	a4,a5
    1c8c:	04d5f863          	bgeu	a1,a3,1cdc <atoi+0x66>
		s++;
	switch (*s) {
    1c90:	02b00693          	li	a3,43
    1c94:	04d78963          	beq	a5,a3,1ce6 <atoi+0x70>
    1c98:	02d00693          	li	a3,45
    1c9c:	06d78263          	beq	a5,a3,1d00 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1ca0:	fd07061b          	addiw	a2,a4,-48
    1ca4:	47a5                	li	a5,9
    1ca6:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1ca8:	4e01                	li	t3,0
	while (isdigit(*s))
    1caa:	04c7e963          	bltu	a5,a2,1cfc <atoi+0x86>
	int n = 0, neg = 0;
    1cae:	4501                	li	a0,0
	while (isdigit(*s))
    1cb0:	4825                	li	a6,9
    1cb2:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cb6:	0025179b          	slliw	a5,a0,0x2
    1cba:	9fa9                	addw	a5,a5,a0
    1cbc:	fd07031b          	addiw	t1,a4,-48
    1cc0:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1cc4:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1cc8:	0685                	addi	a3,a3,1
    1cca:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cce:	0006071b          	sext.w	a4,a2
    1cd2:	feb870e3          	bgeu	a6,a1,1cb2 <atoi+0x3c>
	return neg ? n : -n;
    1cd6:	000e0563          	beqz	t3,1ce0 <atoi+0x6a>
}
    1cda:	8082                	ret
		s++;
    1cdc:	0505                	addi	a0,a0,1
    1cde:	bf79                	j	1c7c <atoi+0x6>
	return neg ? n : -n;
    1ce0:	4113053b          	subw	a0,t1,a7
    1ce4:	8082                	ret
	while (isdigit(*s))
    1ce6:	00154703          	lbu	a4,1(a0)
    1cea:	47a5                	li	a5,9
		s++;
    1cec:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cf0:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cf4:	4e01                	li	t3,0
	while (isdigit(*s))
    1cf6:	2701                	sext.w	a4,a4
    1cf8:	fac7fbe3          	bgeu	a5,a2,1cae <atoi+0x38>
    1cfc:	4501                	li	a0,0
}
    1cfe:	8082                	ret
	while (isdigit(*s))
    1d00:	00154703          	lbu	a4,1(a0)
    1d04:	47a5                	li	a5,9
		s++;
    1d06:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d0a:	fd07061b          	addiw	a2,a4,-48
    1d0e:	2701                	sext.w	a4,a4
    1d10:	fec7e6e3          	bltu	a5,a2,1cfc <atoi+0x86>
		neg = 1;
    1d14:	4e05                	li	t3,1
    1d16:	bf61                	j	1cae <atoi+0x38>

0000000000001d18 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d18:	16060d63          	beqz	a2,1e92 <memset+0x17a>
    1d1c:	40a007b3          	neg	a5,a0
    1d20:	8b9d                	andi	a5,a5,7
    1d22:	00778693          	addi	a3,a5,7
    1d26:	482d                	li	a6,11
    1d28:	0ff5f713          	zext.b	a4,a1
    1d2c:	fff60593          	addi	a1,a2,-1
    1d30:	1706e263          	bltu	a3,a6,1e94 <memset+0x17c>
    1d34:	16d5ea63          	bltu	a1,a3,1ea8 <memset+0x190>
    1d38:	16078563          	beqz	a5,1ea2 <memset+0x18a>
    1d3c:	00e50023          	sb	a4,0(a0)
    1d40:	4685                	li	a3,1
    1d42:	00150593          	addi	a1,a0,1
    1d46:	14d78c63          	beq	a5,a3,1e9e <memset+0x186>
    1d4a:	00e500a3          	sb	a4,1(a0)
    1d4e:	4689                	li	a3,2
    1d50:	00250593          	addi	a1,a0,2
    1d54:	14d78d63          	beq	a5,a3,1eae <memset+0x196>
    1d58:	00e50123          	sb	a4,2(a0)
    1d5c:	468d                	li	a3,3
    1d5e:	00350593          	addi	a1,a0,3
    1d62:	12d78b63          	beq	a5,a3,1e98 <memset+0x180>
    1d66:	00e501a3          	sb	a4,3(a0)
    1d6a:	4691                	li	a3,4
    1d6c:	00450593          	addi	a1,a0,4
    1d70:	14d78163          	beq	a5,a3,1eb2 <memset+0x19a>
    1d74:	00e50223          	sb	a4,4(a0)
    1d78:	4695                	li	a3,5
    1d7a:	00550593          	addi	a1,a0,5
    1d7e:	12d78c63          	beq	a5,a3,1eb6 <memset+0x19e>
    1d82:	00e502a3          	sb	a4,5(a0)
    1d86:	469d                	li	a3,7
    1d88:	00650593          	addi	a1,a0,6
    1d8c:	12d79763          	bne	a5,a3,1eba <memset+0x1a2>
    1d90:	00750593          	addi	a1,a0,7
    1d94:	00e50323          	sb	a4,6(a0)
    1d98:	481d                	li	a6,7
    1d9a:	00871693          	slli	a3,a4,0x8
    1d9e:	01071893          	slli	a7,a4,0x10
    1da2:	8ed9                	or	a3,a3,a4
    1da4:	01871313          	slli	t1,a4,0x18
    1da8:	0116e6b3          	or	a3,a3,a7
    1dac:	0066e6b3          	or	a3,a3,t1
    1db0:	02071893          	slli	a7,a4,0x20
    1db4:	02871e13          	slli	t3,a4,0x28
    1db8:	0116e6b3          	or	a3,a3,a7
    1dbc:	40f60333          	sub	t1,a2,a5
    1dc0:	03071893          	slli	a7,a4,0x30
    1dc4:	01c6e6b3          	or	a3,a3,t3
    1dc8:	0116e6b3          	or	a3,a3,a7
    1dcc:	03871e13          	slli	t3,a4,0x38
    1dd0:	97aa                	add	a5,a5,a0
    1dd2:	ff837893          	andi	a7,t1,-8
    1dd6:	01c6e6b3          	or	a3,a3,t3
    1dda:	98be                	add	a7,a7,a5
    1ddc:	e394                	sd	a3,0(a5)
    1dde:	07a1                	addi	a5,a5,8
    1de0:	ff179ee3          	bne	a5,a7,1ddc <memset+0xc4>
    1de4:	ff837893          	andi	a7,t1,-8
    1de8:	011587b3          	add	a5,a1,a7
    1dec:	010886bb          	addw	a3,a7,a6
    1df0:	0b130663          	beq	t1,a7,1e9c <memset+0x184>
    1df4:	00e78023          	sb	a4,0(a5)
    1df8:	0016859b          	addiw	a1,a3,1
    1dfc:	08c5fb63          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e00:	00e780a3          	sb	a4,1(a5)
    1e04:	0026859b          	addiw	a1,a3,2
    1e08:	08c5f563          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e0c:	00e78123          	sb	a4,2(a5)
    1e10:	0036859b          	addiw	a1,a3,3
    1e14:	06c5ff63          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e18:	00e781a3          	sb	a4,3(a5)
    1e1c:	0046859b          	addiw	a1,a3,4
    1e20:	06c5f963          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e24:	00e78223          	sb	a4,4(a5)
    1e28:	0056859b          	addiw	a1,a3,5
    1e2c:	06c5f363          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e30:	00e782a3          	sb	a4,5(a5)
    1e34:	0066859b          	addiw	a1,a3,6
    1e38:	04c5fd63          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e3c:	00e78323          	sb	a4,6(a5)
    1e40:	0076859b          	addiw	a1,a3,7
    1e44:	04c5f763          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e48:	00e783a3          	sb	a4,7(a5)
    1e4c:	0086859b          	addiw	a1,a3,8
    1e50:	04c5f163          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e54:	00e78423          	sb	a4,8(a5)
    1e58:	0096859b          	addiw	a1,a3,9
    1e5c:	02c5fb63          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e60:	00e784a3          	sb	a4,9(a5)
    1e64:	00a6859b          	addiw	a1,a3,10
    1e68:	02c5f563          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e6c:	00e78523          	sb	a4,10(a5)
    1e70:	00b6859b          	addiw	a1,a3,11
    1e74:	00c5ff63          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e78:	00e785a3          	sb	a4,11(a5)
    1e7c:	00c6859b          	addiw	a1,a3,12
    1e80:	00c5f963          	bgeu	a1,a2,1e92 <memset+0x17a>
    1e84:	00e78623          	sb	a4,12(a5)
    1e88:	26b5                	addiw	a3,a3,13
    1e8a:	00c6f463          	bgeu	a3,a2,1e92 <memset+0x17a>
    1e8e:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e92:	8082                	ret
    1e94:	46ad                	li	a3,11
    1e96:	bd79                	j	1d34 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e98:	480d                	li	a6,3
    1e9a:	b701                	j	1d9a <memset+0x82>
    1e9c:	8082                	ret
    1e9e:	4805                	li	a6,1
    1ea0:	bded                	j	1d9a <memset+0x82>
    1ea2:	85aa                	mv	a1,a0
    1ea4:	4801                	li	a6,0
    1ea6:	bdd5                	j	1d9a <memset+0x82>
    1ea8:	87aa                	mv	a5,a0
    1eaa:	4681                	li	a3,0
    1eac:	b7a1                	j	1df4 <memset+0xdc>
    1eae:	4809                	li	a6,2
    1eb0:	b5ed                	j	1d9a <memset+0x82>
    1eb2:	4811                	li	a6,4
    1eb4:	b5dd                	j	1d9a <memset+0x82>
    1eb6:	4815                	li	a6,5
    1eb8:	b5cd                	j	1d9a <memset+0x82>
    1eba:	4819                	li	a6,6
    1ebc:	bdf9                	j	1d9a <memset+0x82>

0000000000001ebe <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ebe:	00054783          	lbu	a5,0(a0)
    1ec2:	0005c703          	lbu	a4,0(a1)
    1ec6:	00e79863          	bne	a5,a4,1ed6 <strcmp+0x18>
    1eca:	0505                	addi	a0,a0,1
    1ecc:	0585                	addi	a1,a1,1
    1ece:	fbe5                	bnez	a5,1ebe <strcmp>
    1ed0:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1ed2:	9d19                	subw	a0,a0,a4
    1ed4:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1ed6:	0007851b          	sext.w	a0,a5
    1eda:	bfe5                	j	1ed2 <strcmp+0x14>

0000000000001edc <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1edc:	ca15                	beqz	a2,1f10 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ede:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ee2:	167d                	addi	a2,a2,-1
    1ee4:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ee8:	eb99                	bnez	a5,1efe <strncmp+0x22>
    1eea:	a815                	j	1f1e <strncmp+0x42>
    1eec:	00a68e63          	beq	a3,a0,1f08 <strncmp+0x2c>
    1ef0:	0505                	addi	a0,a0,1
    1ef2:	00f71b63          	bne	a4,a5,1f08 <strncmp+0x2c>
    1ef6:	00054783          	lbu	a5,0(a0)
    1efa:	cf89                	beqz	a5,1f14 <strncmp+0x38>
    1efc:	85b2                	mv	a1,a2
    1efe:	0005c703          	lbu	a4,0(a1)
    1f02:	00158613          	addi	a2,a1,1
    1f06:	f37d                	bnez	a4,1eec <strncmp+0x10>
		;
	return *l - *r;
    1f08:	0007851b          	sext.w	a0,a5
    1f0c:	9d19                	subw	a0,a0,a4
    1f0e:	8082                	ret
		return 0;
    1f10:	4501                	li	a0,0
}
    1f12:	8082                	ret
	return *l - *r;
    1f14:	0015c703          	lbu	a4,1(a1)
    1f18:	4501                	li	a0,0
    1f1a:	9d19                	subw	a0,a0,a4
    1f1c:	8082                	ret
    1f1e:	0005c703          	lbu	a4,0(a1)
    1f22:	4501                	li	a0,0
    1f24:	b7e5                	j	1f0c <strncmp+0x30>

0000000000001f26 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f26:	00757793          	andi	a5,a0,7
    1f2a:	cf89                	beqz	a5,1f44 <strlen+0x1e>
    1f2c:	87aa                	mv	a5,a0
    1f2e:	a029                	j	1f38 <strlen+0x12>
    1f30:	0785                	addi	a5,a5,1
    1f32:	0077f713          	andi	a4,a5,7
    1f36:	cb01                	beqz	a4,1f46 <strlen+0x20>
		if (!*s)
    1f38:	0007c703          	lbu	a4,0(a5)
    1f3c:	fb75                	bnez	a4,1f30 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f3e:	40a78533          	sub	a0,a5,a0
}
    1f42:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f44:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f46:	6394                	ld	a3,0(a5)
    1f48:	00001597          	auipc	a1,0x1
    1f4c:	8a05b583          	ld	a1,-1888(a1) # 27e8 <enable_deadlock_detect+0x124>
    1f50:	00001617          	auipc	a2,0x1
    1f54:	8a063603          	ld	a2,-1888(a2) # 27f0 <enable_deadlock_detect+0x12c>
    1f58:	a019                	j	1f5e <strlen+0x38>
    1f5a:	6794                	ld	a3,8(a5)
    1f5c:	07a1                	addi	a5,a5,8
    1f5e:	00b68733          	add	a4,a3,a1
    1f62:	fff6c693          	not	a3,a3
    1f66:	8f75                	and	a4,a4,a3
    1f68:	8f71                	and	a4,a4,a2
    1f6a:	db65                	beqz	a4,1f5a <strlen+0x34>
	for (; *s; s++)
    1f6c:	0007c703          	lbu	a4,0(a5)
    1f70:	d779                	beqz	a4,1f3e <strlen+0x18>
    1f72:	0017c703          	lbu	a4,1(a5)
    1f76:	0785                	addi	a5,a5,1
    1f78:	d379                	beqz	a4,1f3e <strlen+0x18>
    1f7a:	0017c703          	lbu	a4,1(a5)
    1f7e:	0785                	addi	a5,a5,1
    1f80:	fb6d                	bnez	a4,1f72 <strlen+0x4c>
    1f82:	bf75                	j	1f3e <strlen+0x18>

0000000000001f84 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f84:	00757713          	andi	a4,a0,7
{
    1f88:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f8a:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f8e:	cb19                	beqz	a4,1fa4 <memchr+0x20>
    1f90:	ce25                	beqz	a2,2008 <memchr+0x84>
    1f92:	0007c703          	lbu	a4,0(a5)
    1f96:	04b70e63          	beq	a4,a1,1ff2 <memchr+0x6e>
    1f9a:	0785                	addi	a5,a5,1
    1f9c:	0077f713          	andi	a4,a5,7
    1fa0:	167d                	addi	a2,a2,-1
    1fa2:	f77d                	bnez	a4,1f90 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1fa4:	4501                	li	a0,0
	if (n && *s != c) {
    1fa6:	c235                	beqz	a2,200a <memchr+0x86>
    1fa8:	0007c703          	lbu	a4,0(a5)
    1fac:	04b70363          	beq	a4,a1,1ff2 <memchr+0x6e>
		size_t k = ONES * c;
    1fb0:	00001517          	auipc	a0,0x1
    1fb4:	84853503          	ld	a0,-1976(a0) # 27f8 <enable_deadlock_detect+0x134>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fb8:	471d                	li	a4,7
		size_t k = ONES * c;
    1fba:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fbe:	02c77a63          	bgeu	a4,a2,1ff2 <memchr+0x6e>
    1fc2:	00001897          	auipc	a7,0x1
    1fc6:	8268b883          	ld	a7,-2010(a7) # 27e8 <enable_deadlock_detect+0x124>
    1fca:	00001817          	auipc	a6,0x1
    1fce:	82683803          	ld	a6,-2010(a6) # 27f0 <enable_deadlock_detect+0x12c>
    1fd2:	431d                	li	t1,7
    1fd4:	a029                	j	1fde <memchr+0x5a>
		     w++, n -= SS)
    1fd6:	1661                	addi	a2,a2,-8
    1fd8:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fda:	02c37963          	bgeu	t1,a2,200c <memchr+0x88>
    1fde:	6398                	ld	a4,0(a5)
    1fe0:	8f29                	xor	a4,a4,a0
    1fe2:	011706b3          	add	a3,a4,a7
    1fe6:	fff74713          	not	a4,a4
    1fea:	8f75                	and	a4,a4,a3
    1fec:	01077733          	and	a4,a4,a6
    1ff0:	d37d                	beqz	a4,1fd6 <memchr+0x52>
{
    1ff2:	853e                	mv	a0,a5
    1ff4:	97b2                	add	a5,a5,a2
    1ff6:	a021                	j	1ffe <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1ff8:	0505                	addi	a0,a0,1
    1ffa:	00f50763          	beq	a0,a5,2008 <memchr+0x84>
    1ffe:	00054703          	lbu	a4,0(a0)
    2002:	feb71be3          	bne	a4,a1,1ff8 <memchr+0x74>
    2006:	8082                	ret
	return n ? (void *)s : 0;
    2008:	4501                	li	a0,0
}
    200a:	8082                	ret
	return n ? (void *)s : 0;
    200c:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    200e:	f275                	bnez	a2,1ff2 <memchr+0x6e>
}
    2010:	8082                	ret

0000000000002012 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2012:	1101                	addi	sp,sp,-32
    2014:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2016:	862e                	mv	a2,a1
{
    2018:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    201a:	4581                	li	a1,0
{
    201c:	e426                	sd	s1,8(sp)
    201e:	ec06                	sd	ra,24(sp)
    2020:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2022:	f63ff0ef          	jal	ra,1f84 <memchr>
	return p ? p - s : n;
    2026:	c519                	beqz	a0,2034 <strnlen+0x22>
}
    2028:	60e2                	ld	ra,24(sp)
    202a:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    202c:	8d05                	sub	a0,a0,s1
}
    202e:	64a2                	ld	s1,8(sp)
    2030:	6105                	addi	sp,sp,32
    2032:	8082                	ret
    2034:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2036:	8522                	mv	a0,s0
}
    2038:	6442                	ld	s0,16(sp)
    203a:	64a2                	ld	s1,8(sp)
    203c:	6105                	addi	sp,sp,32
    203e:	8082                	ret

0000000000002040 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2040:	00a5c7b3          	xor	a5,a1,a0
    2044:	8b9d                	andi	a5,a5,7
    2046:	eb95                	bnez	a5,207a <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2048:	0075f793          	andi	a5,a1,7
    204c:	e7b1                	bnez	a5,2098 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    204e:	6198                	ld	a4,0(a1)
    2050:	00000617          	auipc	a2,0x0
    2054:	79863603          	ld	a2,1944(a2) # 27e8 <enable_deadlock_detect+0x124>
    2058:	00000817          	auipc	a6,0x0
    205c:	79883803          	ld	a6,1944(a6) # 27f0 <enable_deadlock_detect+0x12c>
    2060:	a029                	j	206a <stpcpy+0x2a>
    2062:	05a1                	addi	a1,a1,8
    2064:	e118                	sd	a4,0(a0)
    2066:	6198                	ld	a4,0(a1)
    2068:	0521                	addi	a0,a0,8
    206a:	00c707b3          	add	a5,a4,a2
    206e:	fff74693          	not	a3,a4
    2072:	8ff5                	and	a5,a5,a3
    2074:	0107f7b3          	and	a5,a5,a6
    2078:	d7ed                	beqz	a5,2062 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    207a:	0005c783          	lbu	a5,0(a1)
    207e:	00f50023          	sb	a5,0(a0)
    2082:	c785                	beqz	a5,20aa <stpcpy+0x6a>
    2084:	0015c783          	lbu	a5,1(a1)
    2088:	0505                	addi	a0,a0,1
    208a:	0585                	addi	a1,a1,1
    208c:	00f50023          	sb	a5,0(a0)
    2090:	fbf5                	bnez	a5,2084 <stpcpy+0x44>
		;
	return d;
}
    2092:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2094:	0505                	addi	a0,a0,1
    2096:	df45                	beqz	a4,204e <stpcpy+0xe>
			if (!(*d = *s))
    2098:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    209c:	0585                	addi	a1,a1,1
    209e:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20a2:	00f50023          	sb	a5,0(a0)
    20a6:	f7fd                	bnez	a5,2094 <stpcpy+0x54>
}
    20a8:	8082                	ret
    20aa:	8082                	ret

00000000000020ac <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20ac:	00a5c7b3          	xor	a5,a1,a0
    20b0:	8b9d                	andi	a5,a5,7
    20b2:	1a079863          	bnez	a5,2262 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20b6:	0075f793          	andi	a5,a1,7
    20ba:	16078463          	beqz	a5,2222 <stpncpy+0x176>
    20be:	ea01                	bnez	a2,20ce <stpncpy+0x22>
    20c0:	a421                	j	22c8 <stpncpy+0x21c>
    20c2:	167d                	addi	a2,a2,-1
    20c4:	0505                	addi	a0,a0,1
    20c6:	14070e63          	beqz	a4,2222 <stpncpy+0x176>
    20ca:	1a060863          	beqz	a2,227a <stpncpy+0x1ce>
    20ce:	0005c783          	lbu	a5,0(a1)
    20d2:	0585                	addi	a1,a1,1
    20d4:	0075f713          	andi	a4,a1,7
    20d8:	00f50023          	sb	a5,0(a0)
    20dc:	f3fd                	bnez	a5,20c2 <stpncpy+0x16>
    20de:	4805                	li	a6,1
    20e0:	1a061863          	bnez	a2,2290 <stpncpy+0x1e4>
    20e4:	40a007b3          	neg	a5,a0
    20e8:	8b9d                	andi	a5,a5,7
    20ea:	4681                	li	a3,0
    20ec:	18061a63          	bnez	a2,2280 <stpncpy+0x1d4>
    20f0:	00778713          	addi	a4,a5,7
    20f4:	45ad                	li	a1,11
    20f6:	18b76363          	bltu	a4,a1,227c <stpncpy+0x1d0>
    20fa:	1ae6eb63          	bltu	a3,a4,22b0 <stpncpy+0x204>
    20fe:	1a078363          	beqz	a5,22a4 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2102:	00050023          	sb	zero,0(a0)
    2106:	4685                	li	a3,1
    2108:	00150713          	addi	a4,a0,1
    210c:	18d78f63          	beq	a5,a3,22aa <stpncpy+0x1fe>
    2110:	000500a3          	sb	zero,1(a0)
    2114:	4689                	li	a3,2
    2116:	00250713          	addi	a4,a0,2
    211a:	18d78e63          	beq	a5,a3,22b6 <stpncpy+0x20a>
    211e:	00050123          	sb	zero,2(a0)
    2122:	468d                	li	a3,3
    2124:	00350713          	addi	a4,a0,3
    2128:	16d78c63          	beq	a5,a3,22a0 <stpncpy+0x1f4>
    212c:	000501a3          	sb	zero,3(a0)
    2130:	4691                	li	a3,4
    2132:	00450713          	addi	a4,a0,4
    2136:	18d78263          	beq	a5,a3,22ba <stpncpy+0x20e>
    213a:	00050223          	sb	zero,4(a0)
    213e:	4695                	li	a3,5
    2140:	00550713          	addi	a4,a0,5
    2144:	16d78d63          	beq	a5,a3,22be <stpncpy+0x212>
    2148:	000502a3          	sb	zero,5(a0)
    214c:	469d                	li	a3,7
    214e:	00650713          	addi	a4,a0,6
    2152:	16d79863          	bne	a5,a3,22c2 <stpncpy+0x216>
    2156:	00750713          	addi	a4,a0,7
    215a:	00050323          	sb	zero,6(a0)
    215e:	40f80833          	sub	a6,a6,a5
    2162:	ff887593          	andi	a1,a6,-8
    2166:	97aa                	add	a5,a5,a0
    2168:	95be                	add	a1,a1,a5
    216a:	0007b023          	sd	zero,0(a5)
    216e:	07a1                	addi	a5,a5,8
    2170:	feb79de3          	bne	a5,a1,216a <stpncpy+0xbe>
    2174:	ff887593          	andi	a1,a6,-8
    2178:	9ead                	addw	a3,a3,a1
    217a:	00b707b3          	add	a5,a4,a1
    217e:	12b80863          	beq	a6,a1,22ae <stpncpy+0x202>
    2182:	00078023          	sb	zero,0(a5)
    2186:	0016871b          	addiw	a4,a3,1
    218a:	0ec77863          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    218e:	000780a3          	sb	zero,1(a5)
    2192:	0026871b          	addiw	a4,a3,2
    2196:	0ec77263          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    219a:	00078123          	sb	zero,2(a5)
    219e:	0036871b          	addiw	a4,a3,3
    21a2:	0cc77c63          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21a6:	000781a3          	sb	zero,3(a5)
    21aa:	0046871b          	addiw	a4,a3,4
    21ae:	0cc77663          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21b2:	00078223          	sb	zero,4(a5)
    21b6:	0056871b          	addiw	a4,a3,5
    21ba:	0cc77063          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21be:	000782a3          	sb	zero,5(a5)
    21c2:	0066871b          	addiw	a4,a3,6
    21c6:	0ac77a63          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21ca:	00078323          	sb	zero,6(a5)
    21ce:	0076871b          	addiw	a4,a3,7
    21d2:	0ac77463          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21d6:	000783a3          	sb	zero,7(a5)
    21da:	0086871b          	addiw	a4,a3,8
    21de:	08c77e63          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21e2:	00078423          	sb	zero,8(a5)
    21e6:	0096871b          	addiw	a4,a3,9
    21ea:	08c77863          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21ee:	000784a3          	sb	zero,9(a5)
    21f2:	00a6871b          	addiw	a4,a3,10
    21f6:	08c77263          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    21fa:	00078523          	sb	zero,10(a5)
    21fe:	00b6871b          	addiw	a4,a3,11
    2202:	06c77c63          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    2206:	000785a3          	sb	zero,11(a5)
    220a:	00c6871b          	addiw	a4,a3,12
    220e:	06c77663          	bgeu	a4,a2,227a <stpncpy+0x1ce>
    2212:	00078623          	sb	zero,12(a5)
    2216:	26b5                	addiw	a3,a3,13
    2218:	06c6f163          	bgeu	a3,a2,227a <stpncpy+0x1ce>
    221c:	000786a3          	sb	zero,13(a5)
    2220:	8082                	ret
			;
		if (!n || !*s)
    2222:	c645                	beqz	a2,22ca <stpncpy+0x21e>
    2224:	0005c783          	lbu	a5,0(a1)
    2228:	ea078be3          	beqz	a5,20de <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    222c:	479d                	li	a5,7
    222e:	02c7ff63          	bgeu	a5,a2,226c <stpncpy+0x1c0>
    2232:	00000897          	auipc	a7,0x0
    2236:	5b68b883          	ld	a7,1462(a7) # 27e8 <enable_deadlock_detect+0x124>
    223a:	00000817          	auipc	a6,0x0
    223e:	5b683803          	ld	a6,1462(a6) # 27f0 <enable_deadlock_detect+0x12c>
    2242:	431d                	li	t1,7
    2244:	6198                	ld	a4,0(a1)
    2246:	011707b3          	add	a5,a4,a7
    224a:	fff74693          	not	a3,a4
    224e:	8ff5                	and	a5,a5,a3
    2250:	0107f7b3          	and	a5,a5,a6
    2254:	ef81                	bnez	a5,226c <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2256:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2258:	1661                	addi	a2,a2,-8
    225a:	05a1                	addi	a1,a1,8
    225c:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    225e:	fec363e3          	bltu	t1,a2,2244 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2262:	e609                	bnez	a2,226c <stpncpy+0x1c0>
    2264:	a08d                	j	22c6 <stpncpy+0x21a>
    2266:	167d                	addi	a2,a2,-1
    2268:	0505                	addi	a0,a0,1
    226a:	ca01                	beqz	a2,227a <stpncpy+0x1ce>
    226c:	0005c783          	lbu	a5,0(a1)
    2270:	0585                	addi	a1,a1,1
    2272:	00f50023          	sb	a5,0(a0)
    2276:	fbe5                	bnez	a5,2266 <stpncpy+0x1ba>
		;
tail:
    2278:	b59d                	j	20de <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    227a:	8082                	ret
    227c:	472d                	li	a4,11
    227e:	bdb5                	j	20fa <stpncpy+0x4e>
    2280:	00778713          	addi	a4,a5,7
    2284:	45ad                	li	a1,11
    2286:	fff60693          	addi	a3,a2,-1
    228a:	e6b778e3          	bgeu	a4,a1,20fa <stpncpy+0x4e>
    228e:	b7fd                	j	227c <stpncpy+0x1d0>
    2290:	40a007b3          	neg	a5,a0
    2294:	8832                	mv	a6,a2
    2296:	8b9d                	andi	a5,a5,7
    2298:	4681                	li	a3,0
    229a:	e4060be3          	beqz	a2,20f0 <stpncpy+0x44>
    229e:	b7cd                	j	2280 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22a0:	468d                	li	a3,3
    22a2:	bd75                	j	215e <stpncpy+0xb2>
    22a4:	872a                	mv	a4,a0
    22a6:	4681                	li	a3,0
    22a8:	bd5d                	j	215e <stpncpy+0xb2>
    22aa:	4685                	li	a3,1
    22ac:	bd4d                	j	215e <stpncpy+0xb2>
    22ae:	8082                	ret
    22b0:	87aa                	mv	a5,a0
    22b2:	4681                	li	a3,0
    22b4:	b5f9                	j	2182 <stpncpy+0xd6>
    22b6:	4689                	li	a3,2
    22b8:	b55d                	j	215e <stpncpy+0xb2>
    22ba:	4691                	li	a3,4
    22bc:	b54d                	j	215e <stpncpy+0xb2>
    22be:	4695                	li	a3,5
    22c0:	bd79                	j	215e <stpncpy+0xb2>
    22c2:	4699                	li	a3,6
    22c4:	bd69                	j	215e <stpncpy+0xb2>
    22c6:	8082                	ret
    22c8:	8082                	ret
    22ca:	8082                	ret

00000000000022cc <basename>:

char *basename(char *s)
{
    22cc:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22ce:	c54d                	beqz	a0,2378 <basename+0xac>
    22d0:	00054783          	lbu	a5,0(a0)
		return ".";
    22d4:	00000517          	auipc	a0,0x0
    22d8:	50450513          	addi	a0,a0,1284 # 27d8 <enable_deadlock_detect+0x114>
	if (!s || !*s)
    22dc:	e391                	bnez	a5,22e0 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22de:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22e0:	0076f713          	andi	a4,a3,7
    22e4:	87b6                	mv	a5,a3
    22e6:	cf51                	beqz	a4,2382 <basename+0xb6>
    22e8:	0785                	addi	a5,a5,1
    22ea:	0077f713          	andi	a4,a5,7
    22ee:	c729                	beqz	a4,2338 <basename+0x6c>
		if (!*s)
    22f0:	0007c703          	lbu	a4,0(a5)
    22f4:	fb75                	bnez	a4,22e8 <basename+0x1c>
	return s - a;
    22f6:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22f8:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22fa:	cf8d                	beqz	a5,2334 <basename+0x68>
    22fc:	00f68733          	add	a4,a3,a5
    2300:	02f00593          	li	a1,47
    2304:	a031                	j	2310 <basename+0x44>
		s[i] = 0;
    2306:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    230a:	17fd                	addi	a5,a5,-1
    230c:	177d                	addi	a4,a4,-1
    230e:	c39d                	beqz	a5,2334 <basename+0x68>
    2310:	00074603          	lbu	a2,0(a4)
    2314:	feb609e3          	beq	a2,a1,2306 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2318:	02f00613          	li	a2,47
    231c:	a011                	j	2320 <basename+0x54>
    231e:	cb99                	beqz	a5,2334 <basename+0x68>
    2320:	853e                	mv	a0,a5
    2322:	17fd                	addi	a5,a5,-1
    2324:	00f68733          	add	a4,a3,a5
    2328:	00074703          	lbu	a4,0(a4)
    232c:	fec719e3          	bne	a4,a2,231e <basename+0x52>
	return s + i;
    2330:	9536                	add	a0,a0,a3
    2332:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2334:	8536                	mv	a0,a3
    2336:	8082                	ret
    2338:	6390                	ld	a2,0(a5)
    233a:	00000517          	auipc	a0,0x0
    233e:	4ae53503          	ld	a0,1198(a0) # 27e8 <enable_deadlock_detect+0x124>
    2342:	00000597          	auipc	a1,0x0
    2346:	4ae5b583          	ld	a1,1198(a1) # 27f0 <enable_deadlock_detect+0x12c>
    234a:	fff64713          	not	a4,a2
    234e:	962a                	add	a2,a2,a0
    2350:	8f71                	and	a4,a4,a2
    2352:	8f6d                	and	a4,a4,a1
    2354:	eb11                	bnez	a4,2368 <basename+0x9c>
    2356:	6790                	ld	a2,8(a5)
    2358:	07a1                	addi	a5,a5,8
    235a:	00a60733          	add	a4,a2,a0
    235e:	fff64613          	not	a2,a2
    2362:	8f71                	and	a4,a4,a2
    2364:	8f6d                	and	a4,a4,a1
    2366:	db65                	beqz	a4,2356 <basename+0x8a>
	for (; *s; s++)
    2368:	0007c703          	lbu	a4,0(a5)
    236c:	d749                	beqz	a4,22f6 <basename+0x2a>
    236e:	0017c703          	lbu	a4,1(a5)
    2372:	0785                	addi	a5,a5,1
    2374:	ff6d                	bnez	a4,236e <basename+0xa2>
    2376:	b741                	j	22f6 <basename+0x2a>
		return ".";
    2378:	00000517          	auipc	a0,0x0
    237c:	46050513          	addi	a0,a0,1120 # 27d8 <enable_deadlock_detect+0x114>
    2380:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2382:	6290                	ld	a2,0(a3)
    2384:	00000517          	auipc	a0,0x0
    2388:	46453503          	ld	a0,1124(a0) # 27e8 <enable_deadlock_detect+0x124>
    238c:	00000597          	auipc	a1,0x0
    2390:	4645b583          	ld	a1,1124(a1) # 27f0 <enable_deadlock_detect+0x12c>
    2394:	fff64713          	not	a4,a2
    2398:	962a                	add	a2,a2,a0
    239a:	8f71                	and	a4,a4,a2
    239c:	8f6d                	and	a4,a4,a1
    239e:	df45                	beqz	a4,2356 <basename+0x8a>
    23a0:	b7f9                	j	236e <basename+0xa2>

00000000000023a2 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23a2:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23a6:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23a8:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23ac:	2501                	sext.w	a0,a0
    23ae:	8082                	ret

00000000000023b0 <close>:

int close(int fd)
{
	if (fd == 1) {
    23b0:	4785                	li	a5,1
    23b2:	00f50863          	beq	a0,a5,23c2 <close+0x12>
	register long a7 __asm__("a7") = n;
    23b6:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23ba:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23be:	2501                	sext.w	a0,a0
    23c0:	8082                	ret
{
    23c2:	1101                	addi	sp,sp,-32
    23c4:	ec06                	sd	ra,24(sp)
    23c6:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23c8:	cdffe0ef          	jal	ra,10a6 <__write_buffer>
		__clear_buffer();
    23cc:	d03fe0ef          	jal	ra,10ce <__clear_buffer>
    23d0:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23d2:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23d6:	00000073          	ecall
}
    23da:	60e2                	ld	ra,24(sp)
    23dc:	2501                	sext.w	a0,a0
    23de:	6105                	addi	sp,sp,32
    23e0:	8082                	ret

00000000000023e2 <read>:
	register long a7 __asm__("a7") = n;
    23e2:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23e6:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23ea:	8082                	ret

00000000000023ec <write>:
	register long a7 __asm__("a7") = n;
    23ec:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23f0:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23f4:	8082                	ret

00000000000023f6 <getpid>:
	register long a7 __asm__("a7") = n;
    23f6:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23fa:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23fe:	2501                	sext.w	a0,a0
    2400:	8082                	ret

0000000000002402 <getppid>:
	register long a7 __asm__("a7") = n;
    2402:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2406:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    240a:	2501                	sext.w	a0,a0
    240c:	8082                	ret

000000000000240e <sched_yield>:
	register long a7 __asm__("a7") = n;
    240e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2412:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2416:	2501                	sext.w	a0,a0
    2418:	8082                	ret

000000000000241a <fork>:
	register long a7 __asm__("a7") = n;
    241a:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    241e:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2422:	2501                	sext.w	a0,a0
    2424:	8082                	ret

0000000000002426 <exit>:

void exit(int code)
{
    2426:	1141                	addi	sp,sp,-16
    2428:	e406                	sd	ra,8(sp)
    242a:	e022                	sd	s0,0(sp)
    242c:	842a                	mv	s0,a0
	__write_buffer();
    242e:	c79fe0ef          	jal	ra,10a6 <__write_buffer>
	__clear_buffer();
    2432:	c9dfe0ef          	jal	ra,10ce <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2436:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    243a:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    243c:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2440:	60a2                	ld	ra,8(sp)
    2442:	6402                	ld	s0,0(sp)
    2444:	0141                	addi	sp,sp,16
    2446:	8082                	ret

0000000000002448 <waitpid>:
	register long a7 __asm__("a7") = n;
    2448:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    244c:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2450:	2501                	sext.w	a0,a0
    2452:	8082                	ret

0000000000002454 <exec>:
	register long a7 __asm__("a7") = n;
    2454:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2458:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    245c:	2501                	sext.w	a0,a0
    245e:	8082                	ret

0000000000002460 <get_mtime>:

int64 get_mtime()
{
    2460:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2462:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2466:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2468:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    246a:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    246e:	2501                	sext.w	a0,a0
    2470:	ed01                	bnez	a0,2488 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2472:	6722                	ld	a4,8(sp)
    2474:	3e800793          	li	a5,1000
    2478:	6682                	ld	a3,0(sp)
    247a:	02f75733          	divu	a4,a4,a5
    247e:	02d78533          	mul	a0,a5,a3
    2482:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2484:	0141                	addi	sp,sp,16
    2486:	8082                	ret
	return -1;
    2488:	557d                	li	a0,-1
    248a:	bfed                	j	2484 <get_mtime+0x24>

000000000000248c <sys_get_time>:
	register long a7 __asm__("a7") = n;
    248c:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2490:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2494:	2501                	sext.w	a0,a0
    2496:	8082                	ret

0000000000002498 <sleep>:

int sleep(unsigned long long time)
{
    2498:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    249a:	880a                	mv	a6,sp
{
    249c:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    249e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24a4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a6:	00000073          	ecall
	if (err == 0) {
    24aa:	2501                	sext.w	a0,a0
    24ac:	ed31                	bnez	a0,2508 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24ae:	6722                	ld	a4,8(sp)
    24b0:	3e800793          	li	a5,1000
    24b4:	6682                	ld	a3,0(sp)
    24b6:	02f75733          	divu	a4,a4,a5
    24ba:	02d787b3          	mul	a5,a5,a3
    24be:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24c0:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c4:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c6:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c8:	00000073          	ecall
	if (err == 0) {
    24cc:	2501                	sext.w	a0,a0
    24ce:	e915                	bnez	a0,2502 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24d0:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24d2:	3e800693          	li	a3,1000
    24d6:	a819                	j	24ec <sleep+0x54>
	__asm_syscall("r"(a7))
    24d8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24dc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24e0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24e2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e4:	00000073          	ecall
	if (err == 0) {
    24e8:	2501                	sext.w	a0,a0
    24ea:	ed01                	bnez	a0,2502 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24ec:	6722                	ld	a4,8(sp)
    24ee:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24f0:	07c00893          	li	a7,124
    24f4:	02d75733          	divu	a4,a4,a3
    24f8:	02f687b3          	mul	a5,a3,a5
    24fc:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24fe:	fcc7ede3          	bltu	a5,a2,24d8 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2502:	4501                	li	a0,0
    2504:	0141                	addi	sp,sp,16
    2506:	8082                	ret
    2508:	57fd                	li	a5,-1
    250a:	bf5d                	j	24c0 <sleep+0x28>

000000000000250c <sys_task_info>:
	register long a7 __asm__("a7") = n;
    250c:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2510:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2514:	2501                	sext.w	a0,a0
    2516:	8082                	ret

0000000000002518 <set_priority>:
	register long a7 __asm__("a7") = n;
    2518:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    251c:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2520:	2501                	sext.w	a0,a0
    2522:	8082                	ret

0000000000002524 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2524:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2528:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    252c:	2501                	sext.w	a0,a0
    252e:	8082                	ret

0000000000002530 <munmap>:
	register long a7 __asm__("a7") = n;
    2530:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2534:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2538:	2501                	sext.w	a0,a0
    253a:	8082                	ret

000000000000253c <wait>:

int wait(int *code)
{
    253c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    253e:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2542:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2544:	00000073          	ecall
	return waitpid(-1, code);
}
    2548:	2501                	sext.w	a0,a0
    254a:	8082                	ret

000000000000254c <spawn>:
	register long a7 __asm__("a7") = n;
    254c:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2550:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2554:	2501                	sext.w	a0,a0
    2556:	8082                	ret

0000000000002558 <pipe>:
	register long a7 __asm__("a7") = n;
    2558:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    255c:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2560:	2501                	sext.w	a0,a0
    2562:	8082                	ret

0000000000002564 <mailread>:
	register long a7 __asm__("a7") = n;
    2564:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2568:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    256c:	2501                	sext.w	a0,a0
    256e:	8082                	ret

0000000000002570 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2570:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2574:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2578:	2501                	sext.w	a0,a0
    257a:	8082                	ret

000000000000257c <fstat>:
	register long a7 __asm__("a7") = n;
    257c:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2580:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2584:	2501                	sext.w	a0,a0
    2586:	8082                	ret

0000000000002588 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2588:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    258a:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    258e:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2590:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2594:	2501                	sext.w	a0,a0
    2596:	8082                	ret

0000000000002598 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2598:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    259a:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    259e:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25a0:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25a4:	2501                	sext.w	a0,a0
    25a6:	8082                	ret

00000000000025a8 <link>:

int link(char *old_path, char *new_path)
{
    25a8:	87aa                	mv	a5,a0
    25aa:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25ac:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25b0:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25b4:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25b6:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25ba:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25bc:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25c0:	2501                	sext.w	a0,a0
    25c2:	8082                	ret

00000000000025c4 <unlink>:

int unlink(char *path)
{
    25c4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25c6:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25ca:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25ce:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d0:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25d4:	2501                	sext.w	a0,a0
    25d6:	8082                	ret

00000000000025d8 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25d8:	00000797          	auipc	a5,0x0
    25dc:	3607b783          	ld	a5,864(a5) # 2938 <_GLOBAL_OFFSET_TABLE_+0x8>
    25e0:	439c                	lw	a5,0(a5)
    25e2:	c799                	beqz	a5,25f0 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25e4:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e8:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25ec:	2501                	sext.w	a0,a0
    25ee:	8082                	ret
{
    25f0:	1101                	addi	sp,sp,-32
    25f2:	ec06                	sd	ra,24(sp)
    25f4:	e42e                	sd	a1,8(sp)
    25f6:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25f8:	fe7fe0ef          	jal	ra,15de <enable_thread_io_buffer>
    25fc:	65a2                	ld	a1,8(sp)
    25fe:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2600:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2604:	00000073          	ecall
}
    2608:	60e2                	ld	ra,24(sp)
    260a:	2501                	sext.w	a0,a0
    260c:	6105                	addi	sp,sp,32
    260e:	8082                	ret

0000000000002610 <gettid>:
	register long a7 __asm__("a7") = n;
    2610:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2614:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2618:	2501                	sext.w	a0,a0
    261a:	8082                	ret

000000000000261c <waittid>:

int waittid(int tid)
{
    261c:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    261e:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2622:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2626:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2628:	2501                	sext.w	a0,a0
	while (ret == -2) {
    262a:	00e51e63          	bne	a0,a4,2646 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    262e:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2632:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2636:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    263a:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    263c:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2640:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2642:	fee506e3          	beq	a0,a4,262e <waittid+0x12>
	}
	return ret;
}
    2646:	8082                	ret

0000000000002648 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2648:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    264c:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    264e:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2652:	2501                	sext.w	a0,a0
    2654:	8082                	ret

0000000000002656 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2656:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    265a:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    265c:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2660:	2501                	sext.w	a0,a0
    2662:	8082                	ret

0000000000002664 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2664:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2668:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    266c:	2501                	sext.w	a0,a0
    266e:	8082                	ret

0000000000002670 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2670:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2674:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2678:	2501                	sext.w	a0,a0
    267a:	8082                	ret

000000000000267c <semaphore_create>:
	register long a7 __asm__("a7") = n;
    267c:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2680:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2684:	2501                	sext.w	a0,a0
    2686:	8082                	ret

0000000000002688 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2688:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    268c:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2690:	2501                	sext.w	a0,a0
    2692:	8082                	ret

0000000000002694 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2694:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2698:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    269c:	2501                	sext.w	a0,a0
    269e:	8082                	ret

00000000000026a0 <condvar_create>:
	register long a7 __asm__("a7") = n;
    26a0:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26a4:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26a8:	2501                	sext.w	a0,a0
    26aa:	8082                	ret

00000000000026ac <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26ac:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26b0:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26b4:	2501                	sext.w	a0,a0
    26b6:	8082                	ret

00000000000026b8 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26b8:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26bc:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26c0:	2501                	sext.w	a0,a0
    26c2:	8082                	ret

00000000000026c4 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26c4:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26c8:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26cc:	2501                	sext.w	a0,a0
    26ce:	8082                	ret
