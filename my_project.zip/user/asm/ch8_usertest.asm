
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8_usertest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	ac91                	j	1254 <__start_main>

0000000000001002 <run_tests>:
#ifndef USER_TEST
#define USER_TEST

int run_tests(const char *tests[], int n)
{
    1002:	7175                	addi	sp,sp,-144
    1004:	e506                	sd	ra,136(sp)
    1006:	e122                	sd	s0,128(sp)
    1008:	fca6                	sd	s1,120(sp)
    100a:	f8ca                	sd	s2,112(sp)
    100c:	f4ce                	sd	s3,104(sp)
    100e:	f0d2                	sd	s4,96(sp)
    1010:	ecd6                	sd	s5,88(sp)
    1012:	e8da                	sd	s6,80(sp)
    1014:	e4de                	sd	s7,72(sp)
    1016:	e0e2                	sd	s8,64(sp)
    1018:	fc66                	sd	s9,56(sp)
    101a:	f86a                	sd	s10,48(sp)
    101c:	f46e                	sd	s11,40(sp)
	int success = 0;
	for (int i = 0; i < n; ++i) {
    101e:	0eb05c63          	blez	a1,1116 <run_tests+0x114>
    1022:	fff58a1b          	addiw	s4,a1,-1
    1026:	020a1793          	slli	a5,s4,0x20
    102a:	01d7da13          	srli	s4,a5,0x1d
    102e:	00850793          	addi	a5,a0,8
    1032:	84aa                	mv	s1,a0
    1034:	9a3e                	add	s4,s4,a5
	int success = 0;
    1036:	4981                	li	s3,0
    1038:	01c10b93          	addi	s7,sp,28
		const char *test = tests[i];
		printf("Usertests: Running %s\n", test);
    103c:	00002b17          	auipc	s6,0x2
    1040:	884b0b13          	addi	s6,s6,-1916 # 28c0 <enable_deadlock_detect+0x12>
		}
		int xstate = 0;
		int wait_pid = waitpid(pid, &xstate);
		assert_eq(pid, wait_pid);
		success += (xstate == 0);
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1044:	00002a97          	auipc	s5,0x2
    1048:	91ca8a93          	addi	s5,s5,-1764 # 2960 <enable_deadlock_detect+0xb2>
		assert_eq(pid, wait_pid);
    104c:	00002d17          	auipc	s10,0x2
    1050:	88cd0d13          	addi	s10,s10,-1908 # 28d8 <enable_deadlock_detect+0x2a>
    1054:	00002c97          	auipc	s9,0x2
    1058:	8ccc8c93          	addi	s9,s9,-1844 # 2920 <enable_deadlock_detect+0x72>
    105c:	00002c17          	auipc	s8,0x2
    1060:	8ccc0c13          	addi	s8,s8,-1844 # 2928 <enable_deadlock_detect+0x7a>
		const char *test = tests[i];
    1064:	0004b903          	ld	s2,0(s1)
		printf("Usertests: Running %s\n", test);
    1068:	855a                	mv	a0,s6
    106a:	85ca                	mv	a1,s2
    106c:	342000ef          	jal	ra,13ae <printf>
		int pid = fork();
    1070:	594010ef          	jal	ra,2604 <fork>
    1074:	842a                	mv	s0,a0
		if (pid == 0) {
    1076:	c941                	beqz	a0,1106 <run_tests+0x104>
		int wait_pid = waitpid(pid, &xstate);
    1078:	85de                	mv	a1,s7
    107a:	8522                	mv	a0,s0
		int xstate = 0;
    107c:	ce02                	sw	zero,28(sp)
		int wait_pid = waitpid(pid, &xstate);
    107e:	5b4010ef          	jal	ra,2632 <waitpid>
    1082:	8daa                	mv	s11,a0
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1084:	8622                	mv	a2,s0
    1086:	85ca                	mv	a1,s2
    1088:	8556                	mv	a0,s5
		assert_eq(pid, wait_pid);
    108a:	07b40363          	beq	s0,s11,10f0 <run_tests+0xee>
    108e:	552010ef          	jal	ra,25e0 <getpid>
    1092:	86aa                	mv	a3,a0
    1094:	856a                	mv	a0,s10
    1096:	e436                	sd	a3,8(sp)
    1098:	41e010ef          	jal	ra,24b6 <basename>
    109c:	66a2                	ld	a3,8(sp)
    109e:	872a                	mv	a4,a0
    10a0:	47c5                	li	a5,17
    10a2:	8666                	mv	a2,s9
    10a4:	45fd                	li	a1,31
    10a6:	88ee                	mv	a7,s11
    10a8:	8822                	mv	a6,s0
    10aa:	8562                	mv	a0,s8
    10ac:	302000ef          	jal	ra,13ae <printf>
    10b0:	557d                	li	a0,-1
    10b2:	55e010ef          	jal	ra,2610 <exit>
		success += (xstate == 0);
    10b6:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10b8:	04a1                	addi	s1,s1,8
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10ba:	8622                	mv	a2,s0
		success += (xstate == 0);
    10bc:	0016b793          	seqz	a5,a3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c0:	85ca                	mv	a1,s2
    10c2:	8556                	mv	a0,s5
		success += (xstate == 0);
    10c4:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c8:	2e6000ef          	jal	ra,13ae <printf>
	for (int i = 0; i < n; ++i) {
    10cc:	f89a1ce3          	bne	s4,s1,1064 <run_tests+0x62>
		       test, pid, xstate);
	}
	return success;
}
    10d0:	60aa                	ld	ra,136(sp)
    10d2:	640a                	ld	s0,128(sp)
    10d4:	74e6                	ld	s1,120(sp)
    10d6:	7946                	ld	s2,112(sp)
    10d8:	7a06                	ld	s4,96(sp)
    10da:	6ae6                	ld	s5,88(sp)
    10dc:	6b46                	ld	s6,80(sp)
    10de:	6ba6                	ld	s7,72(sp)
    10e0:	6c06                	ld	s8,64(sp)
    10e2:	7ce2                	ld	s9,56(sp)
    10e4:	7d42                	ld	s10,48(sp)
    10e6:	7da2                	ld	s11,40(sp)
    10e8:	854e                	mv	a0,s3
    10ea:	79a6                	ld	s3,104(sp)
    10ec:	6149                	addi	sp,sp,144
    10ee:	8082                	ret
		success += (xstate == 0);
    10f0:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10f2:	04a1                	addi	s1,s1,8
		success += (xstate == 0);
    10f4:	0016b793          	seqz	a5,a3
    10f8:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10fc:	2b2000ef          	jal	ra,13ae <printf>
	for (int i = 0; i < n; ++i) {
    1100:	f74492e3          	bne	s1,s4,1064 <run_tests+0x62>
    1104:	b7f1                	j	10d0 <run_tests+0xce>
			exec(test, NULL);
    1106:	4581                	li	a1,0
    1108:	854a                	mv	a0,s2
    110a:	534010ef          	jal	ra,263e <exec>
			exit(-1);
    110e:	557d                	li	a0,-1
    1110:	500010ef          	jal	ra,2610 <exit>
    1114:	b795                	j	1078 <run_tests+0x76>
	int success = 0;
    1116:	4981                	li	s3,0
    1118:	bf65                	j	10d0 <run_tests+0xce>

000000000000111a <test>:

int test(const char *succs[], int nsucc, const char *fails[], int nfail,
	 const char *message)
{
    111a:	7139                	addi	sp,sp,-64
    111c:	f822                	sd	s0,48(sp)
    111e:	f426                	sd	s1,40(sp)
    1120:	ec4e                	sd	s3,24(sp)
    1122:	fc06                	sd	ra,56(sp)
    1124:	f04a                	sd	s2,32(sp)
    1126:	e852                	sd	s4,16(sp)
    1128:	e456                	sd	s5,8(sp)
    112a:	84b2                	mv	s1,a2
    112c:	89b6                	mv	s3,a3
    112e:	843a                	mv	s0,a4
	if (succs && nsucc > 0) {
    1130:	c501                	beqz	a0,1138 <test+0x1e>
    1132:	892e                	mv	s2,a1
    1134:	06b04763          	bgtz	a1,11a2 <test+0x88>
		int succ_count = run_tests(succs, nsucc);
		assert_eq(succ_count, nsucc);
	}
	if (fails && nfail > 0) {
    1138:	c099                	beqz	s1,113e <test+0x24>
    113a:	03304063          	bgtz	s3,115a <test+0x40>
		int fail_count = run_tests(fails, nfail);
		assert_eq(fail_count, 0);
	}
	if (message)
    113e:	c401                	beqz	s0,1146 <test+0x2c>
		puts(message);
    1140:	8522                	mv	a0,s0
    1142:	183000ef          	jal	ra,1ac4 <puts>
	return 0;
}
    1146:	70e2                	ld	ra,56(sp)
    1148:	7442                	ld	s0,48(sp)
    114a:	74a2                	ld	s1,40(sp)
    114c:	7902                	ld	s2,32(sp)
    114e:	69e2                	ld	s3,24(sp)
    1150:	6a42                	ld	s4,16(sp)
    1152:	6aa2                	ld	s5,8(sp)
    1154:	4501                	li	a0,0
    1156:	6121                	addi	sp,sp,64
    1158:	8082                	ret
		int fail_count = run_tests(fails, nfail);
    115a:	8526                	mv	a0,s1
    115c:	85ce                	mv	a1,s3
    115e:	ea5ff0ef          	jal	ra,1002 <run_tests>
    1162:	84aa                	mv	s1,a0
		assert_eq(fail_count, 0);
    1164:	dd69                	beqz	a0,113e <test+0x24>
    1166:	47a010ef          	jal	ra,25e0 <getpid>
    116a:	892a                	mv	s2,a0
    116c:	00001517          	auipc	a0,0x1
    1170:	76c50513          	addi	a0,a0,1900 # 28d8 <enable_deadlock_detect+0x2a>
    1174:	342010ef          	jal	ra,24b6 <basename>
    1178:	872a                	mv	a4,a0
    117a:	4881                	li	a7,0
    117c:	00001517          	auipc	a0,0x1
    1180:	7ac50513          	addi	a0,a0,1964 # 2928 <enable_deadlock_detect+0x7a>
    1184:	8826                	mv	a6,s1
    1186:	02200793          	li	a5,34
    118a:	86ca                	mv	a3,s2
    118c:	00001617          	auipc	a2,0x1
    1190:	79460613          	addi	a2,a2,1940 # 2920 <enable_deadlock_detect+0x72>
    1194:	45fd                	li	a1,31
    1196:	218000ef          	jal	ra,13ae <printf>
    119a:	557d                	li	a0,-1
    119c:	474010ef          	jal	ra,2610 <exit>
    11a0:	bf79                	j	113e <test+0x24>
		int succ_count = run_tests(succs, nsucc);
    11a2:	e61ff0ef          	jal	ra,1002 <run_tests>
    11a6:	8a2a                	mv	s4,a0
		assert_eq(succ_count, nsucc);
    11a8:	f8a908e3          	beq	s2,a0,1138 <test+0x1e>
    11ac:	434010ef          	jal	ra,25e0 <getpid>
    11b0:	8aaa                	mv	s5,a0
    11b2:	00001517          	auipc	a0,0x1
    11b6:	72650513          	addi	a0,a0,1830 # 28d8 <enable_deadlock_detect+0x2a>
    11ba:	2fc010ef          	jal	ra,24b6 <basename>
    11be:	872a                	mv	a4,a0
    11c0:	88ca                	mv	a7,s2
    11c2:	8852                	mv	a6,s4
    11c4:	00001517          	auipc	a0,0x1
    11c8:	76450513          	addi	a0,a0,1892 # 2928 <enable_deadlock_detect+0x7a>
    11cc:	47f9                	li	a5,30
    11ce:	86d6                	mv	a3,s5
    11d0:	00001617          	auipc	a2,0x1
    11d4:	75060613          	addi	a2,a2,1872 # 2920 <enable_deadlock_detect+0x72>
    11d8:	45fd                	li	a1,31
    11da:	1d4000ef          	jal	ra,13ae <printf>
    11de:	557d                	li	a0,-1
    11e0:	430010ef          	jal	ra,2610 <exit>
    11e4:	bf91                	j	1138 <test+0x1e>

00000000000011e6 <main>:
	"ch8b_sync_sem\0",     "ch8b_test_condvar\0",  "ch8b_threads_arg\0",
	"ch8b_threads\0",      "ch8b_spin_mut_race\0", "ch8b_mut_phi_din\0",
};

int main()
{
    11e6:	1101                	addi	sp,sp,-32
	int num_test = sizeof(TESTS) / sizeof(char *);
	int succ = run_tests(TESTS, num_test);
    11e8:	45e1                	li	a1,24
    11ea:	00002517          	auipc	a0,0x2
    11ee:	bee50513          	addi	a0,a0,-1042 # 2dd8 <TESTS>
{
    11f2:	ec06                	sd	ra,24(sp)
    11f4:	e822                	sd	s0,16(sp)
    11f6:	e426                	sd	s1,8(sp)
	int succ = run_tests(TESTS, num_test);
    11f8:	e0bff0ef          	jal	ra,1002 <run_tests>
	assert_eq(succ, num_test);
    11fc:	47e1                	li	a5,24
    11fe:	02f50f63          	beq	a0,a5,123c <main+0x56>
    1202:	842a                	mv	s0,a0
    1204:	3dc010ef          	jal	ra,25e0 <getpid>
    1208:	84aa                	mv	s1,a0
    120a:	00001517          	auipc	a0,0x1
    120e:	78e50513          	addi	a0,a0,1934 # 2998 <enable_deadlock_detect+0xea>
    1212:	2a4010ef          	jal	ra,24b6 <basename>
    1216:	872a                	mv	a4,a0
    1218:	48e1                	li	a7,24
    121a:	00001517          	auipc	a0,0x1
    121e:	70e50513          	addi	a0,a0,1806 # 2928 <enable_deadlock_detect+0x7a>
    1222:	8822                	mv	a6,s0
    1224:	47dd                	li	a5,23
    1226:	86a6                	mv	a3,s1
    1228:	00001617          	auipc	a2,0x1
    122c:	6f860613          	addi	a2,a2,1784 # 2920 <enable_deadlock_detect+0x72>
    1230:	45fd                	li	a1,31
    1232:	17c000ef          	jal	ra,13ae <printf>
    1236:	557d                	li	a0,-1
    1238:	3d8010ef          	jal	ra,2610 <exit>
	puts("ch8 Usertests passed!");
    123c:	00001517          	auipc	a0,0x1
    1240:	7a450513          	addi	a0,a0,1956 # 29e0 <enable_deadlock_detect+0x132>
    1244:	081000ef          	jal	ra,1ac4 <puts>
	return 0;
}
    1248:	60e2                	ld	ra,24(sp)
    124a:	6442                	ld	s0,16(sp)
    124c:	64a2                	ld	s1,8(sp)
    124e:	4501                	li	a0,0
    1250:	6105                	addi	sp,sp,32
    1252:	8082                	ret

0000000000001254 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1254:	1141                	addi	sp,sp,-16
    1256:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1258:	f8fff0ef          	jal	ra,11e6 <main>
    125c:	3b4010ef          	jal	ra,2610 <exit>
	return 0;
    1260:	60a2                	ld	ra,8(sp)
    1262:	4501                	li	a0,0
    1264:	0141                	addi	sp,sp,16
    1266:	8082                	ret

0000000000001268 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1268:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    126a:	4605                	li	a2,1
    126c:	00f10593          	addi	a1,sp,15
    1270:	4501                	li	a0,0
{
    1272:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1274:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1278:	354010ef          	jal	ra,25cc <read>
    127c:	4785                	li	a5,1
    127e:	00f51763          	bne	a0,a5,128c <getchar+0x24>
		return byte;
    1282:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1286:	60e2                	ld	ra,24(sp)
    1288:	6105                	addi	sp,sp,32
    128a:	8082                	ret
		return EOF;
    128c:	557d                	li	a0,-1
    128e:	bfe5                	j	1286 <getchar+0x1e>

0000000000001290 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1290:	00002517          	auipc	a0,0x2
    1294:	86052503          	lw	a0,-1952(a0) # 2af0 <buffer_len>
    1298:	e111                	bnez	a0,129c <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    129a:	8082                	ret
{
    129c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    129e:	862a                	mv	a2,a0
    12a0:	00002597          	auipc	a1,0x2
    12a4:	85858593          	addi	a1,a1,-1960 # 2af8 <buffer>
    12a8:	4505                	li	a0,1
{
    12aa:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12ac:	32a010ef          	jal	ra,25d6 <write>
}
    12b0:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12b2:	2501                	sext.w	a0,a0
}
    12b4:	0141                	addi	sp,sp,16
    12b6:	8082                	ret

00000000000012b8 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    12b8:	00002797          	auipc	a5,0x2
    12bc:	8207ac23          	sw	zero,-1992(a5) # 2af0 <buffer_len>
}
    12c0:	8082                	ret

00000000000012c2 <__fflush>:
	if (buffer_len == 0)
    12c2:	00002517          	auipc	a0,0x2
    12c6:	82e52503          	lw	a0,-2002(a0) # 2af0 <buffer_len>
    12ca:	e511                	bnez	a0,12d6 <__fflush+0x14>
	buffer_len = 0;
    12cc:	00002797          	auipc	a5,0x2
    12d0:	8207a223          	sw	zero,-2012(a5) # 2af0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    12d4:	8082                	ret
{
    12d6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12d8:	862a                	mv	a2,a0
    12da:	00002597          	auipc	a1,0x2
    12de:	81e58593          	addi	a1,a1,-2018 # 2af8 <buffer>
    12e2:	4505                	li	a0,1
{
    12e4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12e6:	2f0010ef          	jal	ra,25d6 <write>
	return r >= 0 ? 0 : r;
    12ea:	0005079b          	sext.w	a5,a0
}
    12ee:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12f0:	0017a793          	slti	a5,a5,1
    12f4:	40f007bb          	negw	a5,a5
    12f8:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    12fa:	00001797          	auipc	a5,0x1
    12fe:	7e07ab23          	sw	zero,2038(a5) # 2af0 <buffer_len>
	return r >= 0 ? 0 : r;
    1302:	2501                	sext.w	a0,a0
}
    1304:	0141                	addi	sp,sp,16
    1306:	8082                	ret

0000000000001308 <fflush>:

int fflush(int fd)
{
    1308:	1101                	addi	sp,sp,-32
    130a:	e822                	sd	s0,16(sp)
    130c:	ec06                	sd	ra,24(sp)
    130e:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1310:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1312:	4401                	li	s0,0
	if (fd == 1) {
    1314:	00e50863          	beq	a0,a4,1324 <fflush+0x1c>
}
    1318:	60e2                	ld	ra,24(sp)
    131a:	8522                	mv	a0,s0
    131c:	6442                	ld	s0,16(sp)
    131e:	64a2                	ld	s1,8(sp)
    1320:	6105                	addi	sp,sp,32
    1322:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1324:	00001497          	auipc	s1,0x1
    1328:	7cc48493          	addi	s1,s1,1996 # 2af0 <buffer_len>
    132c:	1084a703          	lw	a4,264(s1)
    1330:	02a70e63          	beq	a4,a0,136c <fflush+0x64>
	if (buffer_len == 0)
    1334:	4080                	lw	s0,0(s1)
    1336:	c00d                	beqz	s0,1358 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1338:	8622                	mv	a2,s0
    133a:	00001597          	auipc	a1,0x1
    133e:	7be58593          	addi	a1,a1,1982 # 2af8 <buffer>
    1342:	294010ef          	jal	ra,25d6 <write>
	return r >= 0 ? 0 : r;
    1346:	0005079b          	sext.w	a5,a0
    134a:	0017a793          	slti	a5,a5,1
    134e:	40f007bb          	negw	a5,a5
    1352:	8d7d                	and	a0,a0,a5
    1354:	0005041b          	sext.w	s0,a0
}
    1358:	60e2                	ld	ra,24(sp)
    135a:	8522                	mv	a0,s0
    135c:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    135e:	00001797          	auipc	a5,0x1
    1362:	7807a923          	sw	zero,1938(a5) # 2af0 <buffer_len>
}
    1366:	64a2                	ld	s1,8(sp)
    1368:	6105                	addi	sp,sp,32
    136a:	8082                	ret
			mutex_lock(buffer_lock);
    136c:	10c4a503          	lw	a0,268(s1)
    1370:	4de010ef          	jal	ra,284e <mutex_lock>
	if (buffer_len == 0)
    1374:	4080                	lw	s0,0(s1)
    1376:	e811                	bnez	s0,138a <fflush+0x82>
			mutex_unlock(buffer_lock);
    1378:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    137c:	00001797          	auipc	a5,0x1
    1380:	7607aa23          	sw	zero,1908(a5) # 2af0 <buffer_len>
			mutex_unlock(buffer_lock);
    1384:	4d6010ef          	jal	ra,285a <mutex_unlock>
    1388:	bf41                	j	1318 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    138a:	8622                	mv	a2,s0
    138c:	00001597          	auipc	a1,0x1
    1390:	76c58593          	addi	a1,a1,1900 # 2af8 <buffer>
    1394:	4505                	li	a0,1
    1396:	240010ef          	jal	ra,25d6 <write>
	return r >= 0 ? 0 : r;
    139a:	0005079b          	sext.w	a5,a0
    139e:	0017a793          	slti	a5,a5,1
    13a2:	40f007bb          	negw	a5,a5
    13a6:	8d7d                	and	a0,a0,a5
    13a8:	0005041b          	sext.w	s0,a0
	return r;
    13ac:	b7f1                	j	1378 <fflush+0x70>

00000000000013ae <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    13ae:	7131                	addi	sp,sp,-192
    13b0:	e0da                	sd	s6,64(sp)
    13b2:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    13b4:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    13b6:	013c                	addi	a5,sp,136
{
    13b8:	f0ca                	sd	s2,96(sp)
    13ba:	ecce                	sd	s3,88(sp)
    13bc:	e8d2                	sd	s4,80(sp)
    13be:	e4d6                	sd	s5,72(sp)
    13c0:	fc86                	sd	ra,120(sp)
    13c2:	f8a2                	sd	s0,112(sp)
    13c4:	f4a6                	sd	s1,104(sp)
    13c6:	89aa                	mv	s3,a0
    13c8:	e52e                	sd	a1,136(sp)
    13ca:	e932                	sd	a2,144(sp)
    13cc:	ed36                	sd	a3,152(sp)
    13ce:	f13a                	sd	a4,160(sp)
    13d0:	f942                	sd	a6,176(sp)
    13d2:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    13d4:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    13d6:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    13da:	00001a17          	auipc	s4,0x1
    13de:	716a0a13          	addi	s4,s4,1814 # 2af0 <buffer_len>
    13e2:	4a85                	li	s5,1
	buf[i++] = '0';
    13e4:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13e8:	0009c783          	lbu	a5,0(s3)
    13ec:	18078663          	beqz	a5,1578 <printf+0x1ca>
    13f0:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13f2:	19278d63          	beq	a5,s2,158c <printf+0x1de>
    13f6:	0015c783          	lbu	a5,1(a1)
    13fa:	0585                	addi	a1,a1,1
    13fc:	fbfd                	bnez	a5,13f2 <printf+0x44>
    13fe:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1400:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1404:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1408:	1b578863          	beq	a5,s5,15b8 <printf+0x20a>
		len = out_unlocked(s, l);
    140c:	85a2                	mv	a1,s0
    140e:	854e                	mv	a0,s3
    1410:	42a000ef          	jal	ra,183a <out_unlocked>
		out(f, a, l);
		if (l)
    1414:	1c041063          	bnez	s0,15d4 <printf+0x226>
			continue;
		if (s[1] == 0)
    1418:	0014c783          	lbu	a5,1(s1)
    141c:	14078e63          	beqz	a5,1578 <printf+0x1ca>
			break;
		switch (s[1]) {
    1420:	07300713          	li	a4,115
    1424:	1ce78863          	beq	a5,a4,15f4 <printf+0x246>
    1428:	1af76863          	bltu	a4,a5,15d8 <printf+0x22a>
    142c:	06400713          	li	a4,100
    1430:	22e78063          	beq	a5,a4,1650 <printf+0x2a2>
    1434:	07000713          	li	a4,112
    1438:	1ee79563          	bne	a5,a4,1622 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    143c:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    143e:	00002797          	auipc	a5,0x2
    1442:	98278793          	addi	a5,a5,-1662 # 2dc0 <digits>
	buf[i++] = '0';
    1446:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    144a:	6298                	ld	a4,0(a3)
    144c:	06a1                	addi	a3,a3,8
    144e:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1450:	00471393          	slli	t2,a4,0x4
    1454:	00871293          	slli	t0,a4,0x8
    1458:	00c71f93          	slli	t6,a4,0xc
    145c:	01071f13          	slli	t5,a4,0x10
    1460:	01471e93          	slli	t4,a4,0x14
    1464:	01871e13          	slli	t3,a4,0x18
    1468:	01c71893          	slli	a7,a4,0x1c
    146c:	02471813          	slli	a6,a4,0x24
    1470:	02871513          	slli	a0,a4,0x28
    1474:	02c71593          	slli	a1,a4,0x2c
    1478:	03071613          	slli	a2,a4,0x30
    147c:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1480:	03c75413          	srli	s0,a4,0x3c
    1484:	01c7531b          	srliw	t1,a4,0x1c
    1488:	03c3d393          	srli	t2,t2,0x3c
    148c:	03c2d293          	srli	t0,t0,0x3c
    1490:	03cfdf93          	srli	t6,t6,0x3c
    1494:	03cf5f13          	srli	t5,t5,0x3c
    1498:	03cede93          	srli	t4,t4,0x3c
    149c:	03ce5e13          	srli	t3,t3,0x3c
    14a0:	03c8d893          	srli	a7,a7,0x3c
    14a4:	03c85813          	srli	a6,a6,0x3c
    14a8:	9171                	srli	a0,a0,0x3c
    14aa:	91f1                	srli	a1,a1,0x3c
    14ac:	9271                	srli	a2,a2,0x3c
    14ae:	92f1                	srli	a3,a3,0x3c
    14b0:	95be                	add	a1,a1,a5
    14b2:	963e                	add	a2,a2,a5
    14b4:	96be                	add	a3,a3,a5
    14b6:	943e                	add	s0,s0,a5
    14b8:	93be                	add	t2,t2,a5
    14ba:	92be                	add	t0,t0,a5
    14bc:	9fbe                	add	t6,t6,a5
    14be:	9f3e                	add	t5,t5,a5
    14c0:	9ebe                	add	t4,t4,a5
    14c2:	9e3e                	add	t3,t3,a5
    14c4:	98be                	add	a7,a7,a5
    14c6:	933e                	add	t1,t1,a5
    14c8:	983e                	add	a6,a6,a5
    14ca:	953e                	add	a0,a0,a5
    14cc:	0005c983          	lbu	s3,0(a1)
    14d0:	00044403          	lbu	s0,0(s0)
    14d4:	00064583          	lbu	a1,0(a2)
    14d8:	0003c383          	lbu	t2,0(t2)
    14dc:	0006c603          	lbu	a2,0(a3)
    14e0:	0002c283          	lbu	t0,0(t0)
    14e4:	000fcf83          	lbu	t6,0(t6)
    14e8:	000f4f03          	lbu	t5,0(t5)
    14ec:	000ece83          	lbu	t4,0(t4)
    14f0:	000e4e03          	lbu	t3,0(t3)
    14f4:	0008c883          	lbu	a7,0(a7)
    14f8:	00034303          	lbu	t1,0(t1)
    14fc:	00084803          	lbu	a6,0(a6)
    1500:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1504:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1508:	92f1                	srli	a3,a3,0x3c
    150a:	8b3d                	andi	a4,a4,15
    150c:	96be                	add	a3,a3,a5
    150e:	97ba                	add	a5,a5,a4
    1510:	00810d23          	sb	s0,26(sp)
    1514:	00710da3          	sb	t2,27(sp)
    1518:	00510e23          	sb	t0,28(sp)
    151c:	01f10ea3          	sb	t6,29(sp)
    1520:	01e10f23          	sb	t5,30(sp)
    1524:	01d10fa3          	sb	t4,31(sp)
    1528:	03c10023          	sb	t3,32(sp)
    152c:	031100a3          	sb	a7,33(sp)
    1530:	02610123          	sb	t1,34(sp)
    1534:	030101a3          	sb	a6,35(sp)
    1538:	02a10223          	sb	a0,36(sp)
    153c:	033102a3          	sb	s3,37(sp)
    1540:	02b10323          	sb	a1,38(sp)
    1544:	02c103a3          	sb	a2,39(sp)
    1548:	0006c683          	lbu	a3,0(a3)
    154c:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1550:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1554:	02d10423          	sb	a3,40(sp)
    1558:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    155c:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1560:	11578263          	beq	a5,s5,1664 <printf+0x2b6>
		len = out_unlocked(s, l);
    1564:	45c9                	li	a1,18
    1566:	0828                	addi	a0,sp,24
    1568:	2d2000ef          	jal	ra,183a <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    156c:	00248993          	addi	s3,s1,2
		if (!*s)
    1570:	0009c783          	lbu	a5,0(s3)
    1574:	e6079ee3          	bnez	a5,13f0 <printf+0x42>
	}
	va_end(ap);
    1578:	70e6                	ld	ra,120(sp)
    157a:	7446                	ld	s0,112(sp)
    157c:	74a6                	ld	s1,104(sp)
    157e:	7906                	ld	s2,96(sp)
    1580:	69e6                	ld	s3,88(sp)
    1582:	6a46                	ld	s4,80(sp)
    1584:	6aa6                	ld	s5,72(sp)
    1586:	6b06                	ld	s6,64(sp)
    1588:	6129                	addi	sp,sp,192
    158a:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    158c:	0005c783          	lbu	a5,0(a1)
    1590:	84ae                	mv	s1,a1
    1592:	01278963          	beq	a5,s2,15a4 <printf+0x1f6>
    1596:	b5ad                	j	1400 <printf+0x52>
    1598:	0024c783          	lbu	a5,2(s1)
    159c:	0585                	addi	a1,a1,1
    159e:	0489                	addi	s1,s1,2
    15a0:	e72790e3          	bne	a5,s2,1400 <printf+0x52>
    15a4:	0014c783          	lbu	a5,1(s1)
    15a8:	ff2788e3          	beq	a5,s2,1598 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    15ac:	108a2783          	lw	a5,264(s4)
		l = z - a;
    15b0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    15b4:	e5579ce3          	bne	a5,s5,140c <printf+0x5e>
		mutex_lock(buffer_lock);
    15b8:	10ca2503          	lw	a0,268(s4)
    15bc:	292010ef          	jal	ra,284e <mutex_lock>
		len = out_unlocked(s, l);
    15c0:	85a2                	mv	a1,s0
    15c2:	854e                	mv	a0,s3
    15c4:	276000ef          	jal	ra,183a <out_unlocked>
		mutex_unlock(buffer_lock);
    15c8:	10ca2503          	lw	a0,268(s4)
    15cc:	28e010ef          	jal	ra,285a <mutex_unlock>
		if (l)
    15d0:	e40404e3          	beqz	s0,1418 <printf+0x6a>
    15d4:	89a6                	mv	s3,s1
    15d6:	bd09                	j	13e8 <printf+0x3a>
		switch (s[1]) {
    15d8:	07800713          	li	a4,120
    15dc:	04e79363          	bne	a5,a4,1622 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    15e0:	67c2                	ld	a5,16(sp)
    15e2:	45c1                	li	a1,16
		s += 2;
    15e4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15e8:	4388                	lw	a0,0(a5)
    15ea:	07a1                	addi	a5,a5,8
    15ec:	e83e                	sd	a5,16(sp)
    15ee:	5f8000ef          	jal	ra,1be6 <printint.constprop.0>
		s += 2;
    15f2:	bfbd                	j	1570 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    15f4:	67c2                	ld	a5,16(sp)
    15f6:	6380                	ld	s0,0(a5)
    15f8:	07a1                	addi	a5,a5,8
    15fa:	e83e                	sd	a5,16(sp)
    15fc:	1c040163          	beqz	s0,17be <printf+0x410>
			l = strnlen(a, 200);
    1600:	0c800593          	li	a1,200
    1604:	8522                	mv	a0,s0
    1606:	3f7000ef          	jal	ra,21fc <strnlen>
	if (buffer_lock_enabled == 1) {
    160a:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    160e:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1612:	19578663          	beq	a5,s5,179e <printf+0x3f0>
		len = out_unlocked(s, l);
    1616:	8522                	mv	a0,s0
    1618:	222000ef          	jal	ra,183a <out_unlocked>
		s += 2;
    161c:	00248993          	addi	s3,s1,2
    1620:	bf81                	j	1570 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1622:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1626:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    162a:	0f578663          	beq	a5,s5,1716 <printf+0x368>
		len = out_unlocked(s, l);
    162e:	0828                	addi	a0,sp,24
    1630:	316000ef          	jal	ra,1946 <out_unlocked.constprop.0>
			putchar(s[1]);
    1634:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1638:	108a2783          	lw	a5,264(s4)
	char byte = c;
    163c:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1640:	05578163          	beq	a5,s5,1682 <printf+0x2d4>
		len = out_unlocked(s, l);
    1644:	0828                	addi	a0,sp,24
    1646:	300000ef          	jal	ra,1946 <out_unlocked.constprop.0>
		s += 2;
    164a:	00248993          	addi	s3,s1,2
    164e:	b70d                	j	1570 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1650:	67c2                	ld	a5,16(sp)
    1652:	45a9                	li	a1,10
		s += 2;
    1654:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1658:	4388                	lw	a0,0(a5)
    165a:	07a1                	addi	a5,a5,8
    165c:	e83e                	sd	a5,16(sp)
    165e:	588000ef          	jal	ra,1be6 <printint.constprop.0>
		s += 2;
    1662:	b739                	j	1570 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1664:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1668:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    166c:	1e2010ef          	jal	ra,284e <mutex_lock>
		len = out_unlocked(s, l);
    1670:	45c9                	li	a1,18
    1672:	0828                	addi	a0,sp,24
    1674:	1c6000ef          	jal	ra,183a <out_unlocked>
		mutex_unlock(buffer_lock);
    1678:	10ca2503          	lw	a0,268(s4)
    167c:	1de010ef          	jal	ra,285a <mutex_unlock>
		s += 2;
    1680:	bdc5                	j	1570 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1682:	10ca2503          	lw	a0,268(s4)
    1686:	1c8010ef          	jal	ra,284e <mutex_lock>
		buffer[buffer_len++] = c;
    168a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1692:	0017861b          	addiw	a2,a5,1
    1696:	97d2                	add	a5,a5,s4
    1698:	00ca2023          	sw	a2,0(s4)
    169c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16a0:	00c6cc63          	blt	a3,a2,16b8 <printf+0x30a>
    16a4:	47a9                	li	a5,10
    16a6:	06f40663          	beq	s0,a5,1712 <printf+0x364>
		mutex_unlock(buffer_lock);
    16aa:	10ca2503          	lw	a0,268(s4)
		s += 2;
    16ae:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    16b2:	1a8010ef          	jal	ra,285a <mutex_unlock>
		s += 2;
    16b6:	bd6d                	j	1570 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    16b8:	10000793          	li	a5,256
    16bc:	00f61e63          	bne	a2,a5,16d8 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    16c0:	00001597          	auipc	a1,0x1
    16c4:	43858593          	addi	a1,a1,1080 # 2af8 <buffer>
    16c8:	4505                	li	a0,1
    16ca:	70d000ef          	jal	ra,25d6 <write>
	buffer_len = 0;
    16ce:	00001797          	auipc	a5,0x1
    16d2:	4207a123          	sw	zero,1058(a5) # 2af0 <buffer_len>
			if (r < 0) {
    16d6:	bfd1                	j	16aa <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    16d8:	709000ef          	jal	ra,25e0 <getpid>
    16dc:	842a                	mv	s0,a0
    16de:	00001517          	auipc	a0,0x1
    16e2:	32250513          	addi	a0,a0,802 # 2a00 <enable_deadlock_detect+0x152>
    16e6:	5d1000ef          	jal	ra,24b6 <basename>
    16ea:	872a                	mv	a4,a0
    16ec:	00001617          	auipc	a2,0x1
    16f0:	23460613          	addi	a2,a2,564 # 2920 <enable_deadlock_detect+0x72>
    16f4:	05400793          	li	a5,84
    16f8:	86a2                	mv	a3,s0
    16fa:	45fd                	li	a1,31
    16fc:	00001517          	auipc	a0,0x1
    1700:	34450513          	addi	a0,a0,836 # 2a40 <enable_deadlock_detect+0x192>
    1704:	cabff0ef          	jal	ra,13ae <printf>
    1708:	557d                	li	a0,-1
    170a:	707000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    170e:	000a2603          	lw	a2,0(s4)
    1712:	de41                	beqz	a2,16aa <printf+0x2fc>
    1714:	b775                	j	16c0 <printf+0x312>
		mutex_lock(buffer_lock);
    1716:	10ca2503          	lw	a0,268(s4)
    171a:	134010ef          	jal	ra,284e <mutex_lock>
		buffer[buffer_len++] = c;
    171e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1722:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1726:	0017861b          	addiw	a2,a5,1
    172a:	97d2                	add	a5,a5,s4
    172c:	00ca2023          	sw	a2,0(s4)
    1730:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1734:	02c6d163          	bge	a3,a2,1756 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1738:	10000793          	li	a5,256
    173c:	02f61263          	bne	a2,a5,1760 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1740:	00001597          	auipc	a1,0x1
    1744:	3b858593          	addi	a1,a1,952 # 2af8 <buffer>
    1748:	4505                	li	a0,1
    174a:	68d000ef          	jal	ra,25d6 <write>
	buffer_len = 0;
    174e:	00001797          	auipc	a5,0x1
    1752:	3a07a123          	sw	zero,930(a5) # 2af0 <buffer_len>
		mutex_unlock(buffer_lock);
    1756:	10ca2503          	lw	a0,268(s4)
    175a:	100010ef          	jal	ra,285a <mutex_unlock>
    175e:	bdd9                	j	1634 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1760:	681000ef          	jal	ra,25e0 <getpid>
    1764:	842a                	mv	s0,a0
    1766:	00001517          	auipc	a0,0x1
    176a:	29a50513          	addi	a0,a0,666 # 2a00 <enable_deadlock_detect+0x152>
    176e:	549000ef          	jal	ra,24b6 <basename>
    1772:	872a                	mv	a4,a0
    1774:	00001617          	auipc	a2,0x1
    1778:	1ac60613          	addi	a2,a2,428 # 2920 <enable_deadlock_detect+0x72>
    177c:	05400793          	li	a5,84
    1780:	86a2                	mv	a3,s0
    1782:	45fd                	li	a1,31
    1784:	00001517          	auipc	a0,0x1
    1788:	2bc50513          	addi	a0,a0,700 # 2a40 <enable_deadlock_detect+0x192>
    178c:	c23ff0ef          	jal	ra,13ae <printf>
    1790:	557d                	li	a0,-1
    1792:	67f000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    1796:	000a2603          	lw	a2,0(s4)
    179a:	de55                	beqz	a2,1756 <printf+0x3a8>
    179c:	b755                	j	1740 <printf+0x392>
		mutex_lock(buffer_lock);
    179e:	10ca2503          	lw	a0,268(s4)
    17a2:	e42e                	sd	a1,8(sp)
		s += 2;
    17a4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    17a8:	0a6010ef          	jal	ra,284e <mutex_lock>
		len = out_unlocked(s, l);
    17ac:	65a2                	ld	a1,8(sp)
    17ae:	8522                	mv	a0,s0
    17b0:	08a000ef          	jal	ra,183a <out_unlocked>
		mutex_unlock(buffer_lock);
    17b4:	10ca2503          	lw	a0,268(s4)
    17b8:	0a2010ef          	jal	ra,285a <mutex_unlock>
		s += 2;
    17bc:	bb55                	j	1570 <printf+0x1c2>
				a = "(null)";
    17be:	00001417          	auipc	s0,0x1
    17c2:	23a40413          	addi	s0,s0,570 # 29f8 <enable_deadlock_detect+0x14a>
    17c6:	bd2d                	j	1600 <printf+0x252>

00000000000017c8 <enable_thread_io_buffer>:
{
    17c8:	1101                	addi	sp,sp,-32
    17ca:	e822                	sd	s0,16(sp)
    17cc:	ec06                	sd	ra,24(sp)
    17ce:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    17d0:	00001417          	auipc	s0,0x1
    17d4:	32040413          	addi	s0,s0,800 # 2af0 <buffer_len>
    17d8:	05a010ef          	jal	ra,2832 <mutex_create>
    17dc:	10a42623          	sw	a0,268(s0)
    17e0:	00054a63          	bltz	a0,17f4 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17e4:	4785                	li	a5,1
}
    17e6:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17e8:	10f42423          	sw	a5,264(s0)
}
    17ec:	6442                	ld	s0,16(sp)
    17ee:	64a2                	ld	s1,8(sp)
    17f0:	6105                	addi	sp,sp,32
    17f2:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    17f4:	5ed000ef          	jal	ra,25e0 <getpid>
    17f8:	84aa                	mv	s1,a0
    17fa:	00001517          	auipc	a0,0x1
    17fe:	20650513          	addi	a0,a0,518 # 2a00 <enable_deadlock_detect+0x152>
    1802:	4b5000ef          	jal	ra,24b6 <basename>
    1806:	872a                	mv	a4,a0
    1808:	04800793          	li	a5,72
    180c:	86a6                	mv	a3,s1
    180e:	00001517          	auipc	a0,0x1
    1812:	27250513          	addi	a0,a0,626 # 2a80 <enable_deadlock_detect+0x1d2>
    1816:	00001617          	auipc	a2,0x1
    181a:	10a60613          	addi	a2,a2,266 # 2920 <enable_deadlock_detect+0x72>
    181e:	45fd                	li	a1,31
    1820:	b8fff0ef          	jal	ra,13ae <printf>
    1824:	557d                	li	a0,-1
    1826:	5eb000ef          	jal	ra,2610 <exit>
	buffer_lock_enabled = 1;
    182a:	4785                	li	a5,1
}
    182c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    182e:	10f42423          	sw	a5,264(s0)
}
    1832:	6442                	ld	s0,16(sp)
    1834:	64a2                	ld	s1,8(sp)
    1836:	6105                	addi	sp,sp,32
    1838:	8082                	ret

000000000000183a <out_unlocked>:
{
    183a:	7159                	addi	sp,sp,-112
    183c:	f486                	sd	ra,104(sp)
    183e:	f0a2                	sd	s0,96(sp)
    1840:	eca6                	sd	s1,88(sp)
    1842:	e8ca                	sd	s2,80(sp)
    1844:	e4ce                	sd	s3,72(sp)
    1846:	e0d2                	sd	s4,64(sp)
    1848:	fc56                	sd	s5,56(sp)
    184a:	f85a                	sd	s6,48(sp)
    184c:	f45e                	sd	s7,40(sp)
    184e:	f062                	sd	s8,32(sp)
    1850:	ec66                	sd	s9,24(sp)
    1852:	e86a                	sd	s10,16(sp)
    1854:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1856:	0e058663          	beqz	a1,1942 <out_unlocked+0x108>
    185a:	842a                	mv	s0,a0
    185c:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1860:	4981                	li	s3,0
    1862:	00001d17          	auipc	s10,0x1
    1866:	28ed0d13          	addi	s10,s10,654 # 2af0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    186a:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    186e:	00001b17          	auipc	s6,0x1
    1872:	28ab0b13          	addi	s6,s6,650 # 2af8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1876:	10000a93          	li	s5,256
    187a:	00001c97          	auipc	s9,0x1
    187e:	186c8c93          	addi	s9,s9,390 # 2a00 <enable_deadlock_detect+0x152>
    1882:	00001c17          	auipc	s8,0x1
    1886:	09ec0c13          	addi	s8,s8,158 # 2920 <enable_deadlock_detect+0x72>
    188a:	00001b97          	auipc	s7,0x1
    188e:	1b6b8b93          	addi	s7,s7,438 # 2a40 <enable_deadlock_detect+0x192>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1892:	4a29                	li	s4,10
    1894:	a031                	j	18a0 <out_unlocked+0x66>
    1896:	09468863          	beq	a3,s4,1926 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    189a:	0405                	addi	s0,s0,1
    189c:	04848163          	beq	s1,s0,18de <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    18a0:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    18a4:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    18a8:	0017861b          	addiw	a2,a5,1
    18ac:	97ea                	add	a5,a5,s10
    18ae:	00cd2023          	sw	a2,0(s10)
    18b2:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b6:	fec950e3          	bge	s2,a2,1896 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    18ba:	05561263          	bne	a2,s5,18fe <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    18be:	85da                	mv	a1,s6
    18c0:	4505                	li	a0,1
    18c2:	515000ef          	jal	ra,25d6 <write>
    18c6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18c8:	00001797          	auipc	a5,0x1
    18cc:	2207a423          	sw	zero,552(a5) # 2af0 <buffer_len>
			if (r < 0) {
    18d0:	06054763          	bltz	a0,193e <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    18d4:	0405                	addi	s0,s0,1
			ret += r;
    18d6:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    18da:	fc8493e3          	bne	s1,s0,18a0 <out_unlocked+0x66>
}
    18de:	70a6                	ld	ra,104(sp)
    18e0:	7406                	ld	s0,96(sp)
    18e2:	64e6                	ld	s1,88(sp)
    18e4:	6946                	ld	s2,80(sp)
    18e6:	6a06                	ld	s4,64(sp)
    18e8:	7ae2                	ld	s5,56(sp)
    18ea:	7b42                	ld	s6,48(sp)
    18ec:	7ba2                	ld	s7,40(sp)
    18ee:	7c02                	ld	s8,32(sp)
    18f0:	6ce2                	ld	s9,24(sp)
    18f2:	6d42                	ld	s10,16(sp)
    18f4:	6da2                	ld	s11,8(sp)
    18f6:	854e                	mv	a0,s3
    18f8:	69a6                	ld	s3,72(sp)
    18fa:	6165                	addi	sp,sp,112
    18fc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18fe:	4e3000ef          	jal	ra,25e0 <getpid>
    1902:	8daa                	mv	s11,a0
    1904:	8566                	mv	a0,s9
    1906:	3b1000ef          	jal	ra,24b6 <basename>
    190a:	872a                	mv	a4,a0
    190c:	8662                	mv	a2,s8
    190e:	05400793          	li	a5,84
    1912:	86ee                	mv	a3,s11
    1914:	45fd                	li	a1,31
    1916:	855e                	mv	a0,s7
    1918:	a97ff0ef          	jal	ra,13ae <printf>
    191c:	557d                	li	a0,-1
    191e:	4f3000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    1922:	000d2603          	lw	a2,0(s10)
    1926:	da35                	beqz	a2,189a <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1928:	85da                	mv	a1,s6
    192a:	4505                	li	a0,1
    192c:	4ab000ef          	jal	ra,25d6 <write>
    1930:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1932:	00001797          	auipc	a5,0x1
    1936:	1a07af23          	sw	zero,446(a5) # 2af0 <buffer_len>
			if (r < 0) {
    193a:	f8055de3          	bgez	a0,18d4 <out_unlocked+0x9a>
    193e:	89aa                	mv	s3,a0
    1940:	bf79                	j	18de <out_unlocked+0xa4>
	int ret = 0;
    1942:	4981                	li	s3,0
    1944:	bf69                	j	18de <out_unlocked+0xa4>

0000000000001946 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1946:	1101                	addi	sp,sp,-32
    1948:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    194a:	00001497          	auipc	s1,0x1
    194e:	1a648493          	addi	s1,s1,422 # 2af0 <buffer_len>
    1952:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1954:	ec06                	sd	ra,24(sp)
    1956:	e822                	sd	s0,16(sp)
		char c = s[i];
    1958:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    195c:	0017861b          	addiw	a2,a5,1
    1960:	97a6                	add	a5,a5,s1
    1962:	00e78423          	sb	a4,8(a5)
    1966:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1968:	0ff00793          	li	a5,255
    196c:	00c7cc63          	blt	a5,a2,1984 <out_unlocked.constprop.0+0x3e>
    1970:	47a9                	li	a5,10
    1972:	06f70c63          	beq	a4,a5,19ea <out_unlocked.constprop.0+0xa4>
    1976:	4601                	li	a2,0
}
    1978:	60e2                	ld	ra,24(sp)
    197a:	6442                	ld	s0,16(sp)
    197c:	64a2                	ld	s1,8(sp)
    197e:	8532                	mv	a0,a2
    1980:	6105                	addi	sp,sp,32
    1982:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1984:	10000793          	li	a5,256
    1988:	02f61563          	bne	a2,a5,19b2 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    198c:	00001597          	auipc	a1,0x1
    1990:	16c58593          	addi	a1,a1,364 # 2af8 <buffer>
    1994:	4505                	li	a0,1
    1996:	441000ef          	jal	ra,25d6 <write>
}
    199a:	60e2                	ld	ra,24(sp)
    199c:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    199e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19a2:	00001797          	auipc	a5,0x1
    19a6:	1407a723          	sw	zero,334(a5) # 2af0 <buffer_len>
}
    19aa:	64a2                	ld	s1,8(sp)
    19ac:	8532                	mv	a0,a2
    19ae:	6105                	addi	sp,sp,32
    19b0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19b2:	42f000ef          	jal	ra,25e0 <getpid>
    19b6:	842a                	mv	s0,a0
    19b8:	00001517          	auipc	a0,0x1
    19bc:	04850513          	addi	a0,a0,72 # 2a00 <enable_deadlock_detect+0x152>
    19c0:	2f7000ef          	jal	ra,24b6 <basename>
    19c4:	872a                	mv	a4,a0
    19c6:	00001617          	auipc	a2,0x1
    19ca:	f5a60613          	addi	a2,a2,-166 # 2920 <enable_deadlock_detect+0x72>
    19ce:	05400793          	li	a5,84
    19d2:	86a2                	mv	a3,s0
    19d4:	45fd                	li	a1,31
    19d6:	00001517          	auipc	a0,0x1
    19da:	06a50513          	addi	a0,a0,106 # 2a40 <enable_deadlock_detect+0x192>
    19de:	9d1ff0ef          	jal	ra,13ae <printf>
    19e2:	557d                	li	a0,-1
    19e4:	42d000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    19e8:	4090                	lw	a2,0(s1)
    19ea:	d659                	beqz	a2,1978 <out_unlocked.constprop.0+0x32>
    19ec:	b745                	j	198c <out_unlocked.constprop.0+0x46>

00000000000019ee <putchar>:
{
    19ee:	7139                	addi	sp,sp,-64
    19f0:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19f2:	00001497          	auipc	s1,0x1
    19f6:	0fe48493          	addi	s1,s1,254 # 2af0 <buffer_len>
    19fa:	1084a703          	lw	a4,264(s1)
{
    19fe:	f822                	sd	s0,48(sp)
	char byte = c;
    1a00:	0ff57413          	zext.b	s0,a0
{
    1a04:	fc06                	sd	ra,56(sp)
	char byte = c;
    1a06:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1a0a:	4785                	li	a5,1
    1a0c:	00f70d63          	beq	a4,a5,1a26 <putchar+0x38>
		len = out_unlocked(s, l);
    1a10:	01f10513          	addi	a0,sp,31
    1a14:	f33ff0ef          	jal	ra,1946 <out_unlocked.constprop.0>
}
    1a18:	70e2                	ld	ra,56(sp)
    1a1a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1a1c:	862a                	mv	a2,a0
}
    1a1e:	74a2                	ld	s1,40(sp)
    1a20:	8532                	mv	a0,a2
    1a22:	6121                	addi	sp,sp,64
    1a24:	8082                	ret
		mutex_lock(buffer_lock);
    1a26:	10c4a503          	lw	a0,268(s1)
    1a2a:	625000ef          	jal	ra,284e <mutex_lock>
		buffer[buffer_len++] = c;
    1a2e:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a30:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a34:	0017861b          	addiw	a2,a5,1
    1a38:	97a6                	add	a5,a5,s1
    1a3a:	c090                	sw	a2,0(s1)
    1a3c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a40:	02c6c263          	blt	a3,a2,1a64 <putchar+0x76>
    1a44:	47a9                	li	a5,10
    1a46:	06f40d63          	beq	s0,a5,1ac0 <putchar+0xd2>
    1a4a:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a4c:	10c4a503          	lw	a0,268(s1)
    1a50:	e432                	sd	a2,8(sp)
    1a52:	609000ef          	jal	ra,285a <mutex_unlock>
    1a56:	6622                	ld	a2,8(sp)
}
    1a58:	70e2                	ld	ra,56(sp)
    1a5a:	7442                	ld	s0,48(sp)
    1a5c:	74a2                	ld	s1,40(sp)
    1a5e:	8532                	mv	a0,a2
    1a60:	6121                	addi	sp,sp,64
    1a62:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a64:	10000793          	li	a5,256
    1a68:	02f61063          	bne	a2,a5,1a88 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a6c:	00001597          	auipc	a1,0x1
    1a70:	08c58593          	addi	a1,a1,140 # 2af8 <buffer>
    1a74:	4505                	li	a0,1
    1a76:	361000ef          	jal	ra,25d6 <write>
    1a7a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a7e:	00001797          	auipc	a5,0x1
    1a82:	0607a923          	sw	zero,114(a5) # 2af0 <buffer_len>
			if (r < 0) {
    1a86:	b7d9                	j	1a4c <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a88:	359000ef          	jal	ra,25e0 <getpid>
    1a8c:	842a                	mv	s0,a0
    1a8e:	00001517          	auipc	a0,0x1
    1a92:	f7250513          	addi	a0,a0,-142 # 2a00 <enable_deadlock_detect+0x152>
    1a96:	221000ef          	jal	ra,24b6 <basename>
    1a9a:	872a                	mv	a4,a0
    1a9c:	00001617          	auipc	a2,0x1
    1aa0:	e8460613          	addi	a2,a2,-380 # 2920 <enable_deadlock_detect+0x72>
    1aa4:	05400793          	li	a5,84
    1aa8:	86a2                	mv	a3,s0
    1aaa:	45fd                	li	a1,31
    1aac:	00001517          	auipc	a0,0x1
    1ab0:	f9450513          	addi	a0,a0,-108 # 2a40 <enable_deadlock_detect+0x192>
    1ab4:	8fbff0ef          	jal	ra,13ae <printf>
    1ab8:	557d                	li	a0,-1
    1aba:	357000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    1abe:	4090                	lw	a2,0(s1)
    1ac0:	d651                	beqz	a2,1a4c <putchar+0x5e>
    1ac2:	b76d                	j	1a6c <putchar+0x7e>

0000000000001ac4 <puts>:
{
    1ac4:	7139                	addi	sp,sp,-64
    1ac6:	f822                	sd	s0,48(sp)
    1ac8:	f426                	sd	s1,40(sp)
    1aca:	fc06                	sd	ra,56(sp)
    1acc:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1ace:	00001417          	auipc	s0,0x1
    1ad2:	02240413          	addi	s0,s0,34 # 2af0 <buffer_len>
{
    1ad6:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ad8:	638000ef          	jal	ra,2110 <strlen>
	if (buffer_lock_enabled == 1) {
    1adc:	10842703          	lw	a4,264(s0)
    1ae0:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ae2:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1ae4:	04f70563          	beq	a4,a5,1b2e <puts+0x6a>
		len = out_unlocked(s, l);
    1ae8:	8526                	mv	a0,s1
    1aea:	d51ff0ef          	jal	ra,183a <out_unlocked>
    1aee:	892a                	mv	s2,a0
    1af0:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1af2:	00095963          	bgez	s2,1b04 <puts+0x40>
}
    1af6:	70e2                	ld	ra,56(sp)
    1af8:	7442                	ld	s0,48(sp)
    1afa:	7902                	ld	s2,32(sp)
    1afc:	8526                	mv	a0,s1
    1afe:	74a2                	ld	s1,40(sp)
    1b00:	6121                	addi	sp,sp,64
    1b02:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1b04:	10842703          	lw	a4,264(s0)
	char byte = c;
    1b08:	44a9                	li	s1,10
    1b0a:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1b0e:	4785                	li	a5,1
    1b10:	02f70e63          	beq	a4,a5,1b4c <puts+0x88>
		len = out_unlocked(s, l);
    1b14:	01f10513          	addi	a0,sp,31
    1b18:	e2fff0ef          	jal	ra,1946 <out_unlocked.constprop.0>
}
    1b1c:	70e2                	ld	ra,56(sp)
    1b1e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b20:	41f5549b          	sraiw	s1,a0,0x1f
}
    1b24:	7902                	ld	s2,32(sp)
    1b26:	8526                	mv	a0,s1
    1b28:	74a2                	ld	s1,40(sp)
    1b2a:	6121                	addi	sp,sp,64
    1b2c:	8082                	ret
		mutex_lock(buffer_lock);
    1b2e:	e42a                	sd	a0,8(sp)
    1b30:	10c42503          	lw	a0,268(s0)
    1b34:	51b000ef          	jal	ra,284e <mutex_lock>
		len = out_unlocked(s, l);
    1b38:	65a2                	ld	a1,8(sp)
    1b3a:	8526                	mv	a0,s1
    1b3c:	cffff0ef          	jal	ra,183a <out_unlocked>
    1b40:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b42:	10c42503          	lw	a0,268(s0)
    1b46:	515000ef          	jal	ra,285a <mutex_unlock>
    1b4a:	b75d                	j	1af0 <puts+0x2c>
		mutex_lock(buffer_lock);
    1b4c:	10c42503          	lw	a0,268(s0)
    1b50:	4ff000ef          	jal	ra,284e <mutex_lock>
		buffer[buffer_len++] = c;
    1b54:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b56:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b5a:	0017861b          	addiw	a2,a5,1
    1b5e:	97a2                	add	a5,a5,s0
    1b60:	c010                	sw	a2,0(s0)
    1b62:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b66:	06c6dc63          	bge	a3,a2,1bde <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b6a:	10000793          	li	a5,256
    1b6e:	02f61c63          	bne	a2,a5,1ba6 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b72:	00001597          	auipc	a1,0x1
    1b76:	f8658593          	addi	a1,a1,-122 # 2af8 <buffer>
    1b7a:	4505                	li	a0,1
    1b7c:	25b000ef          	jal	ra,25d6 <write>
			if (r < 0) {
    1b80:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b82:	00001797          	auipc	a5,0x1
    1b86:	f607a723          	sw	zero,-146(a5) # 2af0 <buffer_len>
			if (r < 0) {
    1b8a:	04054c63          	bltz	a0,1be2 <puts+0x11e>
			if (r < buffer_len) {
    1b8e:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b90:	10c42503          	lw	a0,268(s0)
    1b94:	4c7000ef          	jal	ra,285a <mutex_unlock>
}
    1b98:	70e2                	ld	ra,56(sp)
    1b9a:	7442                	ld	s0,48(sp)
    1b9c:	7902                	ld	s2,32(sp)
    1b9e:	8526                	mv	a0,s1
    1ba0:	74a2                	ld	s1,40(sp)
    1ba2:	6121                	addi	sp,sp,64
    1ba4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1ba6:	23b000ef          	jal	ra,25e0 <getpid>
    1baa:	84aa                	mv	s1,a0
    1bac:	00001517          	auipc	a0,0x1
    1bb0:	e5450513          	addi	a0,a0,-428 # 2a00 <enable_deadlock_detect+0x152>
    1bb4:	103000ef          	jal	ra,24b6 <basename>
    1bb8:	872a                	mv	a4,a0
    1bba:	00001617          	auipc	a2,0x1
    1bbe:	d6660613          	addi	a2,a2,-666 # 2920 <enable_deadlock_detect+0x72>
    1bc2:	05400793          	li	a5,84
    1bc6:	86a6                	mv	a3,s1
    1bc8:	45fd                	li	a1,31
    1bca:	00001517          	auipc	a0,0x1
    1bce:	e7650513          	addi	a0,a0,-394 # 2a40 <enable_deadlock_detect+0x192>
    1bd2:	fdcff0ef          	jal	ra,13ae <printf>
    1bd6:	557d                	li	a0,-1
    1bd8:	239000ef          	jal	ra,2610 <exit>
	if (buffer_len == 0)
    1bdc:	4010                	lw	a2,0(s0)
    1bde:	da45                	beqz	a2,1b8e <puts+0xca>
    1be0:	bf49                	j	1b72 <puts+0xae>
    1be2:	54fd                	li	s1,-1
    1be4:	b775                	j	1b90 <puts+0xcc>

0000000000001be6 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1be6:	715d                	addi	sp,sp,-80
    1be8:	e486                	sd	ra,72(sp)
    1bea:	e0a2                	sd	s0,64(sp)
    1bec:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1bee:	14054363          	bltz	a0,1d34 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bf2:	02b577bb          	remuw	a5,a0,a1
    1bf6:	00001617          	auipc	a2,0x1
    1bfa:	1ca60613          	addi	a2,a2,458 # 2dc0 <digits>
	buf[16] = 0;
    1bfe:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c02:	0005871b          	sext.w	a4,a1
    1c06:	1782                	slli	a5,a5,0x20
    1c08:	9381                	srli	a5,a5,0x20
    1c0a:	97b2                	add	a5,a5,a2
    1c0c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c10:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1c14:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1c18:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1c1a:	0eb56763          	bltu	a0,a1,1d08 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c1e:	02e877bb          	remuw	a5,a6,a4
    1c22:	1782                	slli	a5,a5,0x20
    1c24:	9381                	srli	a5,a5,0x20
    1c26:	97b2                	add	a5,a5,a2
    1c28:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c2c:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1c30:	02f10323          	sb	a5,38(sp)
    1c34:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1c36:	0ce86963          	bltu	a6,a4,1d08 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c3a:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c3e:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c42:	1582                	slli	a1,a1,0x20
    1c44:	9181                	srli	a1,a1,0x20
    1c46:	95b2                	add	a1,a1,a2
    1c48:	0005c583          	lbu	a1,0(a1)
    1c4c:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c50:	0007859b          	sext.w	a1,a5
    1c54:	16e6e563          	bltu	a3,a4,1dbe <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c58:	02e7f6bb          	remuw	a3,a5,a4
    1c5c:	1682                	slli	a3,a3,0x20
    1c5e:	9281                	srli	a3,a3,0x20
    1c60:	96b2                	add	a3,a3,a2
    1c62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c66:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c6a:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c6e:	16e5e163          	bltu	a1,a4,1dd0 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c72:	02e876bb          	remuw	a3,a6,a4
    1c76:	1682                	slli	a3,a3,0x20
    1c78:	9281                	srli	a3,a3,0x20
    1c7a:	96b2                	add	a3,a3,a2
    1c7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c80:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c84:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c88:	14e86d63          	bltu	a6,a4,1de2 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c8c:	02e5f6bb          	remuw	a3,a1,a4
    1c90:	1682                	slli	a3,a3,0x20
    1c92:	9281                	srli	a3,a3,0x20
    1c94:	96b2                	add	a3,a3,a2
    1c96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c9a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c9e:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ca2:	10e5e563          	bltu	a1,a4,1dac <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ca6:	02e876bb          	remuw	a3,a6,a4
    1caa:	1682                	slli	a3,a3,0x20
    1cac:	9281                	srli	a3,a3,0x20
    1cae:	96b2                	add	a3,a3,a2
    1cb0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cb4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cb8:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1cbc:	14e86263          	bltu	a6,a4,1e00 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1cc0:	02e5f6bb          	remuw	a3,a1,a4
    1cc4:	1682                	slli	a3,a3,0x20
    1cc6:	9281                	srli	a3,a3,0x20
    1cc8:	96b2                	add	a3,a3,a2
    1cca:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cce:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1cd2:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1cd6:	14e5e463          	bltu	a1,a4,1e1e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1cda:	02e876bb          	remuw	a3,a6,a4
    1cde:	1682                	slli	a3,a3,0x20
    1ce0:	9281                	srli	a3,a3,0x20
    1ce2:	96b2                	add	a3,a3,a2
    1ce4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ce8:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1cec:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cf0:	14e86063          	bltu	a6,a4,1e30 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1cf4:	1782                	slli	a5,a5,0x20
    1cf6:	9381                	srli	a5,a5,0x20
    1cf8:	97b2                	add	a5,a5,a2
    1cfa:	0007c703          	lbu	a4,0(a5)
    1cfe:	4799                	li	a5,6
    1d00:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1d04:	10054763          	bltz	a0,1e12 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1d08:	00001497          	auipc	s1,0x1
    1d0c:	de848493          	addi	s1,s1,-536 # 2af0 <buffer_len>
    1d10:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1d14:	0828                	addi	a0,sp,24
    1d16:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1d18:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1d1a:	00f50433          	add	s0,a0,a5
    1d1e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1d20:	06e68463          	beq	a3,a4,1d88 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1d24:	8522                	mv	a0,s0
    1d26:	b15ff0ef          	jal	ra,183a <out_unlocked>
}
    1d2a:	60a6                	ld	ra,72(sp)
    1d2c:	6406                	ld	s0,64(sp)
    1d2e:	74e2                	ld	s1,56(sp)
    1d30:	6161                	addi	sp,sp,80
    1d32:	8082                	ret
		x = -xx;
    1d34:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d38:	02b877bb          	remuw	a5,a6,a1
    1d3c:	00001617          	auipc	a2,0x1
    1d40:	08460613          	addi	a2,a2,132 # 2dc0 <digits>
	buf[16] = 0;
    1d44:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d48:	0005871b          	sext.w	a4,a1
    1d4c:	1782                	slli	a5,a5,0x20
    1d4e:	9381                	srli	a5,a5,0x20
    1d50:	97b2                	add	a5,a5,a2
    1d52:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d56:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d5a:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d5e:	08b86b63          	bltu	a6,a1,1df4 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d62:	02e8f7bb          	remuw	a5,a7,a4
    1d66:	1782                	slli	a5,a5,0x20
    1d68:	9381                	srli	a5,a5,0x20
    1d6a:	97b2                	add	a5,a5,a2
    1d6c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d70:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d74:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d78:	ece8f1e3          	bgeu	a7,a4,1c3a <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d7c:	02d00793          	li	a5,45
    1d80:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d84:	47b5                	li	a5,13
    1d86:	b749                	j	1d08 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d88:	10c4a503          	lw	a0,268(s1)
    1d8c:	e42e                	sd	a1,8(sp)
    1d8e:	2c1000ef          	jal	ra,284e <mutex_lock>
		len = out_unlocked(s, l);
    1d92:	65a2                	ld	a1,8(sp)
    1d94:	8522                	mv	a0,s0
    1d96:	aa5ff0ef          	jal	ra,183a <out_unlocked>
		mutex_unlock(buffer_lock);
    1d9a:	10c4a503          	lw	a0,268(s1)
    1d9e:	2bd000ef          	jal	ra,285a <mutex_unlock>
}
    1da2:	60a6                	ld	ra,72(sp)
    1da4:	6406                	ld	s0,64(sp)
    1da6:	74e2                	ld	s1,56(sp)
    1da8:	6161                	addi	sp,sp,80
    1daa:	8082                	ret
		buf[i--] = digits[x % base];
    1dac:	47a9                	li	a5,10
	if (sign)
    1dae:	f4055de3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1db2:	02d00793          	li	a5,45
    1db6:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1dba:	47a5                	li	a5,9
    1dbc:	b7b1                	j	1d08 <printint.constprop.0+0x122>
    1dbe:	47b5                	li	a5,13
	if (sign)
    1dc0:	f40554e3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dc4:	02d00793          	li	a5,45
    1dc8:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1dcc:	47b1                	li	a5,12
    1dce:	bf2d                	j	1d08 <printint.constprop.0+0x122>
    1dd0:	47b1                	li	a5,12
	if (sign)
    1dd2:	f2055be3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dd6:	02d00793          	li	a5,45
    1dda:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1dde:	47ad                	li	a5,11
    1de0:	b725                	j	1d08 <printint.constprop.0+0x122>
    1de2:	47ad                	li	a5,11
	if (sign)
    1de4:	f20552e3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de8:	02d00793          	li	a5,45
    1dec:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1df0:	47a9                	li	a5,10
    1df2:	bf19                	j	1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1df4:	02d00793          	li	a5,45
    1df8:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1dfc:	47b9                	li	a5,14
    1dfe:	b729                	j	1d08 <printint.constprop.0+0x122>
    1e00:	47a5                	li	a5,9
	if (sign)
    1e02:	f00553e3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e06:	02d00793          	li	a5,45
    1e0a:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1e0e:	47a1                	li	a5,8
    1e10:	bde5                	j	1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e12:	02d00793          	li	a5,45
    1e16:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1e1a:	4795                	li	a5,5
    1e1c:	b5f5                	j	1d08 <printint.constprop.0+0x122>
    1e1e:	47a1                	li	a5,8
	if (sign)
    1e20:	ee0554e3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e24:	02d00793          	li	a5,45
    1e28:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1e2c:	479d                	li	a5,7
    1e2e:	bde9                	j	1d08 <printint.constprop.0+0x122>
    1e30:	479d                	li	a5,7
	if (sign)
    1e32:	ec055be3          	bgez	a0,1d08 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e36:	02d00793          	li	a5,45
    1e3a:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e3e:	4799                	li	a5,6
    1e40:	b5e1                	j	1d08 <printint.constprop.0+0x122>

0000000000001e42 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e42:	02000793          	li	a5,32
    1e46:	00f50663          	beq	a0,a5,1e52 <isspace+0x10>
    1e4a:	355d                	addiw	a0,a0,-9
    1e4c:	00553513          	sltiu	a0,a0,5
    1e50:	8082                	ret
    1e52:	4505                	li	a0,1
}
    1e54:	8082                	ret

0000000000001e56 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e56:	fd05051b          	addiw	a0,a0,-48
}
    1e5a:	00a53513          	sltiu	a0,a0,10
    1e5e:	8082                	ret

0000000000001e60 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e60:	02000613          	li	a2,32
    1e64:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e66:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e6a:	ff77869b          	addiw	a3,a5,-9
    1e6e:	04c78c63          	beq	a5,a2,1ec6 <atoi+0x66>
    1e72:	0007871b          	sext.w	a4,a5
    1e76:	04d5f863          	bgeu	a1,a3,1ec6 <atoi+0x66>
		s++;
	switch (*s) {
    1e7a:	02b00693          	li	a3,43
    1e7e:	04d78963          	beq	a5,a3,1ed0 <atoi+0x70>
    1e82:	02d00693          	li	a3,45
    1e86:	06d78263          	beq	a5,a3,1eea <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e8a:	fd07061b          	addiw	a2,a4,-48
    1e8e:	47a5                	li	a5,9
    1e90:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e92:	4e01                	li	t3,0
	while (isdigit(*s))
    1e94:	04c7e963          	bltu	a5,a2,1ee6 <atoi+0x86>
	int n = 0, neg = 0;
    1e98:	4501                	li	a0,0
	while (isdigit(*s))
    1e9a:	4825                	li	a6,9
    1e9c:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1ea0:	0025179b          	slliw	a5,a0,0x2
    1ea4:	9fa9                	addw	a5,a5,a0
    1ea6:	fd07031b          	addiw	t1,a4,-48
    1eaa:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1eae:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1eb2:	0685                	addi	a3,a3,1
    1eb4:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1eb8:	0006071b          	sext.w	a4,a2
    1ebc:	feb870e3          	bgeu	a6,a1,1e9c <atoi+0x3c>
	return neg ? n : -n;
    1ec0:	000e0563          	beqz	t3,1eca <atoi+0x6a>
}
    1ec4:	8082                	ret
		s++;
    1ec6:	0505                	addi	a0,a0,1
    1ec8:	bf79                	j	1e66 <atoi+0x6>
	return neg ? n : -n;
    1eca:	4113053b          	subw	a0,t1,a7
    1ece:	8082                	ret
	while (isdigit(*s))
    1ed0:	00154703          	lbu	a4,1(a0)
    1ed4:	47a5                	li	a5,9
		s++;
    1ed6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1eda:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1ede:	4e01                	li	t3,0
	while (isdigit(*s))
    1ee0:	2701                	sext.w	a4,a4
    1ee2:	fac7fbe3          	bgeu	a5,a2,1e98 <atoi+0x38>
    1ee6:	4501                	li	a0,0
}
    1ee8:	8082                	ret
	while (isdigit(*s))
    1eea:	00154703          	lbu	a4,1(a0)
    1eee:	47a5                	li	a5,9
		s++;
    1ef0:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ef4:	fd07061b          	addiw	a2,a4,-48
    1ef8:	2701                	sext.w	a4,a4
    1efa:	fec7e6e3          	bltu	a5,a2,1ee6 <atoi+0x86>
		neg = 1;
    1efe:	4e05                	li	t3,1
    1f00:	bf61                	j	1e98 <atoi+0x38>

0000000000001f02 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f02:	16060d63          	beqz	a2,207c <memset+0x17a>
    1f06:	40a007b3          	neg	a5,a0
    1f0a:	8b9d                	andi	a5,a5,7
    1f0c:	00778693          	addi	a3,a5,7
    1f10:	482d                	li	a6,11
    1f12:	0ff5f713          	zext.b	a4,a1
    1f16:	fff60593          	addi	a1,a2,-1
    1f1a:	1706e263          	bltu	a3,a6,207e <memset+0x17c>
    1f1e:	16d5ea63          	bltu	a1,a3,2092 <memset+0x190>
    1f22:	16078563          	beqz	a5,208c <memset+0x18a>
    1f26:	00e50023          	sb	a4,0(a0)
    1f2a:	4685                	li	a3,1
    1f2c:	00150593          	addi	a1,a0,1
    1f30:	14d78c63          	beq	a5,a3,2088 <memset+0x186>
    1f34:	00e500a3          	sb	a4,1(a0)
    1f38:	4689                	li	a3,2
    1f3a:	00250593          	addi	a1,a0,2
    1f3e:	14d78d63          	beq	a5,a3,2098 <memset+0x196>
    1f42:	00e50123          	sb	a4,2(a0)
    1f46:	468d                	li	a3,3
    1f48:	00350593          	addi	a1,a0,3
    1f4c:	12d78b63          	beq	a5,a3,2082 <memset+0x180>
    1f50:	00e501a3          	sb	a4,3(a0)
    1f54:	4691                	li	a3,4
    1f56:	00450593          	addi	a1,a0,4
    1f5a:	14d78163          	beq	a5,a3,209c <memset+0x19a>
    1f5e:	00e50223          	sb	a4,4(a0)
    1f62:	4695                	li	a3,5
    1f64:	00550593          	addi	a1,a0,5
    1f68:	12d78c63          	beq	a5,a3,20a0 <memset+0x19e>
    1f6c:	00e502a3          	sb	a4,5(a0)
    1f70:	469d                	li	a3,7
    1f72:	00650593          	addi	a1,a0,6
    1f76:	12d79763          	bne	a5,a3,20a4 <memset+0x1a2>
    1f7a:	00750593          	addi	a1,a0,7
    1f7e:	00e50323          	sb	a4,6(a0)
    1f82:	481d                	li	a6,7
    1f84:	00871693          	slli	a3,a4,0x8
    1f88:	01071893          	slli	a7,a4,0x10
    1f8c:	8ed9                	or	a3,a3,a4
    1f8e:	01871313          	slli	t1,a4,0x18
    1f92:	0116e6b3          	or	a3,a3,a7
    1f96:	0066e6b3          	or	a3,a3,t1
    1f9a:	02071893          	slli	a7,a4,0x20
    1f9e:	02871e13          	slli	t3,a4,0x28
    1fa2:	0116e6b3          	or	a3,a3,a7
    1fa6:	40f60333          	sub	t1,a2,a5
    1faa:	03071893          	slli	a7,a4,0x30
    1fae:	01c6e6b3          	or	a3,a3,t3
    1fb2:	0116e6b3          	or	a3,a3,a7
    1fb6:	03871e13          	slli	t3,a4,0x38
    1fba:	97aa                	add	a5,a5,a0
    1fbc:	ff837893          	andi	a7,t1,-8
    1fc0:	01c6e6b3          	or	a3,a3,t3
    1fc4:	98be                	add	a7,a7,a5
    1fc6:	e394                	sd	a3,0(a5)
    1fc8:	07a1                	addi	a5,a5,8
    1fca:	ff179ee3          	bne	a5,a7,1fc6 <memset+0xc4>
    1fce:	ff837893          	andi	a7,t1,-8
    1fd2:	011587b3          	add	a5,a1,a7
    1fd6:	010886bb          	addw	a3,a7,a6
    1fda:	0b130663          	beq	t1,a7,2086 <memset+0x184>
    1fde:	00e78023          	sb	a4,0(a5)
    1fe2:	0016859b          	addiw	a1,a3,1
    1fe6:	08c5fb63          	bgeu	a1,a2,207c <memset+0x17a>
    1fea:	00e780a3          	sb	a4,1(a5)
    1fee:	0026859b          	addiw	a1,a3,2
    1ff2:	08c5f563          	bgeu	a1,a2,207c <memset+0x17a>
    1ff6:	00e78123          	sb	a4,2(a5)
    1ffa:	0036859b          	addiw	a1,a3,3
    1ffe:	06c5ff63          	bgeu	a1,a2,207c <memset+0x17a>
    2002:	00e781a3          	sb	a4,3(a5)
    2006:	0046859b          	addiw	a1,a3,4
    200a:	06c5f963          	bgeu	a1,a2,207c <memset+0x17a>
    200e:	00e78223          	sb	a4,4(a5)
    2012:	0056859b          	addiw	a1,a3,5
    2016:	06c5f363          	bgeu	a1,a2,207c <memset+0x17a>
    201a:	00e782a3          	sb	a4,5(a5)
    201e:	0066859b          	addiw	a1,a3,6
    2022:	04c5fd63          	bgeu	a1,a2,207c <memset+0x17a>
    2026:	00e78323          	sb	a4,6(a5)
    202a:	0076859b          	addiw	a1,a3,7
    202e:	04c5f763          	bgeu	a1,a2,207c <memset+0x17a>
    2032:	00e783a3          	sb	a4,7(a5)
    2036:	0086859b          	addiw	a1,a3,8
    203a:	04c5f163          	bgeu	a1,a2,207c <memset+0x17a>
    203e:	00e78423          	sb	a4,8(a5)
    2042:	0096859b          	addiw	a1,a3,9
    2046:	02c5fb63          	bgeu	a1,a2,207c <memset+0x17a>
    204a:	00e784a3          	sb	a4,9(a5)
    204e:	00a6859b          	addiw	a1,a3,10
    2052:	02c5f563          	bgeu	a1,a2,207c <memset+0x17a>
    2056:	00e78523          	sb	a4,10(a5)
    205a:	00b6859b          	addiw	a1,a3,11
    205e:	00c5ff63          	bgeu	a1,a2,207c <memset+0x17a>
    2062:	00e785a3          	sb	a4,11(a5)
    2066:	00c6859b          	addiw	a1,a3,12
    206a:	00c5f963          	bgeu	a1,a2,207c <memset+0x17a>
    206e:	00e78623          	sb	a4,12(a5)
    2072:	26b5                	addiw	a3,a3,13
    2074:	00c6f463          	bgeu	a3,a2,207c <memset+0x17a>
    2078:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    207c:	8082                	ret
    207e:	46ad                	li	a3,11
    2080:	bd79                	j	1f1e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2082:	480d                	li	a6,3
    2084:	b701                	j	1f84 <memset+0x82>
    2086:	8082                	ret
    2088:	4805                	li	a6,1
    208a:	bded                	j	1f84 <memset+0x82>
    208c:	85aa                	mv	a1,a0
    208e:	4801                	li	a6,0
    2090:	bdd5                	j	1f84 <memset+0x82>
    2092:	87aa                	mv	a5,a0
    2094:	4681                	li	a3,0
    2096:	b7a1                	j	1fde <memset+0xdc>
    2098:	4809                	li	a6,2
    209a:	b5ed                	j	1f84 <memset+0x82>
    209c:	4811                	li	a6,4
    209e:	b5dd                	j	1f84 <memset+0x82>
    20a0:	4815                	li	a6,5
    20a2:	b5cd                	j	1f84 <memset+0x82>
    20a4:	4819                	li	a6,6
    20a6:	bdf9                	j	1f84 <memset+0x82>

00000000000020a8 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    20a8:	00054783          	lbu	a5,0(a0)
    20ac:	0005c703          	lbu	a4,0(a1)
    20b0:	00e79863          	bne	a5,a4,20c0 <strcmp+0x18>
    20b4:	0505                	addi	a0,a0,1
    20b6:	0585                	addi	a1,a1,1
    20b8:	fbe5                	bnez	a5,20a8 <strcmp>
    20ba:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    20bc:	9d19                	subw	a0,a0,a4
    20be:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    20c0:	0007851b          	sext.w	a0,a5
    20c4:	bfe5                	j	20bc <strcmp+0x14>

00000000000020c6 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    20c6:	ca15                	beqz	a2,20fa <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20c8:	00054783          	lbu	a5,0(a0)
	if (!n--)
    20cc:	167d                	addi	a2,a2,-1
    20ce:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20d2:	eb99                	bnez	a5,20e8 <strncmp+0x22>
    20d4:	a815                	j	2108 <strncmp+0x42>
    20d6:	00a68e63          	beq	a3,a0,20f2 <strncmp+0x2c>
    20da:	0505                	addi	a0,a0,1
    20dc:	00f71b63          	bne	a4,a5,20f2 <strncmp+0x2c>
    20e0:	00054783          	lbu	a5,0(a0)
    20e4:	cf89                	beqz	a5,20fe <strncmp+0x38>
    20e6:	85b2                	mv	a1,a2
    20e8:	0005c703          	lbu	a4,0(a1)
    20ec:	00158613          	addi	a2,a1,1
    20f0:	f37d                	bnez	a4,20d6 <strncmp+0x10>
		;
	return *l - *r;
    20f2:	0007851b          	sext.w	a0,a5
    20f6:	9d19                	subw	a0,a0,a4
    20f8:	8082                	ret
		return 0;
    20fa:	4501                	li	a0,0
}
    20fc:	8082                	ret
	return *l - *r;
    20fe:	0015c703          	lbu	a4,1(a1)
    2102:	4501                	li	a0,0
    2104:	9d19                	subw	a0,a0,a4
    2106:	8082                	ret
    2108:	0005c703          	lbu	a4,0(a1)
    210c:	4501                	li	a0,0
    210e:	b7e5                	j	20f6 <strncmp+0x30>

0000000000002110 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2110:	00757793          	andi	a5,a0,7
    2114:	cf89                	beqz	a5,212e <strlen+0x1e>
    2116:	87aa                	mv	a5,a0
    2118:	a029                	j	2122 <strlen+0x12>
    211a:	0785                	addi	a5,a5,1
    211c:	0077f713          	andi	a4,a5,7
    2120:	cb01                	beqz	a4,2130 <strlen+0x20>
		if (!*s)
    2122:	0007c703          	lbu	a4,0(a5)
    2126:	fb75                	bnez	a4,211a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2128:	40a78533          	sub	a0,a5,a0
}
    212c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    212e:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2130:	6394                	ld	a3,0(a5)
    2132:	00001597          	auipc	a1,0x1
    2136:	9a65b583          	ld	a1,-1626(a1) # 2ad8 <enable_deadlock_detect+0x22a>
    213a:	00001617          	auipc	a2,0x1
    213e:	9a663603          	ld	a2,-1626(a2) # 2ae0 <enable_deadlock_detect+0x232>
    2142:	a019                	j	2148 <strlen+0x38>
    2144:	6794                	ld	a3,8(a5)
    2146:	07a1                	addi	a5,a5,8
    2148:	00b68733          	add	a4,a3,a1
    214c:	fff6c693          	not	a3,a3
    2150:	8f75                	and	a4,a4,a3
    2152:	8f71                	and	a4,a4,a2
    2154:	db65                	beqz	a4,2144 <strlen+0x34>
	for (; *s; s++)
    2156:	0007c703          	lbu	a4,0(a5)
    215a:	d779                	beqz	a4,2128 <strlen+0x18>
    215c:	0017c703          	lbu	a4,1(a5)
    2160:	0785                	addi	a5,a5,1
    2162:	d379                	beqz	a4,2128 <strlen+0x18>
    2164:	0017c703          	lbu	a4,1(a5)
    2168:	0785                	addi	a5,a5,1
    216a:	fb6d                	bnez	a4,215c <strlen+0x4c>
    216c:	bf75                	j	2128 <strlen+0x18>

000000000000216e <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    216e:	00757713          	andi	a4,a0,7
{
    2172:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2174:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2178:	cb19                	beqz	a4,218e <memchr+0x20>
    217a:	ce25                	beqz	a2,21f2 <memchr+0x84>
    217c:	0007c703          	lbu	a4,0(a5)
    2180:	04b70e63          	beq	a4,a1,21dc <memchr+0x6e>
    2184:	0785                	addi	a5,a5,1
    2186:	0077f713          	andi	a4,a5,7
    218a:	167d                	addi	a2,a2,-1
    218c:	f77d                	bnez	a4,217a <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    218e:	4501                	li	a0,0
	if (n && *s != c) {
    2190:	c235                	beqz	a2,21f4 <memchr+0x86>
    2192:	0007c703          	lbu	a4,0(a5)
    2196:	04b70363          	beq	a4,a1,21dc <memchr+0x6e>
		size_t k = ONES * c;
    219a:	00001517          	auipc	a0,0x1
    219e:	94e53503          	ld	a0,-1714(a0) # 2ae8 <enable_deadlock_detect+0x23a>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21a2:	471d                	li	a4,7
		size_t k = ONES * c;
    21a4:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21a8:	02c77a63          	bgeu	a4,a2,21dc <memchr+0x6e>
    21ac:	00001897          	auipc	a7,0x1
    21b0:	92c8b883          	ld	a7,-1748(a7) # 2ad8 <enable_deadlock_detect+0x22a>
    21b4:	00001817          	auipc	a6,0x1
    21b8:	92c83803          	ld	a6,-1748(a6) # 2ae0 <enable_deadlock_detect+0x232>
    21bc:	431d                	li	t1,7
    21be:	a029                	j	21c8 <memchr+0x5a>
		     w++, n -= SS)
    21c0:	1661                	addi	a2,a2,-8
    21c2:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21c4:	02c37963          	bgeu	t1,a2,21f6 <memchr+0x88>
    21c8:	6398                	ld	a4,0(a5)
    21ca:	8f29                	xor	a4,a4,a0
    21cc:	011706b3          	add	a3,a4,a7
    21d0:	fff74713          	not	a4,a4
    21d4:	8f75                	and	a4,a4,a3
    21d6:	01077733          	and	a4,a4,a6
    21da:	d37d                	beqz	a4,21c0 <memchr+0x52>
{
    21dc:	853e                	mv	a0,a5
    21de:	97b2                	add	a5,a5,a2
    21e0:	a021                	j	21e8 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21e2:	0505                	addi	a0,a0,1
    21e4:	00f50763          	beq	a0,a5,21f2 <memchr+0x84>
    21e8:	00054703          	lbu	a4,0(a0)
    21ec:	feb71be3          	bne	a4,a1,21e2 <memchr+0x74>
    21f0:	8082                	ret
	return n ? (void *)s : 0;
    21f2:	4501                	li	a0,0
}
    21f4:	8082                	ret
	return n ? (void *)s : 0;
    21f6:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    21f8:	f275                	bnez	a2,21dc <memchr+0x6e>
}
    21fa:	8082                	ret

00000000000021fc <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    21fc:	1101                	addi	sp,sp,-32
    21fe:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2200:	862e                	mv	a2,a1
{
    2202:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2204:	4581                	li	a1,0
{
    2206:	e426                	sd	s1,8(sp)
    2208:	ec06                	sd	ra,24(sp)
    220a:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    220c:	f63ff0ef          	jal	ra,216e <memchr>
	return p ? p - s : n;
    2210:	c519                	beqz	a0,221e <strnlen+0x22>
}
    2212:	60e2                	ld	ra,24(sp)
    2214:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2216:	8d05                	sub	a0,a0,s1
}
    2218:	64a2                	ld	s1,8(sp)
    221a:	6105                	addi	sp,sp,32
    221c:	8082                	ret
    221e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2220:	8522                	mv	a0,s0
}
    2222:	6442                	ld	s0,16(sp)
    2224:	64a2                	ld	s1,8(sp)
    2226:	6105                	addi	sp,sp,32
    2228:	8082                	ret

000000000000222a <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    222a:	00a5c7b3          	xor	a5,a1,a0
    222e:	8b9d                	andi	a5,a5,7
    2230:	eb95                	bnez	a5,2264 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2232:	0075f793          	andi	a5,a1,7
    2236:	e7b1                	bnez	a5,2282 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2238:	6198                	ld	a4,0(a1)
    223a:	00001617          	auipc	a2,0x1
    223e:	89e63603          	ld	a2,-1890(a2) # 2ad8 <enable_deadlock_detect+0x22a>
    2242:	00001817          	auipc	a6,0x1
    2246:	89e83803          	ld	a6,-1890(a6) # 2ae0 <enable_deadlock_detect+0x232>
    224a:	a029                	j	2254 <stpcpy+0x2a>
    224c:	05a1                	addi	a1,a1,8
    224e:	e118                	sd	a4,0(a0)
    2250:	6198                	ld	a4,0(a1)
    2252:	0521                	addi	a0,a0,8
    2254:	00c707b3          	add	a5,a4,a2
    2258:	fff74693          	not	a3,a4
    225c:	8ff5                	and	a5,a5,a3
    225e:	0107f7b3          	and	a5,a5,a6
    2262:	d7ed                	beqz	a5,224c <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2264:	0005c783          	lbu	a5,0(a1)
    2268:	00f50023          	sb	a5,0(a0)
    226c:	c785                	beqz	a5,2294 <stpcpy+0x6a>
    226e:	0015c783          	lbu	a5,1(a1)
    2272:	0505                	addi	a0,a0,1
    2274:	0585                	addi	a1,a1,1
    2276:	00f50023          	sb	a5,0(a0)
    227a:	fbf5                	bnez	a5,226e <stpcpy+0x44>
		;
	return d;
}
    227c:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    227e:	0505                	addi	a0,a0,1
    2280:	df45                	beqz	a4,2238 <stpcpy+0xe>
			if (!(*d = *s))
    2282:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2286:	0585                	addi	a1,a1,1
    2288:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    228c:	00f50023          	sb	a5,0(a0)
    2290:	f7fd                	bnez	a5,227e <stpcpy+0x54>
}
    2292:	8082                	ret
    2294:	8082                	ret

0000000000002296 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2296:	00a5c7b3          	xor	a5,a1,a0
    229a:	8b9d                	andi	a5,a5,7
    229c:	1a079863          	bnez	a5,244c <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    22a0:	0075f793          	andi	a5,a1,7
    22a4:	16078463          	beqz	a5,240c <stpncpy+0x176>
    22a8:	ea01                	bnez	a2,22b8 <stpncpy+0x22>
    22aa:	a421                	j	24b2 <stpncpy+0x21c>
    22ac:	167d                	addi	a2,a2,-1
    22ae:	0505                	addi	a0,a0,1
    22b0:	14070e63          	beqz	a4,240c <stpncpy+0x176>
    22b4:	1a060863          	beqz	a2,2464 <stpncpy+0x1ce>
    22b8:	0005c783          	lbu	a5,0(a1)
    22bc:	0585                	addi	a1,a1,1
    22be:	0075f713          	andi	a4,a1,7
    22c2:	00f50023          	sb	a5,0(a0)
    22c6:	f3fd                	bnez	a5,22ac <stpncpy+0x16>
    22c8:	4805                	li	a6,1
    22ca:	1a061863          	bnez	a2,247a <stpncpy+0x1e4>
    22ce:	40a007b3          	neg	a5,a0
    22d2:	8b9d                	andi	a5,a5,7
    22d4:	4681                	li	a3,0
    22d6:	18061a63          	bnez	a2,246a <stpncpy+0x1d4>
    22da:	00778713          	addi	a4,a5,7
    22de:	45ad                	li	a1,11
    22e0:	18b76363          	bltu	a4,a1,2466 <stpncpy+0x1d0>
    22e4:	1ae6eb63          	bltu	a3,a4,249a <stpncpy+0x204>
    22e8:	1a078363          	beqz	a5,248e <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22ec:	00050023          	sb	zero,0(a0)
    22f0:	4685                	li	a3,1
    22f2:	00150713          	addi	a4,a0,1
    22f6:	18d78f63          	beq	a5,a3,2494 <stpncpy+0x1fe>
    22fa:	000500a3          	sb	zero,1(a0)
    22fe:	4689                	li	a3,2
    2300:	00250713          	addi	a4,a0,2
    2304:	18d78e63          	beq	a5,a3,24a0 <stpncpy+0x20a>
    2308:	00050123          	sb	zero,2(a0)
    230c:	468d                	li	a3,3
    230e:	00350713          	addi	a4,a0,3
    2312:	16d78c63          	beq	a5,a3,248a <stpncpy+0x1f4>
    2316:	000501a3          	sb	zero,3(a0)
    231a:	4691                	li	a3,4
    231c:	00450713          	addi	a4,a0,4
    2320:	18d78263          	beq	a5,a3,24a4 <stpncpy+0x20e>
    2324:	00050223          	sb	zero,4(a0)
    2328:	4695                	li	a3,5
    232a:	00550713          	addi	a4,a0,5
    232e:	16d78d63          	beq	a5,a3,24a8 <stpncpy+0x212>
    2332:	000502a3          	sb	zero,5(a0)
    2336:	469d                	li	a3,7
    2338:	00650713          	addi	a4,a0,6
    233c:	16d79863          	bne	a5,a3,24ac <stpncpy+0x216>
    2340:	00750713          	addi	a4,a0,7
    2344:	00050323          	sb	zero,6(a0)
    2348:	40f80833          	sub	a6,a6,a5
    234c:	ff887593          	andi	a1,a6,-8
    2350:	97aa                	add	a5,a5,a0
    2352:	95be                	add	a1,a1,a5
    2354:	0007b023          	sd	zero,0(a5)
    2358:	07a1                	addi	a5,a5,8
    235a:	feb79de3          	bne	a5,a1,2354 <stpncpy+0xbe>
    235e:	ff887593          	andi	a1,a6,-8
    2362:	9ead                	addw	a3,a3,a1
    2364:	00b707b3          	add	a5,a4,a1
    2368:	12b80863          	beq	a6,a1,2498 <stpncpy+0x202>
    236c:	00078023          	sb	zero,0(a5)
    2370:	0016871b          	addiw	a4,a3,1
    2374:	0ec77863          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    2378:	000780a3          	sb	zero,1(a5)
    237c:	0026871b          	addiw	a4,a3,2
    2380:	0ec77263          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    2384:	00078123          	sb	zero,2(a5)
    2388:	0036871b          	addiw	a4,a3,3
    238c:	0cc77c63          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    2390:	000781a3          	sb	zero,3(a5)
    2394:	0046871b          	addiw	a4,a3,4
    2398:	0cc77663          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    239c:	00078223          	sb	zero,4(a5)
    23a0:	0056871b          	addiw	a4,a3,5
    23a4:	0cc77063          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23a8:	000782a3          	sb	zero,5(a5)
    23ac:	0066871b          	addiw	a4,a3,6
    23b0:	0ac77a63          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23b4:	00078323          	sb	zero,6(a5)
    23b8:	0076871b          	addiw	a4,a3,7
    23bc:	0ac77463          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23c0:	000783a3          	sb	zero,7(a5)
    23c4:	0086871b          	addiw	a4,a3,8
    23c8:	08c77e63          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23cc:	00078423          	sb	zero,8(a5)
    23d0:	0096871b          	addiw	a4,a3,9
    23d4:	08c77863          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23d8:	000784a3          	sb	zero,9(a5)
    23dc:	00a6871b          	addiw	a4,a3,10
    23e0:	08c77263          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23e4:	00078523          	sb	zero,10(a5)
    23e8:	00b6871b          	addiw	a4,a3,11
    23ec:	06c77c63          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23f0:	000785a3          	sb	zero,11(a5)
    23f4:	00c6871b          	addiw	a4,a3,12
    23f8:	06c77663          	bgeu	a4,a2,2464 <stpncpy+0x1ce>
    23fc:	00078623          	sb	zero,12(a5)
    2400:	26b5                	addiw	a3,a3,13
    2402:	06c6f163          	bgeu	a3,a2,2464 <stpncpy+0x1ce>
    2406:	000786a3          	sb	zero,13(a5)
    240a:	8082                	ret
			;
		if (!n || !*s)
    240c:	c645                	beqz	a2,24b4 <stpncpy+0x21e>
    240e:	0005c783          	lbu	a5,0(a1)
    2412:	ea078be3          	beqz	a5,22c8 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2416:	479d                	li	a5,7
    2418:	02c7ff63          	bgeu	a5,a2,2456 <stpncpy+0x1c0>
    241c:	00000897          	auipc	a7,0x0
    2420:	6bc8b883          	ld	a7,1724(a7) # 2ad8 <enable_deadlock_detect+0x22a>
    2424:	00000817          	auipc	a6,0x0
    2428:	6bc83803          	ld	a6,1724(a6) # 2ae0 <enable_deadlock_detect+0x232>
    242c:	431d                	li	t1,7
    242e:	6198                	ld	a4,0(a1)
    2430:	011707b3          	add	a5,a4,a7
    2434:	fff74693          	not	a3,a4
    2438:	8ff5                	and	a5,a5,a3
    243a:	0107f7b3          	and	a5,a5,a6
    243e:	ef81                	bnez	a5,2456 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2440:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2442:	1661                	addi	a2,a2,-8
    2444:	05a1                	addi	a1,a1,8
    2446:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2448:	fec363e3          	bltu	t1,a2,242e <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    244c:	e609                	bnez	a2,2456 <stpncpy+0x1c0>
    244e:	a08d                	j	24b0 <stpncpy+0x21a>
    2450:	167d                	addi	a2,a2,-1
    2452:	0505                	addi	a0,a0,1
    2454:	ca01                	beqz	a2,2464 <stpncpy+0x1ce>
    2456:	0005c783          	lbu	a5,0(a1)
    245a:	0585                	addi	a1,a1,1
    245c:	00f50023          	sb	a5,0(a0)
    2460:	fbe5                	bnez	a5,2450 <stpncpy+0x1ba>
		;
tail:
    2462:	b59d                	j	22c8 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2464:	8082                	ret
    2466:	472d                	li	a4,11
    2468:	bdb5                	j	22e4 <stpncpy+0x4e>
    246a:	00778713          	addi	a4,a5,7
    246e:	45ad                	li	a1,11
    2470:	fff60693          	addi	a3,a2,-1
    2474:	e6b778e3          	bgeu	a4,a1,22e4 <stpncpy+0x4e>
    2478:	b7fd                	j	2466 <stpncpy+0x1d0>
    247a:	40a007b3          	neg	a5,a0
    247e:	8832                	mv	a6,a2
    2480:	8b9d                	andi	a5,a5,7
    2482:	4681                	li	a3,0
    2484:	e4060be3          	beqz	a2,22da <stpncpy+0x44>
    2488:	b7cd                	j	246a <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    248a:	468d                	li	a3,3
    248c:	bd75                	j	2348 <stpncpy+0xb2>
    248e:	872a                	mv	a4,a0
    2490:	4681                	li	a3,0
    2492:	bd5d                	j	2348 <stpncpy+0xb2>
    2494:	4685                	li	a3,1
    2496:	bd4d                	j	2348 <stpncpy+0xb2>
    2498:	8082                	ret
    249a:	87aa                	mv	a5,a0
    249c:	4681                	li	a3,0
    249e:	b5f9                	j	236c <stpncpy+0xd6>
    24a0:	4689                	li	a3,2
    24a2:	b55d                	j	2348 <stpncpy+0xb2>
    24a4:	4691                	li	a3,4
    24a6:	b54d                	j	2348 <stpncpy+0xb2>
    24a8:	4695                	li	a3,5
    24aa:	bd79                	j	2348 <stpncpy+0xb2>
    24ac:	4699                	li	a3,6
    24ae:	bd69                	j	2348 <stpncpy+0xb2>
    24b0:	8082                	ret
    24b2:	8082                	ret
    24b4:	8082                	ret

00000000000024b6 <basename>:

char *basename(char *s)
{
    24b6:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    24b8:	c54d                	beqz	a0,2562 <basename+0xac>
    24ba:	00054783          	lbu	a5,0(a0)
		return ".";
    24be:	00000517          	auipc	a0,0x0
    24c2:	61250513          	addi	a0,a0,1554 # 2ad0 <enable_deadlock_detect+0x222>
	if (!s || !*s)
    24c6:	e391                	bnez	a5,24ca <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    24c8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    24ca:	0076f713          	andi	a4,a3,7
    24ce:	87b6                	mv	a5,a3
    24d0:	cf51                	beqz	a4,256c <basename+0xb6>
    24d2:	0785                	addi	a5,a5,1
    24d4:	0077f713          	andi	a4,a5,7
    24d8:	c729                	beqz	a4,2522 <basename+0x6c>
		if (!*s)
    24da:	0007c703          	lbu	a4,0(a5)
    24de:	fb75                	bnez	a4,24d2 <basename+0x1c>
	return s - a;
    24e0:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24e2:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24e4:	cf8d                	beqz	a5,251e <basename+0x68>
    24e6:	00f68733          	add	a4,a3,a5
    24ea:	02f00593          	li	a1,47
    24ee:	a031                	j	24fa <basename+0x44>
		s[i] = 0;
    24f0:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    24f4:	17fd                	addi	a5,a5,-1
    24f6:	177d                	addi	a4,a4,-1
    24f8:	c39d                	beqz	a5,251e <basename+0x68>
    24fa:	00074603          	lbu	a2,0(a4)
    24fe:	feb609e3          	beq	a2,a1,24f0 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2502:	02f00613          	li	a2,47
    2506:	a011                	j	250a <basename+0x54>
    2508:	cb99                	beqz	a5,251e <basename+0x68>
    250a:	853e                	mv	a0,a5
    250c:	17fd                	addi	a5,a5,-1
    250e:	00f68733          	add	a4,a3,a5
    2512:	00074703          	lbu	a4,0(a4)
    2516:	fec719e3          	bne	a4,a2,2508 <basename+0x52>
	return s + i;
    251a:	9536                	add	a0,a0,a3
    251c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    251e:	8536                	mv	a0,a3
    2520:	8082                	ret
    2522:	6390                	ld	a2,0(a5)
    2524:	00000517          	auipc	a0,0x0
    2528:	5b453503          	ld	a0,1460(a0) # 2ad8 <enable_deadlock_detect+0x22a>
    252c:	00000597          	auipc	a1,0x0
    2530:	5b45b583          	ld	a1,1460(a1) # 2ae0 <enable_deadlock_detect+0x232>
    2534:	fff64713          	not	a4,a2
    2538:	962a                	add	a2,a2,a0
    253a:	8f71                	and	a4,a4,a2
    253c:	8f6d                	and	a4,a4,a1
    253e:	eb11                	bnez	a4,2552 <basename+0x9c>
    2540:	6790                	ld	a2,8(a5)
    2542:	07a1                	addi	a5,a5,8
    2544:	00a60733          	add	a4,a2,a0
    2548:	fff64613          	not	a2,a2
    254c:	8f71                	and	a4,a4,a2
    254e:	8f6d                	and	a4,a4,a1
    2550:	db65                	beqz	a4,2540 <basename+0x8a>
	for (; *s; s++)
    2552:	0007c703          	lbu	a4,0(a5)
    2556:	d749                	beqz	a4,24e0 <basename+0x2a>
    2558:	0017c703          	lbu	a4,1(a5)
    255c:	0785                	addi	a5,a5,1
    255e:	ff6d                	bnez	a4,2558 <basename+0xa2>
    2560:	b741                	j	24e0 <basename+0x2a>
		return ".";
    2562:	00000517          	auipc	a0,0x0
    2566:	56e50513          	addi	a0,a0,1390 # 2ad0 <enable_deadlock_detect+0x222>
    256a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    256c:	6290                	ld	a2,0(a3)
    256e:	00000517          	auipc	a0,0x0
    2572:	56a53503          	ld	a0,1386(a0) # 2ad8 <enable_deadlock_detect+0x22a>
    2576:	00000597          	auipc	a1,0x0
    257a:	56a5b583          	ld	a1,1386(a1) # 2ae0 <enable_deadlock_detect+0x232>
    257e:	fff64713          	not	a4,a2
    2582:	962a                	add	a2,a2,a0
    2584:	8f71                	and	a4,a4,a2
    2586:	8f6d                	and	a4,a4,a1
    2588:	df45                	beqz	a4,2540 <basename+0x8a>
    258a:	b7f9                	j	2558 <basename+0xa2>

000000000000258c <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    258c:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2590:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2592:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2596:	2501                	sext.w	a0,a0
    2598:	8082                	ret

000000000000259a <close>:

int close(int fd)
{
	if (fd == 1) {
    259a:	4785                	li	a5,1
    259c:	00f50863          	beq	a0,a5,25ac <close+0x12>
	register long a7 __asm__("a7") = n;
    25a0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25a4:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    25a8:	2501                	sext.w	a0,a0
    25aa:	8082                	ret
{
    25ac:	1101                	addi	sp,sp,-32
    25ae:	ec06                	sd	ra,24(sp)
    25b0:	e42a                	sd	a0,8(sp)
		__write_buffer();
    25b2:	cdffe0ef          	jal	ra,1290 <__write_buffer>
		__clear_buffer();
    25b6:	d03fe0ef          	jal	ra,12b8 <__clear_buffer>
    25ba:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    25bc:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25c0:	00000073          	ecall
}
    25c4:	60e2                	ld	ra,24(sp)
    25c6:	2501                	sext.w	a0,a0
    25c8:	6105                	addi	sp,sp,32
    25ca:	8082                	ret

00000000000025cc <read>:
	register long a7 __asm__("a7") = n;
    25cc:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d0:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    25d4:	8082                	ret

00000000000025d6 <write>:
	register long a7 __asm__("a7") = n;
    25d6:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25da:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    25de:	8082                	ret

00000000000025e0 <getpid>:
	register long a7 __asm__("a7") = n;
    25e0:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25e4:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25e8:	2501                	sext.w	a0,a0
    25ea:	8082                	ret

00000000000025ec <getppid>:
	register long a7 __asm__("a7") = n;
    25ec:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25f0:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    25f4:	2501                	sext.w	a0,a0
    25f6:	8082                	ret

00000000000025f8 <sched_yield>:
	register long a7 __asm__("a7") = n;
    25f8:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25fc:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2600:	2501                	sext.w	a0,a0
    2602:	8082                	ret

0000000000002604 <fork>:
	register long a7 __asm__("a7") = n;
    2604:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2608:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    260c:	2501                	sext.w	a0,a0
    260e:	8082                	ret

0000000000002610 <exit>:

void exit(int code)
{
    2610:	1141                	addi	sp,sp,-16
    2612:	e406                	sd	ra,8(sp)
    2614:	e022                	sd	s0,0(sp)
    2616:	842a                	mv	s0,a0
	__write_buffer();
    2618:	c79fe0ef          	jal	ra,1290 <__write_buffer>
	__clear_buffer();
    261c:	c9dfe0ef          	jal	ra,12b8 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2620:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2624:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2626:	00000073          	ecall
	syscall(SYS_exit, code);
}
    262a:	60a2                	ld	ra,8(sp)
    262c:	6402                	ld	s0,0(sp)
    262e:	0141                	addi	sp,sp,16
    2630:	8082                	ret

0000000000002632 <waitpid>:
	register long a7 __asm__("a7") = n;
    2632:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2636:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <exec>:
	register long a7 __asm__("a7") = n;
    263e:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2642:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret

000000000000264a <get_mtime>:

int64 get_mtime()
{
    264a:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    264c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2650:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2652:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2654:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2658:	2501                	sext.w	a0,a0
    265a:	ed01                	bnez	a0,2672 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    265c:	6722                	ld	a4,8(sp)
    265e:	3e800793          	li	a5,1000
    2662:	6682                	ld	a3,0(sp)
    2664:	02f75733          	divu	a4,a4,a5
    2668:	02d78533          	mul	a0,a5,a3
    266c:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    266e:	0141                	addi	sp,sp,16
    2670:	8082                	ret
	return -1;
    2672:	557d                	li	a0,-1
    2674:	bfed                	j	266e <get_mtime+0x24>

0000000000002676 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2676:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267a:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <sleep>:

int sleep(unsigned long long time)
{
    2682:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2684:	880a                	mv	a6,sp
{
    2686:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2688:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    268c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    268e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2690:	00000073          	ecall
	if (err == 0) {
    2694:	2501                	sext.w	a0,a0
    2696:	ed31                	bnez	a0,26f2 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2698:	6722                	ld	a4,8(sp)
    269a:	3e800793          	li	a5,1000
    269e:	6682                	ld	a3,0(sp)
    26a0:	02f75733          	divu	a4,a4,a5
    26a4:	02d787b3          	mul	a5,a5,a3
    26a8:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    26aa:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26ae:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26b0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26b2:	00000073          	ecall
	if (err == 0) {
    26b6:	2501                	sext.w	a0,a0
    26b8:	e915                	bnez	a0,26ec <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    26ba:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    26bc:	3e800693          	li	a3,1000
    26c0:	a819                	j	26d6 <sleep+0x54>
	__asm_syscall("r"(a7))
    26c2:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26c6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26ca:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26cc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ce:	00000073          	ecall
	if (err == 0) {
    26d2:	2501                	sext.w	a0,a0
    26d4:	ed01                	bnez	a0,26ec <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    26d6:	6722                	ld	a4,8(sp)
    26d8:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    26da:	07c00893          	li	a7,124
    26de:	02d75733          	divu	a4,a4,a3
    26e2:	02f687b3          	mul	a5,a3,a5
    26e6:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26e8:	fcc7ede3          	bltu	a5,a2,26c2 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26ec:	4501                	li	a0,0
    26ee:	0141                	addi	sp,sp,16
    26f0:	8082                	ret
    26f2:	57fd                	li	a5,-1
    26f4:	bf5d                	j	26aa <sleep+0x28>

00000000000026f6 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    26f6:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    26fa:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    26fe:	2501                	sext.w	a0,a0
    2700:	8082                	ret

0000000000002702 <set_priority>:
	register long a7 __asm__("a7") = n;
    2702:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2706:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    270a:	2501                	sext.w	a0,a0
    270c:	8082                	ret

000000000000270e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    270e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2712:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2716:	2501                	sext.w	a0,a0
    2718:	8082                	ret

000000000000271a <munmap>:
	register long a7 __asm__("a7") = n;
    271a:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    271e:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2722:	2501                	sext.w	a0,a0
    2724:	8082                	ret

0000000000002726 <wait>:

int wait(int *code)
{
    2726:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2728:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    272c:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    272e:	00000073          	ecall
	return waitpid(-1, code);
}
    2732:	2501                	sext.w	a0,a0
    2734:	8082                	ret

0000000000002736 <spawn>:
	register long a7 __asm__("a7") = n;
    2736:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    273a:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    273e:	2501                	sext.w	a0,a0
    2740:	8082                	ret

0000000000002742 <pipe>:
	register long a7 __asm__("a7") = n;
    2742:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2746:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <mailread>:
	register long a7 __asm__("a7") = n;
    274e:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2752:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <mailwrite>:
	register long a7 __asm__("a7") = n;
    275a:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    275e:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2762:	2501                	sext.w	a0,a0
    2764:	8082                	ret

0000000000002766 <fstat>:
	register long a7 __asm__("a7") = n;
    2766:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    276a:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    276e:	2501                	sext.w	a0,a0
    2770:	8082                	ret

0000000000002772 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2772:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2774:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2778:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    277a:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    277e:	2501                	sext.w	a0,a0
    2780:	8082                	ret

0000000000002782 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2782:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2784:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2788:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    278a:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    278e:	2501                	sext.w	a0,a0
    2790:	8082                	ret

0000000000002792 <link>:

int link(char *old_path, char *new_path)
{
    2792:	87aa                	mv	a5,a0
    2794:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2796:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    279a:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    279e:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    27a0:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    27a4:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27a6:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    27aa:	2501                	sext.w	a0,a0
    27ac:	8082                	ret

00000000000027ae <unlink>:

int unlink(char *path)
{
    27ae:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27b0:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    27b4:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    27b8:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27ba:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    27be:	2501                	sext.w	a0,a0
    27c0:	8082                	ret

00000000000027c2 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    27c2:	00000797          	auipc	a5,0x0
    27c6:	6de7b783          	ld	a5,1758(a5) # 2ea0 <_GLOBAL_OFFSET_TABLE_+0x8>
    27ca:	439c                	lw	a5,0(a5)
    27cc:	c799                	beqz	a5,27da <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    27ce:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27d2:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    27d6:	2501                	sext.w	a0,a0
    27d8:	8082                	ret
{
    27da:	1101                	addi	sp,sp,-32
    27dc:	ec06                	sd	ra,24(sp)
    27de:	e42e                	sd	a1,8(sp)
    27e0:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27e2:	fe7fe0ef          	jal	ra,17c8 <enable_thread_io_buffer>
    27e6:	65a2                	ld	a1,8(sp)
    27e8:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27ea:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ee:	00000073          	ecall
}
    27f2:	60e2                	ld	ra,24(sp)
    27f4:	2501                	sext.w	a0,a0
    27f6:	6105                	addi	sp,sp,32
    27f8:	8082                	ret

00000000000027fa <gettid>:
	register long a7 __asm__("a7") = n;
    27fa:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    27fe:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2802:	2501                	sext.w	a0,a0
    2804:	8082                	ret

0000000000002806 <waittid>:

int waittid(int tid)
{
    2806:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2808:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    280c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2810:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2812:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2814:	00e51e63          	bne	a0,a4,2830 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2818:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    281c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2820:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2824:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2826:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    282a:	2501                	sext.w	a0,a0
	while (ret == -2) {
    282c:	fee506e3          	beq	a0,a4,2818 <waittid+0x12>
	}
	return ret;
}
    2830:	8082                	ret

0000000000002832 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2832:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2836:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2838:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    283c:	2501                	sext.w	a0,a0
    283e:	8082                	ret

0000000000002840 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2840:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2844:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2846:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    284a:	2501                	sext.w	a0,a0
    284c:	8082                	ret

000000000000284e <mutex_lock>:
	register long a7 __asm__("a7") = n;
    284e:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2852:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2856:	2501                	sext.w	a0,a0
    2858:	8082                	ret

000000000000285a <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    285a:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    285e:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2862:	2501                	sext.w	a0,a0
    2864:	8082                	ret

0000000000002866 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2866:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    286a:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    286e:	2501                	sext.w	a0,a0
    2870:	8082                	ret

0000000000002872 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2872:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2876:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    287a:	2501                	sext.w	a0,a0
    287c:	8082                	ret

000000000000287e <semaphore_down>:
	register long a7 __asm__("a7") = n;
    287e:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2882:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2886:	2501                	sext.w	a0,a0
    2888:	8082                	ret

000000000000288a <condvar_create>:
	register long a7 __asm__("a7") = n;
    288a:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    288e:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2892:	2501                	sext.w	a0,a0
    2894:	8082                	ret

0000000000002896 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2896:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    289a:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    289e:	2501                	sext.w	a0,a0
    28a0:	8082                	ret

00000000000028a2 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    28a2:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28a6:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    28aa:	2501                	sext.w	a0,a0
    28ac:	8082                	ret

00000000000028ae <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    28ae:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    28b2:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    28b6:	2501                	sext.w	a0,a0
    28b8:	8082                	ret
