
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_forktest2:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a205                	j	1120 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

const int NUM = 5;

int main()
{
    1002:	715d                	addi	sp,sp,-80
    1004:	e0a2                	sd	s0,64(sp)
    1006:	fc26                	sd	s1,56(sp)
    1008:	e486                	sd	ra,72(sp)
    100a:	f84a                	sd	s2,48(sp)
    100c:	f44e                	sd	s3,40(sp)
    100e:	f052                	sd	s4,32(sp)
    1010:	ec56                	sd	s5,24(sp)
    1012:	e85a                	sd	s6,16(sp)
    1014:	4415                	li	s0,5
	for (int i = 0; i < NUM; ++i) {
		int pid = fork();
		if (pid == 0) {
			exec("ch2b_hello_world", NULL);
    1016:	00001497          	auipc	s1,0x1
    101a:	77248493          	addi	s1,s1,1906 # 2788 <enable_deadlock_detect+0xe>
		int pid = fork();
    101e:	4b2010ef          	jal	ra,24d0 <fork>
	for (int i = 0; i < NUM; ++i) {
    1022:	347d                	addiw	s0,s0,-1
		if (pid == 0) {
    1024:	cd51                	beqz	a0,10c0 <main+0xbe>
	for (int i = 0; i < NUM; ++i) {
    1026:	fc65                	bnez	s0,101e <main+0x1c>
			exit(0);
		}
	}
	int xstate = 0;
    1028:	c602                	sw	zero,12(sp)
    102a:	4415                	li	s0,5
    102c:	0064                	addi	s1,sp,12
	for (int i = 0; i < NUM; ++i) {
		assert(wait(&xstate) > 0);
    102e:	00001a17          	auipc	s4,0x1
    1032:	772a0a13          	addi	s4,s4,1906 # 27a0 <enable_deadlock_detect+0x26>
    1036:	00001997          	auipc	s3,0x1
    103a:	7b298993          	addi	s3,s3,1970 # 27e8 <enable_deadlock_detect+0x6e>
    103e:	00001b17          	auipc	s6,0x1
    1042:	7b2b0b13          	addi	s6,s6,1970 # 27f0 <enable_deadlock_detect+0x76>
		assert_eq(xstate, 0);
    1046:	00001a97          	auipc	s5,0x1
    104a:	7eaa8a93          	addi	s5,s5,2026 # 2830 <enable_deadlock_detect+0xb6>
		assert(wait(&xstate) > 0);
    104e:	8526                	mv	a0,s1
    1050:	5a2010ef          	jal	ra,25f2 <wait>
	for (int i = 0; i < NUM; ++i) {
    1054:	347d                	addiw	s0,s0,-1
		assert(wait(&xstate) > 0);
    1056:	0aa05363          	blez	a0,10fc <main+0xfa>
		assert_eq(xstate, 0);
    105a:	47b2                	lw	a5,12(sp)
    105c:	ebbd                	bnez	a5,10d2 <main+0xd0>
	for (int i = 0; i < NUM; ++i) {
    105e:	f865                	bnez	s0,104e <main+0x4c>
	}
	assert(wait(&xstate) < 0);
    1060:	8526                	mv	a0,s1
    1062:	590010ef          	jal	ra,25f2 <wait>
    1066:	02054c63          	bltz	a0,109e <main+0x9c>
    106a:	442010ef          	jal	ra,24ac <getpid>
    106e:	842a                	mv	s0,a0
    1070:	00001517          	auipc	a0,0x1
    1074:	73050513          	addi	a0,a0,1840 # 27a0 <enable_deadlock_detect+0x26>
    1078:	30a010ef          	jal	ra,2382 <basename>
    107c:	872a                	mv	a4,a0
    107e:	47d5                	li	a5,21
    1080:	00001517          	auipc	a0,0x1
    1084:	7e850513          	addi	a0,a0,2024 # 2868 <enable_deadlock_detect+0xee>
    1088:	86a2                	mv	a3,s0
    108a:	00001617          	auipc	a2,0x1
    108e:	75e60613          	addi	a2,a2,1886 # 27e8 <enable_deadlock_detect+0x6e>
    1092:	45fd                	li	a1,31
    1094:	1e6000ef          	jal	ra,127a <printf>
    1098:	557d                	li	a0,-1
    109a:	442010ef          	jal	ra,24dc <exit>
	printf("forktest2 test passed!\n");
    109e:	00002517          	auipc	a0,0x2
    10a2:	80a50513          	addi	a0,a0,-2038 # 28a8 <enable_deadlock_detect+0x12e>
    10a6:	1d4000ef          	jal	ra,127a <printf>
	return 0;
}
    10aa:	60a6                	ld	ra,72(sp)
    10ac:	6406                	ld	s0,64(sp)
    10ae:	74e2                	ld	s1,56(sp)
    10b0:	7942                	ld	s2,48(sp)
    10b2:	79a2                	ld	s3,40(sp)
    10b4:	7a02                	ld	s4,32(sp)
    10b6:	6ae2                	ld	s5,24(sp)
    10b8:	6b42                	ld	s6,16(sp)
    10ba:	4501                	li	a0,0
    10bc:	6161                	addi	sp,sp,80
    10be:	8082                	ret
			exec("ch2b_hello_world", NULL);
    10c0:	4581                	li	a1,0
    10c2:	8526                	mv	a0,s1
    10c4:	446010ef          	jal	ra,250a <exec>
			exit(0);
    10c8:	4501                	li	a0,0
    10ca:	412010ef          	jal	ra,24dc <exit>
	for (int i = 0; i < NUM; ++i) {
    10ce:	f821                	bnez	s0,101e <main+0x1c>
    10d0:	bfa1                	j	1028 <main+0x26>
		assert_eq(xstate, 0);
    10d2:	3da010ef          	jal	ra,24ac <getpid>
    10d6:	892a                	mv	s2,a0
    10d8:	8552                	mv	a0,s4
    10da:	2a8010ef          	jal	ra,2382 <basename>
    10de:	4832                	lw	a6,12(sp)
    10e0:	872a                	mv	a4,a0
    10e2:	4881                	li	a7,0
    10e4:	8556                	mv	a0,s5
    10e6:	47cd                	li	a5,19
    10e8:	86ca                	mv	a3,s2
    10ea:	864e                	mv	a2,s3
    10ec:	45fd                	li	a1,31
    10ee:	18c000ef          	jal	ra,127a <printf>
    10f2:	557d                	li	a0,-1
    10f4:	3e8010ef          	jal	ra,24dc <exit>
	for (int i = 0; i < NUM; ++i) {
    10f8:	f839                	bnez	s0,104e <main+0x4c>
    10fa:	b79d                	j	1060 <main+0x5e>
		assert(wait(&xstate) > 0);
    10fc:	3b0010ef          	jal	ra,24ac <getpid>
    1100:	892a                	mv	s2,a0
    1102:	8552                	mv	a0,s4
    1104:	27e010ef          	jal	ra,2382 <basename>
    1108:	872a                	mv	a4,a0
    110a:	47c9                	li	a5,18
    110c:	855a                	mv	a0,s6
    110e:	86ca                	mv	a3,s2
    1110:	864e                	mv	a2,s3
    1112:	45fd                	li	a1,31
    1114:	166000ef          	jal	ra,127a <printf>
    1118:	557d                	li	a0,-1
    111a:	3c2010ef          	jal	ra,24dc <exit>
    111e:	bf35                	j	105a <main+0x58>

0000000000001120 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1120:	1141                	addi	sp,sp,-16
    1122:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1124:	edfff0ef          	jal	ra,1002 <main>
    1128:	3b4010ef          	jal	ra,24dc <exit>
	return 0;
    112c:	60a2                	ld	ra,8(sp)
    112e:	4501                	li	a0,0
    1130:	0141                	addi	sp,sp,16
    1132:	8082                	ret

0000000000001134 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1134:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1136:	4605                	li	a2,1
    1138:	00f10593          	addi	a1,sp,15
    113c:	4501                	li	a0,0
{
    113e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1140:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1144:	354010ef          	jal	ra,2498 <read>
    1148:	4785                	li	a5,1
    114a:	00f51763          	bne	a0,a5,1158 <getchar+0x24>
		return byte;
    114e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1152:	60e2                	ld	ra,24(sp)
    1154:	6105                	addi	sp,sp,32
    1156:	8082                	ret
		return EOF;
    1158:	557d                	li	a0,-1
    115a:	bfe5                	j	1152 <getchar+0x1e>

000000000000115c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    115c:	00002517          	auipc	a0,0x2
    1160:	85c52503          	lw	a0,-1956(a0) # 29b8 <buffer_len>
    1164:	e111                	bnez	a0,1168 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1166:	8082                	ret
{
    1168:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    116a:	862a                	mv	a2,a0
    116c:	00002597          	auipc	a1,0x2
    1170:	85458593          	addi	a1,a1,-1964 # 29c0 <buffer>
    1174:	4505                	li	a0,1
{
    1176:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1178:	32a010ef          	jal	ra,24a2 <write>
}
    117c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    117e:	2501                	sext.w	a0,a0
}
    1180:	0141                	addi	sp,sp,16
    1182:	8082                	ret

0000000000001184 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1184:	00002797          	auipc	a5,0x2
    1188:	8207aa23          	sw	zero,-1996(a5) # 29b8 <buffer_len>
}
    118c:	8082                	ret

000000000000118e <__fflush>:
	if (buffer_len == 0)
    118e:	00002517          	auipc	a0,0x2
    1192:	82a52503          	lw	a0,-2006(a0) # 29b8 <buffer_len>
    1196:	e511                	bnez	a0,11a2 <__fflush+0x14>
	buffer_len = 0;
    1198:	00002797          	auipc	a5,0x2
    119c:	8207a023          	sw	zero,-2016(a5) # 29b8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11a0:	8082                	ret
{
    11a2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11a4:	862a                	mv	a2,a0
    11a6:	00002597          	auipc	a1,0x2
    11aa:	81a58593          	addi	a1,a1,-2022 # 29c0 <buffer>
    11ae:	4505                	li	a0,1
{
    11b0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11b2:	2f0010ef          	jal	ra,24a2 <write>
	return r >= 0 ? 0 : r;
    11b6:	0005079b          	sext.w	a5,a0
}
    11ba:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11bc:	0017a793          	slti	a5,a5,1
    11c0:	40f007bb          	negw	a5,a5
    11c4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11c6:	00001797          	auipc	a5,0x1
    11ca:	7e07a923          	sw	zero,2034(a5) # 29b8 <buffer_len>
	return r >= 0 ? 0 : r;
    11ce:	2501                	sext.w	a0,a0
}
    11d0:	0141                	addi	sp,sp,16
    11d2:	8082                	ret

00000000000011d4 <fflush>:

int fflush(int fd)
{
    11d4:	1101                	addi	sp,sp,-32
    11d6:	e822                	sd	s0,16(sp)
    11d8:	ec06                	sd	ra,24(sp)
    11da:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11dc:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    11de:	4401                	li	s0,0
	if (fd == 1) {
    11e0:	00e50863          	beq	a0,a4,11f0 <fflush+0x1c>
}
    11e4:	60e2                	ld	ra,24(sp)
    11e6:	8522                	mv	a0,s0
    11e8:	6442                	ld	s0,16(sp)
    11ea:	64a2                	ld	s1,8(sp)
    11ec:	6105                	addi	sp,sp,32
    11ee:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11f0:	00001497          	auipc	s1,0x1
    11f4:	7c848493          	addi	s1,s1,1992 # 29b8 <buffer_len>
    11f8:	1084a703          	lw	a4,264(s1)
    11fc:	02a70e63          	beq	a4,a0,1238 <fflush+0x64>
	if (buffer_len == 0)
    1200:	4080                	lw	s0,0(s1)
    1202:	c00d                	beqz	s0,1224 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1204:	8622                	mv	a2,s0
    1206:	00001597          	auipc	a1,0x1
    120a:	7ba58593          	addi	a1,a1,1978 # 29c0 <buffer>
    120e:	294010ef          	jal	ra,24a2 <write>
	return r >= 0 ? 0 : r;
    1212:	0005079b          	sext.w	a5,a0
    1216:	0017a793          	slti	a5,a5,1
    121a:	40f007bb          	negw	a5,a5
    121e:	8d7d                	and	a0,a0,a5
    1220:	0005041b          	sext.w	s0,a0
}
    1224:	60e2                	ld	ra,24(sp)
    1226:	8522                	mv	a0,s0
    1228:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    122a:	00001797          	auipc	a5,0x1
    122e:	7807a723          	sw	zero,1934(a5) # 29b8 <buffer_len>
}
    1232:	64a2                	ld	s1,8(sp)
    1234:	6105                	addi	sp,sp,32
    1236:	8082                	ret
			mutex_lock(buffer_lock);
    1238:	10c4a503          	lw	a0,268(s1)
    123c:	4de010ef          	jal	ra,271a <mutex_lock>
	if (buffer_len == 0)
    1240:	4080                	lw	s0,0(s1)
    1242:	e811                	bnez	s0,1256 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1244:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1248:	00001797          	auipc	a5,0x1
    124c:	7607a823          	sw	zero,1904(a5) # 29b8 <buffer_len>
			mutex_unlock(buffer_lock);
    1250:	4d6010ef          	jal	ra,2726 <mutex_unlock>
    1254:	bf41                	j	11e4 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1256:	8622                	mv	a2,s0
    1258:	00001597          	auipc	a1,0x1
    125c:	76858593          	addi	a1,a1,1896 # 29c0 <buffer>
    1260:	4505                	li	a0,1
    1262:	240010ef          	jal	ra,24a2 <write>
	return r >= 0 ? 0 : r;
    1266:	0005079b          	sext.w	a5,a0
    126a:	0017a793          	slti	a5,a5,1
    126e:	40f007bb          	negw	a5,a5
    1272:	8d7d                	and	a0,a0,a5
    1274:	0005041b          	sext.w	s0,a0
	return r;
    1278:	b7f1                	j	1244 <fflush+0x70>

000000000000127a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    127a:	7131                	addi	sp,sp,-192
    127c:	e0da                	sd	s6,64(sp)
    127e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1280:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1282:	013c                	addi	a5,sp,136
{
    1284:	f0ca                	sd	s2,96(sp)
    1286:	ecce                	sd	s3,88(sp)
    1288:	e8d2                	sd	s4,80(sp)
    128a:	e4d6                	sd	s5,72(sp)
    128c:	fc86                	sd	ra,120(sp)
    128e:	f8a2                	sd	s0,112(sp)
    1290:	f4a6                	sd	s1,104(sp)
    1292:	89aa                	mv	s3,a0
    1294:	e52e                	sd	a1,136(sp)
    1296:	e932                	sd	a2,144(sp)
    1298:	ed36                	sd	a3,152(sp)
    129a:	f13a                	sd	a4,160(sp)
    129c:	f942                	sd	a6,176(sp)
    129e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12a0:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12a2:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12a6:	00001a17          	auipc	s4,0x1
    12aa:	712a0a13          	addi	s4,s4,1810 # 29b8 <buffer_len>
    12ae:	4a85                	li	s5,1
	buf[i++] = '0';
    12b0:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12b4:	0009c783          	lbu	a5,0(s3)
    12b8:	18078663          	beqz	a5,1444 <printf+0x1ca>
    12bc:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12be:	19278d63          	beq	a5,s2,1458 <printf+0x1de>
    12c2:	0015c783          	lbu	a5,1(a1)
    12c6:	0585                	addi	a1,a1,1
    12c8:	fbfd                	bnez	a5,12be <printf+0x44>
    12ca:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12cc:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12d0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12d4:	1b578863          	beq	a5,s5,1484 <printf+0x20a>
		len = out_unlocked(s, l);
    12d8:	85a2                	mv	a1,s0
    12da:	854e                	mv	a0,s3
    12dc:	42a000ef          	jal	ra,1706 <out_unlocked>
		out(f, a, l);
		if (l)
    12e0:	1c041063          	bnez	s0,14a0 <printf+0x226>
			continue;
		if (s[1] == 0)
    12e4:	0014c783          	lbu	a5,1(s1)
    12e8:	14078e63          	beqz	a5,1444 <printf+0x1ca>
			break;
		switch (s[1]) {
    12ec:	07300713          	li	a4,115
    12f0:	1ce78863          	beq	a5,a4,14c0 <printf+0x246>
    12f4:	1af76863          	bltu	a4,a5,14a4 <printf+0x22a>
    12f8:	06400713          	li	a4,100
    12fc:	22e78063          	beq	a5,a4,151c <printf+0x2a2>
    1300:	07000713          	li	a4,112
    1304:	1ee79563          	bne	a5,a4,14ee <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1308:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    130a:	00001797          	auipc	a5,0x1
    130e:	7c678793          	addi	a5,a5,1990 # 2ad0 <digits>
	buf[i++] = '0';
    1312:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1316:	6298                	ld	a4,0(a3)
    1318:	06a1                	addi	a3,a3,8
    131a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    131c:	00471393          	slli	t2,a4,0x4
    1320:	00871293          	slli	t0,a4,0x8
    1324:	00c71f93          	slli	t6,a4,0xc
    1328:	01071f13          	slli	t5,a4,0x10
    132c:	01471e93          	slli	t4,a4,0x14
    1330:	01871e13          	slli	t3,a4,0x18
    1334:	01c71893          	slli	a7,a4,0x1c
    1338:	02471813          	slli	a6,a4,0x24
    133c:	02871513          	slli	a0,a4,0x28
    1340:	02c71593          	slli	a1,a4,0x2c
    1344:	03071613          	slli	a2,a4,0x30
    1348:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    134c:	03c75413          	srli	s0,a4,0x3c
    1350:	01c7531b          	srliw	t1,a4,0x1c
    1354:	03c3d393          	srli	t2,t2,0x3c
    1358:	03c2d293          	srli	t0,t0,0x3c
    135c:	03cfdf93          	srli	t6,t6,0x3c
    1360:	03cf5f13          	srli	t5,t5,0x3c
    1364:	03cede93          	srli	t4,t4,0x3c
    1368:	03ce5e13          	srli	t3,t3,0x3c
    136c:	03c8d893          	srli	a7,a7,0x3c
    1370:	03c85813          	srli	a6,a6,0x3c
    1374:	9171                	srli	a0,a0,0x3c
    1376:	91f1                	srli	a1,a1,0x3c
    1378:	9271                	srli	a2,a2,0x3c
    137a:	92f1                	srli	a3,a3,0x3c
    137c:	95be                	add	a1,a1,a5
    137e:	963e                	add	a2,a2,a5
    1380:	96be                	add	a3,a3,a5
    1382:	943e                	add	s0,s0,a5
    1384:	93be                	add	t2,t2,a5
    1386:	92be                	add	t0,t0,a5
    1388:	9fbe                	add	t6,t6,a5
    138a:	9f3e                	add	t5,t5,a5
    138c:	9ebe                	add	t4,t4,a5
    138e:	9e3e                	add	t3,t3,a5
    1390:	98be                	add	a7,a7,a5
    1392:	933e                	add	t1,t1,a5
    1394:	983e                	add	a6,a6,a5
    1396:	953e                	add	a0,a0,a5
    1398:	0005c983          	lbu	s3,0(a1)
    139c:	00044403          	lbu	s0,0(s0)
    13a0:	00064583          	lbu	a1,0(a2)
    13a4:	0003c383          	lbu	t2,0(t2)
    13a8:	0006c603          	lbu	a2,0(a3)
    13ac:	0002c283          	lbu	t0,0(t0)
    13b0:	000fcf83          	lbu	t6,0(t6)
    13b4:	000f4f03          	lbu	t5,0(t5)
    13b8:	000ece83          	lbu	t4,0(t4)
    13bc:	000e4e03          	lbu	t3,0(t3)
    13c0:	0008c883          	lbu	a7,0(a7)
    13c4:	00034303          	lbu	t1,0(t1)
    13c8:	00084803          	lbu	a6,0(a6)
    13cc:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13d0:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13d4:	92f1                	srli	a3,a3,0x3c
    13d6:	8b3d                	andi	a4,a4,15
    13d8:	96be                	add	a3,a3,a5
    13da:	97ba                	add	a5,a5,a4
    13dc:	00810d23          	sb	s0,26(sp)
    13e0:	00710da3          	sb	t2,27(sp)
    13e4:	00510e23          	sb	t0,28(sp)
    13e8:	01f10ea3          	sb	t6,29(sp)
    13ec:	01e10f23          	sb	t5,30(sp)
    13f0:	01d10fa3          	sb	t4,31(sp)
    13f4:	03c10023          	sb	t3,32(sp)
    13f8:	031100a3          	sb	a7,33(sp)
    13fc:	02610123          	sb	t1,34(sp)
    1400:	030101a3          	sb	a6,35(sp)
    1404:	02a10223          	sb	a0,36(sp)
    1408:	033102a3          	sb	s3,37(sp)
    140c:	02b10323          	sb	a1,38(sp)
    1410:	02c103a3          	sb	a2,39(sp)
    1414:	0006c683          	lbu	a3,0(a3)
    1418:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    141c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1420:	02d10423          	sb	a3,40(sp)
    1424:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1428:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    142c:	11578263          	beq	a5,s5,1530 <printf+0x2b6>
		len = out_unlocked(s, l);
    1430:	45c9                	li	a1,18
    1432:	0828                	addi	a0,sp,24
    1434:	2d2000ef          	jal	ra,1706 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1438:	00248993          	addi	s3,s1,2
		if (!*s)
    143c:	0009c783          	lbu	a5,0(s3)
    1440:	e6079ee3          	bnez	a5,12bc <printf+0x42>
	}
	va_end(ap);
    1444:	70e6                	ld	ra,120(sp)
    1446:	7446                	ld	s0,112(sp)
    1448:	74a6                	ld	s1,104(sp)
    144a:	7906                	ld	s2,96(sp)
    144c:	69e6                	ld	s3,88(sp)
    144e:	6a46                	ld	s4,80(sp)
    1450:	6aa6                	ld	s5,72(sp)
    1452:	6b06                	ld	s6,64(sp)
    1454:	6129                	addi	sp,sp,192
    1456:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1458:	0005c783          	lbu	a5,0(a1)
    145c:	84ae                	mv	s1,a1
    145e:	01278963          	beq	a5,s2,1470 <printf+0x1f6>
    1462:	b5ad                	j	12cc <printf+0x52>
    1464:	0024c783          	lbu	a5,2(s1)
    1468:	0585                	addi	a1,a1,1
    146a:	0489                	addi	s1,s1,2
    146c:	e72790e3          	bne	a5,s2,12cc <printf+0x52>
    1470:	0014c783          	lbu	a5,1(s1)
    1474:	ff2788e3          	beq	a5,s2,1464 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1478:	108a2783          	lw	a5,264(s4)
		l = z - a;
    147c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1480:	e5579ce3          	bne	a5,s5,12d8 <printf+0x5e>
		mutex_lock(buffer_lock);
    1484:	10ca2503          	lw	a0,268(s4)
    1488:	292010ef          	jal	ra,271a <mutex_lock>
		len = out_unlocked(s, l);
    148c:	85a2                	mv	a1,s0
    148e:	854e                	mv	a0,s3
    1490:	276000ef          	jal	ra,1706 <out_unlocked>
		mutex_unlock(buffer_lock);
    1494:	10ca2503          	lw	a0,268(s4)
    1498:	28e010ef          	jal	ra,2726 <mutex_unlock>
		if (l)
    149c:	e40404e3          	beqz	s0,12e4 <printf+0x6a>
    14a0:	89a6                	mv	s3,s1
    14a2:	bd09                	j	12b4 <printf+0x3a>
		switch (s[1]) {
    14a4:	07800713          	li	a4,120
    14a8:	04e79363          	bne	a5,a4,14ee <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    14ac:	67c2                	ld	a5,16(sp)
    14ae:	45c1                	li	a1,16
		s += 2;
    14b0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14b4:	4388                	lw	a0,0(a5)
    14b6:	07a1                	addi	a5,a5,8
    14b8:	e83e                	sd	a5,16(sp)
    14ba:	5f8000ef          	jal	ra,1ab2 <printint.constprop.0>
		s += 2;
    14be:	bfbd                	j	143c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14c0:	67c2                	ld	a5,16(sp)
    14c2:	6380                	ld	s0,0(a5)
    14c4:	07a1                	addi	a5,a5,8
    14c6:	e83e                	sd	a5,16(sp)
    14c8:	1c040163          	beqz	s0,168a <printf+0x410>
			l = strnlen(a, 200);
    14cc:	0c800593          	li	a1,200
    14d0:	8522                	mv	a0,s0
    14d2:	3f7000ef          	jal	ra,20c8 <strnlen>
	if (buffer_lock_enabled == 1) {
    14d6:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14da:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    14de:	19578663          	beq	a5,s5,166a <printf+0x3f0>
		len = out_unlocked(s, l);
    14e2:	8522                	mv	a0,s0
    14e4:	222000ef          	jal	ra,1706 <out_unlocked>
		s += 2;
    14e8:	00248993          	addi	s3,s1,2
    14ec:	bf81                	j	143c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    14ee:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14f2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14f6:	0f578663          	beq	a5,s5,15e2 <printf+0x368>
		len = out_unlocked(s, l);
    14fa:	0828                	addi	a0,sp,24
    14fc:	316000ef          	jal	ra,1812 <out_unlocked.constprop.0>
			putchar(s[1]);
    1500:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1504:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1508:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    150c:	05578163          	beq	a5,s5,154e <printf+0x2d4>
		len = out_unlocked(s, l);
    1510:	0828                	addi	a0,sp,24
    1512:	300000ef          	jal	ra,1812 <out_unlocked.constprop.0>
		s += 2;
    1516:	00248993          	addi	s3,s1,2
    151a:	b70d                	j	143c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    151c:	67c2                	ld	a5,16(sp)
    151e:	45a9                	li	a1,10
		s += 2;
    1520:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1524:	4388                	lw	a0,0(a5)
    1526:	07a1                	addi	a5,a5,8
    1528:	e83e                	sd	a5,16(sp)
    152a:	588000ef          	jal	ra,1ab2 <printint.constprop.0>
		s += 2;
    152e:	b739                	j	143c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1530:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1534:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1538:	1e2010ef          	jal	ra,271a <mutex_lock>
		len = out_unlocked(s, l);
    153c:	45c9                	li	a1,18
    153e:	0828                	addi	a0,sp,24
    1540:	1c6000ef          	jal	ra,1706 <out_unlocked>
		mutex_unlock(buffer_lock);
    1544:	10ca2503          	lw	a0,268(s4)
    1548:	1de010ef          	jal	ra,2726 <mutex_unlock>
		s += 2;
    154c:	bdc5                	j	143c <printf+0x1c2>
		mutex_lock(buffer_lock);
    154e:	10ca2503          	lw	a0,268(s4)
    1552:	1c8010ef          	jal	ra,271a <mutex_lock>
		buffer[buffer_len++] = c;
    1556:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    155a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    155e:	0017861b          	addiw	a2,a5,1
    1562:	97d2                	add	a5,a5,s4
    1564:	00ca2023          	sw	a2,0(s4)
    1568:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    156c:	00c6cc63          	blt	a3,a2,1584 <printf+0x30a>
    1570:	47a9                	li	a5,10
    1572:	06f40663          	beq	s0,a5,15de <printf+0x364>
		mutex_unlock(buffer_lock);
    1576:	10ca2503          	lw	a0,268(s4)
		s += 2;
    157a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    157e:	1a8010ef          	jal	ra,2726 <mutex_unlock>
		s += 2;
    1582:	bd6d                	j	143c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1584:	10000793          	li	a5,256
    1588:	00f61e63          	bne	a2,a5,15a4 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    158c:	00001597          	auipc	a1,0x1
    1590:	43458593          	addi	a1,a1,1076 # 29c0 <buffer>
    1594:	4505                	li	a0,1
    1596:	70d000ef          	jal	ra,24a2 <write>
	buffer_len = 0;
    159a:	00001797          	auipc	a5,0x1
    159e:	4007af23          	sw	zero,1054(a5) # 29b8 <buffer_len>
			if (r < 0) {
    15a2:	bfd1                	j	1576 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15a4:	709000ef          	jal	ra,24ac <getpid>
    15a8:	842a                	mv	s0,a0
    15aa:	00001517          	auipc	a0,0x1
    15ae:	31e50513          	addi	a0,a0,798 # 28c8 <enable_deadlock_detect+0x14e>
    15b2:	5d1000ef          	jal	ra,2382 <basename>
    15b6:	872a                	mv	a4,a0
    15b8:	00001617          	auipc	a2,0x1
    15bc:	23060613          	addi	a2,a2,560 # 27e8 <enable_deadlock_detect+0x6e>
    15c0:	05400793          	li	a5,84
    15c4:	86a2                	mv	a3,s0
    15c6:	45fd                	li	a1,31
    15c8:	00001517          	auipc	a0,0x1
    15cc:	34050513          	addi	a0,a0,832 # 2908 <enable_deadlock_detect+0x18e>
    15d0:	cabff0ef          	jal	ra,127a <printf>
    15d4:	557d                	li	a0,-1
    15d6:	707000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    15da:	000a2603          	lw	a2,0(s4)
    15de:	de41                	beqz	a2,1576 <printf+0x2fc>
    15e0:	b775                	j	158c <printf+0x312>
		mutex_lock(buffer_lock);
    15e2:	10ca2503          	lw	a0,268(s4)
    15e6:	134010ef          	jal	ra,271a <mutex_lock>
		buffer[buffer_len++] = c;
    15ea:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15ee:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15f2:	0017861b          	addiw	a2,a5,1
    15f6:	97d2                	add	a5,a5,s4
    15f8:	00ca2023          	sw	a2,0(s4)
    15fc:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1600:	02c6d163          	bge	a3,a2,1622 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1604:	10000793          	li	a5,256
    1608:	02f61263          	bne	a2,a5,162c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    160c:	00001597          	auipc	a1,0x1
    1610:	3b458593          	addi	a1,a1,948 # 29c0 <buffer>
    1614:	4505                	li	a0,1
    1616:	68d000ef          	jal	ra,24a2 <write>
	buffer_len = 0;
    161a:	00001797          	auipc	a5,0x1
    161e:	3807af23          	sw	zero,926(a5) # 29b8 <buffer_len>
		mutex_unlock(buffer_lock);
    1622:	10ca2503          	lw	a0,268(s4)
    1626:	100010ef          	jal	ra,2726 <mutex_unlock>
    162a:	bdd9                	j	1500 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    162c:	681000ef          	jal	ra,24ac <getpid>
    1630:	842a                	mv	s0,a0
    1632:	00001517          	auipc	a0,0x1
    1636:	29650513          	addi	a0,a0,662 # 28c8 <enable_deadlock_detect+0x14e>
    163a:	549000ef          	jal	ra,2382 <basename>
    163e:	872a                	mv	a4,a0
    1640:	00001617          	auipc	a2,0x1
    1644:	1a860613          	addi	a2,a2,424 # 27e8 <enable_deadlock_detect+0x6e>
    1648:	05400793          	li	a5,84
    164c:	86a2                	mv	a3,s0
    164e:	45fd                	li	a1,31
    1650:	00001517          	auipc	a0,0x1
    1654:	2b850513          	addi	a0,a0,696 # 2908 <enable_deadlock_detect+0x18e>
    1658:	c23ff0ef          	jal	ra,127a <printf>
    165c:	557d                	li	a0,-1
    165e:	67f000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    1662:	000a2603          	lw	a2,0(s4)
    1666:	de55                	beqz	a2,1622 <printf+0x3a8>
    1668:	b755                	j	160c <printf+0x392>
		mutex_lock(buffer_lock);
    166a:	10ca2503          	lw	a0,268(s4)
    166e:	e42e                	sd	a1,8(sp)
		s += 2;
    1670:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1674:	0a6010ef          	jal	ra,271a <mutex_lock>
		len = out_unlocked(s, l);
    1678:	65a2                	ld	a1,8(sp)
    167a:	8522                	mv	a0,s0
    167c:	08a000ef          	jal	ra,1706 <out_unlocked>
		mutex_unlock(buffer_lock);
    1680:	10ca2503          	lw	a0,268(s4)
    1684:	0a2010ef          	jal	ra,2726 <mutex_unlock>
		s += 2;
    1688:	bb55                	j	143c <printf+0x1c2>
				a = "(null)";
    168a:	00001417          	auipc	s0,0x1
    168e:	23640413          	addi	s0,s0,566 # 28c0 <enable_deadlock_detect+0x146>
    1692:	bd2d                	j	14cc <printf+0x252>

0000000000001694 <enable_thread_io_buffer>:
{
    1694:	1101                	addi	sp,sp,-32
    1696:	e822                	sd	s0,16(sp)
    1698:	ec06                	sd	ra,24(sp)
    169a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    169c:	00001417          	auipc	s0,0x1
    16a0:	31c40413          	addi	s0,s0,796 # 29b8 <buffer_len>
    16a4:	05a010ef          	jal	ra,26fe <mutex_create>
    16a8:	10a42623          	sw	a0,268(s0)
    16ac:	00054a63          	bltz	a0,16c0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16b0:	4785                	li	a5,1
}
    16b2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16b4:	10f42423          	sw	a5,264(s0)
}
    16b8:	6442                	ld	s0,16(sp)
    16ba:	64a2                	ld	s1,8(sp)
    16bc:	6105                	addi	sp,sp,32
    16be:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16c0:	5ed000ef          	jal	ra,24ac <getpid>
    16c4:	84aa                	mv	s1,a0
    16c6:	00001517          	auipc	a0,0x1
    16ca:	20250513          	addi	a0,a0,514 # 28c8 <enable_deadlock_detect+0x14e>
    16ce:	4b5000ef          	jal	ra,2382 <basename>
    16d2:	872a                	mv	a4,a0
    16d4:	04800793          	li	a5,72
    16d8:	86a6                	mv	a3,s1
    16da:	00001517          	auipc	a0,0x1
    16de:	26e50513          	addi	a0,a0,622 # 2948 <enable_deadlock_detect+0x1ce>
    16e2:	00001617          	auipc	a2,0x1
    16e6:	10660613          	addi	a2,a2,262 # 27e8 <enable_deadlock_detect+0x6e>
    16ea:	45fd                	li	a1,31
    16ec:	b8fff0ef          	jal	ra,127a <printf>
    16f0:	557d                	li	a0,-1
    16f2:	5eb000ef          	jal	ra,24dc <exit>
	buffer_lock_enabled = 1;
    16f6:	4785                	li	a5,1
}
    16f8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16fa:	10f42423          	sw	a5,264(s0)
}
    16fe:	6442                	ld	s0,16(sp)
    1700:	64a2                	ld	s1,8(sp)
    1702:	6105                	addi	sp,sp,32
    1704:	8082                	ret

0000000000001706 <out_unlocked>:
{
    1706:	7159                	addi	sp,sp,-112
    1708:	f486                	sd	ra,104(sp)
    170a:	f0a2                	sd	s0,96(sp)
    170c:	eca6                	sd	s1,88(sp)
    170e:	e8ca                	sd	s2,80(sp)
    1710:	e4ce                	sd	s3,72(sp)
    1712:	e0d2                	sd	s4,64(sp)
    1714:	fc56                	sd	s5,56(sp)
    1716:	f85a                	sd	s6,48(sp)
    1718:	f45e                	sd	s7,40(sp)
    171a:	f062                	sd	s8,32(sp)
    171c:	ec66                	sd	s9,24(sp)
    171e:	e86a                	sd	s10,16(sp)
    1720:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1722:	0e058663          	beqz	a1,180e <out_unlocked+0x108>
    1726:	842a                	mv	s0,a0
    1728:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    172c:	4981                	li	s3,0
    172e:	00001d17          	auipc	s10,0x1
    1732:	28ad0d13          	addi	s10,s10,650 # 29b8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1736:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    173a:	00001b17          	auipc	s6,0x1
    173e:	286b0b13          	addi	s6,s6,646 # 29c0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1742:	10000a93          	li	s5,256
    1746:	00001c97          	auipc	s9,0x1
    174a:	182c8c93          	addi	s9,s9,386 # 28c8 <enable_deadlock_detect+0x14e>
    174e:	00001c17          	auipc	s8,0x1
    1752:	09ac0c13          	addi	s8,s8,154 # 27e8 <enable_deadlock_detect+0x6e>
    1756:	00001b97          	auipc	s7,0x1
    175a:	1b2b8b93          	addi	s7,s7,434 # 2908 <enable_deadlock_detect+0x18e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    175e:	4a29                	li	s4,10
    1760:	a031                	j	176c <out_unlocked+0x66>
    1762:	09468863          	beq	a3,s4,17f2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1766:	0405                	addi	s0,s0,1
    1768:	04848163          	beq	s1,s0,17aa <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    176c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1770:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1774:	0017861b          	addiw	a2,a5,1
    1778:	97ea                	add	a5,a5,s10
    177a:	00cd2023          	sw	a2,0(s10)
    177e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1782:	fec950e3          	bge	s2,a2,1762 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1786:	05561263          	bne	a2,s5,17ca <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    178a:	85da                	mv	a1,s6
    178c:	4505                	li	a0,1
    178e:	515000ef          	jal	ra,24a2 <write>
    1792:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1794:	00001797          	auipc	a5,0x1
    1798:	2207a223          	sw	zero,548(a5) # 29b8 <buffer_len>
			if (r < 0) {
    179c:	06054763          	bltz	a0,180a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17a0:	0405                	addi	s0,s0,1
			ret += r;
    17a2:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17a6:	fc8493e3          	bne	s1,s0,176c <out_unlocked+0x66>
}
    17aa:	70a6                	ld	ra,104(sp)
    17ac:	7406                	ld	s0,96(sp)
    17ae:	64e6                	ld	s1,88(sp)
    17b0:	6946                	ld	s2,80(sp)
    17b2:	6a06                	ld	s4,64(sp)
    17b4:	7ae2                	ld	s5,56(sp)
    17b6:	7b42                	ld	s6,48(sp)
    17b8:	7ba2                	ld	s7,40(sp)
    17ba:	7c02                	ld	s8,32(sp)
    17bc:	6ce2                	ld	s9,24(sp)
    17be:	6d42                	ld	s10,16(sp)
    17c0:	6da2                	ld	s11,8(sp)
    17c2:	854e                	mv	a0,s3
    17c4:	69a6                	ld	s3,72(sp)
    17c6:	6165                	addi	sp,sp,112
    17c8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17ca:	4e3000ef          	jal	ra,24ac <getpid>
    17ce:	8daa                	mv	s11,a0
    17d0:	8566                	mv	a0,s9
    17d2:	3b1000ef          	jal	ra,2382 <basename>
    17d6:	872a                	mv	a4,a0
    17d8:	8662                	mv	a2,s8
    17da:	05400793          	li	a5,84
    17de:	86ee                	mv	a3,s11
    17e0:	45fd                	li	a1,31
    17e2:	855e                	mv	a0,s7
    17e4:	a97ff0ef          	jal	ra,127a <printf>
    17e8:	557d                	li	a0,-1
    17ea:	4f3000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    17ee:	000d2603          	lw	a2,0(s10)
    17f2:	da35                	beqz	a2,1766 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17f4:	85da                	mv	a1,s6
    17f6:	4505                	li	a0,1
    17f8:	4ab000ef          	jal	ra,24a2 <write>
    17fc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17fe:	00001797          	auipc	a5,0x1
    1802:	1a07ad23          	sw	zero,442(a5) # 29b8 <buffer_len>
			if (r < 0) {
    1806:	f8055de3          	bgez	a0,17a0 <out_unlocked+0x9a>
    180a:	89aa                	mv	s3,a0
    180c:	bf79                	j	17aa <out_unlocked+0xa4>
	int ret = 0;
    180e:	4981                	li	s3,0
    1810:	bf69                	j	17aa <out_unlocked+0xa4>

0000000000001812 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1812:	1101                	addi	sp,sp,-32
    1814:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1816:	00001497          	auipc	s1,0x1
    181a:	1a248493          	addi	s1,s1,418 # 29b8 <buffer_len>
    181e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1820:	ec06                	sd	ra,24(sp)
    1822:	e822                	sd	s0,16(sp)
		char c = s[i];
    1824:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1828:	0017861b          	addiw	a2,a5,1
    182c:	97a6                	add	a5,a5,s1
    182e:	00e78423          	sb	a4,8(a5)
    1832:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1834:	0ff00793          	li	a5,255
    1838:	00c7cc63          	blt	a5,a2,1850 <out_unlocked.constprop.0+0x3e>
    183c:	47a9                	li	a5,10
    183e:	06f70c63          	beq	a4,a5,18b6 <out_unlocked.constprop.0+0xa4>
    1842:	4601                	li	a2,0
}
    1844:	60e2                	ld	ra,24(sp)
    1846:	6442                	ld	s0,16(sp)
    1848:	64a2                	ld	s1,8(sp)
    184a:	8532                	mv	a0,a2
    184c:	6105                	addi	sp,sp,32
    184e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1850:	10000793          	li	a5,256
    1854:	02f61563          	bne	a2,a5,187e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1858:	00001597          	auipc	a1,0x1
    185c:	16858593          	addi	a1,a1,360 # 29c0 <buffer>
    1860:	4505                	li	a0,1
    1862:	441000ef          	jal	ra,24a2 <write>
}
    1866:	60e2                	ld	ra,24(sp)
    1868:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    186a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    186e:	00001797          	auipc	a5,0x1
    1872:	1407a523          	sw	zero,330(a5) # 29b8 <buffer_len>
}
    1876:	64a2                	ld	s1,8(sp)
    1878:	8532                	mv	a0,a2
    187a:	6105                	addi	sp,sp,32
    187c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    187e:	42f000ef          	jal	ra,24ac <getpid>
    1882:	842a                	mv	s0,a0
    1884:	00001517          	auipc	a0,0x1
    1888:	04450513          	addi	a0,a0,68 # 28c8 <enable_deadlock_detect+0x14e>
    188c:	2f7000ef          	jal	ra,2382 <basename>
    1890:	872a                	mv	a4,a0
    1892:	00001617          	auipc	a2,0x1
    1896:	f5660613          	addi	a2,a2,-170 # 27e8 <enable_deadlock_detect+0x6e>
    189a:	05400793          	li	a5,84
    189e:	86a2                	mv	a3,s0
    18a0:	45fd                	li	a1,31
    18a2:	00001517          	auipc	a0,0x1
    18a6:	06650513          	addi	a0,a0,102 # 2908 <enable_deadlock_detect+0x18e>
    18aa:	9d1ff0ef          	jal	ra,127a <printf>
    18ae:	557d                	li	a0,-1
    18b0:	42d000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    18b4:	4090                	lw	a2,0(s1)
    18b6:	d659                	beqz	a2,1844 <out_unlocked.constprop.0+0x32>
    18b8:	b745                	j	1858 <out_unlocked.constprop.0+0x46>

00000000000018ba <putchar>:
{
    18ba:	7139                	addi	sp,sp,-64
    18bc:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18be:	00001497          	auipc	s1,0x1
    18c2:	0fa48493          	addi	s1,s1,250 # 29b8 <buffer_len>
    18c6:	1084a703          	lw	a4,264(s1)
{
    18ca:	f822                	sd	s0,48(sp)
	char byte = c;
    18cc:	0ff57413          	zext.b	s0,a0
{
    18d0:	fc06                	sd	ra,56(sp)
	char byte = c;
    18d2:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18d6:	4785                	li	a5,1
    18d8:	00f70d63          	beq	a4,a5,18f2 <putchar+0x38>
		len = out_unlocked(s, l);
    18dc:	01f10513          	addi	a0,sp,31
    18e0:	f33ff0ef          	jal	ra,1812 <out_unlocked.constprop.0>
}
    18e4:	70e2                	ld	ra,56(sp)
    18e6:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    18e8:	862a                	mv	a2,a0
}
    18ea:	74a2                	ld	s1,40(sp)
    18ec:	8532                	mv	a0,a2
    18ee:	6121                	addi	sp,sp,64
    18f0:	8082                	ret
		mutex_lock(buffer_lock);
    18f2:	10c4a503          	lw	a0,268(s1)
    18f6:	625000ef          	jal	ra,271a <mutex_lock>
		buffer[buffer_len++] = c;
    18fa:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18fc:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1900:	0017861b          	addiw	a2,a5,1
    1904:	97a6                	add	a5,a5,s1
    1906:	c090                	sw	a2,0(s1)
    1908:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    190c:	02c6c263          	blt	a3,a2,1930 <putchar+0x76>
    1910:	47a9                	li	a5,10
    1912:	06f40d63          	beq	s0,a5,198c <putchar+0xd2>
    1916:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1918:	10c4a503          	lw	a0,268(s1)
    191c:	e432                	sd	a2,8(sp)
    191e:	609000ef          	jal	ra,2726 <mutex_unlock>
    1922:	6622                	ld	a2,8(sp)
}
    1924:	70e2                	ld	ra,56(sp)
    1926:	7442                	ld	s0,48(sp)
    1928:	74a2                	ld	s1,40(sp)
    192a:	8532                	mv	a0,a2
    192c:	6121                	addi	sp,sp,64
    192e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1930:	10000793          	li	a5,256
    1934:	02f61063          	bne	a2,a5,1954 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1938:	00001597          	auipc	a1,0x1
    193c:	08858593          	addi	a1,a1,136 # 29c0 <buffer>
    1940:	4505                	li	a0,1
    1942:	361000ef          	jal	ra,24a2 <write>
    1946:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    194a:	00001797          	auipc	a5,0x1
    194e:	0607a723          	sw	zero,110(a5) # 29b8 <buffer_len>
			if (r < 0) {
    1952:	b7d9                	j	1918 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1954:	359000ef          	jal	ra,24ac <getpid>
    1958:	842a                	mv	s0,a0
    195a:	00001517          	auipc	a0,0x1
    195e:	f6e50513          	addi	a0,a0,-146 # 28c8 <enable_deadlock_detect+0x14e>
    1962:	221000ef          	jal	ra,2382 <basename>
    1966:	872a                	mv	a4,a0
    1968:	00001617          	auipc	a2,0x1
    196c:	e8060613          	addi	a2,a2,-384 # 27e8 <enable_deadlock_detect+0x6e>
    1970:	05400793          	li	a5,84
    1974:	86a2                	mv	a3,s0
    1976:	45fd                	li	a1,31
    1978:	00001517          	auipc	a0,0x1
    197c:	f9050513          	addi	a0,a0,-112 # 2908 <enable_deadlock_detect+0x18e>
    1980:	8fbff0ef          	jal	ra,127a <printf>
    1984:	557d                	li	a0,-1
    1986:	357000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    198a:	4090                	lw	a2,0(s1)
    198c:	d651                	beqz	a2,1918 <putchar+0x5e>
    198e:	b76d                	j	1938 <putchar+0x7e>

0000000000001990 <puts>:
{
    1990:	7139                	addi	sp,sp,-64
    1992:	f822                	sd	s0,48(sp)
    1994:	f426                	sd	s1,40(sp)
    1996:	fc06                	sd	ra,56(sp)
    1998:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    199a:	00001417          	auipc	s0,0x1
    199e:	01e40413          	addi	s0,s0,30 # 29b8 <buffer_len>
{
    19a2:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19a4:	638000ef          	jal	ra,1fdc <strlen>
	if (buffer_lock_enabled == 1) {
    19a8:	10842703          	lw	a4,264(s0)
    19ac:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19ae:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19b0:	04f70563          	beq	a4,a5,19fa <puts+0x6a>
		len = out_unlocked(s, l);
    19b4:	8526                	mv	a0,s1
    19b6:	d51ff0ef          	jal	ra,1706 <out_unlocked>
    19ba:	892a                	mv	s2,a0
    19bc:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19be:	00095963          	bgez	s2,19d0 <puts+0x40>
}
    19c2:	70e2                	ld	ra,56(sp)
    19c4:	7442                	ld	s0,48(sp)
    19c6:	7902                	ld	s2,32(sp)
    19c8:	8526                	mv	a0,s1
    19ca:	74a2                	ld	s1,40(sp)
    19cc:	6121                	addi	sp,sp,64
    19ce:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19d0:	10842703          	lw	a4,264(s0)
	char byte = c;
    19d4:	44a9                	li	s1,10
    19d6:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19da:	4785                	li	a5,1
    19dc:	02f70e63          	beq	a4,a5,1a18 <puts+0x88>
		len = out_unlocked(s, l);
    19e0:	01f10513          	addi	a0,sp,31
    19e4:	e2fff0ef          	jal	ra,1812 <out_unlocked.constprop.0>
}
    19e8:	70e2                	ld	ra,56(sp)
    19ea:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19ec:	41f5549b          	sraiw	s1,a0,0x1f
}
    19f0:	7902                	ld	s2,32(sp)
    19f2:	8526                	mv	a0,s1
    19f4:	74a2                	ld	s1,40(sp)
    19f6:	6121                	addi	sp,sp,64
    19f8:	8082                	ret
		mutex_lock(buffer_lock);
    19fa:	e42a                	sd	a0,8(sp)
    19fc:	10c42503          	lw	a0,268(s0)
    1a00:	51b000ef          	jal	ra,271a <mutex_lock>
		len = out_unlocked(s, l);
    1a04:	65a2                	ld	a1,8(sp)
    1a06:	8526                	mv	a0,s1
    1a08:	cffff0ef          	jal	ra,1706 <out_unlocked>
    1a0c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a0e:	10c42503          	lw	a0,268(s0)
    1a12:	515000ef          	jal	ra,2726 <mutex_unlock>
    1a16:	b75d                	j	19bc <puts+0x2c>
		mutex_lock(buffer_lock);
    1a18:	10c42503          	lw	a0,268(s0)
    1a1c:	4ff000ef          	jal	ra,271a <mutex_lock>
		buffer[buffer_len++] = c;
    1a20:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a22:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a26:	0017861b          	addiw	a2,a5,1
    1a2a:	97a2                	add	a5,a5,s0
    1a2c:	c010                	sw	a2,0(s0)
    1a2e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a32:	06c6dc63          	bge	a3,a2,1aaa <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a36:	10000793          	li	a5,256
    1a3a:	02f61c63          	bne	a2,a5,1a72 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a3e:	00001597          	auipc	a1,0x1
    1a42:	f8258593          	addi	a1,a1,-126 # 29c0 <buffer>
    1a46:	4505                	li	a0,1
    1a48:	25b000ef          	jal	ra,24a2 <write>
			if (r < 0) {
    1a4c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a4e:	00001797          	auipc	a5,0x1
    1a52:	f607a523          	sw	zero,-150(a5) # 29b8 <buffer_len>
			if (r < 0) {
    1a56:	04054c63          	bltz	a0,1aae <puts+0x11e>
			if (r < buffer_len) {
    1a5a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a5c:	10c42503          	lw	a0,268(s0)
    1a60:	4c7000ef          	jal	ra,2726 <mutex_unlock>
}
    1a64:	70e2                	ld	ra,56(sp)
    1a66:	7442                	ld	s0,48(sp)
    1a68:	7902                	ld	s2,32(sp)
    1a6a:	8526                	mv	a0,s1
    1a6c:	74a2                	ld	s1,40(sp)
    1a6e:	6121                	addi	sp,sp,64
    1a70:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a72:	23b000ef          	jal	ra,24ac <getpid>
    1a76:	84aa                	mv	s1,a0
    1a78:	00001517          	auipc	a0,0x1
    1a7c:	e5050513          	addi	a0,a0,-432 # 28c8 <enable_deadlock_detect+0x14e>
    1a80:	103000ef          	jal	ra,2382 <basename>
    1a84:	872a                	mv	a4,a0
    1a86:	00001617          	auipc	a2,0x1
    1a8a:	d6260613          	addi	a2,a2,-670 # 27e8 <enable_deadlock_detect+0x6e>
    1a8e:	05400793          	li	a5,84
    1a92:	86a6                	mv	a3,s1
    1a94:	45fd                	li	a1,31
    1a96:	00001517          	auipc	a0,0x1
    1a9a:	e7250513          	addi	a0,a0,-398 # 2908 <enable_deadlock_detect+0x18e>
    1a9e:	fdcff0ef          	jal	ra,127a <printf>
    1aa2:	557d                	li	a0,-1
    1aa4:	239000ef          	jal	ra,24dc <exit>
	if (buffer_len == 0)
    1aa8:	4010                	lw	a2,0(s0)
    1aaa:	da45                	beqz	a2,1a5a <puts+0xca>
    1aac:	bf49                	j	1a3e <puts+0xae>
    1aae:	54fd                	li	s1,-1
    1ab0:	b775                	j	1a5c <puts+0xcc>

0000000000001ab2 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ab2:	715d                	addi	sp,sp,-80
    1ab4:	e486                	sd	ra,72(sp)
    1ab6:	e0a2                	sd	s0,64(sp)
    1ab8:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1aba:	14054363          	bltz	a0,1c00 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1abe:	02b577bb          	remuw	a5,a0,a1
    1ac2:	00001617          	auipc	a2,0x1
    1ac6:	00e60613          	addi	a2,a2,14 # 2ad0 <digits>
	buf[16] = 0;
    1aca:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ace:	0005871b          	sext.w	a4,a1
    1ad2:	1782                	slli	a5,a5,0x20
    1ad4:	9381                	srli	a5,a5,0x20
    1ad6:	97b2                	add	a5,a5,a2
    1ad8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1adc:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ae0:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ae4:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ae6:	0eb56763          	bltu	a0,a1,1bd4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aea:	02e877bb          	remuw	a5,a6,a4
    1aee:	1782                	slli	a5,a5,0x20
    1af0:	9381                	srli	a5,a5,0x20
    1af2:	97b2                	add	a5,a5,a2
    1af4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1af8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1afc:	02f10323          	sb	a5,38(sp)
    1b00:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b02:	0ce86963          	bltu	a6,a4,1bd4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b06:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b0a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b0e:	1582                	slli	a1,a1,0x20
    1b10:	9181                	srli	a1,a1,0x20
    1b12:	95b2                	add	a1,a1,a2
    1b14:	0005c583          	lbu	a1,0(a1)
    1b18:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b1c:	0007859b          	sext.w	a1,a5
    1b20:	16e6e563          	bltu	a3,a4,1c8a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b24:	02e7f6bb          	remuw	a3,a5,a4
    1b28:	1682                	slli	a3,a3,0x20
    1b2a:	9281                	srli	a3,a3,0x20
    1b2c:	96b2                	add	a3,a3,a2
    1b2e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b32:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b36:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b3a:	16e5e163          	bltu	a1,a4,1c9c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b3e:	02e876bb          	remuw	a3,a6,a4
    1b42:	1682                	slli	a3,a3,0x20
    1b44:	9281                	srli	a3,a3,0x20
    1b46:	96b2                	add	a3,a3,a2
    1b48:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b4c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b50:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b54:	14e86d63          	bltu	a6,a4,1cae <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b58:	02e5f6bb          	remuw	a3,a1,a4
    1b5c:	1682                	slli	a3,a3,0x20
    1b5e:	9281                	srli	a3,a3,0x20
    1b60:	96b2                	add	a3,a3,a2
    1b62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b66:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b6a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b6e:	10e5e563          	bltu	a1,a4,1c78 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b72:	02e876bb          	remuw	a3,a6,a4
    1b76:	1682                	slli	a3,a3,0x20
    1b78:	9281                	srli	a3,a3,0x20
    1b7a:	96b2                	add	a3,a3,a2
    1b7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b80:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b84:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b88:	14e86263          	bltu	a6,a4,1ccc <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b8c:	02e5f6bb          	remuw	a3,a1,a4
    1b90:	1682                	slli	a3,a3,0x20
    1b92:	9281                	srli	a3,a3,0x20
    1b94:	96b2                	add	a3,a3,a2
    1b96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b9a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b9e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ba2:	14e5e463          	bltu	a1,a4,1cea <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ba6:	02e876bb          	remuw	a3,a6,a4
    1baa:	1682                	slli	a3,a3,0x20
    1bac:	9281                	srli	a3,a3,0x20
    1bae:	96b2                	add	a3,a3,a2
    1bb0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bb4:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1bb8:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1bbc:	14e86063          	bltu	a6,a4,1cfc <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1bc0:	1782                	slli	a5,a5,0x20
    1bc2:	9381                	srli	a5,a5,0x20
    1bc4:	97b2                	add	a5,a5,a2
    1bc6:	0007c703          	lbu	a4,0(a5)
    1bca:	4799                	li	a5,6
    1bcc:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1bd0:	10054763          	bltz	a0,1cde <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1bd4:	00001497          	auipc	s1,0x1
    1bd8:	de448493          	addi	s1,s1,-540 # 29b8 <buffer_len>
    1bdc:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1be0:	0828                	addi	a0,sp,24
    1be2:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1be4:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1be6:	00f50433          	add	s0,a0,a5
    1bea:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1bec:	06e68463          	beq	a3,a4,1c54 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1bf0:	8522                	mv	a0,s0
    1bf2:	b15ff0ef          	jal	ra,1706 <out_unlocked>
}
    1bf6:	60a6                	ld	ra,72(sp)
    1bf8:	6406                	ld	s0,64(sp)
    1bfa:	74e2                	ld	s1,56(sp)
    1bfc:	6161                	addi	sp,sp,80
    1bfe:	8082                	ret
		x = -xx;
    1c00:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c04:	02b877bb          	remuw	a5,a6,a1
    1c08:	00001617          	auipc	a2,0x1
    1c0c:	ec860613          	addi	a2,a2,-312 # 2ad0 <digits>
	buf[16] = 0;
    1c10:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c14:	0005871b          	sext.w	a4,a1
    1c18:	1782                	slli	a5,a5,0x20
    1c1a:	9381                	srli	a5,a5,0x20
    1c1c:	97b2                	add	a5,a5,a2
    1c1e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c22:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c26:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c2a:	08b86b63          	bltu	a6,a1,1cc0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c2e:	02e8f7bb          	remuw	a5,a7,a4
    1c32:	1782                	slli	a5,a5,0x20
    1c34:	9381                	srli	a5,a5,0x20
    1c36:	97b2                	add	a5,a5,a2
    1c38:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c3c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c40:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c44:	ece8f1e3          	bgeu	a7,a4,1b06 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c48:	02d00793          	li	a5,45
    1c4c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c50:	47b5                	li	a5,13
    1c52:	b749                	j	1bd4 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c54:	10c4a503          	lw	a0,268(s1)
    1c58:	e42e                	sd	a1,8(sp)
    1c5a:	2c1000ef          	jal	ra,271a <mutex_lock>
		len = out_unlocked(s, l);
    1c5e:	65a2                	ld	a1,8(sp)
    1c60:	8522                	mv	a0,s0
    1c62:	aa5ff0ef          	jal	ra,1706 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c66:	10c4a503          	lw	a0,268(s1)
    1c6a:	2bd000ef          	jal	ra,2726 <mutex_unlock>
}
    1c6e:	60a6                	ld	ra,72(sp)
    1c70:	6406                	ld	s0,64(sp)
    1c72:	74e2                	ld	s1,56(sp)
    1c74:	6161                	addi	sp,sp,80
    1c76:	8082                	ret
		buf[i--] = digits[x % base];
    1c78:	47a9                	li	a5,10
	if (sign)
    1c7a:	f4055de3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c7e:	02d00793          	li	a5,45
    1c82:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c86:	47a5                	li	a5,9
    1c88:	b7b1                	j	1bd4 <printint.constprop.0+0x122>
    1c8a:	47b5                	li	a5,13
	if (sign)
    1c8c:	f40554e3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c90:	02d00793          	li	a5,45
    1c94:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c98:	47b1                	li	a5,12
    1c9a:	bf2d                	j	1bd4 <printint.constprop.0+0x122>
    1c9c:	47b1                	li	a5,12
	if (sign)
    1c9e:	f2055be3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca2:	02d00793          	li	a5,45
    1ca6:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1caa:	47ad                	li	a5,11
    1cac:	b725                	j	1bd4 <printint.constprop.0+0x122>
    1cae:	47ad                	li	a5,11
	if (sign)
    1cb0:	f20552e3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb4:	02d00793          	li	a5,45
    1cb8:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1cbc:	47a9                	li	a5,10
    1cbe:	bf19                	j	1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc0:	02d00793          	li	a5,45
    1cc4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cc8:	47b9                	li	a5,14
    1cca:	b729                	j	1bd4 <printint.constprop.0+0x122>
    1ccc:	47a5                	li	a5,9
	if (sign)
    1cce:	f00553e3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd2:	02d00793          	li	a5,45
    1cd6:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1cda:	47a1                	li	a5,8
    1cdc:	bde5                	j	1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cde:	02d00793          	li	a5,45
    1ce2:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ce6:	4795                	li	a5,5
    1ce8:	b5f5                	j	1bd4 <printint.constprop.0+0x122>
    1cea:	47a1                	li	a5,8
	if (sign)
    1cec:	ee0554e3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf0:	02d00793          	li	a5,45
    1cf4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1cf8:	479d                	li	a5,7
    1cfa:	bde9                	j	1bd4 <printint.constprop.0+0x122>
    1cfc:	479d                	li	a5,7
	if (sign)
    1cfe:	ec055be3          	bgez	a0,1bd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d02:	02d00793          	li	a5,45
    1d06:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d0a:	4799                	li	a5,6
    1d0c:	b5e1                	j	1bd4 <printint.constprop.0+0x122>

0000000000001d0e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d0e:	02000793          	li	a5,32
    1d12:	00f50663          	beq	a0,a5,1d1e <isspace+0x10>
    1d16:	355d                	addiw	a0,a0,-9
    1d18:	00553513          	sltiu	a0,a0,5
    1d1c:	8082                	ret
    1d1e:	4505                	li	a0,1
}
    1d20:	8082                	ret

0000000000001d22 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d22:	fd05051b          	addiw	a0,a0,-48
}
    1d26:	00a53513          	sltiu	a0,a0,10
    1d2a:	8082                	ret

0000000000001d2c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d2c:	02000613          	li	a2,32
    1d30:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d32:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d36:	ff77869b          	addiw	a3,a5,-9
    1d3a:	04c78c63          	beq	a5,a2,1d92 <atoi+0x66>
    1d3e:	0007871b          	sext.w	a4,a5
    1d42:	04d5f863          	bgeu	a1,a3,1d92 <atoi+0x66>
		s++;
	switch (*s) {
    1d46:	02b00693          	li	a3,43
    1d4a:	04d78963          	beq	a5,a3,1d9c <atoi+0x70>
    1d4e:	02d00693          	li	a3,45
    1d52:	06d78263          	beq	a5,a3,1db6 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d56:	fd07061b          	addiw	a2,a4,-48
    1d5a:	47a5                	li	a5,9
    1d5c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d5e:	4e01                	li	t3,0
	while (isdigit(*s))
    1d60:	04c7e963          	bltu	a5,a2,1db2 <atoi+0x86>
	int n = 0, neg = 0;
    1d64:	4501                	li	a0,0
	while (isdigit(*s))
    1d66:	4825                	li	a6,9
    1d68:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d6c:	0025179b          	slliw	a5,a0,0x2
    1d70:	9fa9                	addw	a5,a5,a0
    1d72:	fd07031b          	addiw	t1,a4,-48
    1d76:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d7a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d7e:	0685                	addi	a3,a3,1
    1d80:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d84:	0006071b          	sext.w	a4,a2
    1d88:	feb870e3          	bgeu	a6,a1,1d68 <atoi+0x3c>
	return neg ? n : -n;
    1d8c:	000e0563          	beqz	t3,1d96 <atoi+0x6a>
}
    1d90:	8082                	ret
		s++;
    1d92:	0505                	addi	a0,a0,1
    1d94:	bf79                	j	1d32 <atoi+0x6>
	return neg ? n : -n;
    1d96:	4113053b          	subw	a0,t1,a7
    1d9a:	8082                	ret
	while (isdigit(*s))
    1d9c:	00154703          	lbu	a4,1(a0)
    1da0:	47a5                	li	a5,9
		s++;
    1da2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1da6:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1daa:	4e01                	li	t3,0
	while (isdigit(*s))
    1dac:	2701                	sext.w	a4,a4
    1dae:	fac7fbe3          	bgeu	a5,a2,1d64 <atoi+0x38>
    1db2:	4501                	li	a0,0
}
    1db4:	8082                	ret
	while (isdigit(*s))
    1db6:	00154703          	lbu	a4,1(a0)
    1dba:	47a5                	li	a5,9
		s++;
    1dbc:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dc0:	fd07061b          	addiw	a2,a4,-48
    1dc4:	2701                	sext.w	a4,a4
    1dc6:	fec7e6e3          	bltu	a5,a2,1db2 <atoi+0x86>
		neg = 1;
    1dca:	4e05                	li	t3,1
    1dcc:	bf61                	j	1d64 <atoi+0x38>

0000000000001dce <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1dce:	16060d63          	beqz	a2,1f48 <memset+0x17a>
    1dd2:	40a007b3          	neg	a5,a0
    1dd6:	8b9d                	andi	a5,a5,7
    1dd8:	00778693          	addi	a3,a5,7
    1ddc:	482d                	li	a6,11
    1dde:	0ff5f713          	zext.b	a4,a1
    1de2:	fff60593          	addi	a1,a2,-1
    1de6:	1706e263          	bltu	a3,a6,1f4a <memset+0x17c>
    1dea:	16d5ea63          	bltu	a1,a3,1f5e <memset+0x190>
    1dee:	16078563          	beqz	a5,1f58 <memset+0x18a>
    1df2:	00e50023          	sb	a4,0(a0)
    1df6:	4685                	li	a3,1
    1df8:	00150593          	addi	a1,a0,1
    1dfc:	14d78c63          	beq	a5,a3,1f54 <memset+0x186>
    1e00:	00e500a3          	sb	a4,1(a0)
    1e04:	4689                	li	a3,2
    1e06:	00250593          	addi	a1,a0,2
    1e0a:	14d78d63          	beq	a5,a3,1f64 <memset+0x196>
    1e0e:	00e50123          	sb	a4,2(a0)
    1e12:	468d                	li	a3,3
    1e14:	00350593          	addi	a1,a0,3
    1e18:	12d78b63          	beq	a5,a3,1f4e <memset+0x180>
    1e1c:	00e501a3          	sb	a4,3(a0)
    1e20:	4691                	li	a3,4
    1e22:	00450593          	addi	a1,a0,4
    1e26:	14d78163          	beq	a5,a3,1f68 <memset+0x19a>
    1e2a:	00e50223          	sb	a4,4(a0)
    1e2e:	4695                	li	a3,5
    1e30:	00550593          	addi	a1,a0,5
    1e34:	12d78c63          	beq	a5,a3,1f6c <memset+0x19e>
    1e38:	00e502a3          	sb	a4,5(a0)
    1e3c:	469d                	li	a3,7
    1e3e:	00650593          	addi	a1,a0,6
    1e42:	12d79763          	bne	a5,a3,1f70 <memset+0x1a2>
    1e46:	00750593          	addi	a1,a0,7
    1e4a:	00e50323          	sb	a4,6(a0)
    1e4e:	481d                	li	a6,7
    1e50:	00871693          	slli	a3,a4,0x8
    1e54:	01071893          	slli	a7,a4,0x10
    1e58:	8ed9                	or	a3,a3,a4
    1e5a:	01871313          	slli	t1,a4,0x18
    1e5e:	0116e6b3          	or	a3,a3,a7
    1e62:	0066e6b3          	or	a3,a3,t1
    1e66:	02071893          	slli	a7,a4,0x20
    1e6a:	02871e13          	slli	t3,a4,0x28
    1e6e:	0116e6b3          	or	a3,a3,a7
    1e72:	40f60333          	sub	t1,a2,a5
    1e76:	03071893          	slli	a7,a4,0x30
    1e7a:	01c6e6b3          	or	a3,a3,t3
    1e7e:	0116e6b3          	or	a3,a3,a7
    1e82:	03871e13          	slli	t3,a4,0x38
    1e86:	97aa                	add	a5,a5,a0
    1e88:	ff837893          	andi	a7,t1,-8
    1e8c:	01c6e6b3          	or	a3,a3,t3
    1e90:	98be                	add	a7,a7,a5
    1e92:	e394                	sd	a3,0(a5)
    1e94:	07a1                	addi	a5,a5,8
    1e96:	ff179ee3          	bne	a5,a7,1e92 <memset+0xc4>
    1e9a:	ff837893          	andi	a7,t1,-8
    1e9e:	011587b3          	add	a5,a1,a7
    1ea2:	010886bb          	addw	a3,a7,a6
    1ea6:	0b130663          	beq	t1,a7,1f52 <memset+0x184>
    1eaa:	00e78023          	sb	a4,0(a5)
    1eae:	0016859b          	addiw	a1,a3,1
    1eb2:	08c5fb63          	bgeu	a1,a2,1f48 <memset+0x17a>
    1eb6:	00e780a3          	sb	a4,1(a5)
    1eba:	0026859b          	addiw	a1,a3,2
    1ebe:	08c5f563          	bgeu	a1,a2,1f48 <memset+0x17a>
    1ec2:	00e78123          	sb	a4,2(a5)
    1ec6:	0036859b          	addiw	a1,a3,3
    1eca:	06c5ff63          	bgeu	a1,a2,1f48 <memset+0x17a>
    1ece:	00e781a3          	sb	a4,3(a5)
    1ed2:	0046859b          	addiw	a1,a3,4
    1ed6:	06c5f963          	bgeu	a1,a2,1f48 <memset+0x17a>
    1eda:	00e78223          	sb	a4,4(a5)
    1ede:	0056859b          	addiw	a1,a3,5
    1ee2:	06c5f363          	bgeu	a1,a2,1f48 <memset+0x17a>
    1ee6:	00e782a3          	sb	a4,5(a5)
    1eea:	0066859b          	addiw	a1,a3,6
    1eee:	04c5fd63          	bgeu	a1,a2,1f48 <memset+0x17a>
    1ef2:	00e78323          	sb	a4,6(a5)
    1ef6:	0076859b          	addiw	a1,a3,7
    1efa:	04c5f763          	bgeu	a1,a2,1f48 <memset+0x17a>
    1efe:	00e783a3          	sb	a4,7(a5)
    1f02:	0086859b          	addiw	a1,a3,8
    1f06:	04c5f163          	bgeu	a1,a2,1f48 <memset+0x17a>
    1f0a:	00e78423          	sb	a4,8(a5)
    1f0e:	0096859b          	addiw	a1,a3,9
    1f12:	02c5fb63          	bgeu	a1,a2,1f48 <memset+0x17a>
    1f16:	00e784a3          	sb	a4,9(a5)
    1f1a:	00a6859b          	addiw	a1,a3,10
    1f1e:	02c5f563          	bgeu	a1,a2,1f48 <memset+0x17a>
    1f22:	00e78523          	sb	a4,10(a5)
    1f26:	00b6859b          	addiw	a1,a3,11
    1f2a:	00c5ff63          	bgeu	a1,a2,1f48 <memset+0x17a>
    1f2e:	00e785a3          	sb	a4,11(a5)
    1f32:	00c6859b          	addiw	a1,a3,12
    1f36:	00c5f963          	bgeu	a1,a2,1f48 <memset+0x17a>
    1f3a:	00e78623          	sb	a4,12(a5)
    1f3e:	26b5                	addiw	a3,a3,13
    1f40:	00c6f463          	bgeu	a3,a2,1f48 <memset+0x17a>
    1f44:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f48:	8082                	ret
    1f4a:	46ad                	li	a3,11
    1f4c:	bd79                	j	1dea <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f4e:	480d                	li	a6,3
    1f50:	b701                	j	1e50 <memset+0x82>
    1f52:	8082                	ret
    1f54:	4805                	li	a6,1
    1f56:	bded                	j	1e50 <memset+0x82>
    1f58:	85aa                	mv	a1,a0
    1f5a:	4801                	li	a6,0
    1f5c:	bdd5                	j	1e50 <memset+0x82>
    1f5e:	87aa                	mv	a5,a0
    1f60:	4681                	li	a3,0
    1f62:	b7a1                	j	1eaa <memset+0xdc>
    1f64:	4809                	li	a6,2
    1f66:	b5ed                	j	1e50 <memset+0x82>
    1f68:	4811                	li	a6,4
    1f6a:	b5dd                	j	1e50 <memset+0x82>
    1f6c:	4815                	li	a6,5
    1f6e:	b5cd                	j	1e50 <memset+0x82>
    1f70:	4819                	li	a6,6
    1f72:	bdf9                	j	1e50 <memset+0x82>

0000000000001f74 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f74:	00054783          	lbu	a5,0(a0)
    1f78:	0005c703          	lbu	a4,0(a1)
    1f7c:	00e79863          	bne	a5,a4,1f8c <strcmp+0x18>
    1f80:	0505                	addi	a0,a0,1
    1f82:	0585                	addi	a1,a1,1
    1f84:	fbe5                	bnez	a5,1f74 <strcmp>
    1f86:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f88:	9d19                	subw	a0,a0,a4
    1f8a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f8c:	0007851b          	sext.w	a0,a5
    1f90:	bfe5                	j	1f88 <strcmp+0x14>

0000000000001f92 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f92:	ca15                	beqz	a2,1fc6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f94:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f98:	167d                	addi	a2,a2,-1
    1f9a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f9e:	eb99                	bnez	a5,1fb4 <strncmp+0x22>
    1fa0:	a815                	j	1fd4 <strncmp+0x42>
    1fa2:	00a68e63          	beq	a3,a0,1fbe <strncmp+0x2c>
    1fa6:	0505                	addi	a0,a0,1
    1fa8:	00f71b63          	bne	a4,a5,1fbe <strncmp+0x2c>
    1fac:	00054783          	lbu	a5,0(a0)
    1fb0:	cf89                	beqz	a5,1fca <strncmp+0x38>
    1fb2:	85b2                	mv	a1,a2
    1fb4:	0005c703          	lbu	a4,0(a1)
    1fb8:	00158613          	addi	a2,a1,1
    1fbc:	f37d                	bnez	a4,1fa2 <strncmp+0x10>
		;
	return *l - *r;
    1fbe:	0007851b          	sext.w	a0,a5
    1fc2:	9d19                	subw	a0,a0,a4
    1fc4:	8082                	ret
		return 0;
    1fc6:	4501                	li	a0,0
}
    1fc8:	8082                	ret
	return *l - *r;
    1fca:	0015c703          	lbu	a4,1(a1)
    1fce:	4501                	li	a0,0
    1fd0:	9d19                	subw	a0,a0,a4
    1fd2:	8082                	ret
    1fd4:	0005c703          	lbu	a4,0(a1)
    1fd8:	4501                	li	a0,0
    1fda:	b7e5                	j	1fc2 <strncmp+0x30>

0000000000001fdc <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1fdc:	00757793          	andi	a5,a0,7
    1fe0:	cf89                	beqz	a5,1ffa <strlen+0x1e>
    1fe2:	87aa                	mv	a5,a0
    1fe4:	a029                	j	1fee <strlen+0x12>
    1fe6:	0785                	addi	a5,a5,1
    1fe8:	0077f713          	andi	a4,a5,7
    1fec:	cb01                	beqz	a4,1ffc <strlen+0x20>
		if (!*s)
    1fee:	0007c703          	lbu	a4,0(a5)
    1ff2:	fb75                	bnez	a4,1fe6 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1ff4:	40a78533          	sub	a0,a5,a0
}
    1ff8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1ffa:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1ffc:	6394                	ld	a3,0(a5)
    1ffe:	00001597          	auipc	a1,0x1
    2002:	9a25b583          	ld	a1,-1630(a1) # 29a0 <enable_deadlock_detect+0x226>
    2006:	00001617          	auipc	a2,0x1
    200a:	9a263603          	ld	a2,-1630(a2) # 29a8 <enable_deadlock_detect+0x22e>
    200e:	a019                	j	2014 <strlen+0x38>
    2010:	6794                	ld	a3,8(a5)
    2012:	07a1                	addi	a5,a5,8
    2014:	00b68733          	add	a4,a3,a1
    2018:	fff6c693          	not	a3,a3
    201c:	8f75                	and	a4,a4,a3
    201e:	8f71                	and	a4,a4,a2
    2020:	db65                	beqz	a4,2010 <strlen+0x34>
	for (; *s; s++)
    2022:	0007c703          	lbu	a4,0(a5)
    2026:	d779                	beqz	a4,1ff4 <strlen+0x18>
    2028:	0017c703          	lbu	a4,1(a5)
    202c:	0785                	addi	a5,a5,1
    202e:	d379                	beqz	a4,1ff4 <strlen+0x18>
    2030:	0017c703          	lbu	a4,1(a5)
    2034:	0785                	addi	a5,a5,1
    2036:	fb6d                	bnez	a4,2028 <strlen+0x4c>
    2038:	bf75                	j	1ff4 <strlen+0x18>

000000000000203a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    203a:	00757713          	andi	a4,a0,7
{
    203e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2040:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2044:	cb19                	beqz	a4,205a <memchr+0x20>
    2046:	ce25                	beqz	a2,20be <memchr+0x84>
    2048:	0007c703          	lbu	a4,0(a5)
    204c:	04b70e63          	beq	a4,a1,20a8 <memchr+0x6e>
    2050:	0785                	addi	a5,a5,1
    2052:	0077f713          	andi	a4,a5,7
    2056:	167d                	addi	a2,a2,-1
    2058:	f77d                	bnez	a4,2046 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    205a:	4501                	li	a0,0
	if (n && *s != c) {
    205c:	c235                	beqz	a2,20c0 <memchr+0x86>
    205e:	0007c703          	lbu	a4,0(a5)
    2062:	04b70363          	beq	a4,a1,20a8 <memchr+0x6e>
		size_t k = ONES * c;
    2066:	00001517          	auipc	a0,0x1
    206a:	94a53503          	ld	a0,-1718(a0) # 29b0 <enable_deadlock_detect+0x236>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    206e:	471d                	li	a4,7
		size_t k = ONES * c;
    2070:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2074:	02c77a63          	bgeu	a4,a2,20a8 <memchr+0x6e>
    2078:	00001897          	auipc	a7,0x1
    207c:	9288b883          	ld	a7,-1752(a7) # 29a0 <enable_deadlock_detect+0x226>
    2080:	00001817          	auipc	a6,0x1
    2084:	92883803          	ld	a6,-1752(a6) # 29a8 <enable_deadlock_detect+0x22e>
    2088:	431d                	li	t1,7
    208a:	a029                	j	2094 <memchr+0x5a>
		     w++, n -= SS)
    208c:	1661                	addi	a2,a2,-8
    208e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2090:	02c37963          	bgeu	t1,a2,20c2 <memchr+0x88>
    2094:	6398                	ld	a4,0(a5)
    2096:	8f29                	xor	a4,a4,a0
    2098:	011706b3          	add	a3,a4,a7
    209c:	fff74713          	not	a4,a4
    20a0:	8f75                	and	a4,a4,a3
    20a2:	01077733          	and	a4,a4,a6
    20a6:	d37d                	beqz	a4,208c <memchr+0x52>
{
    20a8:	853e                	mv	a0,a5
    20aa:	97b2                	add	a5,a5,a2
    20ac:	a021                	j	20b4 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20ae:	0505                	addi	a0,a0,1
    20b0:	00f50763          	beq	a0,a5,20be <memchr+0x84>
    20b4:	00054703          	lbu	a4,0(a0)
    20b8:	feb71be3          	bne	a4,a1,20ae <memchr+0x74>
    20bc:	8082                	ret
	return n ? (void *)s : 0;
    20be:	4501                	li	a0,0
}
    20c0:	8082                	ret
	return n ? (void *)s : 0;
    20c2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20c4:	f275                	bnez	a2,20a8 <memchr+0x6e>
}
    20c6:	8082                	ret

00000000000020c8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20c8:	1101                	addi	sp,sp,-32
    20ca:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20cc:	862e                	mv	a2,a1
{
    20ce:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20d0:	4581                	li	a1,0
{
    20d2:	e426                	sd	s1,8(sp)
    20d4:	ec06                	sd	ra,24(sp)
    20d6:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20d8:	f63ff0ef          	jal	ra,203a <memchr>
	return p ? p - s : n;
    20dc:	c519                	beqz	a0,20ea <strnlen+0x22>
}
    20de:	60e2                	ld	ra,24(sp)
    20e0:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    20e2:	8d05                	sub	a0,a0,s1
}
    20e4:	64a2                	ld	s1,8(sp)
    20e6:	6105                	addi	sp,sp,32
    20e8:	8082                	ret
    20ea:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20ec:	8522                	mv	a0,s0
}
    20ee:	6442                	ld	s0,16(sp)
    20f0:	64a2                	ld	s1,8(sp)
    20f2:	6105                	addi	sp,sp,32
    20f4:	8082                	ret

00000000000020f6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20f6:	00a5c7b3          	xor	a5,a1,a0
    20fa:	8b9d                	andi	a5,a5,7
    20fc:	eb95                	bnez	a5,2130 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20fe:	0075f793          	andi	a5,a1,7
    2102:	e7b1                	bnez	a5,214e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2104:	6198                	ld	a4,0(a1)
    2106:	00001617          	auipc	a2,0x1
    210a:	89a63603          	ld	a2,-1894(a2) # 29a0 <enable_deadlock_detect+0x226>
    210e:	00001817          	auipc	a6,0x1
    2112:	89a83803          	ld	a6,-1894(a6) # 29a8 <enable_deadlock_detect+0x22e>
    2116:	a029                	j	2120 <stpcpy+0x2a>
    2118:	05a1                	addi	a1,a1,8
    211a:	e118                	sd	a4,0(a0)
    211c:	6198                	ld	a4,0(a1)
    211e:	0521                	addi	a0,a0,8
    2120:	00c707b3          	add	a5,a4,a2
    2124:	fff74693          	not	a3,a4
    2128:	8ff5                	and	a5,a5,a3
    212a:	0107f7b3          	and	a5,a5,a6
    212e:	d7ed                	beqz	a5,2118 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2130:	0005c783          	lbu	a5,0(a1)
    2134:	00f50023          	sb	a5,0(a0)
    2138:	c785                	beqz	a5,2160 <stpcpy+0x6a>
    213a:	0015c783          	lbu	a5,1(a1)
    213e:	0505                	addi	a0,a0,1
    2140:	0585                	addi	a1,a1,1
    2142:	00f50023          	sb	a5,0(a0)
    2146:	fbf5                	bnez	a5,213a <stpcpy+0x44>
		;
	return d;
}
    2148:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    214a:	0505                	addi	a0,a0,1
    214c:	df45                	beqz	a4,2104 <stpcpy+0xe>
			if (!(*d = *s))
    214e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2152:	0585                	addi	a1,a1,1
    2154:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2158:	00f50023          	sb	a5,0(a0)
    215c:	f7fd                	bnez	a5,214a <stpcpy+0x54>
}
    215e:	8082                	ret
    2160:	8082                	ret

0000000000002162 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2162:	00a5c7b3          	xor	a5,a1,a0
    2166:	8b9d                	andi	a5,a5,7
    2168:	1a079863          	bnez	a5,2318 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    216c:	0075f793          	andi	a5,a1,7
    2170:	16078463          	beqz	a5,22d8 <stpncpy+0x176>
    2174:	ea01                	bnez	a2,2184 <stpncpy+0x22>
    2176:	a421                	j	237e <stpncpy+0x21c>
    2178:	167d                	addi	a2,a2,-1
    217a:	0505                	addi	a0,a0,1
    217c:	14070e63          	beqz	a4,22d8 <stpncpy+0x176>
    2180:	1a060863          	beqz	a2,2330 <stpncpy+0x1ce>
    2184:	0005c783          	lbu	a5,0(a1)
    2188:	0585                	addi	a1,a1,1
    218a:	0075f713          	andi	a4,a1,7
    218e:	00f50023          	sb	a5,0(a0)
    2192:	f3fd                	bnez	a5,2178 <stpncpy+0x16>
    2194:	4805                	li	a6,1
    2196:	1a061863          	bnez	a2,2346 <stpncpy+0x1e4>
    219a:	40a007b3          	neg	a5,a0
    219e:	8b9d                	andi	a5,a5,7
    21a0:	4681                	li	a3,0
    21a2:	18061a63          	bnez	a2,2336 <stpncpy+0x1d4>
    21a6:	00778713          	addi	a4,a5,7
    21aa:	45ad                	li	a1,11
    21ac:	18b76363          	bltu	a4,a1,2332 <stpncpy+0x1d0>
    21b0:	1ae6eb63          	bltu	a3,a4,2366 <stpncpy+0x204>
    21b4:	1a078363          	beqz	a5,235a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21b8:	00050023          	sb	zero,0(a0)
    21bc:	4685                	li	a3,1
    21be:	00150713          	addi	a4,a0,1
    21c2:	18d78f63          	beq	a5,a3,2360 <stpncpy+0x1fe>
    21c6:	000500a3          	sb	zero,1(a0)
    21ca:	4689                	li	a3,2
    21cc:	00250713          	addi	a4,a0,2
    21d0:	18d78e63          	beq	a5,a3,236c <stpncpy+0x20a>
    21d4:	00050123          	sb	zero,2(a0)
    21d8:	468d                	li	a3,3
    21da:	00350713          	addi	a4,a0,3
    21de:	16d78c63          	beq	a5,a3,2356 <stpncpy+0x1f4>
    21e2:	000501a3          	sb	zero,3(a0)
    21e6:	4691                	li	a3,4
    21e8:	00450713          	addi	a4,a0,4
    21ec:	18d78263          	beq	a5,a3,2370 <stpncpy+0x20e>
    21f0:	00050223          	sb	zero,4(a0)
    21f4:	4695                	li	a3,5
    21f6:	00550713          	addi	a4,a0,5
    21fa:	16d78d63          	beq	a5,a3,2374 <stpncpy+0x212>
    21fe:	000502a3          	sb	zero,5(a0)
    2202:	469d                	li	a3,7
    2204:	00650713          	addi	a4,a0,6
    2208:	16d79863          	bne	a5,a3,2378 <stpncpy+0x216>
    220c:	00750713          	addi	a4,a0,7
    2210:	00050323          	sb	zero,6(a0)
    2214:	40f80833          	sub	a6,a6,a5
    2218:	ff887593          	andi	a1,a6,-8
    221c:	97aa                	add	a5,a5,a0
    221e:	95be                	add	a1,a1,a5
    2220:	0007b023          	sd	zero,0(a5)
    2224:	07a1                	addi	a5,a5,8
    2226:	feb79de3          	bne	a5,a1,2220 <stpncpy+0xbe>
    222a:	ff887593          	andi	a1,a6,-8
    222e:	9ead                	addw	a3,a3,a1
    2230:	00b707b3          	add	a5,a4,a1
    2234:	12b80863          	beq	a6,a1,2364 <stpncpy+0x202>
    2238:	00078023          	sb	zero,0(a5)
    223c:	0016871b          	addiw	a4,a3,1
    2240:	0ec77863          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2244:	000780a3          	sb	zero,1(a5)
    2248:	0026871b          	addiw	a4,a3,2
    224c:	0ec77263          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2250:	00078123          	sb	zero,2(a5)
    2254:	0036871b          	addiw	a4,a3,3
    2258:	0cc77c63          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    225c:	000781a3          	sb	zero,3(a5)
    2260:	0046871b          	addiw	a4,a3,4
    2264:	0cc77663          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2268:	00078223          	sb	zero,4(a5)
    226c:	0056871b          	addiw	a4,a3,5
    2270:	0cc77063          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2274:	000782a3          	sb	zero,5(a5)
    2278:	0066871b          	addiw	a4,a3,6
    227c:	0ac77a63          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2280:	00078323          	sb	zero,6(a5)
    2284:	0076871b          	addiw	a4,a3,7
    2288:	0ac77463          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    228c:	000783a3          	sb	zero,7(a5)
    2290:	0086871b          	addiw	a4,a3,8
    2294:	08c77e63          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    2298:	00078423          	sb	zero,8(a5)
    229c:	0096871b          	addiw	a4,a3,9
    22a0:	08c77863          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    22a4:	000784a3          	sb	zero,9(a5)
    22a8:	00a6871b          	addiw	a4,a3,10
    22ac:	08c77263          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    22b0:	00078523          	sb	zero,10(a5)
    22b4:	00b6871b          	addiw	a4,a3,11
    22b8:	06c77c63          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    22bc:	000785a3          	sb	zero,11(a5)
    22c0:	00c6871b          	addiw	a4,a3,12
    22c4:	06c77663          	bgeu	a4,a2,2330 <stpncpy+0x1ce>
    22c8:	00078623          	sb	zero,12(a5)
    22cc:	26b5                	addiw	a3,a3,13
    22ce:	06c6f163          	bgeu	a3,a2,2330 <stpncpy+0x1ce>
    22d2:	000786a3          	sb	zero,13(a5)
    22d6:	8082                	ret
			;
		if (!n || !*s)
    22d8:	c645                	beqz	a2,2380 <stpncpy+0x21e>
    22da:	0005c783          	lbu	a5,0(a1)
    22de:	ea078be3          	beqz	a5,2194 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22e2:	479d                	li	a5,7
    22e4:	02c7ff63          	bgeu	a5,a2,2322 <stpncpy+0x1c0>
    22e8:	00000897          	auipc	a7,0x0
    22ec:	6b88b883          	ld	a7,1720(a7) # 29a0 <enable_deadlock_detect+0x226>
    22f0:	00000817          	auipc	a6,0x0
    22f4:	6b883803          	ld	a6,1720(a6) # 29a8 <enable_deadlock_detect+0x22e>
    22f8:	431d                	li	t1,7
    22fa:	6198                	ld	a4,0(a1)
    22fc:	011707b3          	add	a5,a4,a7
    2300:	fff74693          	not	a3,a4
    2304:	8ff5                	and	a5,a5,a3
    2306:	0107f7b3          	and	a5,a5,a6
    230a:	ef81                	bnez	a5,2322 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    230c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    230e:	1661                	addi	a2,a2,-8
    2310:	05a1                	addi	a1,a1,8
    2312:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2314:	fec363e3          	bltu	t1,a2,22fa <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2318:	e609                	bnez	a2,2322 <stpncpy+0x1c0>
    231a:	a08d                	j	237c <stpncpy+0x21a>
    231c:	167d                	addi	a2,a2,-1
    231e:	0505                	addi	a0,a0,1
    2320:	ca01                	beqz	a2,2330 <stpncpy+0x1ce>
    2322:	0005c783          	lbu	a5,0(a1)
    2326:	0585                	addi	a1,a1,1
    2328:	00f50023          	sb	a5,0(a0)
    232c:	fbe5                	bnez	a5,231c <stpncpy+0x1ba>
		;
tail:
    232e:	b59d                	j	2194 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2330:	8082                	ret
    2332:	472d                	li	a4,11
    2334:	bdb5                	j	21b0 <stpncpy+0x4e>
    2336:	00778713          	addi	a4,a5,7
    233a:	45ad                	li	a1,11
    233c:	fff60693          	addi	a3,a2,-1
    2340:	e6b778e3          	bgeu	a4,a1,21b0 <stpncpy+0x4e>
    2344:	b7fd                	j	2332 <stpncpy+0x1d0>
    2346:	40a007b3          	neg	a5,a0
    234a:	8832                	mv	a6,a2
    234c:	8b9d                	andi	a5,a5,7
    234e:	4681                	li	a3,0
    2350:	e4060be3          	beqz	a2,21a6 <stpncpy+0x44>
    2354:	b7cd                	j	2336 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2356:	468d                	li	a3,3
    2358:	bd75                	j	2214 <stpncpy+0xb2>
    235a:	872a                	mv	a4,a0
    235c:	4681                	li	a3,0
    235e:	bd5d                	j	2214 <stpncpy+0xb2>
    2360:	4685                	li	a3,1
    2362:	bd4d                	j	2214 <stpncpy+0xb2>
    2364:	8082                	ret
    2366:	87aa                	mv	a5,a0
    2368:	4681                	li	a3,0
    236a:	b5f9                	j	2238 <stpncpy+0xd6>
    236c:	4689                	li	a3,2
    236e:	b55d                	j	2214 <stpncpy+0xb2>
    2370:	4691                	li	a3,4
    2372:	b54d                	j	2214 <stpncpy+0xb2>
    2374:	4695                	li	a3,5
    2376:	bd79                	j	2214 <stpncpy+0xb2>
    2378:	4699                	li	a3,6
    237a:	bd69                	j	2214 <stpncpy+0xb2>
    237c:	8082                	ret
    237e:	8082                	ret
    2380:	8082                	ret

0000000000002382 <basename>:

char *basename(char *s)
{
    2382:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2384:	c54d                	beqz	a0,242e <basename+0xac>
    2386:	00054783          	lbu	a5,0(a0)
		return ".";
    238a:	00000517          	auipc	a0,0x0
    238e:	60e50513          	addi	a0,a0,1550 # 2998 <enable_deadlock_detect+0x21e>
	if (!s || !*s)
    2392:	e391                	bnez	a5,2396 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2394:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2396:	0076f713          	andi	a4,a3,7
    239a:	87b6                	mv	a5,a3
    239c:	cf51                	beqz	a4,2438 <basename+0xb6>
    239e:	0785                	addi	a5,a5,1
    23a0:	0077f713          	andi	a4,a5,7
    23a4:	c729                	beqz	a4,23ee <basename+0x6c>
		if (!*s)
    23a6:	0007c703          	lbu	a4,0(a5)
    23aa:	fb75                	bnez	a4,239e <basename+0x1c>
	return s - a;
    23ac:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23ae:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23b0:	cf8d                	beqz	a5,23ea <basename+0x68>
    23b2:	00f68733          	add	a4,a3,a5
    23b6:	02f00593          	li	a1,47
    23ba:	a031                	j	23c6 <basename+0x44>
		s[i] = 0;
    23bc:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23c0:	17fd                	addi	a5,a5,-1
    23c2:	177d                	addi	a4,a4,-1
    23c4:	c39d                	beqz	a5,23ea <basename+0x68>
    23c6:	00074603          	lbu	a2,0(a4)
    23ca:	feb609e3          	beq	a2,a1,23bc <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23ce:	02f00613          	li	a2,47
    23d2:	a011                	j	23d6 <basename+0x54>
    23d4:	cb99                	beqz	a5,23ea <basename+0x68>
    23d6:	853e                	mv	a0,a5
    23d8:	17fd                	addi	a5,a5,-1
    23da:	00f68733          	add	a4,a3,a5
    23de:	00074703          	lbu	a4,0(a4)
    23e2:	fec719e3          	bne	a4,a2,23d4 <basename+0x52>
	return s + i;
    23e6:	9536                	add	a0,a0,a3
    23e8:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23ea:	8536                	mv	a0,a3
    23ec:	8082                	ret
    23ee:	6390                	ld	a2,0(a5)
    23f0:	00000517          	auipc	a0,0x0
    23f4:	5b053503          	ld	a0,1456(a0) # 29a0 <enable_deadlock_detect+0x226>
    23f8:	00000597          	auipc	a1,0x0
    23fc:	5b05b583          	ld	a1,1456(a1) # 29a8 <enable_deadlock_detect+0x22e>
    2400:	fff64713          	not	a4,a2
    2404:	962a                	add	a2,a2,a0
    2406:	8f71                	and	a4,a4,a2
    2408:	8f6d                	and	a4,a4,a1
    240a:	eb11                	bnez	a4,241e <basename+0x9c>
    240c:	6790                	ld	a2,8(a5)
    240e:	07a1                	addi	a5,a5,8
    2410:	00a60733          	add	a4,a2,a0
    2414:	fff64613          	not	a2,a2
    2418:	8f71                	and	a4,a4,a2
    241a:	8f6d                	and	a4,a4,a1
    241c:	db65                	beqz	a4,240c <basename+0x8a>
	for (; *s; s++)
    241e:	0007c703          	lbu	a4,0(a5)
    2422:	d749                	beqz	a4,23ac <basename+0x2a>
    2424:	0017c703          	lbu	a4,1(a5)
    2428:	0785                	addi	a5,a5,1
    242a:	ff6d                	bnez	a4,2424 <basename+0xa2>
    242c:	b741                	j	23ac <basename+0x2a>
		return ".";
    242e:	00000517          	auipc	a0,0x0
    2432:	56a50513          	addi	a0,a0,1386 # 2998 <enable_deadlock_detect+0x21e>
    2436:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2438:	6290                	ld	a2,0(a3)
    243a:	00000517          	auipc	a0,0x0
    243e:	56653503          	ld	a0,1382(a0) # 29a0 <enable_deadlock_detect+0x226>
    2442:	00000597          	auipc	a1,0x0
    2446:	5665b583          	ld	a1,1382(a1) # 29a8 <enable_deadlock_detect+0x22e>
    244a:	fff64713          	not	a4,a2
    244e:	962a                	add	a2,a2,a0
    2450:	8f71                	and	a4,a4,a2
    2452:	8f6d                	and	a4,a4,a1
    2454:	df45                	beqz	a4,240c <basename+0x8a>
    2456:	b7f9                	j	2424 <basename+0xa2>

0000000000002458 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2458:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    245c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    245e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2462:	2501                	sext.w	a0,a0
    2464:	8082                	ret

0000000000002466 <close>:

int close(int fd)
{
	if (fd == 1) {
    2466:	4785                	li	a5,1
    2468:	00f50863          	beq	a0,a5,2478 <close+0x12>
	register long a7 __asm__("a7") = n;
    246c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2470:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2474:	2501                	sext.w	a0,a0
    2476:	8082                	ret
{
    2478:	1101                	addi	sp,sp,-32
    247a:	ec06                	sd	ra,24(sp)
    247c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    247e:	cdffe0ef          	jal	ra,115c <__write_buffer>
		__clear_buffer();
    2482:	d03fe0ef          	jal	ra,1184 <__clear_buffer>
    2486:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2488:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    248c:	00000073          	ecall
}
    2490:	60e2                	ld	ra,24(sp)
    2492:	2501                	sext.w	a0,a0
    2494:	6105                	addi	sp,sp,32
    2496:	8082                	ret

0000000000002498 <read>:
	register long a7 __asm__("a7") = n;
    2498:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    249c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24a0:	8082                	ret

00000000000024a2 <write>:
	register long a7 __asm__("a7") = n;
    24a2:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24a6:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    24aa:	8082                	ret

00000000000024ac <getpid>:
	register long a7 __asm__("a7") = n;
    24ac:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24b0:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24b4:	2501                	sext.w	a0,a0
    24b6:	8082                	ret

00000000000024b8 <getppid>:
	register long a7 __asm__("a7") = n;
    24b8:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24bc:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24c0:	2501                	sext.w	a0,a0
    24c2:	8082                	ret

00000000000024c4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24c4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24c8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24cc:	2501                	sext.w	a0,a0
    24ce:	8082                	ret

00000000000024d0 <fork>:
	register long a7 __asm__("a7") = n;
    24d0:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24d4:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24d8:	2501                	sext.w	a0,a0
    24da:	8082                	ret

00000000000024dc <exit>:

void exit(int code)
{
    24dc:	1141                	addi	sp,sp,-16
    24de:	e406                	sd	ra,8(sp)
    24e0:	e022                	sd	s0,0(sp)
    24e2:	842a                	mv	s0,a0
	__write_buffer();
    24e4:	c79fe0ef          	jal	ra,115c <__write_buffer>
	__clear_buffer();
    24e8:	c9dfe0ef          	jal	ra,1184 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24ec:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24f0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24f2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24f6:	60a2                	ld	ra,8(sp)
    24f8:	6402                	ld	s0,0(sp)
    24fa:	0141                	addi	sp,sp,16
    24fc:	8082                	ret

00000000000024fe <waitpid>:
	register long a7 __asm__("a7") = n;
    24fe:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2502:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2506:	2501                	sext.w	a0,a0
    2508:	8082                	ret

000000000000250a <exec>:
	register long a7 __asm__("a7") = n;
    250a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    250e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2512:	2501                	sext.w	a0,a0
    2514:	8082                	ret

0000000000002516 <get_mtime>:

int64 get_mtime()
{
    2516:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2518:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    251c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    251e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2520:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2524:	2501                	sext.w	a0,a0
    2526:	ed01                	bnez	a0,253e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2528:	6722                	ld	a4,8(sp)
    252a:	3e800793          	li	a5,1000
    252e:	6682                	ld	a3,0(sp)
    2530:	02f75733          	divu	a4,a4,a5
    2534:	02d78533          	mul	a0,a5,a3
    2538:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    253a:	0141                	addi	sp,sp,16
    253c:	8082                	ret
	return -1;
    253e:	557d                	li	a0,-1
    2540:	bfed                	j	253a <get_mtime+0x24>

0000000000002542 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2542:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2546:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    254a:	2501                	sext.w	a0,a0
    254c:	8082                	ret

000000000000254e <sleep>:

int sleep(unsigned long long time)
{
    254e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2550:	880a                	mv	a6,sp
{
    2552:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2554:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2558:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    255a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    255c:	00000073          	ecall
	if (err == 0) {
    2560:	2501                	sext.w	a0,a0
    2562:	ed31                	bnez	a0,25be <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2564:	6722                	ld	a4,8(sp)
    2566:	3e800793          	li	a5,1000
    256a:	6682                	ld	a3,0(sp)
    256c:	02f75733          	divu	a4,a4,a5
    2570:	02d787b3          	mul	a5,a5,a3
    2574:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2576:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    257a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    257c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    257e:	00000073          	ecall
	if (err == 0) {
    2582:	2501                	sext.w	a0,a0
    2584:	e915                	bnez	a0,25b8 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2586:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2588:	3e800693          	li	a3,1000
    258c:	a819                	j	25a2 <sleep+0x54>
	__asm_syscall("r"(a7))
    258e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2592:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2596:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2598:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259a:	00000073          	ecall
	if (err == 0) {
    259e:	2501                	sext.w	a0,a0
    25a0:	ed01                	bnez	a0,25b8 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25a2:	6722                	ld	a4,8(sp)
    25a4:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25a6:	07c00893          	li	a7,124
    25aa:	02d75733          	divu	a4,a4,a3
    25ae:	02f687b3          	mul	a5,a3,a5
    25b2:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25b4:	fcc7ede3          	bltu	a5,a2,258e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25b8:	4501                	li	a0,0
    25ba:	0141                	addi	sp,sp,16
    25bc:	8082                	ret
    25be:	57fd                	li	a5,-1
    25c0:	bf5d                	j	2576 <sleep+0x28>

00000000000025c2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25c2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25c6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25ca:	2501                	sext.w	a0,a0
    25cc:	8082                	ret

00000000000025ce <set_priority>:
	register long a7 __asm__("a7") = n;
    25ce:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25d2:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25d6:	2501                	sext.w	a0,a0
    25d8:	8082                	ret

00000000000025da <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25da:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25de:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    25e2:	2501                	sext.w	a0,a0
    25e4:	8082                	ret

00000000000025e6 <munmap>:
	register long a7 __asm__("a7") = n;
    25e6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ea:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    25ee:	2501                	sext.w	a0,a0
    25f0:	8082                	ret

00000000000025f2 <wait>:

int wait(int *code)
{
    25f2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25f4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25f8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fa:	00000073          	ecall
	return waitpid(-1, code);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <spawn>:
	register long a7 __asm__("a7") = n;
    2602:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2606:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret

000000000000260e <pipe>:
	register long a7 __asm__("a7") = n;
    260e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2612:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2616:	2501                	sext.w	a0,a0
    2618:	8082                	ret

000000000000261a <mailread>:
	register long a7 __asm__("a7") = n;
    261a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2622:	2501                	sext.w	a0,a0
    2624:	8082                	ret

0000000000002626 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2626:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    262a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    262e:	2501                	sext.w	a0,a0
    2630:	8082                	ret

0000000000002632 <fstat>:
	register long a7 __asm__("a7") = n;
    2632:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2636:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    263e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2640:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2644:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2646:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    264a:	2501                	sext.w	a0,a0
    264c:	8082                	ret

000000000000264e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    264e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2650:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2654:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2656:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    265a:	2501                	sext.w	a0,a0
    265c:	8082                	ret

000000000000265e <link>:

int link(char *old_path, char *new_path)
{
    265e:	87aa                	mv	a5,a0
    2660:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2662:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2666:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    266a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    266c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2670:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2672:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2676:	2501                	sext.w	a0,a0
    2678:	8082                	ret

000000000000267a <unlink>:

int unlink(char *path)
{
    267a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    267c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2680:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2684:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2686:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    268e:	00000797          	auipc	a5,0x0
    2692:	4627b783          	ld	a5,1122(a5) # 2af0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2696:	439c                	lw	a5,0(a5)
    2698:	c799                	beqz	a5,26a6 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    269a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    269e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret
{
    26a6:	1101                	addi	sp,sp,-32
    26a8:	ec06                	sd	ra,24(sp)
    26aa:	e42e                	sd	a1,8(sp)
    26ac:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26ae:	fe7fe0ef          	jal	ra,1694 <enable_thread_io_buffer>
    26b2:	65a2                	ld	a1,8(sp)
    26b4:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26b6:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26ba:	00000073          	ecall
}
    26be:	60e2                	ld	ra,24(sp)
    26c0:	2501                	sext.w	a0,a0
    26c2:	6105                	addi	sp,sp,32
    26c4:	8082                	ret

00000000000026c6 <gettid>:
	register long a7 __asm__("a7") = n;
    26c6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26ca:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26ce:	2501                	sext.w	a0,a0
    26d0:	8082                	ret

00000000000026d2 <waittid>:

int waittid(int tid)
{
    26d2:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26d4:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26d8:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26dc:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    26de:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26e0:	00e51e63          	bne	a0,a4,26fc <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    26e4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26e8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26ec:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26f0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26f2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26f6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26f8:	fee506e3          	beq	a0,a4,26e4 <waittid+0x12>
	}
	return ret;
}
    26fc:	8082                	ret

00000000000026fe <mutex_create>:
	register long a7 __asm__("a7") = n;
    26fe:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2702:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    270c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2710:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2712:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2716:	2501                	sext.w	a0,a0
    2718:	8082                	ret

000000000000271a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    271a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    271e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2722:	2501                	sext.w	a0,a0
    2724:	8082                	ret

0000000000002726 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2726:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    272a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    272e:	2501                	sext.w	a0,a0
    2730:	8082                	ret

0000000000002732 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2732:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2736:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    273a:	2501                	sext.w	a0,a0
    273c:	8082                	ret

000000000000273e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    273e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2742:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2746:	2501                	sext.w	a0,a0
    2748:	8082                	ret

000000000000274a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    274a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    274e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2752:	2501                	sext.w	a0,a0
    2754:	8082                	ret

0000000000002756 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2756:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    275a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    275e:	2501                	sext.w	a0,a0
    2760:	8082                	ret

0000000000002762 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2762:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2766:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    276a:	2501                	sext.w	a0,a0
    276c:	8082                	ret

000000000000276e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    276e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2772:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2776:	2501                	sext.w	a0,a0
    2778:	8082                	ret

000000000000277a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    277a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    277e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2782:	2501                	sext.w	a0,a0
    2784:	8082                	ret
