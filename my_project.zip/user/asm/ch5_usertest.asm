
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_usertest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a60d                	j	1322 <__start_main>

0000000000001002 <run_tests>:
#ifndef USER_TEST
#define USER_TEST

int run_tests(const char *tests[], int n)
{
    1002:	7175                	addi	sp,sp,-144
    1004:	e506                	sd	ra,136(sp)
    1006:	e122                	sd	s0,128(sp)
    1008:	fca6                	sd	s1,120(sp)
    100a:	f8ca                	sd	s2,112(sp)
    100c:	f4ce                	sd	s3,104(sp)
    100e:	f0d2                	sd	s4,96(sp)
    1010:	ecd6                	sd	s5,88(sp)
    1012:	e8da                	sd	s6,80(sp)
    1014:	e4de                	sd	s7,72(sp)
    1016:	e0e2                	sd	s8,64(sp)
    1018:	fc66                	sd	s9,56(sp)
    101a:	f86a                	sd	s10,48(sp)
    101c:	f46e                	sd	s11,40(sp)
	int success = 0;
	for (int i = 0; i < n; ++i) {
    101e:	0eb05c63          	blez	a1,1116 <run_tests+0x114>
    1022:	fff58a1b          	addiw	s4,a1,-1
    1026:	020a1793          	slli	a5,s4,0x20
    102a:	01d7da13          	srli	s4,a5,0x1d
    102e:	00850793          	addi	a5,a0,8
    1032:	84aa                	mv	s1,a0
    1034:	9a3e                	add	s4,s4,a5
	int success = 0;
    1036:	4981                	li	s3,0
    1038:	01c10b93          	addi	s7,sp,28
		const char *test = tests[i];
		printf("Usertests: Running %s\n", test);
    103c:	00002b17          	auipc	s6,0x2
    1040:	94cb0b13          	addi	s6,s6,-1716 # 2988 <enable_deadlock_detect+0xc>
		}
		int xstate = 0;
		int wait_pid = waitpid(pid, &xstate);
		assert_eq(pid, wait_pid);
		success += (xstate == 0);
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1044:	00002a97          	auipc	s5,0x2
    1048:	9e4a8a93          	addi	s5,s5,-1564 # 2a28 <enable_deadlock_detect+0xac>
		assert_eq(pid, wait_pid);
    104c:	00002d17          	auipc	s10,0x2
    1050:	954d0d13          	addi	s10,s10,-1708 # 29a0 <enable_deadlock_detect+0x24>
    1054:	00002c97          	auipc	s9,0x2
    1058:	994c8c93          	addi	s9,s9,-1644 # 29e8 <enable_deadlock_detect+0x6c>
    105c:	00002c17          	auipc	s8,0x2
    1060:	994c0c13          	addi	s8,s8,-1644 # 29f0 <enable_deadlock_detect+0x74>
		const char *test = tests[i];
    1064:	0004b903          	ld	s2,0(s1)
		printf("Usertests: Running %s\n", test);
    1068:	855a                	mv	a0,s6
    106a:	85ca                	mv	a1,s2
    106c:	410000ef          	jal	ra,147c <printf>
		int pid = fork();
    1070:	662010ef          	jal	ra,26d2 <fork>
    1074:	842a                	mv	s0,a0
		if (pid == 0) {
    1076:	c941                	beqz	a0,1106 <run_tests+0x104>
		int wait_pid = waitpid(pid, &xstate);
    1078:	85de                	mv	a1,s7
    107a:	8522                	mv	a0,s0
		int xstate = 0;
    107c:	ce02                	sw	zero,28(sp)
		int wait_pid = waitpid(pid, &xstate);
    107e:	682010ef          	jal	ra,2700 <waitpid>
    1082:	8daa                	mv	s11,a0
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1084:	8622                	mv	a2,s0
    1086:	85ca                	mv	a1,s2
    1088:	8556                	mv	a0,s5
		assert_eq(pid, wait_pid);
    108a:	07b40363          	beq	s0,s11,10f0 <run_tests+0xee>
    108e:	620010ef          	jal	ra,26ae <getpid>
    1092:	86aa                	mv	a3,a0
    1094:	856a                	mv	a0,s10
    1096:	e436                	sd	a3,8(sp)
    1098:	4ec010ef          	jal	ra,2584 <basename>
    109c:	66a2                	ld	a3,8(sp)
    109e:	872a                	mv	a4,a0
    10a0:	47c5                	li	a5,17
    10a2:	8666                	mv	a2,s9
    10a4:	45fd                	li	a1,31
    10a6:	88ee                	mv	a7,s11
    10a8:	8822                	mv	a6,s0
    10aa:	8562                	mv	a0,s8
    10ac:	3d0000ef          	jal	ra,147c <printf>
    10b0:	557d                	li	a0,-1
    10b2:	62c010ef          	jal	ra,26de <exit>
		success += (xstate == 0);
    10b6:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10b8:	04a1                	addi	s1,s1,8
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10ba:	8622                	mv	a2,s0
		success += (xstate == 0);
    10bc:	0016b793          	seqz	a5,a3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c0:	85ca                	mv	a1,s2
    10c2:	8556                	mv	a0,s5
		success += (xstate == 0);
    10c4:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c8:	3b4000ef          	jal	ra,147c <printf>
	for (int i = 0; i < n; ++i) {
    10cc:	f89a1ce3          	bne	s4,s1,1064 <run_tests+0x62>
		       test, pid, xstate);
	}
	return success;
}
    10d0:	60aa                	ld	ra,136(sp)
    10d2:	640a                	ld	s0,128(sp)
    10d4:	74e6                	ld	s1,120(sp)
    10d6:	7946                	ld	s2,112(sp)
    10d8:	7a06                	ld	s4,96(sp)
    10da:	6ae6                	ld	s5,88(sp)
    10dc:	6b46                	ld	s6,80(sp)
    10de:	6ba6                	ld	s7,72(sp)
    10e0:	6c06                	ld	s8,64(sp)
    10e2:	7ce2                	ld	s9,56(sp)
    10e4:	7d42                	ld	s10,48(sp)
    10e6:	7da2                	ld	s11,40(sp)
    10e8:	854e                	mv	a0,s3
    10ea:	79a6                	ld	s3,104(sp)
    10ec:	6149                	addi	sp,sp,144
    10ee:	8082                	ret
		success += (xstate == 0);
    10f0:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10f2:	04a1                	addi	s1,s1,8
		success += (xstate == 0);
    10f4:	0016b793          	seqz	a5,a3
    10f8:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10fc:	380000ef          	jal	ra,147c <printf>
	for (int i = 0; i < n; ++i) {
    1100:	f74492e3          	bne	s1,s4,1064 <run_tests+0x62>
    1104:	b7f1                	j	10d0 <run_tests+0xce>
			exec(test, NULL);
    1106:	4581                	li	a1,0
    1108:	854a                	mv	a0,s2
    110a:	602010ef          	jal	ra,270c <exec>
			exit(-1);
    110e:	557d                	li	a0,-1
    1110:	5ce010ef          	jal	ra,26de <exit>
    1114:	b795                	j	1078 <run_tests+0x76>
	int success = 0;
    1116:	4981                	li	s3,0
    1118:	bf65                	j	10d0 <run_tests+0xce>

000000000000111a <test>:

int test(const char *succs[], int nsucc, const char *fails[], int nfail,
	 const char *message)
{
    111a:	7139                	addi	sp,sp,-64
    111c:	f822                	sd	s0,48(sp)
    111e:	f426                	sd	s1,40(sp)
    1120:	ec4e                	sd	s3,24(sp)
    1122:	fc06                	sd	ra,56(sp)
    1124:	f04a                	sd	s2,32(sp)
    1126:	e852                	sd	s4,16(sp)
    1128:	e456                	sd	s5,8(sp)
    112a:	84b2                	mv	s1,a2
    112c:	89b6                	mv	s3,a3
    112e:	843a                	mv	s0,a4
	if (succs && nsucc > 0) {
    1130:	c501                	beqz	a0,1138 <test+0x1e>
    1132:	892e                	mv	s2,a1
    1134:	06b04763          	bgtz	a1,11a2 <test+0x88>
		int succ_count = run_tests(succs, nsucc);
		assert_eq(succ_count, nsucc);
	}
	if (fails && nfail > 0) {
    1138:	c099                	beqz	s1,113e <test+0x24>
    113a:	03304063          	bgtz	s3,115a <test+0x40>
		int fail_count = run_tests(fails, nfail);
		assert_eq(fail_count, 0);
	}
	if (message)
    113e:	c401                	beqz	s0,1146 <test+0x2c>
		puts(message);
    1140:	8522                	mv	a0,s0
    1142:	251000ef          	jal	ra,1b92 <puts>
	return 0;
}
    1146:	70e2                	ld	ra,56(sp)
    1148:	7442                	ld	s0,48(sp)
    114a:	74a2                	ld	s1,40(sp)
    114c:	7902                	ld	s2,32(sp)
    114e:	69e2                	ld	s3,24(sp)
    1150:	6a42                	ld	s4,16(sp)
    1152:	6aa2                	ld	s5,8(sp)
    1154:	4501                	li	a0,0
    1156:	6121                	addi	sp,sp,64
    1158:	8082                	ret
		int fail_count = run_tests(fails, nfail);
    115a:	8526                	mv	a0,s1
    115c:	85ce                	mv	a1,s3
    115e:	ea5ff0ef          	jal	ra,1002 <run_tests>
    1162:	84aa                	mv	s1,a0
		assert_eq(fail_count, 0);
    1164:	dd69                	beqz	a0,113e <test+0x24>
    1166:	548010ef          	jal	ra,26ae <getpid>
    116a:	892a                	mv	s2,a0
    116c:	00002517          	auipc	a0,0x2
    1170:	83450513          	addi	a0,a0,-1996 # 29a0 <enable_deadlock_detect+0x24>
    1174:	410010ef          	jal	ra,2584 <basename>
    1178:	872a                	mv	a4,a0
    117a:	4881                	li	a7,0
    117c:	00002517          	auipc	a0,0x2
    1180:	87450513          	addi	a0,a0,-1932 # 29f0 <enable_deadlock_detect+0x74>
    1184:	8826                	mv	a6,s1
    1186:	02200793          	li	a5,34
    118a:	86ca                	mv	a3,s2
    118c:	00002617          	auipc	a2,0x2
    1190:	85c60613          	addi	a2,a2,-1956 # 29e8 <enable_deadlock_detect+0x6c>
    1194:	45fd                	li	a1,31
    1196:	2e6000ef          	jal	ra,147c <printf>
    119a:	557d                	li	a0,-1
    119c:	542010ef          	jal	ra,26de <exit>
    11a0:	bf79                	j	113e <test+0x24>
		int succ_count = run_tests(succs, nsucc);
    11a2:	e61ff0ef          	jal	ra,1002 <run_tests>
    11a6:	8a2a                	mv	s4,a0
		assert_eq(succ_count, nsucc);
    11a8:	f8a908e3          	beq	s2,a0,1138 <test+0x1e>
    11ac:	502010ef          	jal	ra,26ae <getpid>
    11b0:	8aaa                	mv	s5,a0
    11b2:	00001517          	auipc	a0,0x1
    11b6:	7ee50513          	addi	a0,a0,2030 # 29a0 <enable_deadlock_detect+0x24>
    11ba:	3ca010ef          	jal	ra,2584 <basename>
    11be:	872a                	mv	a4,a0
    11c0:	88ca                	mv	a7,s2
    11c2:	8852                	mv	a6,s4
    11c4:	00002517          	auipc	a0,0x2
    11c8:	82c50513          	addi	a0,a0,-2004 # 29f0 <enable_deadlock_detect+0x74>
    11cc:	47f9                	li	a5,30
    11ce:	86d6                	mv	a3,s5
    11d0:	00002617          	auipc	a2,0x2
    11d4:	81860613          	addi	a2,a2,-2024 # 29e8 <enable_deadlock_detect+0x6c>
    11d8:	45fd                	li	a1,31
    11da:	2a2000ef          	jal	ra,147c <printf>
    11de:	557d                	li	a0,-1
    11e0:	4fe010ef          	jal	ra,26de <exit>
    11e4:	bf91                	j	1138 <test+0x1e>

00000000000011e6 <main>:
	"ch4_unmap1\0",	      "ch5_spawn0\0",	  "ch5_spawn1\0",
	"ch5_setprio\0",
};

int main()
{
    11e6:	7171                	addi	sp,sp,-176
    11e8:	ed26                	sd	s1,152(sp)
    11ea:	0804                	addi	s1,sp,16
    11ec:	f122                	sd	s0,160(sp)
    11ee:	e94a                	sd	s2,144(sp)
    11f0:	e54e                	sd	s3,136(sp)
    11f2:	e152                	sd	s4,128(sp)
    11f4:	f506                	sd	ra,168(sp)
    11f6:	fcd6                	sd	s5,120(sp)
    11f8:	f8da                	sd	s6,112(sp)
    11fa:	f4de                	sd	s7,104(sp)
    11fc:	f0e2                	sd	s8,96(sp)
	int pid[20] = {0};
    11fe:	e802                	sd	zero,16(sp)
    1200:	ec02                	sd	zero,24(sp)
    1202:	f002                	sd	zero,32(sp)
    1204:	f402                	sd	zero,40(sp)
    1206:	f802                	sd	zero,48(sp)
    1208:	fc02                	sd	zero,56(sp)
    120a:	e082                	sd	zero,64(sp)
    120c:	e482                	sd	zero,72(sp)
    120e:	e882                	sd	zero,80(sp)
    1210:	ec82                	sd	zero,88(sp)
	for (int i = 0; i < 20; i++) {
    1212:	00002417          	auipc	s0,0x2
    1216:	c2640413          	addi	s0,s0,-986 # 2e38 <TESTS>
    121a:	00002a17          	auipc	s4,0x2
    121e:	cbea0a13          	addi	s4,s4,-834 # 2ed8 <_GLOBAL_OFFSET_TABLE_>
	int pid[20] = {0};
    1222:	8926                	mv	s2,s1
		printf("Usertests: Running %s\n", TESTS[i]);
    1224:	00001997          	auipc	s3,0x1
    1228:	76498993          	addi	s3,s3,1892 # 2988 <enable_deadlock_detect+0xc>
    122c:	600c                	ld	a1,0(s0)
    122e:	854e                	mv	a0,s3
	for (int i = 0; i < 20; i++) {
    1230:	0421                	addi	s0,s0,8
		printf("Usertests: Running %s\n", TESTS[i]);
    1232:	24a000ef          	jal	ra,147c <printf>
		pid[i] = spawn(TESTS[i]);
    1236:	ff843503          	ld	a0,-8(s0)
	for (int i = 0; i < 20; i++) {
    123a:	0911                	addi	s2,s2,4
		pid[i] = spawn(TESTS[i]);
    123c:	5c8010ef          	jal	ra,2804 <spawn>
    1240:	fea92e23          	sw	a0,-4(s2)
	for (int i = 0; i < 20; i++) {
    1244:	ff4414e3          	bne	s0,s4,122c <main+0x46>

	}
	int exit_pid = 0;
    1248:	c602                	sw	zero,12(sp)
	for(int i = 0; i < 20; i++) {
    124a:	05048a93          	addi	s5,s1,80
    124e:	00c10a13          	addi	s4,sp,12
        int wait_pid = waitpid(pid[i], &exit_pid);
        assert_eq(wait_pid, pid[i]);
    1252:	00002c17          	auipc	s8,0x2
    1256:	80ec0c13          	addi	s8,s8,-2034 # 2a60 <enable_deadlock_detect+0xe4>
    125a:	00001b97          	auipc	s7,0x1
    125e:	78eb8b93          	addi	s7,s7,1934 # 29e8 <enable_deadlock_detect+0x6c>
    1262:	00001b17          	auipc	s6,0x1
    1266:	78eb0b13          	addi	s6,s6,1934 # 29f0 <enable_deadlock_detect+0x74>
        int wait_pid = waitpid(pid[i], &exit_pid);
    126a:	0004a903          	lw	s2,0(s1)
    126e:	85d2                	mv	a1,s4
	for(int i = 0; i < 20; i++) {
    1270:	0491                	addi	s1,s1,4
        int wait_pid = waitpid(pid[i], &exit_pid);
    1272:	854a                	mv	a0,s2
    1274:	48c010ef          	jal	ra,2700 <waitpid>
    1278:	842a                	mv	s0,a0
        assert_eq(wait_pid, pid[i]);
    127a:	02a90563          	beq	s2,a0,12a4 <main+0xbe>
    127e:	430010ef          	jal	ra,26ae <getpid>
    1282:	89aa                	mv	s3,a0
    1284:	8562                	mv	a0,s8
    1286:	2fe010ef          	jal	ra,2584 <basename>
    128a:	872a                	mv	a4,a0
    128c:	88ca                	mv	a7,s2
    128e:	855a                	mv	a0,s6
    1290:	8822                	mv	a6,s0
    1292:	47f5                	li	a5,29
    1294:	86ce                	mv	a3,s3
    1296:	865e                	mv	a2,s7
    1298:	45fd                	li	a1,31
    129a:	1e2000ef          	jal	ra,147c <printf>
    129e:	557d                	li	a0,-1
    12a0:	43e010ef          	jal	ra,26de <exit>
	for(int i = 0; i < 20; i++) {
    12a4:	fc9a93e3          	bne	s5,s1,126a <main+0x84>
    }
	int stride_pid = spawn("ch5t_usertest\0");
    12a8:	00002517          	auipc	a0,0x2
    12ac:	a2050513          	addi	a0,a0,-1504 # 2cc8 <buffer_lock+0x4>
    12b0:	554010ef          	jal	ra,2804 <spawn>
	int wait_pid = waitpid(stride_pid, &exit_pid);
    12b4:	85d2                	mv	a1,s4
	int stride_pid = spawn("ch5t_usertest\0");
    12b6:	84aa                	mv	s1,a0
	int wait_pid = waitpid(stride_pid, &exit_pid);
    12b8:	448010ef          	jal	ra,2700 <waitpid>
    12bc:	842a                	mv	s0,a0
	assert_eq(wait_pid, stride_pid);
    12be:	02a48f63          	beq	s1,a0,12fc <main+0x116>
    12c2:	3ec010ef          	jal	ra,26ae <getpid>
    12c6:	892a                	mv	s2,a0
    12c8:	00001517          	auipc	a0,0x1
    12cc:	79850513          	addi	a0,a0,1944 # 2a60 <enable_deadlock_detect+0xe4>
    12d0:	2b4010ef          	jal	ra,2584 <basename>
    12d4:	872a                	mv	a4,a0
    12d6:	88a6                	mv	a7,s1
    12d8:	00001517          	auipc	a0,0x1
    12dc:	71850513          	addi	a0,a0,1816 # 29f0 <enable_deadlock_detect+0x74>
    12e0:	8822                	mv	a6,s0
    12e2:	02100793          	li	a5,33
    12e6:	86ca                	mv	a3,s2
    12e8:	00001617          	auipc	a2,0x1
    12ec:	70060613          	addi	a2,a2,1792 # 29e8 <enable_deadlock_detect+0x6c>
    12f0:	45fd                	li	a1,31
    12f2:	18a000ef          	jal	ra,147c <printf>
    12f6:	557d                	li	a0,-1
    12f8:	3e6010ef          	jal	ra,26de <exit>
    puts("ch5 Usertests passed!");
    12fc:	00001517          	auipc	a0,0x1
    1300:	7ac50513          	addi	a0,a0,1964 # 2aa8 <enable_deadlock_detect+0x12c>
    1304:	08f000ef          	jal	ra,1b92 <puts>
	return 0;
}
    1308:	70aa                	ld	ra,168(sp)
    130a:	740a                	ld	s0,160(sp)
    130c:	64ea                	ld	s1,152(sp)
    130e:	694a                	ld	s2,144(sp)
    1310:	69aa                	ld	s3,136(sp)
    1312:	6a0a                	ld	s4,128(sp)
    1314:	7ae6                	ld	s5,120(sp)
    1316:	7b46                	ld	s6,112(sp)
    1318:	7ba6                	ld	s7,104(sp)
    131a:	7c06                	ld	s8,96(sp)
    131c:	4501                	li	a0,0
    131e:	614d                	addi	sp,sp,176
    1320:	8082                	ret

0000000000001322 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1322:	1141                	addi	sp,sp,-16
    1324:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1326:	ec1ff0ef          	jal	ra,11e6 <main>
    132a:	3b4010ef          	jal	ra,26de <exit>
	return 0;
    132e:	60a2                	ld	ra,8(sp)
    1330:	4501                	li	a0,0
    1332:	0141                	addi	sp,sp,16
    1334:	8082                	ret

0000000000001336 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1336:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1338:	4605                	li	a2,1
    133a:	00f10593          	addi	a1,sp,15
    133e:	4501                	li	a0,0
{
    1340:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1342:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1346:	354010ef          	jal	ra,269a <read>
    134a:	4785                	li	a5,1
    134c:	00f51763          	bne	a0,a5,135a <getchar+0x24>
		return byte;
    1350:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1354:	60e2                	ld	ra,24(sp)
    1356:	6105                	addi	sp,sp,32
    1358:	8082                	ret
		return EOF;
    135a:	557d                	li	a0,-1
    135c:	bfe5                	j	1354 <getchar+0x1e>

000000000000135e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    135e:	00002517          	auipc	a0,0x2
    1362:	85a52503          	lw	a0,-1958(a0) # 2bb8 <buffer_len>
    1366:	e111                	bnez	a0,136a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1368:	8082                	ret
{
    136a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    136c:	862a                	mv	a2,a0
    136e:	00002597          	auipc	a1,0x2
    1372:	85258593          	addi	a1,a1,-1966 # 2bc0 <buffer>
    1376:	4505                	li	a0,1
{
    1378:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    137a:	32a010ef          	jal	ra,26a4 <write>
}
    137e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1380:	2501                	sext.w	a0,a0
}
    1382:	0141                	addi	sp,sp,16
    1384:	8082                	ret

0000000000001386 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1386:	00002797          	auipc	a5,0x2
    138a:	8207a923          	sw	zero,-1998(a5) # 2bb8 <buffer_len>
}
    138e:	8082                	ret

0000000000001390 <__fflush>:
	if (buffer_len == 0)
    1390:	00002517          	auipc	a0,0x2
    1394:	82852503          	lw	a0,-2008(a0) # 2bb8 <buffer_len>
    1398:	e511                	bnez	a0,13a4 <__fflush+0x14>
	buffer_len = 0;
    139a:	00002797          	auipc	a5,0x2
    139e:	8007af23          	sw	zero,-2018(a5) # 2bb8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13a2:	8082                	ret
{
    13a4:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13a6:	862a                	mv	a2,a0
    13a8:	00002597          	auipc	a1,0x2
    13ac:	81858593          	addi	a1,a1,-2024 # 2bc0 <buffer>
    13b0:	4505                	li	a0,1
{
    13b2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13b4:	2f0010ef          	jal	ra,26a4 <write>
	return r >= 0 ? 0 : r;
    13b8:	0005079b          	sext.w	a5,a0
}
    13bc:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13be:	0017a793          	slti	a5,a5,1
    13c2:	40f007bb          	negw	a5,a5
    13c6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13c8:	00001797          	auipc	a5,0x1
    13cc:	7e07a823          	sw	zero,2032(a5) # 2bb8 <buffer_len>
	return r >= 0 ? 0 : r;
    13d0:	2501                	sext.w	a0,a0
}
    13d2:	0141                	addi	sp,sp,16
    13d4:	8082                	ret

00000000000013d6 <fflush>:

int fflush(int fd)
{
    13d6:	1101                	addi	sp,sp,-32
    13d8:	e822                	sd	s0,16(sp)
    13da:	ec06                	sd	ra,24(sp)
    13dc:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13de:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13e0:	4401                	li	s0,0
	if (fd == 1) {
    13e2:	00e50863          	beq	a0,a4,13f2 <fflush+0x1c>
}
    13e6:	60e2                	ld	ra,24(sp)
    13e8:	8522                	mv	a0,s0
    13ea:	6442                	ld	s0,16(sp)
    13ec:	64a2                	ld	s1,8(sp)
    13ee:	6105                	addi	sp,sp,32
    13f0:	8082                	ret
		if (buffer_lock_enabled == 1) {
    13f2:	00001497          	auipc	s1,0x1
    13f6:	7c648493          	addi	s1,s1,1990 # 2bb8 <buffer_len>
    13fa:	1084a703          	lw	a4,264(s1)
    13fe:	02a70e63          	beq	a4,a0,143a <fflush+0x64>
	if (buffer_len == 0)
    1402:	4080                	lw	s0,0(s1)
    1404:	c00d                	beqz	s0,1426 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1406:	8622                	mv	a2,s0
    1408:	00001597          	auipc	a1,0x1
    140c:	7b858593          	addi	a1,a1,1976 # 2bc0 <buffer>
    1410:	294010ef          	jal	ra,26a4 <write>
	return r >= 0 ? 0 : r;
    1414:	0005079b          	sext.w	a5,a0
    1418:	0017a793          	slti	a5,a5,1
    141c:	40f007bb          	negw	a5,a5
    1420:	8d7d                	and	a0,a0,a5
    1422:	0005041b          	sext.w	s0,a0
}
    1426:	60e2                	ld	ra,24(sp)
    1428:	8522                	mv	a0,s0
    142a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    142c:	00001797          	auipc	a5,0x1
    1430:	7807a623          	sw	zero,1932(a5) # 2bb8 <buffer_len>
}
    1434:	64a2                	ld	s1,8(sp)
    1436:	6105                	addi	sp,sp,32
    1438:	8082                	ret
			mutex_lock(buffer_lock);
    143a:	10c4a503          	lw	a0,268(s1)
    143e:	4de010ef          	jal	ra,291c <mutex_lock>
	if (buffer_len == 0)
    1442:	4080                	lw	s0,0(s1)
    1444:	e811                	bnez	s0,1458 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1446:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    144a:	00001797          	auipc	a5,0x1
    144e:	7607a723          	sw	zero,1902(a5) # 2bb8 <buffer_len>
			mutex_unlock(buffer_lock);
    1452:	4d6010ef          	jal	ra,2928 <mutex_unlock>
    1456:	bf41                	j	13e6 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1458:	8622                	mv	a2,s0
    145a:	00001597          	auipc	a1,0x1
    145e:	76658593          	addi	a1,a1,1894 # 2bc0 <buffer>
    1462:	4505                	li	a0,1
    1464:	240010ef          	jal	ra,26a4 <write>
	return r >= 0 ? 0 : r;
    1468:	0005079b          	sext.w	a5,a0
    146c:	0017a793          	slti	a5,a5,1
    1470:	40f007bb          	negw	a5,a5
    1474:	8d7d                	and	a0,a0,a5
    1476:	0005041b          	sext.w	s0,a0
	return r;
    147a:	b7f1                	j	1446 <fflush+0x70>

000000000000147c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    147c:	7131                	addi	sp,sp,-192
    147e:	e0da                	sd	s6,64(sp)
    1480:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1482:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1484:	013c                	addi	a5,sp,136
{
    1486:	f0ca                	sd	s2,96(sp)
    1488:	ecce                	sd	s3,88(sp)
    148a:	e8d2                	sd	s4,80(sp)
    148c:	e4d6                	sd	s5,72(sp)
    148e:	fc86                	sd	ra,120(sp)
    1490:	f8a2                	sd	s0,112(sp)
    1492:	f4a6                	sd	s1,104(sp)
    1494:	89aa                	mv	s3,a0
    1496:	e52e                	sd	a1,136(sp)
    1498:	e932                	sd	a2,144(sp)
    149a:	ed36                	sd	a3,152(sp)
    149c:	f13a                	sd	a4,160(sp)
    149e:	f942                	sd	a6,176(sp)
    14a0:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14a2:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14a4:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14a8:	00001a17          	auipc	s4,0x1
    14ac:	710a0a13          	addi	s4,s4,1808 # 2bb8 <buffer_len>
    14b0:	4a85                	li	s5,1
	buf[i++] = '0';
    14b2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14b6:	0009c783          	lbu	a5,0(s3)
    14ba:	18078663          	beqz	a5,1646 <printf+0x1ca>
    14be:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14c0:	19278d63          	beq	a5,s2,165a <printf+0x1de>
    14c4:	0015c783          	lbu	a5,1(a1)
    14c8:	0585                	addi	a1,a1,1
    14ca:	fbfd                	bnez	a5,14c0 <printf+0x44>
    14cc:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14ce:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14d2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14d6:	1b578863          	beq	a5,s5,1686 <printf+0x20a>
		len = out_unlocked(s, l);
    14da:	85a2                	mv	a1,s0
    14dc:	854e                	mv	a0,s3
    14de:	42a000ef          	jal	ra,1908 <out_unlocked>
		out(f, a, l);
		if (l)
    14e2:	1c041063          	bnez	s0,16a2 <printf+0x226>
			continue;
		if (s[1] == 0)
    14e6:	0014c783          	lbu	a5,1(s1)
    14ea:	14078e63          	beqz	a5,1646 <printf+0x1ca>
			break;
		switch (s[1]) {
    14ee:	07300713          	li	a4,115
    14f2:	1ce78863          	beq	a5,a4,16c2 <printf+0x246>
    14f6:	1af76863          	bltu	a4,a5,16a6 <printf+0x22a>
    14fa:	06400713          	li	a4,100
    14fe:	22e78063          	beq	a5,a4,171e <printf+0x2a2>
    1502:	07000713          	li	a4,112
    1506:	1ee79563          	bne	a5,a4,16f0 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    150a:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    150c:	00002797          	auipc	a5,0x2
    1510:	91478793          	addi	a5,a5,-1772 # 2e20 <digits>
	buf[i++] = '0';
    1514:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1518:	6298                	ld	a4,0(a3)
    151a:	06a1                	addi	a3,a3,8
    151c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    151e:	00471393          	slli	t2,a4,0x4
    1522:	00871293          	slli	t0,a4,0x8
    1526:	00c71f93          	slli	t6,a4,0xc
    152a:	01071f13          	slli	t5,a4,0x10
    152e:	01471e93          	slli	t4,a4,0x14
    1532:	01871e13          	slli	t3,a4,0x18
    1536:	01c71893          	slli	a7,a4,0x1c
    153a:	02471813          	slli	a6,a4,0x24
    153e:	02871513          	slli	a0,a4,0x28
    1542:	02c71593          	slli	a1,a4,0x2c
    1546:	03071613          	slli	a2,a4,0x30
    154a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    154e:	03c75413          	srli	s0,a4,0x3c
    1552:	01c7531b          	srliw	t1,a4,0x1c
    1556:	03c3d393          	srli	t2,t2,0x3c
    155a:	03c2d293          	srli	t0,t0,0x3c
    155e:	03cfdf93          	srli	t6,t6,0x3c
    1562:	03cf5f13          	srli	t5,t5,0x3c
    1566:	03cede93          	srli	t4,t4,0x3c
    156a:	03ce5e13          	srli	t3,t3,0x3c
    156e:	03c8d893          	srli	a7,a7,0x3c
    1572:	03c85813          	srli	a6,a6,0x3c
    1576:	9171                	srli	a0,a0,0x3c
    1578:	91f1                	srli	a1,a1,0x3c
    157a:	9271                	srli	a2,a2,0x3c
    157c:	92f1                	srli	a3,a3,0x3c
    157e:	95be                	add	a1,a1,a5
    1580:	963e                	add	a2,a2,a5
    1582:	96be                	add	a3,a3,a5
    1584:	943e                	add	s0,s0,a5
    1586:	93be                	add	t2,t2,a5
    1588:	92be                	add	t0,t0,a5
    158a:	9fbe                	add	t6,t6,a5
    158c:	9f3e                	add	t5,t5,a5
    158e:	9ebe                	add	t4,t4,a5
    1590:	9e3e                	add	t3,t3,a5
    1592:	98be                	add	a7,a7,a5
    1594:	933e                	add	t1,t1,a5
    1596:	983e                	add	a6,a6,a5
    1598:	953e                	add	a0,a0,a5
    159a:	0005c983          	lbu	s3,0(a1)
    159e:	00044403          	lbu	s0,0(s0)
    15a2:	00064583          	lbu	a1,0(a2)
    15a6:	0003c383          	lbu	t2,0(t2)
    15aa:	0006c603          	lbu	a2,0(a3)
    15ae:	0002c283          	lbu	t0,0(t0)
    15b2:	000fcf83          	lbu	t6,0(t6)
    15b6:	000f4f03          	lbu	t5,0(t5)
    15ba:	000ece83          	lbu	t4,0(t4)
    15be:	000e4e03          	lbu	t3,0(t3)
    15c2:	0008c883          	lbu	a7,0(a7)
    15c6:	00034303          	lbu	t1,0(t1)
    15ca:	00084803          	lbu	a6,0(a6)
    15ce:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15d2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15d6:	92f1                	srli	a3,a3,0x3c
    15d8:	8b3d                	andi	a4,a4,15
    15da:	96be                	add	a3,a3,a5
    15dc:	97ba                	add	a5,a5,a4
    15de:	00810d23          	sb	s0,26(sp)
    15e2:	00710da3          	sb	t2,27(sp)
    15e6:	00510e23          	sb	t0,28(sp)
    15ea:	01f10ea3          	sb	t6,29(sp)
    15ee:	01e10f23          	sb	t5,30(sp)
    15f2:	01d10fa3          	sb	t4,31(sp)
    15f6:	03c10023          	sb	t3,32(sp)
    15fa:	031100a3          	sb	a7,33(sp)
    15fe:	02610123          	sb	t1,34(sp)
    1602:	030101a3          	sb	a6,35(sp)
    1606:	02a10223          	sb	a0,36(sp)
    160a:	033102a3          	sb	s3,37(sp)
    160e:	02b10323          	sb	a1,38(sp)
    1612:	02c103a3          	sb	a2,39(sp)
    1616:	0006c683          	lbu	a3,0(a3)
    161a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    161e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1622:	02d10423          	sb	a3,40(sp)
    1626:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    162a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    162e:	11578263          	beq	a5,s5,1732 <printf+0x2b6>
		len = out_unlocked(s, l);
    1632:	45c9                	li	a1,18
    1634:	0828                	addi	a0,sp,24
    1636:	2d2000ef          	jal	ra,1908 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    163a:	00248993          	addi	s3,s1,2
		if (!*s)
    163e:	0009c783          	lbu	a5,0(s3)
    1642:	e6079ee3          	bnez	a5,14be <printf+0x42>
	}
	va_end(ap);
    1646:	70e6                	ld	ra,120(sp)
    1648:	7446                	ld	s0,112(sp)
    164a:	74a6                	ld	s1,104(sp)
    164c:	7906                	ld	s2,96(sp)
    164e:	69e6                	ld	s3,88(sp)
    1650:	6a46                	ld	s4,80(sp)
    1652:	6aa6                	ld	s5,72(sp)
    1654:	6b06                	ld	s6,64(sp)
    1656:	6129                	addi	sp,sp,192
    1658:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    165a:	0005c783          	lbu	a5,0(a1)
    165e:	84ae                	mv	s1,a1
    1660:	01278963          	beq	a5,s2,1672 <printf+0x1f6>
    1664:	b5ad                	j	14ce <printf+0x52>
    1666:	0024c783          	lbu	a5,2(s1)
    166a:	0585                	addi	a1,a1,1
    166c:	0489                	addi	s1,s1,2
    166e:	e72790e3          	bne	a5,s2,14ce <printf+0x52>
    1672:	0014c783          	lbu	a5,1(s1)
    1676:	ff2788e3          	beq	a5,s2,1666 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    167a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    167e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1682:	e5579ce3          	bne	a5,s5,14da <printf+0x5e>
		mutex_lock(buffer_lock);
    1686:	10ca2503          	lw	a0,268(s4)
    168a:	292010ef          	jal	ra,291c <mutex_lock>
		len = out_unlocked(s, l);
    168e:	85a2                	mv	a1,s0
    1690:	854e                	mv	a0,s3
    1692:	276000ef          	jal	ra,1908 <out_unlocked>
		mutex_unlock(buffer_lock);
    1696:	10ca2503          	lw	a0,268(s4)
    169a:	28e010ef          	jal	ra,2928 <mutex_unlock>
		if (l)
    169e:	e40404e3          	beqz	s0,14e6 <printf+0x6a>
    16a2:	89a6                	mv	s3,s1
    16a4:	bd09                	j	14b6 <printf+0x3a>
		switch (s[1]) {
    16a6:	07800713          	li	a4,120
    16aa:	04e79363          	bne	a5,a4,16f0 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16ae:	67c2                	ld	a5,16(sp)
    16b0:	45c1                	li	a1,16
		s += 2;
    16b2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16b6:	4388                	lw	a0,0(a5)
    16b8:	07a1                	addi	a5,a5,8
    16ba:	e83e                	sd	a5,16(sp)
    16bc:	5f8000ef          	jal	ra,1cb4 <printint.constprop.0>
		s += 2;
    16c0:	bfbd                	j	163e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16c2:	67c2                	ld	a5,16(sp)
    16c4:	6380                	ld	s0,0(a5)
    16c6:	07a1                	addi	a5,a5,8
    16c8:	e83e                	sd	a5,16(sp)
    16ca:	1c040163          	beqz	s0,188c <printf+0x410>
			l = strnlen(a, 200);
    16ce:	0c800593          	li	a1,200
    16d2:	8522                	mv	a0,s0
    16d4:	3f7000ef          	jal	ra,22ca <strnlen>
	if (buffer_lock_enabled == 1) {
    16d8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16dc:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16e0:	19578663          	beq	a5,s5,186c <printf+0x3f0>
		len = out_unlocked(s, l);
    16e4:	8522                	mv	a0,s0
    16e6:	222000ef          	jal	ra,1908 <out_unlocked>
		s += 2;
    16ea:	00248993          	addi	s3,s1,2
    16ee:	bf81                	j	163e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    16f0:	108a2783          	lw	a5,264(s4)
	char byte = c;
    16f4:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    16f8:	0f578663          	beq	a5,s5,17e4 <printf+0x368>
		len = out_unlocked(s, l);
    16fc:	0828                	addi	a0,sp,24
    16fe:	316000ef          	jal	ra,1a14 <out_unlocked.constprop.0>
			putchar(s[1]);
    1702:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1706:	108a2783          	lw	a5,264(s4)
	char byte = c;
    170a:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    170e:	05578163          	beq	a5,s5,1750 <printf+0x2d4>
		len = out_unlocked(s, l);
    1712:	0828                	addi	a0,sp,24
    1714:	300000ef          	jal	ra,1a14 <out_unlocked.constprop.0>
		s += 2;
    1718:	00248993          	addi	s3,s1,2
    171c:	b70d                	j	163e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    171e:	67c2                	ld	a5,16(sp)
    1720:	45a9                	li	a1,10
		s += 2;
    1722:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1726:	4388                	lw	a0,0(a5)
    1728:	07a1                	addi	a5,a5,8
    172a:	e83e                	sd	a5,16(sp)
    172c:	588000ef          	jal	ra,1cb4 <printint.constprop.0>
		s += 2;
    1730:	b739                	j	163e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1732:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1736:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    173a:	1e2010ef          	jal	ra,291c <mutex_lock>
		len = out_unlocked(s, l);
    173e:	45c9                	li	a1,18
    1740:	0828                	addi	a0,sp,24
    1742:	1c6000ef          	jal	ra,1908 <out_unlocked>
		mutex_unlock(buffer_lock);
    1746:	10ca2503          	lw	a0,268(s4)
    174a:	1de010ef          	jal	ra,2928 <mutex_unlock>
		s += 2;
    174e:	bdc5                	j	163e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1750:	10ca2503          	lw	a0,268(s4)
    1754:	1c8010ef          	jal	ra,291c <mutex_lock>
		buffer[buffer_len++] = c;
    1758:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    175c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1760:	0017861b          	addiw	a2,a5,1
    1764:	97d2                	add	a5,a5,s4
    1766:	00ca2023          	sw	a2,0(s4)
    176a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    176e:	00c6cc63          	blt	a3,a2,1786 <printf+0x30a>
    1772:	47a9                	li	a5,10
    1774:	06f40663          	beq	s0,a5,17e0 <printf+0x364>
		mutex_unlock(buffer_lock);
    1778:	10ca2503          	lw	a0,268(s4)
		s += 2;
    177c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1780:	1a8010ef          	jal	ra,2928 <mutex_unlock>
		s += 2;
    1784:	bd6d                	j	163e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1786:	10000793          	li	a5,256
    178a:	00f61e63          	bne	a2,a5,17a6 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    178e:	00001597          	auipc	a1,0x1
    1792:	43258593          	addi	a1,a1,1074 # 2bc0 <buffer>
    1796:	4505                	li	a0,1
    1798:	70d000ef          	jal	ra,26a4 <write>
	buffer_len = 0;
    179c:	00001797          	auipc	a5,0x1
    17a0:	4007ae23          	sw	zero,1052(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    17a4:	bfd1                	j	1778 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17a6:	709000ef          	jal	ra,26ae <getpid>
    17aa:	842a                	mv	s0,a0
    17ac:	00001517          	auipc	a0,0x1
    17b0:	31c50513          	addi	a0,a0,796 # 2ac8 <enable_deadlock_detect+0x14c>
    17b4:	5d1000ef          	jal	ra,2584 <basename>
    17b8:	872a                	mv	a4,a0
    17ba:	00001617          	auipc	a2,0x1
    17be:	22e60613          	addi	a2,a2,558 # 29e8 <enable_deadlock_detect+0x6c>
    17c2:	05400793          	li	a5,84
    17c6:	86a2                	mv	a3,s0
    17c8:	45fd                	li	a1,31
    17ca:	00001517          	auipc	a0,0x1
    17ce:	33e50513          	addi	a0,a0,830 # 2b08 <enable_deadlock_detect+0x18c>
    17d2:	cabff0ef          	jal	ra,147c <printf>
    17d6:	557d                	li	a0,-1
    17d8:	707000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    17dc:	000a2603          	lw	a2,0(s4)
    17e0:	de41                	beqz	a2,1778 <printf+0x2fc>
    17e2:	b775                	j	178e <printf+0x312>
		mutex_lock(buffer_lock);
    17e4:	10ca2503          	lw	a0,268(s4)
    17e8:	134010ef          	jal	ra,291c <mutex_lock>
		buffer[buffer_len++] = c;
    17ec:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17f0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    17f4:	0017861b          	addiw	a2,a5,1
    17f8:	97d2                	add	a5,a5,s4
    17fa:	00ca2023          	sw	a2,0(s4)
    17fe:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1802:	02c6d163          	bge	a3,a2,1824 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1806:	10000793          	li	a5,256
    180a:	02f61263          	bne	a2,a5,182e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    180e:	00001597          	auipc	a1,0x1
    1812:	3b258593          	addi	a1,a1,946 # 2bc0 <buffer>
    1816:	4505                	li	a0,1
    1818:	68d000ef          	jal	ra,26a4 <write>
	buffer_len = 0;
    181c:	00001797          	auipc	a5,0x1
    1820:	3807ae23          	sw	zero,924(a5) # 2bb8 <buffer_len>
		mutex_unlock(buffer_lock);
    1824:	10ca2503          	lw	a0,268(s4)
    1828:	100010ef          	jal	ra,2928 <mutex_unlock>
    182c:	bdd9                	j	1702 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    182e:	681000ef          	jal	ra,26ae <getpid>
    1832:	842a                	mv	s0,a0
    1834:	00001517          	auipc	a0,0x1
    1838:	29450513          	addi	a0,a0,660 # 2ac8 <enable_deadlock_detect+0x14c>
    183c:	549000ef          	jal	ra,2584 <basename>
    1840:	872a                	mv	a4,a0
    1842:	00001617          	auipc	a2,0x1
    1846:	1a660613          	addi	a2,a2,422 # 29e8 <enable_deadlock_detect+0x6c>
    184a:	05400793          	li	a5,84
    184e:	86a2                	mv	a3,s0
    1850:	45fd                	li	a1,31
    1852:	00001517          	auipc	a0,0x1
    1856:	2b650513          	addi	a0,a0,694 # 2b08 <enable_deadlock_detect+0x18c>
    185a:	c23ff0ef          	jal	ra,147c <printf>
    185e:	557d                	li	a0,-1
    1860:	67f000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    1864:	000a2603          	lw	a2,0(s4)
    1868:	de55                	beqz	a2,1824 <printf+0x3a8>
    186a:	b755                	j	180e <printf+0x392>
		mutex_lock(buffer_lock);
    186c:	10ca2503          	lw	a0,268(s4)
    1870:	e42e                	sd	a1,8(sp)
		s += 2;
    1872:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1876:	0a6010ef          	jal	ra,291c <mutex_lock>
		len = out_unlocked(s, l);
    187a:	65a2                	ld	a1,8(sp)
    187c:	8522                	mv	a0,s0
    187e:	08a000ef          	jal	ra,1908 <out_unlocked>
		mutex_unlock(buffer_lock);
    1882:	10ca2503          	lw	a0,268(s4)
    1886:	0a2010ef          	jal	ra,2928 <mutex_unlock>
		s += 2;
    188a:	bb55                	j	163e <printf+0x1c2>
				a = "(null)";
    188c:	00001417          	auipc	s0,0x1
    1890:	23440413          	addi	s0,s0,564 # 2ac0 <enable_deadlock_detect+0x144>
    1894:	bd2d                	j	16ce <printf+0x252>

0000000000001896 <enable_thread_io_buffer>:
{
    1896:	1101                	addi	sp,sp,-32
    1898:	e822                	sd	s0,16(sp)
    189a:	ec06                	sd	ra,24(sp)
    189c:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    189e:	00001417          	auipc	s0,0x1
    18a2:	31a40413          	addi	s0,s0,794 # 2bb8 <buffer_len>
    18a6:	05a010ef          	jal	ra,2900 <mutex_create>
    18aa:	10a42623          	sw	a0,268(s0)
    18ae:	00054a63          	bltz	a0,18c2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18b2:	4785                	li	a5,1
}
    18b4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18b6:	10f42423          	sw	a5,264(s0)
}
    18ba:	6442                	ld	s0,16(sp)
    18bc:	64a2                	ld	s1,8(sp)
    18be:	6105                	addi	sp,sp,32
    18c0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18c2:	5ed000ef          	jal	ra,26ae <getpid>
    18c6:	84aa                	mv	s1,a0
    18c8:	00001517          	auipc	a0,0x1
    18cc:	20050513          	addi	a0,a0,512 # 2ac8 <enable_deadlock_detect+0x14c>
    18d0:	4b5000ef          	jal	ra,2584 <basename>
    18d4:	872a                	mv	a4,a0
    18d6:	04800793          	li	a5,72
    18da:	86a6                	mv	a3,s1
    18dc:	00001517          	auipc	a0,0x1
    18e0:	26c50513          	addi	a0,a0,620 # 2b48 <enable_deadlock_detect+0x1cc>
    18e4:	00001617          	auipc	a2,0x1
    18e8:	10460613          	addi	a2,a2,260 # 29e8 <enable_deadlock_detect+0x6c>
    18ec:	45fd                	li	a1,31
    18ee:	b8fff0ef          	jal	ra,147c <printf>
    18f2:	557d                	li	a0,-1
    18f4:	5eb000ef          	jal	ra,26de <exit>
	buffer_lock_enabled = 1;
    18f8:	4785                	li	a5,1
}
    18fa:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18fc:	10f42423          	sw	a5,264(s0)
}
    1900:	6442                	ld	s0,16(sp)
    1902:	64a2                	ld	s1,8(sp)
    1904:	6105                	addi	sp,sp,32
    1906:	8082                	ret

0000000000001908 <out_unlocked>:
{
    1908:	7159                	addi	sp,sp,-112
    190a:	f486                	sd	ra,104(sp)
    190c:	f0a2                	sd	s0,96(sp)
    190e:	eca6                	sd	s1,88(sp)
    1910:	e8ca                	sd	s2,80(sp)
    1912:	e4ce                	sd	s3,72(sp)
    1914:	e0d2                	sd	s4,64(sp)
    1916:	fc56                	sd	s5,56(sp)
    1918:	f85a                	sd	s6,48(sp)
    191a:	f45e                	sd	s7,40(sp)
    191c:	f062                	sd	s8,32(sp)
    191e:	ec66                	sd	s9,24(sp)
    1920:	e86a                	sd	s10,16(sp)
    1922:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1924:	0e058663          	beqz	a1,1a10 <out_unlocked+0x108>
    1928:	842a                	mv	s0,a0
    192a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    192e:	4981                	li	s3,0
    1930:	00001d17          	auipc	s10,0x1
    1934:	288d0d13          	addi	s10,s10,648 # 2bb8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1938:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    193c:	00001b17          	auipc	s6,0x1
    1940:	284b0b13          	addi	s6,s6,644 # 2bc0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1944:	10000a93          	li	s5,256
    1948:	00001c97          	auipc	s9,0x1
    194c:	180c8c93          	addi	s9,s9,384 # 2ac8 <enable_deadlock_detect+0x14c>
    1950:	00001c17          	auipc	s8,0x1
    1954:	098c0c13          	addi	s8,s8,152 # 29e8 <enable_deadlock_detect+0x6c>
    1958:	00001b97          	auipc	s7,0x1
    195c:	1b0b8b93          	addi	s7,s7,432 # 2b08 <enable_deadlock_detect+0x18c>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1960:	4a29                	li	s4,10
    1962:	a031                	j	196e <out_unlocked+0x66>
    1964:	09468863          	beq	a3,s4,19f4 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1968:	0405                	addi	s0,s0,1
    196a:	04848163          	beq	s1,s0,19ac <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    196e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1972:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1976:	0017861b          	addiw	a2,a5,1
    197a:	97ea                	add	a5,a5,s10
    197c:	00cd2023          	sw	a2,0(s10)
    1980:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1984:	fec950e3          	bge	s2,a2,1964 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1988:	05561263          	bne	a2,s5,19cc <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    198c:	85da                	mv	a1,s6
    198e:	4505                	li	a0,1
    1990:	515000ef          	jal	ra,26a4 <write>
    1994:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1996:	00001797          	auipc	a5,0x1
    199a:	2207a123          	sw	zero,546(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    199e:	06054763          	bltz	a0,1a0c <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19a2:	0405                	addi	s0,s0,1
			ret += r;
    19a4:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19a8:	fc8493e3          	bne	s1,s0,196e <out_unlocked+0x66>
}
    19ac:	70a6                	ld	ra,104(sp)
    19ae:	7406                	ld	s0,96(sp)
    19b0:	64e6                	ld	s1,88(sp)
    19b2:	6946                	ld	s2,80(sp)
    19b4:	6a06                	ld	s4,64(sp)
    19b6:	7ae2                	ld	s5,56(sp)
    19b8:	7b42                	ld	s6,48(sp)
    19ba:	7ba2                	ld	s7,40(sp)
    19bc:	7c02                	ld	s8,32(sp)
    19be:	6ce2                	ld	s9,24(sp)
    19c0:	6d42                	ld	s10,16(sp)
    19c2:	6da2                	ld	s11,8(sp)
    19c4:	854e                	mv	a0,s3
    19c6:	69a6                	ld	s3,72(sp)
    19c8:	6165                	addi	sp,sp,112
    19ca:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19cc:	4e3000ef          	jal	ra,26ae <getpid>
    19d0:	8daa                	mv	s11,a0
    19d2:	8566                	mv	a0,s9
    19d4:	3b1000ef          	jal	ra,2584 <basename>
    19d8:	872a                	mv	a4,a0
    19da:	8662                	mv	a2,s8
    19dc:	05400793          	li	a5,84
    19e0:	86ee                	mv	a3,s11
    19e2:	45fd                	li	a1,31
    19e4:	855e                	mv	a0,s7
    19e6:	a97ff0ef          	jal	ra,147c <printf>
    19ea:	557d                	li	a0,-1
    19ec:	4f3000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    19f0:	000d2603          	lw	a2,0(s10)
    19f4:	da35                	beqz	a2,1968 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    19f6:	85da                	mv	a1,s6
    19f8:	4505                	li	a0,1
    19fa:	4ab000ef          	jal	ra,26a4 <write>
    19fe:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a00:	00001797          	auipc	a5,0x1
    1a04:	1a07ac23          	sw	zero,440(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1a08:	f8055de3          	bgez	a0,19a2 <out_unlocked+0x9a>
    1a0c:	89aa                	mv	s3,a0
    1a0e:	bf79                	j	19ac <out_unlocked+0xa4>
	int ret = 0;
    1a10:	4981                	li	s3,0
    1a12:	bf69                	j	19ac <out_unlocked+0xa4>

0000000000001a14 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a14:	1101                	addi	sp,sp,-32
    1a16:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a18:	00001497          	auipc	s1,0x1
    1a1c:	1a048493          	addi	s1,s1,416 # 2bb8 <buffer_len>
    1a20:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a22:	ec06                	sd	ra,24(sp)
    1a24:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a26:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a2a:	0017861b          	addiw	a2,a5,1
    1a2e:	97a6                	add	a5,a5,s1
    1a30:	00e78423          	sb	a4,8(a5)
    1a34:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a36:	0ff00793          	li	a5,255
    1a3a:	00c7cc63          	blt	a5,a2,1a52 <out_unlocked.constprop.0+0x3e>
    1a3e:	47a9                	li	a5,10
    1a40:	06f70c63          	beq	a4,a5,1ab8 <out_unlocked.constprop.0+0xa4>
    1a44:	4601                	li	a2,0
}
    1a46:	60e2                	ld	ra,24(sp)
    1a48:	6442                	ld	s0,16(sp)
    1a4a:	64a2                	ld	s1,8(sp)
    1a4c:	8532                	mv	a0,a2
    1a4e:	6105                	addi	sp,sp,32
    1a50:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a52:	10000793          	li	a5,256
    1a56:	02f61563          	bne	a2,a5,1a80 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a5a:	00001597          	auipc	a1,0x1
    1a5e:	16658593          	addi	a1,a1,358 # 2bc0 <buffer>
    1a62:	4505                	li	a0,1
    1a64:	441000ef          	jal	ra,26a4 <write>
}
    1a68:	60e2                	ld	ra,24(sp)
    1a6a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a6c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a70:	00001797          	auipc	a5,0x1
    1a74:	1407a423          	sw	zero,328(a5) # 2bb8 <buffer_len>
}
    1a78:	64a2                	ld	s1,8(sp)
    1a7a:	8532                	mv	a0,a2
    1a7c:	6105                	addi	sp,sp,32
    1a7e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a80:	42f000ef          	jal	ra,26ae <getpid>
    1a84:	842a                	mv	s0,a0
    1a86:	00001517          	auipc	a0,0x1
    1a8a:	04250513          	addi	a0,a0,66 # 2ac8 <enable_deadlock_detect+0x14c>
    1a8e:	2f7000ef          	jal	ra,2584 <basename>
    1a92:	872a                	mv	a4,a0
    1a94:	00001617          	auipc	a2,0x1
    1a98:	f5460613          	addi	a2,a2,-172 # 29e8 <enable_deadlock_detect+0x6c>
    1a9c:	05400793          	li	a5,84
    1aa0:	86a2                	mv	a3,s0
    1aa2:	45fd                	li	a1,31
    1aa4:	00001517          	auipc	a0,0x1
    1aa8:	06450513          	addi	a0,a0,100 # 2b08 <enable_deadlock_detect+0x18c>
    1aac:	9d1ff0ef          	jal	ra,147c <printf>
    1ab0:	557d                	li	a0,-1
    1ab2:	42d000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    1ab6:	4090                	lw	a2,0(s1)
    1ab8:	d659                	beqz	a2,1a46 <out_unlocked.constprop.0+0x32>
    1aba:	b745                	j	1a5a <out_unlocked.constprop.0+0x46>

0000000000001abc <putchar>:
{
    1abc:	7139                	addi	sp,sp,-64
    1abe:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ac0:	00001497          	auipc	s1,0x1
    1ac4:	0f848493          	addi	s1,s1,248 # 2bb8 <buffer_len>
    1ac8:	1084a703          	lw	a4,264(s1)
{
    1acc:	f822                	sd	s0,48(sp)
	char byte = c;
    1ace:	0ff57413          	zext.b	s0,a0
{
    1ad2:	fc06                	sd	ra,56(sp)
	char byte = c;
    1ad4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1ad8:	4785                	li	a5,1
    1ada:	00f70d63          	beq	a4,a5,1af4 <putchar+0x38>
		len = out_unlocked(s, l);
    1ade:	01f10513          	addi	a0,sp,31
    1ae2:	f33ff0ef          	jal	ra,1a14 <out_unlocked.constprop.0>
}
    1ae6:	70e2                	ld	ra,56(sp)
    1ae8:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1aea:	862a                	mv	a2,a0
}
    1aec:	74a2                	ld	s1,40(sp)
    1aee:	8532                	mv	a0,a2
    1af0:	6121                	addi	sp,sp,64
    1af2:	8082                	ret
		mutex_lock(buffer_lock);
    1af4:	10c4a503          	lw	a0,268(s1)
    1af8:	625000ef          	jal	ra,291c <mutex_lock>
		buffer[buffer_len++] = c;
    1afc:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1afe:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b02:	0017861b          	addiw	a2,a5,1
    1b06:	97a6                	add	a5,a5,s1
    1b08:	c090                	sw	a2,0(s1)
    1b0a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b0e:	02c6c263          	blt	a3,a2,1b32 <putchar+0x76>
    1b12:	47a9                	li	a5,10
    1b14:	06f40d63          	beq	s0,a5,1b8e <putchar+0xd2>
    1b18:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b1a:	10c4a503          	lw	a0,268(s1)
    1b1e:	e432                	sd	a2,8(sp)
    1b20:	609000ef          	jal	ra,2928 <mutex_unlock>
    1b24:	6622                	ld	a2,8(sp)
}
    1b26:	70e2                	ld	ra,56(sp)
    1b28:	7442                	ld	s0,48(sp)
    1b2a:	74a2                	ld	s1,40(sp)
    1b2c:	8532                	mv	a0,a2
    1b2e:	6121                	addi	sp,sp,64
    1b30:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b32:	10000793          	li	a5,256
    1b36:	02f61063          	bne	a2,a5,1b56 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b3a:	00001597          	auipc	a1,0x1
    1b3e:	08658593          	addi	a1,a1,134 # 2bc0 <buffer>
    1b42:	4505                	li	a0,1
    1b44:	361000ef          	jal	ra,26a4 <write>
    1b48:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b4c:	00001797          	auipc	a5,0x1
    1b50:	0607a623          	sw	zero,108(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1b54:	b7d9                	j	1b1a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b56:	359000ef          	jal	ra,26ae <getpid>
    1b5a:	842a                	mv	s0,a0
    1b5c:	00001517          	auipc	a0,0x1
    1b60:	f6c50513          	addi	a0,a0,-148 # 2ac8 <enable_deadlock_detect+0x14c>
    1b64:	221000ef          	jal	ra,2584 <basename>
    1b68:	872a                	mv	a4,a0
    1b6a:	00001617          	auipc	a2,0x1
    1b6e:	e7e60613          	addi	a2,a2,-386 # 29e8 <enable_deadlock_detect+0x6c>
    1b72:	05400793          	li	a5,84
    1b76:	86a2                	mv	a3,s0
    1b78:	45fd                	li	a1,31
    1b7a:	00001517          	auipc	a0,0x1
    1b7e:	f8e50513          	addi	a0,a0,-114 # 2b08 <enable_deadlock_detect+0x18c>
    1b82:	8fbff0ef          	jal	ra,147c <printf>
    1b86:	557d                	li	a0,-1
    1b88:	357000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    1b8c:	4090                	lw	a2,0(s1)
    1b8e:	d651                	beqz	a2,1b1a <putchar+0x5e>
    1b90:	b76d                	j	1b3a <putchar+0x7e>

0000000000001b92 <puts>:
{
    1b92:	7139                	addi	sp,sp,-64
    1b94:	f822                	sd	s0,48(sp)
    1b96:	f426                	sd	s1,40(sp)
    1b98:	fc06                	sd	ra,56(sp)
    1b9a:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1b9c:	00001417          	auipc	s0,0x1
    1ba0:	01c40413          	addi	s0,s0,28 # 2bb8 <buffer_len>
{
    1ba4:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ba6:	638000ef          	jal	ra,21de <strlen>
	if (buffer_lock_enabled == 1) {
    1baa:	10842703          	lw	a4,264(s0)
    1bae:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bb0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bb2:	04f70563          	beq	a4,a5,1bfc <puts+0x6a>
		len = out_unlocked(s, l);
    1bb6:	8526                	mv	a0,s1
    1bb8:	d51ff0ef          	jal	ra,1908 <out_unlocked>
    1bbc:	892a                	mv	s2,a0
    1bbe:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bc0:	00095963          	bgez	s2,1bd2 <puts+0x40>
}
    1bc4:	70e2                	ld	ra,56(sp)
    1bc6:	7442                	ld	s0,48(sp)
    1bc8:	7902                	ld	s2,32(sp)
    1bca:	8526                	mv	a0,s1
    1bcc:	74a2                	ld	s1,40(sp)
    1bce:	6121                	addi	sp,sp,64
    1bd0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1bd2:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bd6:	44a9                	li	s1,10
    1bd8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bdc:	4785                	li	a5,1
    1bde:	02f70e63          	beq	a4,a5,1c1a <puts+0x88>
		len = out_unlocked(s, l);
    1be2:	01f10513          	addi	a0,sp,31
    1be6:	e2fff0ef          	jal	ra,1a14 <out_unlocked.constprop.0>
}
    1bea:	70e2                	ld	ra,56(sp)
    1bec:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bee:	41f5549b          	sraiw	s1,a0,0x1f
}
    1bf2:	7902                	ld	s2,32(sp)
    1bf4:	8526                	mv	a0,s1
    1bf6:	74a2                	ld	s1,40(sp)
    1bf8:	6121                	addi	sp,sp,64
    1bfa:	8082                	ret
		mutex_lock(buffer_lock);
    1bfc:	e42a                	sd	a0,8(sp)
    1bfe:	10c42503          	lw	a0,268(s0)
    1c02:	51b000ef          	jal	ra,291c <mutex_lock>
		len = out_unlocked(s, l);
    1c06:	65a2                	ld	a1,8(sp)
    1c08:	8526                	mv	a0,s1
    1c0a:	cffff0ef          	jal	ra,1908 <out_unlocked>
    1c0e:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c10:	10c42503          	lw	a0,268(s0)
    1c14:	515000ef          	jal	ra,2928 <mutex_unlock>
    1c18:	b75d                	j	1bbe <puts+0x2c>
		mutex_lock(buffer_lock);
    1c1a:	10c42503          	lw	a0,268(s0)
    1c1e:	4ff000ef          	jal	ra,291c <mutex_lock>
		buffer[buffer_len++] = c;
    1c22:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c24:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c28:	0017861b          	addiw	a2,a5,1
    1c2c:	97a2                	add	a5,a5,s0
    1c2e:	c010                	sw	a2,0(s0)
    1c30:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c34:	06c6dc63          	bge	a3,a2,1cac <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c38:	10000793          	li	a5,256
    1c3c:	02f61c63          	bne	a2,a5,1c74 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c40:	00001597          	auipc	a1,0x1
    1c44:	f8058593          	addi	a1,a1,-128 # 2bc0 <buffer>
    1c48:	4505                	li	a0,1
    1c4a:	25b000ef          	jal	ra,26a4 <write>
			if (r < 0) {
    1c4e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c50:	00001797          	auipc	a5,0x1
    1c54:	f607a423          	sw	zero,-152(a5) # 2bb8 <buffer_len>
			if (r < 0) {
    1c58:	04054c63          	bltz	a0,1cb0 <puts+0x11e>
			if (r < buffer_len) {
    1c5c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c5e:	10c42503          	lw	a0,268(s0)
    1c62:	4c7000ef          	jal	ra,2928 <mutex_unlock>
}
    1c66:	70e2                	ld	ra,56(sp)
    1c68:	7442                	ld	s0,48(sp)
    1c6a:	7902                	ld	s2,32(sp)
    1c6c:	8526                	mv	a0,s1
    1c6e:	74a2                	ld	s1,40(sp)
    1c70:	6121                	addi	sp,sp,64
    1c72:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c74:	23b000ef          	jal	ra,26ae <getpid>
    1c78:	84aa                	mv	s1,a0
    1c7a:	00001517          	auipc	a0,0x1
    1c7e:	e4e50513          	addi	a0,a0,-434 # 2ac8 <enable_deadlock_detect+0x14c>
    1c82:	103000ef          	jal	ra,2584 <basename>
    1c86:	872a                	mv	a4,a0
    1c88:	00001617          	auipc	a2,0x1
    1c8c:	d6060613          	addi	a2,a2,-672 # 29e8 <enable_deadlock_detect+0x6c>
    1c90:	05400793          	li	a5,84
    1c94:	86a6                	mv	a3,s1
    1c96:	45fd                	li	a1,31
    1c98:	00001517          	auipc	a0,0x1
    1c9c:	e7050513          	addi	a0,a0,-400 # 2b08 <enable_deadlock_detect+0x18c>
    1ca0:	fdcff0ef          	jal	ra,147c <printf>
    1ca4:	557d                	li	a0,-1
    1ca6:	239000ef          	jal	ra,26de <exit>
	if (buffer_len == 0)
    1caa:	4010                	lw	a2,0(s0)
    1cac:	da45                	beqz	a2,1c5c <puts+0xca>
    1cae:	bf49                	j	1c40 <puts+0xae>
    1cb0:	54fd                	li	s1,-1
    1cb2:	b775                	j	1c5e <puts+0xcc>

0000000000001cb4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cb4:	715d                	addi	sp,sp,-80
    1cb6:	e486                	sd	ra,72(sp)
    1cb8:	e0a2                	sd	s0,64(sp)
    1cba:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1cbc:	14054363          	bltz	a0,1e02 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1cc0:	02b577bb          	remuw	a5,a0,a1
    1cc4:	00001617          	auipc	a2,0x1
    1cc8:	15c60613          	addi	a2,a2,348 # 2e20 <digits>
	buf[16] = 0;
    1ccc:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1cd0:	0005871b          	sext.w	a4,a1
    1cd4:	1782                	slli	a5,a5,0x20
    1cd6:	9381                	srli	a5,a5,0x20
    1cd8:	97b2                	add	a5,a5,a2
    1cda:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cde:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ce2:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ce6:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ce8:	0eb56763          	bltu	a0,a1,1dd6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1cec:	02e877bb          	remuw	a5,a6,a4
    1cf0:	1782                	slli	a5,a5,0x20
    1cf2:	9381                	srli	a5,a5,0x20
    1cf4:	97b2                	add	a5,a5,a2
    1cf6:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cfa:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1cfe:	02f10323          	sb	a5,38(sp)
    1d02:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d04:	0ce86963          	bltu	a6,a4,1dd6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d08:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d0c:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d10:	1582                	slli	a1,a1,0x20
    1d12:	9181                	srli	a1,a1,0x20
    1d14:	95b2                	add	a1,a1,a2
    1d16:	0005c583          	lbu	a1,0(a1)
    1d1a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d1e:	0007859b          	sext.w	a1,a5
    1d22:	16e6e563          	bltu	a3,a4,1e8c <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d26:	02e7f6bb          	remuw	a3,a5,a4
    1d2a:	1682                	slli	a3,a3,0x20
    1d2c:	9281                	srli	a3,a3,0x20
    1d2e:	96b2                	add	a3,a3,a2
    1d30:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d34:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d38:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d3c:	16e5e163          	bltu	a1,a4,1e9e <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d40:	02e876bb          	remuw	a3,a6,a4
    1d44:	1682                	slli	a3,a3,0x20
    1d46:	9281                	srli	a3,a3,0x20
    1d48:	96b2                	add	a3,a3,a2
    1d4a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d4e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d52:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d56:	14e86d63          	bltu	a6,a4,1eb0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d5a:	02e5f6bb          	remuw	a3,a1,a4
    1d5e:	1682                	slli	a3,a3,0x20
    1d60:	9281                	srli	a3,a3,0x20
    1d62:	96b2                	add	a3,a3,a2
    1d64:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d68:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d6c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d70:	10e5e563          	bltu	a1,a4,1e7a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d74:	02e876bb          	remuw	a3,a6,a4
    1d78:	1682                	slli	a3,a3,0x20
    1d7a:	9281                	srli	a3,a3,0x20
    1d7c:	96b2                	add	a3,a3,a2
    1d7e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d82:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d86:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1d8a:	14e86263          	bltu	a6,a4,1ece <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1d8e:	02e5f6bb          	remuw	a3,a1,a4
    1d92:	1682                	slli	a3,a3,0x20
    1d94:	9281                	srli	a3,a3,0x20
    1d96:	96b2                	add	a3,a3,a2
    1d98:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d9c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1da0:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1da4:	14e5e463          	bltu	a1,a4,1eec <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1da8:	02e876bb          	remuw	a3,a6,a4
    1dac:	1682                	slli	a3,a3,0x20
    1dae:	9281                	srli	a3,a3,0x20
    1db0:	96b2                	add	a3,a3,a2
    1db2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1db6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1dba:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1dbe:	14e86063          	bltu	a6,a4,1efe <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1dc2:	1782                	slli	a5,a5,0x20
    1dc4:	9381                	srli	a5,a5,0x20
    1dc6:	97b2                	add	a5,a5,a2
    1dc8:	0007c703          	lbu	a4,0(a5)
    1dcc:	4799                	li	a5,6
    1dce:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1dd2:	10054763          	bltz	a0,1ee0 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1dd6:	00001497          	auipc	s1,0x1
    1dda:	de248493          	addi	s1,s1,-542 # 2bb8 <buffer_len>
    1dde:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1de2:	0828                	addi	a0,sp,24
    1de4:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1de6:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1de8:	00f50433          	add	s0,a0,a5
    1dec:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1dee:	06e68463          	beq	a3,a4,1e56 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1df2:	8522                	mv	a0,s0
    1df4:	b15ff0ef          	jal	ra,1908 <out_unlocked>
}
    1df8:	60a6                	ld	ra,72(sp)
    1dfa:	6406                	ld	s0,64(sp)
    1dfc:	74e2                	ld	s1,56(sp)
    1dfe:	6161                	addi	sp,sp,80
    1e00:	8082                	ret
		x = -xx;
    1e02:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e06:	02b877bb          	remuw	a5,a6,a1
    1e0a:	00001617          	auipc	a2,0x1
    1e0e:	01660613          	addi	a2,a2,22 # 2e20 <digits>
	buf[16] = 0;
    1e12:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e16:	0005871b          	sext.w	a4,a1
    1e1a:	1782                	slli	a5,a5,0x20
    1e1c:	9381                	srli	a5,a5,0x20
    1e1e:	97b2                	add	a5,a5,a2
    1e20:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e24:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e28:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e2c:	08b86b63          	bltu	a6,a1,1ec2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e30:	02e8f7bb          	remuw	a5,a7,a4
    1e34:	1782                	slli	a5,a5,0x20
    1e36:	9381                	srli	a5,a5,0x20
    1e38:	97b2                	add	a5,a5,a2
    1e3a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e3e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e42:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e46:	ece8f1e3          	bgeu	a7,a4,1d08 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e4a:	02d00793          	li	a5,45
    1e4e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e52:	47b5                	li	a5,13
    1e54:	b749                	j	1dd6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e56:	10c4a503          	lw	a0,268(s1)
    1e5a:	e42e                	sd	a1,8(sp)
    1e5c:	2c1000ef          	jal	ra,291c <mutex_lock>
		len = out_unlocked(s, l);
    1e60:	65a2                	ld	a1,8(sp)
    1e62:	8522                	mv	a0,s0
    1e64:	aa5ff0ef          	jal	ra,1908 <out_unlocked>
		mutex_unlock(buffer_lock);
    1e68:	10c4a503          	lw	a0,268(s1)
    1e6c:	2bd000ef          	jal	ra,2928 <mutex_unlock>
}
    1e70:	60a6                	ld	ra,72(sp)
    1e72:	6406                	ld	s0,64(sp)
    1e74:	74e2                	ld	s1,56(sp)
    1e76:	6161                	addi	sp,sp,80
    1e78:	8082                	ret
		buf[i--] = digits[x % base];
    1e7a:	47a9                	li	a5,10
	if (sign)
    1e7c:	f4055de3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e80:	02d00793          	li	a5,45
    1e84:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e88:	47a5                	li	a5,9
    1e8a:	b7b1                	j	1dd6 <printint.constprop.0+0x122>
    1e8c:	47b5                	li	a5,13
	if (sign)
    1e8e:	f40554e3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e92:	02d00793          	li	a5,45
    1e96:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1e9a:	47b1                	li	a5,12
    1e9c:	bf2d                	j	1dd6 <printint.constprop.0+0x122>
    1e9e:	47b1                	li	a5,12
	if (sign)
    1ea0:	f2055be3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea4:	02d00793          	li	a5,45
    1ea8:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1eac:	47ad                	li	a5,11
    1eae:	b725                	j	1dd6 <printint.constprop.0+0x122>
    1eb0:	47ad                	li	a5,11
	if (sign)
    1eb2:	f20552e3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb6:	02d00793          	li	a5,45
    1eba:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ebe:	47a9                	li	a5,10
    1ec0:	bf19                	j	1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ec2:	02d00793          	li	a5,45
    1ec6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1eca:	47b9                	li	a5,14
    1ecc:	b729                	j	1dd6 <printint.constprop.0+0x122>
    1ece:	47a5                	li	a5,9
	if (sign)
    1ed0:	f00553e3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed4:	02d00793          	li	a5,45
    1ed8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1edc:	47a1                	li	a5,8
    1ede:	bde5                	j	1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ee0:	02d00793          	li	a5,45
    1ee4:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ee8:	4795                	li	a5,5
    1eea:	b5f5                	j	1dd6 <printint.constprop.0+0x122>
    1eec:	47a1                	li	a5,8
	if (sign)
    1eee:	ee0554e3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef2:	02d00793          	li	a5,45
    1ef6:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1efa:	479d                	li	a5,7
    1efc:	bde9                	j	1dd6 <printint.constprop.0+0x122>
    1efe:	479d                	li	a5,7
	if (sign)
    1f00:	ec055be3          	bgez	a0,1dd6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f04:	02d00793          	li	a5,45
    1f08:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f0c:	4799                	li	a5,6
    1f0e:	b5e1                	j	1dd6 <printint.constprop.0+0x122>

0000000000001f10 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f10:	02000793          	li	a5,32
    1f14:	00f50663          	beq	a0,a5,1f20 <isspace+0x10>
    1f18:	355d                	addiw	a0,a0,-9
    1f1a:	00553513          	sltiu	a0,a0,5
    1f1e:	8082                	ret
    1f20:	4505                	li	a0,1
}
    1f22:	8082                	ret

0000000000001f24 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f24:	fd05051b          	addiw	a0,a0,-48
}
    1f28:	00a53513          	sltiu	a0,a0,10
    1f2c:	8082                	ret

0000000000001f2e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f2e:	02000613          	li	a2,32
    1f32:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f34:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f38:	ff77869b          	addiw	a3,a5,-9
    1f3c:	04c78c63          	beq	a5,a2,1f94 <atoi+0x66>
    1f40:	0007871b          	sext.w	a4,a5
    1f44:	04d5f863          	bgeu	a1,a3,1f94 <atoi+0x66>
		s++;
	switch (*s) {
    1f48:	02b00693          	li	a3,43
    1f4c:	04d78963          	beq	a5,a3,1f9e <atoi+0x70>
    1f50:	02d00693          	li	a3,45
    1f54:	06d78263          	beq	a5,a3,1fb8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f58:	fd07061b          	addiw	a2,a4,-48
    1f5c:	47a5                	li	a5,9
    1f5e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f60:	4e01                	li	t3,0
	while (isdigit(*s))
    1f62:	04c7e963          	bltu	a5,a2,1fb4 <atoi+0x86>
	int n = 0, neg = 0;
    1f66:	4501                	li	a0,0
	while (isdigit(*s))
    1f68:	4825                	li	a6,9
    1f6a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f6e:	0025179b          	slliw	a5,a0,0x2
    1f72:	9fa9                	addw	a5,a5,a0
    1f74:	fd07031b          	addiw	t1,a4,-48
    1f78:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f7c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f80:	0685                	addi	a3,a3,1
    1f82:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f86:	0006071b          	sext.w	a4,a2
    1f8a:	feb870e3          	bgeu	a6,a1,1f6a <atoi+0x3c>
	return neg ? n : -n;
    1f8e:	000e0563          	beqz	t3,1f98 <atoi+0x6a>
}
    1f92:	8082                	ret
		s++;
    1f94:	0505                	addi	a0,a0,1
    1f96:	bf79                	j	1f34 <atoi+0x6>
	return neg ? n : -n;
    1f98:	4113053b          	subw	a0,t1,a7
    1f9c:	8082                	ret
	while (isdigit(*s))
    1f9e:	00154703          	lbu	a4,1(a0)
    1fa2:	47a5                	li	a5,9
		s++;
    1fa4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fa8:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fac:	4e01                	li	t3,0
	while (isdigit(*s))
    1fae:	2701                	sext.w	a4,a4
    1fb0:	fac7fbe3          	bgeu	a5,a2,1f66 <atoi+0x38>
    1fb4:	4501                	li	a0,0
}
    1fb6:	8082                	ret
	while (isdigit(*s))
    1fb8:	00154703          	lbu	a4,1(a0)
    1fbc:	47a5                	li	a5,9
		s++;
    1fbe:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fc2:	fd07061b          	addiw	a2,a4,-48
    1fc6:	2701                	sext.w	a4,a4
    1fc8:	fec7e6e3          	bltu	a5,a2,1fb4 <atoi+0x86>
		neg = 1;
    1fcc:	4e05                	li	t3,1
    1fce:	bf61                	j	1f66 <atoi+0x38>

0000000000001fd0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fd0:	16060d63          	beqz	a2,214a <memset+0x17a>
    1fd4:	40a007b3          	neg	a5,a0
    1fd8:	8b9d                	andi	a5,a5,7
    1fda:	00778693          	addi	a3,a5,7
    1fde:	482d                	li	a6,11
    1fe0:	0ff5f713          	zext.b	a4,a1
    1fe4:	fff60593          	addi	a1,a2,-1
    1fe8:	1706e263          	bltu	a3,a6,214c <memset+0x17c>
    1fec:	16d5ea63          	bltu	a1,a3,2160 <memset+0x190>
    1ff0:	16078563          	beqz	a5,215a <memset+0x18a>
    1ff4:	00e50023          	sb	a4,0(a0)
    1ff8:	4685                	li	a3,1
    1ffa:	00150593          	addi	a1,a0,1
    1ffe:	14d78c63          	beq	a5,a3,2156 <memset+0x186>
    2002:	00e500a3          	sb	a4,1(a0)
    2006:	4689                	li	a3,2
    2008:	00250593          	addi	a1,a0,2
    200c:	14d78d63          	beq	a5,a3,2166 <memset+0x196>
    2010:	00e50123          	sb	a4,2(a0)
    2014:	468d                	li	a3,3
    2016:	00350593          	addi	a1,a0,3
    201a:	12d78b63          	beq	a5,a3,2150 <memset+0x180>
    201e:	00e501a3          	sb	a4,3(a0)
    2022:	4691                	li	a3,4
    2024:	00450593          	addi	a1,a0,4
    2028:	14d78163          	beq	a5,a3,216a <memset+0x19a>
    202c:	00e50223          	sb	a4,4(a0)
    2030:	4695                	li	a3,5
    2032:	00550593          	addi	a1,a0,5
    2036:	12d78c63          	beq	a5,a3,216e <memset+0x19e>
    203a:	00e502a3          	sb	a4,5(a0)
    203e:	469d                	li	a3,7
    2040:	00650593          	addi	a1,a0,6
    2044:	12d79763          	bne	a5,a3,2172 <memset+0x1a2>
    2048:	00750593          	addi	a1,a0,7
    204c:	00e50323          	sb	a4,6(a0)
    2050:	481d                	li	a6,7
    2052:	00871693          	slli	a3,a4,0x8
    2056:	01071893          	slli	a7,a4,0x10
    205a:	8ed9                	or	a3,a3,a4
    205c:	01871313          	slli	t1,a4,0x18
    2060:	0116e6b3          	or	a3,a3,a7
    2064:	0066e6b3          	or	a3,a3,t1
    2068:	02071893          	slli	a7,a4,0x20
    206c:	02871e13          	slli	t3,a4,0x28
    2070:	0116e6b3          	or	a3,a3,a7
    2074:	40f60333          	sub	t1,a2,a5
    2078:	03071893          	slli	a7,a4,0x30
    207c:	01c6e6b3          	or	a3,a3,t3
    2080:	0116e6b3          	or	a3,a3,a7
    2084:	03871e13          	slli	t3,a4,0x38
    2088:	97aa                	add	a5,a5,a0
    208a:	ff837893          	andi	a7,t1,-8
    208e:	01c6e6b3          	or	a3,a3,t3
    2092:	98be                	add	a7,a7,a5
    2094:	e394                	sd	a3,0(a5)
    2096:	07a1                	addi	a5,a5,8
    2098:	ff179ee3          	bne	a5,a7,2094 <memset+0xc4>
    209c:	ff837893          	andi	a7,t1,-8
    20a0:	011587b3          	add	a5,a1,a7
    20a4:	010886bb          	addw	a3,a7,a6
    20a8:	0b130663          	beq	t1,a7,2154 <memset+0x184>
    20ac:	00e78023          	sb	a4,0(a5)
    20b0:	0016859b          	addiw	a1,a3,1
    20b4:	08c5fb63          	bgeu	a1,a2,214a <memset+0x17a>
    20b8:	00e780a3          	sb	a4,1(a5)
    20bc:	0026859b          	addiw	a1,a3,2
    20c0:	08c5f563          	bgeu	a1,a2,214a <memset+0x17a>
    20c4:	00e78123          	sb	a4,2(a5)
    20c8:	0036859b          	addiw	a1,a3,3
    20cc:	06c5ff63          	bgeu	a1,a2,214a <memset+0x17a>
    20d0:	00e781a3          	sb	a4,3(a5)
    20d4:	0046859b          	addiw	a1,a3,4
    20d8:	06c5f963          	bgeu	a1,a2,214a <memset+0x17a>
    20dc:	00e78223          	sb	a4,4(a5)
    20e0:	0056859b          	addiw	a1,a3,5
    20e4:	06c5f363          	bgeu	a1,a2,214a <memset+0x17a>
    20e8:	00e782a3          	sb	a4,5(a5)
    20ec:	0066859b          	addiw	a1,a3,6
    20f0:	04c5fd63          	bgeu	a1,a2,214a <memset+0x17a>
    20f4:	00e78323          	sb	a4,6(a5)
    20f8:	0076859b          	addiw	a1,a3,7
    20fc:	04c5f763          	bgeu	a1,a2,214a <memset+0x17a>
    2100:	00e783a3          	sb	a4,7(a5)
    2104:	0086859b          	addiw	a1,a3,8
    2108:	04c5f163          	bgeu	a1,a2,214a <memset+0x17a>
    210c:	00e78423          	sb	a4,8(a5)
    2110:	0096859b          	addiw	a1,a3,9
    2114:	02c5fb63          	bgeu	a1,a2,214a <memset+0x17a>
    2118:	00e784a3          	sb	a4,9(a5)
    211c:	00a6859b          	addiw	a1,a3,10
    2120:	02c5f563          	bgeu	a1,a2,214a <memset+0x17a>
    2124:	00e78523          	sb	a4,10(a5)
    2128:	00b6859b          	addiw	a1,a3,11
    212c:	00c5ff63          	bgeu	a1,a2,214a <memset+0x17a>
    2130:	00e785a3          	sb	a4,11(a5)
    2134:	00c6859b          	addiw	a1,a3,12
    2138:	00c5f963          	bgeu	a1,a2,214a <memset+0x17a>
    213c:	00e78623          	sb	a4,12(a5)
    2140:	26b5                	addiw	a3,a3,13
    2142:	00c6f463          	bgeu	a3,a2,214a <memset+0x17a>
    2146:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    214a:	8082                	ret
    214c:	46ad                	li	a3,11
    214e:	bd79                	j	1fec <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2150:	480d                	li	a6,3
    2152:	b701                	j	2052 <memset+0x82>
    2154:	8082                	ret
    2156:	4805                	li	a6,1
    2158:	bded                	j	2052 <memset+0x82>
    215a:	85aa                	mv	a1,a0
    215c:	4801                	li	a6,0
    215e:	bdd5                	j	2052 <memset+0x82>
    2160:	87aa                	mv	a5,a0
    2162:	4681                	li	a3,0
    2164:	b7a1                	j	20ac <memset+0xdc>
    2166:	4809                	li	a6,2
    2168:	b5ed                	j	2052 <memset+0x82>
    216a:	4811                	li	a6,4
    216c:	b5dd                	j	2052 <memset+0x82>
    216e:	4815                	li	a6,5
    2170:	b5cd                	j	2052 <memset+0x82>
    2172:	4819                	li	a6,6
    2174:	bdf9                	j	2052 <memset+0x82>

0000000000002176 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2176:	00054783          	lbu	a5,0(a0)
    217a:	0005c703          	lbu	a4,0(a1)
    217e:	00e79863          	bne	a5,a4,218e <strcmp+0x18>
    2182:	0505                	addi	a0,a0,1
    2184:	0585                	addi	a1,a1,1
    2186:	fbe5                	bnez	a5,2176 <strcmp>
    2188:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    218a:	9d19                	subw	a0,a0,a4
    218c:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    218e:	0007851b          	sext.w	a0,a5
    2192:	bfe5                	j	218a <strcmp+0x14>

0000000000002194 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2194:	ca15                	beqz	a2,21c8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2196:	00054783          	lbu	a5,0(a0)
	if (!n--)
    219a:	167d                	addi	a2,a2,-1
    219c:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21a0:	eb99                	bnez	a5,21b6 <strncmp+0x22>
    21a2:	a815                	j	21d6 <strncmp+0x42>
    21a4:	00a68e63          	beq	a3,a0,21c0 <strncmp+0x2c>
    21a8:	0505                	addi	a0,a0,1
    21aa:	00f71b63          	bne	a4,a5,21c0 <strncmp+0x2c>
    21ae:	00054783          	lbu	a5,0(a0)
    21b2:	cf89                	beqz	a5,21cc <strncmp+0x38>
    21b4:	85b2                	mv	a1,a2
    21b6:	0005c703          	lbu	a4,0(a1)
    21ba:	00158613          	addi	a2,a1,1
    21be:	f37d                	bnez	a4,21a4 <strncmp+0x10>
		;
	return *l - *r;
    21c0:	0007851b          	sext.w	a0,a5
    21c4:	9d19                	subw	a0,a0,a4
    21c6:	8082                	ret
		return 0;
    21c8:	4501                	li	a0,0
}
    21ca:	8082                	ret
	return *l - *r;
    21cc:	0015c703          	lbu	a4,1(a1)
    21d0:	4501                	li	a0,0
    21d2:	9d19                	subw	a0,a0,a4
    21d4:	8082                	ret
    21d6:	0005c703          	lbu	a4,0(a1)
    21da:	4501                	li	a0,0
    21dc:	b7e5                	j	21c4 <strncmp+0x30>

00000000000021de <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21de:	00757793          	andi	a5,a0,7
    21e2:	cf89                	beqz	a5,21fc <strlen+0x1e>
    21e4:	87aa                	mv	a5,a0
    21e6:	a029                	j	21f0 <strlen+0x12>
    21e8:	0785                	addi	a5,a5,1
    21ea:	0077f713          	andi	a4,a5,7
    21ee:	cb01                	beqz	a4,21fe <strlen+0x20>
		if (!*s)
    21f0:	0007c703          	lbu	a4,0(a5)
    21f4:	fb75                	bnez	a4,21e8 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    21f6:	40a78533          	sub	a0,a5,a0
}
    21fa:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    21fc:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    21fe:	6394                	ld	a3,0(a5)
    2200:	00001597          	auipc	a1,0x1
    2204:	9a05b583          	ld	a1,-1632(a1) # 2ba0 <enable_deadlock_detect+0x224>
    2208:	00001617          	auipc	a2,0x1
    220c:	9a063603          	ld	a2,-1632(a2) # 2ba8 <enable_deadlock_detect+0x22c>
    2210:	a019                	j	2216 <strlen+0x38>
    2212:	6794                	ld	a3,8(a5)
    2214:	07a1                	addi	a5,a5,8
    2216:	00b68733          	add	a4,a3,a1
    221a:	fff6c693          	not	a3,a3
    221e:	8f75                	and	a4,a4,a3
    2220:	8f71                	and	a4,a4,a2
    2222:	db65                	beqz	a4,2212 <strlen+0x34>
	for (; *s; s++)
    2224:	0007c703          	lbu	a4,0(a5)
    2228:	d779                	beqz	a4,21f6 <strlen+0x18>
    222a:	0017c703          	lbu	a4,1(a5)
    222e:	0785                	addi	a5,a5,1
    2230:	d379                	beqz	a4,21f6 <strlen+0x18>
    2232:	0017c703          	lbu	a4,1(a5)
    2236:	0785                	addi	a5,a5,1
    2238:	fb6d                	bnez	a4,222a <strlen+0x4c>
    223a:	bf75                	j	21f6 <strlen+0x18>

000000000000223c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    223c:	00757713          	andi	a4,a0,7
{
    2240:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2242:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2246:	cb19                	beqz	a4,225c <memchr+0x20>
    2248:	ce25                	beqz	a2,22c0 <memchr+0x84>
    224a:	0007c703          	lbu	a4,0(a5)
    224e:	04b70e63          	beq	a4,a1,22aa <memchr+0x6e>
    2252:	0785                	addi	a5,a5,1
    2254:	0077f713          	andi	a4,a5,7
    2258:	167d                	addi	a2,a2,-1
    225a:	f77d                	bnez	a4,2248 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    225c:	4501                	li	a0,0
	if (n && *s != c) {
    225e:	c235                	beqz	a2,22c2 <memchr+0x86>
    2260:	0007c703          	lbu	a4,0(a5)
    2264:	04b70363          	beq	a4,a1,22aa <memchr+0x6e>
		size_t k = ONES * c;
    2268:	00001517          	auipc	a0,0x1
    226c:	94853503          	ld	a0,-1720(a0) # 2bb0 <enable_deadlock_detect+0x234>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2270:	471d                	li	a4,7
		size_t k = ONES * c;
    2272:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2276:	02c77a63          	bgeu	a4,a2,22aa <memchr+0x6e>
    227a:	00001897          	auipc	a7,0x1
    227e:	9268b883          	ld	a7,-1754(a7) # 2ba0 <enable_deadlock_detect+0x224>
    2282:	00001817          	auipc	a6,0x1
    2286:	92683803          	ld	a6,-1754(a6) # 2ba8 <enable_deadlock_detect+0x22c>
    228a:	431d                	li	t1,7
    228c:	a029                	j	2296 <memchr+0x5a>
		     w++, n -= SS)
    228e:	1661                	addi	a2,a2,-8
    2290:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2292:	02c37963          	bgeu	t1,a2,22c4 <memchr+0x88>
    2296:	6398                	ld	a4,0(a5)
    2298:	8f29                	xor	a4,a4,a0
    229a:	011706b3          	add	a3,a4,a7
    229e:	fff74713          	not	a4,a4
    22a2:	8f75                	and	a4,a4,a3
    22a4:	01077733          	and	a4,a4,a6
    22a8:	d37d                	beqz	a4,228e <memchr+0x52>
{
    22aa:	853e                	mv	a0,a5
    22ac:	97b2                	add	a5,a5,a2
    22ae:	a021                	j	22b6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22b0:	0505                	addi	a0,a0,1
    22b2:	00f50763          	beq	a0,a5,22c0 <memchr+0x84>
    22b6:	00054703          	lbu	a4,0(a0)
    22ba:	feb71be3          	bne	a4,a1,22b0 <memchr+0x74>
    22be:	8082                	ret
	return n ? (void *)s : 0;
    22c0:	4501                	li	a0,0
}
    22c2:	8082                	ret
	return n ? (void *)s : 0;
    22c4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22c6:	f275                	bnez	a2,22aa <memchr+0x6e>
}
    22c8:	8082                	ret

00000000000022ca <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22ca:	1101                	addi	sp,sp,-32
    22cc:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22ce:	862e                	mv	a2,a1
{
    22d0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22d2:	4581                	li	a1,0
{
    22d4:	e426                	sd	s1,8(sp)
    22d6:	ec06                	sd	ra,24(sp)
    22d8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22da:	f63ff0ef          	jal	ra,223c <memchr>
	return p ? p - s : n;
    22de:	c519                	beqz	a0,22ec <strnlen+0x22>
}
    22e0:	60e2                	ld	ra,24(sp)
    22e2:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22e4:	8d05                	sub	a0,a0,s1
}
    22e6:	64a2                	ld	s1,8(sp)
    22e8:	6105                	addi	sp,sp,32
    22ea:	8082                	ret
    22ec:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    22ee:	8522                	mv	a0,s0
}
    22f0:	6442                	ld	s0,16(sp)
    22f2:	64a2                	ld	s1,8(sp)
    22f4:	6105                	addi	sp,sp,32
    22f6:	8082                	ret

00000000000022f8 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    22f8:	00a5c7b3          	xor	a5,a1,a0
    22fc:	8b9d                	andi	a5,a5,7
    22fe:	eb95                	bnez	a5,2332 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2300:	0075f793          	andi	a5,a1,7
    2304:	e7b1                	bnez	a5,2350 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2306:	6198                	ld	a4,0(a1)
    2308:	00001617          	auipc	a2,0x1
    230c:	89863603          	ld	a2,-1896(a2) # 2ba0 <enable_deadlock_detect+0x224>
    2310:	00001817          	auipc	a6,0x1
    2314:	89883803          	ld	a6,-1896(a6) # 2ba8 <enable_deadlock_detect+0x22c>
    2318:	a029                	j	2322 <stpcpy+0x2a>
    231a:	05a1                	addi	a1,a1,8
    231c:	e118                	sd	a4,0(a0)
    231e:	6198                	ld	a4,0(a1)
    2320:	0521                	addi	a0,a0,8
    2322:	00c707b3          	add	a5,a4,a2
    2326:	fff74693          	not	a3,a4
    232a:	8ff5                	and	a5,a5,a3
    232c:	0107f7b3          	and	a5,a5,a6
    2330:	d7ed                	beqz	a5,231a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2332:	0005c783          	lbu	a5,0(a1)
    2336:	00f50023          	sb	a5,0(a0)
    233a:	c785                	beqz	a5,2362 <stpcpy+0x6a>
    233c:	0015c783          	lbu	a5,1(a1)
    2340:	0505                	addi	a0,a0,1
    2342:	0585                	addi	a1,a1,1
    2344:	00f50023          	sb	a5,0(a0)
    2348:	fbf5                	bnez	a5,233c <stpcpy+0x44>
		;
	return d;
}
    234a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    234c:	0505                	addi	a0,a0,1
    234e:	df45                	beqz	a4,2306 <stpcpy+0xe>
			if (!(*d = *s))
    2350:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2354:	0585                	addi	a1,a1,1
    2356:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    235a:	00f50023          	sb	a5,0(a0)
    235e:	f7fd                	bnez	a5,234c <stpcpy+0x54>
}
    2360:	8082                	ret
    2362:	8082                	ret

0000000000002364 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2364:	00a5c7b3          	xor	a5,a1,a0
    2368:	8b9d                	andi	a5,a5,7
    236a:	1a079863          	bnez	a5,251a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    236e:	0075f793          	andi	a5,a1,7
    2372:	16078463          	beqz	a5,24da <stpncpy+0x176>
    2376:	ea01                	bnez	a2,2386 <stpncpy+0x22>
    2378:	a421                	j	2580 <stpncpy+0x21c>
    237a:	167d                	addi	a2,a2,-1
    237c:	0505                	addi	a0,a0,1
    237e:	14070e63          	beqz	a4,24da <stpncpy+0x176>
    2382:	1a060863          	beqz	a2,2532 <stpncpy+0x1ce>
    2386:	0005c783          	lbu	a5,0(a1)
    238a:	0585                	addi	a1,a1,1
    238c:	0075f713          	andi	a4,a1,7
    2390:	00f50023          	sb	a5,0(a0)
    2394:	f3fd                	bnez	a5,237a <stpncpy+0x16>
    2396:	4805                	li	a6,1
    2398:	1a061863          	bnez	a2,2548 <stpncpy+0x1e4>
    239c:	40a007b3          	neg	a5,a0
    23a0:	8b9d                	andi	a5,a5,7
    23a2:	4681                	li	a3,0
    23a4:	18061a63          	bnez	a2,2538 <stpncpy+0x1d4>
    23a8:	00778713          	addi	a4,a5,7
    23ac:	45ad                	li	a1,11
    23ae:	18b76363          	bltu	a4,a1,2534 <stpncpy+0x1d0>
    23b2:	1ae6eb63          	bltu	a3,a4,2568 <stpncpy+0x204>
    23b6:	1a078363          	beqz	a5,255c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23ba:	00050023          	sb	zero,0(a0)
    23be:	4685                	li	a3,1
    23c0:	00150713          	addi	a4,a0,1
    23c4:	18d78f63          	beq	a5,a3,2562 <stpncpy+0x1fe>
    23c8:	000500a3          	sb	zero,1(a0)
    23cc:	4689                	li	a3,2
    23ce:	00250713          	addi	a4,a0,2
    23d2:	18d78e63          	beq	a5,a3,256e <stpncpy+0x20a>
    23d6:	00050123          	sb	zero,2(a0)
    23da:	468d                	li	a3,3
    23dc:	00350713          	addi	a4,a0,3
    23e0:	16d78c63          	beq	a5,a3,2558 <stpncpy+0x1f4>
    23e4:	000501a3          	sb	zero,3(a0)
    23e8:	4691                	li	a3,4
    23ea:	00450713          	addi	a4,a0,4
    23ee:	18d78263          	beq	a5,a3,2572 <stpncpy+0x20e>
    23f2:	00050223          	sb	zero,4(a0)
    23f6:	4695                	li	a3,5
    23f8:	00550713          	addi	a4,a0,5
    23fc:	16d78d63          	beq	a5,a3,2576 <stpncpy+0x212>
    2400:	000502a3          	sb	zero,5(a0)
    2404:	469d                	li	a3,7
    2406:	00650713          	addi	a4,a0,6
    240a:	16d79863          	bne	a5,a3,257a <stpncpy+0x216>
    240e:	00750713          	addi	a4,a0,7
    2412:	00050323          	sb	zero,6(a0)
    2416:	40f80833          	sub	a6,a6,a5
    241a:	ff887593          	andi	a1,a6,-8
    241e:	97aa                	add	a5,a5,a0
    2420:	95be                	add	a1,a1,a5
    2422:	0007b023          	sd	zero,0(a5)
    2426:	07a1                	addi	a5,a5,8
    2428:	feb79de3          	bne	a5,a1,2422 <stpncpy+0xbe>
    242c:	ff887593          	andi	a1,a6,-8
    2430:	9ead                	addw	a3,a3,a1
    2432:	00b707b3          	add	a5,a4,a1
    2436:	12b80863          	beq	a6,a1,2566 <stpncpy+0x202>
    243a:	00078023          	sb	zero,0(a5)
    243e:	0016871b          	addiw	a4,a3,1
    2442:	0ec77863          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    2446:	000780a3          	sb	zero,1(a5)
    244a:	0026871b          	addiw	a4,a3,2
    244e:	0ec77263          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    2452:	00078123          	sb	zero,2(a5)
    2456:	0036871b          	addiw	a4,a3,3
    245a:	0cc77c63          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    245e:	000781a3          	sb	zero,3(a5)
    2462:	0046871b          	addiw	a4,a3,4
    2466:	0cc77663          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    246a:	00078223          	sb	zero,4(a5)
    246e:	0056871b          	addiw	a4,a3,5
    2472:	0cc77063          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    2476:	000782a3          	sb	zero,5(a5)
    247a:	0066871b          	addiw	a4,a3,6
    247e:	0ac77a63          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    2482:	00078323          	sb	zero,6(a5)
    2486:	0076871b          	addiw	a4,a3,7
    248a:	0ac77463          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    248e:	000783a3          	sb	zero,7(a5)
    2492:	0086871b          	addiw	a4,a3,8
    2496:	08c77e63          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    249a:	00078423          	sb	zero,8(a5)
    249e:	0096871b          	addiw	a4,a3,9
    24a2:	08c77863          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    24a6:	000784a3          	sb	zero,9(a5)
    24aa:	00a6871b          	addiw	a4,a3,10
    24ae:	08c77263          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    24b2:	00078523          	sb	zero,10(a5)
    24b6:	00b6871b          	addiw	a4,a3,11
    24ba:	06c77c63          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    24be:	000785a3          	sb	zero,11(a5)
    24c2:	00c6871b          	addiw	a4,a3,12
    24c6:	06c77663          	bgeu	a4,a2,2532 <stpncpy+0x1ce>
    24ca:	00078623          	sb	zero,12(a5)
    24ce:	26b5                	addiw	a3,a3,13
    24d0:	06c6f163          	bgeu	a3,a2,2532 <stpncpy+0x1ce>
    24d4:	000786a3          	sb	zero,13(a5)
    24d8:	8082                	ret
			;
		if (!n || !*s)
    24da:	c645                	beqz	a2,2582 <stpncpy+0x21e>
    24dc:	0005c783          	lbu	a5,0(a1)
    24e0:	ea078be3          	beqz	a5,2396 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24e4:	479d                	li	a5,7
    24e6:	02c7ff63          	bgeu	a5,a2,2524 <stpncpy+0x1c0>
    24ea:	00000897          	auipc	a7,0x0
    24ee:	6b68b883          	ld	a7,1718(a7) # 2ba0 <enable_deadlock_detect+0x224>
    24f2:	00000817          	auipc	a6,0x0
    24f6:	6b683803          	ld	a6,1718(a6) # 2ba8 <enable_deadlock_detect+0x22c>
    24fa:	431d                	li	t1,7
    24fc:	6198                	ld	a4,0(a1)
    24fe:	011707b3          	add	a5,a4,a7
    2502:	fff74693          	not	a3,a4
    2506:	8ff5                	and	a5,a5,a3
    2508:	0107f7b3          	and	a5,a5,a6
    250c:	ef81                	bnez	a5,2524 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    250e:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2510:	1661                	addi	a2,a2,-8
    2512:	05a1                	addi	a1,a1,8
    2514:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2516:	fec363e3          	bltu	t1,a2,24fc <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    251a:	e609                	bnez	a2,2524 <stpncpy+0x1c0>
    251c:	a08d                	j	257e <stpncpy+0x21a>
    251e:	167d                	addi	a2,a2,-1
    2520:	0505                	addi	a0,a0,1
    2522:	ca01                	beqz	a2,2532 <stpncpy+0x1ce>
    2524:	0005c783          	lbu	a5,0(a1)
    2528:	0585                	addi	a1,a1,1
    252a:	00f50023          	sb	a5,0(a0)
    252e:	fbe5                	bnez	a5,251e <stpncpy+0x1ba>
		;
tail:
    2530:	b59d                	j	2396 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2532:	8082                	ret
    2534:	472d                	li	a4,11
    2536:	bdb5                	j	23b2 <stpncpy+0x4e>
    2538:	00778713          	addi	a4,a5,7
    253c:	45ad                	li	a1,11
    253e:	fff60693          	addi	a3,a2,-1
    2542:	e6b778e3          	bgeu	a4,a1,23b2 <stpncpy+0x4e>
    2546:	b7fd                	j	2534 <stpncpy+0x1d0>
    2548:	40a007b3          	neg	a5,a0
    254c:	8832                	mv	a6,a2
    254e:	8b9d                	andi	a5,a5,7
    2550:	4681                	li	a3,0
    2552:	e4060be3          	beqz	a2,23a8 <stpncpy+0x44>
    2556:	b7cd                	j	2538 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2558:	468d                	li	a3,3
    255a:	bd75                	j	2416 <stpncpy+0xb2>
    255c:	872a                	mv	a4,a0
    255e:	4681                	li	a3,0
    2560:	bd5d                	j	2416 <stpncpy+0xb2>
    2562:	4685                	li	a3,1
    2564:	bd4d                	j	2416 <stpncpy+0xb2>
    2566:	8082                	ret
    2568:	87aa                	mv	a5,a0
    256a:	4681                	li	a3,0
    256c:	b5f9                	j	243a <stpncpy+0xd6>
    256e:	4689                	li	a3,2
    2570:	b55d                	j	2416 <stpncpy+0xb2>
    2572:	4691                	li	a3,4
    2574:	b54d                	j	2416 <stpncpy+0xb2>
    2576:	4695                	li	a3,5
    2578:	bd79                	j	2416 <stpncpy+0xb2>
    257a:	4699                	li	a3,6
    257c:	bd69                	j	2416 <stpncpy+0xb2>
    257e:	8082                	ret
    2580:	8082                	ret
    2582:	8082                	ret

0000000000002584 <basename>:

char *basename(char *s)
{
    2584:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2586:	c54d                	beqz	a0,2630 <basename+0xac>
    2588:	00054783          	lbu	a5,0(a0)
		return ".";
    258c:	00000517          	auipc	a0,0x0
    2590:	60c50513          	addi	a0,a0,1548 # 2b98 <enable_deadlock_detect+0x21c>
	if (!s || !*s)
    2594:	e391                	bnez	a5,2598 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2596:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2598:	0076f713          	andi	a4,a3,7
    259c:	87b6                	mv	a5,a3
    259e:	cf51                	beqz	a4,263a <basename+0xb6>
    25a0:	0785                	addi	a5,a5,1
    25a2:	0077f713          	andi	a4,a5,7
    25a6:	c729                	beqz	a4,25f0 <basename+0x6c>
		if (!*s)
    25a8:	0007c703          	lbu	a4,0(a5)
    25ac:	fb75                	bnez	a4,25a0 <basename+0x1c>
	return s - a;
    25ae:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25b0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25b2:	cf8d                	beqz	a5,25ec <basename+0x68>
    25b4:	00f68733          	add	a4,a3,a5
    25b8:	02f00593          	li	a1,47
    25bc:	a031                	j	25c8 <basename+0x44>
		s[i] = 0;
    25be:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25c2:	17fd                	addi	a5,a5,-1
    25c4:	177d                	addi	a4,a4,-1
    25c6:	c39d                	beqz	a5,25ec <basename+0x68>
    25c8:	00074603          	lbu	a2,0(a4)
    25cc:	feb609e3          	beq	a2,a1,25be <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25d0:	02f00613          	li	a2,47
    25d4:	a011                	j	25d8 <basename+0x54>
    25d6:	cb99                	beqz	a5,25ec <basename+0x68>
    25d8:	853e                	mv	a0,a5
    25da:	17fd                	addi	a5,a5,-1
    25dc:	00f68733          	add	a4,a3,a5
    25e0:	00074703          	lbu	a4,0(a4)
    25e4:	fec719e3          	bne	a4,a2,25d6 <basename+0x52>
	return s + i;
    25e8:	9536                	add	a0,a0,a3
    25ea:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    25ec:	8536                	mv	a0,a3
    25ee:	8082                	ret
    25f0:	6390                	ld	a2,0(a5)
    25f2:	00000517          	auipc	a0,0x0
    25f6:	5ae53503          	ld	a0,1454(a0) # 2ba0 <enable_deadlock_detect+0x224>
    25fa:	00000597          	auipc	a1,0x0
    25fe:	5ae5b583          	ld	a1,1454(a1) # 2ba8 <enable_deadlock_detect+0x22c>
    2602:	fff64713          	not	a4,a2
    2606:	962a                	add	a2,a2,a0
    2608:	8f71                	and	a4,a4,a2
    260a:	8f6d                	and	a4,a4,a1
    260c:	eb11                	bnez	a4,2620 <basename+0x9c>
    260e:	6790                	ld	a2,8(a5)
    2610:	07a1                	addi	a5,a5,8
    2612:	00a60733          	add	a4,a2,a0
    2616:	fff64613          	not	a2,a2
    261a:	8f71                	and	a4,a4,a2
    261c:	8f6d                	and	a4,a4,a1
    261e:	db65                	beqz	a4,260e <basename+0x8a>
	for (; *s; s++)
    2620:	0007c703          	lbu	a4,0(a5)
    2624:	d749                	beqz	a4,25ae <basename+0x2a>
    2626:	0017c703          	lbu	a4,1(a5)
    262a:	0785                	addi	a5,a5,1
    262c:	ff6d                	bnez	a4,2626 <basename+0xa2>
    262e:	b741                	j	25ae <basename+0x2a>
		return ".";
    2630:	00000517          	auipc	a0,0x0
    2634:	56850513          	addi	a0,a0,1384 # 2b98 <enable_deadlock_detect+0x21c>
    2638:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    263a:	6290                	ld	a2,0(a3)
    263c:	00000517          	auipc	a0,0x0
    2640:	56453503          	ld	a0,1380(a0) # 2ba0 <enable_deadlock_detect+0x224>
    2644:	00000597          	auipc	a1,0x0
    2648:	5645b583          	ld	a1,1380(a1) # 2ba8 <enable_deadlock_detect+0x22c>
    264c:	fff64713          	not	a4,a2
    2650:	962a                	add	a2,a2,a0
    2652:	8f71                	and	a4,a4,a2
    2654:	8f6d                	and	a4,a4,a1
    2656:	df45                	beqz	a4,260e <basename+0x8a>
    2658:	b7f9                	j	2626 <basename+0xa2>

000000000000265a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    265a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    265e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2660:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2664:	2501                	sext.w	a0,a0
    2666:	8082                	ret

0000000000002668 <close>:

int close(int fd)
{
	if (fd == 1) {
    2668:	4785                	li	a5,1
    266a:	00f50863          	beq	a0,a5,267a <close+0x12>
	register long a7 __asm__("a7") = n;
    266e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2672:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2676:	2501                	sext.w	a0,a0
    2678:	8082                	ret
{
    267a:	1101                	addi	sp,sp,-32
    267c:	ec06                	sd	ra,24(sp)
    267e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2680:	cdffe0ef          	jal	ra,135e <__write_buffer>
		__clear_buffer();
    2684:	d03fe0ef          	jal	ra,1386 <__clear_buffer>
    2688:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    268a:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    268e:	00000073          	ecall
}
    2692:	60e2                	ld	ra,24(sp)
    2694:	2501                	sext.w	a0,a0
    2696:	6105                	addi	sp,sp,32
    2698:	8082                	ret

000000000000269a <read>:
	register long a7 __asm__("a7") = n;
    269a:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    269e:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    26a2:	8082                	ret

00000000000026a4 <write>:
	register long a7 __asm__("a7") = n;
    26a4:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26a8:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    26ac:	8082                	ret

00000000000026ae <getpid>:
	register long a7 __asm__("a7") = n;
    26ae:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    26b2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    26b6:	2501                	sext.w	a0,a0
    26b8:	8082                	ret

00000000000026ba <getppid>:
	register long a7 __asm__("a7") = n;
    26ba:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    26be:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    26c2:	2501                	sext.w	a0,a0
    26c4:	8082                	ret

00000000000026c6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    26c6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26ca:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    26ce:	2501                	sext.w	a0,a0
    26d0:	8082                	ret

00000000000026d2 <fork>:
	register long a7 __asm__("a7") = n;
    26d2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    26d6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    26da:	2501                	sext.w	a0,a0
    26dc:	8082                	ret

00000000000026de <exit>:

void exit(int code)
{
    26de:	1141                	addi	sp,sp,-16
    26e0:	e406                	sd	ra,8(sp)
    26e2:	e022                	sd	s0,0(sp)
    26e4:	842a                	mv	s0,a0
	__write_buffer();
    26e6:	c79fe0ef          	jal	ra,135e <__write_buffer>
	__clear_buffer();
    26ea:	c9dfe0ef          	jal	ra,1386 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    26ee:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    26f2:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    26f4:	00000073          	ecall
	syscall(SYS_exit, code);
}
    26f8:	60a2                	ld	ra,8(sp)
    26fa:	6402                	ld	s0,0(sp)
    26fc:	0141                	addi	sp,sp,16
    26fe:	8082                	ret

0000000000002700 <waitpid>:
	register long a7 __asm__("a7") = n;
    2700:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2704:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <exec>:
	register long a7 __asm__("a7") = n;
    270c:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2710:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <get_mtime>:

int64 get_mtime()
{
    2718:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    271a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    271e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2720:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2722:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2726:	2501                	sext.w	a0,a0
    2728:	ed01                	bnez	a0,2740 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    272a:	6722                	ld	a4,8(sp)
    272c:	3e800793          	li	a5,1000
    2730:	6682                	ld	a3,0(sp)
    2732:	02f75733          	divu	a4,a4,a5
    2736:	02d78533          	mul	a0,a5,a3
    273a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    273c:	0141                	addi	sp,sp,16
    273e:	8082                	ret
	return -1;
    2740:	557d                	li	a0,-1
    2742:	bfed                	j	273c <get_mtime+0x24>

0000000000002744 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2744:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2748:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    274c:	2501                	sext.w	a0,a0
    274e:	8082                	ret

0000000000002750 <sleep>:

int sleep(unsigned long long time)
{
    2750:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2752:	880a                	mv	a6,sp
{
    2754:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2756:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    275a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    275c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    275e:	00000073          	ecall
	if (err == 0) {
    2762:	2501                	sext.w	a0,a0
    2764:	ed31                	bnez	a0,27c0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2766:	6722                	ld	a4,8(sp)
    2768:	3e800793          	li	a5,1000
    276c:	6682                	ld	a3,0(sp)
    276e:	02f75733          	divu	a4,a4,a5
    2772:	02d787b3          	mul	a5,a5,a3
    2776:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2778:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    277c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    277e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2780:	00000073          	ecall
	if (err == 0) {
    2784:	2501                	sext.w	a0,a0
    2786:	e915                	bnez	a0,27ba <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2788:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    278a:	3e800693          	li	a3,1000
    278e:	a819                	j	27a4 <sleep+0x54>
	__asm_syscall("r"(a7))
    2790:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2794:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2798:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    279a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    279c:	00000073          	ecall
	if (err == 0) {
    27a0:	2501                	sext.w	a0,a0
    27a2:	ed01                	bnez	a0,27ba <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    27a4:	6722                	ld	a4,8(sp)
    27a6:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    27a8:	07c00893          	li	a7,124
    27ac:	02d75733          	divu	a4,a4,a3
    27b0:	02f687b3          	mul	a5,a3,a5
    27b4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    27b6:	fcc7ede3          	bltu	a5,a2,2790 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    27ba:	4501                	li	a0,0
    27bc:	0141                	addi	sp,sp,16
    27be:	8082                	ret
    27c0:	57fd                	li	a5,-1
    27c2:	bf5d                	j	2778 <sleep+0x28>

00000000000027c4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    27c4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    27c8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    27cc:	2501                	sext.w	a0,a0
    27ce:	8082                	ret

00000000000027d0 <set_priority>:
	register long a7 __asm__("a7") = n;
    27d0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    27d4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    27d8:	2501                	sext.w	a0,a0
    27da:	8082                	ret

00000000000027dc <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    27dc:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27e0:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    27e4:	2501                	sext.w	a0,a0
    27e6:	8082                	ret

00000000000027e8 <munmap>:
	register long a7 __asm__("a7") = n;
    27e8:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ec:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    27f0:	2501                	sext.w	a0,a0
    27f2:	8082                	ret

00000000000027f4 <wait>:

int wait(int *code)
{
    27f4:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27f6:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    27fa:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27fc:	00000073          	ecall
	return waitpid(-1, code);
}
    2800:	2501                	sext.w	a0,a0
    2802:	8082                	ret

0000000000002804 <spawn>:
	register long a7 __asm__("a7") = n;
    2804:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2808:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    280c:	2501                	sext.w	a0,a0
    280e:	8082                	ret

0000000000002810 <pipe>:
	register long a7 __asm__("a7") = n;
    2810:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2814:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2818:	2501                	sext.w	a0,a0
    281a:	8082                	ret

000000000000281c <mailread>:
	register long a7 __asm__("a7") = n;
    281c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2820:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2824:	2501                	sext.w	a0,a0
    2826:	8082                	ret

0000000000002828 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2828:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    282c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2830:	2501                	sext.w	a0,a0
    2832:	8082                	ret

0000000000002834 <fstat>:
	register long a7 __asm__("a7") = n;
    2834:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2838:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    283c:	2501                	sext.w	a0,a0
    283e:	8082                	ret

0000000000002840 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2840:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2842:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2846:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2848:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    284c:	2501                	sext.w	a0,a0
    284e:	8082                	ret

0000000000002850 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2850:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2852:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2856:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2858:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    285c:	2501                	sext.w	a0,a0
    285e:	8082                	ret

0000000000002860 <link>:

int link(char *old_path, char *new_path)
{
    2860:	87aa                	mv	a5,a0
    2862:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2864:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2868:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    286c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    286e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2872:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2874:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2878:	2501                	sext.w	a0,a0
    287a:	8082                	ret

000000000000287c <unlink>:

int unlink(char *path)
{
    287c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    287e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2882:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2886:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2888:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    288c:	2501                	sext.w	a0,a0
    288e:	8082                	ret

0000000000002890 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2890:	00000797          	auipc	a5,0x0
    2894:	6507b783          	ld	a5,1616(a5) # 2ee0 <_GLOBAL_OFFSET_TABLE_+0x8>
    2898:	439c                	lw	a5,0(a5)
    289a:	c799                	beqz	a5,28a8 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    289c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28a0:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    28a4:	2501                	sext.w	a0,a0
    28a6:	8082                	ret
{
    28a8:	1101                	addi	sp,sp,-32
    28aa:	ec06                	sd	ra,24(sp)
    28ac:	e42e                	sd	a1,8(sp)
    28ae:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    28b0:	fe7fe0ef          	jal	ra,1896 <enable_thread_io_buffer>
    28b4:	65a2                	ld	a1,8(sp)
    28b6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    28b8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28bc:	00000073          	ecall
}
    28c0:	60e2                	ld	ra,24(sp)
    28c2:	2501                	sext.w	a0,a0
    28c4:	6105                	addi	sp,sp,32
    28c6:	8082                	ret

00000000000028c8 <gettid>:
	register long a7 __asm__("a7") = n;
    28c8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    28cc:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    28d0:	2501                	sext.w	a0,a0
    28d2:	8082                	ret

00000000000028d4 <waittid>:

int waittid(int tid)
{
    28d4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    28d6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    28da:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    28de:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    28e0:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28e2:	00e51e63          	bne	a0,a4,28fe <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    28e6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    28ea:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    28ee:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    28f2:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    28f4:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    28f8:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28fa:	fee506e3          	beq	a0,a4,28e6 <waittid+0x12>
	}
	return ret;
}
    28fe:	8082                	ret

0000000000002900 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2900:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2904:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2906:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    290a:	2501                	sext.w	a0,a0
    290c:	8082                	ret

000000000000290e <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    290e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2912:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2914:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2918:	2501                	sext.w	a0,a0
    291a:	8082                	ret

000000000000291c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    291c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2920:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2924:	2501                	sext.w	a0,a0
    2926:	8082                	ret

0000000000002928 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2928:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    292c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2930:	2501                	sext.w	a0,a0
    2932:	8082                	ret

0000000000002934 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2934:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2938:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    293c:	2501                	sext.w	a0,a0
    293e:	8082                	ret

0000000000002940 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2940:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2944:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2948:	2501                	sext.w	a0,a0
    294a:	8082                	ret

000000000000294c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    294c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2950:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2954:	2501                	sext.w	a0,a0
    2956:	8082                	ret

0000000000002958 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2958:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    295c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2960:	2501                	sext.w	a0,a0
    2962:	8082                	ret

0000000000002964 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2964:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2968:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    296c:	2501                	sext.w	a0,a0
    296e:	8082                	ret

0000000000002970 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2970:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2974:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2978:	2501                	sext.w	a0,a0
    297a:	8082                	ret

000000000000297c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    297c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2980:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2984:	2501                	sext.w	a0,a0
    2986:	8082                	ret
