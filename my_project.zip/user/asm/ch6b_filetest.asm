
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_filetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a0d1                	j	10c4 <__start_main>

0000000000001002 <main>:
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main()
{
    1002:	7179                	addi	sp,sp,-48
	int exit_code;
	int fd = open("test\0", O_CREATE | O_WRONLY);
    1004:	20100593          	li	a1,513
    1008:	00002517          	auipc	a0,0x2
    100c:	98850513          	addi	a0,a0,-1656 # 2990 <buffer_lock+0x4>
{
    1010:	f406                	sd	ra,40(sp)
    1012:	f022                	sd	s0,32(sp)
    1014:	ec26                	sd	s1,24(sp)
	int fd = open("test\0", O_CREATE | O_WRONLY);
    1016:	3e6010ef          	jal	ra,23fc <open>
	printf("open OK, fd = %d\n", fd);
    101a:	85aa                	mv	a1,a0
	int fd = open("test\0", O_CREATE | O_WRONLY);
    101c:	842a                	mv	s0,a0
	printf("open OK, fd = %d\n", fd);
    101e:	00001517          	auipc	a0,0x1
    1022:	71250513          	addi	a0,a0,1810 # 2730 <enable_deadlock_detect+0x12>
    1026:	1f8000ef          	jal	ra,121e <printf>
	char *str = "hello world!\0";
	int len = strlen(str);
    102a:	00002517          	auipc	a0,0x2
    102e:	96e50513          	addi	a0,a0,-1682 # 2998 <buffer_lock+0xc>
    1032:	74f000ef          	jal	ra,1f80 <strlen>
	write(fd, str, len);
    1036:	0005049b          	sext.w	s1,a0
    103a:	8626                	mv	a2,s1
    103c:	00002597          	auipc	a1,0x2
    1040:	95c58593          	addi	a1,a1,-1700 # 2998 <buffer_lock+0xc>
    1044:	8522                	mv	a0,s0
    1046:	400010ef          	jal	ra,2446 <write>
	close(fd);
    104a:	8522                	mv	a0,s0
    104c:	3be010ef          	jal	ra,240a <close>
	puts("write over.");
    1050:	00001517          	auipc	a0,0x1
    1054:	6f850513          	addi	a0,a0,1784 # 2748 <enable_deadlock_detect+0x2a>
    1058:	0dd000ef          	jal	ra,1934 <puts>
	int pid = fork();
    105c:	418010ef          	jal	ra,2474 <fork>
	if (pid == 0) {
    1060:	c105                	beqz	a0,1080 <main+0x7e>
		puts(str);
		puts("read over.");
		close(fd);
		exit(0);
	}
	wait(&exit_code);
    1062:	0068                	addi	a0,sp,12
    1064:	532010ef          	jal	ra,2596 <wait>
	puts("filetest passed.");
    1068:	00001517          	auipc	a0,0x1
    106c:	70050513          	addi	a0,a0,1792 # 2768 <enable_deadlock_detect+0x4a>
    1070:	0c5000ef          	jal	ra,1934 <puts>
	return 0;
}
    1074:	70a2                	ld	ra,40(sp)
    1076:	7402                	ld	s0,32(sp)
    1078:	64e2                	ld	s1,24(sp)
    107a:	4501                	li	a0,0
    107c:	6145                	addi	sp,sp,48
    107e:	8082                	ret
		int fd = open("test\0", O_RDONLY);
    1080:	4581                	li	a1,0
    1082:	00002517          	auipc	a0,0x2
    1086:	90e50513          	addi	a0,a0,-1778 # 2990 <buffer_lock+0x4>
    108a:	372010ef          	jal	ra,23fc <open>
		str[read(fd, str, len)] = 0;
    108e:	8626                	mv	a2,s1
    1090:	00002597          	auipc	a1,0x2
    1094:	90858593          	addi	a1,a1,-1784 # 2998 <buffer_lock+0xc>
		int fd = open("test\0", O_RDONLY);
    1098:	842a                	mv	s0,a0
		str[read(fd, str, len)] = 0;
    109a:	3a2010ef          	jal	ra,243c <read>
		puts(str);
    109e:	00002517          	auipc	a0,0x2
    10a2:	8fa50513          	addi	a0,a0,-1798 # 2998 <buffer_lock+0xc>
    10a6:	08f000ef          	jal	ra,1934 <puts>
		puts("read over.");
    10aa:	00001517          	auipc	a0,0x1
    10ae:	6ae50513          	addi	a0,a0,1710 # 2758 <enable_deadlock_detect+0x3a>
    10b2:	083000ef          	jal	ra,1934 <puts>
		close(fd);
    10b6:	8522                	mv	a0,s0
    10b8:	352010ef          	jal	ra,240a <close>
		exit(0);
    10bc:	4501                	li	a0,0
    10be:	3c2010ef          	jal	ra,2480 <exit>
    10c2:	b745                	j	1062 <main+0x60>

00000000000010c4 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    10c4:	1141                	addi	sp,sp,-16
    10c6:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    10c8:	f3bff0ef          	jal	ra,1002 <main>
    10cc:	3b4010ef          	jal	ra,2480 <exit>
	return 0;
    10d0:	60a2                	ld	ra,8(sp)
    10d2:	4501                	li	a0,0
    10d4:	0141                	addi	sp,sp,16
    10d6:	8082                	ret

00000000000010d8 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    10d8:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    10da:	4605                	li	a2,1
    10dc:	00f10593          	addi	a1,sp,15
    10e0:	4501                	li	a0,0
{
    10e2:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10e4:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10e8:	354010ef          	jal	ra,243c <read>
    10ec:	4785                	li	a5,1
    10ee:	00f51763          	bne	a0,a5,10fc <getchar+0x24>
		return byte;
    10f2:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10f6:	60e2                	ld	ra,24(sp)
    10f8:	6105                	addi	sp,sp,32
    10fa:	8082                	ret
		return EOF;
    10fc:	557d                	li	a0,-1
    10fe:	bfe5                	j	10f6 <getchar+0x1e>

0000000000001100 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1100:	00001517          	auipc	a0,0x1
    1104:	78052503          	lw	a0,1920(a0) # 2880 <buffer_len>
    1108:	e111                	bnez	a0,110c <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    110a:	8082                	ret
{
    110c:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    110e:	862a                	mv	a2,a0
    1110:	00001597          	auipc	a1,0x1
    1114:	77858593          	addi	a1,a1,1912 # 2888 <buffer>
    1118:	4505                	li	a0,1
{
    111a:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    111c:	32a010ef          	jal	ra,2446 <write>
}
    1120:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1122:	2501                	sext.w	a0,a0
}
    1124:	0141                	addi	sp,sp,16
    1126:	8082                	ret

0000000000001128 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1128:	00001797          	auipc	a5,0x1
    112c:	7407ac23          	sw	zero,1880(a5) # 2880 <buffer_len>
}
    1130:	8082                	ret

0000000000001132 <__fflush>:
	if (buffer_len == 0)
    1132:	00001517          	auipc	a0,0x1
    1136:	74e52503          	lw	a0,1870(a0) # 2880 <buffer_len>
    113a:	e511                	bnez	a0,1146 <__fflush+0x14>
	buffer_len = 0;
    113c:	00001797          	auipc	a5,0x1
    1140:	7407a223          	sw	zero,1860(a5) # 2880 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1144:	8082                	ret
{
    1146:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1148:	862a                	mv	a2,a0
    114a:	00001597          	auipc	a1,0x1
    114e:	73e58593          	addi	a1,a1,1854 # 2888 <buffer>
    1152:	4505                	li	a0,1
{
    1154:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1156:	2f0010ef          	jal	ra,2446 <write>
	return r >= 0 ? 0 : r;
    115a:	0005079b          	sext.w	a5,a0
}
    115e:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1160:	0017a793          	slti	a5,a5,1
    1164:	40f007bb          	negw	a5,a5
    1168:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    116a:	00001797          	auipc	a5,0x1
    116e:	7007ab23          	sw	zero,1814(a5) # 2880 <buffer_len>
	return r >= 0 ? 0 : r;
    1172:	2501                	sext.w	a0,a0
}
    1174:	0141                	addi	sp,sp,16
    1176:	8082                	ret

0000000000001178 <fflush>:

int fflush(int fd)
{
    1178:	1101                	addi	sp,sp,-32
    117a:	e822                	sd	s0,16(sp)
    117c:	ec06                	sd	ra,24(sp)
    117e:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1180:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1182:	4401                	li	s0,0
	if (fd == 1) {
    1184:	00e50863          	beq	a0,a4,1194 <fflush+0x1c>
}
    1188:	60e2                	ld	ra,24(sp)
    118a:	8522                	mv	a0,s0
    118c:	6442                	ld	s0,16(sp)
    118e:	64a2                	ld	s1,8(sp)
    1190:	6105                	addi	sp,sp,32
    1192:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1194:	00001497          	auipc	s1,0x1
    1198:	6ec48493          	addi	s1,s1,1772 # 2880 <buffer_len>
    119c:	1084a703          	lw	a4,264(s1)
    11a0:	02a70e63          	beq	a4,a0,11dc <fflush+0x64>
	if (buffer_len == 0)
    11a4:	4080                	lw	s0,0(s1)
    11a6:	c00d                	beqz	s0,11c8 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11a8:	8622                	mv	a2,s0
    11aa:	00001597          	auipc	a1,0x1
    11ae:	6de58593          	addi	a1,a1,1758 # 2888 <buffer>
    11b2:	294010ef          	jal	ra,2446 <write>
	return r >= 0 ? 0 : r;
    11b6:	0005079b          	sext.w	a5,a0
    11ba:	0017a793          	slti	a5,a5,1
    11be:	40f007bb          	negw	a5,a5
    11c2:	8d7d                	and	a0,a0,a5
    11c4:	0005041b          	sext.w	s0,a0
}
    11c8:	60e2                	ld	ra,24(sp)
    11ca:	8522                	mv	a0,s0
    11cc:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    11ce:	00001797          	auipc	a5,0x1
    11d2:	6a07a923          	sw	zero,1714(a5) # 2880 <buffer_len>
}
    11d6:	64a2                	ld	s1,8(sp)
    11d8:	6105                	addi	sp,sp,32
    11da:	8082                	ret
			mutex_lock(buffer_lock);
    11dc:	10c4a503          	lw	a0,268(s1)
    11e0:	4de010ef          	jal	ra,26be <mutex_lock>
	if (buffer_len == 0)
    11e4:	4080                	lw	s0,0(s1)
    11e6:	e811                	bnez	s0,11fa <fflush+0x82>
			mutex_unlock(buffer_lock);
    11e8:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11ec:	00001797          	auipc	a5,0x1
    11f0:	6807aa23          	sw	zero,1684(a5) # 2880 <buffer_len>
			mutex_unlock(buffer_lock);
    11f4:	4d6010ef          	jal	ra,26ca <mutex_unlock>
    11f8:	bf41                	j	1188 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11fa:	8622                	mv	a2,s0
    11fc:	00001597          	auipc	a1,0x1
    1200:	68c58593          	addi	a1,a1,1676 # 2888 <buffer>
    1204:	4505                	li	a0,1
    1206:	240010ef          	jal	ra,2446 <write>
	return r >= 0 ? 0 : r;
    120a:	0005079b          	sext.w	a5,a0
    120e:	0017a793          	slti	a5,a5,1
    1212:	40f007bb          	negw	a5,a5
    1216:	8d7d                	and	a0,a0,a5
    1218:	0005041b          	sext.w	s0,a0
	return r;
    121c:	b7f1                	j	11e8 <fflush+0x70>

000000000000121e <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    121e:	7131                	addi	sp,sp,-192
    1220:	e0da                	sd	s6,64(sp)
    1222:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1224:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1226:	013c                	addi	a5,sp,136
{
    1228:	f0ca                	sd	s2,96(sp)
    122a:	ecce                	sd	s3,88(sp)
    122c:	e8d2                	sd	s4,80(sp)
    122e:	e4d6                	sd	s5,72(sp)
    1230:	fc86                	sd	ra,120(sp)
    1232:	f8a2                	sd	s0,112(sp)
    1234:	f4a6                	sd	s1,104(sp)
    1236:	89aa                	mv	s3,a0
    1238:	e52e                	sd	a1,136(sp)
    123a:	e932                	sd	a2,144(sp)
    123c:	ed36                	sd	a3,152(sp)
    123e:	f13a                	sd	a4,160(sp)
    1240:	f942                	sd	a6,176(sp)
    1242:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1244:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1246:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    124a:	00001a17          	auipc	s4,0x1
    124e:	636a0a13          	addi	s4,s4,1590 # 2880 <buffer_len>
    1252:	4a85                	li	s5,1
	buf[i++] = '0';
    1254:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1258:	0009c783          	lbu	a5,0(s3)
    125c:	18078663          	beqz	a5,13e8 <printf+0x1ca>
    1260:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1262:	19278d63          	beq	a5,s2,13fc <printf+0x1de>
    1266:	0015c783          	lbu	a5,1(a1)
    126a:	0585                	addi	a1,a1,1
    126c:	fbfd                	bnez	a5,1262 <printf+0x44>
    126e:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1270:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1274:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1278:	1b578863          	beq	a5,s5,1428 <printf+0x20a>
		len = out_unlocked(s, l);
    127c:	85a2                	mv	a1,s0
    127e:	854e                	mv	a0,s3
    1280:	42a000ef          	jal	ra,16aa <out_unlocked>
		out(f, a, l);
		if (l)
    1284:	1c041063          	bnez	s0,1444 <printf+0x226>
			continue;
		if (s[1] == 0)
    1288:	0014c783          	lbu	a5,1(s1)
    128c:	14078e63          	beqz	a5,13e8 <printf+0x1ca>
			break;
		switch (s[1]) {
    1290:	07300713          	li	a4,115
    1294:	1ce78863          	beq	a5,a4,1464 <printf+0x246>
    1298:	1af76863          	bltu	a4,a5,1448 <printf+0x22a>
    129c:	06400713          	li	a4,100
    12a0:	22e78063          	beq	a5,a4,14c0 <printf+0x2a2>
    12a4:	07000713          	li	a4,112
    12a8:	1ee79563          	bne	a5,a4,1492 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12ac:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12ae:	00001797          	auipc	a5,0x1
    12b2:	6fa78793          	addi	a5,a5,1786 # 29a8 <digits>
	buf[i++] = '0';
    12b6:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12ba:	6298                	ld	a4,0(a3)
    12bc:	06a1                	addi	a3,a3,8
    12be:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    12c0:	00471393          	slli	t2,a4,0x4
    12c4:	00871293          	slli	t0,a4,0x8
    12c8:	00c71f93          	slli	t6,a4,0xc
    12cc:	01071f13          	slli	t5,a4,0x10
    12d0:	01471e93          	slli	t4,a4,0x14
    12d4:	01871e13          	slli	t3,a4,0x18
    12d8:	01c71893          	slli	a7,a4,0x1c
    12dc:	02471813          	slli	a6,a4,0x24
    12e0:	02871513          	slli	a0,a4,0x28
    12e4:	02c71593          	slli	a1,a4,0x2c
    12e8:	03071613          	slli	a2,a4,0x30
    12ec:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12f0:	03c75413          	srli	s0,a4,0x3c
    12f4:	01c7531b          	srliw	t1,a4,0x1c
    12f8:	03c3d393          	srli	t2,t2,0x3c
    12fc:	03c2d293          	srli	t0,t0,0x3c
    1300:	03cfdf93          	srli	t6,t6,0x3c
    1304:	03cf5f13          	srli	t5,t5,0x3c
    1308:	03cede93          	srli	t4,t4,0x3c
    130c:	03ce5e13          	srli	t3,t3,0x3c
    1310:	03c8d893          	srli	a7,a7,0x3c
    1314:	03c85813          	srli	a6,a6,0x3c
    1318:	9171                	srli	a0,a0,0x3c
    131a:	91f1                	srli	a1,a1,0x3c
    131c:	9271                	srli	a2,a2,0x3c
    131e:	92f1                	srli	a3,a3,0x3c
    1320:	95be                	add	a1,a1,a5
    1322:	963e                	add	a2,a2,a5
    1324:	96be                	add	a3,a3,a5
    1326:	943e                	add	s0,s0,a5
    1328:	93be                	add	t2,t2,a5
    132a:	92be                	add	t0,t0,a5
    132c:	9fbe                	add	t6,t6,a5
    132e:	9f3e                	add	t5,t5,a5
    1330:	9ebe                	add	t4,t4,a5
    1332:	9e3e                	add	t3,t3,a5
    1334:	98be                	add	a7,a7,a5
    1336:	933e                	add	t1,t1,a5
    1338:	983e                	add	a6,a6,a5
    133a:	953e                	add	a0,a0,a5
    133c:	0005c983          	lbu	s3,0(a1)
    1340:	00044403          	lbu	s0,0(s0)
    1344:	00064583          	lbu	a1,0(a2)
    1348:	0003c383          	lbu	t2,0(t2)
    134c:	0006c603          	lbu	a2,0(a3)
    1350:	0002c283          	lbu	t0,0(t0)
    1354:	000fcf83          	lbu	t6,0(t6)
    1358:	000f4f03          	lbu	t5,0(t5)
    135c:	000ece83          	lbu	t4,0(t4)
    1360:	000e4e03          	lbu	t3,0(t3)
    1364:	0008c883          	lbu	a7,0(a7)
    1368:	00034303          	lbu	t1,0(t1)
    136c:	00084803          	lbu	a6,0(a6)
    1370:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1374:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1378:	92f1                	srli	a3,a3,0x3c
    137a:	8b3d                	andi	a4,a4,15
    137c:	96be                	add	a3,a3,a5
    137e:	97ba                	add	a5,a5,a4
    1380:	00810d23          	sb	s0,26(sp)
    1384:	00710da3          	sb	t2,27(sp)
    1388:	00510e23          	sb	t0,28(sp)
    138c:	01f10ea3          	sb	t6,29(sp)
    1390:	01e10f23          	sb	t5,30(sp)
    1394:	01d10fa3          	sb	t4,31(sp)
    1398:	03c10023          	sb	t3,32(sp)
    139c:	031100a3          	sb	a7,33(sp)
    13a0:	02610123          	sb	t1,34(sp)
    13a4:	030101a3          	sb	a6,35(sp)
    13a8:	02a10223          	sb	a0,36(sp)
    13ac:	033102a3          	sb	s3,37(sp)
    13b0:	02b10323          	sb	a1,38(sp)
    13b4:	02c103a3          	sb	a2,39(sp)
    13b8:	0006c683          	lbu	a3,0(a3)
    13bc:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    13c0:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13c4:	02d10423          	sb	a3,40(sp)
    13c8:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    13cc:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    13d0:	11578263          	beq	a5,s5,14d4 <printf+0x2b6>
		len = out_unlocked(s, l);
    13d4:	45c9                	li	a1,18
    13d6:	0828                	addi	a0,sp,24
    13d8:	2d2000ef          	jal	ra,16aa <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13dc:	00248993          	addi	s3,s1,2
		if (!*s)
    13e0:	0009c783          	lbu	a5,0(s3)
    13e4:	e6079ee3          	bnez	a5,1260 <printf+0x42>
	}
	va_end(ap);
    13e8:	70e6                	ld	ra,120(sp)
    13ea:	7446                	ld	s0,112(sp)
    13ec:	74a6                	ld	s1,104(sp)
    13ee:	7906                	ld	s2,96(sp)
    13f0:	69e6                	ld	s3,88(sp)
    13f2:	6a46                	ld	s4,80(sp)
    13f4:	6aa6                	ld	s5,72(sp)
    13f6:	6b06                	ld	s6,64(sp)
    13f8:	6129                	addi	sp,sp,192
    13fa:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13fc:	0005c783          	lbu	a5,0(a1)
    1400:	84ae                	mv	s1,a1
    1402:	01278963          	beq	a5,s2,1414 <printf+0x1f6>
    1406:	b5ad                	j	1270 <printf+0x52>
    1408:	0024c783          	lbu	a5,2(s1)
    140c:	0585                	addi	a1,a1,1
    140e:	0489                	addi	s1,s1,2
    1410:	e72790e3          	bne	a5,s2,1270 <printf+0x52>
    1414:	0014c783          	lbu	a5,1(s1)
    1418:	ff2788e3          	beq	a5,s2,1408 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    141c:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1420:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1424:	e5579ce3          	bne	a5,s5,127c <printf+0x5e>
		mutex_lock(buffer_lock);
    1428:	10ca2503          	lw	a0,268(s4)
    142c:	292010ef          	jal	ra,26be <mutex_lock>
		len = out_unlocked(s, l);
    1430:	85a2                	mv	a1,s0
    1432:	854e                	mv	a0,s3
    1434:	276000ef          	jal	ra,16aa <out_unlocked>
		mutex_unlock(buffer_lock);
    1438:	10ca2503          	lw	a0,268(s4)
    143c:	28e010ef          	jal	ra,26ca <mutex_unlock>
		if (l)
    1440:	e40404e3          	beqz	s0,1288 <printf+0x6a>
    1444:	89a6                	mv	s3,s1
    1446:	bd09                	j	1258 <printf+0x3a>
		switch (s[1]) {
    1448:	07800713          	li	a4,120
    144c:	04e79363          	bne	a5,a4,1492 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1450:	67c2                	ld	a5,16(sp)
    1452:	45c1                	li	a1,16
		s += 2;
    1454:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1458:	4388                	lw	a0,0(a5)
    145a:	07a1                	addi	a5,a5,8
    145c:	e83e                	sd	a5,16(sp)
    145e:	5f8000ef          	jal	ra,1a56 <printint.constprop.0>
		s += 2;
    1462:	bfbd                	j	13e0 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1464:	67c2                	ld	a5,16(sp)
    1466:	6380                	ld	s0,0(a5)
    1468:	07a1                	addi	a5,a5,8
    146a:	e83e                	sd	a5,16(sp)
    146c:	1c040163          	beqz	s0,162e <printf+0x410>
			l = strnlen(a, 200);
    1470:	0c800593          	li	a1,200
    1474:	8522                	mv	a0,s0
    1476:	3f7000ef          	jal	ra,206c <strnlen>
	if (buffer_lock_enabled == 1) {
    147a:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    147e:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1482:	19578663          	beq	a5,s5,160e <printf+0x3f0>
		len = out_unlocked(s, l);
    1486:	8522                	mv	a0,s0
    1488:	222000ef          	jal	ra,16aa <out_unlocked>
		s += 2;
    148c:	00248993          	addi	s3,s1,2
    1490:	bf81                	j	13e0 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1492:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1496:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    149a:	0f578663          	beq	a5,s5,1586 <printf+0x368>
		len = out_unlocked(s, l);
    149e:	0828                	addi	a0,sp,24
    14a0:	316000ef          	jal	ra,17b6 <out_unlocked.constprop.0>
			putchar(s[1]);
    14a4:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14a8:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14ac:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14b0:	05578163          	beq	a5,s5,14f2 <printf+0x2d4>
		len = out_unlocked(s, l);
    14b4:	0828                	addi	a0,sp,24
    14b6:	300000ef          	jal	ra,17b6 <out_unlocked.constprop.0>
		s += 2;
    14ba:	00248993          	addi	s3,s1,2
    14be:	b70d                	j	13e0 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    14c0:	67c2                	ld	a5,16(sp)
    14c2:	45a9                	li	a1,10
		s += 2;
    14c4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    14c8:	4388                	lw	a0,0(a5)
    14ca:	07a1                	addi	a5,a5,8
    14cc:	e83e                	sd	a5,16(sp)
    14ce:	588000ef          	jal	ra,1a56 <printint.constprop.0>
		s += 2;
    14d2:	b739                	j	13e0 <printf+0x1c2>
		mutex_lock(buffer_lock);
    14d4:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14d8:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14dc:	1e2010ef          	jal	ra,26be <mutex_lock>
		len = out_unlocked(s, l);
    14e0:	45c9                	li	a1,18
    14e2:	0828                	addi	a0,sp,24
    14e4:	1c6000ef          	jal	ra,16aa <out_unlocked>
		mutex_unlock(buffer_lock);
    14e8:	10ca2503          	lw	a0,268(s4)
    14ec:	1de010ef          	jal	ra,26ca <mutex_unlock>
		s += 2;
    14f0:	bdc5                	j	13e0 <printf+0x1c2>
		mutex_lock(buffer_lock);
    14f2:	10ca2503          	lw	a0,268(s4)
    14f6:	1c8010ef          	jal	ra,26be <mutex_lock>
		buffer[buffer_len++] = c;
    14fa:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14fe:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1502:	0017861b          	addiw	a2,a5,1
    1506:	97d2                	add	a5,a5,s4
    1508:	00ca2023          	sw	a2,0(s4)
    150c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1510:	00c6cc63          	blt	a3,a2,1528 <printf+0x30a>
    1514:	47a9                	li	a5,10
    1516:	06f40663          	beq	s0,a5,1582 <printf+0x364>
		mutex_unlock(buffer_lock);
    151a:	10ca2503          	lw	a0,268(s4)
		s += 2;
    151e:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1522:	1a8010ef          	jal	ra,26ca <mutex_unlock>
		s += 2;
    1526:	bd6d                	j	13e0 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1528:	10000793          	li	a5,256
    152c:	00f61e63          	bne	a2,a5,1548 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1530:	00001597          	auipc	a1,0x1
    1534:	35858593          	addi	a1,a1,856 # 2888 <buffer>
    1538:	4505                	li	a0,1
    153a:	70d000ef          	jal	ra,2446 <write>
	buffer_len = 0;
    153e:	00001797          	auipc	a5,0x1
    1542:	3407a123          	sw	zero,834(a5) # 2880 <buffer_len>
			if (r < 0) {
    1546:	bfd1                	j	151a <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1548:	709000ef          	jal	ra,2450 <getpid>
    154c:	842a                	mv	s0,a0
    154e:	00001517          	auipc	a0,0x1
    1552:	23a50513          	addi	a0,a0,570 # 2788 <enable_deadlock_detect+0x6a>
    1556:	5d1000ef          	jal	ra,2326 <basename>
    155a:	872a                	mv	a4,a0
    155c:	00001617          	auipc	a2,0x1
    1560:	26c60613          	addi	a2,a2,620 # 27c8 <enable_deadlock_detect+0xaa>
    1564:	05400793          	li	a5,84
    1568:	86a2                	mv	a3,s0
    156a:	45fd                	li	a1,31
    156c:	00001517          	auipc	a0,0x1
    1570:	26450513          	addi	a0,a0,612 # 27d0 <enable_deadlock_detect+0xb2>
    1574:	cabff0ef          	jal	ra,121e <printf>
    1578:	557d                	li	a0,-1
    157a:	707000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    157e:	000a2603          	lw	a2,0(s4)
    1582:	de41                	beqz	a2,151a <printf+0x2fc>
    1584:	b775                	j	1530 <printf+0x312>
		mutex_lock(buffer_lock);
    1586:	10ca2503          	lw	a0,268(s4)
    158a:	134010ef          	jal	ra,26be <mutex_lock>
		buffer[buffer_len++] = c;
    158e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1592:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1596:	0017861b          	addiw	a2,a5,1
    159a:	97d2                	add	a5,a5,s4
    159c:	00ca2023          	sw	a2,0(s4)
    15a0:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15a4:	02c6d163          	bge	a3,a2,15c6 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15a8:	10000793          	li	a5,256
    15ac:	02f61263          	bne	a2,a5,15d0 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15b0:	00001597          	auipc	a1,0x1
    15b4:	2d858593          	addi	a1,a1,728 # 2888 <buffer>
    15b8:	4505                	li	a0,1
    15ba:	68d000ef          	jal	ra,2446 <write>
	buffer_len = 0;
    15be:	00001797          	auipc	a5,0x1
    15c2:	2c07a123          	sw	zero,706(a5) # 2880 <buffer_len>
		mutex_unlock(buffer_lock);
    15c6:	10ca2503          	lw	a0,268(s4)
    15ca:	100010ef          	jal	ra,26ca <mutex_unlock>
    15ce:	bdd9                	j	14a4 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    15d0:	681000ef          	jal	ra,2450 <getpid>
    15d4:	842a                	mv	s0,a0
    15d6:	00001517          	auipc	a0,0x1
    15da:	1b250513          	addi	a0,a0,434 # 2788 <enable_deadlock_detect+0x6a>
    15de:	549000ef          	jal	ra,2326 <basename>
    15e2:	872a                	mv	a4,a0
    15e4:	00001617          	auipc	a2,0x1
    15e8:	1e460613          	addi	a2,a2,484 # 27c8 <enable_deadlock_detect+0xaa>
    15ec:	05400793          	li	a5,84
    15f0:	86a2                	mv	a3,s0
    15f2:	45fd                	li	a1,31
    15f4:	00001517          	auipc	a0,0x1
    15f8:	1dc50513          	addi	a0,a0,476 # 27d0 <enable_deadlock_detect+0xb2>
    15fc:	c23ff0ef          	jal	ra,121e <printf>
    1600:	557d                	li	a0,-1
    1602:	67f000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    1606:	000a2603          	lw	a2,0(s4)
    160a:	de55                	beqz	a2,15c6 <printf+0x3a8>
    160c:	b755                	j	15b0 <printf+0x392>
		mutex_lock(buffer_lock);
    160e:	10ca2503          	lw	a0,268(s4)
    1612:	e42e                	sd	a1,8(sp)
		s += 2;
    1614:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1618:	0a6010ef          	jal	ra,26be <mutex_lock>
		len = out_unlocked(s, l);
    161c:	65a2                	ld	a1,8(sp)
    161e:	8522                	mv	a0,s0
    1620:	08a000ef          	jal	ra,16aa <out_unlocked>
		mutex_unlock(buffer_lock);
    1624:	10ca2503          	lw	a0,268(s4)
    1628:	0a2010ef          	jal	ra,26ca <mutex_unlock>
		s += 2;
    162c:	bb55                	j	13e0 <printf+0x1c2>
				a = "(null)";
    162e:	00001417          	auipc	s0,0x1
    1632:	15240413          	addi	s0,s0,338 # 2780 <enable_deadlock_detect+0x62>
    1636:	bd2d                	j	1470 <printf+0x252>

0000000000001638 <enable_thread_io_buffer>:
{
    1638:	1101                	addi	sp,sp,-32
    163a:	e822                	sd	s0,16(sp)
    163c:	ec06                	sd	ra,24(sp)
    163e:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1640:	00001417          	auipc	s0,0x1
    1644:	24040413          	addi	s0,s0,576 # 2880 <buffer_len>
    1648:	05a010ef          	jal	ra,26a2 <mutex_create>
    164c:	10a42623          	sw	a0,268(s0)
    1650:	00054a63          	bltz	a0,1664 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1654:	4785                	li	a5,1
}
    1656:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1658:	10f42423          	sw	a5,264(s0)
}
    165c:	6442                	ld	s0,16(sp)
    165e:	64a2                	ld	s1,8(sp)
    1660:	6105                	addi	sp,sp,32
    1662:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1664:	5ed000ef          	jal	ra,2450 <getpid>
    1668:	84aa                	mv	s1,a0
    166a:	00001517          	auipc	a0,0x1
    166e:	11e50513          	addi	a0,a0,286 # 2788 <enable_deadlock_detect+0x6a>
    1672:	4b5000ef          	jal	ra,2326 <basename>
    1676:	872a                	mv	a4,a0
    1678:	04800793          	li	a5,72
    167c:	86a6                	mv	a3,s1
    167e:	00001517          	auipc	a0,0x1
    1682:	19250513          	addi	a0,a0,402 # 2810 <enable_deadlock_detect+0xf2>
    1686:	00001617          	auipc	a2,0x1
    168a:	14260613          	addi	a2,a2,322 # 27c8 <enable_deadlock_detect+0xaa>
    168e:	45fd                	li	a1,31
    1690:	b8fff0ef          	jal	ra,121e <printf>
    1694:	557d                	li	a0,-1
    1696:	5eb000ef          	jal	ra,2480 <exit>
	buffer_lock_enabled = 1;
    169a:	4785                	li	a5,1
}
    169c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    169e:	10f42423          	sw	a5,264(s0)
}
    16a2:	6442                	ld	s0,16(sp)
    16a4:	64a2                	ld	s1,8(sp)
    16a6:	6105                	addi	sp,sp,32
    16a8:	8082                	ret

00000000000016aa <out_unlocked>:
{
    16aa:	7159                	addi	sp,sp,-112
    16ac:	f486                	sd	ra,104(sp)
    16ae:	f0a2                	sd	s0,96(sp)
    16b0:	eca6                	sd	s1,88(sp)
    16b2:	e8ca                	sd	s2,80(sp)
    16b4:	e4ce                	sd	s3,72(sp)
    16b6:	e0d2                	sd	s4,64(sp)
    16b8:	fc56                	sd	s5,56(sp)
    16ba:	f85a                	sd	s6,48(sp)
    16bc:	f45e                	sd	s7,40(sp)
    16be:	f062                	sd	s8,32(sp)
    16c0:	ec66                	sd	s9,24(sp)
    16c2:	e86a                	sd	s10,16(sp)
    16c4:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    16c6:	0e058663          	beqz	a1,17b2 <out_unlocked+0x108>
    16ca:	842a                	mv	s0,a0
    16cc:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    16d0:	4981                	li	s3,0
    16d2:	00001d17          	auipc	s10,0x1
    16d6:	1aed0d13          	addi	s10,s10,430 # 2880 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16da:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16de:	00001b17          	auipc	s6,0x1
    16e2:	1aab0b13          	addi	s6,s6,426 # 2888 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16e6:	10000a93          	li	s5,256
    16ea:	00001c97          	auipc	s9,0x1
    16ee:	09ec8c93          	addi	s9,s9,158 # 2788 <enable_deadlock_detect+0x6a>
    16f2:	00001c17          	auipc	s8,0x1
    16f6:	0d6c0c13          	addi	s8,s8,214 # 27c8 <enable_deadlock_detect+0xaa>
    16fa:	00001b97          	auipc	s7,0x1
    16fe:	0d6b8b93          	addi	s7,s7,214 # 27d0 <enable_deadlock_detect+0xb2>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1702:	4a29                	li	s4,10
    1704:	a031                	j	1710 <out_unlocked+0x66>
    1706:	09468863          	beq	a3,s4,1796 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    170a:	0405                	addi	s0,s0,1
    170c:	04848163          	beq	s1,s0,174e <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1710:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1714:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1718:	0017861b          	addiw	a2,a5,1
    171c:	97ea                	add	a5,a5,s10
    171e:	00cd2023          	sw	a2,0(s10)
    1722:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1726:	fec950e3          	bge	s2,a2,1706 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    172a:	05561263          	bne	a2,s5,176e <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    172e:	85da                	mv	a1,s6
    1730:	4505                	li	a0,1
    1732:	515000ef          	jal	ra,2446 <write>
    1736:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1738:	00001797          	auipc	a5,0x1
    173c:	1407a423          	sw	zero,328(a5) # 2880 <buffer_len>
			if (r < 0) {
    1740:	06054763          	bltz	a0,17ae <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1744:	0405                	addi	s0,s0,1
			ret += r;
    1746:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    174a:	fc8493e3          	bne	s1,s0,1710 <out_unlocked+0x66>
}
    174e:	70a6                	ld	ra,104(sp)
    1750:	7406                	ld	s0,96(sp)
    1752:	64e6                	ld	s1,88(sp)
    1754:	6946                	ld	s2,80(sp)
    1756:	6a06                	ld	s4,64(sp)
    1758:	7ae2                	ld	s5,56(sp)
    175a:	7b42                	ld	s6,48(sp)
    175c:	7ba2                	ld	s7,40(sp)
    175e:	7c02                	ld	s8,32(sp)
    1760:	6ce2                	ld	s9,24(sp)
    1762:	6d42                	ld	s10,16(sp)
    1764:	6da2                	ld	s11,8(sp)
    1766:	854e                	mv	a0,s3
    1768:	69a6                	ld	s3,72(sp)
    176a:	6165                	addi	sp,sp,112
    176c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    176e:	4e3000ef          	jal	ra,2450 <getpid>
    1772:	8daa                	mv	s11,a0
    1774:	8566                	mv	a0,s9
    1776:	3b1000ef          	jal	ra,2326 <basename>
    177a:	872a                	mv	a4,a0
    177c:	8662                	mv	a2,s8
    177e:	05400793          	li	a5,84
    1782:	86ee                	mv	a3,s11
    1784:	45fd                	li	a1,31
    1786:	855e                	mv	a0,s7
    1788:	a97ff0ef          	jal	ra,121e <printf>
    178c:	557d                	li	a0,-1
    178e:	4f3000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    1792:	000d2603          	lw	a2,0(s10)
    1796:	da35                	beqz	a2,170a <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1798:	85da                	mv	a1,s6
    179a:	4505                	li	a0,1
    179c:	4ab000ef          	jal	ra,2446 <write>
    17a0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17a2:	00001797          	auipc	a5,0x1
    17a6:	0c07af23          	sw	zero,222(a5) # 2880 <buffer_len>
			if (r < 0) {
    17aa:	f8055de3          	bgez	a0,1744 <out_unlocked+0x9a>
    17ae:	89aa                	mv	s3,a0
    17b0:	bf79                	j	174e <out_unlocked+0xa4>
	int ret = 0;
    17b2:	4981                	li	s3,0
    17b4:	bf69                	j	174e <out_unlocked+0xa4>

00000000000017b6 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17b6:	1101                	addi	sp,sp,-32
    17b8:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17ba:	00001497          	auipc	s1,0x1
    17be:	0c648493          	addi	s1,s1,198 # 2880 <buffer_len>
    17c2:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    17c4:	ec06                	sd	ra,24(sp)
    17c6:	e822                	sd	s0,16(sp)
		char c = s[i];
    17c8:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    17cc:	0017861b          	addiw	a2,a5,1
    17d0:	97a6                	add	a5,a5,s1
    17d2:	00e78423          	sb	a4,8(a5)
    17d6:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17d8:	0ff00793          	li	a5,255
    17dc:	00c7cc63          	blt	a5,a2,17f4 <out_unlocked.constprop.0+0x3e>
    17e0:	47a9                	li	a5,10
    17e2:	06f70c63          	beq	a4,a5,185a <out_unlocked.constprop.0+0xa4>
    17e6:	4601                	li	a2,0
}
    17e8:	60e2                	ld	ra,24(sp)
    17ea:	6442                	ld	s0,16(sp)
    17ec:	64a2                	ld	s1,8(sp)
    17ee:	8532                	mv	a0,a2
    17f0:	6105                	addi	sp,sp,32
    17f2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17f4:	10000793          	li	a5,256
    17f8:	02f61563          	bne	a2,a5,1822 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17fc:	00001597          	auipc	a1,0x1
    1800:	08c58593          	addi	a1,a1,140 # 2888 <buffer>
    1804:	4505                	li	a0,1
    1806:	441000ef          	jal	ra,2446 <write>
}
    180a:	60e2                	ld	ra,24(sp)
    180c:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    180e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1812:	00001797          	auipc	a5,0x1
    1816:	0607a723          	sw	zero,110(a5) # 2880 <buffer_len>
}
    181a:	64a2                	ld	s1,8(sp)
    181c:	8532                	mv	a0,a2
    181e:	6105                	addi	sp,sp,32
    1820:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1822:	42f000ef          	jal	ra,2450 <getpid>
    1826:	842a                	mv	s0,a0
    1828:	00001517          	auipc	a0,0x1
    182c:	f6050513          	addi	a0,a0,-160 # 2788 <enable_deadlock_detect+0x6a>
    1830:	2f7000ef          	jal	ra,2326 <basename>
    1834:	872a                	mv	a4,a0
    1836:	00001617          	auipc	a2,0x1
    183a:	f9260613          	addi	a2,a2,-110 # 27c8 <enable_deadlock_detect+0xaa>
    183e:	05400793          	li	a5,84
    1842:	86a2                	mv	a3,s0
    1844:	45fd                	li	a1,31
    1846:	00001517          	auipc	a0,0x1
    184a:	f8a50513          	addi	a0,a0,-118 # 27d0 <enable_deadlock_detect+0xb2>
    184e:	9d1ff0ef          	jal	ra,121e <printf>
    1852:	557d                	li	a0,-1
    1854:	42d000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    1858:	4090                	lw	a2,0(s1)
    185a:	d659                	beqz	a2,17e8 <out_unlocked.constprop.0+0x32>
    185c:	b745                	j	17fc <out_unlocked.constprop.0+0x46>

000000000000185e <putchar>:
{
    185e:	7139                	addi	sp,sp,-64
    1860:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1862:	00001497          	auipc	s1,0x1
    1866:	01e48493          	addi	s1,s1,30 # 2880 <buffer_len>
    186a:	1084a703          	lw	a4,264(s1)
{
    186e:	f822                	sd	s0,48(sp)
	char byte = c;
    1870:	0ff57413          	zext.b	s0,a0
{
    1874:	fc06                	sd	ra,56(sp)
	char byte = c;
    1876:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    187a:	4785                	li	a5,1
    187c:	00f70d63          	beq	a4,a5,1896 <putchar+0x38>
		len = out_unlocked(s, l);
    1880:	01f10513          	addi	a0,sp,31
    1884:	f33ff0ef          	jal	ra,17b6 <out_unlocked.constprop.0>
}
    1888:	70e2                	ld	ra,56(sp)
    188a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    188c:	862a                	mv	a2,a0
}
    188e:	74a2                	ld	s1,40(sp)
    1890:	8532                	mv	a0,a2
    1892:	6121                	addi	sp,sp,64
    1894:	8082                	ret
		mutex_lock(buffer_lock);
    1896:	10c4a503          	lw	a0,268(s1)
    189a:	625000ef          	jal	ra,26be <mutex_lock>
		buffer[buffer_len++] = c;
    189e:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18a0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18a4:	0017861b          	addiw	a2,a5,1
    18a8:	97a6                	add	a5,a5,s1
    18aa:	c090                	sw	a2,0(s1)
    18ac:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18b0:	02c6c263          	blt	a3,a2,18d4 <putchar+0x76>
    18b4:	47a9                	li	a5,10
    18b6:	06f40d63          	beq	s0,a5,1930 <putchar+0xd2>
    18ba:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18bc:	10c4a503          	lw	a0,268(s1)
    18c0:	e432                	sd	a2,8(sp)
    18c2:	609000ef          	jal	ra,26ca <mutex_unlock>
    18c6:	6622                	ld	a2,8(sp)
}
    18c8:	70e2                	ld	ra,56(sp)
    18ca:	7442                	ld	s0,48(sp)
    18cc:	74a2                	ld	s1,40(sp)
    18ce:	8532                	mv	a0,a2
    18d0:	6121                	addi	sp,sp,64
    18d2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18d4:	10000793          	li	a5,256
    18d8:	02f61063          	bne	a2,a5,18f8 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18dc:	00001597          	auipc	a1,0x1
    18e0:	fac58593          	addi	a1,a1,-84 # 2888 <buffer>
    18e4:	4505                	li	a0,1
    18e6:	361000ef          	jal	ra,2446 <write>
    18ea:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18ee:	00001797          	auipc	a5,0x1
    18f2:	f807a923          	sw	zero,-110(a5) # 2880 <buffer_len>
			if (r < 0) {
    18f6:	b7d9                	j	18bc <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18f8:	359000ef          	jal	ra,2450 <getpid>
    18fc:	842a                	mv	s0,a0
    18fe:	00001517          	auipc	a0,0x1
    1902:	e8a50513          	addi	a0,a0,-374 # 2788 <enable_deadlock_detect+0x6a>
    1906:	221000ef          	jal	ra,2326 <basename>
    190a:	872a                	mv	a4,a0
    190c:	00001617          	auipc	a2,0x1
    1910:	ebc60613          	addi	a2,a2,-324 # 27c8 <enable_deadlock_detect+0xaa>
    1914:	05400793          	li	a5,84
    1918:	86a2                	mv	a3,s0
    191a:	45fd                	li	a1,31
    191c:	00001517          	auipc	a0,0x1
    1920:	eb450513          	addi	a0,a0,-332 # 27d0 <enable_deadlock_detect+0xb2>
    1924:	8fbff0ef          	jal	ra,121e <printf>
    1928:	557d                	li	a0,-1
    192a:	357000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    192e:	4090                	lw	a2,0(s1)
    1930:	d651                	beqz	a2,18bc <putchar+0x5e>
    1932:	b76d                	j	18dc <putchar+0x7e>

0000000000001934 <puts>:
{
    1934:	7139                	addi	sp,sp,-64
    1936:	f822                	sd	s0,48(sp)
    1938:	f426                	sd	s1,40(sp)
    193a:	fc06                	sd	ra,56(sp)
    193c:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    193e:	00001417          	auipc	s0,0x1
    1942:	f4240413          	addi	s0,s0,-190 # 2880 <buffer_len>
{
    1946:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1948:	638000ef          	jal	ra,1f80 <strlen>
	if (buffer_lock_enabled == 1) {
    194c:	10842703          	lw	a4,264(s0)
    1950:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1952:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1954:	04f70563          	beq	a4,a5,199e <puts+0x6a>
		len = out_unlocked(s, l);
    1958:	8526                	mv	a0,s1
    195a:	d51ff0ef          	jal	ra,16aa <out_unlocked>
    195e:	892a                	mv	s2,a0
    1960:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1962:	00095963          	bgez	s2,1974 <puts+0x40>
}
    1966:	70e2                	ld	ra,56(sp)
    1968:	7442                	ld	s0,48(sp)
    196a:	7902                	ld	s2,32(sp)
    196c:	8526                	mv	a0,s1
    196e:	74a2                	ld	s1,40(sp)
    1970:	6121                	addi	sp,sp,64
    1972:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1974:	10842703          	lw	a4,264(s0)
	char byte = c;
    1978:	44a9                	li	s1,10
    197a:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    197e:	4785                	li	a5,1
    1980:	02f70e63          	beq	a4,a5,19bc <puts+0x88>
		len = out_unlocked(s, l);
    1984:	01f10513          	addi	a0,sp,31
    1988:	e2fff0ef          	jal	ra,17b6 <out_unlocked.constprop.0>
}
    198c:	70e2                	ld	ra,56(sp)
    198e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1990:	41f5549b          	sraiw	s1,a0,0x1f
}
    1994:	7902                	ld	s2,32(sp)
    1996:	8526                	mv	a0,s1
    1998:	74a2                	ld	s1,40(sp)
    199a:	6121                	addi	sp,sp,64
    199c:	8082                	ret
		mutex_lock(buffer_lock);
    199e:	e42a                	sd	a0,8(sp)
    19a0:	10c42503          	lw	a0,268(s0)
    19a4:	51b000ef          	jal	ra,26be <mutex_lock>
		len = out_unlocked(s, l);
    19a8:	65a2                	ld	a1,8(sp)
    19aa:	8526                	mv	a0,s1
    19ac:	cffff0ef          	jal	ra,16aa <out_unlocked>
    19b0:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19b2:	10c42503          	lw	a0,268(s0)
    19b6:	515000ef          	jal	ra,26ca <mutex_unlock>
    19ba:	b75d                	j	1960 <puts+0x2c>
		mutex_lock(buffer_lock);
    19bc:	10c42503          	lw	a0,268(s0)
    19c0:	4ff000ef          	jal	ra,26be <mutex_lock>
		buffer[buffer_len++] = c;
    19c4:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19c6:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19ca:	0017861b          	addiw	a2,a5,1
    19ce:	97a2                	add	a5,a5,s0
    19d0:	c010                	sw	a2,0(s0)
    19d2:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19d6:	06c6dc63          	bge	a3,a2,1a4e <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    19da:	10000793          	li	a5,256
    19de:	02f61c63          	bne	a2,a5,1a16 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19e2:	00001597          	auipc	a1,0x1
    19e6:	ea658593          	addi	a1,a1,-346 # 2888 <buffer>
    19ea:	4505                	li	a0,1
    19ec:	25b000ef          	jal	ra,2446 <write>
			if (r < 0) {
    19f0:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19f2:	00001797          	auipc	a5,0x1
    19f6:	e807a723          	sw	zero,-370(a5) # 2880 <buffer_len>
			if (r < 0) {
    19fa:	04054c63          	bltz	a0,1a52 <puts+0x11e>
			if (r < buffer_len) {
    19fe:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a00:	10c42503          	lw	a0,268(s0)
    1a04:	4c7000ef          	jal	ra,26ca <mutex_unlock>
}
    1a08:	70e2                	ld	ra,56(sp)
    1a0a:	7442                	ld	s0,48(sp)
    1a0c:	7902                	ld	s2,32(sp)
    1a0e:	8526                	mv	a0,s1
    1a10:	74a2                	ld	s1,40(sp)
    1a12:	6121                	addi	sp,sp,64
    1a14:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a16:	23b000ef          	jal	ra,2450 <getpid>
    1a1a:	84aa                	mv	s1,a0
    1a1c:	00001517          	auipc	a0,0x1
    1a20:	d6c50513          	addi	a0,a0,-660 # 2788 <enable_deadlock_detect+0x6a>
    1a24:	103000ef          	jal	ra,2326 <basename>
    1a28:	872a                	mv	a4,a0
    1a2a:	00001617          	auipc	a2,0x1
    1a2e:	d9e60613          	addi	a2,a2,-610 # 27c8 <enable_deadlock_detect+0xaa>
    1a32:	05400793          	li	a5,84
    1a36:	86a6                	mv	a3,s1
    1a38:	45fd                	li	a1,31
    1a3a:	00001517          	auipc	a0,0x1
    1a3e:	d9650513          	addi	a0,a0,-618 # 27d0 <enable_deadlock_detect+0xb2>
    1a42:	fdcff0ef          	jal	ra,121e <printf>
    1a46:	557d                	li	a0,-1
    1a48:	239000ef          	jal	ra,2480 <exit>
	if (buffer_len == 0)
    1a4c:	4010                	lw	a2,0(s0)
    1a4e:	da45                	beqz	a2,19fe <puts+0xca>
    1a50:	bf49                	j	19e2 <puts+0xae>
    1a52:	54fd                	li	s1,-1
    1a54:	b775                	j	1a00 <puts+0xcc>

0000000000001a56 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a56:	715d                	addi	sp,sp,-80
    1a58:	e486                	sd	ra,72(sp)
    1a5a:	e0a2                	sd	s0,64(sp)
    1a5c:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a5e:	14054363          	bltz	a0,1ba4 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a62:	02b577bb          	remuw	a5,a0,a1
    1a66:	00001617          	auipc	a2,0x1
    1a6a:	f4260613          	addi	a2,a2,-190 # 29a8 <digits>
	buf[16] = 0;
    1a6e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a72:	0005871b          	sext.w	a4,a1
    1a76:	1782                	slli	a5,a5,0x20
    1a78:	9381                	srli	a5,a5,0x20
    1a7a:	97b2                	add	a5,a5,a2
    1a7c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a80:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a84:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a88:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a8a:	0eb56763          	bltu	a0,a1,1b78 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a8e:	02e877bb          	remuw	a5,a6,a4
    1a92:	1782                	slli	a5,a5,0x20
    1a94:	9381                	srli	a5,a5,0x20
    1a96:	97b2                	add	a5,a5,a2
    1a98:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a9c:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1aa0:	02f10323          	sb	a5,38(sp)
    1aa4:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1aa6:	0ce86963          	bltu	a6,a4,1b78 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aaa:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1aae:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1ab2:	1582                	slli	a1,a1,0x20
    1ab4:	9181                	srli	a1,a1,0x20
    1ab6:	95b2                	add	a1,a1,a2
    1ab8:	0005c583          	lbu	a1,0(a1)
    1abc:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1ac0:	0007859b          	sext.w	a1,a5
    1ac4:	16e6e563          	bltu	a3,a4,1c2e <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1ac8:	02e7f6bb          	remuw	a3,a5,a4
    1acc:	1682                	slli	a3,a3,0x20
    1ace:	9281                	srli	a3,a3,0x20
    1ad0:	96b2                	add	a3,a3,a2
    1ad2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ad6:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ada:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1ade:	16e5e163          	bltu	a1,a4,1c40 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1ae2:	02e876bb          	remuw	a3,a6,a4
    1ae6:	1682                	slli	a3,a3,0x20
    1ae8:	9281                	srli	a3,a3,0x20
    1aea:	96b2                	add	a3,a3,a2
    1aec:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1af0:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1af4:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1af8:	14e86d63          	bltu	a6,a4,1c52 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1afc:	02e5f6bb          	remuw	a3,a1,a4
    1b00:	1682                	slli	a3,a3,0x20
    1b02:	9281                	srli	a3,a3,0x20
    1b04:	96b2                	add	a3,a3,a2
    1b06:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b0a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b0e:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b12:	10e5e563          	bltu	a1,a4,1c1c <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b16:	02e876bb          	remuw	a3,a6,a4
    1b1a:	1682                	slli	a3,a3,0x20
    1b1c:	9281                	srli	a3,a3,0x20
    1b1e:	96b2                	add	a3,a3,a2
    1b20:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b24:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b28:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b2c:	14e86263          	bltu	a6,a4,1c70 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b30:	02e5f6bb          	remuw	a3,a1,a4
    1b34:	1682                	slli	a3,a3,0x20
    1b36:	9281                	srli	a3,a3,0x20
    1b38:	96b2                	add	a3,a3,a2
    1b3a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b3e:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b42:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b46:	14e5e463          	bltu	a1,a4,1c8e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b4a:	02e876bb          	remuw	a3,a6,a4
    1b4e:	1682                	slli	a3,a3,0x20
    1b50:	9281                	srli	a3,a3,0x20
    1b52:	96b2                	add	a3,a3,a2
    1b54:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b58:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b5c:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b60:	14e86063          	bltu	a6,a4,1ca0 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b64:	1782                	slli	a5,a5,0x20
    1b66:	9381                	srli	a5,a5,0x20
    1b68:	97b2                	add	a5,a5,a2
    1b6a:	0007c703          	lbu	a4,0(a5)
    1b6e:	4799                	li	a5,6
    1b70:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b74:	10054763          	bltz	a0,1c82 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b78:	00001497          	auipc	s1,0x1
    1b7c:	d0848493          	addi	s1,s1,-760 # 2880 <buffer_len>
    1b80:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b84:	0828                	addi	a0,sp,24
    1b86:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b88:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b8a:	00f50433          	add	s0,a0,a5
    1b8e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b90:	06e68463          	beq	a3,a4,1bf8 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b94:	8522                	mv	a0,s0
    1b96:	b15ff0ef          	jal	ra,16aa <out_unlocked>
}
    1b9a:	60a6                	ld	ra,72(sp)
    1b9c:	6406                	ld	s0,64(sp)
    1b9e:	74e2                	ld	s1,56(sp)
    1ba0:	6161                	addi	sp,sp,80
    1ba2:	8082                	ret
		x = -xx;
    1ba4:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1ba8:	02b877bb          	remuw	a5,a6,a1
    1bac:	00001617          	auipc	a2,0x1
    1bb0:	dfc60613          	addi	a2,a2,-516 # 29a8 <digits>
	buf[16] = 0;
    1bb4:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bb8:	0005871b          	sext.w	a4,a1
    1bbc:	1782                	slli	a5,a5,0x20
    1bbe:	9381                	srli	a5,a5,0x20
    1bc0:	97b2                	add	a5,a5,a2
    1bc2:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bc6:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1bca:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1bce:	08b86b63          	bltu	a6,a1,1c64 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1bd2:	02e8f7bb          	remuw	a5,a7,a4
    1bd6:	1782                	slli	a5,a5,0x20
    1bd8:	9381                	srli	a5,a5,0x20
    1bda:	97b2                	add	a5,a5,a2
    1bdc:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1be0:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1be4:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1be8:	ece8f1e3          	bgeu	a7,a4,1aaa <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bec:	02d00793          	li	a5,45
    1bf0:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1bf4:	47b5                	li	a5,13
    1bf6:	b749                	j	1b78 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1bf8:	10c4a503          	lw	a0,268(s1)
    1bfc:	e42e                	sd	a1,8(sp)
    1bfe:	2c1000ef          	jal	ra,26be <mutex_lock>
		len = out_unlocked(s, l);
    1c02:	65a2                	ld	a1,8(sp)
    1c04:	8522                	mv	a0,s0
    1c06:	aa5ff0ef          	jal	ra,16aa <out_unlocked>
		mutex_unlock(buffer_lock);
    1c0a:	10c4a503          	lw	a0,268(s1)
    1c0e:	2bd000ef          	jal	ra,26ca <mutex_unlock>
}
    1c12:	60a6                	ld	ra,72(sp)
    1c14:	6406                	ld	s0,64(sp)
    1c16:	74e2                	ld	s1,56(sp)
    1c18:	6161                	addi	sp,sp,80
    1c1a:	8082                	ret
		buf[i--] = digits[x % base];
    1c1c:	47a9                	li	a5,10
	if (sign)
    1c1e:	f4055de3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c22:	02d00793          	li	a5,45
    1c26:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c2a:	47a5                	li	a5,9
    1c2c:	b7b1                	j	1b78 <printint.constprop.0+0x122>
    1c2e:	47b5                	li	a5,13
	if (sign)
    1c30:	f40554e3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c34:	02d00793          	li	a5,45
    1c38:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c3c:	47b1                	li	a5,12
    1c3e:	bf2d                	j	1b78 <printint.constprop.0+0x122>
    1c40:	47b1                	li	a5,12
	if (sign)
    1c42:	f2055be3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c46:	02d00793          	li	a5,45
    1c4a:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c4e:	47ad                	li	a5,11
    1c50:	b725                	j	1b78 <printint.constprop.0+0x122>
    1c52:	47ad                	li	a5,11
	if (sign)
    1c54:	f20552e3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c58:	02d00793          	li	a5,45
    1c5c:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c60:	47a9                	li	a5,10
    1c62:	bf19                	j	1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c64:	02d00793          	li	a5,45
    1c68:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c6c:	47b9                	li	a5,14
    1c6e:	b729                	j	1b78 <printint.constprop.0+0x122>
    1c70:	47a5                	li	a5,9
	if (sign)
    1c72:	f00553e3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c76:	02d00793          	li	a5,45
    1c7a:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c7e:	47a1                	li	a5,8
    1c80:	bde5                	j	1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c82:	02d00793          	li	a5,45
    1c86:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c8a:	4795                	li	a5,5
    1c8c:	b5f5                	j	1b78 <printint.constprop.0+0x122>
    1c8e:	47a1                	li	a5,8
	if (sign)
    1c90:	ee0554e3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c94:	02d00793          	li	a5,45
    1c98:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c9c:	479d                	li	a5,7
    1c9e:	bde9                	j	1b78 <printint.constprop.0+0x122>
    1ca0:	479d                	li	a5,7
	if (sign)
    1ca2:	ec055be3          	bgez	a0,1b78 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca6:	02d00793          	li	a5,45
    1caa:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cae:	4799                	li	a5,6
    1cb0:	b5e1                	j	1b78 <printint.constprop.0+0x122>

0000000000001cb2 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cb2:	02000793          	li	a5,32
    1cb6:	00f50663          	beq	a0,a5,1cc2 <isspace+0x10>
    1cba:	355d                	addiw	a0,a0,-9
    1cbc:	00553513          	sltiu	a0,a0,5
    1cc0:	8082                	ret
    1cc2:	4505                	li	a0,1
}
    1cc4:	8082                	ret

0000000000001cc6 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1cc6:	fd05051b          	addiw	a0,a0,-48
}
    1cca:	00a53513          	sltiu	a0,a0,10
    1cce:	8082                	ret

0000000000001cd0 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cd0:	02000613          	li	a2,32
    1cd4:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1cd6:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cda:	ff77869b          	addiw	a3,a5,-9
    1cde:	04c78c63          	beq	a5,a2,1d36 <atoi+0x66>
    1ce2:	0007871b          	sext.w	a4,a5
    1ce6:	04d5f863          	bgeu	a1,a3,1d36 <atoi+0x66>
		s++;
	switch (*s) {
    1cea:	02b00693          	li	a3,43
    1cee:	04d78963          	beq	a5,a3,1d40 <atoi+0x70>
    1cf2:	02d00693          	li	a3,45
    1cf6:	06d78263          	beq	a5,a3,1d5a <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1cfa:	fd07061b          	addiw	a2,a4,-48
    1cfe:	47a5                	li	a5,9
    1d00:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d02:	4e01                	li	t3,0
	while (isdigit(*s))
    1d04:	04c7e963          	bltu	a5,a2,1d56 <atoi+0x86>
	int n = 0, neg = 0;
    1d08:	4501                	li	a0,0
	while (isdigit(*s))
    1d0a:	4825                	li	a6,9
    1d0c:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d10:	0025179b          	slliw	a5,a0,0x2
    1d14:	9fa9                	addw	a5,a5,a0
    1d16:	fd07031b          	addiw	t1,a4,-48
    1d1a:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d1e:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d22:	0685                	addi	a3,a3,1
    1d24:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d28:	0006071b          	sext.w	a4,a2
    1d2c:	feb870e3          	bgeu	a6,a1,1d0c <atoi+0x3c>
	return neg ? n : -n;
    1d30:	000e0563          	beqz	t3,1d3a <atoi+0x6a>
}
    1d34:	8082                	ret
		s++;
    1d36:	0505                	addi	a0,a0,1
    1d38:	bf79                	j	1cd6 <atoi+0x6>
	return neg ? n : -n;
    1d3a:	4113053b          	subw	a0,t1,a7
    1d3e:	8082                	ret
	while (isdigit(*s))
    1d40:	00154703          	lbu	a4,1(a0)
    1d44:	47a5                	li	a5,9
		s++;
    1d46:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d4a:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d4e:	4e01                	li	t3,0
	while (isdigit(*s))
    1d50:	2701                	sext.w	a4,a4
    1d52:	fac7fbe3          	bgeu	a5,a2,1d08 <atoi+0x38>
    1d56:	4501                	li	a0,0
}
    1d58:	8082                	ret
	while (isdigit(*s))
    1d5a:	00154703          	lbu	a4,1(a0)
    1d5e:	47a5                	li	a5,9
		s++;
    1d60:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d64:	fd07061b          	addiw	a2,a4,-48
    1d68:	2701                	sext.w	a4,a4
    1d6a:	fec7e6e3          	bltu	a5,a2,1d56 <atoi+0x86>
		neg = 1;
    1d6e:	4e05                	li	t3,1
    1d70:	bf61                	j	1d08 <atoi+0x38>

0000000000001d72 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d72:	16060d63          	beqz	a2,1eec <memset+0x17a>
    1d76:	40a007b3          	neg	a5,a0
    1d7a:	8b9d                	andi	a5,a5,7
    1d7c:	00778693          	addi	a3,a5,7
    1d80:	482d                	li	a6,11
    1d82:	0ff5f713          	zext.b	a4,a1
    1d86:	fff60593          	addi	a1,a2,-1
    1d8a:	1706e263          	bltu	a3,a6,1eee <memset+0x17c>
    1d8e:	16d5ea63          	bltu	a1,a3,1f02 <memset+0x190>
    1d92:	16078563          	beqz	a5,1efc <memset+0x18a>
    1d96:	00e50023          	sb	a4,0(a0)
    1d9a:	4685                	li	a3,1
    1d9c:	00150593          	addi	a1,a0,1
    1da0:	14d78c63          	beq	a5,a3,1ef8 <memset+0x186>
    1da4:	00e500a3          	sb	a4,1(a0)
    1da8:	4689                	li	a3,2
    1daa:	00250593          	addi	a1,a0,2
    1dae:	14d78d63          	beq	a5,a3,1f08 <memset+0x196>
    1db2:	00e50123          	sb	a4,2(a0)
    1db6:	468d                	li	a3,3
    1db8:	00350593          	addi	a1,a0,3
    1dbc:	12d78b63          	beq	a5,a3,1ef2 <memset+0x180>
    1dc0:	00e501a3          	sb	a4,3(a0)
    1dc4:	4691                	li	a3,4
    1dc6:	00450593          	addi	a1,a0,4
    1dca:	14d78163          	beq	a5,a3,1f0c <memset+0x19a>
    1dce:	00e50223          	sb	a4,4(a0)
    1dd2:	4695                	li	a3,5
    1dd4:	00550593          	addi	a1,a0,5
    1dd8:	12d78c63          	beq	a5,a3,1f10 <memset+0x19e>
    1ddc:	00e502a3          	sb	a4,5(a0)
    1de0:	469d                	li	a3,7
    1de2:	00650593          	addi	a1,a0,6
    1de6:	12d79763          	bne	a5,a3,1f14 <memset+0x1a2>
    1dea:	00750593          	addi	a1,a0,7
    1dee:	00e50323          	sb	a4,6(a0)
    1df2:	481d                	li	a6,7
    1df4:	00871693          	slli	a3,a4,0x8
    1df8:	01071893          	slli	a7,a4,0x10
    1dfc:	8ed9                	or	a3,a3,a4
    1dfe:	01871313          	slli	t1,a4,0x18
    1e02:	0116e6b3          	or	a3,a3,a7
    1e06:	0066e6b3          	or	a3,a3,t1
    1e0a:	02071893          	slli	a7,a4,0x20
    1e0e:	02871e13          	slli	t3,a4,0x28
    1e12:	0116e6b3          	or	a3,a3,a7
    1e16:	40f60333          	sub	t1,a2,a5
    1e1a:	03071893          	slli	a7,a4,0x30
    1e1e:	01c6e6b3          	or	a3,a3,t3
    1e22:	0116e6b3          	or	a3,a3,a7
    1e26:	03871e13          	slli	t3,a4,0x38
    1e2a:	97aa                	add	a5,a5,a0
    1e2c:	ff837893          	andi	a7,t1,-8
    1e30:	01c6e6b3          	or	a3,a3,t3
    1e34:	98be                	add	a7,a7,a5
    1e36:	e394                	sd	a3,0(a5)
    1e38:	07a1                	addi	a5,a5,8
    1e3a:	ff179ee3          	bne	a5,a7,1e36 <memset+0xc4>
    1e3e:	ff837893          	andi	a7,t1,-8
    1e42:	011587b3          	add	a5,a1,a7
    1e46:	010886bb          	addw	a3,a7,a6
    1e4a:	0b130663          	beq	t1,a7,1ef6 <memset+0x184>
    1e4e:	00e78023          	sb	a4,0(a5)
    1e52:	0016859b          	addiw	a1,a3,1
    1e56:	08c5fb63          	bgeu	a1,a2,1eec <memset+0x17a>
    1e5a:	00e780a3          	sb	a4,1(a5)
    1e5e:	0026859b          	addiw	a1,a3,2
    1e62:	08c5f563          	bgeu	a1,a2,1eec <memset+0x17a>
    1e66:	00e78123          	sb	a4,2(a5)
    1e6a:	0036859b          	addiw	a1,a3,3
    1e6e:	06c5ff63          	bgeu	a1,a2,1eec <memset+0x17a>
    1e72:	00e781a3          	sb	a4,3(a5)
    1e76:	0046859b          	addiw	a1,a3,4
    1e7a:	06c5f963          	bgeu	a1,a2,1eec <memset+0x17a>
    1e7e:	00e78223          	sb	a4,4(a5)
    1e82:	0056859b          	addiw	a1,a3,5
    1e86:	06c5f363          	bgeu	a1,a2,1eec <memset+0x17a>
    1e8a:	00e782a3          	sb	a4,5(a5)
    1e8e:	0066859b          	addiw	a1,a3,6
    1e92:	04c5fd63          	bgeu	a1,a2,1eec <memset+0x17a>
    1e96:	00e78323          	sb	a4,6(a5)
    1e9a:	0076859b          	addiw	a1,a3,7
    1e9e:	04c5f763          	bgeu	a1,a2,1eec <memset+0x17a>
    1ea2:	00e783a3          	sb	a4,7(a5)
    1ea6:	0086859b          	addiw	a1,a3,8
    1eaa:	04c5f163          	bgeu	a1,a2,1eec <memset+0x17a>
    1eae:	00e78423          	sb	a4,8(a5)
    1eb2:	0096859b          	addiw	a1,a3,9
    1eb6:	02c5fb63          	bgeu	a1,a2,1eec <memset+0x17a>
    1eba:	00e784a3          	sb	a4,9(a5)
    1ebe:	00a6859b          	addiw	a1,a3,10
    1ec2:	02c5f563          	bgeu	a1,a2,1eec <memset+0x17a>
    1ec6:	00e78523          	sb	a4,10(a5)
    1eca:	00b6859b          	addiw	a1,a3,11
    1ece:	00c5ff63          	bgeu	a1,a2,1eec <memset+0x17a>
    1ed2:	00e785a3          	sb	a4,11(a5)
    1ed6:	00c6859b          	addiw	a1,a3,12
    1eda:	00c5f963          	bgeu	a1,a2,1eec <memset+0x17a>
    1ede:	00e78623          	sb	a4,12(a5)
    1ee2:	26b5                	addiw	a3,a3,13
    1ee4:	00c6f463          	bgeu	a3,a2,1eec <memset+0x17a>
    1ee8:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1eec:	8082                	ret
    1eee:	46ad                	li	a3,11
    1ef0:	bd79                	j	1d8e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ef2:	480d                	li	a6,3
    1ef4:	b701                	j	1df4 <memset+0x82>
    1ef6:	8082                	ret
    1ef8:	4805                	li	a6,1
    1efa:	bded                	j	1df4 <memset+0x82>
    1efc:	85aa                	mv	a1,a0
    1efe:	4801                	li	a6,0
    1f00:	bdd5                	j	1df4 <memset+0x82>
    1f02:	87aa                	mv	a5,a0
    1f04:	4681                	li	a3,0
    1f06:	b7a1                	j	1e4e <memset+0xdc>
    1f08:	4809                	li	a6,2
    1f0a:	b5ed                	j	1df4 <memset+0x82>
    1f0c:	4811                	li	a6,4
    1f0e:	b5dd                	j	1df4 <memset+0x82>
    1f10:	4815                	li	a6,5
    1f12:	b5cd                	j	1df4 <memset+0x82>
    1f14:	4819                	li	a6,6
    1f16:	bdf9                	j	1df4 <memset+0x82>

0000000000001f18 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f18:	00054783          	lbu	a5,0(a0)
    1f1c:	0005c703          	lbu	a4,0(a1)
    1f20:	00e79863          	bne	a5,a4,1f30 <strcmp+0x18>
    1f24:	0505                	addi	a0,a0,1
    1f26:	0585                	addi	a1,a1,1
    1f28:	fbe5                	bnez	a5,1f18 <strcmp>
    1f2a:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f2c:	9d19                	subw	a0,a0,a4
    1f2e:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f30:	0007851b          	sext.w	a0,a5
    1f34:	bfe5                	j	1f2c <strcmp+0x14>

0000000000001f36 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f36:	ca15                	beqz	a2,1f6a <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f38:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f3c:	167d                	addi	a2,a2,-1
    1f3e:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f42:	eb99                	bnez	a5,1f58 <strncmp+0x22>
    1f44:	a815                	j	1f78 <strncmp+0x42>
    1f46:	00a68e63          	beq	a3,a0,1f62 <strncmp+0x2c>
    1f4a:	0505                	addi	a0,a0,1
    1f4c:	00f71b63          	bne	a4,a5,1f62 <strncmp+0x2c>
    1f50:	00054783          	lbu	a5,0(a0)
    1f54:	cf89                	beqz	a5,1f6e <strncmp+0x38>
    1f56:	85b2                	mv	a1,a2
    1f58:	0005c703          	lbu	a4,0(a1)
    1f5c:	00158613          	addi	a2,a1,1
    1f60:	f37d                	bnez	a4,1f46 <strncmp+0x10>
		;
	return *l - *r;
    1f62:	0007851b          	sext.w	a0,a5
    1f66:	9d19                	subw	a0,a0,a4
    1f68:	8082                	ret
		return 0;
    1f6a:	4501                	li	a0,0
}
    1f6c:	8082                	ret
	return *l - *r;
    1f6e:	0015c703          	lbu	a4,1(a1)
    1f72:	4501                	li	a0,0
    1f74:	9d19                	subw	a0,a0,a4
    1f76:	8082                	ret
    1f78:	0005c703          	lbu	a4,0(a1)
    1f7c:	4501                	li	a0,0
    1f7e:	b7e5                	j	1f66 <strncmp+0x30>

0000000000001f80 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f80:	00757793          	andi	a5,a0,7
    1f84:	cf89                	beqz	a5,1f9e <strlen+0x1e>
    1f86:	87aa                	mv	a5,a0
    1f88:	a029                	j	1f92 <strlen+0x12>
    1f8a:	0785                	addi	a5,a5,1
    1f8c:	0077f713          	andi	a4,a5,7
    1f90:	cb01                	beqz	a4,1fa0 <strlen+0x20>
		if (!*s)
    1f92:	0007c703          	lbu	a4,0(a5)
    1f96:	fb75                	bnez	a4,1f8a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f98:	40a78533          	sub	a0,a5,a0
}
    1f9c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f9e:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fa0:	6394                	ld	a3,0(a5)
    1fa2:	00001597          	auipc	a1,0x1
    1fa6:	8c65b583          	ld	a1,-1850(a1) # 2868 <enable_deadlock_detect+0x14a>
    1faa:	00001617          	auipc	a2,0x1
    1fae:	8c663603          	ld	a2,-1850(a2) # 2870 <enable_deadlock_detect+0x152>
    1fb2:	a019                	j	1fb8 <strlen+0x38>
    1fb4:	6794                	ld	a3,8(a5)
    1fb6:	07a1                	addi	a5,a5,8
    1fb8:	00b68733          	add	a4,a3,a1
    1fbc:	fff6c693          	not	a3,a3
    1fc0:	8f75                	and	a4,a4,a3
    1fc2:	8f71                	and	a4,a4,a2
    1fc4:	db65                	beqz	a4,1fb4 <strlen+0x34>
	for (; *s; s++)
    1fc6:	0007c703          	lbu	a4,0(a5)
    1fca:	d779                	beqz	a4,1f98 <strlen+0x18>
    1fcc:	0017c703          	lbu	a4,1(a5)
    1fd0:	0785                	addi	a5,a5,1
    1fd2:	d379                	beqz	a4,1f98 <strlen+0x18>
    1fd4:	0017c703          	lbu	a4,1(a5)
    1fd8:	0785                	addi	a5,a5,1
    1fda:	fb6d                	bnez	a4,1fcc <strlen+0x4c>
    1fdc:	bf75                	j	1f98 <strlen+0x18>

0000000000001fde <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fde:	00757713          	andi	a4,a0,7
{
    1fe2:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1fe4:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fe8:	cb19                	beqz	a4,1ffe <memchr+0x20>
    1fea:	ce25                	beqz	a2,2062 <memchr+0x84>
    1fec:	0007c703          	lbu	a4,0(a5)
    1ff0:	04b70e63          	beq	a4,a1,204c <memchr+0x6e>
    1ff4:	0785                	addi	a5,a5,1
    1ff6:	0077f713          	andi	a4,a5,7
    1ffa:	167d                	addi	a2,a2,-1
    1ffc:	f77d                	bnez	a4,1fea <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1ffe:	4501                	li	a0,0
	if (n && *s != c) {
    2000:	c235                	beqz	a2,2064 <memchr+0x86>
    2002:	0007c703          	lbu	a4,0(a5)
    2006:	04b70363          	beq	a4,a1,204c <memchr+0x6e>
		size_t k = ONES * c;
    200a:	00001517          	auipc	a0,0x1
    200e:	86e53503          	ld	a0,-1938(a0) # 2878 <enable_deadlock_detect+0x15a>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2012:	471d                	li	a4,7
		size_t k = ONES * c;
    2014:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2018:	02c77a63          	bgeu	a4,a2,204c <memchr+0x6e>
    201c:	00001897          	auipc	a7,0x1
    2020:	84c8b883          	ld	a7,-1972(a7) # 2868 <enable_deadlock_detect+0x14a>
    2024:	00001817          	auipc	a6,0x1
    2028:	84c83803          	ld	a6,-1972(a6) # 2870 <enable_deadlock_detect+0x152>
    202c:	431d                	li	t1,7
    202e:	a029                	j	2038 <memchr+0x5a>
		     w++, n -= SS)
    2030:	1661                	addi	a2,a2,-8
    2032:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2034:	02c37963          	bgeu	t1,a2,2066 <memchr+0x88>
    2038:	6398                	ld	a4,0(a5)
    203a:	8f29                	xor	a4,a4,a0
    203c:	011706b3          	add	a3,a4,a7
    2040:	fff74713          	not	a4,a4
    2044:	8f75                	and	a4,a4,a3
    2046:	01077733          	and	a4,a4,a6
    204a:	d37d                	beqz	a4,2030 <memchr+0x52>
{
    204c:	853e                	mv	a0,a5
    204e:	97b2                	add	a5,a5,a2
    2050:	a021                	j	2058 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2052:	0505                	addi	a0,a0,1
    2054:	00f50763          	beq	a0,a5,2062 <memchr+0x84>
    2058:	00054703          	lbu	a4,0(a0)
    205c:	feb71be3          	bne	a4,a1,2052 <memchr+0x74>
    2060:	8082                	ret
	return n ? (void *)s : 0;
    2062:	4501                	li	a0,0
}
    2064:	8082                	ret
	return n ? (void *)s : 0;
    2066:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2068:	f275                	bnez	a2,204c <memchr+0x6e>
}
    206a:	8082                	ret

000000000000206c <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    206c:	1101                	addi	sp,sp,-32
    206e:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2070:	862e                	mv	a2,a1
{
    2072:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2074:	4581                	li	a1,0
{
    2076:	e426                	sd	s1,8(sp)
    2078:	ec06                	sd	ra,24(sp)
    207a:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    207c:	f63ff0ef          	jal	ra,1fde <memchr>
	return p ? p - s : n;
    2080:	c519                	beqz	a0,208e <strnlen+0x22>
}
    2082:	60e2                	ld	ra,24(sp)
    2084:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2086:	8d05                	sub	a0,a0,s1
}
    2088:	64a2                	ld	s1,8(sp)
    208a:	6105                	addi	sp,sp,32
    208c:	8082                	ret
    208e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2090:	8522                	mv	a0,s0
}
    2092:	6442                	ld	s0,16(sp)
    2094:	64a2                	ld	s1,8(sp)
    2096:	6105                	addi	sp,sp,32
    2098:	8082                	ret

000000000000209a <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    209a:	00a5c7b3          	xor	a5,a1,a0
    209e:	8b9d                	andi	a5,a5,7
    20a0:	eb95                	bnez	a5,20d4 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20a2:	0075f793          	andi	a5,a1,7
    20a6:	e7b1                	bnez	a5,20f2 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20a8:	6198                	ld	a4,0(a1)
    20aa:	00000617          	auipc	a2,0x0
    20ae:	7be63603          	ld	a2,1982(a2) # 2868 <enable_deadlock_detect+0x14a>
    20b2:	00000817          	auipc	a6,0x0
    20b6:	7be83803          	ld	a6,1982(a6) # 2870 <enable_deadlock_detect+0x152>
    20ba:	a029                	j	20c4 <stpcpy+0x2a>
    20bc:	05a1                	addi	a1,a1,8
    20be:	e118                	sd	a4,0(a0)
    20c0:	6198                	ld	a4,0(a1)
    20c2:	0521                	addi	a0,a0,8
    20c4:	00c707b3          	add	a5,a4,a2
    20c8:	fff74693          	not	a3,a4
    20cc:	8ff5                	and	a5,a5,a3
    20ce:	0107f7b3          	and	a5,a5,a6
    20d2:	d7ed                	beqz	a5,20bc <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    20d4:	0005c783          	lbu	a5,0(a1)
    20d8:	00f50023          	sb	a5,0(a0)
    20dc:	c785                	beqz	a5,2104 <stpcpy+0x6a>
    20de:	0015c783          	lbu	a5,1(a1)
    20e2:	0505                	addi	a0,a0,1
    20e4:	0585                	addi	a1,a1,1
    20e6:	00f50023          	sb	a5,0(a0)
    20ea:	fbf5                	bnez	a5,20de <stpcpy+0x44>
		;
	return d;
}
    20ec:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20ee:	0505                	addi	a0,a0,1
    20f0:	df45                	beqz	a4,20a8 <stpcpy+0xe>
			if (!(*d = *s))
    20f2:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20f6:	0585                	addi	a1,a1,1
    20f8:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20fc:	00f50023          	sb	a5,0(a0)
    2100:	f7fd                	bnez	a5,20ee <stpcpy+0x54>
}
    2102:	8082                	ret
    2104:	8082                	ret

0000000000002106 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2106:	00a5c7b3          	xor	a5,a1,a0
    210a:	8b9d                	andi	a5,a5,7
    210c:	1a079863          	bnez	a5,22bc <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2110:	0075f793          	andi	a5,a1,7
    2114:	16078463          	beqz	a5,227c <stpncpy+0x176>
    2118:	ea01                	bnez	a2,2128 <stpncpy+0x22>
    211a:	a421                	j	2322 <stpncpy+0x21c>
    211c:	167d                	addi	a2,a2,-1
    211e:	0505                	addi	a0,a0,1
    2120:	14070e63          	beqz	a4,227c <stpncpy+0x176>
    2124:	1a060863          	beqz	a2,22d4 <stpncpy+0x1ce>
    2128:	0005c783          	lbu	a5,0(a1)
    212c:	0585                	addi	a1,a1,1
    212e:	0075f713          	andi	a4,a1,7
    2132:	00f50023          	sb	a5,0(a0)
    2136:	f3fd                	bnez	a5,211c <stpncpy+0x16>
    2138:	4805                	li	a6,1
    213a:	1a061863          	bnez	a2,22ea <stpncpy+0x1e4>
    213e:	40a007b3          	neg	a5,a0
    2142:	8b9d                	andi	a5,a5,7
    2144:	4681                	li	a3,0
    2146:	18061a63          	bnez	a2,22da <stpncpy+0x1d4>
    214a:	00778713          	addi	a4,a5,7
    214e:	45ad                	li	a1,11
    2150:	18b76363          	bltu	a4,a1,22d6 <stpncpy+0x1d0>
    2154:	1ae6eb63          	bltu	a3,a4,230a <stpncpy+0x204>
    2158:	1a078363          	beqz	a5,22fe <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    215c:	00050023          	sb	zero,0(a0)
    2160:	4685                	li	a3,1
    2162:	00150713          	addi	a4,a0,1
    2166:	18d78f63          	beq	a5,a3,2304 <stpncpy+0x1fe>
    216a:	000500a3          	sb	zero,1(a0)
    216e:	4689                	li	a3,2
    2170:	00250713          	addi	a4,a0,2
    2174:	18d78e63          	beq	a5,a3,2310 <stpncpy+0x20a>
    2178:	00050123          	sb	zero,2(a0)
    217c:	468d                	li	a3,3
    217e:	00350713          	addi	a4,a0,3
    2182:	16d78c63          	beq	a5,a3,22fa <stpncpy+0x1f4>
    2186:	000501a3          	sb	zero,3(a0)
    218a:	4691                	li	a3,4
    218c:	00450713          	addi	a4,a0,4
    2190:	18d78263          	beq	a5,a3,2314 <stpncpy+0x20e>
    2194:	00050223          	sb	zero,4(a0)
    2198:	4695                	li	a3,5
    219a:	00550713          	addi	a4,a0,5
    219e:	16d78d63          	beq	a5,a3,2318 <stpncpy+0x212>
    21a2:	000502a3          	sb	zero,5(a0)
    21a6:	469d                	li	a3,7
    21a8:	00650713          	addi	a4,a0,6
    21ac:	16d79863          	bne	a5,a3,231c <stpncpy+0x216>
    21b0:	00750713          	addi	a4,a0,7
    21b4:	00050323          	sb	zero,6(a0)
    21b8:	40f80833          	sub	a6,a6,a5
    21bc:	ff887593          	andi	a1,a6,-8
    21c0:	97aa                	add	a5,a5,a0
    21c2:	95be                	add	a1,a1,a5
    21c4:	0007b023          	sd	zero,0(a5)
    21c8:	07a1                	addi	a5,a5,8
    21ca:	feb79de3          	bne	a5,a1,21c4 <stpncpy+0xbe>
    21ce:	ff887593          	andi	a1,a6,-8
    21d2:	9ead                	addw	a3,a3,a1
    21d4:	00b707b3          	add	a5,a4,a1
    21d8:	12b80863          	beq	a6,a1,2308 <stpncpy+0x202>
    21dc:	00078023          	sb	zero,0(a5)
    21e0:	0016871b          	addiw	a4,a3,1
    21e4:	0ec77863          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    21e8:	000780a3          	sb	zero,1(a5)
    21ec:	0026871b          	addiw	a4,a3,2
    21f0:	0ec77263          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    21f4:	00078123          	sb	zero,2(a5)
    21f8:	0036871b          	addiw	a4,a3,3
    21fc:	0cc77c63          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2200:	000781a3          	sb	zero,3(a5)
    2204:	0046871b          	addiw	a4,a3,4
    2208:	0cc77663          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    220c:	00078223          	sb	zero,4(a5)
    2210:	0056871b          	addiw	a4,a3,5
    2214:	0cc77063          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2218:	000782a3          	sb	zero,5(a5)
    221c:	0066871b          	addiw	a4,a3,6
    2220:	0ac77a63          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2224:	00078323          	sb	zero,6(a5)
    2228:	0076871b          	addiw	a4,a3,7
    222c:	0ac77463          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2230:	000783a3          	sb	zero,7(a5)
    2234:	0086871b          	addiw	a4,a3,8
    2238:	08c77e63          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    223c:	00078423          	sb	zero,8(a5)
    2240:	0096871b          	addiw	a4,a3,9
    2244:	08c77863          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2248:	000784a3          	sb	zero,9(a5)
    224c:	00a6871b          	addiw	a4,a3,10
    2250:	08c77263          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2254:	00078523          	sb	zero,10(a5)
    2258:	00b6871b          	addiw	a4,a3,11
    225c:	06c77c63          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    2260:	000785a3          	sb	zero,11(a5)
    2264:	00c6871b          	addiw	a4,a3,12
    2268:	06c77663          	bgeu	a4,a2,22d4 <stpncpy+0x1ce>
    226c:	00078623          	sb	zero,12(a5)
    2270:	26b5                	addiw	a3,a3,13
    2272:	06c6f163          	bgeu	a3,a2,22d4 <stpncpy+0x1ce>
    2276:	000786a3          	sb	zero,13(a5)
    227a:	8082                	ret
			;
		if (!n || !*s)
    227c:	c645                	beqz	a2,2324 <stpncpy+0x21e>
    227e:	0005c783          	lbu	a5,0(a1)
    2282:	ea078be3          	beqz	a5,2138 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2286:	479d                	li	a5,7
    2288:	02c7ff63          	bgeu	a5,a2,22c6 <stpncpy+0x1c0>
    228c:	00000897          	auipc	a7,0x0
    2290:	5dc8b883          	ld	a7,1500(a7) # 2868 <enable_deadlock_detect+0x14a>
    2294:	00000817          	auipc	a6,0x0
    2298:	5dc83803          	ld	a6,1500(a6) # 2870 <enable_deadlock_detect+0x152>
    229c:	431d                	li	t1,7
    229e:	6198                	ld	a4,0(a1)
    22a0:	011707b3          	add	a5,a4,a7
    22a4:	fff74693          	not	a3,a4
    22a8:	8ff5                	and	a5,a5,a3
    22aa:	0107f7b3          	and	a5,a5,a6
    22ae:	ef81                	bnez	a5,22c6 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22b0:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22b2:	1661                	addi	a2,a2,-8
    22b4:	05a1                	addi	a1,a1,8
    22b6:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22b8:	fec363e3          	bltu	t1,a2,229e <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22bc:	e609                	bnez	a2,22c6 <stpncpy+0x1c0>
    22be:	a08d                	j	2320 <stpncpy+0x21a>
    22c0:	167d                	addi	a2,a2,-1
    22c2:	0505                	addi	a0,a0,1
    22c4:	ca01                	beqz	a2,22d4 <stpncpy+0x1ce>
    22c6:	0005c783          	lbu	a5,0(a1)
    22ca:	0585                	addi	a1,a1,1
    22cc:	00f50023          	sb	a5,0(a0)
    22d0:	fbe5                	bnez	a5,22c0 <stpncpy+0x1ba>
		;
tail:
    22d2:	b59d                	j	2138 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    22d4:	8082                	ret
    22d6:	472d                	li	a4,11
    22d8:	bdb5                	j	2154 <stpncpy+0x4e>
    22da:	00778713          	addi	a4,a5,7
    22de:	45ad                	li	a1,11
    22e0:	fff60693          	addi	a3,a2,-1
    22e4:	e6b778e3          	bgeu	a4,a1,2154 <stpncpy+0x4e>
    22e8:	b7fd                	j	22d6 <stpncpy+0x1d0>
    22ea:	40a007b3          	neg	a5,a0
    22ee:	8832                	mv	a6,a2
    22f0:	8b9d                	andi	a5,a5,7
    22f2:	4681                	li	a3,0
    22f4:	e4060be3          	beqz	a2,214a <stpncpy+0x44>
    22f8:	b7cd                	j	22da <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22fa:	468d                	li	a3,3
    22fc:	bd75                	j	21b8 <stpncpy+0xb2>
    22fe:	872a                	mv	a4,a0
    2300:	4681                	li	a3,0
    2302:	bd5d                	j	21b8 <stpncpy+0xb2>
    2304:	4685                	li	a3,1
    2306:	bd4d                	j	21b8 <stpncpy+0xb2>
    2308:	8082                	ret
    230a:	87aa                	mv	a5,a0
    230c:	4681                	li	a3,0
    230e:	b5f9                	j	21dc <stpncpy+0xd6>
    2310:	4689                	li	a3,2
    2312:	b55d                	j	21b8 <stpncpy+0xb2>
    2314:	4691                	li	a3,4
    2316:	b54d                	j	21b8 <stpncpy+0xb2>
    2318:	4695                	li	a3,5
    231a:	bd79                	j	21b8 <stpncpy+0xb2>
    231c:	4699                	li	a3,6
    231e:	bd69                	j	21b8 <stpncpy+0xb2>
    2320:	8082                	ret
    2322:	8082                	ret
    2324:	8082                	ret

0000000000002326 <basename>:

char *basename(char *s)
{
    2326:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2328:	c54d                	beqz	a0,23d2 <basename+0xac>
    232a:	00054783          	lbu	a5,0(a0)
		return ".";
    232e:	00000517          	auipc	a0,0x0
    2332:	53250513          	addi	a0,a0,1330 # 2860 <enable_deadlock_detect+0x142>
	if (!s || !*s)
    2336:	e391                	bnez	a5,233a <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2338:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    233a:	0076f713          	andi	a4,a3,7
    233e:	87b6                	mv	a5,a3
    2340:	cf51                	beqz	a4,23dc <basename+0xb6>
    2342:	0785                	addi	a5,a5,1
    2344:	0077f713          	andi	a4,a5,7
    2348:	c729                	beqz	a4,2392 <basename+0x6c>
		if (!*s)
    234a:	0007c703          	lbu	a4,0(a5)
    234e:	fb75                	bnez	a4,2342 <basename+0x1c>
	return s - a;
    2350:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2352:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2354:	cf8d                	beqz	a5,238e <basename+0x68>
    2356:	00f68733          	add	a4,a3,a5
    235a:	02f00593          	li	a1,47
    235e:	a031                	j	236a <basename+0x44>
		s[i] = 0;
    2360:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2364:	17fd                	addi	a5,a5,-1
    2366:	177d                	addi	a4,a4,-1
    2368:	c39d                	beqz	a5,238e <basename+0x68>
    236a:	00074603          	lbu	a2,0(a4)
    236e:	feb609e3          	beq	a2,a1,2360 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2372:	02f00613          	li	a2,47
    2376:	a011                	j	237a <basename+0x54>
    2378:	cb99                	beqz	a5,238e <basename+0x68>
    237a:	853e                	mv	a0,a5
    237c:	17fd                	addi	a5,a5,-1
    237e:	00f68733          	add	a4,a3,a5
    2382:	00074703          	lbu	a4,0(a4)
    2386:	fec719e3          	bne	a4,a2,2378 <basename+0x52>
	return s + i;
    238a:	9536                	add	a0,a0,a3
    238c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    238e:	8536                	mv	a0,a3
    2390:	8082                	ret
    2392:	6390                	ld	a2,0(a5)
    2394:	00000517          	auipc	a0,0x0
    2398:	4d453503          	ld	a0,1236(a0) # 2868 <enable_deadlock_detect+0x14a>
    239c:	00000597          	auipc	a1,0x0
    23a0:	4d45b583          	ld	a1,1236(a1) # 2870 <enable_deadlock_detect+0x152>
    23a4:	fff64713          	not	a4,a2
    23a8:	962a                	add	a2,a2,a0
    23aa:	8f71                	and	a4,a4,a2
    23ac:	8f6d                	and	a4,a4,a1
    23ae:	eb11                	bnez	a4,23c2 <basename+0x9c>
    23b0:	6790                	ld	a2,8(a5)
    23b2:	07a1                	addi	a5,a5,8
    23b4:	00a60733          	add	a4,a2,a0
    23b8:	fff64613          	not	a2,a2
    23bc:	8f71                	and	a4,a4,a2
    23be:	8f6d                	and	a4,a4,a1
    23c0:	db65                	beqz	a4,23b0 <basename+0x8a>
	for (; *s; s++)
    23c2:	0007c703          	lbu	a4,0(a5)
    23c6:	d749                	beqz	a4,2350 <basename+0x2a>
    23c8:	0017c703          	lbu	a4,1(a5)
    23cc:	0785                	addi	a5,a5,1
    23ce:	ff6d                	bnez	a4,23c8 <basename+0xa2>
    23d0:	b741                	j	2350 <basename+0x2a>
		return ".";
    23d2:	00000517          	auipc	a0,0x0
    23d6:	48e50513          	addi	a0,a0,1166 # 2860 <enable_deadlock_detect+0x142>
    23da:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23dc:	6290                	ld	a2,0(a3)
    23de:	00000517          	auipc	a0,0x0
    23e2:	48a53503          	ld	a0,1162(a0) # 2868 <enable_deadlock_detect+0x14a>
    23e6:	00000597          	auipc	a1,0x0
    23ea:	48a5b583          	ld	a1,1162(a1) # 2870 <enable_deadlock_detect+0x152>
    23ee:	fff64713          	not	a4,a2
    23f2:	962a                	add	a2,a2,a0
    23f4:	8f71                	and	a4,a4,a2
    23f6:	8f6d                	and	a4,a4,a1
    23f8:	df45                	beqz	a4,23b0 <basename+0x8a>
    23fa:	b7f9                	j	23c8 <basename+0xa2>

00000000000023fc <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23fc:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2400:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2402:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2406:	2501                	sext.w	a0,a0
    2408:	8082                	ret

000000000000240a <close>:

int close(int fd)
{
	if (fd == 1) {
    240a:	4785                	li	a5,1
    240c:	00f50863          	beq	a0,a5,241c <close+0x12>
	register long a7 __asm__("a7") = n;
    2410:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2414:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2418:	2501                	sext.w	a0,a0
    241a:	8082                	ret
{
    241c:	1101                	addi	sp,sp,-32
    241e:	ec06                	sd	ra,24(sp)
    2420:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2422:	cdffe0ef          	jal	ra,1100 <__write_buffer>
		__clear_buffer();
    2426:	d03fe0ef          	jal	ra,1128 <__clear_buffer>
    242a:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    242c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2430:	00000073          	ecall
}
    2434:	60e2                	ld	ra,24(sp)
    2436:	2501                	sext.w	a0,a0
    2438:	6105                	addi	sp,sp,32
    243a:	8082                	ret

000000000000243c <read>:
	register long a7 __asm__("a7") = n;
    243c:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2440:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2444:	8082                	ret

0000000000002446 <write>:
	register long a7 __asm__("a7") = n;
    2446:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    244a:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    244e:	8082                	ret

0000000000002450 <getpid>:
	register long a7 __asm__("a7") = n;
    2450:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2454:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2458:	2501                	sext.w	a0,a0
    245a:	8082                	ret

000000000000245c <getppid>:
	register long a7 __asm__("a7") = n;
    245c:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2460:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2464:	2501                	sext.w	a0,a0
    2466:	8082                	ret

0000000000002468 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2468:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    246c:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2470:	2501                	sext.w	a0,a0
    2472:	8082                	ret

0000000000002474 <fork>:
	register long a7 __asm__("a7") = n;
    2474:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2478:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    247c:	2501                	sext.w	a0,a0
    247e:	8082                	ret

0000000000002480 <exit>:

void exit(int code)
{
    2480:	1141                	addi	sp,sp,-16
    2482:	e406                	sd	ra,8(sp)
    2484:	e022                	sd	s0,0(sp)
    2486:	842a                	mv	s0,a0
	__write_buffer();
    2488:	c79fe0ef          	jal	ra,1100 <__write_buffer>
	__clear_buffer();
    248c:	c9dfe0ef          	jal	ra,1128 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2490:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2494:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2496:	00000073          	ecall
	syscall(SYS_exit, code);
}
    249a:	60a2                	ld	ra,8(sp)
    249c:	6402                	ld	s0,0(sp)
    249e:	0141                	addi	sp,sp,16
    24a0:	8082                	ret

00000000000024a2 <waitpid>:
	register long a7 __asm__("a7") = n;
    24a2:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a6:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24aa:	2501                	sext.w	a0,a0
    24ac:	8082                	ret

00000000000024ae <exec>:
	register long a7 __asm__("a7") = n;
    24ae:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24b2:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24b6:	2501                	sext.w	a0,a0
    24b8:	8082                	ret

00000000000024ba <get_mtime>:

int64 get_mtime()
{
    24ba:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24bc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c0:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    24c2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c4:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    24c8:	2501                	sext.w	a0,a0
    24ca:	ed01                	bnez	a0,24e2 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    24cc:	6722                	ld	a4,8(sp)
    24ce:	3e800793          	li	a5,1000
    24d2:	6682                	ld	a3,0(sp)
    24d4:	02f75733          	divu	a4,a4,a5
    24d8:	02d78533          	mul	a0,a5,a3
    24dc:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24de:	0141                	addi	sp,sp,16
    24e0:	8082                	ret
	return -1;
    24e2:	557d                	li	a0,-1
    24e4:	bfed                	j	24de <get_mtime+0x24>

00000000000024e6 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24e6:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ea:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24ee:	2501                	sext.w	a0,a0
    24f0:	8082                	ret

00000000000024f2 <sleep>:

int sleep(unsigned long long time)
{
    24f2:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24f4:	880a                	mv	a6,sp
{
    24f6:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24f8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24fc:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24fe:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2500:	00000073          	ecall
	if (err == 0) {
    2504:	2501                	sext.w	a0,a0
    2506:	ed31                	bnez	a0,2562 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2508:	6722                	ld	a4,8(sp)
    250a:	3e800793          	li	a5,1000
    250e:	6682                	ld	a3,0(sp)
    2510:	02f75733          	divu	a4,a4,a5
    2514:	02d787b3          	mul	a5,a5,a3
    2518:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    251a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    251e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2520:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2522:	00000073          	ecall
	if (err == 0) {
    2526:	2501                	sext.w	a0,a0
    2528:	e915                	bnez	a0,255c <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    252a:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    252c:	3e800693          	li	a3,1000
    2530:	a819                	j	2546 <sleep+0x54>
	__asm_syscall("r"(a7))
    2532:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2536:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    253a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    253c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    253e:	00000073          	ecall
	if (err == 0) {
    2542:	2501                	sext.w	a0,a0
    2544:	ed01                	bnez	a0,255c <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2546:	6722                	ld	a4,8(sp)
    2548:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    254a:	07c00893          	li	a7,124
    254e:	02d75733          	divu	a4,a4,a3
    2552:	02f687b3          	mul	a5,a3,a5
    2556:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2558:	fcc7ede3          	bltu	a5,a2,2532 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    255c:	4501                	li	a0,0
    255e:	0141                	addi	sp,sp,16
    2560:	8082                	ret
    2562:	57fd                	li	a5,-1
    2564:	bf5d                	j	251a <sleep+0x28>

0000000000002566 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2566:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    256a:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    256e:	2501                	sext.w	a0,a0
    2570:	8082                	ret

0000000000002572 <set_priority>:
	register long a7 __asm__("a7") = n;
    2572:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2576:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    257a:	2501                	sext.w	a0,a0
    257c:	8082                	ret

000000000000257e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    257e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2582:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2586:	2501                	sext.w	a0,a0
    2588:	8082                	ret

000000000000258a <munmap>:
	register long a7 __asm__("a7") = n;
    258a:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258e:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2592:	2501                	sext.w	a0,a0
    2594:	8082                	ret

0000000000002596 <wait>:

int wait(int *code)
{
    2596:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2598:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    259c:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259e:	00000073          	ecall
	return waitpid(-1, code);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <spawn>:
	register long a7 __asm__("a7") = n;
    25a6:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25aa:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25ae:	2501                	sext.w	a0,a0
    25b0:	8082                	ret

00000000000025b2 <pipe>:
	register long a7 __asm__("a7") = n;
    25b2:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25b6:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25ba:	2501                	sext.w	a0,a0
    25bc:	8082                	ret

00000000000025be <mailread>:
	register long a7 __asm__("a7") = n;
    25be:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c2:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    25c6:	2501                	sext.w	a0,a0
    25c8:	8082                	ret

00000000000025ca <mailwrite>:
	register long a7 __asm__("a7") = n;
    25ca:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ce:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    25d2:	2501                	sext.w	a0,a0
    25d4:	8082                	ret

00000000000025d6 <fstat>:
	register long a7 __asm__("a7") = n;
    25d6:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25da:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25de:	2501                	sext.w	a0,a0
    25e0:	8082                	ret

00000000000025e2 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25e2:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25e4:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25e8:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25ea:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25ee:	2501                	sext.w	a0,a0
    25f0:	8082                	ret

00000000000025f2 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25f2:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25f4:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25f8:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25fa:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <link>:

int link(char *old_path, char *new_path)
{
    2602:	87aa                	mv	a5,a0
    2604:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2606:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    260a:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    260e:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2610:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2614:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2616:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    261a:	2501                	sext.w	a0,a0
    261c:	8082                	ret

000000000000261e <unlink>:

int unlink(char *path)
{
    261e:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2620:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2624:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2628:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    262a:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    262e:	2501                	sext.w	a0,a0
    2630:	8082                	ret

0000000000002632 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2632:	00000797          	auipc	a5,0x0
    2636:	3967b783          	ld	a5,918(a5) # 29c8 <_GLOBAL_OFFSET_TABLE_+0x8>
    263a:	439c                	lw	a5,0(a5)
    263c:	c799                	beqz	a5,264a <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    263e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2642:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret
{
    264a:	1101                	addi	sp,sp,-32
    264c:	ec06                	sd	ra,24(sp)
    264e:	e42e                	sd	a1,8(sp)
    2650:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2652:	fe7fe0ef          	jal	ra,1638 <enable_thread_io_buffer>
    2656:	65a2                	ld	a1,8(sp)
    2658:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    265a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    265e:	00000073          	ecall
}
    2662:	60e2                	ld	ra,24(sp)
    2664:	2501                	sext.w	a0,a0
    2666:	6105                	addi	sp,sp,32
    2668:	8082                	ret

000000000000266a <gettid>:
	register long a7 __asm__("a7") = n;
    266a:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    266e:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2672:	2501                	sext.w	a0,a0
    2674:	8082                	ret

0000000000002676 <waittid>:

int waittid(int tid)
{
    2676:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2678:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    267c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2680:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2682:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2684:	00e51e63          	bne	a0,a4,26a0 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2688:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    268c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2690:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2694:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2696:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    269a:	2501                	sext.w	a0,a0
	while (ret == -2) {
    269c:	fee506e3          	beq	a0,a4,2688 <waittid+0x12>
	}
	return ret;
}
    26a0:	8082                	ret

00000000000026a2 <mutex_create>:
	register long a7 __asm__("a7") = n;
    26a2:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26a6:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26a8:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26b0:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26b4:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26b6:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <mutex_lock>:
	register long a7 __asm__("a7") = n;
    26be:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    26c2:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    26ca:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    26d6:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    26da:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26e2:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26e6:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26ea:	2501                	sext.w	a0,a0
    26ec:	8082                	ret

00000000000026ee <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26ee:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26f2:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26f6:	2501                	sext.w	a0,a0
    26f8:	8082                	ret

00000000000026fa <condvar_create>:
	register long a7 __asm__("a7") = n;
    26fa:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26fe:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2702:	2501                	sext.w	a0,a0
    2704:	8082                	ret

0000000000002706 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2706:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    270a:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    270e:	2501                	sext.w	a0,a0
    2710:	8082                	ret

0000000000002712 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2712:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2716:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    271a:	2501                	sext.w	a0,a0
    271c:	8082                	ret

000000000000271e <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    271e:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2722:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2726:	2501                	sext.w	a0,a0
    2728:	8082                	ret
