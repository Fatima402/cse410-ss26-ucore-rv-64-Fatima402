
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch4_unmap0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	ac31                	j	121c <__start_main>

0000000000001002 <main>:
/*
理想结果：输出 Test 04_5 ummap OK!
*/

int main()
{
    1002:	7139                	addi	sp,sp,-64
	uint64 start = 0x10000000;
	uint64 len = 4096;
	int prot = 3;
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1004:	577d                	li	a4,-1
    1006:	4681                	li	a3,0
    1008:	460d                	li	a2,3
    100a:	6585                	lui	a1,0x1
    100c:	10000537          	lui	a0,0x10000
{
    1010:	fc06                	sd	ra,56(sp)
    1012:	f822                	sd	s0,48(sp)
    1014:	f426                	sd	s1,40(sp)
    1016:	f04a                	sd	s2,32(sp)
    1018:	ec4e                	sd	s3,24(sp)
    101a:	e852                	sd	s4,16(sp)
    101c:	e456                	sd	s5,8(sp)
    101e:	e05a                	sd	s6,0(sp)
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    1020:	6b6010ef          	jal	ra,26d6 <mmap>
    1024:	e569                	bnez	a0,10ee <main+0xec>
	assert_eq(mmap((void *)(start + len), len * 2, prot, MAP_ANONYMOUS,
    1026:	577d                	li	a4,-1
    1028:	4681                	li	a3,0
    102a:	460d                	li	a2,3
    102c:	6589                	lui	a1,0x2
    102e:	10001537          	lui	a0,0x10001
    1032:	6a4010ef          	jal	ra,26d6 <mmap>
    1036:	18051d63          	bnez	a0,11d0 <main+0x1ce>
		       -1), 0);
	assert_eq(munmap((void *)start, len), 0);
    103a:	6585                	lui	a1,0x1
    103c:	10000537          	lui	a0,0x10000
    1040:	6a2010ef          	jal	ra,26e2 <munmap>
    1044:	14051363          	bnez	a0,118a <main+0x188>
	assert_eq(mmap((void *)(start - len), len + 1, prot, MAP_ANONYMOUS,
    1048:	6405                	lui	s0,0x1
    104a:	577d                	li	a4,-1
    104c:	4681                	li	a3,0
    104e:	460d                	li	a2,3
    1050:	00140593          	addi	a1,s0,1 # 1001 <_start+0x1>
    1054:	0ffff537          	lui	a0,0xffff
    1058:	67e010ef          	jal	ra,26d6 <mmap>
    105c:	0c051f63          	bnez	a0,113a <main+0x138>
{
    1060:	0ffff7b7          	lui	a5,0xffff
		       -1), 0);
	for (uint64 i = (start - len); i < (start + len * 3); ++i) {
    1064:	10003737          	lui	a4,0x10003
		uint8 *addr = (uint8 *)i;
		*addr = (uint8)i;
    1068:	00f78023          	sb	a5,0(a5) # ffff000 <.got.plt+0xfffc4a8>
	for (uint64 i = (start - len); i < (start + len * 3); ++i) {
    106c:	0785                	addi	a5,a5,1
    106e:	fee79de3          	bne	a5,a4,1068 <main+0x66>
	}
	for (uint64 i = (start - len); i < (start + len * 3); ++i) {
    1072:	0ffff437          	lui	s0,0xffff
		uint8 *addr = (uint8 *)i;
		assert_eq(*addr, (uint8)i);
    1076:	00002b17          	auipc	s6,0x2
    107a:	812b0b13          	addi	s6,s6,-2030 # 2888 <enable_deadlock_detect+0x12>
    107e:	00002a97          	auipc	s5,0x2
    1082:	852a8a93          	addi	s5,s5,-1966 # 28d0 <enable_deadlock_detect+0x5a>
    1086:	00002a17          	auipc	s4,0x2
    108a:	852a0a13          	addi	s4,s4,-1966 # 28d8 <enable_deadlock_detect+0x62>
	for (uint64 i = (start - len); i < (start + len * 3); ++i) {
    108e:	100039b7          	lui	s3,0x10003
		assert_eq(*addr, (uint8)i);
    1092:	00044783          	lbu	a5,0(s0) # ffff000 <.got.plt+0xfffc4a8>
    1096:	0ff47493          	zext.b	s1,s0
    109a:	02978663          	beq	a5,s1,10c6 <main+0xc4>
    109e:	50a010ef          	jal	ra,25a8 <getpid>
    10a2:	892a                	mv	s2,a0
    10a4:	855a                	mv	a0,s6
    10a6:	3d8010ef          	jal	ra,247e <basename>
    10aa:	00044803          	lbu	a6,0(s0)
    10ae:	872a                	mv	a4,a0
    10b0:	88a6                	mv	a7,s1
    10b2:	8552                	mv	a0,s4
    10b4:	47ed                	li	a5,27
    10b6:	86ca                	mv	a3,s2
    10b8:	8656                	mv	a2,s5
    10ba:	45fd                	li	a1,31
    10bc:	2ba000ef          	jal	ra,1376 <printf>
    10c0:	557d                	li	a0,-1
    10c2:	516010ef          	jal	ra,25d8 <exit>
	for (uint64 i = (start - len); i < (start + len * 3); ++i) {
    10c6:	0405                	addi	s0,s0,1
    10c8:	fd3415e3          	bne	s0,s3,1092 <main+0x90>
	}
	puts("Test 04_4 ummap OK!");
    10cc:	00002517          	auipc	a0,0x2
    10d0:	84450513          	addi	a0,a0,-1980 # 2910 <enable_deadlock_detect+0x9a>
    10d4:	1b9000ef          	jal	ra,1a8c <puts>
	return 0;
    10d8:	70e2                	ld	ra,56(sp)
    10da:	7442                	ld	s0,48(sp)
    10dc:	74a2                	ld	s1,40(sp)
    10de:	7902                	ld	s2,32(sp)
    10e0:	69e2                	ld	s3,24(sp)
    10e2:	6a42                	ld	s4,16(sp)
    10e4:	6aa2                	ld	s5,8(sp)
    10e6:	6b02                	ld	s6,0(sp)
    10e8:	4501                	li	a0,0
    10ea:	6121                	addi	sp,sp,64
    10ec:	8082                	ret
	assert_eq(0, mmap((void *)start, len, prot, MAP_ANONYMOUS, -1));
    10ee:	4ba010ef          	jal	ra,25a8 <getpid>
    10f2:	842a                	mv	s0,a0
    10f4:	00001517          	auipc	a0,0x1
    10f8:	79450513          	addi	a0,a0,1940 # 2888 <enable_deadlock_detect+0x12>
    10fc:	382010ef          	jal	ra,247e <basename>
    1100:	84aa                	mv	s1,a0
    1102:	577d                	li	a4,-1
    1104:	4681                	li	a3,0
    1106:	460d                	li	a2,3
    1108:	6585                	lui	a1,0x1
    110a:	10000537          	lui	a0,0x10000
    110e:	5c8010ef          	jal	ra,26d6 <mmap>
    1112:	88aa                	mv	a7,a0
    1114:	4801                	li	a6,0
    1116:	00001517          	auipc	a0,0x1
    111a:	7c250513          	addi	a0,a0,1986 # 28d8 <enable_deadlock_detect+0x62>
    111e:	47bd                	li	a5,15
    1120:	8726                	mv	a4,s1
    1122:	86a2                	mv	a3,s0
    1124:	00001617          	auipc	a2,0x1
    1128:	7ac60613          	addi	a2,a2,1964 # 28d0 <enable_deadlock_detect+0x5a>
    112c:	45fd                	li	a1,31
    112e:	248000ef          	jal	ra,1376 <printf>
    1132:	557d                	li	a0,-1
    1134:	4a4010ef          	jal	ra,25d8 <exit>
    1138:	b5fd                	j	1026 <main+0x24>
	assert_eq(mmap((void *)(start - len), len + 1, prot, MAP_ANONYMOUS,
    113a:	46e010ef          	jal	ra,25a8 <getpid>
    113e:	84aa                	mv	s1,a0
    1140:	00001517          	auipc	a0,0x1
    1144:	74850513          	addi	a0,a0,1864 # 2888 <enable_deadlock_detect+0x12>
    1148:	336010ef          	jal	ra,247e <basename>
    114c:	87aa                	mv	a5,a0
    114e:	00140593          	addi	a1,s0,1
    1152:	577d                	li	a4,-1
    1154:	4681                	li	a3,0
    1156:	460d                	li	a2,3
    1158:	0ffff537          	lui	a0,0xffff
    115c:	843e                	mv	s0,a5
    115e:	578010ef          	jal	ra,26d6 <mmap>
    1162:	882a                	mv	a6,a0
    1164:	4881                	li	a7,0
    1166:	00001517          	auipc	a0,0x1
    116a:	77250513          	addi	a0,a0,1906 # 28d8 <enable_deadlock_detect+0x62>
    116e:	47cd                	li	a5,19
    1170:	8722                	mv	a4,s0
    1172:	86a6                	mv	a3,s1
    1174:	00001617          	auipc	a2,0x1
    1178:	75c60613          	addi	a2,a2,1884 # 28d0 <enable_deadlock_detect+0x5a>
    117c:	45fd                	li	a1,31
    117e:	1f8000ef          	jal	ra,1376 <printf>
    1182:	557d                	li	a0,-1
    1184:	454010ef          	jal	ra,25d8 <exit>
    1188:	bde1                	j	1060 <main+0x5e>
	assert_eq(munmap((void *)start, len), 0);
    118a:	41e010ef          	jal	ra,25a8 <getpid>
    118e:	842a                	mv	s0,a0
    1190:	00001517          	auipc	a0,0x1
    1194:	6f850513          	addi	a0,a0,1784 # 2888 <enable_deadlock_detect+0x12>
    1198:	2e6010ef          	jal	ra,247e <basename>
    119c:	84aa                	mv	s1,a0
    119e:	6585                	lui	a1,0x1
    11a0:	10000537          	lui	a0,0x10000
    11a4:	53e010ef          	jal	ra,26e2 <munmap>
    11a8:	882a                	mv	a6,a0
    11aa:	4881                	li	a7,0
    11ac:	00001517          	auipc	a0,0x1
    11b0:	72c50513          	addi	a0,a0,1836 # 28d8 <enable_deadlock_detect+0x62>
    11b4:	47c9                	li	a5,18
    11b6:	8726                	mv	a4,s1
    11b8:	86a2                	mv	a3,s0
    11ba:	00001617          	auipc	a2,0x1
    11be:	71660613          	addi	a2,a2,1814 # 28d0 <enable_deadlock_detect+0x5a>
    11c2:	45fd                	li	a1,31
    11c4:	1b2000ef          	jal	ra,1376 <printf>
    11c8:	557d                	li	a0,-1
    11ca:	40e010ef          	jal	ra,25d8 <exit>
    11ce:	bdad                	j	1048 <main+0x46>
	assert_eq(mmap((void *)(start + len), len * 2, prot, MAP_ANONYMOUS,
    11d0:	3d8010ef          	jal	ra,25a8 <getpid>
    11d4:	842a                	mv	s0,a0
    11d6:	00001517          	auipc	a0,0x1
    11da:	6b250513          	addi	a0,a0,1714 # 2888 <enable_deadlock_detect+0x12>
    11de:	2a0010ef          	jal	ra,247e <basename>
    11e2:	84aa                	mv	s1,a0
    11e4:	577d                	li	a4,-1
    11e6:	4681                	li	a3,0
    11e8:	460d                	li	a2,3
    11ea:	6589                	lui	a1,0x2
    11ec:	10001537          	lui	a0,0x10001
    11f0:	4e6010ef          	jal	ra,26d6 <mmap>
    11f4:	882a                	mv	a6,a0
    11f6:	4881                	li	a7,0
    11f8:	00001517          	auipc	a0,0x1
    11fc:	6e050513          	addi	a0,a0,1760 # 28d8 <enable_deadlock_detect+0x62>
    1200:	47c1                	li	a5,16
    1202:	8726                	mv	a4,s1
    1204:	86a2                	mv	a3,s0
    1206:	00001617          	auipc	a2,0x1
    120a:	6ca60613          	addi	a2,a2,1738 # 28d0 <enable_deadlock_detect+0x5a>
    120e:	45fd                	li	a1,31
    1210:	166000ef          	jal	ra,1376 <printf>
    1214:	557d                	li	a0,-1
    1216:	3c2010ef          	jal	ra,25d8 <exit>
    121a:	b505                	j	103a <main+0x38>

000000000000121c <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    121c:	1141                	addi	sp,sp,-16
    121e:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1220:	de3ff0ef          	jal	ra,1002 <main>
    1224:	3b4010ef          	jal	ra,25d8 <exit>
	return 0;
    1228:	60a2                	ld	ra,8(sp)
    122a:	4501                	li	a0,0
    122c:	0141                	addi	sp,sp,16
    122e:	8082                	ret

0000000000001230 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1230:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1232:	4605                	li	a2,1
    1234:	00f10593          	addi	a1,sp,15
    1238:	4501                	li	a0,0
{
    123a:	ec06                	sd	ra,24(sp)
	char byte = 0;
    123c:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1240:	354010ef          	jal	ra,2594 <read>
    1244:	4785                	li	a5,1
    1246:	00f51763          	bne	a0,a5,1254 <getchar+0x24>
		return byte;
    124a:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    124e:	60e2                	ld	ra,24(sp)
    1250:	6105                	addi	sp,sp,32
    1252:	8082                	ret
		return EOF;
    1254:	557d                	li	a0,-1
    1256:	bfe5                	j	124e <getchar+0x1e>

0000000000001258 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1258:	00001517          	auipc	a0,0x1
    125c:	7c852503          	lw	a0,1992(a0) # 2a20 <buffer_len>
    1260:	e111                	bnez	a0,1264 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1262:	8082                	ret
{
    1264:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1266:	862a                	mv	a2,a0
    1268:	00001597          	auipc	a1,0x1
    126c:	7c058593          	addi	a1,a1,1984 # 2a28 <buffer>
    1270:	4505                	li	a0,1
{
    1272:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1274:	32a010ef          	jal	ra,259e <write>
}
    1278:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    127a:	2501                	sext.w	a0,a0
}
    127c:	0141                	addi	sp,sp,16
    127e:	8082                	ret

0000000000001280 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1280:	00001797          	auipc	a5,0x1
    1284:	7a07a023          	sw	zero,1952(a5) # 2a20 <buffer_len>
}
    1288:	8082                	ret

000000000000128a <__fflush>:
	if (buffer_len == 0)
    128a:	00001517          	auipc	a0,0x1
    128e:	79652503          	lw	a0,1942(a0) # 2a20 <buffer_len>
    1292:	e511                	bnez	a0,129e <__fflush+0x14>
	buffer_len = 0;
    1294:	00001797          	auipc	a5,0x1
    1298:	7807a623          	sw	zero,1932(a5) # 2a20 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    129c:	8082                	ret
{
    129e:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12a0:	862a                	mv	a2,a0
    12a2:	00001597          	auipc	a1,0x1
    12a6:	78658593          	addi	a1,a1,1926 # 2a28 <buffer>
    12aa:	4505                	li	a0,1
{
    12ac:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12ae:	2f0010ef          	jal	ra,259e <write>
	return r >= 0 ? 0 : r;
    12b2:	0005079b          	sext.w	a5,a0
}
    12b6:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12b8:	0017a793          	slti	a5,a5,1
    12bc:	40f007bb          	negw	a5,a5
    12c0:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    12c2:	00001797          	auipc	a5,0x1
    12c6:	7407af23          	sw	zero,1886(a5) # 2a20 <buffer_len>
	return r >= 0 ? 0 : r;
    12ca:	2501                	sext.w	a0,a0
}
    12cc:	0141                	addi	sp,sp,16
    12ce:	8082                	ret

00000000000012d0 <fflush>:

int fflush(int fd)
{
    12d0:	1101                	addi	sp,sp,-32
    12d2:	e822                	sd	s0,16(sp)
    12d4:	ec06                	sd	ra,24(sp)
    12d6:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    12d8:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    12da:	4401                	li	s0,0
	if (fd == 1) {
    12dc:	00e50863          	beq	a0,a4,12ec <fflush+0x1c>
}
    12e0:	60e2                	ld	ra,24(sp)
    12e2:	8522                	mv	a0,s0
    12e4:	6442                	ld	s0,16(sp)
    12e6:	64a2                	ld	s1,8(sp)
    12e8:	6105                	addi	sp,sp,32
    12ea:	8082                	ret
		if (buffer_lock_enabled == 1) {
    12ec:	00001497          	auipc	s1,0x1
    12f0:	73448493          	addi	s1,s1,1844 # 2a20 <buffer_len>
    12f4:	1084a703          	lw	a4,264(s1)
    12f8:	02a70e63          	beq	a4,a0,1334 <fflush+0x64>
	if (buffer_len == 0)
    12fc:	4080                	lw	s0,0(s1)
    12fe:	c00d                	beqz	s0,1320 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1300:	8622                	mv	a2,s0
    1302:	00001597          	auipc	a1,0x1
    1306:	72658593          	addi	a1,a1,1830 # 2a28 <buffer>
    130a:	294010ef          	jal	ra,259e <write>
	return r >= 0 ? 0 : r;
    130e:	0005079b          	sext.w	a5,a0
    1312:	0017a793          	slti	a5,a5,1
    1316:	40f007bb          	negw	a5,a5
    131a:	8d7d                	and	a0,a0,a5
    131c:	0005041b          	sext.w	s0,a0
}
    1320:	60e2                	ld	ra,24(sp)
    1322:	8522                	mv	a0,s0
    1324:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1326:	00001797          	auipc	a5,0x1
    132a:	6e07ad23          	sw	zero,1786(a5) # 2a20 <buffer_len>
}
    132e:	64a2                	ld	s1,8(sp)
    1330:	6105                	addi	sp,sp,32
    1332:	8082                	ret
			mutex_lock(buffer_lock);
    1334:	10c4a503          	lw	a0,268(s1)
    1338:	4de010ef          	jal	ra,2816 <mutex_lock>
	if (buffer_len == 0)
    133c:	4080                	lw	s0,0(s1)
    133e:	e811                	bnez	s0,1352 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1340:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1344:	00001797          	auipc	a5,0x1
    1348:	6c07ae23          	sw	zero,1756(a5) # 2a20 <buffer_len>
			mutex_unlock(buffer_lock);
    134c:	4d6010ef          	jal	ra,2822 <mutex_unlock>
    1350:	bf41                	j	12e0 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1352:	8622                	mv	a2,s0
    1354:	00001597          	auipc	a1,0x1
    1358:	6d458593          	addi	a1,a1,1748 # 2a28 <buffer>
    135c:	4505                	li	a0,1
    135e:	240010ef          	jal	ra,259e <write>
	return r >= 0 ? 0 : r;
    1362:	0005079b          	sext.w	a5,a0
    1366:	0017a793          	slti	a5,a5,1
    136a:	40f007bb          	negw	a5,a5
    136e:	8d7d                	and	a0,a0,a5
    1370:	0005041b          	sext.w	s0,a0
	return r;
    1374:	b7f1                	j	1340 <fflush+0x70>

0000000000001376 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1376:	7131                	addi	sp,sp,-192
    1378:	e0da                	sd	s6,64(sp)
    137a:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    137c:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    137e:	013c                	addi	a5,sp,136
{
    1380:	f0ca                	sd	s2,96(sp)
    1382:	ecce                	sd	s3,88(sp)
    1384:	e8d2                	sd	s4,80(sp)
    1386:	e4d6                	sd	s5,72(sp)
    1388:	fc86                	sd	ra,120(sp)
    138a:	f8a2                	sd	s0,112(sp)
    138c:	f4a6                	sd	s1,104(sp)
    138e:	89aa                	mv	s3,a0
    1390:	e52e                	sd	a1,136(sp)
    1392:	e932                	sd	a2,144(sp)
    1394:	ed36                	sd	a3,152(sp)
    1396:	f13a                	sd	a4,160(sp)
    1398:	f942                	sd	a6,176(sp)
    139a:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    139c:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    139e:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    13a2:	00001a17          	auipc	s4,0x1
    13a6:	67ea0a13          	addi	s4,s4,1662 # 2a20 <buffer_len>
    13aa:	4a85                	li	s5,1
	buf[i++] = '0';
    13ac:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13b0:	0009c783          	lbu	a5,0(s3) # 10003000 <.got.plt+0x100004a8>
    13b4:	18078663          	beqz	a5,1540 <printf+0x1ca>
    13b8:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13ba:	19278d63          	beq	a5,s2,1554 <printf+0x1de>
    13be:	0015c783          	lbu	a5,1(a1)
    13c2:	0585                	addi	a1,a1,1
    13c4:	fbfd                	bnez	a5,13ba <printf+0x44>
    13c6:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    13c8:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    13cc:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13d0:	1b578863          	beq	a5,s5,1580 <printf+0x20a>
		len = out_unlocked(s, l);
    13d4:	85a2                	mv	a1,s0
    13d6:	854e                	mv	a0,s3
    13d8:	42a000ef          	jal	ra,1802 <out_unlocked>
		out(f, a, l);
		if (l)
    13dc:	1c041063          	bnez	s0,159c <printf+0x226>
			continue;
		if (s[1] == 0)
    13e0:	0014c783          	lbu	a5,1(s1)
    13e4:	14078e63          	beqz	a5,1540 <printf+0x1ca>
			break;
		switch (s[1]) {
    13e8:	07300713          	li	a4,115
    13ec:	1ce78863          	beq	a5,a4,15bc <printf+0x246>
    13f0:	1af76863          	bltu	a4,a5,15a0 <printf+0x22a>
    13f4:	06400713          	li	a4,100
    13f8:	22e78063          	beq	a5,a4,1618 <printf+0x2a2>
    13fc:	07000713          	li	a4,112
    1400:	1ee79563          	bne	a5,a4,15ea <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1404:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1406:	00001797          	auipc	a5,0x1
    140a:	72a78793          	addi	a5,a5,1834 # 2b30 <digits>
	buf[i++] = '0';
    140e:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1412:	6298                	ld	a4,0(a3)
    1414:	06a1                	addi	a3,a3,8
    1416:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1418:	00471393          	slli	t2,a4,0x4
    141c:	00871293          	slli	t0,a4,0x8
    1420:	00c71f93          	slli	t6,a4,0xc
    1424:	01071f13          	slli	t5,a4,0x10
    1428:	01471e93          	slli	t4,a4,0x14
    142c:	01871e13          	slli	t3,a4,0x18
    1430:	01c71893          	slli	a7,a4,0x1c
    1434:	02471813          	slli	a6,a4,0x24
    1438:	02871513          	slli	a0,a4,0x28
    143c:	02c71593          	slli	a1,a4,0x2c
    1440:	03071613          	slli	a2,a4,0x30
    1444:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1448:	03c75413          	srli	s0,a4,0x3c
    144c:	01c7531b          	srliw	t1,a4,0x1c
    1450:	03c3d393          	srli	t2,t2,0x3c
    1454:	03c2d293          	srli	t0,t0,0x3c
    1458:	03cfdf93          	srli	t6,t6,0x3c
    145c:	03cf5f13          	srli	t5,t5,0x3c
    1460:	03cede93          	srli	t4,t4,0x3c
    1464:	03ce5e13          	srli	t3,t3,0x3c
    1468:	03c8d893          	srli	a7,a7,0x3c
    146c:	03c85813          	srli	a6,a6,0x3c
    1470:	9171                	srli	a0,a0,0x3c
    1472:	91f1                	srli	a1,a1,0x3c
    1474:	9271                	srli	a2,a2,0x3c
    1476:	92f1                	srli	a3,a3,0x3c
    1478:	95be                	add	a1,a1,a5
    147a:	963e                	add	a2,a2,a5
    147c:	96be                	add	a3,a3,a5
    147e:	943e                	add	s0,s0,a5
    1480:	93be                	add	t2,t2,a5
    1482:	92be                	add	t0,t0,a5
    1484:	9fbe                	add	t6,t6,a5
    1486:	9f3e                	add	t5,t5,a5
    1488:	9ebe                	add	t4,t4,a5
    148a:	9e3e                	add	t3,t3,a5
    148c:	98be                	add	a7,a7,a5
    148e:	933e                	add	t1,t1,a5
    1490:	983e                	add	a6,a6,a5
    1492:	953e                	add	a0,a0,a5
    1494:	0005c983          	lbu	s3,0(a1)
    1498:	00044403          	lbu	s0,0(s0)
    149c:	00064583          	lbu	a1,0(a2)
    14a0:	0003c383          	lbu	t2,0(t2)
    14a4:	0006c603          	lbu	a2,0(a3)
    14a8:	0002c283          	lbu	t0,0(t0)
    14ac:	000fcf83          	lbu	t6,0(t6)
    14b0:	000f4f03          	lbu	t5,0(t5)
    14b4:	000ece83          	lbu	t4,0(t4)
    14b8:	000e4e03          	lbu	t3,0(t3)
    14bc:	0008c883          	lbu	a7,0(a7)
    14c0:	00034303          	lbu	t1,0(t1)
    14c4:	00084803          	lbu	a6,0(a6)
    14c8:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    14cc:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    14d0:	92f1                	srli	a3,a3,0x3c
    14d2:	8b3d                	andi	a4,a4,15
    14d4:	96be                	add	a3,a3,a5
    14d6:	97ba                	add	a5,a5,a4
    14d8:	00810d23          	sb	s0,26(sp)
    14dc:	00710da3          	sb	t2,27(sp)
    14e0:	00510e23          	sb	t0,28(sp)
    14e4:	01f10ea3          	sb	t6,29(sp)
    14e8:	01e10f23          	sb	t5,30(sp)
    14ec:	01d10fa3          	sb	t4,31(sp)
    14f0:	03c10023          	sb	t3,32(sp)
    14f4:	031100a3          	sb	a7,33(sp)
    14f8:	02610123          	sb	t1,34(sp)
    14fc:	030101a3          	sb	a6,35(sp)
    1500:	02a10223          	sb	a0,36(sp)
    1504:	033102a3          	sb	s3,37(sp)
    1508:	02b10323          	sb	a1,38(sp)
    150c:	02c103a3          	sb	a2,39(sp)
    1510:	0006c683          	lbu	a3,0(a3)
    1514:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1518:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    151c:	02d10423          	sb	a3,40(sp)
    1520:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1524:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1528:	11578263          	beq	a5,s5,162c <printf+0x2b6>
		len = out_unlocked(s, l);
    152c:	45c9                	li	a1,18
    152e:	0828                	addi	a0,sp,24
    1530:	2d2000ef          	jal	ra,1802 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1534:	00248993          	addi	s3,s1,2
		if (!*s)
    1538:	0009c783          	lbu	a5,0(s3)
    153c:	e6079ee3          	bnez	a5,13b8 <printf+0x42>
	}
	va_end(ap);
    1540:	70e6                	ld	ra,120(sp)
    1542:	7446                	ld	s0,112(sp)
    1544:	74a6                	ld	s1,104(sp)
    1546:	7906                	ld	s2,96(sp)
    1548:	69e6                	ld	s3,88(sp)
    154a:	6a46                	ld	s4,80(sp)
    154c:	6aa6                	ld	s5,72(sp)
    154e:	6b06                	ld	s6,64(sp)
    1550:	6129                	addi	sp,sp,192
    1552:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1554:	0005c783          	lbu	a5,0(a1)
    1558:	84ae                	mv	s1,a1
    155a:	01278963          	beq	a5,s2,156c <printf+0x1f6>
    155e:	b5ad                	j	13c8 <printf+0x52>
    1560:	0024c783          	lbu	a5,2(s1)
    1564:	0585                	addi	a1,a1,1
    1566:	0489                	addi	s1,s1,2
    1568:	e72790e3          	bne	a5,s2,13c8 <printf+0x52>
    156c:	0014c783          	lbu	a5,1(s1)
    1570:	ff2788e3          	beq	a5,s2,1560 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1574:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1578:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    157c:	e5579ce3          	bne	a5,s5,13d4 <printf+0x5e>
		mutex_lock(buffer_lock);
    1580:	10ca2503          	lw	a0,268(s4)
    1584:	292010ef          	jal	ra,2816 <mutex_lock>
		len = out_unlocked(s, l);
    1588:	85a2                	mv	a1,s0
    158a:	854e                	mv	a0,s3
    158c:	276000ef          	jal	ra,1802 <out_unlocked>
		mutex_unlock(buffer_lock);
    1590:	10ca2503          	lw	a0,268(s4)
    1594:	28e010ef          	jal	ra,2822 <mutex_unlock>
		if (l)
    1598:	e40404e3          	beqz	s0,13e0 <printf+0x6a>
    159c:	89a6                	mv	s3,s1
    159e:	bd09                	j	13b0 <printf+0x3a>
		switch (s[1]) {
    15a0:	07800713          	li	a4,120
    15a4:	04e79363          	bne	a5,a4,15ea <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    15a8:	67c2                	ld	a5,16(sp)
    15aa:	45c1                	li	a1,16
		s += 2;
    15ac:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15b0:	4388                	lw	a0,0(a5)
    15b2:	07a1                	addi	a5,a5,8
    15b4:	e83e                	sd	a5,16(sp)
    15b6:	5f8000ef          	jal	ra,1bae <printint.constprop.0>
		s += 2;
    15ba:	bfbd                	j	1538 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    15bc:	67c2                	ld	a5,16(sp)
    15be:	6380                	ld	s0,0(a5)
    15c0:	07a1                	addi	a5,a5,8
    15c2:	e83e                	sd	a5,16(sp)
    15c4:	1c040163          	beqz	s0,1786 <printf+0x410>
			l = strnlen(a, 200);
    15c8:	0c800593          	li	a1,200
    15cc:	8522                	mv	a0,s0
    15ce:	3f7000ef          	jal	ra,21c4 <strnlen>
	if (buffer_lock_enabled == 1) {
    15d2:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    15d6:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    15da:	19578663          	beq	a5,s5,1766 <printf+0x3f0>
		len = out_unlocked(s, l);
    15de:	8522                	mv	a0,s0
    15e0:	222000ef          	jal	ra,1802 <out_unlocked>
		s += 2;
    15e4:	00248993          	addi	s3,s1,2
    15e8:	bf81                	j	1538 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    15ea:	108a2783          	lw	a5,264(s4)
	char byte = c;
    15ee:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    15f2:	0f578663          	beq	a5,s5,16de <printf+0x368>
		len = out_unlocked(s, l);
    15f6:	0828                	addi	a0,sp,24
    15f8:	316000ef          	jal	ra,190e <out_unlocked.constprop.0>
			putchar(s[1]);
    15fc:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1600:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1604:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1608:	05578163          	beq	a5,s5,164a <printf+0x2d4>
		len = out_unlocked(s, l);
    160c:	0828                	addi	a0,sp,24
    160e:	300000ef          	jal	ra,190e <out_unlocked.constprop.0>
		s += 2;
    1612:	00248993          	addi	s3,s1,2
    1616:	b70d                	j	1538 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1618:	67c2                	ld	a5,16(sp)
    161a:	45a9                	li	a1,10
		s += 2;
    161c:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1620:	4388                	lw	a0,0(a5)
    1622:	07a1                	addi	a5,a5,8
    1624:	e83e                	sd	a5,16(sp)
    1626:	588000ef          	jal	ra,1bae <printint.constprop.0>
		s += 2;
    162a:	b739                	j	1538 <printf+0x1c2>
		mutex_lock(buffer_lock);
    162c:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1630:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1634:	1e2010ef          	jal	ra,2816 <mutex_lock>
		len = out_unlocked(s, l);
    1638:	45c9                	li	a1,18
    163a:	0828                	addi	a0,sp,24
    163c:	1c6000ef          	jal	ra,1802 <out_unlocked>
		mutex_unlock(buffer_lock);
    1640:	10ca2503          	lw	a0,268(s4)
    1644:	1de010ef          	jal	ra,2822 <mutex_unlock>
		s += 2;
    1648:	bdc5                	j	1538 <printf+0x1c2>
		mutex_lock(buffer_lock);
    164a:	10ca2503          	lw	a0,268(s4)
    164e:	1c8010ef          	jal	ra,2816 <mutex_lock>
		buffer[buffer_len++] = c;
    1652:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1656:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    165a:	0017861b          	addiw	a2,a5,1
    165e:	97d2                	add	a5,a5,s4
    1660:	00ca2023          	sw	a2,0(s4)
    1664:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1668:	00c6cc63          	blt	a3,a2,1680 <printf+0x30a>
    166c:	47a9                	li	a5,10
    166e:	06f40663          	beq	s0,a5,16da <printf+0x364>
		mutex_unlock(buffer_lock);
    1672:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1676:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    167a:	1a8010ef          	jal	ra,2822 <mutex_unlock>
		s += 2;
    167e:	bd6d                	j	1538 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1680:	10000793          	li	a5,256
    1684:	00f61e63          	bne	a2,a5,16a0 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1688:	00001597          	auipc	a1,0x1
    168c:	3a058593          	addi	a1,a1,928 # 2a28 <buffer>
    1690:	4505                	li	a0,1
    1692:	70d000ef          	jal	ra,259e <write>
	buffer_len = 0;
    1696:	00001797          	auipc	a5,0x1
    169a:	3807a523          	sw	zero,906(a5) # 2a20 <buffer_len>
			if (r < 0) {
    169e:	bfd1                	j	1672 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    16a0:	709000ef          	jal	ra,25a8 <getpid>
    16a4:	842a                	mv	s0,a0
    16a6:	00001517          	auipc	a0,0x1
    16aa:	28a50513          	addi	a0,a0,650 # 2930 <enable_deadlock_detect+0xba>
    16ae:	5d1000ef          	jal	ra,247e <basename>
    16b2:	872a                	mv	a4,a0
    16b4:	00001617          	auipc	a2,0x1
    16b8:	21c60613          	addi	a2,a2,540 # 28d0 <enable_deadlock_detect+0x5a>
    16bc:	05400793          	li	a5,84
    16c0:	86a2                	mv	a3,s0
    16c2:	45fd                	li	a1,31
    16c4:	00001517          	auipc	a0,0x1
    16c8:	2ac50513          	addi	a0,a0,684 # 2970 <enable_deadlock_detect+0xfa>
    16cc:	cabff0ef          	jal	ra,1376 <printf>
    16d0:	557d                	li	a0,-1
    16d2:	707000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    16d6:	000a2603          	lw	a2,0(s4)
    16da:	de41                	beqz	a2,1672 <printf+0x2fc>
    16dc:	b775                	j	1688 <printf+0x312>
		mutex_lock(buffer_lock);
    16de:	10ca2503          	lw	a0,268(s4)
    16e2:	134010ef          	jal	ra,2816 <mutex_lock>
		buffer[buffer_len++] = c;
    16e6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ea:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    16ee:	0017861b          	addiw	a2,a5,1
    16f2:	97d2                	add	a5,a5,s4
    16f4:	00ca2023          	sw	a2,0(s4)
    16f8:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16fc:	02c6d163          	bge	a3,a2,171e <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1700:	10000793          	li	a5,256
    1704:	02f61263          	bne	a2,a5,1728 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1708:	00001597          	auipc	a1,0x1
    170c:	32058593          	addi	a1,a1,800 # 2a28 <buffer>
    1710:	4505                	li	a0,1
    1712:	68d000ef          	jal	ra,259e <write>
	buffer_len = 0;
    1716:	00001797          	auipc	a5,0x1
    171a:	3007a523          	sw	zero,778(a5) # 2a20 <buffer_len>
		mutex_unlock(buffer_lock);
    171e:	10ca2503          	lw	a0,268(s4)
    1722:	100010ef          	jal	ra,2822 <mutex_unlock>
    1726:	bdd9                	j	15fc <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1728:	681000ef          	jal	ra,25a8 <getpid>
    172c:	842a                	mv	s0,a0
    172e:	00001517          	auipc	a0,0x1
    1732:	20250513          	addi	a0,a0,514 # 2930 <enable_deadlock_detect+0xba>
    1736:	549000ef          	jal	ra,247e <basename>
    173a:	872a                	mv	a4,a0
    173c:	00001617          	auipc	a2,0x1
    1740:	19460613          	addi	a2,a2,404 # 28d0 <enable_deadlock_detect+0x5a>
    1744:	05400793          	li	a5,84
    1748:	86a2                	mv	a3,s0
    174a:	45fd                	li	a1,31
    174c:	00001517          	auipc	a0,0x1
    1750:	22450513          	addi	a0,a0,548 # 2970 <enable_deadlock_detect+0xfa>
    1754:	c23ff0ef          	jal	ra,1376 <printf>
    1758:	557d                	li	a0,-1
    175a:	67f000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    175e:	000a2603          	lw	a2,0(s4)
    1762:	de55                	beqz	a2,171e <printf+0x3a8>
    1764:	b755                	j	1708 <printf+0x392>
		mutex_lock(buffer_lock);
    1766:	10ca2503          	lw	a0,268(s4)
    176a:	e42e                	sd	a1,8(sp)
		s += 2;
    176c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1770:	0a6010ef          	jal	ra,2816 <mutex_lock>
		len = out_unlocked(s, l);
    1774:	65a2                	ld	a1,8(sp)
    1776:	8522                	mv	a0,s0
    1778:	08a000ef          	jal	ra,1802 <out_unlocked>
		mutex_unlock(buffer_lock);
    177c:	10ca2503          	lw	a0,268(s4)
    1780:	0a2010ef          	jal	ra,2822 <mutex_unlock>
		s += 2;
    1784:	bb55                	j	1538 <printf+0x1c2>
				a = "(null)";
    1786:	00001417          	auipc	s0,0x1
    178a:	1a240413          	addi	s0,s0,418 # 2928 <enable_deadlock_detect+0xb2>
    178e:	bd2d                	j	15c8 <printf+0x252>

0000000000001790 <enable_thread_io_buffer>:
{
    1790:	1101                	addi	sp,sp,-32
    1792:	e822                	sd	s0,16(sp)
    1794:	ec06                	sd	ra,24(sp)
    1796:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1798:	00001417          	auipc	s0,0x1
    179c:	28840413          	addi	s0,s0,648 # 2a20 <buffer_len>
    17a0:	05a010ef          	jal	ra,27fa <mutex_create>
    17a4:	10a42623          	sw	a0,268(s0)
    17a8:	00054a63          	bltz	a0,17bc <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17ac:	4785                	li	a5,1
}
    17ae:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17b0:	10f42423          	sw	a5,264(s0)
}
    17b4:	6442                	ld	s0,16(sp)
    17b6:	64a2                	ld	s1,8(sp)
    17b8:	6105                	addi	sp,sp,32
    17ba:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    17bc:	5ed000ef          	jal	ra,25a8 <getpid>
    17c0:	84aa                	mv	s1,a0
    17c2:	00001517          	auipc	a0,0x1
    17c6:	16e50513          	addi	a0,a0,366 # 2930 <enable_deadlock_detect+0xba>
    17ca:	4b5000ef          	jal	ra,247e <basename>
    17ce:	872a                	mv	a4,a0
    17d0:	04800793          	li	a5,72
    17d4:	86a6                	mv	a3,s1
    17d6:	00001517          	auipc	a0,0x1
    17da:	1da50513          	addi	a0,a0,474 # 29b0 <enable_deadlock_detect+0x13a>
    17de:	00001617          	auipc	a2,0x1
    17e2:	0f260613          	addi	a2,a2,242 # 28d0 <enable_deadlock_detect+0x5a>
    17e6:	45fd                	li	a1,31
    17e8:	b8fff0ef          	jal	ra,1376 <printf>
    17ec:	557d                	li	a0,-1
    17ee:	5eb000ef          	jal	ra,25d8 <exit>
	buffer_lock_enabled = 1;
    17f2:	4785                	li	a5,1
}
    17f4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17f6:	10f42423          	sw	a5,264(s0)
}
    17fa:	6442                	ld	s0,16(sp)
    17fc:	64a2                	ld	s1,8(sp)
    17fe:	6105                	addi	sp,sp,32
    1800:	8082                	ret

0000000000001802 <out_unlocked>:
{
    1802:	7159                	addi	sp,sp,-112
    1804:	f486                	sd	ra,104(sp)
    1806:	f0a2                	sd	s0,96(sp)
    1808:	eca6                	sd	s1,88(sp)
    180a:	e8ca                	sd	s2,80(sp)
    180c:	e4ce                	sd	s3,72(sp)
    180e:	e0d2                	sd	s4,64(sp)
    1810:	fc56                	sd	s5,56(sp)
    1812:	f85a                	sd	s6,48(sp)
    1814:	f45e                	sd	s7,40(sp)
    1816:	f062                	sd	s8,32(sp)
    1818:	ec66                	sd	s9,24(sp)
    181a:	e86a                	sd	s10,16(sp)
    181c:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    181e:	0e058663          	beqz	a1,190a <out_unlocked+0x108>
    1822:	842a                	mv	s0,a0
    1824:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1828:	4981                	li	s3,0
    182a:	00001d17          	auipc	s10,0x1
    182e:	1f6d0d13          	addi	s10,s10,502 # 2a20 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1832:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1836:	00001b17          	auipc	s6,0x1
    183a:	1f2b0b13          	addi	s6,s6,498 # 2a28 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    183e:	10000a93          	li	s5,256
    1842:	00001c97          	auipc	s9,0x1
    1846:	0eec8c93          	addi	s9,s9,238 # 2930 <enable_deadlock_detect+0xba>
    184a:	00001c17          	auipc	s8,0x1
    184e:	086c0c13          	addi	s8,s8,134 # 28d0 <enable_deadlock_detect+0x5a>
    1852:	00001b97          	auipc	s7,0x1
    1856:	11eb8b93          	addi	s7,s7,286 # 2970 <enable_deadlock_detect+0xfa>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    185a:	4a29                	li	s4,10
    185c:	a031                	j	1868 <out_unlocked+0x66>
    185e:	09468863          	beq	a3,s4,18ee <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1862:	0405                	addi	s0,s0,1
    1864:	04848163          	beq	s1,s0,18a6 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1868:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    186c:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1870:	0017861b          	addiw	a2,a5,1
    1874:	97ea                	add	a5,a5,s10
    1876:	00cd2023          	sw	a2,0(s10)
    187a:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    187e:	fec950e3          	bge	s2,a2,185e <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1882:	05561263          	bne	a2,s5,18c6 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1886:	85da                	mv	a1,s6
    1888:	4505                	li	a0,1
    188a:	515000ef          	jal	ra,259e <write>
    188e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1890:	00001797          	auipc	a5,0x1
    1894:	1807a823          	sw	zero,400(a5) # 2a20 <buffer_len>
			if (r < 0) {
    1898:	06054763          	bltz	a0,1906 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    189c:	0405                	addi	s0,s0,1
			ret += r;
    189e:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    18a2:	fc8493e3          	bne	s1,s0,1868 <out_unlocked+0x66>
}
    18a6:	70a6                	ld	ra,104(sp)
    18a8:	7406                	ld	s0,96(sp)
    18aa:	64e6                	ld	s1,88(sp)
    18ac:	6946                	ld	s2,80(sp)
    18ae:	6a06                	ld	s4,64(sp)
    18b0:	7ae2                	ld	s5,56(sp)
    18b2:	7b42                	ld	s6,48(sp)
    18b4:	7ba2                	ld	s7,40(sp)
    18b6:	7c02                	ld	s8,32(sp)
    18b8:	6ce2                	ld	s9,24(sp)
    18ba:	6d42                	ld	s10,16(sp)
    18bc:	6da2                	ld	s11,8(sp)
    18be:	854e                	mv	a0,s3
    18c0:	69a6                	ld	s3,72(sp)
    18c2:	6165                	addi	sp,sp,112
    18c4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18c6:	4e3000ef          	jal	ra,25a8 <getpid>
    18ca:	8daa                	mv	s11,a0
    18cc:	8566                	mv	a0,s9
    18ce:	3b1000ef          	jal	ra,247e <basename>
    18d2:	872a                	mv	a4,a0
    18d4:	8662                	mv	a2,s8
    18d6:	05400793          	li	a5,84
    18da:	86ee                	mv	a3,s11
    18dc:	45fd                	li	a1,31
    18de:	855e                	mv	a0,s7
    18e0:	a97ff0ef          	jal	ra,1376 <printf>
    18e4:	557d                	li	a0,-1
    18e6:	4f3000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    18ea:	000d2603          	lw	a2,0(s10)
    18ee:	da35                	beqz	a2,1862 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    18f0:	85da                	mv	a1,s6
    18f2:	4505                	li	a0,1
    18f4:	4ab000ef          	jal	ra,259e <write>
    18f8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18fa:	00001797          	auipc	a5,0x1
    18fe:	1207a323          	sw	zero,294(a5) # 2a20 <buffer_len>
			if (r < 0) {
    1902:	f8055de3          	bgez	a0,189c <out_unlocked+0x9a>
    1906:	89aa                	mv	s3,a0
    1908:	bf79                	j	18a6 <out_unlocked+0xa4>
	int ret = 0;
    190a:	4981                	li	s3,0
    190c:	bf69                	j	18a6 <out_unlocked+0xa4>

000000000000190e <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    190e:	1101                	addi	sp,sp,-32
    1910:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1912:	00001497          	auipc	s1,0x1
    1916:	10e48493          	addi	s1,s1,270 # 2a20 <buffer_len>
    191a:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    191c:	ec06                	sd	ra,24(sp)
    191e:	e822                	sd	s0,16(sp)
		char c = s[i];
    1920:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1924:	0017861b          	addiw	a2,a5,1
    1928:	97a6                	add	a5,a5,s1
    192a:	00e78423          	sb	a4,8(a5)
    192e:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1930:	0ff00793          	li	a5,255
    1934:	00c7cc63          	blt	a5,a2,194c <out_unlocked.constprop.0+0x3e>
    1938:	47a9                	li	a5,10
    193a:	06f70c63          	beq	a4,a5,19b2 <out_unlocked.constprop.0+0xa4>
    193e:	4601                	li	a2,0
}
    1940:	60e2                	ld	ra,24(sp)
    1942:	6442                	ld	s0,16(sp)
    1944:	64a2                	ld	s1,8(sp)
    1946:	8532                	mv	a0,a2
    1948:	6105                	addi	sp,sp,32
    194a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    194c:	10000793          	li	a5,256
    1950:	02f61563          	bne	a2,a5,197a <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1954:	00001597          	auipc	a1,0x1
    1958:	0d458593          	addi	a1,a1,212 # 2a28 <buffer>
    195c:	4505                	li	a0,1
    195e:	441000ef          	jal	ra,259e <write>
}
    1962:	60e2                	ld	ra,24(sp)
    1964:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1966:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    196a:	00001797          	auipc	a5,0x1
    196e:	0a07ab23          	sw	zero,182(a5) # 2a20 <buffer_len>
}
    1972:	64a2                	ld	s1,8(sp)
    1974:	8532                	mv	a0,a2
    1976:	6105                	addi	sp,sp,32
    1978:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    197a:	42f000ef          	jal	ra,25a8 <getpid>
    197e:	842a                	mv	s0,a0
    1980:	00001517          	auipc	a0,0x1
    1984:	fb050513          	addi	a0,a0,-80 # 2930 <enable_deadlock_detect+0xba>
    1988:	2f7000ef          	jal	ra,247e <basename>
    198c:	872a                	mv	a4,a0
    198e:	00001617          	auipc	a2,0x1
    1992:	f4260613          	addi	a2,a2,-190 # 28d0 <enable_deadlock_detect+0x5a>
    1996:	05400793          	li	a5,84
    199a:	86a2                	mv	a3,s0
    199c:	45fd                	li	a1,31
    199e:	00001517          	auipc	a0,0x1
    19a2:	fd250513          	addi	a0,a0,-46 # 2970 <enable_deadlock_detect+0xfa>
    19a6:	9d1ff0ef          	jal	ra,1376 <printf>
    19aa:	557d                	li	a0,-1
    19ac:	42d000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    19b0:	4090                	lw	a2,0(s1)
    19b2:	d659                	beqz	a2,1940 <out_unlocked.constprop.0+0x32>
    19b4:	b745                	j	1954 <out_unlocked.constprop.0+0x46>

00000000000019b6 <putchar>:
{
    19b6:	7139                	addi	sp,sp,-64
    19b8:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19ba:	00001497          	auipc	s1,0x1
    19be:	06648493          	addi	s1,s1,102 # 2a20 <buffer_len>
    19c2:	1084a703          	lw	a4,264(s1)
{
    19c6:	f822                	sd	s0,48(sp)
	char byte = c;
    19c8:	0ff57413          	zext.b	s0,a0
{
    19cc:	fc06                	sd	ra,56(sp)
	char byte = c;
    19ce:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    19d2:	4785                	li	a5,1
    19d4:	00f70d63          	beq	a4,a5,19ee <putchar+0x38>
		len = out_unlocked(s, l);
    19d8:	01f10513          	addi	a0,sp,31
    19dc:	f33ff0ef          	jal	ra,190e <out_unlocked.constprop.0>
}
    19e0:	70e2                	ld	ra,56(sp)
    19e2:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    19e4:	862a                	mv	a2,a0
}
    19e6:	74a2                	ld	s1,40(sp)
    19e8:	8532                	mv	a0,a2
    19ea:	6121                	addi	sp,sp,64
    19ec:	8082                	ret
		mutex_lock(buffer_lock);
    19ee:	10c4a503          	lw	a0,268(s1)
    19f2:	625000ef          	jal	ra,2816 <mutex_lock>
		buffer[buffer_len++] = c;
    19f6:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19f8:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19fc:	0017861b          	addiw	a2,a5,1
    1a00:	97a6                	add	a5,a5,s1
    1a02:	c090                	sw	a2,0(s1)
    1a04:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a08:	02c6c263          	blt	a3,a2,1a2c <putchar+0x76>
    1a0c:	47a9                	li	a5,10
    1a0e:	06f40d63          	beq	s0,a5,1a88 <putchar+0xd2>
    1a12:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a14:	10c4a503          	lw	a0,268(s1)
    1a18:	e432                	sd	a2,8(sp)
    1a1a:	609000ef          	jal	ra,2822 <mutex_unlock>
    1a1e:	6622                	ld	a2,8(sp)
}
    1a20:	70e2                	ld	ra,56(sp)
    1a22:	7442                	ld	s0,48(sp)
    1a24:	74a2                	ld	s1,40(sp)
    1a26:	8532                	mv	a0,a2
    1a28:	6121                	addi	sp,sp,64
    1a2a:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a2c:	10000793          	li	a5,256
    1a30:	02f61063          	bne	a2,a5,1a50 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a34:	00001597          	auipc	a1,0x1
    1a38:	ff458593          	addi	a1,a1,-12 # 2a28 <buffer>
    1a3c:	4505                	li	a0,1
    1a3e:	361000ef          	jal	ra,259e <write>
    1a42:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a46:	00001797          	auipc	a5,0x1
    1a4a:	fc07ad23          	sw	zero,-38(a5) # 2a20 <buffer_len>
			if (r < 0) {
    1a4e:	b7d9                	j	1a14 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a50:	359000ef          	jal	ra,25a8 <getpid>
    1a54:	842a                	mv	s0,a0
    1a56:	00001517          	auipc	a0,0x1
    1a5a:	eda50513          	addi	a0,a0,-294 # 2930 <enable_deadlock_detect+0xba>
    1a5e:	221000ef          	jal	ra,247e <basename>
    1a62:	872a                	mv	a4,a0
    1a64:	00001617          	auipc	a2,0x1
    1a68:	e6c60613          	addi	a2,a2,-404 # 28d0 <enable_deadlock_detect+0x5a>
    1a6c:	05400793          	li	a5,84
    1a70:	86a2                	mv	a3,s0
    1a72:	45fd                	li	a1,31
    1a74:	00001517          	auipc	a0,0x1
    1a78:	efc50513          	addi	a0,a0,-260 # 2970 <enable_deadlock_detect+0xfa>
    1a7c:	8fbff0ef          	jal	ra,1376 <printf>
    1a80:	557d                	li	a0,-1
    1a82:	357000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    1a86:	4090                	lw	a2,0(s1)
    1a88:	d651                	beqz	a2,1a14 <putchar+0x5e>
    1a8a:	b76d                	j	1a34 <putchar+0x7e>

0000000000001a8c <puts>:
{
    1a8c:	7139                	addi	sp,sp,-64
    1a8e:	f822                	sd	s0,48(sp)
    1a90:	f426                	sd	s1,40(sp)
    1a92:	fc06                	sd	ra,56(sp)
    1a94:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1a96:	00001417          	auipc	s0,0x1
    1a9a:	f8a40413          	addi	s0,s0,-118 # 2a20 <buffer_len>
{
    1a9e:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aa0:	638000ef          	jal	ra,20d8 <strlen>
	if (buffer_lock_enabled == 1) {
    1aa4:	10842703          	lw	a4,264(s0)
    1aa8:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aaa:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1aac:	04f70563          	beq	a4,a5,1af6 <puts+0x6a>
		len = out_unlocked(s, l);
    1ab0:	8526                	mv	a0,s1
    1ab2:	d51ff0ef          	jal	ra,1802 <out_unlocked>
    1ab6:	892a                	mv	s2,a0
    1ab8:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aba:	00095963          	bgez	s2,1acc <puts+0x40>
}
    1abe:	70e2                	ld	ra,56(sp)
    1ac0:	7442                	ld	s0,48(sp)
    1ac2:	7902                	ld	s2,32(sp)
    1ac4:	8526                	mv	a0,s1
    1ac6:	74a2                	ld	s1,40(sp)
    1ac8:	6121                	addi	sp,sp,64
    1aca:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1acc:	10842703          	lw	a4,264(s0)
	char byte = c;
    1ad0:	44a9                	li	s1,10
    1ad2:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1ad6:	4785                	li	a5,1
    1ad8:	02f70e63          	beq	a4,a5,1b14 <puts+0x88>
		len = out_unlocked(s, l);
    1adc:	01f10513          	addi	a0,sp,31
    1ae0:	e2fff0ef          	jal	ra,190e <out_unlocked.constprop.0>
}
    1ae4:	70e2                	ld	ra,56(sp)
    1ae6:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ae8:	41f5549b          	sraiw	s1,a0,0x1f
}
    1aec:	7902                	ld	s2,32(sp)
    1aee:	8526                	mv	a0,s1
    1af0:	74a2                	ld	s1,40(sp)
    1af2:	6121                	addi	sp,sp,64
    1af4:	8082                	ret
		mutex_lock(buffer_lock);
    1af6:	e42a                	sd	a0,8(sp)
    1af8:	10c42503          	lw	a0,268(s0)
    1afc:	51b000ef          	jal	ra,2816 <mutex_lock>
		len = out_unlocked(s, l);
    1b00:	65a2                	ld	a1,8(sp)
    1b02:	8526                	mv	a0,s1
    1b04:	cffff0ef          	jal	ra,1802 <out_unlocked>
    1b08:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b0a:	10c42503          	lw	a0,268(s0)
    1b0e:	515000ef          	jal	ra,2822 <mutex_unlock>
    1b12:	b75d                	j	1ab8 <puts+0x2c>
		mutex_lock(buffer_lock);
    1b14:	10c42503          	lw	a0,268(s0)
    1b18:	4ff000ef          	jal	ra,2816 <mutex_lock>
		buffer[buffer_len++] = c;
    1b1c:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b1e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b22:	0017861b          	addiw	a2,a5,1
    1b26:	97a2                	add	a5,a5,s0
    1b28:	c010                	sw	a2,0(s0)
    1b2a:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b2e:	06c6dc63          	bge	a3,a2,1ba6 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b32:	10000793          	li	a5,256
    1b36:	02f61c63          	bne	a2,a5,1b6e <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b3a:	00001597          	auipc	a1,0x1
    1b3e:	eee58593          	addi	a1,a1,-274 # 2a28 <buffer>
    1b42:	4505                	li	a0,1
    1b44:	25b000ef          	jal	ra,259e <write>
			if (r < 0) {
    1b48:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b4a:	00001797          	auipc	a5,0x1
    1b4e:	ec07ab23          	sw	zero,-298(a5) # 2a20 <buffer_len>
			if (r < 0) {
    1b52:	04054c63          	bltz	a0,1baa <puts+0x11e>
			if (r < buffer_len) {
    1b56:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b58:	10c42503          	lw	a0,268(s0)
    1b5c:	4c7000ef          	jal	ra,2822 <mutex_unlock>
}
    1b60:	70e2                	ld	ra,56(sp)
    1b62:	7442                	ld	s0,48(sp)
    1b64:	7902                	ld	s2,32(sp)
    1b66:	8526                	mv	a0,s1
    1b68:	74a2                	ld	s1,40(sp)
    1b6a:	6121                	addi	sp,sp,64
    1b6c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b6e:	23b000ef          	jal	ra,25a8 <getpid>
    1b72:	84aa                	mv	s1,a0
    1b74:	00001517          	auipc	a0,0x1
    1b78:	dbc50513          	addi	a0,a0,-580 # 2930 <enable_deadlock_detect+0xba>
    1b7c:	103000ef          	jal	ra,247e <basename>
    1b80:	872a                	mv	a4,a0
    1b82:	00001617          	auipc	a2,0x1
    1b86:	d4e60613          	addi	a2,a2,-690 # 28d0 <enable_deadlock_detect+0x5a>
    1b8a:	05400793          	li	a5,84
    1b8e:	86a6                	mv	a3,s1
    1b90:	45fd                	li	a1,31
    1b92:	00001517          	auipc	a0,0x1
    1b96:	dde50513          	addi	a0,a0,-546 # 2970 <enable_deadlock_detect+0xfa>
    1b9a:	fdcff0ef          	jal	ra,1376 <printf>
    1b9e:	557d                	li	a0,-1
    1ba0:	239000ef          	jal	ra,25d8 <exit>
	if (buffer_len == 0)
    1ba4:	4010                	lw	a2,0(s0)
    1ba6:	da45                	beqz	a2,1b56 <puts+0xca>
    1ba8:	bf49                	j	1b3a <puts+0xae>
    1baa:	54fd                	li	s1,-1
    1bac:	b775                	j	1b58 <puts+0xcc>

0000000000001bae <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1bae:	715d                	addi	sp,sp,-80
    1bb0:	e486                	sd	ra,72(sp)
    1bb2:	e0a2                	sd	s0,64(sp)
    1bb4:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1bb6:	14054363          	bltz	a0,1cfc <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bba:	02b577bb          	remuw	a5,a0,a1
    1bbe:	00001617          	auipc	a2,0x1
    1bc2:	f7260613          	addi	a2,a2,-142 # 2b30 <digits>
	buf[16] = 0;
    1bc6:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bca:	0005871b          	sext.w	a4,a1
    1bce:	1782                	slli	a5,a5,0x20
    1bd0:	9381                	srli	a5,a5,0x20
    1bd2:	97b2                	add	a5,a5,a2
    1bd4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bd8:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1bdc:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1be0:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1be2:	0eb56763          	bltu	a0,a1,1cd0 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1be6:	02e877bb          	remuw	a5,a6,a4
    1bea:	1782                	slli	a5,a5,0x20
    1bec:	9381                	srli	a5,a5,0x20
    1bee:	97b2                	add	a5,a5,a2
    1bf0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bf4:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1bf8:	02f10323          	sb	a5,38(sp)
    1bfc:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1bfe:	0ce86963          	bltu	a6,a4,1cd0 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c02:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c06:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c0a:	1582                	slli	a1,a1,0x20
    1c0c:	9181                	srli	a1,a1,0x20
    1c0e:	95b2                	add	a1,a1,a2
    1c10:	0005c583          	lbu	a1,0(a1)
    1c14:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c18:	0007859b          	sext.w	a1,a5
    1c1c:	16e6e563          	bltu	a3,a4,1d86 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c20:	02e7f6bb          	remuw	a3,a5,a4
    1c24:	1682                	slli	a3,a3,0x20
    1c26:	9281                	srli	a3,a3,0x20
    1c28:	96b2                	add	a3,a3,a2
    1c2a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c2e:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c32:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c36:	16e5e163          	bltu	a1,a4,1d98 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c3a:	02e876bb          	remuw	a3,a6,a4
    1c3e:	1682                	slli	a3,a3,0x20
    1c40:	9281                	srli	a3,a3,0x20
    1c42:	96b2                	add	a3,a3,a2
    1c44:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c48:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c4c:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c50:	14e86d63          	bltu	a6,a4,1daa <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c54:	02e5f6bb          	remuw	a3,a1,a4
    1c58:	1682                	slli	a3,a3,0x20
    1c5a:	9281                	srli	a3,a3,0x20
    1c5c:	96b2                	add	a3,a3,a2
    1c5e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c62:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c66:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1c6a:	10e5e563          	bltu	a1,a4,1d74 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1c6e:	02e876bb          	remuw	a3,a6,a4
    1c72:	1682                	slli	a3,a3,0x20
    1c74:	9281                	srli	a3,a3,0x20
    1c76:	96b2                	add	a3,a3,a2
    1c78:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c7c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c80:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1c84:	14e86263          	bltu	a6,a4,1dc8 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1c88:	02e5f6bb          	remuw	a3,a1,a4
    1c8c:	1682                	slli	a3,a3,0x20
    1c8e:	9281                	srli	a3,a3,0x20
    1c90:	96b2                	add	a3,a3,a2
    1c92:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c96:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1c9a:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1c9e:	14e5e463          	bltu	a1,a4,1de6 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ca2:	02e876bb          	remuw	a3,a6,a4
    1ca6:	1682                	slli	a3,a3,0x20
    1ca8:	9281                	srli	a3,a3,0x20
    1caa:	96b2                	add	a3,a3,a2
    1cac:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cb0:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1cb4:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cb8:	14e86063          	bltu	a6,a4,1df8 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1cbc:	1782                	slli	a5,a5,0x20
    1cbe:	9381                	srli	a5,a5,0x20
    1cc0:	97b2                	add	a5,a5,a2
    1cc2:	0007c703          	lbu	a4,0(a5)
    1cc6:	4799                	li	a5,6
    1cc8:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1ccc:	10054763          	bltz	a0,1dda <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1cd0:	00001497          	auipc	s1,0x1
    1cd4:	d5048493          	addi	s1,s1,-688 # 2a20 <buffer_len>
    1cd8:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1cdc:	0828                	addi	a0,sp,24
    1cde:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1ce0:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1ce2:	00f50433          	add	s0,a0,a5
    1ce6:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1ce8:	06e68463          	beq	a3,a4,1d50 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1cec:	8522                	mv	a0,s0
    1cee:	b15ff0ef          	jal	ra,1802 <out_unlocked>
}
    1cf2:	60a6                	ld	ra,72(sp)
    1cf4:	6406                	ld	s0,64(sp)
    1cf6:	74e2                	ld	s1,56(sp)
    1cf8:	6161                	addi	sp,sp,80
    1cfa:	8082                	ret
		x = -xx;
    1cfc:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d00:	02b877bb          	remuw	a5,a6,a1
    1d04:	00001617          	auipc	a2,0x1
    1d08:	e2c60613          	addi	a2,a2,-468 # 2b30 <digits>
	buf[16] = 0;
    1d0c:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d10:	0005871b          	sext.w	a4,a1
    1d14:	1782                	slli	a5,a5,0x20
    1d16:	9381                	srli	a5,a5,0x20
    1d18:	97b2                	add	a5,a5,a2
    1d1a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d1e:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d22:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d26:	08b86b63          	bltu	a6,a1,1dbc <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d2a:	02e8f7bb          	remuw	a5,a7,a4
    1d2e:	1782                	slli	a5,a5,0x20
    1d30:	9381                	srli	a5,a5,0x20
    1d32:	97b2                	add	a5,a5,a2
    1d34:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d38:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d3c:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d40:	ece8f1e3          	bgeu	a7,a4,1c02 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d44:	02d00793          	li	a5,45
    1d48:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d4c:	47b5                	li	a5,13
    1d4e:	b749                	j	1cd0 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d50:	10c4a503          	lw	a0,268(s1)
    1d54:	e42e                	sd	a1,8(sp)
    1d56:	2c1000ef          	jal	ra,2816 <mutex_lock>
		len = out_unlocked(s, l);
    1d5a:	65a2                	ld	a1,8(sp)
    1d5c:	8522                	mv	a0,s0
    1d5e:	aa5ff0ef          	jal	ra,1802 <out_unlocked>
		mutex_unlock(buffer_lock);
    1d62:	10c4a503          	lw	a0,268(s1)
    1d66:	2bd000ef          	jal	ra,2822 <mutex_unlock>
}
    1d6a:	60a6                	ld	ra,72(sp)
    1d6c:	6406                	ld	s0,64(sp)
    1d6e:	74e2                	ld	s1,56(sp)
    1d70:	6161                	addi	sp,sp,80
    1d72:	8082                	ret
		buf[i--] = digits[x % base];
    1d74:	47a9                	li	a5,10
	if (sign)
    1d76:	f4055de3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d7a:	02d00793          	li	a5,45
    1d7e:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1d82:	47a5                	li	a5,9
    1d84:	b7b1                	j	1cd0 <printint.constprop.0+0x122>
    1d86:	47b5                	li	a5,13
	if (sign)
    1d88:	f40554e3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d8c:	02d00793          	li	a5,45
    1d90:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1d94:	47b1                	li	a5,12
    1d96:	bf2d                	j	1cd0 <printint.constprop.0+0x122>
    1d98:	47b1                	li	a5,12
	if (sign)
    1d9a:	f2055be3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d9e:	02d00793          	li	a5,45
    1da2:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1da6:	47ad                	li	a5,11
    1da8:	b725                	j	1cd0 <printint.constprop.0+0x122>
    1daa:	47ad                	li	a5,11
	if (sign)
    1dac:	f20552e3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1db0:	02d00793          	li	a5,45
    1db4:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1db8:	47a9                	li	a5,10
    1dba:	bf19                	j	1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dbc:	02d00793          	li	a5,45
    1dc0:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1dc4:	47b9                	li	a5,14
    1dc6:	b729                	j	1cd0 <printint.constprop.0+0x122>
    1dc8:	47a5                	li	a5,9
	if (sign)
    1dca:	f00553e3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dce:	02d00793          	li	a5,45
    1dd2:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1dd6:	47a1                	li	a5,8
    1dd8:	bde5                	j	1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dda:	02d00793          	li	a5,45
    1dde:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1de2:	4795                	li	a5,5
    1de4:	b5f5                	j	1cd0 <printint.constprop.0+0x122>
    1de6:	47a1                	li	a5,8
	if (sign)
    1de8:	ee0554e3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dec:	02d00793          	li	a5,45
    1df0:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1df4:	479d                	li	a5,7
    1df6:	bde9                	j	1cd0 <printint.constprop.0+0x122>
    1df8:	479d                	li	a5,7
	if (sign)
    1dfa:	ec055be3          	bgez	a0,1cd0 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dfe:	02d00793          	li	a5,45
    1e02:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e06:	4799                	li	a5,6
    1e08:	b5e1                	j	1cd0 <printint.constprop.0+0x122>

0000000000001e0a <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e0a:	02000793          	li	a5,32
    1e0e:	00f50663          	beq	a0,a5,1e1a <isspace+0x10>
    1e12:	355d                	addiw	a0,a0,-9
    1e14:	00553513          	sltiu	a0,a0,5
    1e18:	8082                	ret
    1e1a:	4505                	li	a0,1
}
    1e1c:	8082                	ret

0000000000001e1e <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e1e:	fd05051b          	addiw	a0,a0,-48
}
    1e22:	00a53513          	sltiu	a0,a0,10
    1e26:	8082                	ret

0000000000001e28 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e28:	02000613          	li	a2,32
    1e2c:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e2e:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e32:	ff77869b          	addiw	a3,a5,-9
    1e36:	04c78c63          	beq	a5,a2,1e8e <atoi+0x66>
    1e3a:	0007871b          	sext.w	a4,a5
    1e3e:	04d5f863          	bgeu	a1,a3,1e8e <atoi+0x66>
		s++;
	switch (*s) {
    1e42:	02b00693          	li	a3,43
    1e46:	04d78963          	beq	a5,a3,1e98 <atoi+0x70>
    1e4a:	02d00693          	li	a3,45
    1e4e:	06d78263          	beq	a5,a3,1eb2 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e52:	fd07061b          	addiw	a2,a4,-48
    1e56:	47a5                	li	a5,9
    1e58:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e5a:	4e01                	li	t3,0
	while (isdigit(*s))
    1e5c:	04c7e963          	bltu	a5,a2,1eae <atoi+0x86>
	int n = 0, neg = 0;
    1e60:	4501                	li	a0,0
	while (isdigit(*s))
    1e62:	4825                	li	a6,9
    1e64:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1e68:	0025179b          	slliw	a5,a0,0x2
    1e6c:	9fa9                	addw	a5,a5,a0
    1e6e:	fd07031b          	addiw	t1,a4,-48
    1e72:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1e76:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1e7a:	0685                	addi	a3,a3,1
    1e7c:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1e80:	0006071b          	sext.w	a4,a2
    1e84:	feb870e3          	bgeu	a6,a1,1e64 <atoi+0x3c>
	return neg ? n : -n;
    1e88:	000e0563          	beqz	t3,1e92 <atoi+0x6a>
}
    1e8c:	8082                	ret
		s++;
    1e8e:	0505                	addi	a0,a0,1
    1e90:	bf79                	j	1e2e <atoi+0x6>
	return neg ? n : -n;
    1e92:	4113053b          	subw	a0,t1,a7
    1e96:	8082                	ret
	while (isdigit(*s))
    1e98:	00154703          	lbu	a4,1(a0)
    1e9c:	47a5                	li	a5,9
		s++;
    1e9e:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ea2:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1ea6:	4e01                	li	t3,0
	while (isdigit(*s))
    1ea8:	2701                	sext.w	a4,a4
    1eaa:	fac7fbe3          	bgeu	a5,a2,1e60 <atoi+0x38>
    1eae:	4501                	li	a0,0
}
    1eb0:	8082                	ret
	while (isdigit(*s))
    1eb2:	00154703          	lbu	a4,1(a0)
    1eb6:	47a5                	li	a5,9
		s++;
    1eb8:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ebc:	fd07061b          	addiw	a2,a4,-48
    1ec0:	2701                	sext.w	a4,a4
    1ec2:	fec7e6e3          	bltu	a5,a2,1eae <atoi+0x86>
		neg = 1;
    1ec6:	4e05                	li	t3,1
    1ec8:	bf61                	j	1e60 <atoi+0x38>

0000000000001eca <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1eca:	16060d63          	beqz	a2,2044 <memset+0x17a>
    1ece:	40a007b3          	neg	a5,a0
    1ed2:	8b9d                	andi	a5,a5,7
    1ed4:	00778693          	addi	a3,a5,7
    1ed8:	482d                	li	a6,11
    1eda:	0ff5f713          	zext.b	a4,a1
    1ede:	fff60593          	addi	a1,a2,-1
    1ee2:	1706e263          	bltu	a3,a6,2046 <memset+0x17c>
    1ee6:	16d5ea63          	bltu	a1,a3,205a <memset+0x190>
    1eea:	16078563          	beqz	a5,2054 <memset+0x18a>
    1eee:	00e50023          	sb	a4,0(a0)
    1ef2:	4685                	li	a3,1
    1ef4:	00150593          	addi	a1,a0,1
    1ef8:	14d78c63          	beq	a5,a3,2050 <memset+0x186>
    1efc:	00e500a3          	sb	a4,1(a0)
    1f00:	4689                	li	a3,2
    1f02:	00250593          	addi	a1,a0,2
    1f06:	14d78d63          	beq	a5,a3,2060 <memset+0x196>
    1f0a:	00e50123          	sb	a4,2(a0)
    1f0e:	468d                	li	a3,3
    1f10:	00350593          	addi	a1,a0,3
    1f14:	12d78b63          	beq	a5,a3,204a <memset+0x180>
    1f18:	00e501a3          	sb	a4,3(a0)
    1f1c:	4691                	li	a3,4
    1f1e:	00450593          	addi	a1,a0,4
    1f22:	14d78163          	beq	a5,a3,2064 <memset+0x19a>
    1f26:	00e50223          	sb	a4,4(a0)
    1f2a:	4695                	li	a3,5
    1f2c:	00550593          	addi	a1,a0,5
    1f30:	12d78c63          	beq	a5,a3,2068 <memset+0x19e>
    1f34:	00e502a3          	sb	a4,5(a0)
    1f38:	469d                	li	a3,7
    1f3a:	00650593          	addi	a1,a0,6
    1f3e:	12d79763          	bne	a5,a3,206c <memset+0x1a2>
    1f42:	00750593          	addi	a1,a0,7
    1f46:	00e50323          	sb	a4,6(a0)
    1f4a:	481d                	li	a6,7
    1f4c:	00871693          	slli	a3,a4,0x8
    1f50:	01071893          	slli	a7,a4,0x10
    1f54:	8ed9                	or	a3,a3,a4
    1f56:	01871313          	slli	t1,a4,0x18
    1f5a:	0116e6b3          	or	a3,a3,a7
    1f5e:	0066e6b3          	or	a3,a3,t1
    1f62:	02071893          	slli	a7,a4,0x20
    1f66:	02871e13          	slli	t3,a4,0x28
    1f6a:	0116e6b3          	or	a3,a3,a7
    1f6e:	40f60333          	sub	t1,a2,a5
    1f72:	03071893          	slli	a7,a4,0x30
    1f76:	01c6e6b3          	or	a3,a3,t3
    1f7a:	0116e6b3          	or	a3,a3,a7
    1f7e:	03871e13          	slli	t3,a4,0x38
    1f82:	97aa                	add	a5,a5,a0
    1f84:	ff837893          	andi	a7,t1,-8
    1f88:	01c6e6b3          	or	a3,a3,t3
    1f8c:	98be                	add	a7,a7,a5
    1f8e:	e394                	sd	a3,0(a5)
    1f90:	07a1                	addi	a5,a5,8
    1f92:	ff179ee3          	bne	a5,a7,1f8e <memset+0xc4>
    1f96:	ff837893          	andi	a7,t1,-8
    1f9a:	011587b3          	add	a5,a1,a7
    1f9e:	010886bb          	addw	a3,a7,a6
    1fa2:	0b130663          	beq	t1,a7,204e <memset+0x184>
    1fa6:	00e78023          	sb	a4,0(a5)
    1faa:	0016859b          	addiw	a1,a3,1
    1fae:	08c5fb63          	bgeu	a1,a2,2044 <memset+0x17a>
    1fb2:	00e780a3          	sb	a4,1(a5)
    1fb6:	0026859b          	addiw	a1,a3,2
    1fba:	08c5f563          	bgeu	a1,a2,2044 <memset+0x17a>
    1fbe:	00e78123          	sb	a4,2(a5)
    1fc2:	0036859b          	addiw	a1,a3,3
    1fc6:	06c5ff63          	bgeu	a1,a2,2044 <memset+0x17a>
    1fca:	00e781a3          	sb	a4,3(a5)
    1fce:	0046859b          	addiw	a1,a3,4
    1fd2:	06c5f963          	bgeu	a1,a2,2044 <memset+0x17a>
    1fd6:	00e78223          	sb	a4,4(a5)
    1fda:	0056859b          	addiw	a1,a3,5
    1fde:	06c5f363          	bgeu	a1,a2,2044 <memset+0x17a>
    1fe2:	00e782a3          	sb	a4,5(a5)
    1fe6:	0066859b          	addiw	a1,a3,6
    1fea:	04c5fd63          	bgeu	a1,a2,2044 <memset+0x17a>
    1fee:	00e78323          	sb	a4,6(a5)
    1ff2:	0076859b          	addiw	a1,a3,7
    1ff6:	04c5f763          	bgeu	a1,a2,2044 <memset+0x17a>
    1ffa:	00e783a3          	sb	a4,7(a5)
    1ffe:	0086859b          	addiw	a1,a3,8
    2002:	04c5f163          	bgeu	a1,a2,2044 <memset+0x17a>
    2006:	00e78423          	sb	a4,8(a5)
    200a:	0096859b          	addiw	a1,a3,9
    200e:	02c5fb63          	bgeu	a1,a2,2044 <memset+0x17a>
    2012:	00e784a3          	sb	a4,9(a5)
    2016:	00a6859b          	addiw	a1,a3,10
    201a:	02c5f563          	bgeu	a1,a2,2044 <memset+0x17a>
    201e:	00e78523          	sb	a4,10(a5)
    2022:	00b6859b          	addiw	a1,a3,11
    2026:	00c5ff63          	bgeu	a1,a2,2044 <memset+0x17a>
    202a:	00e785a3          	sb	a4,11(a5)
    202e:	00c6859b          	addiw	a1,a3,12
    2032:	00c5f963          	bgeu	a1,a2,2044 <memset+0x17a>
    2036:	00e78623          	sb	a4,12(a5)
    203a:	26b5                	addiw	a3,a3,13
    203c:	00c6f463          	bgeu	a3,a2,2044 <memset+0x17a>
    2040:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2044:	8082                	ret
    2046:	46ad                	li	a3,11
    2048:	bd79                	j	1ee6 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    204a:	480d                	li	a6,3
    204c:	b701                	j	1f4c <memset+0x82>
    204e:	8082                	ret
    2050:	4805                	li	a6,1
    2052:	bded                	j	1f4c <memset+0x82>
    2054:	85aa                	mv	a1,a0
    2056:	4801                	li	a6,0
    2058:	bdd5                	j	1f4c <memset+0x82>
    205a:	87aa                	mv	a5,a0
    205c:	4681                	li	a3,0
    205e:	b7a1                	j	1fa6 <memset+0xdc>
    2060:	4809                	li	a6,2
    2062:	b5ed                	j	1f4c <memset+0x82>
    2064:	4811                	li	a6,4
    2066:	b5dd                	j	1f4c <memset+0x82>
    2068:	4815                	li	a6,5
    206a:	b5cd                	j	1f4c <memset+0x82>
    206c:	4819                	li	a6,6
    206e:	bdf9                	j	1f4c <memset+0x82>

0000000000002070 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2070:	00054783          	lbu	a5,0(a0)
    2074:	0005c703          	lbu	a4,0(a1)
    2078:	00e79863          	bne	a5,a4,2088 <strcmp+0x18>
    207c:	0505                	addi	a0,a0,1
    207e:	0585                	addi	a1,a1,1
    2080:	fbe5                	bnez	a5,2070 <strcmp>
    2082:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2084:	9d19                	subw	a0,a0,a4
    2086:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    2088:	0007851b          	sext.w	a0,a5
    208c:	bfe5                	j	2084 <strcmp+0x14>

000000000000208e <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    208e:	ca15                	beqz	a2,20c2 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2090:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2094:	167d                	addi	a2,a2,-1
    2096:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    209a:	eb99                	bnez	a5,20b0 <strncmp+0x22>
    209c:	a815                	j	20d0 <strncmp+0x42>
    209e:	00a68e63          	beq	a3,a0,20ba <strncmp+0x2c>
    20a2:	0505                	addi	a0,a0,1
    20a4:	00f71b63          	bne	a4,a5,20ba <strncmp+0x2c>
    20a8:	00054783          	lbu	a5,0(a0)
    20ac:	cf89                	beqz	a5,20c6 <strncmp+0x38>
    20ae:	85b2                	mv	a1,a2
    20b0:	0005c703          	lbu	a4,0(a1)
    20b4:	00158613          	addi	a2,a1,1
    20b8:	f37d                	bnez	a4,209e <strncmp+0x10>
		;
	return *l - *r;
    20ba:	0007851b          	sext.w	a0,a5
    20be:	9d19                	subw	a0,a0,a4
    20c0:	8082                	ret
		return 0;
    20c2:	4501                	li	a0,0
}
    20c4:	8082                	ret
	return *l - *r;
    20c6:	0015c703          	lbu	a4,1(a1)
    20ca:	4501                	li	a0,0
    20cc:	9d19                	subw	a0,a0,a4
    20ce:	8082                	ret
    20d0:	0005c703          	lbu	a4,0(a1)
    20d4:	4501                	li	a0,0
    20d6:	b7e5                	j	20be <strncmp+0x30>

00000000000020d8 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    20d8:	00757793          	andi	a5,a0,7
    20dc:	cf89                	beqz	a5,20f6 <strlen+0x1e>
    20de:	87aa                	mv	a5,a0
    20e0:	a029                	j	20ea <strlen+0x12>
    20e2:	0785                	addi	a5,a5,1
    20e4:	0077f713          	andi	a4,a5,7
    20e8:	cb01                	beqz	a4,20f8 <strlen+0x20>
		if (!*s)
    20ea:	0007c703          	lbu	a4,0(a5)
    20ee:	fb75                	bnez	a4,20e2 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    20f0:	40a78533          	sub	a0,a5,a0
}
    20f4:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    20f6:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    20f8:	6394                	ld	a3,0(a5)
    20fa:	00001597          	auipc	a1,0x1
    20fe:	90e5b583          	ld	a1,-1778(a1) # 2a08 <enable_deadlock_detect+0x192>
    2102:	00001617          	auipc	a2,0x1
    2106:	90e63603          	ld	a2,-1778(a2) # 2a10 <enable_deadlock_detect+0x19a>
    210a:	a019                	j	2110 <strlen+0x38>
    210c:	6794                	ld	a3,8(a5)
    210e:	07a1                	addi	a5,a5,8
    2110:	00b68733          	add	a4,a3,a1
    2114:	fff6c693          	not	a3,a3
    2118:	8f75                	and	a4,a4,a3
    211a:	8f71                	and	a4,a4,a2
    211c:	db65                	beqz	a4,210c <strlen+0x34>
	for (; *s; s++)
    211e:	0007c703          	lbu	a4,0(a5)
    2122:	d779                	beqz	a4,20f0 <strlen+0x18>
    2124:	0017c703          	lbu	a4,1(a5)
    2128:	0785                	addi	a5,a5,1
    212a:	d379                	beqz	a4,20f0 <strlen+0x18>
    212c:	0017c703          	lbu	a4,1(a5)
    2130:	0785                	addi	a5,a5,1
    2132:	fb6d                	bnez	a4,2124 <strlen+0x4c>
    2134:	bf75                	j	20f0 <strlen+0x18>

0000000000002136 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2136:	00757713          	andi	a4,a0,7
{
    213a:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    213c:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2140:	cb19                	beqz	a4,2156 <memchr+0x20>
    2142:	ce25                	beqz	a2,21ba <memchr+0x84>
    2144:	0007c703          	lbu	a4,0(a5)
    2148:	04b70e63          	beq	a4,a1,21a4 <memchr+0x6e>
    214c:	0785                	addi	a5,a5,1
    214e:	0077f713          	andi	a4,a5,7
    2152:	167d                	addi	a2,a2,-1
    2154:	f77d                	bnez	a4,2142 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2156:	4501                	li	a0,0
	if (n && *s != c) {
    2158:	c235                	beqz	a2,21bc <memchr+0x86>
    215a:	0007c703          	lbu	a4,0(a5)
    215e:	04b70363          	beq	a4,a1,21a4 <memchr+0x6e>
		size_t k = ONES * c;
    2162:	00001517          	auipc	a0,0x1
    2166:	8b653503          	ld	a0,-1866(a0) # 2a18 <enable_deadlock_detect+0x1a2>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    216a:	471d                	li	a4,7
		size_t k = ONES * c;
    216c:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2170:	02c77a63          	bgeu	a4,a2,21a4 <memchr+0x6e>
    2174:	00001897          	auipc	a7,0x1
    2178:	8948b883          	ld	a7,-1900(a7) # 2a08 <enable_deadlock_detect+0x192>
    217c:	00001817          	auipc	a6,0x1
    2180:	89483803          	ld	a6,-1900(a6) # 2a10 <enable_deadlock_detect+0x19a>
    2184:	431d                	li	t1,7
    2186:	a029                	j	2190 <memchr+0x5a>
		     w++, n -= SS)
    2188:	1661                	addi	a2,a2,-8
    218a:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    218c:	02c37963          	bgeu	t1,a2,21be <memchr+0x88>
    2190:	6398                	ld	a4,0(a5)
    2192:	8f29                	xor	a4,a4,a0
    2194:	011706b3          	add	a3,a4,a7
    2198:	fff74713          	not	a4,a4
    219c:	8f75                	and	a4,a4,a3
    219e:	01077733          	and	a4,a4,a6
    21a2:	d37d                	beqz	a4,2188 <memchr+0x52>
{
    21a4:	853e                	mv	a0,a5
    21a6:	97b2                	add	a5,a5,a2
    21a8:	a021                	j	21b0 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21aa:	0505                	addi	a0,a0,1
    21ac:	00f50763          	beq	a0,a5,21ba <memchr+0x84>
    21b0:	00054703          	lbu	a4,0(a0)
    21b4:	feb71be3          	bne	a4,a1,21aa <memchr+0x74>
    21b8:	8082                	ret
	return n ? (void *)s : 0;
    21ba:	4501                	li	a0,0
}
    21bc:	8082                	ret
	return n ? (void *)s : 0;
    21be:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    21c0:	f275                	bnez	a2,21a4 <memchr+0x6e>
}
    21c2:	8082                	ret

00000000000021c4 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    21c4:	1101                	addi	sp,sp,-32
    21c6:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    21c8:	862e                	mv	a2,a1
{
    21ca:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    21cc:	4581                	li	a1,0
{
    21ce:	e426                	sd	s1,8(sp)
    21d0:	ec06                	sd	ra,24(sp)
    21d2:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    21d4:	f63ff0ef          	jal	ra,2136 <memchr>
	return p ? p - s : n;
    21d8:	c519                	beqz	a0,21e6 <strnlen+0x22>
}
    21da:	60e2                	ld	ra,24(sp)
    21dc:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    21de:	8d05                	sub	a0,a0,s1
}
    21e0:	64a2                	ld	s1,8(sp)
    21e2:	6105                	addi	sp,sp,32
    21e4:	8082                	ret
    21e6:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    21e8:	8522                	mv	a0,s0
}
    21ea:	6442                	ld	s0,16(sp)
    21ec:	64a2                	ld	s1,8(sp)
    21ee:	6105                	addi	sp,sp,32
    21f0:	8082                	ret

00000000000021f2 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    21f2:	00a5c7b3          	xor	a5,a1,a0
    21f6:	8b9d                	andi	a5,a5,7
    21f8:	eb95                	bnez	a5,222c <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    21fa:	0075f793          	andi	a5,a1,7
    21fe:	e7b1                	bnez	a5,224a <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2200:	6198                	ld	a4,0(a1)
    2202:	00001617          	auipc	a2,0x1
    2206:	80663603          	ld	a2,-2042(a2) # 2a08 <enable_deadlock_detect+0x192>
    220a:	00001817          	auipc	a6,0x1
    220e:	80683803          	ld	a6,-2042(a6) # 2a10 <enable_deadlock_detect+0x19a>
    2212:	a029                	j	221c <stpcpy+0x2a>
    2214:	05a1                	addi	a1,a1,8
    2216:	e118                	sd	a4,0(a0)
    2218:	6198                	ld	a4,0(a1)
    221a:	0521                	addi	a0,a0,8
    221c:	00c707b3          	add	a5,a4,a2
    2220:	fff74693          	not	a3,a4
    2224:	8ff5                	and	a5,a5,a3
    2226:	0107f7b3          	and	a5,a5,a6
    222a:	d7ed                	beqz	a5,2214 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    222c:	0005c783          	lbu	a5,0(a1)
    2230:	00f50023          	sb	a5,0(a0)
    2234:	c785                	beqz	a5,225c <stpcpy+0x6a>
    2236:	0015c783          	lbu	a5,1(a1)
    223a:	0505                	addi	a0,a0,1
    223c:	0585                	addi	a1,a1,1
    223e:	00f50023          	sb	a5,0(a0)
    2242:	fbf5                	bnez	a5,2236 <stpcpy+0x44>
		;
	return d;
}
    2244:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2246:	0505                	addi	a0,a0,1
    2248:	df45                	beqz	a4,2200 <stpcpy+0xe>
			if (!(*d = *s))
    224a:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    224e:	0585                	addi	a1,a1,1
    2250:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2254:	00f50023          	sb	a5,0(a0)
    2258:	f7fd                	bnez	a5,2246 <stpcpy+0x54>
}
    225a:	8082                	ret
    225c:	8082                	ret

000000000000225e <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    225e:	00a5c7b3          	xor	a5,a1,a0
    2262:	8b9d                	andi	a5,a5,7
    2264:	1a079863          	bnez	a5,2414 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2268:	0075f793          	andi	a5,a1,7
    226c:	16078463          	beqz	a5,23d4 <stpncpy+0x176>
    2270:	ea01                	bnez	a2,2280 <stpncpy+0x22>
    2272:	a421                	j	247a <stpncpy+0x21c>
    2274:	167d                	addi	a2,a2,-1
    2276:	0505                	addi	a0,a0,1
    2278:	14070e63          	beqz	a4,23d4 <stpncpy+0x176>
    227c:	1a060863          	beqz	a2,242c <stpncpy+0x1ce>
    2280:	0005c783          	lbu	a5,0(a1)
    2284:	0585                	addi	a1,a1,1
    2286:	0075f713          	andi	a4,a1,7
    228a:	00f50023          	sb	a5,0(a0)
    228e:	f3fd                	bnez	a5,2274 <stpncpy+0x16>
    2290:	4805                	li	a6,1
    2292:	1a061863          	bnez	a2,2442 <stpncpy+0x1e4>
    2296:	40a007b3          	neg	a5,a0
    229a:	8b9d                	andi	a5,a5,7
    229c:	4681                	li	a3,0
    229e:	18061a63          	bnez	a2,2432 <stpncpy+0x1d4>
    22a2:	00778713          	addi	a4,a5,7
    22a6:	45ad                	li	a1,11
    22a8:	18b76363          	bltu	a4,a1,242e <stpncpy+0x1d0>
    22ac:	1ae6eb63          	bltu	a3,a4,2462 <stpncpy+0x204>
    22b0:	1a078363          	beqz	a5,2456 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22b4:	00050023          	sb	zero,0(a0)
    22b8:	4685                	li	a3,1
    22ba:	00150713          	addi	a4,a0,1
    22be:	18d78f63          	beq	a5,a3,245c <stpncpy+0x1fe>
    22c2:	000500a3          	sb	zero,1(a0)
    22c6:	4689                	li	a3,2
    22c8:	00250713          	addi	a4,a0,2
    22cc:	18d78e63          	beq	a5,a3,2468 <stpncpy+0x20a>
    22d0:	00050123          	sb	zero,2(a0)
    22d4:	468d                	li	a3,3
    22d6:	00350713          	addi	a4,a0,3
    22da:	16d78c63          	beq	a5,a3,2452 <stpncpy+0x1f4>
    22de:	000501a3          	sb	zero,3(a0)
    22e2:	4691                	li	a3,4
    22e4:	00450713          	addi	a4,a0,4
    22e8:	18d78263          	beq	a5,a3,246c <stpncpy+0x20e>
    22ec:	00050223          	sb	zero,4(a0)
    22f0:	4695                	li	a3,5
    22f2:	00550713          	addi	a4,a0,5
    22f6:	16d78d63          	beq	a5,a3,2470 <stpncpy+0x212>
    22fa:	000502a3          	sb	zero,5(a0)
    22fe:	469d                	li	a3,7
    2300:	00650713          	addi	a4,a0,6
    2304:	16d79863          	bne	a5,a3,2474 <stpncpy+0x216>
    2308:	00750713          	addi	a4,a0,7
    230c:	00050323          	sb	zero,6(a0)
    2310:	40f80833          	sub	a6,a6,a5
    2314:	ff887593          	andi	a1,a6,-8
    2318:	97aa                	add	a5,a5,a0
    231a:	95be                	add	a1,a1,a5
    231c:	0007b023          	sd	zero,0(a5)
    2320:	07a1                	addi	a5,a5,8
    2322:	feb79de3          	bne	a5,a1,231c <stpncpy+0xbe>
    2326:	ff887593          	andi	a1,a6,-8
    232a:	9ead                	addw	a3,a3,a1
    232c:	00b707b3          	add	a5,a4,a1
    2330:	12b80863          	beq	a6,a1,2460 <stpncpy+0x202>
    2334:	00078023          	sb	zero,0(a5)
    2338:	0016871b          	addiw	a4,a3,1
    233c:	0ec77863          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2340:	000780a3          	sb	zero,1(a5)
    2344:	0026871b          	addiw	a4,a3,2
    2348:	0ec77263          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    234c:	00078123          	sb	zero,2(a5)
    2350:	0036871b          	addiw	a4,a3,3
    2354:	0cc77c63          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2358:	000781a3          	sb	zero,3(a5)
    235c:	0046871b          	addiw	a4,a3,4
    2360:	0cc77663          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2364:	00078223          	sb	zero,4(a5)
    2368:	0056871b          	addiw	a4,a3,5
    236c:	0cc77063          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2370:	000782a3          	sb	zero,5(a5)
    2374:	0066871b          	addiw	a4,a3,6
    2378:	0ac77a63          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    237c:	00078323          	sb	zero,6(a5)
    2380:	0076871b          	addiw	a4,a3,7
    2384:	0ac77463          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2388:	000783a3          	sb	zero,7(a5)
    238c:	0086871b          	addiw	a4,a3,8
    2390:	08c77e63          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    2394:	00078423          	sb	zero,8(a5)
    2398:	0096871b          	addiw	a4,a3,9
    239c:	08c77863          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    23a0:	000784a3          	sb	zero,9(a5)
    23a4:	00a6871b          	addiw	a4,a3,10
    23a8:	08c77263          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    23ac:	00078523          	sb	zero,10(a5)
    23b0:	00b6871b          	addiw	a4,a3,11
    23b4:	06c77c63          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    23b8:	000785a3          	sb	zero,11(a5)
    23bc:	00c6871b          	addiw	a4,a3,12
    23c0:	06c77663          	bgeu	a4,a2,242c <stpncpy+0x1ce>
    23c4:	00078623          	sb	zero,12(a5)
    23c8:	26b5                	addiw	a3,a3,13
    23ca:	06c6f163          	bgeu	a3,a2,242c <stpncpy+0x1ce>
    23ce:	000786a3          	sb	zero,13(a5)
    23d2:	8082                	ret
			;
		if (!n || !*s)
    23d4:	c645                	beqz	a2,247c <stpncpy+0x21e>
    23d6:	0005c783          	lbu	a5,0(a1)
    23da:	ea078be3          	beqz	a5,2290 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    23de:	479d                	li	a5,7
    23e0:	02c7ff63          	bgeu	a5,a2,241e <stpncpy+0x1c0>
    23e4:	00000897          	auipc	a7,0x0
    23e8:	6248b883          	ld	a7,1572(a7) # 2a08 <enable_deadlock_detect+0x192>
    23ec:	00000817          	auipc	a6,0x0
    23f0:	62483803          	ld	a6,1572(a6) # 2a10 <enable_deadlock_detect+0x19a>
    23f4:	431d                	li	t1,7
    23f6:	6198                	ld	a4,0(a1)
    23f8:	011707b3          	add	a5,a4,a7
    23fc:	fff74693          	not	a3,a4
    2400:	8ff5                	and	a5,a5,a3
    2402:	0107f7b3          	and	a5,a5,a6
    2406:	ef81                	bnez	a5,241e <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2408:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    240a:	1661                	addi	a2,a2,-8
    240c:	05a1                	addi	a1,a1,8
    240e:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2410:	fec363e3          	bltu	t1,a2,23f6 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2414:	e609                	bnez	a2,241e <stpncpy+0x1c0>
    2416:	a08d                	j	2478 <stpncpy+0x21a>
    2418:	167d                	addi	a2,a2,-1
    241a:	0505                	addi	a0,a0,1
    241c:	ca01                	beqz	a2,242c <stpncpy+0x1ce>
    241e:	0005c783          	lbu	a5,0(a1)
    2422:	0585                	addi	a1,a1,1
    2424:	00f50023          	sb	a5,0(a0)
    2428:	fbe5                	bnez	a5,2418 <stpncpy+0x1ba>
		;
tail:
    242a:	b59d                	j	2290 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    242c:	8082                	ret
    242e:	472d                	li	a4,11
    2430:	bdb5                	j	22ac <stpncpy+0x4e>
    2432:	00778713          	addi	a4,a5,7
    2436:	45ad                	li	a1,11
    2438:	fff60693          	addi	a3,a2,-1
    243c:	e6b778e3          	bgeu	a4,a1,22ac <stpncpy+0x4e>
    2440:	b7fd                	j	242e <stpncpy+0x1d0>
    2442:	40a007b3          	neg	a5,a0
    2446:	8832                	mv	a6,a2
    2448:	8b9d                	andi	a5,a5,7
    244a:	4681                	li	a3,0
    244c:	e4060be3          	beqz	a2,22a2 <stpncpy+0x44>
    2450:	b7cd                	j	2432 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2452:	468d                	li	a3,3
    2454:	bd75                	j	2310 <stpncpy+0xb2>
    2456:	872a                	mv	a4,a0
    2458:	4681                	li	a3,0
    245a:	bd5d                	j	2310 <stpncpy+0xb2>
    245c:	4685                	li	a3,1
    245e:	bd4d                	j	2310 <stpncpy+0xb2>
    2460:	8082                	ret
    2462:	87aa                	mv	a5,a0
    2464:	4681                	li	a3,0
    2466:	b5f9                	j	2334 <stpncpy+0xd6>
    2468:	4689                	li	a3,2
    246a:	b55d                	j	2310 <stpncpy+0xb2>
    246c:	4691                	li	a3,4
    246e:	b54d                	j	2310 <stpncpy+0xb2>
    2470:	4695                	li	a3,5
    2472:	bd79                	j	2310 <stpncpy+0xb2>
    2474:	4699                	li	a3,6
    2476:	bd69                	j	2310 <stpncpy+0xb2>
    2478:	8082                	ret
    247a:	8082                	ret
    247c:	8082                	ret

000000000000247e <basename>:

char *basename(char *s)
{
    247e:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2480:	c54d                	beqz	a0,252a <basename+0xac>
    2482:	00054783          	lbu	a5,0(a0)
		return ".";
    2486:	00000517          	auipc	a0,0x0
    248a:	57a50513          	addi	a0,a0,1402 # 2a00 <enable_deadlock_detect+0x18a>
	if (!s || !*s)
    248e:	e391                	bnez	a5,2492 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2490:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2492:	0076f713          	andi	a4,a3,7
    2496:	87b6                	mv	a5,a3
    2498:	cf51                	beqz	a4,2534 <basename+0xb6>
    249a:	0785                	addi	a5,a5,1
    249c:	0077f713          	andi	a4,a5,7
    24a0:	c729                	beqz	a4,24ea <basename+0x6c>
		if (!*s)
    24a2:	0007c703          	lbu	a4,0(a5)
    24a6:	fb75                	bnez	a4,249a <basename+0x1c>
	return s - a;
    24a8:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24aa:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24ac:	cf8d                	beqz	a5,24e6 <basename+0x68>
    24ae:	00f68733          	add	a4,a3,a5
    24b2:	02f00593          	li	a1,47
    24b6:	a031                	j	24c2 <basename+0x44>
		s[i] = 0;
    24b8:	00070023          	sb	zero,0(a4) # 10003000 <.got.plt+0x100004a8>
	for (; i && s[i] == '/'; i--)
    24bc:	17fd                	addi	a5,a5,-1
    24be:	177d                	addi	a4,a4,-1
    24c0:	c39d                	beqz	a5,24e6 <basename+0x68>
    24c2:	00074603          	lbu	a2,0(a4)
    24c6:	feb609e3          	beq	a2,a1,24b8 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    24ca:	02f00613          	li	a2,47
    24ce:	a011                	j	24d2 <basename+0x54>
    24d0:	cb99                	beqz	a5,24e6 <basename+0x68>
    24d2:	853e                	mv	a0,a5
    24d4:	17fd                	addi	a5,a5,-1
    24d6:	00f68733          	add	a4,a3,a5
    24da:	00074703          	lbu	a4,0(a4)
    24de:	fec719e3          	bne	a4,a2,24d0 <basename+0x52>
	return s + i;
    24e2:	9536                	add	a0,a0,a3
    24e4:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    24e6:	8536                	mv	a0,a3
    24e8:	8082                	ret
    24ea:	6390                	ld	a2,0(a5)
    24ec:	00000517          	auipc	a0,0x0
    24f0:	51c53503          	ld	a0,1308(a0) # 2a08 <enable_deadlock_detect+0x192>
    24f4:	00000597          	auipc	a1,0x0
    24f8:	51c5b583          	ld	a1,1308(a1) # 2a10 <enable_deadlock_detect+0x19a>
    24fc:	fff64713          	not	a4,a2
    2500:	962a                	add	a2,a2,a0
    2502:	8f71                	and	a4,a4,a2
    2504:	8f6d                	and	a4,a4,a1
    2506:	eb11                	bnez	a4,251a <basename+0x9c>
    2508:	6790                	ld	a2,8(a5)
    250a:	07a1                	addi	a5,a5,8
    250c:	00a60733          	add	a4,a2,a0
    2510:	fff64613          	not	a2,a2
    2514:	8f71                	and	a4,a4,a2
    2516:	8f6d                	and	a4,a4,a1
    2518:	db65                	beqz	a4,2508 <basename+0x8a>
	for (; *s; s++)
    251a:	0007c703          	lbu	a4,0(a5)
    251e:	d749                	beqz	a4,24a8 <basename+0x2a>
    2520:	0017c703          	lbu	a4,1(a5)
    2524:	0785                	addi	a5,a5,1
    2526:	ff6d                	bnez	a4,2520 <basename+0xa2>
    2528:	b741                	j	24a8 <basename+0x2a>
		return ".";
    252a:	00000517          	auipc	a0,0x0
    252e:	4d650513          	addi	a0,a0,1238 # 2a00 <enable_deadlock_detect+0x18a>
    2532:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2534:	6290                	ld	a2,0(a3)
    2536:	00000517          	auipc	a0,0x0
    253a:	4d253503          	ld	a0,1234(a0) # 2a08 <enable_deadlock_detect+0x192>
    253e:	00000597          	auipc	a1,0x0
    2542:	4d25b583          	ld	a1,1234(a1) # 2a10 <enable_deadlock_detect+0x19a>
    2546:	fff64713          	not	a4,a2
    254a:	962a                	add	a2,a2,a0
    254c:	8f71                	and	a4,a4,a2
    254e:	8f6d                	and	a4,a4,a1
    2550:	df45                	beqz	a4,2508 <basename+0x8a>
    2552:	b7f9                	j	2520 <basename+0xa2>

0000000000002554 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2554:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2558:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    255a:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    255e:	2501                	sext.w	a0,a0
    2560:	8082                	ret

0000000000002562 <close>:

int close(int fd)
{
	if (fd == 1) {
    2562:	4785                	li	a5,1
    2564:	00f50863          	beq	a0,a5,2574 <close+0x12>
	register long a7 __asm__("a7") = n;
    2568:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    256c:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2570:	2501                	sext.w	a0,a0
    2572:	8082                	ret
{
    2574:	1101                	addi	sp,sp,-32
    2576:	ec06                	sd	ra,24(sp)
    2578:	e42a                	sd	a0,8(sp)
		__write_buffer();
    257a:	cdffe0ef          	jal	ra,1258 <__write_buffer>
		__clear_buffer();
    257e:	d03fe0ef          	jal	ra,1280 <__clear_buffer>
    2582:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2584:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2588:	00000073          	ecall
}
    258c:	60e2                	ld	ra,24(sp)
    258e:	2501                	sext.w	a0,a0
    2590:	6105                	addi	sp,sp,32
    2592:	8082                	ret

0000000000002594 <read>:
	register long a7 __asm__("a7") = n;
    2594:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2598:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    259c:	8082                	ret

000000000000259e <write>:
	register long a7 __asm__("a7") = n;
    259e:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25a2:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    25a6:	8082                	ret

00000000000025a8 <getpid>:
	register long a7 __asm__("a7") = n;
    25a8:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25ac:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25b0:	2501                	sext.w	a0,a0
    25b2:	8082                	ret

00000000000025b4 <getppid>:
	register long a7 __asm__("a7") = n;
    25b4:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25b8:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    25bc:	2501                	sext.w	a0,a0
    25be:	8082                	ret

00000000000025c0 <sched_yield>:
	register long a7 __asm__("a7") = n;
    25c0:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    25c4:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret

00000000000025cc <fork>:
	register long a7 __asm__("a7") = n;
    25cc:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    25d0:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    25d4:	2501                	sext.w	a0,a0
    25d6:	8082                	ret

00000000000025d8 <exit>:

void exit(int code)
{
    25d8:	1141                	addi	sp,sp,-16
    25da:	e406                	sd	ra,8(sp)
    25dc:	e022                	sd	s0,0(sp)
    25de:	842a                	mv	s0,a0
	__write_buffer();
    25e0:	c79fe0ef          	jal	ra,1258 <__write_buffer>
	__clear_buffer();
    25e4:	c9dfe0ef          	jal	ra,1280 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    25e8:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    25ec:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    25ee:	00000073          	ecall
	syscall(SYS_exit, code);
}
    25f2:	60a2                	ld	ra,8(sp)
    25f4:	6402                	ld	s0,0(sp)
    25f6:	0141                	addi	sp,sp,16
    25f8:	8082                	ret

00000000000025fa <waitpid>:
	register long a7 __asm__("a7") = n;
    25fa:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25fe:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2602:	2501                	sext.w	a0,a0
    2604:	8082                	ret

0000000000002606 <exec>:
	register long a7 __asm__("a7") = n;
    2606:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    260a:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    260e:	2501                	sext.w	a0,a0
    2610:	8082                	ret

0000000000002612 <get_mtime>:

int64 get_mtime()
{
    2612:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2614:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2618:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    261a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261c:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2620:	2501                	sext.w	a0,a0
    2622:	ed01                	bnez	a0,263a <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2624:	6722                	ld	a4,8(sp)
    2626:	3e800793          	li	a5,1000
    262a:	6682                	ld	a3,0(sp)
    262c:	02f75733          	divu	a4,a4,a5
    2630:	02d78533          	mul	a0,a5,a3
    2634:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2636:	0141                	addi	sp,sp,16
    2638:	8082                	ret
	return -1;
    263a:	557d                	li	a0,-1
    263c:	bfed                	j	2636 <get_mtime+0x24>

000000000000263e <sys_get_time>:
	register long a7 __asm__("a7") = n;
    263e:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2642:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret

000000000000264a <sleep>:

int sleep(unsigned long long time)
{
    264a:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    264c:	880a                	mv	a6,sp
{
    264e:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2650:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2654:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2656:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2658:	00000073          	ecall
	if (err == 0) {
    265c:	2501                	sext.w	a0,a0
    265e:	ed31                	bnez	a0,26ba <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2660:	6722                	ld	a4,8(sp)
    2662:	3e800793          	li	a5,1000
    2666:	6682                	ld	a3,0(sp)
    2668:	02f75733          	divu	a4,a4,a5
    266c:	02d787b3          	mul	a5,a5,a3
    2670:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2672:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2676:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2678:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267a:	00000073          	ecall
	if (err == 0) {
    267e:	2501                	sext.w	a0,a0
    2680:	e915                	bnez	a0,26b4 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2682:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2684:	3e800693          	li	a3,1000
    2688:	a819                	j	269e <sleep+0x54>
	__asm_syscall("r"(a7))
    268a:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    268e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2692:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2694:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2696:	00000073          	ecall
	if (err == 0) {
    269a:	2501                	sext.w	a0,a0
    269c:	ed01                	bnez	a0,26b4 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    269e:	6722                	ld	a4,8(sp)
    26a0:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    26a2:	07c00893          	li	a7,124
    26a6:	02d75733          	divu	a4,a4,a3
    26aa:	02f687b3          	mul	a5,a3,a5
    26ae:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26b0:	fcc7ede3          	bltu	a5,a2,268a <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26b4:	4501                	li	a0,0
    26b6:	0141                	addi	sp,sp,16
    26b8:	8082                	ret
    26ba:	57fd                	li	a5,-1
    26bc:	bf5d                	j	2672 <sleep+0x28>

00000000000026be <sys_task_info>:
	register long a7 __asm__("a7") = n;
    26be:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    26c2:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <set_priority>:
	register long a7 __asm__("a7") = n;
    26ca:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    26d6:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26da:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <munmap>:
	register long a7 __asm__("a7") = n;
    26e2:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26e6:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    26ea:	2501                	sext.w	a0,a0
    26ec:	8082                	ret

00000000000026ee <wait>:

int wait(int *code)
{
    26ee:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26f0:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    26f4:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26f6:	00000073          	ecall
	return waitpid(-1, code);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret

00000000000026fe <spawn>:
	register long a7 __asm__("a7") = n;
    26fe:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2702:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2706:	2501                	sext.w	a0,a0
    2708:	8082                	ret

000000000000270a <pipe>:
	register long a7 __asm__("a7") = n;
    270a:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    270e:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2712:	2501                	sext.w	a0,a0
    2714:	8082                	ret

0000000000002716 <mailread>:
	register long a7 __asm__("a7") = n;
    2716:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    271a:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    271e:	2501                	sext.w	a0,a0
    2720:	8082                	ret

0000000000002722 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2722:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2726:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    272a:	2501                	sext.w	a0,a0
    272c:	8082                	ret

000000000000272e <fstat>:
	register long a7 __asm__("a7") = n;
    272e:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2732:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2736:	2501                	sext.w	a0,a0
    2738:	8082                	ret

000000000000273a <sys_linkat>:
	register long a4 __asm__("a4") = e;
    273a:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    273c:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2740:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2742:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2746:	2501                	sext.w	a0,a0
    2748:	8082                	ret

000000000000274a <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    274a:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    274c:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2750:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2752:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <link>:

int link(char *old_path, char *new_path)
{
    275a:	87aa                	mv	a5,a0
    275c:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    275e:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2762:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2766:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2768:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    276c:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    276e:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2772:	2501                	sext.w	a0,a0
    2774:	8082                	ret

0000000000002776 <unlink>:

int unlink(char *path)
{
    2776:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2778:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    277c:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2780:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2782:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2786:	2501                	sext.w	a0,a0
    2788:	8082                	ret

000000000000278a <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    278a:	00000797          	auipc	a5,0x0
    278e:	3c67b783          	ld	a5,966(a5) # 2b50 <_GLOBAL_OFFSET_TABLE_+0x8>
    2792:	439c                	lw	a5,0(a5)
    2794:	c799                	beqz	a5,27a2 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2796:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    279a:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    279e:	2501                	sext.w	a0,a0
    27a0:	8082                	ret
{
    27a2:	1101                	addi	sp,sp,-32
    27a4:	ec06                	sd	ra,24(sp)
    27a6:	e42e                	sd	a1,8(sp)
    27a8:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27aa:	fe7fe0ef          	jal	ra,1790 <enable_thread_io_buffer>
    27ae:	65a2                	ld	a1,8(sp)
    27b0:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27b2:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27b6:	00000073          	ecall
}
    27ba:	60e2                	ld	ra,24(sp)
    27bc:	2501                	sext.w	a0,a0
    27be:	6105                	addi	sp,sp,32
    27c0:	8082                	ret

00000000000027c2 <gettid>:
	register long a7 __asm__("a7") = n;
    27c2:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    27c6:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    27ca:	2501                	sext.w	a0,a0
    27cc:	8082                	ret

00000000000027ce <waittid>:

int waittid(int tid)
{
    27ce:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    27d0:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    27d4:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    27d8:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    27da:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27dc:	00e51e63          	bne	a0,a4,27f8 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    27e0:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    27e4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    27e8:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    27ec:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    27ee:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    27f2:	2501                	sext.w	a0,a0
	while (ret == -2) {
    27f4:	fee506e3          	beq	a0,a4,27e0 <waittid+0x12>
	}
	return ret;
}
    27f8:	8082                	ret

00000000000027fa <mutex_create>:
	register long a7 __asm__("a7") = n;
    27fa:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    27fe:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2800:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2804:	2501                	sext.w	a0,a0
    2806:	8082                	ret

0000000000002808 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2808:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    280c:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    280e:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2812:	2501                	sext.w	a0,a0
    2814:	8082                	ret

0000000000002816 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2816:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    281a:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    281e:	2501                	sext.w	a0,a0
    2820:	8082                	ret

0000000000002822 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2822:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2826:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    282a:	2501                	sext.w	a0,a0
    282c:	8082                	ret

000000000000282e <semaphore_create>:
	register long a7 __asm__("a7") = n;
    282e:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2832:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2836:	2501                	sext.w	a0,a0
    2838:	8082                	ret

000000000000283a <semaphore_up>:
	register long a7 __asm__("a7") = n;
    283a:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    283e:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2842:	2501                	sext.w	a0,a0
    2844:	8082                	ret

0000000000002846 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2846:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    284a:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    284e:	2501                	sext.w	a0,a0
    2850:	8082                	ret

0000000000002852 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2852:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2856:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    285a:	2501                	sext.w	a0,a0
    285c:	8082                	ret

000000000000285e <condvar_signal>:
	register long a7 __asm__("a7") = n;
    285e:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2862:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2866:	2501                	sext.w	a0,a0
    2868:	8082                	ret

000000000000286a <condvar_wait>:
	register long a7 __asm__("a7") = n;
    286a:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    286e:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2872:	2501                	sext.w	a0,a0
    2874:	8082                	ret

0000000000002876 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2876:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    287a:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    287e:	2501                	sext.w	a0,a0
    2880:	8082                	ret
