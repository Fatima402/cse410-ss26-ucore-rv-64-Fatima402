
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch2b_power:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a885                	j	1070 <__start_main>

0000000000001002 <main>:
/// 3^90000=2621
/// 3^100000=2749
/// Test power OK!

int main()
{
    1002:	7139                	addi	sp,sp,-64
    1004:	f04a                	sd	s2,32(sp)
    1006:	ec4e                	sd	s3,24(sp)
	int i, last;
	pow[index] = 1;
	for (i = 1; i <= STEP; ++i) {
		last = pow[index];
		index = (index + 1) % SIZE;
		pow[index] = (last * P) % MOD;
    1008:	6909                	lui	s2,0x2
	for (i = 1; i <= STEP; ++i) {
    100a:	69e1                	lui	s3,0x18
{
    100c:	f822                	sd	s0,48(sp)
    100e:	f426                	sd	s1,40(sp)
    1010:	e852                	sd	s4,16(sp)
    1012:	e456                	sd	s5,8(sp)
		pow[index] = (last * P) % MOD;
    1014:	71790a1b          	addiw	s4,s2,1815
{
    1018:	fc06                	sd	ra,56(sp)
    101a:	440d                	li	s0,3
	for (i = 1; i <= STEP; ++i) {
    101c:	4489                	li	s1,2
		pow[index] = (last * P) % MOD;
    101e:	7109091b          	addiw	s2,s2,1808
		if ((i % 10000) == 0) {
			printf("%d^%d=%d\n", P, i, pow[index]);
    1022:	00001a97          	auipc	s5,0x1
    1026:	6b6a8a93          	addi	s5,s5,1718 # 26d8 <enable_deadlock_detect+0xe>
	for (i = 1; i <= STEP; ++i) {
    102a:	6a198993          	addi	s3,s3,1697 # 186a1 <.got.plt+0x15d61>
		if ((i % 10000) == 0) {
    102e:	0324e7bb          	remw	a5,s1,s2
		pow[index] = (last * P) % MOD;
    1032:	0014171b          	slliw	a4,s0,0x1
    1036:	9c39                	addw	s0,s0,a4
    1038:	0344643b          	remw	s0,s0,s4
		if ((i % 10000) == 0) {
    103c:	e799                	bnez	a5,104a <main+0x48>
			printf("%d^%d=%d\n", P, i, pow[index]);
    103e:	8626                	mv	a2,s1
    1040:	458d                	li	a1,3
    1042:	8556                	mv	a0,s5
    1044:	86a2                	mv	a3,s0
    1046:	184000ef          	jal	ra,11ca <printf>
	for (i = 1; i <= STEP; ++i) {
    104a:	2485                	addiw	s1,s1,1
    104c:	ff3491e3          	bne	s1,s3,102e <main+0x2c>
		}
	}
	puts("Test power OK!");
    1050:	00001517          	auipc	a0,0x1
    1054:	69850513          	addi	a0,a0,1688 # 26e8 <enable_deadlock_detect+0x1e>
    1058:	089000ef          	jal	ra,18e0 <puts>
	return 0;
}
    105c:	70e2                	ld	ra,56(sp)
    105e:	7442                	ld	s0,48(sp)
    1060:	74a2                	ld	s1,40(sp)
    1062:	7902                	ld	s2,32(sp)
    1064:	69e2                	ld	s3,24(sp)
    1066:	6a42                	ld	s4,16(sp)
    1068:	6aa2                	ld	s5,8(sp)
    106a:	4501                	li	a0,0
    106c:	6121                	addi	sp,sp,64
    106e:	8082                	ret

0000000000001070 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1070:	1141                	addi	sp,sp,-16
    1072:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1074:	f8fff0ef          	jal	ra,1002 <main>
    1078:	3b4010ef          	jal	ra,242c <exit>
	return 0;
    107c:	60a2                	ld	ra,8(sp)
    107e:	4501                	li	a0,0
    1080:	0141                	addi	sp,sp,16
    1082:	8082                	ret

0000000000001084 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1084:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1086:	4605                	li	a2,1
    1088:	00f10593          	addi	a1,sp,15
    108c:	4501                	li	a0,0
{
    108e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1090:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1094:	354010ef          	jal	ra,23e8 <read>
    1098:	4785                	li	a5,1
    109a:	00f51763          	bne	a0,a5,10a8 <getchar+0x24>
		return byte;
    109e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10a2:	60e2                	ld	ra,24(sp)
    10a4:	6105                	addi	sp,sp,32
    10a6:	8082                	ret
		return EOF;
    10a8:	557d                	li	a0,-1
    10aa:	bfe5                	j	10a2 <getchar+0x1e>

00000000000010ac <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10ac:	00001517          	auipc	a0,0x1
    10b0:	74c52503          	lw	a0,1868(a0) # 27f8 <buffer_len>
    10b4:	e111                	bnez	a0,10b8 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10b6:	8082                	ret
{
    10b8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ba:	862a                	mv	a2,a0
    10bc:	00001597          	auipc	a1,0x1
    10c0:	74458593          	addi	a1,a1,1860 # 2800 <buffer>
    10c4:	4505                	li	a0,1
{
    10c6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10c8:	32a010ef          	jal	ra,23f2 <write>
}
    10cc:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10ce:	2501                	sext.w	a0,a0
}
    10d0:	0141                	addi	sp,sp,16
    10d2:	8082                	ret

00000000000010d4 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10d4:	00001797          	auipc	a5,0x1
    10d8:	7207a223          	sw	zero,1828(a5) # 27f8 <buffer_len>
}
    10dc:	8082                	ret

00000000000010de <__fflush>:
	if (buffer_len == 0)
    10de:	00001517          	auipc	a0,0x1
    10e2:	71a52503          	lw	a0,1818(a0) # 27f8 <buffer_len>
    10e6:	e511                	bnez	a0,10f2 <__fflush+0x14>
	buffer_len = 0;
    10e8:	00001797          	auipc	a5,0x1
    10ec:	7007a823          	sw	zero,1808(a5) # 27f8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10f0:	8082                	ret
{
    10f2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10f4:	862a                	mv	a2,a0
    10f6:	00001597          	auipc	a1,0x1
    10fa:	70a58593          	addi	a1,a1,1802 # 2800 <buffer>
    10fe:	4505                	li	a0,1
{
    1100:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1102:	2f0010ef          	jal	ra,23f2 <write>
	return r >= 0 ? 0 : r;
    1106:	0005079b          	sext.w	a5,a0
}
    110a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    110c:	0017a793          	slti	a5,a5,1
    1110:	40f007bb          	negw	a5,a5
    1114:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1116:	00001797          	auipc	a5,0x1
    111a:	6e07a123          	sw	zero,1762(a5) # 27f8 <buffer_len>
	return r >= 0 ? 0 : r;
    111e:	2501                	sext.w	a0,a0
}
    1120:	0141                	addi	sp,sp,16
    1122:	8082                	ret

0000000000001124 <fflush>:

int fflush(int fd)
{
    1124:	1101                	addi	sp,sp,-32
    1126:	e822                	sd	s0,16(sp)
    1128:	ec06                	sd	ra,24(sp)
    112a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    112c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    112e:	4401                	li	s0,0
	if (fd == 1) {
    1130:	00e50863          	beq	a0,a4,1140 <fflush+0x1c>
}
    1134:	60e2                	ld	ra,24(sp)
    1136:	8522                	mv	a0,s0
    1138:	6442                	ld	s0,16(sp)
    113a:	64a2                	ld	s1,8(sp)
    113c:	6105                	addi	sp,sp,32
    113e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1140:	00001497          	auipc	s1,0x1
    1144:	6b848493          	addi	s1,s1,1720 # 27f8 <buffer_len>
    1148:	1084a703          	lw	a4,264(s1)
    114c:	02a70e63          	beq	a4,a0,1188 <fflush+0x64>
	if (buffer_len == 0)
    1150:	4080                	lw	s0,0(s1)
    1152:	c00d                	beqz	s0,1174 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1154:	8622                	mv	a2,s0
    1156:	00001597          	auipc	a1,0x1
    115a:	6aa58593          	addi	a1,a1,1706 # 2800 <buffer>
    115e:	294010ef          	jal	ra,23f2 <write>
	return r >= 0 ? 0 : r;
    1162:	0005079b          	sext.w	a5,a0
    1166:	0017a793          	slti	a5,a5,1
    116a:	40f007bb          	negw	a5,a5
    116e:	8d7d                	and	a0,a0,a5
    1170:	0005041b          	sext.w	s0,a0
}
    1174:	60e2                	ld	ra,24(sp)
    1176:	8522                	mv	a0,s0
    1178:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    117a:	00001797          	auipc	a5,0x1
    117e:	6607af23          	sw	zero,1662(a5) # 27f8 <buffer_len>
}
    1182:	64a2                	ld	s1,8(sp)
    1184:	6105                	addi	sp,sp,32
    1186:	8082                	ret
			mutex_lock(buffer_lock);
    1188:	10c4a503          	lw	a0,268(s1)
    118c:	4de010ef          	jal	ra,266a <mutex_lock>
	if (buffer_len == 0)
    1190:	4080                	lw	s0,0(s1)
    1192:	e811                	bnez	s0,11a6 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1194:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1198:	00001797          	auipc	a5,0x1
    119c:	6607a023          	sw	zero,1632(a5) # 27f8 <buffer_len>
			mutex_unlock(buffer_lock);
    11a0:	4d6010ef          	jal	ra,2676 <mutex_unlock>
    11a4:	bf41                	j	1134 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11a6:	8622                	mv	a2,s0
    11a8:	00001597          	auipc	a1,0x1
    11ac:	65858593          	addi	a1,a1,1624 # 2800 <buffer>
    11b0:	4505                	li	a0,1
    11b2:	240010ef          	jal	ra,23f2 <write>
	return r >= 0 ? 0 : r;
    11b6:	0005079b          	sext.w	a5,a0
    11ba:	0017a793          	slti	a5,a5,1
    11be:	40f007bb          	negw	a5,a5
    11c2:	8d7d                	and	a0,a0,a5
    11c4:	0005041b          	sext.w	s0,a0
	return r;
    11c8:	b7f1                	j	1194 <fflush+0x70>

00000000000011ca <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11ca:	7131                	addi	sp,sp,-192
    11cc:	e0da                	sd	s6,64(sp)
    11ce:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11d0:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11d2:	013c                	addi	a5,sp,136
{
    11d4:	f0ca                	sd	s2,96(sp)
    11d6:	ecce                	sd	s3,88(sp)
    11d8:	e8d2                	sd	s4,80(sp)
    11da:	e4d6                	sd	s5,72(sp)
    11dc:	fc86                	sd	ra,120(sp)
    11de:	f8a2                	sd	s0,112(sp)
    11e0:	f4a6                	sd	s1,104(sp)
    11e2:	89aa                	mv	s3,a0
    11e4:	e52e                	sd	a1,136(sp)
    11e6:	e932                	sd	a2,144(sp)
    11e8:	ed36                	sd	a3,152(sp)
    11ea:	f13a                	sd	a4,160(sp)
    11ec:	f942                	sd	a6,176(sp)
    11ee:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11f0:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11f2:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11f6:	00001a17          	auipc	s4,0x1
    11fa:	602a0a13          	addi	s4,s4,1538 # 27f8 <buffer_len>
    11fe:	4a85                	li	s5,1
	buf[i++] = '0';
    1200:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1204:	0009c783          	lbu	a5,0(s3)
    1208:	18078663          	beqz	a5,1394 <printf+0x1ca>
    120c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    120e:	19278d63          	beq	a5,s2,13a8 <printf+0x1de>
    1212:	0015c783          	lbu	a5,1(a1)
    1216:	0585                	addi	a1,a1,1
    1218:	fbfd                	bnez	a5,120e <printf+0x44>
    121a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    121c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1220:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1224:	1b578863          	beq	a5,s5,13d4 <printf+0x20a>
		len = out_unlocked(s, l);
    1228:	85a2                	mv	a1,s0
    122a:	854e                	mv	a0,s3
    122c:	42a000ef          	jal	ra,1656 <out_unlocked>
		out(f, a, l);
		if (l)
    1230:	1c041063          	bnez	s0,13f0 <printf+0x226>
			continue;
		if (s[1] == 0)
    1234:	0014c783          	lbu	a5,1(s1)
    1238:	14078e63          	beqz	a5,1394 <printf+0x1ca>
			break;
		switch (s[1]) {
    123c:	07300713          	li	a4,115
    1240:	1ce78863          	beq	a5,a4,1410 <printf+0x246>
    1244:	1af76863          	bltu	a4,a5,13f4 <printf+0x22a>
    1248:	06400713          	li	a4,100
    124c:	22e78063          	beq	a5,a4,146c <printf+0x2a2>
    1250:	07000713          	li	a4,112
    1254:	1ee79563          	bne	a5,a4,143e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1258:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    125a:	00001797          	auipc	a5,0x1
    125e:	6be78793          	addi	a5,a5,1726 # 2918 <digits>
	buf[i++] = '0';
    1262:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1266:	6298                	ld	a4,0(a3)
    1268:	06a1                	addi	a3,a3,8
    126a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    126c:	00471393          	slli	t2,a4,0x4
    1270:	00871293          	slli	t0,a4,0x8
    1274:	00c71f93          	slli	t6,a4,0xc
    1278:	01071f13          	slli	t5,a4,0x10
    127c:	01471e93          	slli	t4,a4,0x14
    1280:	01871e13          	slli	t3,a4,0x18
    1284:	01c71893          	slli	a7,a4,0x1c
    1288:	02471813          	slli	a6,a4,0x24
    128c:	02871513          	slli	a0,a4,0x28
    1290:	02c71593          	slli	a1,a4,0x2c
    1294:	03071613          	slli	a2,a4,0x30
    1298:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    129c:	03c75413          	srli	s0,a4,0x3c
    12a0:	01c7531b          	srliw	t1,a4,0x1c
    12a4:	03c3d393          	srli	t2,t2,0x3c
    12a8:	03c2d293          	srli	t0,t0,0x3c
    12ac:	03cfdf93          	srli	t6,t6,0x3c
    12b0:	03cf5f13          	srli	t5,t5,0x3c
    12b4:	03cede93          	srli	t4,t4,0x3c
    12b8:	03ce5e13          	srli	t3,t3,0x3c
    12bc:	03c8d893          	srli	a7,a7,0x3c
    12c0:	03c85813          	srli	a6,a6,0x3c
    12c4:	9171                	srli	a0,a0,0x3c
    12c6:	91f1                	srli	a1,a1,0x3c
    12c8:	9271                	srli	a2,a2,0x3c
    12ca:	92f1                	srli	a3,a3,0x3c
    12cc:	95be                	add	a1,a1,a5
    12ce:	963e                	add	a2,a2,a5
    12d0:	96be                	add	a3,a3,a5
    12d2:	943e                	add	s0,s0,a5
    12d4:	93be                	add	t2,t2,a5
    12d6:	92be                	add	t0,t0,a5
    12d8:	9fbe                	add	t6,t6,a5
    12da:	9f3e                	add	t5,t5,a5
    12dc:	9ebe                	add	t4,t4,a5
    12de:	9e3e                	add	t3,t3,a5
    12e0:	98be                	add	a7,a7,a5
    12e2:	933e                	add	t1,t1,a5
    12e4:	983e                	add	a6,a6,a5
    12e6:	953e                	add	a0,a0,a5
    12e8:	0005c983          	lbu	s3,0(a1)
    12ec:	00044403          	lbu	s0,0(s0)
    12f0:	00064583          	lbu	a1,0(a2)
    12f4:	0003c383          	lbu	t2,0(t2)
    12f8:	0006c603          	lbu	a2,0(a3)
    12fc:	0002c283          	lbu	t0,0(t0)
    1300:	000fcf83          	lbu	t6,0(t6)
    1304:	000f4f03          	lbu	t5,0(t5)
    1308:	000ece83          	lbu	t4,0(t4)
    130c:	000e4e03          	lbu	t3,0(t3)
    1310:	0008c883          	lbu	a7,0(a7)
    1314:	00034303          	lbu	t1,0(t1)
    1318:	00084803          	lbu	a6,0(a6)
    131c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1320:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1324:	92f1                	srli	a3,a3,0x3c
    1326:	8b3d                	andi	a4,a4,15
    1328:	96be                	add	a3,a3,a5
    132a:	97ba                	add	a5,a5,a4
    132c:	00810d23          	sb	s0,26(sp)
    1330:	00710da3          	sb	t2,27(sp)
    1334:	00510e23          	sb	t0,28(sp)
    1338:	01f10ea3          	sb	t6,29(sp)
    133c:	01e10f23          	sb	t5,30(sp)
    1340:	01d10fa3          	sb	t4,31(sp)
    1344:	03c10023          	sb	t3,32(sp)
    1348:	031100a3          	sb	a7,33(sp)
    134c:	02610123          	sb	t1,34(sp)
    1350:	030101a3          	sb	a6,35(sp)
    1354:	02a10223          	sb	a0,36(sp)
    1358:	033102a3          	sb	s3,37(sp)
    135c:	02b10323          	sb	a1,38(sp)
    1360:	02c103a3          	sb	a2,39(sp)
    1364:	0006c683          	lbu	a3,0(a3)
    1368:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    136c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1370:	02d10423          	sb	a3,40(sp)
    1374:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1378:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    137c:	11578263          	beq	a5,s5,1480 <printf+0x2b6>
		len = out_unlocked(s, l);
    1380:	45c9                	li	a1,18
    1382:	0828                	addi	a0,sp,24
    1384:	2d2000ef          	jal	ra,1656 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1388:	00248993          	addi	s3,s1,2
		if (!*s)
    138c:	0009c783          	lbu	a5,0(s3)
    1390:	e6079ee3          	bnez	a5,120c <printf+0x42>
	}
	va_end(ap);
    1394:	70e6                	ld	ra,120(sp)
    1396:	7446                	ld	s0,112(sp)
    1398:	74a6                	ld	s1,104(sp)
    139a:	7906                	ld	s2,96(sp)
    139c:	69e6                	ld	s3,88(sp)
    139e:	6a46                	ld	s4,80(sp)
    13a0:	6aa6                	ld	s5,72(sp)
    13a2:	6b06                	ld	s6,64(sp)
    13a4:	6129                	addi	sp,sp,192
    13a6:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13a8:	0005c783          	lbu	a5,0(a1)
    13ac:	84ae                	mv	s1,a1
    13ae:	01278963          	beq	a5,s2,13c0 <printf+0x1f6>
    13b2:	b5ad                	j	121c <printf+0x52>
    13b4:	0024c783          	lbu	a5,2(s1)
    13b8:	0585                	addi	a1,a1,1
    13ba:	0489                	addi	s1,s1,2
    13bc:	e72790e3          	bne	a5,s2,121c <printf+0x52>
    13c0:	0014c783          	lbu	a5,1(s1)
    13c4:	ff2788e3          	beq	a5,s2,13b4 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13c8:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13cc:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13d0:	e5579ce3          	bne	a5,s5,1228 <printf+0x5e>
		mutex_lock(buffer_lock);
    13d4:	10ca2503          	lw	a0,268(s4)
    13d8:	292010ef          	jal	ra,266a <mutex_lock>
		len = out_unlocked(s, l);
    13dc:	85a2                	mv	a1,s0
    13de:	854e                	mv	a0,s3
    13e0:	276000ef          	jal	ra,1656 <out_unlocked>
		mutex_unlock(buffer_lock);
    13e4:	10ca2503          	lw	a0,268(s4)
    13e8:	28e010ef          	jal	ra,2676 <mutex_unlock>
		if (l)
    13ec:	e40404e3          	beqz	s0,1234 <printf+0x6a>
    13f0:	89a6                	mv	s3,s1
    13f2:	bd09                	j	1204 <printf+0x3a>
		switch (s[1]) {
    13f4:	07800713          	li	a4,120
    13f8:	04e79363          	bne	a5,a4,143e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13fc:	67c2                	ld	a5,16(sp)
    13fe:	45c1                	li	a1,16
		s += 2;
    1400:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1404:	4388                	lw	a0,0(a5)
    1406:	07a1                	addi	a5,a5,8
    1408:	e83e                	sd	a5,16(sp)
    140a:	5f8000ef          	jal	ra,1a02 <printint.constprop.0>
		s += 2;
    140e:	bfbd                	j	138c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1410:	67c2                	ld	a5,16(sp)
    1412:	6380                	ld	s0,0(a5)
    1414:	07a1                	addi	a5,a5,8
    1416:	e83e                	sd	a5,16(sp)
    1418:	1c040163          	beqz	s0,15da <printf+0x410>
			l = strnlen(a, 200);
    141c:	0c800593          	li	a1,200
    1420:	8522                	mv	a0,s0
    1422:	3f7000ef          	jal	ra,2018 <strnlen>
	if (buffer_lock_enabled == 1) {
    1426:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    142a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    142e:	19578663          	beq	a5,s5,15ba <printf+0x3f0>
		len = out_unlocked(s, l);
    1432:	8522                	mv	a0,s0
    1434:	222000ef          	jal	ra,1656 <out_unlocked>
		s += 2;
    1438:	00248993          	addi	s3,s1,2
    143c:	bf81                	j	138c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    143e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1442:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1446:	0f578663          	beq	a5,s5,1532 <printf+0x368>
		len = out_unlocked(s, l);
    144a:	0828                	addi	a0,sp,24
    144c:	316000ef          	jal	ra,1762 <out_unlocked.constprop.0>
			putchar(s[1]);
    1450:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1454:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1458:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    145c:	05578163          	beq	a5,s5,149e <printf+0x2d4>
		len = out_unlocked(s, l);
    1460:	0828                	addi	a0,sp,24
    1462:	300000ef          	jal	ra,1762 <out_unlocked.constprop.0>
		s += 2;
    1466:	00248993          	addi	s3,s1,2
    146a:	b70d                	j	138c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    146c:	67c2                	ld	a5,16(sp)
    146e:	45a9                	li	a1,10
		s += 2;
    1470:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1474:	4388                	lw	a0,0(a5)
    1476:	07a1                	addi	a5,a5,8
    1478:	e83e                	sd	a5,16(sp)
    147a:	588000ef          	jal	ra,1a02 <printint.constprop.0>
		s += 2;
    147e:	b739                	j	138c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1480:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1484:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1488:	1e2010ef          	jal	ra,266a <mutex_lock>
		len = out_unlocked(s, l);
    148c:	45c9                	li	a1,18
    148e:	0828                	addi	a0,sp,24
    1490:	1c6000ef          	jal	ra,1656 <out_unlocked>
		mutex_unlock(buffer_lock);
    1494:	10ca2503          	lw	a0,268(s4)
    1498:	1de010ef          	jal	ra,2676 <mutex_unlock>
		s += 2;
    149c:	bdc5                	j	138c <printf+0x1c2>
		mutex_lock(buffer_lock);
    149e:	10ca2503          	lw	a0,268(s4)
    14a2:	1c8010ef          	jal	ra,266a <mutex_lock>
		buffer[buffer_len++] = c;
    14a6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14aa:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14ae:	0017861b          	addiw	a2,a5,1
    14b2:	97d2                	add	a5,a5,s4
    14b4:	00ca2023          	sw	a2,0(s4)
    14b8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14bc:	00c6cc63          	blt	a3,a2,14d4 <printf+0x30a>
    14c0:	47a9                	li	a5,10
    14c2:	06f40663          	beq	s0,a5,152e <printf+0x364>
		mutex_unlock(buffer_lock);
    14c6:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14ca:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14ce:	1a8010ef          	jal	ra,2676 <mutex_unlock>
		s += 2;
    14d2:	bd6d                	j	138c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14d4:	10000793          	li	a5,256
    14d8:	00f61e63          	bne	a2,a5,14f4 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14dc:	00001597          	auipc	a1,0x1
    14e0:	32458593          	addi	a1,a1,804 # 2800 <buffer>
    14e4:	4505                	li	a0,1
    14e6:	70d000ef          	jal	ra,23f2 <write>
	buffer_len = 0;
    14ea:	00001797          	auipc	a5,0x1
    14ee:	3007a723          	sw	zero,782(a5) # 27f8 <buffer_len>
			if (r < 0) {
    14f2:	bfd1                	j	14c6 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14f4:	709000ef          	jal	ra,23fc <getpid>
    14f8:	842a                	mv	s0,a0
    14fa:	00001517          	auipc	a0,0x1
    14fe:	20650513          	addi	a0,a0,518 # 2700 <enable_deadlock_detect+0x36>
    1502:	5d1000ef          	jal	ra,22d2 <basename>
    1506:	872a                	mv	a4,a0
    1508:	00001617          	auipc	a2,0x1
    150c:	23860613          	addi	a2,a2,568 # 2740 <enable_deadlock_detect+0x76>
    1510:	05400793          	li	a5,84
    1514:	86a2                	mv	a3,s0
    1516:	45fd                	li	a1,31
    1518:	00001517          	auipc	a0,0x1
    151c:	23050513          	addi	a0,a0,560 # 2748 <enable_deadlock_detect+0x7e>
    1520:	cabff0ef          	jal	ra,11ca <printf>
    1524:	557d                	li	a0,-1
    1526:	707000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    152a:	000a2603          	lw	a2,0(s4)
    152e:	de41                	beqz	a2,14c6 <printf+0x2fc>
    1530:	b775                	j	14dc <printf+0x312>
		mutex_lock(buffer_lock);
    1532:	10ca2503          	lw	a0,268(s4)
    1536:	134010ef          	jal	ra,266a <mutex_lock>
		buffer[buffer_len++] = c;
    153a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    153e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1542:	0017861b          	addiw	a2,a5,1
    1546:	97d2                	add	a5,a5,s4
    1548:	00ca2023          	sw	a2,0(s4)
    154c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1550:	02c6d163          	bge	a3,a2,1572 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1554:	10000793          	li	a5,256
    1558:	02f61263          	bne	a2,a5,157c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    155c:	00001597          	auipc	a1,0x1
    1560:	2a458593          	addi	a1,a1,676 # 2800 <buffer>
    1564:	4505                	li	a0,1
    1566:	68d000ef          	jal	ra,23f2 <write>
	buffer_len = 0;
    156a:	00001797          	auipc	a5,0x1
    156e:	2807a723          	sw	zero,654(a5) # 27f8 <buffer_len>
		mutex_unlock(buffer_lock);
    1572:	10ca2503          	lw	a0,268(s4)
    1576:	100010ef          	jal	ra,2676 <mutex_unlock>
    157a:	bdd9                	j	1450 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    157c:	681000ef          	jal	ra,23fc <getpid>
    1580:	842a                	mv	s0,a0
    1582:	00001517          	auipc	a0,0x1
    1586:	17e50513          	addi	a0,a0,382 # 2700 <enable_deadlock_detect+0x36>
    158a:	549000ef          	jal	ra,22d2 <basename>
    158e:	872a                	mv	a4,a0
    1590:	00001617          	auipc	a2,0x1
    1594:	1b060613          	addi	a2,a2,432 # 2740 <enable_deadlock_detect+0x76>
    1598:	05400793          	li	a5,84
    159c:	86a2                	mv	a3,s0
    159e:	45fd                	li	a1,31
    15a0:	00001517          	auipc	a0,0x1
    15a4:	1a850513          	addi	a0,a0,424 # 2748 <enable_deadlock_detect+0x7e>
    15a8:	c23ff0ef          	jal	ra,11ca <printf>
    15ac:	557d                	li	a0,-1
    15ae:	67f000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    15b2:	000a2603          	lw	a2,0(s4)
    15b6:	de55                	beqz	a2,1572 <printf+0x3a8>
    15b8:	b755                	j	155c <printf+0x392>
		mutex_lock(buffer_lock);
    15ba:	10ca2503          	lw	a0,268(s4)
    15be:	e42e                	sd	a1,8(sp)
		s += 2;
    15c0:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15c4:	0a6010ef          	jal	ra,266a <mutex_lock>
		len = out_unlocked(s, l);
    15c8:	65a2                	ld	a1,8(sp)
    15ca:	8522                	mv	a0,s0
    15cc:	08a000ef          	jal	ra,1656 <out_unlocked>
		mutex_unlock(buffer_lock);
    15d0:	10ca2503          	lw	a0,268(s4)
    15d4:	0a2010ef          	jal	ra,2676 <mutex_unlock>
		s += 2;
    15d8:	bb55                	j	138c <printf+0x1c2>
				a = "(null)";
    15da:	00001417          	auipc	s0,0x1
    15de:	11e40413          	addi	s0,s0,286 # 26f8 <enable_deadlock_detect+0x2e>
    15e2:	bd2d                	j	141c <printf+0x252>

00000000000015e4 <enable_thread_io_buffer>:
{
    15e4:	1101                	addi	sp,sp,-32
    15e6:	e822                	sd	s0,16(sp)
    15e8:	ec06                	sd	ra,24(sp)
    15ea:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15ec:	00001417          	auipc	s0,0x1
    15f0:	20c40413          	addi	s0,s0,524 # 27f8 <buffer_len>
    15f4:	05a010ef          	jal	ra,264e <mutex_create>
    15f8:	10a42623          	sw	a0,268(s0)
    15fc:	00054a63          	bltz	a0,1610 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1600:	4785                	li	a5,1
}
    1602:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1604:	10f42423          	sw	a5,264(s0)
}
    1608:	6442                	ld	s0,16(sp)
    160a:	64a2                	ld	s1,8(sp)
    160c:	6105                	addi	sp,sp,32
    160e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1610:	5ed000ef          	jal	ra,23fc <getpid>
    1614:	84aa                	mv	s1,a0
    1616:	00001517          	auipc	a0,0x1
    161a:	0ea50513          	addi	a0,a0,234 # 2700 <enable_deadlock_detect+0x36>
    161e:	4b5000ef          	jal	ra,22d2 <basename>
    1622:	872a                	mv	a4,a0
    1624:	04800793          	li	a5,72
    1628:	86a6                	mv	a3,s1
    162a:	00001517          	auipc	a0,0x1
    162e:	15e50513          	addi	a0,a0,350 # 2788 <enable_deadlock_detect+0xbe>
    1632:	00001617          	auipc	a2,0x1
    1636:	10e60613          	addi	a2,a2,270 # 2740 <enable_deadlock_detect+0x76>
    163a:	45fd                	li	a1,31
    163c:	b8fff0ef          	jal	ra,11ca <printf>
    1640:	557d                	li	a0,-1
    1642:	5eb000ef          	jal	ra,242c <exit>
	buffer_lock_enabled = 1;
    1646:	4785                	li	a5,1
}
    1648:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    164a:	10f42423          	sw	a5,264(s0)
}
    164e:	6442                	ld	s0,16(sp)
    1650:	64a2                	ld	s1,8(sp)
    1652:	6105                	addi	sp,sp,32
    1654:	8082                	ret

0000000000001656 <out_unlocked>:
{
    1656:	7159                	addi	sp,sp,-112
    1658:	f486                	sd	ra,104(sp)
    165a:	f0a2                	sd	s0,96(sp)
    165c:	eca6                	sd	s1,88(sp)
    165e:	e8ca                	sd	s2,80(sp)
    1660:	e4ce                	sd	s3,72(sp)
    1662:	e0d2                	sd	s4,64(sp)
    1664:	fc56                	sd	s5,56(sp)
    1666:	f85a                	sd	s6,48(sp)
    1668:	f45e                	sd	s7,40(sp)
    166a:	f062                	sd	s8,32(sp)
    166c:	ec66                	sd	s9,24(sp)
    166e:	e86a                	sd	s10,16(sp)
    1670:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1672:	0e058663          	beqz	a1,175e <out_unlocked+0x108>
    1676:	842a                	mv	s0,a0
    1678:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    167c:	4981                	li	s3,0
    167e:	00001d17          	auipc	s10,0x1
    1682:	17ad0d13          	addi	s10,s10,378 # 27f8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1686:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    168a:	00001b17          	auipc	s6,0x1
    168e:	176b0b13          	addi	s6,s6,374 # 2800 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1692:	10000a93          	li	s5,256
    1696:	00001c97          	auipc	s9,0x1
    169a:	06ac8c93          	addi	s9,s9,106 # 2700 <enable_deadlock_detect+0x36>
    169e:	00001c17          	auipc	s8,0x1
    16a2:	0a2c0c13          	addi	s8,s8,162 # 2740 <enable_deadlock_detect+0x76>
    16a6:	00001b97          	auipc	s7,0x1
    16aa:	0a2b8b93          	addi	s7,s7,162 # 2748 <enable_deadlock_detect+0x7e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ae:	4a29                	li	s4,10
    16b0:	a031                	j	16bc <out_unlocked+0x66>
    16b2:	09468863          	beq	a3,s4,1742 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16b6:	0405                	addi	s0,s0,1
    16b8:	04848163          	beq	s1,s0,16fa <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16bc:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16c0:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16c4:	0017861b          	addiw	a2,a5,1
    16c8:	97ea                	add	a5,a5,s10
    16ca:	00cd2023          	sw	a2,0(s10)
    16ce:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16d2:	fec950e3          	bge	s2,a2,16b2 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16d6:	05561263          	bne	a2,s5,171a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16da:	85da                	mv	a1,s6
    16dc:	4505                	li	a0,1
    16de:	515000ef          	jal	ra,23f2 <write>
    16e2:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16e4:	00001797          	auipc	a5,0x1
    16e8:	1007aa23          	sw	zero,276(a5) # 27f8 <buffer_len>
			if (r < 0) {
    16ec:	06054763          	bltz	a0,175a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16f0:	0405                	addi	s0,s0,1
			ret += r;
    16f2:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16f6:	fc8493e3          	bne	s1,s0,16bc <out_unlocked+0x66>
}
    16fa:	70a6                	ld	ra,104(sp)
    16fc:	7406                	ld	s0,96(sp)
    16fe:	64e6                	ld	s1,88(sp)
    1700:	6946                	ld	s2,80(sp)
    1702:	6a06                	ld	s4,64(sp)
    1704:	7ae2                	ld	s5,56(sp)
    1706:	7b42                	ld	s6,48(sp)
    1708:	7ba2                	ld	s7,40(sp)
    170a:	7c02                	ld	s8,32(sp)
    170c:	6ce2                	ld	s9,24(sp)
    170e:	6d42                	ld	s10,16(sp)
    1710:	6da2                	ld	s11,8(sp)
    1712:	854e                	mv	a0,s3
    1714:	69a6                	ld	s3,72(sp)
    1716:	6165                	addi	sp,sp,112
    1718:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    171a:	4e3000ef          	jal	ra,23fc <getpid>
    171e:	8daa                	mv	s11,a0
    1720:	8566                	mv	a0,s9
    1722:	3b1000ef          	jal	ra,22d2 <basename>
    1726:	872a                	mv	a4,a0
    1728:	8662                	mv	a2,s8
    172a:	05400793          	li	a5,84
    172e:	86ee                	mv	a3,s11
    1730:	45fd                	li	a1,31
    1732:	855e                	mv	a0,s7
    1734:	a97ff0ef          	jal	ra,11ca <printf>
    1738:	557d                	li	a0,-1
    173a:	4f3000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    173e:	000d2603          	lw	a2,0(s10)
    1742:	da35                	beqz	a2,16b6 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1744:	85da                	mv	a1,s6
    1746:	4505                	li	a0,1
    1748:	4ab000ef          	jal	ra,23f2 <write>
    174c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    174e:	00001797          	auipc	a5,0x1
    1752:	0a07a523          	sw	zero,170(a5) # 27f8 <buffer_len>
			if (r < 0) {
    1756:	f8055de3          	bgez	a0,16f0 <out_unlocked+0x9a>
    175a:	89aa                	mv	s3,a0
    175c:	bf79                	j	16fa <out_unlocked+0xa4>
	int ret = 0;
    175e:	4981                	li	s3,0
    1760:	bf69                	j	16fa <out_unlocked+0xa4>

0000000000001762 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1762:	1101                	addi	sp,sp,-32
    1764:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1766:	00001497          	auipc	s1,0x1
    176a:	09248493          	addi	s1,s1,146 # 27f8 <buffer_len>
    176e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1770:	ec06                	sd	ra,24(sp)
    1772:	e822                	sd	s0,16(sp)
		char c = s[i];
    1774:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1778:	0017861b          	addiw	a2,a5,1
    177c:	97a6                	add	a5,a5,s1
    177e:	00e78423          	sb	a4,8(a5)
    1782:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1784:	0ff00793          	li	a5,255
    1788:	00c7cc63          	blt	a5,a2,17a0 <out_unlocked.constprop.0+0x3e>
    178c:	47a9                	li	a5,10
    178e:	06f70c63          	beq	a4,a5,1806 <out_unlocked.constprop.0+0xa4>
    1792:	4601                	li	a2,0
}
    1794:	60e2                	ld	ra,24(sp)
    1796:	6442                	ld	s0,16(sp)
    1798:	64a2                	ld	s1,8(sp)
    179a:	8532                	mv	a0,a2
    179c:	6105                	addi	sp,sp,32
    179e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17a0:	10000793          	li	a5,256
    17a4:	02f61563          	bne	a2,a5,17ce <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17a8:	00001597          	auipc	a1,0x1
    17ac:	05858593          	addi	a1,a1,88 # 2800 <buffer>
    17b0:	4505                	li	a0,1
    17b2:	441000ef          	jal	ra,23f2 <write>
}
    17b6:	60e2                	ld	ra,24(sp)
    17b8:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17ba:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17be:	00001797          	auipc	a5,0x1
    17c2:	0207ad23          	sw	zero,58(a5) # 27f8 <buffer_len>
}
    17c6:	64a2                	ld	s1,8(sp)
    17c8:	8532                	mv	a0,a2
    17ca:	6105                	addi	sp,sp,32
    17cc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17ce:	42f000ef          	jal	ra,23fc <getpid>
    17d2:	842a                	mv	s0,a0
    17d4:	00001517          	auipc	a0,0x1
    17d8:	f2c50513          	addi	a0,a0,-212 # 2700 <enable_deadlock_detect+0x36>
    17dc:	2f7000ef          	jal	ra,22d2 <basename>
    17e0:	872a                	mv	a4,a0
    17e2:	00001617          	auipc	a2,0x1
    17e6:	f5e60613          	addi	a2,a2,-162 # 2740 <enable_deadlock_detect+0x76>
    17ea:	05400793          	li	a5,84
    17ee:	86a2                	mv	a3,s0
    17f0:	45fd                	li	a1,31
    17f2:	00001517          	auipc	a0,0x1
    17f6:	f5650513          	addi	a0,a0,-170 # 2748 <enable_deadlock_detect+0x7e>
    17fa:	9d1ff0ef          	jal	ra,11ca <printf>
    17fe:	557d                	li	a0,-1
    1800:	42d000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    1804:	4090                	lw	a2,0(s1)
    1806:	d659                	beqz	a2,1794 <out_unlocked.constprop.0+0x32>
    1808:	b745                	j	17a8 <out_unlocked.constprop.0+0x46>

000000000000180a <putchar>:
{
    180a:	7139                	addi	sp,sp,-64
    180c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    180e:	00001497          	auipc	s1,0x1
    1812:	fea48493          	addi	s1,s1,-22 # 27f8 <buffer_len>
    1816:	1084a703          	lw	a4,264(s1)
{
    181a:	f822                	sd	s0,48(sp)
	char byte = c;
    181c:	0ff57413          	zext.b	s0,a0
{
    1820:	fc06                	sd	ra,56(sp)
	char byte = c;
    1822:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1826:	4785                	li	a5,1
    1828:	00f70d63          	beq	a4,a5,1842 <putchar+0x38>
		len = out_unlocked(s, l);
    182c:	01f10513          	addi	a0,sp,31
    1830:	f33ff0ef          	jal	ra,1762 <out_unlocked.constprop.0>
}
    1834:	70e2                	ld	ra,56(sp)
    1836:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1838:	862a                	mv	a2,a0
}
    183a:	74a2                	ld	s1,40(sp)
    183c:	8532                	mv	a0,a2
    183e:	6121                	addi	sp,sp,64
    1840:	8082                	ret
		mutex_lock(buffer_lock);
    1842:	10c4a503          	lw	a0,268(s1)
    1846:	625000ef          	jal	ra,266a <mutex_lock>
		buffer[buffer_len++] = c;
    184a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    184c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1850:	0017861b          	addiw	a2,a5,1
    1854:	97a6                	add	a5,a5,s1
    1856:	c090                	sw	a2,0(s1)
    1858:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    185c:	02c6c263          	blt	a3,a2,1880 <putchar+0x76>
    1860:	47a9                	li	a5,10
    1862:	06f40d63          	beq	s0,a5,18dc <putchar+0xd2>
    1866:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1868:	10c4a503          	lw	a0,268(s1)
    186c:	e432                	sd	a2,8(sp)
    186e:	609000ef          	jal	ra,2676 <mutex_unlock>
    1872:	6622                	ld	a2,8(sp)
}
    1874:	70e2                	ld	ra,56(sp)
    1876:	7442                	ld	s0,48(sp)
    1878:	74a2                	ld	s1,40(sp)
    187a:	8532                	mv	a0,a2
    187c:	6121                	addi	sp,sp,64
    187e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1880:	10000793          	li	a5,256
    1884:	02f61063          	bne	a2,a5,18a4 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1888:	00001597          	auipc	a1,0x1
    188c:	f7858593          	addi	a1,a1,-136 # 2800 <buffer>
    1890:	4505                	li	a0,1
    1892:	361000ef          	jal	ra,23f2 <write>
    1896:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    189a:	00001797          	auipc	a5,0x1
    189e:	f407af23          	sw	zero,-162(a5) # 27f8 <buffer_len>
			if (r < 0) {
    18a2:	b7d9                	j	1868 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18a4:	359000ef          	jal	ra,23fc <getpid>
    18a8:	842a                	mv	s0,a0
    18aa:	00001517          	auipc	a0,0x1
    18ae:	e5650513          	addi	a0,a0,-426 # 2700 <enable_deadlock_detect+0x36>
    18b2:	221000ef          	jal	ra,22d2 <basename>
    18b6:	872a                	mv	a4,a0
    18b8:	00001617          	auipc	a2,0x1
    18bc:	e8860613          	addi	a2,a2,-376 # 2740 <enable_deadlock_detect+0x76>
    18c0:	05400793          	li	a5,84
    18c4:	86a2                	mv	a3,s0
    18c6:	45fd                	li	a1,31
    18c8:	00001517          	auipc	a0,0x1
    18cc:	e8050513          	addi	a0,a0,-384 # 2748 <enable_deadlock_detect+0x7e>
    18d0:	8fbff0ef          	jal	ra,11ca <printf>
    18d4:	557d                	li	a0,-1
    18d6:	357000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    18da:	4090                	lw	a2,0(s1)
    18dc:	d651                	beqz	a2,1868 <putchar+0x5e>
    18de:	b76d                	j	1888 <putchar+0x7e>

00000000000018e0 <puts>:
{
    18e0:	7139                	addi	sp,sp,-64
    18e2:	f822                	sd	s0,48(sp)
    18e4:	f426                	sd	s1,40(sp)
    18e6:	fc06                	sd	ra,56(sp)
    18e8:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18ea:	00001417          	auipc	s0,0x1
    18ee:	f0e40413          	addi	s0,s0,-242 # 27f8 <buffer_len>
{
    18f2:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18f4:	638000ef          	jal	ra,1f2c <strlen>
	if (buffer_lock_enabled == 1) {
    18f8:	10842703          	lw	a4,264(s0)
    18fc:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18fe:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1900:	04f70563          	beq	a4,a5,194a <puts+0x6a>
		len = out_unlocked(s, l);
    1904:	8526                	mv	a0,s1
    1906:	d51ff0ef          	jal	ra,1656 <out_unlocked>
    190a:	892a                	mv	s2,a0
    190c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    190e:	00095963          	bgez	s2,1920 <puts+0x40>
}
    1912:	70e2                	ld	ra,56(sp)
    1914:	7442                	ld	s0,48(sp)
    1916:	7902                	ld	s2,32(sp)
    1918:	8526                	mv	a0,s1
    191a:	74a2                	ld	s1,40(sp)
    191c:	6121                	addi	sp,sp,64
    191e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1920:	10842703          	lw	a4,264(s0)
	char byte = c;
    1924:	44a9                	li	s1,10
    1926:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    192a:	4785                	li	a5,1
    192c:	02f70e63          	beq	a4,a5,1968 <puts+0x88>
		len = out_unlocked(s, l);
    1930:	01f10513          	addi	a0,sp,31
    1934:	e2fff0ef          	jal	ra,1762 <out_unlocked.constprop.0>
}
    1938:	70e2                	ld	ra,56(sp)
    193a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    193c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1940:	7902                	ld	s2,32(sp)
    1942:	8526                	mv	a0,s1
    1944:	74a2                	ld	s1,40(sp)
    1946:	6121                	addi	sp,sp,64
    1948:	8082                	ret
		mutex_lock(buffer_lock);
    194a:	e42a                	sd	a0,8(sp)
    194c:	10c42503          	lw	a0,268(s0)
    1950:	51b000ef          	jal	ra,266a <mutex_lock>
		len = out_unlocked(s, l);
    1954:	65a2                	ld	a1,8(sp)
    1956:	8526                	mv	a0,s1
    1958:	cffff0ef          	jal	ra,1656 <out_unlocked>
    195c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    195e:	10c42503          	lw	a0,268(s0)
    1962:	515000ef          	jal	ra,2676 <mutex_unlock>
    1966:	b75d                	j	190c <puts+0x2c>
		mutex_lock(buffer_lock);
    1968:	10c42503          	lw	a0,268(s0)
    196c:	4ff000ef          	jal	ra,266a <mutex_lock>
		buffer[buffer_len++] = c;
    1970:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1972:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1976:	0017861b          	addiw	a2,a5,1
    197a:	97a2                	add	a5,a5,s0
    197c:	c010                	sw	a2,0(s0)
    197e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1982:	06c6dc63          	bge	a3,a2,19fa <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1986:	10000793          	li	a5,256
    198a:	02f61c63          	bne	a2,a5,19c2 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    198e:	00001597          	auipc	a1,0x1
    1992:	e7258593          	addi	a1,a1,-398 # 2800 <buffer>
    1996:	4505                	li	a0,1
    1998:	25b000ef          	jal	ra,23f2 <write>
			if (r < 0) {
    199c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    199e:	00001797          	auipc	a5,0x1
    19a2:	e407ad23          	sw	zero,-422(a5) # 27f8 <buffer_len>
			if (r < 0) {
    19a6:	04054c63          	bltz	a0,19fe <puts+0x11e>
			if (r < buffer_len) {
    19aa:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19ac:	10c42503          	lw	a0,268(s0)
    19b0:	4c7000ef          	jal	ra,2676 <mutex_unlock>
}
    19b4:	70e2                	ld	ra,56(sp)
    19b6:	7442                	ld	s0,48(sp)
    19b8:	7902                	ld	s2,32(sp)
    19ba:	8526                	mv	a0,s1
    19bc:	74a2                	ld	s1,40(sp)
    19be:	6121                	addi	sp,sp,64
    19c0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19c2:	23b000ef          	jal	ra,23fc <getpid>
    19c6:	84aa                	mv	s1,a0
    19c8:	00001517          	auipc	a0,0x1
    19cc:	d3850513          	addi	a0,a0,-712 # 2700 <enable_deadlock_detect+0x36>
    19d0:	103000ef          	jal	ra,22d2 <basename>
    19d4:	872a                	mv	a4,a0
    19d6:	00001617          	auipc	a2,0x1
    19da:	d6a60613          	addi	a2,a2,-662 # 2740 <enable_deadlock_detect+0x76>
    19de:	05400793          	li	a5,84
    19e2:	86a6                	mv	a3,s1
    19e4:	45fd                	li	a1,31
    19e6:	00001517          	auipc	a0,0x1
    19ea:	d6250513          	addi	a0,a0,-670 # 2748 <enable_deadlock_detect+0x7e>
    19ee:	fdcff0ef          	jal	ra,11ca <printf>
    19f2:	557d                	li	a0,-1
    19f4:	239000ef          	jal	ra,242c <exit>
	if (buffer_len == 0)
    19f8:	4010                	lw	a2,0(s0)
    19fa:	da45                	beqz	a2,19aa <puts+0xca>
    19fc:	bf49                	j	198e <puts+0xae>
    19fe:	54fd                	li	s1,-1
    1a00:	b775                	j	19ac <puts+0xcc>

0000000000001a02 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a02:	715d                	addi	sp,sp,-80
    1a04:	e486                	sd	ra,72(sp)
    1a06:	e0a2                	sd	s0,64(sp)
    1a08:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a0a:	14054363          	bltz	a0,1b50 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a0e:	02b577bb          	remuw	a5,a0,a1
    1a12:	00001617          	auipc	a2,0x1
    1a16:	f0660613          	addi	a2,a2,-250 # 2918 <digits>
	buf[16] = 0;
    1a1a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a1e:	0005871b          	sext.w	a4,a1
    1a22:	1782                	slli	a5,a5,0x20
    1a24:	9381                	srli	a5,a5,0x20
    1a26:	97b2                	add	a5,a5,a2
    1a28:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a2c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a30:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a34:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a36:	0eb56763          	bltu	a0,a1,1b24 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a3a:	02e877bb          	remuw	a5,a6,a4
    1a3e:	1782                	slli	a5,a5,0x20
    1a40:	9381                	srli	a5,a5,0x20
    1a42:	97b2                	add	a5,a5,a2
    1a44:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a48:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a4c:	02f10323          	sb	a5,38(sp)
    1a50:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a52:	0ce86963          	bltu	a6,a4,1b24 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a56:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a5a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a5e:	1582                	slli	a1,a1,0x20
    1a60:	9181                	srli	a1,a1,0x20
    1a62:	95b2                	add	a1,a1,a2
    1a64:	0005c583          	lbu	a1,0(a1)
    1a68:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a6c:	0007859b          	sext.w	a1,a5
    1a70:	16e6e563          	bltu	a3,a4,1bda <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a74:	02e7f6bb          	remuw	a3,a5,a4
    1a78:	1682                	slli	a3,a3,0x20
    1a7a:	9281                	srli	a3,a3,0x20
    1a7c:	96b2                	add	a3,a3,a2
    1a7e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a82:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a86:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a8a:	16e5e163          	bltu	a1,a4,1bec <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a8e:	02e876bb          	remuw	a3,a6,a4
    1a92:	1682                	slli	a3,a3,0x20
    1a94:	9281                	srli	a3,a3,0x20
    1a96:	96b2                	add	a3,a3,a2
    1a98:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a9c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1aa0:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1aa4:	14e86d63          	bltu	a6,a4,1bfe <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1aa8:	02e5f6bb          	remuw	a3,a1,a4
    1aac:	1682                	slli	a3,a3,0x20
    1aae:	9281                	srli	a3,a3,0x20
    1ab0:	96b2                	add	a3,a3,a2
    1ab2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab6:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1aba:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1abe:	10e5e563          	bltu	a1,a4,1bc8 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ac2:	02e876bb          	remuw	a3,a6,a4
    1ac6:	1682                	slli	a3,a3,0x20
    1ac8:	9281                	srli	a3,a3,0x20
    1aca:	96b2                	add	a3,a3,a2
    1acc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ad0:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ad4:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ad8:	14e86263          	bltu	a6,a4,1c1c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1adc:	02e5f6bb          	remuw	a3,a1,a4
    1ae0:	1682                	slli	a3,a3,0x20
    1ae2:	9281                	srli	a3,a3,0x20
    1ae4:	96b2                	add	a3,a3,a2
    1ae6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aea:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1aee:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1af2:	14e5e463          	bltu	a1,a4,1c3a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1af6:	02e876bb          	remuw	a3,a6,a4
    1afa:	1682                	slli	a3,a3,0x20
    1afc:	9281                	srli	a3,a3,0x20
    1afe:	96b2                	add	a3,a3,a2
    1b00:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b04:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b08:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b0c:	14e86063          	bltu	a6,a4,1c4c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b10:	1782                	slli	a5,a5,0x20
    1b12:	9381                	srli	a5,a5,0x20
    1b14:	97b2                	add	a5,a5,a2
    1b16:	0007c703          	lbu	a4,0(a5)
    1b1a:	4799                	li	a5,6
    1b1c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b20:	10054763          	bltz	a0,1c2e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b24:	00001497          	auipc	s1,0x1
    1b28:	cd448493          	addi	s1,s1,-812 # 27f8 <buffer_len>
    1b2c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b30:	0828                	addi	a0,sp,24
    1b32:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b34:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b36:	00f50433          	add	s0,a0,a5
    1b3a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b3c:	06e68463          	beq	a3,a4,1ba4 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b40:	8522                	mv	a0,s0
    1b42:	b15ff0ef          	jal	ra,1656 <out_unlocked>
}
    1b46:	60a6                	ld	ra,72(sp)
    1b48:	6406                	ld	s0,64(sp)
    1b4a:	74e2                	ld	s1,56(sp)
    1b4c:	6161                	addi	sp,sp,80
    1b4e:	8082                	ret
		x = -xx;
    1b50:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b54:	02b877bb          	remuw	a5,a6,a1
    1b58:	00001617          	auipc	a2,0x1
    1b5c:	dc060613          	addi	a2,a2,-576 # 2918 <digits>
	buf[16] = 0;
    1b60:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b64:	0005871b          	sext.w	a4,a1
    1b68:	1782                	slli	a5,a5,0x20
    1b6a:	9381                	srli	a5,a5,0x20
    1b6c:	97b2                	add	a5,a5,a2
    1b6e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b72:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b76:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b7a:	08b86b63          	bltu	a6,a1,1c10 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b7e:	02e8f7bb          	remuw	a5,a7,a4
    1b82:	1782                	slli	a5,a5,0x20
    1b84:	9381                	srli	a5,a5,0x20
    1b86:	97b2                	add	a5,a5,a2
    1b88:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b8c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b90:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b94:	ece8f1e3          	bgeu	a7,a4,1a56 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b98:	02d00793          	li	a5,45
    1b9c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1ba0:	47b5                	li	a5,13
    1ba2:	b749                	j	1b24 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1ba4:	10c4a503          	lw	a0,268(s1)
    1ba8:	e42e                	sd	a1,8(sp)
    1baa:	2c1000ef          	jal	ra,266a <mutex_lock>
		len = out_unlocked(s, l);
    1bae:	65a2                	ld	a1,8(sp)
    1bb0:	8522                	mv	a0,s0
    1bb2:	aa5ff0ef          	jal	ra,1656 <out_unlocked>
		mutex_unlock(buffer_lock);
    1bb6:	10c4a503          	lw	a0,268(s1)
    1bba:	2bd000ef          	jal	ra,2676 <mutex_unlock>
}
    1bbe:	60a6                	ld	ra,72(sp)
    1bc0:	6406                	ld	s0,64(sp)
    1bc2:	74e2                	ld	s1,56(sp)
    1bc4:	6161                	addi	sp,sp,80
    1bc6:	8082                	ret
		buf[i--] = digits[x % base];
    1bc8:	47a9                	li	a5,10
	if (sign)
    1bca:	f4055de3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bce:	02d00793          	li	a5,45
    1bd2:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bd6:	47a5                	li	a5,9
    1bd8:	b7b1                	j	1b24 <printint.constprop.0+0x122>
    1bda:	47b5                	li	a5,13
	if (sign)
    1bdc:	f40554e3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be0:	02d00793          	li	a5,45
    1be4:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1be8:	47b1                	li	a5,12
    1bea:	bf2d                	j	1b24 <printint.constprop.0+0x122>
    1bec:	47b1                	li	a5,12
	if (sign)
    1bee:	f2055be3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf2:	02d00793          	li	a5,45
    1bf6:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bfa:	47ad                	li	a5,11
    1bfc:	b725                	j	1b24 <printint.constprop.0+0x122>
    1bfe:	47ad                	li	a5,11
	if (sign)
    1c00:	f20552e3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c04:	02d00793          	li	a5,45
    1c08:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c0c:	47a9                	li	a5,10
    1c0e:	bf19                	j	1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c10:	02d00793          	li	a5,45
    1c14:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c18:	47b9                	li	a5,14
    1c1a:	b729                	j	1b24 <printint.constprop.0+0x122>
    1c1c:	47a5                	li	a5,9
	if (sign)
    1c1e:	f00553e3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c22:	02d00793          	li	a5,45
    1c26:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c2a:	47a1                	li	a5,8
    1c2c:	bde5                	j	1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c2e:	02d00793          	li	a5,45
    1c32:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c36:	4795                	li	a5,5
    1c38:	b5f5                	j	1b24 <printint.constprop.0+0x122>
    1c3a:	47a1                	li	a5,8
	if (sign)
    1c3c:	ee0554e3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c40:	02d00793          	li	a5,45
    1c44:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c48:	479d                	li	a5,7
    1c4a:	bde9                	j	1b24 <printint.constprop.0+0x122>
    1c4c:	479d                	li	a5,7
	if (sign)
    1c4e:	ec055be3          	bgez	a0,1b24 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c52:	02d00793          	li	a5,45
    1c56:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c5a:	4799                	li	a5,6
    1c5c:	b5e1                	j	1b24 <printint.constprop.0+0x122>

0000000000001c5e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c5e:	02000793          	li	a5,32
    1c62:	00f50663          	beq	a0,a5,1c6e <isspace+0x10>
    1c66:	355d                	addiw	a0,a0,-9
    1c68:	00553513          	sltiu	a0,a0,5
    1c6c:	8082                	ret
    1c6e:	4505                	li	a0,1
}
    1c70:	8082                	ret

0000000000001c72 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c72:	fd05051b          	addiw	a0,a0,-48
}
    1c76:	00a53513          	sltiu	a0,a0,10
    1c7a:	8082                	ret

0000000000001c7c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c7c:	02000613          	li	a2,32
    1c80:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c82:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c86:	ff77869b          	addiw	a3,a5,-9
    1c8a:	04c78c63          	beq	a5,a2,1ce2 <atoi+0x66>
    1c8e:	0007871b          	sext.w	a4,a5
    1c92:	04d5f863          	bgeu	a1,a3,1ce2 <atoi+0x66>
		s++;
	switch (*s) {
    1c96:	02b00693          	li	a3,43
    1c9a:	04d78963          	beq	a5,a3,1cec <atoi+0x70>
    1c9e:	02d00693          	li	a3,45
    1ca2:	06d78263          	beq	a5,a3,1d06 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1ca6:	fd07061b          	addiw	a2,a4,-48
    1caa:	47a5                	li	a5,9
    1cac:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cae:	4e01                	li	t3,0
	while (isdigit(*s))
    1cb0:	04c7e963          	bltu	a5,a2,1d02 <atoi+0x86>
	int n = 0, neg = 0;
    1cb4:	4501                	li	a0,0
	while (isdigit(*s))
    1cb6:	4825                	li	a6,9
    1cb8:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cbc:	0025179b          	slliw	a5,a0,0x2
    1cc0:	9fa9                	addw	a5,a5,a0
    1cc2:	fd07031b          	addiw	t1,a4,-48
    1cc6:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1cca:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1cce:	0685                	addi	a3,a3,1
    1cd0:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cd4:	0006071b          	sext.w	a4,a2
    1cd8:	feb870e3          	bgeu	a6,a1,1cb8 <atoi+0x3c>
	return neg ? n : -n;
    1cdc:	000e0563          	beqz	t3,1ce6 <atoi+0x6a>
}
    1ce0:	8082                	ret
		s++;
    1ce2:	0505                	addi	a0,a0,1
    1ce4:	bf79                	j	1c82 <atoi+0x6>
	return neg ? n : -n;
    1ce6:	4113053b          	subw	a0,t1,a7
    1cea:	8082                	ret
	while (isdigit(*s))
    1cec:	00154703          	lbu	a4,1(a0)
    1cf0:	47a5                	li	a5,9
		s++;
    1cf2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cf6:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cfa:	4e01                	li	t3,0
	while (isdigit(*s))
    1cfc:	2701                	sext.w	a4,a4
    1cfe:	fac7fbe3          	bgeu	a5,a2,1cb4 <atoi+0x38>
    1d02:	4501                	li	a0,0
}
    1d04:	8082                	ret
	while (isdigit(*s))
    1d06:	00154703          	lbu	a4,1(a0)
    1d0a:	47a5                	li	a5,9
		s++;
    1d0c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d10:	fd07061b          	addiw	a2,a4,-48
    1d14:	2701                	sext.w	a4,a4
    1d16:	fec7e6e3          	bltu	a5,a2,1d02 <atoi+0x86>
		neg = 1;
    1d1a:	4e05                	li	t3,1
    1d1c:	bf61                	j	1cb4 <atoi+0x38>

0000000000001d1e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d1e:	16060d63          	beqz	a2,1e98 <memset+0x17a>
    1d22:	40a007b3          	neg	a5,a0
    1d26:	8b9d                	andi	a5,a5,7
    1d28:	00778693          	addi	a3,a5,7
    1d2c:	482d                	li	a6,11
    1d2e:	0ff5f713          	zext.b	a4,a1
    1d32:	fff60593          	addi	a1,a2,-1
    1d36:	1706e263          	bltu	a3,a6,1e9a <memset+0x17c>
    1d3a:	16d5ea63          	bltu	a1,a3,1eae <memset+0x190>
    1d3e:	16078563          	beqz	a5,1ea8 <memset+0x18a>
    1d42:	00e50023          	sb	a4,0(a0)
    1d46:	4685                	li	a3,1
    1d48:	00150593          	addi	a1,a0,1
    1d4c:	14d78c63          	beq	a5,a3,1ea4 <memset+0x186>
    1d50:	00e500a3          	sb	a4,1(a0)
    1d54:	4689                	li	a3,2
    1d56:	00250593          	addi	a1,a0,2
    1d5a:	14d78d63          	beq	a5,a3,1eb4 <memset+0x196>
    1d5e:	00e50123          	sb	a4,2(a0)
    1d62:	468d                	li	a3,3
    1d64:	00350593          	addi	a1,a0,3
    1d68:	12d78b63          	beq	a5,a3,1e9e <memset+0x180>
    1d6c:	00e501a3          	sb	a4,3(a0)
    1d70:	4691                	li	a3,4
    1d72:	00450593          	addi	a1,a0,4
    1d76:	14d78163          	beq	a5,a3,1eb8 <memset+0x19a>
    1d7a:	00e50223          	sb	a4,4(a0)
    1d7e:	4695                	li	a3,5
    1d80:	00550593          	addi	a1,a0,5
    1d84:	12d78c63          	beq	a5,a3,1ebc <memset+0x19e>
    1d88:	00e502a3          	sb	a4,5(a0)
    1d8c:	469d                	li	a3,7
    1d8e:	00650593          	addi	a1,a0,6
    1d92:	12d79763          	bne	a5,a3,1ec0 <memset+0x1a2>
    1d96:	00750593          	addi	a1,a0,7
    1d9a:	00e50323          	sb	a4,6(a0)
    1d9e:	481d                	li	a6,7
    1da0:	00871693          	slli	a3,a4,0x8
    1da4:	01071893          	slli	a7,a4,0x10
    1da8:	8ed9                	or	a3,a3,a4
    1daa:	01871313          	slli	t1,a4,0x18
    1dae:	0116e6b3          	or	a3,a3,a7
    1db2:	0066e6b3          	or	a3,a3,t1
    1db6:	02071893          	slli	a7,a4,0x20
    1dba:	02871e13          	slli	t3,a4,0x28
    1dbe:	0116e6b3          	or	a3,a3,a7
    1dc2:	40f60333          	sub	t1,a2,a5
    1dc6:	03071893          	slli	a7,a4,0x30
    1dca:	01c6e6b3          	or	a3,a3,t3
    1dce:	0116e6b3          	or	a3,a3,a7
    1dd2:	03871e13          	slli	t3,a4,0x38
    1dd6:	97aa                	add	a5,a5,a0
    1dd8:	ff837893          	andi	a7,t1,-8
    1ddc:	01c6e6b3          	or	a3,a3,t3
    1de0:	98be                	add	a7,a7,a5
    1de2:	e394                	sd	a3,0(a5)
    1de4:	07a1                	addi	a5,a5,8
    1de6:	ff179ee3          	bne	a5,a7,1de2 <memset+0xc4>
    1dea:	ff837893          	andi	a7,t1,-8
    1dee:	011587b3          	add	a5,a1,a7
    1df2:	010886bb          	addw	a3,a7,a6
    1df6:	0b130663          	beq	t1,a7,1ea2 <memset+0x184>
    1dfa:	00e78023          	sb	a4,0(a5)
    1dfe:	0016859b          	addiw	a1,a3,1
    1e02:	08c5fb63          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e06:	00e780a3          	sb	a4,1(a5)
    1e0a:	0026859b          	addiw	a1,a3,2
    1e0e:	08c5f563          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e12:	00e78123          	sb	a4,2(a5)
    1e16:	0036859b          	addiw	a1,a3,3
    1e1a:	06c5ff63          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e1e:	00e781a3          	sb	a4,3(a5)
    1e22:	0046859b          	addiw	a1,a3,4
    1e26:	06c5f963          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e2a:	00e78223          	sb	a4,4(a5)
    1e2e:	0056859b          	addiw	a1,a3,5
    1e32:	06c5f363          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e36:	00e782a3          	sb	a4,5(a5)
    1e3a:	0066859b          	addiw	a1,a3,6
    1e3e:	04c5fd63          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e42:	00e78323          	sb	a4,6(a5)
    1e46:	0076859b          	addiw	a1,a3,7
    1e4a:	04c5f763          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e4e:	00e783a3          	sb	a4,7(a5)
    1e52:	0086859b          	addiw	a1,a3,8
    1e56:	04c5f163          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e5a:	00e78423          	sb	a4,8(a5)
    1e5e:	0096859b          	addiw	a1,a3,9
    1e62:	02c5fb63          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e66:	00e784a3          	sb	a4,9(a5)
    1e6a:	00a6859b          	addiw	a1,a3,10
    1e6e:	02c5f563          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e72:	00e78523          	sb	a4,10(a5)
    1e76:	00b6859b          	addiw	a1,a3,11
    1e7a:	00c5ff63          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e7e:	00e785a3          	sb	a4,11(a5)
    1e82:	00c6859b          	addiw	a1,a3,12
    1e86:	00c5f963          	bgeu	a1,a2,1e98 <memset+0x17a>
    1e8a:	00e78623          	sb	a4,12(a5)
    1e8e:	26b5                	addiw	a3,a3,13
    1e90:	00c6f463          	bgeu	a3,a2,1e98 <memset+0x17a>
    1e94:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e98:	8082                	ret
    1e9a:	46ad                	li	a3,11
    1e9c:	bd79                	j	1d3a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e9e:	480d                	li	a6,3
    1ea0:	b701                	j	1da0 <memset+0x82>
    1ea2:	8082                	ret
    1ea4:	4805                	li	a6,1
    1ea6:	bded                	j	1da0 <memset+0x82>
    1ea8:	85aa                	mv	a1,a0
    1eaa:	4801                	li	a6,0
    1eac:	bdd5                	j	1da0 <memset+0x82>
    1eae:	87aa                	mv	a5,a0
    1eb0:	4681                	li	a3,0
    1eb2:	b7a1                	j	1dfa <memset+0xdc>
    1eb4:	4809                	li	a6,2
    1eb6:	b5ed                	j	1da0 <memset+0x82>
    1eb8:	4811                	li	a6,4
    1eba:	b5dd                	j	1da0 <memset+0x82>
    1ebc:	4815                	li	a6,5
    1ebe:	b5cd                	j	1da0 <memset+0x82>
    1ec0:	4819                	li	a6,6
    1ec2:	bdf9                	j	1da0 <memset+0x82>

0000000000001ec4 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ec4:	00054783          	lbu	a5,0(a0)
    1ec8:	0005c703          	lbu	a4,0(a1)
    1ecc:	00e79863          	bne	a5,a4,1edc <strcmp+0x18>
    1ed0:	0505                	addi	a0,a0,1
    1ed2:	0585                	addi	a1,a1,1
    1ed4:	fbe5                	bnez	a5,1ec4 <strcmp>
    1ed6:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1ed8:	9d19                	subw	a0,a0,a4
    1eda:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1edc:	0007851b          	sext.w	a0,a5
    1ee0:	bfe5                	j	1ed8 <strcmp+0x14>

0000000000001ee2 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ee2:	ca15                	beqz	a2,1f16 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ee4:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ee8:	167d                	addi	a2,a2,-1
    1eea:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1eee:	eb99                	bnez	a5,1f04 <strncmp+0x22>
    1ef0:	a815                	j	1f24 <strncmp+0x42>
    1ef2:	00a68e63          	beq	a3,a0,1f0e <strncmp+0x2c>
    1ef6:	0505                	addi	a0,a0,1
    1ef8:	00f71b63          	bne	a4,a5,1f0e <strncmp+0x2c>
    1efc:	00054783          	lbu	a5,0(a0)
    1f00:	cf89                	beqz	a5,1f1a <strncmp+0x38>
    1f02:	85b2                	mv	a1,a2
    1f04:	0005c703          	lbu	a4,0(a1)
    1f08:	00158613          	addi	a2,a1,1
    1f0c:	f37d                	bnez	a4,1ef2 <strncmp+0x10>
		;
	return *l - *r;
    1f0e:	0007851b          	sext.w	a0,a5
    1f12:	9d19                	subw	a0,a0,a4
    1f14:	8082                	ret
		return 0;
    1f16:	4501                	li	a0,0
}
    1f18:	8082                	ret
	return *l - *r;
    1f1a:	0015c703          	lbu	a4,1(a1)
    1f1e:	4501                	li	a0,0
    1f20:	9d19                	subw	a0,a0,a4
    1f22:	8082                	ret
    1f24:	0005c703          	lbu	a4,0(a1)
    1f28:	4501                	li	a0,0
    1f2a:	b7e5                	j	1f12 <strncmp+0x30>

0000000000001f2c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f2c:	00757793          	andi	a5,a0,7
    1f30:	cf89                	beqz	a5,1f4a <strlen+0x1e>
    1f32:	87aa                	mv	a5,a0
    1f34:	a029                	j	1f3e <strlen+0x12>
    1f36:	0785                	addi	a5,a5,1
    1f38:	0077f713          	andi	a4,a5,7
    1f3c:	cb01                	beqz	a4,1f4c <strlen+0x20>
		if (!*s)
    1f3e:	0007c703          	lbu	a4,0(a5)
    1f42:	fb75                	bnez	a4,1f36 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f44:	40a78533          	sub	a0,a5,a0
}
    1f48:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f4a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f4c:	6394                	ld	a3,0(a5)
    1f4e:	00001597          	auipc	a1,0x1
    1f52:	8925b583          	ld	a1,-1902(a1) # 27e0 <enable_deadlock_detect+0x116>
    1f56:	00001617          	auipc	a2,0x1
    1f5a:	89263603          	ld	a2,-1902(a2) # 27e8 <enable_deadlock_detect+0x11e>
    1f5e:	a019                	j	1f64 <strlen+0x38>
    1f60:	6794                	ld	a3,8(a5)
    1f62:	07a1                	addi	a5,a5,8
    1f64:	00b68733          	add	a4,a3,a1
    1f68:	fff6c693          	not	a3,a3
    1f6c:	8f75                	and	a4,a4,a3
    1f6e:	8f71                	and	a4,a4,a2
    1f70:	db65                	beqz	a4,1f60 <strlen+0x34>
	for (; *s; s++)
    1f72:	0007c703          	lbu	a4,0(a5)
    1f76:	d779                	beqz	a4,1f44 <strlen+0x18>
    1f78:	0017c703          	lbu	a4,1(a5)
    1f7c:	0785                	addi	a5,a5,1
    1f7e:	d379                	beqz	a4,1f44 <strlen+0x18>
    1f80:	0017c703          	lbu	a4,1(a5)
    1f84:	0785                	addi	a5,a5,1
    1f86:	fb6d                	bnez	a4,1f78 <strlen+0x4c>
    1f88:	bf75                	j	1f44 <strlen+0x18>

0000000000001f8a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f8a:	00757713          	andi	a4,a0,7
{
    1f8e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f90:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f94:	cb19                	beqz	a4,1faa <memchr+0x20>
    1f96:	ce25                	beqz	a2,200e <memchr+0x84>
    1f98:	0007c703          	lbu	a4,0(a5)
    1f9c:	04b70e63          	beq	a4,a1,1ff8 <memchr+0x6e>
    1fa0:	0785                	addi	a5,a5,1
    1fa2:	0077f713          	andi	a4,a5,7
    1fa6:	167d                	addi	a2,a2,-1
    1fa8:	f77d                	bnez	a4,1f96 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1faa:	4501                	li	a0,0
	if (n && *s != c) {
    1fac:	c235                	beqz	a2,2010 <memchr+0x86>
    1fae:	0007c703          	lbu	a4,0(a5)
    1fb2:	04b70363          	beq	a4,a1,1ff8 <memchr+0x6e>
		size_t k = ONES * c;
    1fb6:	00001517          	auipc	a0,0x1
    1fba:	83a53503          	ld	a0,-1990(a0) # 27f0 <enable_deadlock_detect+0x126>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fbe:	471d                	li	a4,7
		size_t k = ONES * c;
    1fc0:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fc4:	02c77a63          	bgeu	a4,a2,1ff8 <memchr+0x6e>
    1fc8:	00001897          	auipc	a7,0x1
    1fcc:	8188b883          	ld	a7,-2024(a7) # 27e0 <enable_deadlock_detect+0x116>
    1fd0:	00001817          	auipc	a6,0x1
    1fd4:	81883803          	ld	a6,-2024(a6) # 27e8 <enable_deadlock_detect+0x11e>
    1fd8:	431d                	li	t1,7
    1fda:	a029                	j	1fe4 <memchr+0x5a>
		     w++, n -= SS)
    1fdc:	1661                	addi	a2,a2,-8
    1fde:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fe0:	02c37963          	bgeu	t1,a2,2012 <memchr+0x88>
    1fe4:	6398                	ld	a4,0(a5)
    1fe6:	8f29                	xor	a4,a4,a0
    1fe8:	011706b3          	add	a3,a4,a7
    1fec:	fff74713          	not	a4,a4
    1ff0:	8f75                	and	a4,a4,a3
    1ff2:	01077733          	and	a4,a4,a6
    1ff6:	d37d                	beqz	a4,1fdc <memchr+0x52>
{
    1ff8:	853e                	mv	a0,a5
    1ffa:	97b2                	add	a5,a5,a2
    1ffc:	a021                	j	2004 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1ffe:	0505                	addi	a0,a0,1
    2000:	00f50763          	beq	a0,a5,200e <memchr+0x84>
    2004:	00054703          	lbu	a4,0(a0)
    2008:	feb71be3          	bne	a4,a1,1ffe <memchr+0x74>
    200c:	8082                	ret
	return n ? (void *)s : 0;
    200e:	4501                	li	a0,0
}
    2010:	8082                	ret
	return n ? (void *)s : 0;
    2012:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2014:	f275                	bnez	a2,1ff8 <memchr+0x6e>
}
    2016:	8082                	ret

0000000000002018 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2018:	1101                	addi	sp,sp,-32
    201a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    201c:	862e                	mv	a2,a1
{
    201e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2020:	4581                	li	a1,0
{
    2022:	e426                	sd	s1,8(sp)
    2024:	ec06                	sd	ra,24(sp)
    2026:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2028:	f63ff0ef          	jal	ra,1f8a <memchr>
	return p ? p - s : n;
    202c:	c519                	beqz	a0,203a <strnlen+0x22>
}
    202e:	60e2                	ld	ra,24(sp)
    2030:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2032:	8d05                	sub	a0,a0,s1
}
    2034:	64a2                	ld	s1,8(sp)
    2036:	6105                	addi	sp,sp,32
    2038:	8082                	ret
    203a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    203c:	8522                	mv	a0,s0
}
    203e:	6442                	ld	s0,16(sp)
    2040:	64a2                	ld	s1,8(sp)
    2042:	6105                	addi	sp,sp,32
    2044:	8082                	ret

0000000000002046 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2046:	00a5c7b3          	xor	a5,a1,a0
    204a:	8b9d                	andi	a5,a5,7
    204c:	eb95                	bnez	a5,2080 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    204e:	0075f793          	andi	a5,a1,7
    2052:	e7b1                	bnez	a5,209e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2054:	6198                	ld	a4,0(a1)
    2056:	00000617          	auipc	a2,0x0
    205a:	78a63603          	ld	a2,1930(a2) # 27e0 <enable_deadlock_detect+0x116>
    205e:	00000817          	auipc	a6,0x0
    2062:	78a83803          	ld	a6,1930(a6) # 27e8 <enable_deadlock_detect+0x11e>
    2066:	a029                	j	2070 <stpcpy+0x2a>
    2068:	05a1                	addi	a1,a1,8
    206a:	e118                	sd	a4,0(a0)
    206c:	6198                	ld	a4,0(a1)
    206e:	0521                	addi	a0,a0,8
    2070:	00c707b3          	add	a5,a4,a2
    2074:	fff74693          	not	a3,a4
    2078:	8ff5                	and	a5,a5,a3
    207a:	0107f7b3          	and	a5,a5,a6
    207e:	d7ed                	beqz	a5,2068 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2080:	0005c783          	lbu	a5,0(a1)
    2084:	00f50023          	sb	a5,0(a0)
    2088:	c785                	beqz	a5,20b0 <stpcpy+0x6a>
    208a:	0015c783          	lbu	a5,1(a1)
    208e:	0505                	addi	a0,a0,1
    2090:	0585                	addi	a1,a1,1
    2092:	00f50023          	sb	a5,0(a0)
    2096:	fbf5                	bnez	a5,208a <stpcpy+0x44>
		;
	return d;
}
    2098:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    209a:	0505                	addi	a0,a0,1
    209c:	df45                	beqz	a4,2054 <stpcpy+0xe>
			if (!(*d = *s))
    209e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20a2:	0585                	addi	a1,a1,1
    20a4:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20a8:	00f50023          	sb	a5,0(a0)
    20ac:	f7fd                	bnez	a5,209a <stpcpy+0x54>
}
    20ae:	8082                	ret
    20b0:	8082                	ret

00000000000020b2 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20b2:	00a5c7b3          	xor	a5,a1,a0
    20b6:	8b9d                	andi	a5,a5,7
    20b8:	1a079863          	bnez	a5,2268 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20bc:	0075f793          	andi	a5,a1,7
    20c0:	16078463          	beqz	a5,2228 <stpncpy+0x176>
    20c4:	ea01                	bnez	a2,20d4 <stpncpy+0x22>
    20c6:	a421                	j	22ce <stpncpy+0x21c>
    20c8:	167d                	addi	a2,a2,-1
    20ca:	0505                	addi	a0,a0,1
    20cc:	14070e63          	beqz	a4,2228 <stpncpy+0x176>
    20d0:	1a060863          	beqz	a2,2280 <stpncpy+0x1ce>
    20d4:	0005c783          	lbu	a5,0(a1)
    20d8:	0585                	addi	a1,a1,1
    20da:	0075f713          	andi	a4,a1,7
    20de:	00f50023          	sb	a5,0(a0)
    20e2:	f3fd                	bnez	a5,20c8 <stpncpy+0x16>
    20e4:	4805                	li	a6,1
    20e6:	1a061863          	bnez	a2,2296 <stpncpy+0x1e4>
    20ea:	40a007b3          	neg	a5,a0
    20ee:	8b9d                	andi	a5,a5,7
    20f0:	4681                	li	a3,0
    20f2:	18061a63          	bnez	a2,2286 <stpncpy+0x1d4>
    20f6:	00778713          	addi	a4,a5,7
    20fa:	45ad                	li	a1,11
    20fc:	18b76363          	bltu	a4,a1,2282 <stpncpy+0x1d0>
    2100:	1ae6eb63          	bltu	a3,a4,22b6 <stpncpy+0x204>
    2104:	1a078363          	beqz	a5,22aa <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2108:	00050023          	sb	zero,0(a0)
    210c:	4685                	li	a3,1
    210e:	00150713          	addi	a4,a0,1
    2112:	18d78f63          	beq	a5,a3,22b0 <stpncpy+0x1fe>
    2116:	000500a3          	sb	zero,1(a0)
    211a:	4689                	li	a3,2
    211c:	00250713          	addi	a4,a0,2
    2120:	18d78e63          	beq	a5,a3,22bc <stpncpy+0x20a>
    2124:	00050123          	sb	zero,2(a0)
    2128:	468d                	li	a3,3
    212a:	00350713          	addi	a4,a0,3
    212e:	16d78c63          	beq	a5,a3,22a6 <stpncpy+0x1f4>
    2132:	000501a3          	sb	zero,3(a0)
    2136:	4691                	li	a3,4
    2138:	00450713          	addi	a4,a0,4
    213c:	18d78263          	beq	a5,a3,22c0 <stpncpy+0x20e>
    2140:	00050223          	sb	zero,4(a0)
    2144:	4695                	li	a3,5
    2146:	00550713          	addi	a4,a0,5
    214a:	16d78d63          	beq	a5,a3,22c4 <stpncpy+0x212>
    214e:	000502a3          	sb	zero,5(a0)
    2152:	469d                	li	a3,7
    2154:	00650713          	addi	a4,a0,6
    2158:	16d79863          	bne	a5,a3,22c8 <stpncpy+0x216>
    215c:	00750713          	addi	a4,a0,7
    2160:	00050323          	sb	zero,6(a0)
    2164:	40f80833          	sub	a6,a6,a5
    2168:	ff887593          	andi	a1,a6,-8
    216c:	97aa                	add	a5,a5,a0
    216e:	95be                	add	a1,a1,a5
    2170:	0007b023          	sd	zero,0(a5)
    2174:	07a1                	addi	a5,a5,8
    2176:	feb79de3          	bne	a5,a1,2170 <stpncpy+0xbe>
    217a:	ff887593          	andi	a1,a6,-8
    217e:	9ead                	addw	a3,a3,a1
    2180:	00b707b3          	add	a5,a4,a1
    2184:	12b80863          	beq	a6,a1,22b4 <stpncpy+0x202>
    2188:	00078023          	sb	zero,0(a5)
    218c:	0016871b          	addiw	a4,a3,1
    2190:	0ec77863          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    2194:	000780a3          	sb	zero,1(a5)
    2198:	0026871b          	addiw	a4,a3,2
    219c:	0ec77263          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21a0:	00078123          	sb	zero,2(a5)
    21a4:	0036871b          	addiw	a4,a3,3
    21a8:	0cc77c63          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21ac:	000781a3          	sb	zero,3(a5)
    21b0:	0046871b          	addiw	a4,a3,4
    21b4:	0cc77663          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21b8:	00078223          	sb	zero,4(a5)
    21bc:	0056871b          	addiw	a4,a3,5
    21c0:	0cc77063          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21c4:	000782a3          	sb	zero,5(a5)
    21c8:	0066871b          	addiw	a4,a3,6
    21cc:	0ac77a63          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21d0:	00078323          	sb	zero,6(a5)
    21d4:	0076871b          	addiw	a4,a3,7
    21d8:	0ac77463          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21dc:	000783a3          	sb	zero,7(a5)
    21e0:	0086871b          	addiw	a4,a3,8
    21e4:	08c77e63          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21e8:	00078423          	sb	zero,8(a5)
    21ec:	0096871b          	addiw	a4,a3,9
    21f0:	08c77863          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    21f4:	000784a3          	sb	zero,9(a5)
    21f8:	00a6871b          	addiw	a4,a3,10
    21fc:	08c77263          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    2200:	00078523          	sb	zero,10(a5)
    2204:	00b6871b          	addiw	a4,a3,11
    2208:	06c77c63          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    220c:	000785a3          	sb	zero,11(a5)
    2210:	00c6871b          	addiw	a4,a3,12
    2214:	06c77663          	bgeu	a4,a2,2280 <stpncpy+0x1ce>
    2218:	00078623          	sb	zero,12(a5)
    221c:	26b5                	addiw	a3,a3,13
    221e:	06c6f163          	bgeu	a3,a2,2280 <stpncpy+0x1ce>
    2222:	000786a3          	sb	zero,13(a5)
    2226:	8082                	ret
			;
		if (!n || !*s)
    2228:	c645                	beqz	a2,22d0 <stpncpy+0x21e>
    222a:	0005c783          	lbu	a5,0(a1)
    222e:	ea078be3          	beqz	a5,20e4 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2232:	479d                	li	a5,7
    2234:	02c7ff63          	bgeu	a5,a2,2272 <stpncpy+0x1c0>
    2238:	00000897          	auipc	a7,0x0
    223c:	5a88b883          	ld	a7,1448(a7) # 27e0 <enable_deadlock_detect+0x116>
    2240:	00000817          	auipc	a6,0x0
    2244:	5a883803          	ld	a6,1448(a6) # 27e8 <enable_deadlock_detect+0x11e>
    2248:	431d                	li	t1,7
    224a:	6198                	ld	a4,0(a1)
    224c:	011707b3          	add	a5,a4,a7
    2250:	fff74693          	not	a3,a4
    2254:	8ff5                	and	a5,a5,a3
    2256:	0107f7b3          	and	a5,a5,a6
    225a:	ef81                	bnez	a5,2272 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    225c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    225e:	1661                	addi	a2,a2,-8
    2260:	05a1                	addi	a1,a1,8
    2262:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2264:	fec363e3          	bltu	t1,a2,224a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2268:	e609                	bnez	a2,2272 <stpncpy+0x1c0>
    226a:	a08d                	j	22cc <stpncpy+0x21a>
    226c:	167d                	addi	a2,a2,-1
    226e:	0505                	addi	a0,a0,1
    2270:	ca01                	beqz	a2,2280 <stpncpy+0x1ce>
    2272:	0005c783          	lbu	a5,0(a1)
    2276:	0585                	addi	a1,a1,1
    2278:	00f50023          	sb	a5,0(a0)
    227c:	fbe5                	bnez	a5,226c <stpncpy+0x1ba>
		;
tail:
    227e:	b59d                	j	20e4 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2280:	8082                	ret
    2282:	472d                	li	a4,11
    2284:	bdb5                	j	2100 <stpncpy+0x4e>
    2286:	00778713          	addi	a4,a5,7
    228a:	45ad                	li	a1,11
    228c:	fff60693          	addi	a3,a2,-1
    2290:	e6b778e3          	bgeu	a4,a1,2100 <stpncpy+0x4e>
    2294:	b7fd                	j	2282 <stpncpy+0x1d0>
    2296:	40a007b3          	neg	a5,a0
    229a:	8832                	mv	a6,a2
    229c:	8b9d                	andi	a5,a5,7
    229e:	4681                	li	a3,0
    22a0:	e4060be3          	beqz	a2,20f6 <stpncpy+0x44>
    22a4:	b7cd                	j	2286 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22a6:	468d                	li	a3,3
    22a8:	bd75                	j	2164 <stpncpy+0xb2>
    22aa:	872a                	mv	a4,a0
    22ac:	4681                	li	a3,0
    22ae:	bd5d                	j	2164 <stpncpy+0xb2>
    22b0:	4685                	li	a3,1
    22b2:	bd4d                	j	2164 <stpncpy+0xb2>
    22b4:	8082                	ret
    22b6:	87aa                	mv	a5,a0
    22b8:	4681                	li	a3,0
    22ba:	b5f9                	j	2188 <stpncpy+0xd6>
    22bc:	4689                	li	a3,2
    22be:	b55d                	j	2164 <stpncpy+0xb2>
    22c0:	4691                	li	a3,4
    22c2:	b54d                	j	2164 <stpncpy+0xb2>
    22c4:	4695                	li	a3,5
    22c6:	bd79                	j	2164 <stpncpy+0xb2>
    22c8:	4699                	li	a3,6
    22ca:	bd69                	j	2164 <stpncpy+0xb2>
    22cc:	8082                	ret
    22ce:	8082                	ret
    22d0:	8082                	ret

00000000000022d2 <basename>:

char *basename(char *s)
{
    22d2:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22d4:	c54d                	beqz	a0,237e <basename+0xac>
    22d6:	00054783          	lbu	a5,0(a0)
		return ".";
    22da:	00000517          	auipc	a0,0x0
    22de:	4fe50513          	addi	a0,a0,1278 # 27d8 <enable_deadlock_detect+0x10e>
	if (!s || !*s)
    22e2:	e391                	bnez	a5,22e6 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22e4:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22e6:	0076f713          	andi	a4,a3,7
    22ea:	87b6                	mv	a5,a3
    22ec:	cf51                	beqz	a4,2388 <basename+0xb6>
    22ee:	0785                	addi	a5,a5,1
    22f0:	0077f713          	andi	a4,a5,7
    22f4:	c729                	beqz	a4,233e <basename+0x6c>
		if (!*s)
    22f6:	0007c703          	lbu	a4,0(a5)
    22fa:	fb75                	bnez	a4,22ee <basename+0x1c>
	return s - a;
    22fc:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22fe:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2300:	cf8d                	beqz	a5,233a <basename+0x68>
    2302:	00f68733          	add	a4,a3,a5
    2306:	02f00593          	li	a1,47
    230a:	a031                	j	2316 <basename+0x44>
		s[i] = 0;
    230c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2310:	17fd                	addi	a5,a5,-1
    2312:	177d                	addi	a4,a4,-1
    2314:	c39d                	beqz	a5,233a <basename+0x68>
    2316:	00074603          	lbu	a2,0(a4)
    231a:	feb609e3          	beq	a2,a1,230c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    231e:	02f00613          	li	a2,47
    2322:	a011                	j	2326 <basename+0x54>
    2324:	cb99                	beqz	a5,233a <basename+0x68>
    2326:	853e                	mv	a0,a5
    2328:	17fd                	addi	a5,a5,-1
    232a:	00f68733          	add	a4,a3,a5
    232e:	00074703          	lbu	a4,0(a4)
    2332:	fec719e3          	bne	a4,a2,2324 <basename+0x52>
	return s + i;
    2336:	9536                	add	a0,a0,a3
    2338:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    233a:	8536                	mv	a0,a3
    233c:	8082                	ret
    233e:	6390                	ld	a2,0(a5)
    2340:	00000517          	auipc	a0,0x0
    2344:	4a053503          	ld	a0,1184(a0) # 27e0 <enable_deadlock_detect+0x116>
    2348:	00000597          	auipc	a1,0x0
    234c:	4a05b583          	ld	a1,1184(a1) # 27e8 <enable_deadlock_detect+0x11e>
    2350:	fff64713          	not	a4,a2
    2354:	962a                	add	a2,a2,a0
    2356:	8f71                	and	a4,a4,a2
    2358:	8f6d                	and	a4,a4,a1
    235a:	eb11                	bnez	a4,236e <basename+0x9c>
    235c:	6790                	ld	a2,8(a5)
    235e:	07a1                	addi	a5,a5,8
    2360:	00a60733          	add	a4,a2,a0
    2364:	fff64613          	not	a2,a2
    2368:	8f71                	and	a4,a4,a2
    236a:	8f6d                	and	a4,a4,a1
    236c:	db65                	beqz	a4,235c <basename+0x8a>
	for (; *s; s++)
    236e:	0007c703          	lbu	a4,0(a5)
    2372:	d749                	beqz	a4,22fc <basename+0x2a>
    2374:	0017c703          	lbu	a4,1(a5)
    2378:	0785                	addi	a5,a5,1
    237a:	ff6d                	bnez	a4,2374 <basename+0xa2>
    237c:	b741                	j	22fc <basename+0x2a>
		return ".";
    237e:	00000517          	auipc	a0,0x0
    2382:	45a50513          	addi	a0,a0,1114 # 27d8 <enable_deadlock_detect+0x10e>
    2386:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2388:	6290                	ld	a2,0(a3)
    238a:	00000517          	auipc	a0,0x0
    238e:	45653503          	ld	a0,1110(a0) # 27e0 <enable_deadlock_detect+0x116>
    2392:	00000597          	auipc	a1,0x0
    2396:	4565b583          	ld	a1,1110(a1) # 27e8 <enable_deadlock_detect+0x11e>
    239a:	fff64713          	not	a4,a2
    239e:	962a                	add	a2,a2,a0
    23a0:	8f71                	and	a4,a4,a2
    23a2:	8f6d                	and	a4,a4,a1
    23a4:	df45                	beqz	a4,235c <basename+0x8a>
    23a6:	b7f9                	j	2374 <basename+0xa2>

00000000000023a8 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23a8:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23ac:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ae:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23b2:	2501                	sext.w	a0,a0
    23b4:	8082                	ret

00000000000023b6 <close>:

int close(int fd)
{
	if (fd == 1) {
    23b6:	4785                	li	a5,1
    23b8:	00f50863          	beq	a0,a5,23c8 <close+0x12>
	register long a7 __asm__("a7") = n;
    23bc:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23c0:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23c4:	2501                	sext.w	a0,a0
    23c6:	8082                	ret
{
    23c8:	1101                	addi	sp,sp,-32
    23ca:	ec06                	sd	ra,24(sp)
    23cc:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23ce:	cdffe0ef          	jal	ra,10ac <__write_buffer>
		__clear_buffer();
    23d2:	d03fe0ef          	jal	ra,10d4 <__clear_buffer>
    23d6:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23d8:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23dc:	00000073          	ecall
}
    23e0:	60e2                	ld	ra,24(sp)
    23e2:	2501                	sext.w	a0,a0
    23e4:	6105                	addi	sp,sp,32
    23e6:	8082                	ret

00000000000023e8 <read>:
	register long a7 __asm__("a7") = n;
    23e8:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23ec:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23f0:	8082                	ret

00000000000023f2 <write>:
	register long a7 __asm__("a7") = n;
    23f2:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23f6:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23fa:	8082                	ret

00000000000023fc <getpid>:
	register long a7 __asm__("a7") = n;
    23fc:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2400:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2404:	2501                	sext.w	a0,a0
    2406:	8082                	ret

0000000000002408 <getppid>:
	register long a7 __asm__("a7") = n;
    2408:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    240c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2410:	2501                	sext.w	a0,a0
    2412:	8082                	ret

0000000000002414 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2414:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2418:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    241c:	2501                	sext.w	a0,a0
    241e:	8082                	ret

0000000000002420 <fork>:
	register long a7 __asm__("a7") = n;
    2420:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2424:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2428:	2501                	sext.w	a0,a0
    242a:	8082                	ret

000000000000242c <exit>:

void exit(int code)
{
    242c:	1141                	addi	sp,sp,-16
    242e:	e406                	sd	ra,8(sp)
    2430:	e022                	sd	s0,0(sp)
    2432:	842a                	mv	s0,a0
	__write_buffer();
    2434:	c79fe0ef          	jal	ra,10ac <__write_buffer>
	__clear_buffer();
    2438:	c9dfe0ef          	jal	ra,10d4 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    243c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2440:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2442:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2446:	60a2                	ld	ra,8(sp)
    2448:	6402                	ld	s0,0(sp)
    244a:	0141                	addi	sp,sp,16
    244c:	8082                	ret

000000000000244e <waitpid>:
	register long a7 __asm__("a7") = n;
    244e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2452:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2456:	2501                	sext.w	a0,a0
    2458:	8082                	ret

000000000000245a <exec>:
	register long a7 __asm__("a7") = n;
    245a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    245e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2462:	2501                	sext.w	a0,a0
    2464:	8082                	ret

0000000000002466 <get_mtime>:

int64 get_mtime()
{
    2466:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2468:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    246c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    246e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2470:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2474:	2501                	sext.w	a0,a0
    2476:	ed01                	bnez	a0,248e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2478:	6722                	ld	a4,8(sp)
    247a:	3e800793          	li	a5,1000
    247e:	6682                	ld	a3,0(sp)
    2480:	02f75733          	divu	a4,a4,a5
    2484:	02d78533          	mul	a0,a5,a3
    2488:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    248a:	0141                	addi	sp,sp,16
    248c:	8082                	ret
	return -1;
    248e:	557d                	li	a0,-1
    2490:	bfed                	j	248a <get_mtime+0x24>

0000000000002492 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2492:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2496:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    249a:	2501                	sext.w	a0,a0
    249c:	8082                	ret

000000000000249e <sleep>:

int sleep(unsigned long long time)
{
    249e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24a0:	880a                	mv	a6,sp
{
    24a2:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24a4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24a8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24aa:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ac:	00000073          	ecall
	if (err == 0) {
    24b0:	2501                	sext.w	a0,a0
    24b2:	ed31                	bnez	a0,250e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24b4:	6722                	ld	a4,8(sp)
    24b6:	3e800793          	li	a5,1000
    24ba:	6682                	ld	a3,0(sp)
    24bc:	02f75733          	divu	a4,a4,a5
    24c0:	02d787b3          	mul	a5,a5,a3
    24c4:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24c6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24ca:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24cc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ce:	00000073          	ecall
	if (err == 0) {
    24d2:	2501                	sext.w	a0,a0
    24d4:	e915                	bnez	a0,2508 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24d6:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24d8:	3e800693          	li	a3,1000
    24dc:	a819                	j	24f2 <sleep+0x54>
	__asm_syscall("r"(a7))
    24de:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24e2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24e6:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24e8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ea:	00000073          	ecall
	if (err == 0) {
    24ee:	2501                	sext.w	a0,a0
    24f0:	ed01                	bnez	a0,2508 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24f2:	6722                	ld	a4,8(sp)
    24f4:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24f6:	07c00893          	li	a7,124
    24fa:	02d75733          	divu	a4,a4,a3
    24fe:	02f687b3          	mul	a5,a3,a5
    2502:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2504:	fcc7ede3          	bltu	a5,a2,24de <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2508:	4501                	li	a0,0
    250a:	0141                	addi	sp,sp,16
    250c:	8082                	ret
    250e:	57fd                	li	a5,-1
    2510:	bf5d                	j	24c6 <sleep+0x28>

0000000000002512 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2512:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2516:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    251a:	2501                	sext.w	a0,a0
    251c:	8082                	ret

000000000000251e <set_priority>:
	register long a7 __asm__("a7") = n;
    251e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2522:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2526:	2501                	sext.w	a0,a0
    2528:	8082                	ret

000000000000252a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    252a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    252e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2532:	2501                	sext.w	a0,a0
    2534:	8082                	ret

0000000000002536 <munmap>:
	register long a7 __asm__("a7") = n;
    2536:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    253a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    253e:	2501                	sext.w	a0,a0
    2540:	8082                	ret

0000000000002542 <wait>:

int wait(int *code)
{
    2542:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2544:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2548:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254a:	00000073          	ecall
	return waitpid(-1, code);
}
    254e:	2501                	sext.w	a0,a0
    2550:	8082                	ret

0000000000002552 <spawn>:
	register long a7 __asm__("a7") = n;
    2552:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2556:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    255a:	2501                	sext.w	a0,a0
    255c:	8082                	ret

000000000000255e <pipe>:
	register long a7 __asm__("a7") = n;
    255e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2562:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2566:	2501                	sext.w	a0,a0
    2568:	8082                	ret

000000000000256a <mailread>:
	register long a7 __asm__("a7") = n;
    256a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    256e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2572:	2501                	sext.w	a0,a0
    2574:	8082                	ret

0000000000002576 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2576:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    257a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <fstat>:
	register long a7 __asm__("a7") = n;
    2582:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2586:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    258a:	2501                	sext.w	a0,a0
    258c:	8082                	ret

000000000000258e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    258e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2590:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2594:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2596:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    259a:	2501                	sext.w	a0,a0
    259c:	8082                	ret

000000000000259e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    259e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25a0:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25a4:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25a6:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25aa:	2501                	sext.w	a0,a0
    25ac:	8082                	ret

00000000000025ae <link>:

int link(char *old_path, char *new_path)
{
    25ae:	87aa                	mv	a5,a0
    25b0:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25b2:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25b6:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25ba:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25bc:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25c0:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25c2:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25c6:	2501                	sext.w	a0,a0
    25c8:	8082                	ret

00000000000025ca <unlink>:

int unlink(char *path)
{
    25ca:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25cc:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25d0:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25d4:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d6:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25da:	2501                	sext.w	a0,a0
    25dc:	8082                	ret

00000000000025de <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25de:	00000797          	auipc	a5,0x0
    25e2:	35a7b783          	ld	a5,858(a5) # 2938 <_GLOBAL_OFFSET_TABLE_+0x8>
    25e6:	439c                	lw	a5,0(a5)
    25e8:	c799                	beqz	a5,25f6 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25ea:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ee:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25f2:	2501                	sext.w	a0,a0
    25f4:	8082                	ret
{
    25f6:	1101                	addi	sp,sp,-32
    25f8:	ec06                	sd	ra,24(sp)
    25fa:	e42e                	sd	a1,8(sp)
    25fc:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25fe:	fe7fe0ef          	jal	ra,15e4 <enable_thread_io_buffer>
    2602:	65a2                	ld	a1,8(sp)
    2604:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2606:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    260a:	00000073          	ecall
}
    260e:	60e2                	ld	ra,24(sp)
    2610:	2501                	sext.w	a0,a0
    2612:	6105                	addi	sp,sp,32
    2614:	8082                	ret

0000000000002616 <gettid>:
	register long a7 __asm__("a7") = n;
    2616:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    261a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    261e:	2501                	sext.w	a0,a0
    2620:	8082                	ret

0000000000002622 <waittid>:

int waittid(int tid)
{
    2622:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2624:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2628:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    262c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    262e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2630:	00e51e63          	bne	a0,a4,264c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2634:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2638:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    263c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2640:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2642:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2646:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2648:	fee506e3          	beq	a0,a4,2634 <waittid+0x12>
	}
	return ret;
}
    264c:	8082                	ret

000000000000264e <mutex_create>:
	register long a7 __asm__("a7") = n;
    264e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2652:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2654:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2658:	2501                	sext.w	a0,a0
    265a:	8082                	ret

000000000000265c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    265c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2660:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2662:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2666:	2501                	sext.w	a0,a0
    2668:	8082                	ret

000000000000266a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    266a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    266e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2672:	2501                	sext.w	a0,a0
    2674:	8082                	ret

0000000000002676 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2676:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    267a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2682:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2686:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    268e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2696:	2501                	sext.w	a0,a0
    2698:	8082                	ret

000000000000269a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    269a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    269e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <condvar_create>:
	register long a7 __asm__("a7") = n;
    26a6:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26aa:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26b2:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26b6:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26be:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c2:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26ca:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret
