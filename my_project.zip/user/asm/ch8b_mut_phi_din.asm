
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch8b_mut_phi_din:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a605                	j	1320 <__start_main>

0000000000001002 <philosopher_dining>:
int eat[N][ROUND * 2];

void philosopher_dining(long id)
{
	int left = id;
	int right = (id + 1) % N;
    1002:	4715                	li	a4,5
    1004:	00150793          	addi	a5,a0,1
    1008:	02e7e7b3          	rem	a5,a5,a4
{
    100c:	7139                	addi	sp,sp,-64
    100e:	e852                	sd	s4,16(sp)
    1010:	fc06                	sd	ra,56(sp)
    1012:	f822                	sd	s0,48(sp)
    1014:	f426                	sd	s1,40(sp)
    1016:	f04a                	sd	s2,32(sp)
    1018:	ec4e                	sd	s3,24(sp)
    101a:	e456                	sd	s5,8(sp)
	int left = id;
    101c:	0005071b          	sext.w	a4,a0
	int min = left < right ? left : right;
    1020:	00078a1b          	sext.w	s4,a5
    1024:	00e7c463          	blt	a5,a4,102c <philosopher_dining+0x2a>
    1028:	00070a1b          	sext.w	s4,a4
	int max = left < right ? right : left;
    102c:	0007099b          	sext.w	s3,a4
    1030:	00f75463          	bge	a4,a5,1038 <philosopher_dining+0x36>
    1034:	0007899b          	sext.w	s3,a5
    1038:	0516                	slli	a0,a0,0x5
	for (int round = 0; round < ROUND; round++) {
    103a:	00002417          	auipc	s0,0x2
    103e:	bc640413          	addi	s0,s0,-1082 # 2c00 <think>
    1042:	00002917          	auipc	s2,0x2
    1046:	e0e90913          	addi	s2,s2,-498 # 2e50 <arr>
    104a:	00002497          	auipc	s1,0x2
    104e:	c5648493          	addi	s1,s1,-938 # 2ca0 <eat>
    1052:	00002a97          	auipc	s5,0x2
    1056:	bcea8a93          	addi	s5,s5,-1074 # 2c20 <think+0x20>
    105a:	942a                	add	s0,s0,a0
    105c:	992a                	add	s2,s2,a0
    105e:	94aa                	add	s1,s1,a0
    1060:	9aaa                	add	s5,s5,a0
		// thinking
		think[id][2 * round] = get_mtime();
    1062:	6b4010ef          	jal	ra,2716 <get_mtime>
		sleep(arr[id][2 * round] * SLEEP_SCALE);
    1066:	00092783          	lw	a5,0(s2)
		think[id][2 * round] = get_mtime();
    106a:	c008                	sw	a0,0(s0)
	for (int round = 0; round < ROUND; round++) {
    106c:	0421                	addi	s0,s0,8
		sleep(arr[id][2 * round] * SLEEP_SCALE);
    106e:	0027951b          	slliw	a0,a5,0x2
    1072:	9d3d                	addw	a0,a0,a5
    1074:	0015151b          	slliw	a0,a0,0x1
    1078:	6d6010ef          	jal	ra,274e <sleep>
		think[id][2 * round + 1] = get_mtime();
    107c:	69a010ef          	jal	ra,2716 <get_mtime>
    1080:	87aa                	mv	a5,a0
    1082:	fef42e23          	sw	a5,-4(s0)
		// wait for forks
		mutex_lock(min);
    1086:	8552                	mv	a0,s4
    1088:	093010ef          	jal	ra,291a <mutex_lock>
		mutex_lock(max);
    108c:	854e                	mv	a0,s3
    108e:	08d010ef          	jal	ra,291a <mutex_lock>
		// eating
		eat[id][2 * round] = get_mtime();
    1092:	684010ef          	jal	ra,2716 <get_mtime>
		sleep(arr[id][2 * round + 1] * SLEEP_SCALE);
    1096:	00492783          	lw	a5,4(s2)
		eat[id][2 * round] = get_mtime();
    109a:	c088                	sw	a0,0(s1)
	for (int round = 0; round < ROUND; round++) {
    109c:	0921                	addi	s2,s2,8
		sleep(arr[id][2 * round + 1] * SLEEP_SCALE);
    109e:	0027951b          	slliw	a0,a5,0x2
    10a2:	9d3d                	addw	a0,a0,a5
    10a4:	0015151b          	slliw	a0,a0,0x1
    10a8:	6a6010ef          	jal	ra,274e <sleep>
		eat[id][2 * round + 1] = get_mtime();
    10ac:	66a010ef          	jal	ra,2716 <get_mtime>
    10b0:	87aa                	mv	a5,a0
    10b2:	c0dc                	sw	a5,4(s1)
		mutex_unlock(max);
    10b4:	854e                	mv	a0,s3
    10b6:	071010ef          	jal	ra,2926 <mutex_unlock>
		mutex_unlock(min);
    10ba:	8552                	mv	a0,s4
    10bc:	06b010ef          	jal	ra,2926 <mutex_unlock>
	for (int round = 0; round < ROUND; round++) {
    10c0:	04a1                	addi	s1,s1,8
    10c2:	fb5410e3          	bne	s0,s5,1062 <philosopher_dining+0x60>
	}
	exit(0);
}
    10c6:	7442                	ld	s0,48(sp)
    10c8:	70e2                	ld	ra,56(sp)
    10ca:	74a2                	ld	s1,40(sp)
    10cc:	7902                	ld	s2,32(sp)
    10ce:	69e2                	ld	s3,24(sp)
    10d0:	6a42                	ld	s4,16(sp)
    10d2:	6aa2                	ld	s5,8(sp)
	exit(0);
    10d4:	4501                	li	a0,0
}
    10d6:	6121                	addi	sp,sp,64
	exit(0);
    10d8:	6040106f          	j	26dc <exit>

00000000000010dc <main>:

int main()
{
    10dc:	7175                	addi	sp,sp,-144
	printf("Here comes %d philosophers!\n", N);
    10de:	4595                	li	a1,5
    10e0:	00002517          	auipc	a0,0x2
    10e4:	8a850513          	addi	a0,a0,-1880 # 2988 <enable_deadlock_detect+0xe>
{
    10e8:	e506                	sd	ra,136(sp)
    10ea:	e122                	sd	s0,128(sp)
    10ec:	f8ca                	sd	s2,112(sp)
    10ee:	f0d2                	sd	s4,96(sp)
    10f0:	ecd6                	sd	s5,88(sp)
    10f2:	e8da                	sd	s6,80(sp)
    10f4:	e4de                	sd	s7,72(sp)
    10f6:	fca6                	sd	s1,120(sp)
    10f8:	f4ce                	sd	s3,104(sp)
    10fa:	e0e2                	sd	s8,64(sp)
    10fc:	fc66                	sd	s9,56(sp)
    10fe:	f86a                	sd	s10,48(sp)
    1100:	f46e                	sd	s11,40(sp)
	printf("Here comes %d philosophers!\n", N);
    1102:	378000ef          	jal	ra,147a <printf>
	int threads[N];
	int start = get_mtime();
    1106:	610010ef          	jal	ra,2716 <get_mtime>
    110a:	892a                	mv	s2,a0
	for (int i = 0; i < N; i++) {
    110c:	4401                	li	s0,0
    110e:	4a15                	li	s4,5
		assert_eq(mutex_blocking_create(), i);
    1110:	00002b97          	auipc	s7,0x2
    1114:	898b8b93          	addi	s7,s7,-1896 # 29a8 <enable_deadlock_detect+0x2e>
    1118:	00002b17          	auipc	s6,0x2
    111c:	8e0b0b13          	addi	s6,s6,-1824 # 29f8 <enable_deadlock_detect+0x7e>
    1120:	00002a97          	auipc	s5,0x2
    1124:	8e0a8a93          	addi	s5,s5,-1824 # 2a00 <enable_deadlock_detect+0x86>
    1128:	7e4010ef          	jal	ra,290c <mutex_blocking_create>
    112c:	1c850363          	beq	a0,s0,12f2 <main+0x216>
    1130:	57c010ef          	jal	ra,26ac <getpid>
    1134:	84aa                	mv	s1,a0
    1136:	855e                	mv	a0,s7
    1138:	44a010ef          	jal	ra,2582 <basename>
    113c:	89aa                	mv	s3,a0
    113e:	7ce010ef          	jal	ra,290c <mutex_blocking_create>
    1142:	88a2                	mv	a7,s0
    1144:	882a                	mv	a6,a0
    1146:	03000793          	li	a5,48
    114a:	8556                	mv	a0,s5
    114c:	874e                	mv	a4,s3
    114e:	86a6                	mv	a3,s1
    1150:	865a                	mv	a2,s6
    1152:	45fd                	li	a1,31
    1154:	326000ef          	jal	ra,147a <printf>
	for (int i = 0; i < N; i++) {
    1158:	2405                	addiw	s0,s0,1
		assert_eq(mutex_blocking_create(), i);
    115a:	557d                	li	a0,-1
    115c:	580010ef          	jal	ra,26dc <exit>
	for (int i = 0; i < N; i++) {
    1160:	fd4414e3          	bne	s0,s4,1128 <main+0x4c>
    1164:	0020                	addi	s0,sp,8
    1166:	89a2                	mv	s3,s0
    1168:	4481                	li	s1,0
	}
	// Notice: Children threads creating must be after mutex creation
	for (int i = 0; i < N; i++) {
		threads[i] = thread_create(philosopher_dining, (void *)i);
    116a:	00000a97          	auipc	s5,0x0
    116e:	e98a8a93          	addi	s5,s5,-360 # 1002 <philosopher_dining>
		assert(threads[i] > 0);
    1172:	00002c97          	auipc	s9,0x2
    1176:	836c8c93          	addi	s9,s9,-1994 # 29a8 <enable_deadlock_detect+0x2e>
    117a:	00002c17          	auipc	s8,0x2
    117e:	87ec0c13          	addi	s8,s8,-1922 # 29f8 <enable_deadlock_detect+0x7e>
    1182:	00002b97          	auipc	s7,0x2
    1186:	8b6b8b93          	addi	s7,s7,-1866 # 2a38 <enable_deadlock_detect+0xbe>
	for (int i = 0; i < N; i++) {
    118a:	4a15                	li	s4,5
		threads[i] = thread_create(philosopher_dining, (void *)i);
    118c:	85a6                	mv	a1,s1
    118e:	8556                	mv	a0,s5
    1190:	6fe010ef          	jal	ra,288e <thread_create>
    1194:	00a9a023          	sw	a0,0(s3)
	for (int i = 0; i < N; i++) {
    1198:	0485                	addi	s1,s1,1
		assert(threads[i] > 0);
    119a:	16a05063          	blez	a0,12fa <main+0x21e>
	for (int i = 0; i < N; i++) {
    119e:	0991                	addi	s3,s3,4
    11a0:	ff4496e3          	bne	s1,s4,118c <main+0xb0>
	}
	puts("Phil threads created");
    11a4:	00002517          	auipc	a0,0x2
    11a8:	8cc50513          	addi	a0,a0,-1844 # 2a70 <enable_deadlock_detect+0xf6>
    11ac:	1e5000ef          	jal	ra,1b90 <puts>
	for (int i = 0; i < N; i++) {
    11b0:	01440493          	addi	s1,s0,20
		waittid(threads[i]);
    11b4:	4008                	lw	a0,0(s0)
	for (int i = 0; i < N; i++) {
    11b6:	0411                	addi	s0,s0,4
		waittid(threads[i]);
    11b8:	71a010ef          	jal	ra,28d2 <waittid>
	for (int i = 0; i < N; i++) {
    11bc:	fe849ce3          	bne	s1,s0,11b4 <main+0xd8>
	}
	int time_cost = get_mtime() - start;
    11c0:	556010ef          	jal	ra,2716 <get_mtime>
    11c4:	412509bb          	subw	s3,a0,s2
	printf("time cost = %d ms\n", time_cost);
    11c8:	85ce                	mv	a1,s3
    11ca:	00002517          	auipc	a0,0x2
    11ce:	8be50513          	addi	a0,a0,-1858 # 2a88 <enable_deadlock_detect+0x10e>
    11d2:	2a8000ef          	jal	ra,147a <printf>
	puts("'-' -> THINKING; 'x' -> EATING; ' ' -> WAITING ");
    11d6:	00002517          	auipc	a0,0x2
    11da:	8ca50513          	addi	a0,a0,-1846 # 2aa0 <enable_deadlock_detect+0x126>
    11de:	1b3000ef          	jal	ra,1b90 <puts>
	for (int i = 0; i <= N; i++) {
		int id = i % N;
		printf("#%d:", id);
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    11e2:	47a9                	li	a5,10
    11e4:	02f9cdbb          	divw	s11,s3,a5
	int time_cost = get_mtime() - start;
    11e8:	2901                	sext.w	s2,s2
	for (int i = 0; i <= N; i++) {
    11ea:	4481                	li	s1,0
		int id = i % N;
    11ec:	4b95                	li	s7,5
		printf("#%d:", id);
    11ee:	00002b17          	auipc	s6,0x2
    11f2:	8e2b0b13          	addi	s6,s6,-1822 # 2ad0 <enable_deadlock_detect+0x156>
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    11f6:	4aa5                	li	s5,9
    11f8:	00002c17          	auipc	s8,0x2
    11fc:	a08c0c13          	addi	s8,s8,-1528 # 2c00 <think>
	for (int i = 0; i <= N; i++) {
    1200:	4a19                	li	s4,6
		printf("#%d:", id);
    1202:	855a                	mv	a0,s6
		int id = i % N;
    1204:	0374e43b          	remw	s0,s1,s7
		printf("#%d:", id);
    1208:	85a2                	mv	a1,s0
    120a:	270000ef          	jal	ra,147a <printf>
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    120e:	093adf63          	bge	s5,s3,12ac <main+0x1d0>
    1212:	0416                	slli	s0,s0,0x5
    1214:	8cca                	mv	s9,s2
    1216:	4d01                	li	s10,0
			int current = j * SLEEP_SCALE + start;
			int round;
			for (round = 0; round < ROUND; round++) {
				int start_thinking = think[id][2 * round];
				int stop_thinking = think[id][2 * round + 1];
    1218:	9462                	add	s0,s0,s8
    121a:	a0b9                	j	1268 <main+0x18c>
			if (round < ROUND)
				continue;
			for (round = 0; round < ROUND; round++) {
				int start_eating = eat[id][2 * round];
				int stop_eating = eat[id][2 * round + 1];
				if (start_eating <= current &&
    121c:	0a042703          	lw	a4,160(s0)
				int stop_eating = eat[id][2 * round + 1];
    1220:	0a442683          	lw	a3,164(s0)
				if (start_eating <= current &&
    1224:	00e7c463          	blt	a5,a4,122c <main+0x150>
    1228:	0cf6d063          	bge	a3,a5,12e8 <main+0x20c>
    122c:	0a842703          	lw	a4,168(s0)
				int stop_eating = eat[id][2 * round + 1];
    1230:	0ac42683          	lw	a3,172(s0)
				if (start_eating <= current &&
    1234:	00e7c463          	blt	a5,a4,123c <main+0x160>
    1238:	0af6d863          	bge	a3,a5,12e8 <main+0x20c>
    123c:	0b042703          	lw	a4,176(s0)
				int stop_eating = eat[id][2 * round + 1];
    1240:	0b442683          	lw	a3,180(s0)
				if (start_eating <= current &&
    1244:	00e7c463          	blt	a5,a4,124c <main+0x170>
    1248:	0af6d063          	bge	a3,a5,12e8 <main+0x20c>
    124c:	0b842703          	lw	a4,184(s0)
				int stop_eating = eat[id][2 * round + 1];
    1250:	0bc42683          	lw	a3,188(s0)
				if (start_eating <= current &&
    1254:	08e7d863          	bge	a5,a4,12e4 <main+0x208>
					break;
				}
			}
			if (round < ROUND)
				continue;
			putchar(' ');
    1258:	02000513          	li	a0,32
    125c:	05f000ef          	jal	ra,1aba <putchar>
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    1260:	2d05                	addiw	s10,s10,1
    1262:	2ca9                	addiw	s9,s9,10
    1264:	05bd5463          	bge	s10,s11,12ac <main+0x1d0>
				if (start_thinking <= current &&
    1268:	4018                	lw	a4,0(s0)
				int stop_thinking = think[id][2 * round + 1];
    126a:	4054                	lw	a3,4(s0)
				if (start_thinking <= current &&
    126c:	000c879b          	sext.w	a5,s9
    1270:	00ecc463          	blt	s9,a4,1278 <main+0x19c>
    1274:	02f6d463          	bge	a3,a5,129c <main+0x1c0>
    1278:	4418                	lw	a4,8(s0)
				int stop_thinking = think[id][2 * round + 1];
    127a:	4454                	lw	a3,12(s0)
				if (start_thinking <= current &&
    127c:	00e7c463          	blt	a5,a4,1284 <main+0x1a8>
    1280:	00f6de63          	bge	a3,a5,129c <main+0x1c0>
    1284:	4818                	lw	a4,16(s0)
				int stop_thinking = think[id][2 * round + 1];
    1286:	4854                	lw	a3,20(s0)
				if (start_thinking <= current &&
    1288:	00e7c463          	blt	a5,a4,1290 <main+0x1b4>
    128c:	00f6d863          	bge	a3,a5,129c <main+0x1c0>
    1290:	4c18                	lw	a4,24(s0)
				int stop_thinking = think[id][2 * round + 1];
    1292:	4c54                	lw	a3,28(s0)
				if (start_thinking <= current &&
    1294:	f8e7c4e3          	blt	a5,a4,121c <main+0x140>
    1298:	f8f6c2e3          	blt	a3,a5,121c <main+0x140>
					putchar('-');
    129c:	02d00513          	li	a0,45
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    12a0:	2d05                	addiw	s10,s10,1
					putchar('-');
    12a2:	019000ef          	jal	ra,1aba <putchar>
		for (int j = 0; j < time_cost / SLEEP_SCALE; j++) {
    12a6:	2ca9                	addiw	s9,s9,10
    12a8:	fdbd40e3          	blt	s10,s11,1268 <main+0x18c>
	for (int i = 0; i <= N; i++) {
    12ac:	2485                	addiw	s1,s1,1
		}
		putchar('\n');
    12ae:	4529                	li	a0,10
    12b0:	00b000ef          	jal	ra,1aba <putchar>
	for (int i = 0; i <= N; i++) {
    12b4:	f54497e3          	bne	s1,s4,1202 <main+0x126>
	}
	puts("philosopher dining problem with mutex passed!");
    12b8:	00002517          	auipc	a0,0x2
    12bc:	82050513          	addi	a0,a0,-2016 # 2ad8 <enable_deadlock_detect+0x15e>
    12c0:	0d1000ef          	jal	ra,1b90 <puts>
	return 0;
}
    12c4:	60aa                	ld	ra,136(sp)
    12c6:	640a                	ld	s0,128(sp)
    12c8:	74e6                	ld	s1,120(sp)
    12ca:	7946                	ld	s2,112(sp)
    12cc:	79a6                	ld	s3,104(sp)
    12ce:	7a06                	ld	s4,96(sp)
    12d0:	6ae6                	ld	s5,88(sp)
    12d2:	6b46                	ld	s6,80(sp)
    12d4:	6ba6                	ld	s7,72(sp)
    12d6:	6c06                	ld	s8,64(sp)
    12d8:	7ce2                	ld	s9,56(sp)
    12da:	7d42                	ld	s10,48(sp)
    12dc:	7da2                	ld	s11,40(sp)
    12de:	4501                	li	a0,0
    12e0:	6149                	addi	sp,sp,144
    12e2:	8082                	ret
				if (start_eating <= current &&
    12e4:	f6f6cae3          	blt	a3,a5,1258 <main+0x17c>
					putchar('x');
    12e8:	07800513          	li	a0,120
    12ec:	7ce000ef          	jal	ra,1aba <putchar>
			if (round < ROUND)
    12f0:	bf85                	j	1260 <main+0x184>
	for (int i = 0; i < N; i++) {
    12f2:	2405                	addiw	s0,s0,1
    12f4:	e3441ae3          	bne	s0,s4,1128 <main+0x4c>
    12f8:	b5b5                	j	1164 <main+0x88>
		assert(threads[i] > 0);
    12fa:	3b2010ef          	jal	ra,26ac <getpid>
    12fe:	8b2a                	mv	s6,a0
    1300:	8566                	mv	a0,s9
    1302:	280010ef          	jal	ra,2582 <basename>
    1306:	872a                	mv	a4,a0
    1308:	03500793          	li	a5,53
    130c:	855e                	mv	a0,s7
    130e:	86da                	mv	a3,s6
    1310:	8662                	mv	a2,s8
    1312:	45fd                	li	a1,31
    1314:	166000ef          	jal	ra,147a <printf>
    1318:	557d                	li	a0,-1
    131a:	3c2010ef          	jal	ra,26dc <exit>
    131e:	b541                	j	119e <main+0xc2>

0000000000001320 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1320:	1141                	addi	sp,sp,-16
    1322:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1324:	db9ff0ef          	jal	ra,10dc <main>
    1328:	3b4010ef          	jal	ra,26dc <exit>
	return 0;
    132c:	60a2                	ld	ra,8(sp)
    132e:	4501                	li	a0,0
    1330:	0141                	addi	sp,sp,16
    1332:	8082                	ret

0000000000001334 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1334:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1336:	4605                	li	a2,1
    1338:	00f10593          	addi	a1,sp,15
    133c:	4501                	li	a0,0
{
    133e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1340:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1344:	354010ef          	jal	ra,2698 <read>
    1348:	4785                	li	a5,1
    134a:	00f51763          	bne	a0,a5,1358 <getchar+0x24>
		return byte;
    134e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1352:	60e2                	ld	ra,24(sp)
    1354:	6105                	addi	sp,sp,32
    1356:	8082                	ret
		return EOF;
    1358:	557d                	li	a0,-1
    135a:	bfe5                	j	1352 <getchar+0x1e>

000000000000135c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    135c:	00002517          	auipc	a0,0x2
    1360:	9e452503          	lw	a0,-1564(a0) # 2d40 <buffer_len>
    1364:	e111                	bnez	a0,1368 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1366:	8082                	ret
{
    1368:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    136a:	862a                	mv	a2,a0
    136c:	00002597          	auipc	a1,0x2
    1370:	9dc58593          	addi	a1,a1,-1572 # 2d48 <buffer>
    1374:	4505                	li	a0,1
{
    1376:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1378:	32a010ef          	jal	ra,26a2 <write>
}
    137c:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    137e:	2501                	sext.w	a0,a0
}
    1380:	0141                	addi	sp,sp,16
    1382:	8082                	ret

0000000000001384 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1384:	00002797          	auipc	a5,0x2
    1388:	9a07ae23          	sw	zero,-1604(a5) # 2d40 <buffer_len>
}
    138c:	8082                	ret

000000000000138e <__fflush>:
	if (buffer_len == 0)
    138e:	00002517          	auipc	a0,0x2
    1392:	9b252503          	lw	a0,-1614(a0) # 2d40 <buffer_len>
    1396:	e511                	bnez	a0,13a2 <__fflush+0x14>
	buffer_len = 0;
    1398:	00002797          	auipc	a5,0x2
    139c:	9a07a423          	sw	zero,-1624(a5) # 2d40 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13a0:	8082                	ret
{
    13a2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13a4:	862a                	mv	a2,a0
    13a6:	00002597          	auipc	a1,0x2
    13aa:	9a258593          	addi	a1,a1,-1630 # 2d48 <buffer>
    13ae:	4505                	li	a0,1
{
    13b0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13b2:	2f0010ef          	jal	ra,26a2 <write>
	return r >= 0 ? 0 : r;
    13b6:	0005079b          	sext.w	a5,a0
}
    13ba:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13bc:	0017a793          	slti	a5,a5,1
    13c0:	40f007bb          	negw	a5,a5
    13c4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13c6:	00002797          	auipc	a5,0x2
    13ca:	9607ad23          	sw	zero,-1670(a5) # 2d40 <buffer_len>
	return r >= 0 ? 0 : r;
    13ce:	2501                	sext.w	a0,a0
}
    13d0:	0141                	addi	sp,sp,16
    13d2:	8082                	ret

00000000000013d4 <fflush>:

int fflush(int fd)
{
    13d4:	1101                	addi	sp,sp,-32
    13d6:	e822                	sd	s0,16(sp)
    13d8:	ec06                	sd	ra,24(sp)
    13da:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13dc:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13de:	4401                	li	s0,0
	if (fd == 1) {
    13e0:	00e50863          	beq	a0,a4,13f0 <fflush+0x1c>
}
    13e4:	60e2                	ld	ra,24(sp)
    13e6:	8522                	mv	a0,s0
    13e8:	6442                	ld	s0,16(sp)
    13ea:	64a2                	ld	s1,8(sp)
    13ec:	6105                	addi	sp,sp,32
    13ee:	8082                	ret
		if (buffer_lock_enabled == 1) {
    13f0:	00002497          	auipc	s1,0x2
    13f4:	95048493          	addi	s1,s1,-1712 # 2d40 <buffer_len>
    13f8:	1084a703          	lw	a4,264(s1)
    13fc:	02a70e63          	beq	a4,a0,1438 <fflush+0x64>
	if (buffer_len == 0)
    1400:	4080                	lw	s0,0(s1)
    1402:	c00d                	beqz	s0,1424 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1404:	8622                	mv	a2,s0
    1406:	00002597          	auipc	a1,0x2
    140a:	94258593          	addi	a1,a1,-1726 # 2d48 <buffer>
    140e:	294010ef          	jal	ra,26a2 <write>
	return r >= 0 ? 0 : r;
    1412:	0005079b          	sext.w	a5,a0
    1416:	0017a793          	slti	a5,a5,1
    141a:	40f007bb          	negw	a5,a5
    141e:	8d7d                	and	a0,a0,a5
    1420:	0005041b          	sext.w	s0,a0
}
    1424:	60e2                	ld	ra,24(sp)
    1426:	8522                	mv	a0,s0
    1428:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    142a:	00002797          	auipc	a5,0x2
    142e:	9007ab23          	sw	zero,-1770(a5) # 2d40 <buffer_len>
}
    1432:	64a2                	ld	s1,8(sp)
    1434:	6105                	addi	sp,sp,32
    1436:	8082                	ret
			mutex_lock(buffer_lock);
    1438:	10c4a503          	lw	a0,268(s1)
    143c:	4de010ef          	jal	ra,291a <mutex_lock>
	if (buffer_len == 0)
    1440:	4080                	lw	s0,0(s1)
    1442:	e811                	bnez	s0,1456 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1444:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1448:	00002797          	auipc	a5,0x2
    144c:	8e07ac23          	sw	zero,-1800(a5) # 2d40 <buffer_len>
			mutex_unlock(buffer_lock);
    1450:	4d6010ef          	jal	ra,2926 <mutex_unlock>
    1454:	bf41                	j	13e4 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1456:	8622                	mv	a2,s0
    1458:	00002597          	auipc	a1,0x2
    145c:	8f058593          	addi	a1,a1,-1808 # 2d48 <buffer>
    1460:	4505                	li	a0,1
    1462:	240010ef          	jal	ra,26a2 <write>
	return r >= 0 ? 0 : r;
    1466:	0005079b          	sext.w	a5,a0
    146a:	0017a793          	slti	a5,a5,1
    146e:	40f007bb          	negw	a5,a5
    1472:	8d7d                	and	a0,a0,a5
    1474:	0005041b          	sext.w	s0,a0
	return r;
    1478:	b7f1                	j	1444 <fflush+0x70>

000000000000147a <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    147a:	7131                	addi	sp,sp,-192
    147c:	e0da                	sd	s6,64(sp)
    147e:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1480:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1482:	013c                	addi	a5,sp,136
{
    1484:	f0ca                	sd	s2,96(sp)
    1486:	ecce                	sd	s3,88(sp)
    1488:	e8d2                	sd	s4,80(sp)
    148a:	e4d6                	sd	s5,72(sp)
    148c:	fc86                	sd	ra,120(sp)
    148e:	f8a2                	sd	s0,112(sp)
    1490:	f4a6                	sd	s1,104(sp)
    1492:	89aa                	mv	s3,a0
    1494:	e52e                	sd	a1,136(sp)
    1496:	e932                	sd	a2,144(sp)
    1498:	ed36                	sd	a3,152(sp)
    149a:	f13a                	sd	a4,160(sp)
    149c:	f942                	sd	a6,176(sp)
    149e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14a0:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14a2:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14a6:	00002a17          	auipc	s4,0x2
    14aa:	89aa0a13          	addi	s4,s4,-1894 # 2d40 <buffer_len>
    14ae:	4a85                	li	s5,1
	buf[i++] = '0';
    14b0:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14b4:	0009c783          	lbu	a5,0(s3)
    14b8:	18078663          	beqz	a5,1644 <printf+0x1ca>
    14bc:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14be:	19278d63          	beq	a5,s2,1658 <printf+0x1de>
    14c2:	0015c783          	lbu	a5,1(a1)
    14c6:	0585                	addi	a1,a1,1
    14c8:	fbfd                	bnez	a5,14be <printf+0x44>
    14ca:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14cc:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14d0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14d4:	1b578863          	beq	a5,s5,1684 <printf+0x20a>
		len = out_unlocked(s, l);
    14d8:	85a2                	mv	a1,s0
    14da:	854e                	mv	a0,s3
    14dc:	42a000ef          	jal	ra,1906 <out_unlocked>
		out(f, a, l);
		if (l)
    14e0:	1c041063          	bnez	s0,16a0 <printf+0x226>
			continue;
		if (s[1] == 0)
    14e4:	0014c783          	lbu	a5,1(s1)
    14e8:	14078e63          	beqz	a5,1644 <printf+0x1ca>
			break;
		switch (s[1]) {
    14ec:	07300713          	li	a4,115
    14f0:	1ce78863          	beq	a5,a4,16c0 <printf+0x246>
    14f4:	1af76863          	bltu	a4,a5,16a4 <printf+0x22a>
    14f8:	06400713          	li	a4,100
    14fc:	22e78063          	beq	a5,a4,171c <printf+0x2a2>
    1500:	07000713          	li	a4,112
    1504:	1ee79563          	bne	a5,a4,16ee <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1508:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    150a:	00002797          	auipc	a5,0x2
    150e:	9e678793          	addi	a5,a5,-1562 # 2ef0 <digits>
	buf[i++] = '0';
    1512:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1516:	6298                	ld	a4,0(a3)
    1518:	06a1                	addi	a3,a3,8
    151a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    151c:	00471393          	slli	t2,a4,0x4
    1520:	00871293          	slli	t0,a4,0x8
    1524:	00c71f93          	slli	t6,a4,0xc
    1528:	01071f13          	slli	t5,a4,0x10
    152c:	01471e93          	slli	t4,a4,0x14
    1530:	01871e13          	slli	t3,a4,0x18
    1534:	01c71893          	slli	a7,a4,0x1c
    1538:	02471813          	slli	a6,a4,0x24
    153c:	02871513          	slli	a0,a4,0x28
    1540:	02c71593          	slli	a1,a4,0x2c
    1544:	03071613          	slli	a2,a4,0x30
    1548:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    154c:	03c75413          	srli	s0,a4,0x3c
    1550:	01c7531b          	srliw	t1,a4,0x1c
    1554:	03c3d393          	srli	t2,t2,0x3c
    1558:	03c2d293          	srli	t0,t0,0x3c
    155c:	03cfdf93          	srli	t6,t6,0x3c
    1560:	03cf5f13          	srli	t5,t5,0x3c
    1564:	03cede93          	srli	t4,t4,0x3c
    1568:	03ce5e13          	srli	t3,t3,0x3c
    156c:	03c8d893          	srli	a7,a7,0x3c
    1570:	03c85813          	srli	a6,a6,0x3c
    1574:	9171                	srli	a0,a0,0x3c
    1576:	91f1                	srli	a1,a1,0x3c
    1578:	9271                	srli	a2,a2,0x3c
    157a:	92f1                	srli	a3,a3,0x3c
    157c:	95be                	add	a1,a1,a5
    157e:	963e                	add	a2,a2,a5
    1580:	96be                	add	a3,a3,a5
    1582:	943e                	add	s0,s0,a5
    1584:	93be                	add	t2,t2,a5
    1586:	92be                	add	t0,t0,a5
    1588:	9fbe                	add	t6,t6,a5
    158a:	9f3e                	add	t5,t5,a5
    158c:	9ebe                	add	t4,t4,a5
    158e:	9e3e                	add	t3,t3,a5
    1590:	98be                	add	a7,a7,a5
    1592:	933e                	add	t1,t1,a5
    1594:	983e                	add	a6,a6,a5
    1596:	953e                	add	a0,a0,a5
    1598:	0005c983          	lbu	s3,0(a1)
    159c:	00044403          	lbu	s0,0(s0)
    15a0:	00064583          	lbu	a1,0(a2)
    15a4:	0003c383          	lbu	t2,0(t2)
    15a8:	0006c603          	lbu	a2,0(a3)
    15ac:	0002c283          	lbu	t0,0(t0)
    15b0:	000fcf83          	lbu	t6,0(t6)
    15b4:	000f4f03          	lbu	t5,0(t5)
    15b8:	000ece83          	lbu	t4,0(t4)
    15bc:	000e4e03          	lbu	t3,0(t3)
    15c0:	0008c883          	lbu	a7,0(a7)
    15c4:	00034303          	lbu	t1,0(t1)
    15c8:	00084803          	lbu	a6,0(a6)
    15cc:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15d0:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15d4:	92f1                	srli	a3,a3,0x3c
    15d6:	8b3d                	andi	a4,a4,15
    15d8:	96be                	add	a3,a3,a5
    15da:	97ba                	add	a5,a5,a4
    15dc:	00810d23          	sb	s0,26(sp)
    15e0:	00710da3          	sb	t2,27(sp)
    15e4:	00510e23          	sb	t0,28(sp)
    15e8:	01f10ea3          	sb	t6,29(sp)
    15ec:	01e10f23          	sb	t5,30(sp)
    15f0:	01d10fa3          	sb	t4,31(sp)
    15f4:	03c10023          	sb	t3,32(sp)
    15f8:	031100a3          	sb	a7,33(sp)
    15fc:	02610123          	sb	t1,34(sp)
    1600:	030101a3          	sb	a6,35(sp)
    1604:	02a10223          	sb	a0,36(sp)
    1608:	033102a3          	sb	s3,37(sp)
    160c:	02b10323          	sb	a1,38(sp)
    1610:	02c103a3          	sb	a2,39(sp)
    1614:	0006c683          	lbu	a3,0(a3)
    1618:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    161c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1620:	02d10423          	sb	a3,40(sp)
    1624:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1628:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    162c:	11578263          	beq	a5,s5,1730 <printf+0x2b6>
		len = out_unlocked(s, l);
    1630:	45c9                	li	a1,18
    1632:	0828                	addi	a0,sp,24
    1634:	2d2000ef          	jal	ra,1906 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1638:	00248993          	addi	s3,s1,2
		if (!*s)
    163c:	0009c783          	lbu	a5,0(s3)
    1640:	e6079ee3          	bnez	a5,14bc <printf+0x42>
	}
	va_end(ap);
    1644:	70e6                	ld	ra,120(sp)
    1646:	7446                	ld	s0,112(sp)
    1648:	74a6                	ld	s1,104(sp)
    164a:	7906                	ld	s2,96(sp)
    164c:	69e6                	ld	s3,88(sp)
    164e:	6a46                	ld	s4,80(sp)
    1650:	6aa6                	ld	s5,72(sp)
    1652:	6b06                	ld	s6,64(sp)
    1654:	6129                	addi	sp,sp,192
    1656:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1658:	0005c783          	lbu	a5,0(a1)
    165c:	84ae                	mv	s1,a1
    165e:	01278963          	beq	a5,s2,1670 <printf+0x1f6>
    1662:	b5ad                	j	14cc <printf+0x52>
    1664:	0024c783          	lbu	a5,2(s1)
    1668:	0585                	addi	a1,a1,1
    166a:	0489                	addi	s1,s1,2
    166c:	e72790e3          	bne	a5,s2,14cc <printf+0x52>
    1670:	0014c783          	lbu	a5,1(s1)
    1674:	ff2788e3          	beq	a5,s2,1664 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1678:	108a2783          	lw	a5,264(s4)
		l = z - a;
    167c:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1680:	e5579ce3          	bne	a5,s5,14d8 <printf+0x5e>
		mutex_lock(buffer_lock);
    1684:	10ca2503          	lw	a0,268(s4)
    1688:	292010ef          	jal	ra,291a <mutex_lock>
		len = out_unlocked(s, l);
    168c:	85a2                	mv	a1,s0
    168e:	854e                	mv	a0,s3
    1690:	276000ef          	jal	ra,1906 <out_unlocked>
		mutex_unlock(buffer_lock);
    1694:	10ca2503          	lw	a0,268(s4)
    1698:	28e010ef          	jal	ra,2926 <mutex_unlock>
		if (l)
    169c:	e40404e3          	beqz	s0,14e4 <printf+0x6a>
    16a0:	89a6                	mv	s3,s1
    16a2:	bd09                	j	14b4 <printf+0x3a>
		switch (s[1]) {
    16a4:	07800713          	li	a4,120
    16a8:	04e79363          	bne	a5,a4,16ee <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16ac:	67c2                	ld	a5,16(sp)
    16ae:	45c1                	li	a1,16
		s += 2;
    16b0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16b4:	4388                	lw	a0,0(a5)
    16b6:	07a1                	addi	a5,a5,8
    16b8:	e83e                	sd	a5,16(sp)
    16ba:	5f8000ef          	jal	ra,1cb2 <printint.constprop.0>
		s += 2;
    16be:	bfbd                	j	163c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16c0:	67c2                	ld	a5,16(sp)
    16c2:	6380                	ld	s0,0(a5)
    16c4:	07a1                	addi	a5,a5,8
    16c6:	e83e                	sd	a5,16(sp)
    16c8:	1c040163          	beqz	s0,188a <printf+0x410>
			l = strnlen(a, 200);
    16cc:	0c800593          	li	a1,200
    16d0:	8522                	mv	a0,s0
    16d2:	3f7000ef          	jal	ra,22c8 <strnlen>
	if (buffer_lock_enabled == 1) {
    16d6:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16da:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16de:	19578663          	beq	a5,s5,186a <printf+0x3f0>
		len = out_unlocked(s, l);
    16e2:	8522                	mv	a0,s0
    16e4:	222000ef          	jal	ra,1906 <out_unlocked>
		s += 2;
    16e8:	00248993          	addi	s3,s1,2
    16ec:	bf81                	j	163c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    16ee:	108a2783          	lw	a5,264(s4)
	char byte = c;
    16f2:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    16f6:	0f578663          	beq	a5,s5,17e2 <printf+0x368>
		len = out_unlocked(s, l);
    16fa:	0828                	addi	a0,sp,24
    16fc:	316000ef          	jal	ra,1a12 <out_unlocked.constprop.0>
			putchar(s[1]);
    1700:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1704:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1708:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    170c:	05578163          	beq	a5,s5,174e <printf+0x2d4>
		len = out_unlocked(s, l);
    1710:	0828                	addi	a0,sp,24
    1712:	300000ef          	jal	ra,1a12 <out_unlocked.constprop.0>
		s += 2;
    1716:	00248993          	addi	s3,s1,2
    171a:	b70d                	j	163c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    171c:	67c2                	ld	a5,16(sp)
    171e:	45a9                	li	a1,10
		s += 2;
    1720:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1724:	4388                	lw	a0,0(a5)
    1726:	07a1                	addi	a5,a5,8
    1728:	e83e                	sd	a5,16(sp)
    172a:	588000ef          	jal	ra,1cb2 <printint.constprop.0>
		s += 2;
    172e:	b739                	j	163c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1730:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1734:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1738:	1e2010ef          	jal	ra,291a <mutex_lock>
		len = out_unlocked(s, l);
    173c:	45c9                	li	a1,18
    173e:	0828                	addi	a0,sp,24
    1740:	1c6000ef          	jal	ra,1906 <out_unlocked>
		mutex_unlock(buffer_lock);
    1744:	10ca2503          	lw	a0,268(s4)
    1748:	1de010ef          	jal	ra,2926 <mutex_unlock>
		s += 2;
    174c:	bdc5                	j	163c <printf+0x1c2>
		mutex_lock(buffer_lock);
    174e:	10ca2503          	lw	a0,268(s4)
    1752:	1c8010ef          	jal	ra,291a <mutex_lock>
		buffer[buffer_len++] = c;
    1756:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    175a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    175e:	0017861b          	addiw	a2,a5,1
    1762:	97d2                	add	a5,a5,s4
    1764:	00ca2023          	sw	a2,0(s4)
    1768:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    176c:	00c6cc63          	blt	a3,a2,1784 <printf+0x30a>
    1770:	47a9                	li	a5,10
    1772:	06f40663          	beq	s0,a5,17de <printf+0x364>
		mutex_unlock(buffer_lock);
    1776:	10ca2503          	lw	a0,268(s4)
		s += 2;
    177a:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    177e:	1a8010ef          	jal	ra,2926 <mutex_unlock>
		s += 2;
    1782:	bd6d                	j	163c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1784:	10000793          	li	a5,256
    1788:	00f61e63          	bne	a2,a5,17a4 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    178c:	00001597          	auipc	a1,0x1
    1790:	5bc58593          	addi	a1,a1,1468 # 2d48 <buffer>
    1794:	4505                	li	a0,1
    1796:	70d000ef          	jal	ra,26a2 <write>
	buffer_len = 0;
    179a:	00001797          	auipc	a5,0x1
    179e:	5a07a323          	sw	zero,1446(a5) # 2d40 <buffer_len>
			if (r < 0) {
    17a2:	bfd1                	j	1776 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17a4:	709000ef          	jal	ra,26ac <getpid>
    17a8:	842a                	mv	s0,a0
    17aa:	00001517          	auipc	a0,0x1
    17ae:	36650513          	addi	a0,a0,870 # 2b10 <enable_deadlock_detect+0x196>
    17b2:	5d1000ef          	jal	ra,2582 <basename>
    17b6:	872a                	mv	a4,a0
    17b8:	00001617          	auipc	a2,0x1
    17bc:	24060613          	addi	a2,a2,576 # 29f8 <enable_deadlock_detect+0x7e>
    17c0:	05400793          	li	a5,84
    17c4:	86a2                	mv	a3,s0
    17c6:	45fd                	li	a1,31
    17c8:	00001517          	auipc	a0,0x1
    17cc:	38850513          	addi	a0,a0,904 # 2b50 <enable_deadlock_detect+0x1d6>
    17d0:	cabff0ef          	jal	ra,147a <printf>
    17d4:	557d                	li	a0,-1
    17d6:	707000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    17da:	000a2603          	lw	a2,0(s4)
    17de:	de41                	beqz	a2,1776 <printf+0x2fc>
    17e0:	b775                	j	178c <printf+0x312>
		mutex_lock(buffer_lock);
    17e2:	10ca2503          	lw	a0,268(s4)
    17e6:	134010ef          	jal	ra,291a <mutex_lock>
		buffer[buffer_len++] = c;
    17ea:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17ee:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    17f2:	0017861b          	addiw	a2,a5,1
    17f6:	97d2                	add	a5,a5,s4
    17f8:	00ca2023          	sw	a2,0(s4)
    17fc:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1800:	02c6d163          	bge	a3,a2,1822 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1804:	10000793          	li	a5,256
    1808:	02f61263          	bne	a2,a5,182c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    180c:	00001597          	auipc	a1,0x1
    1810:	53c58593          	addi	a1,a1,1340 # 2d48 <buffer>
    1814:	4505                	li	a0,1
    1816:	68d000ef          	jal	ra,26a2 <write>
	buffer_len = 0;
    181a:	00001797          	auipc	a5,0x1
    181e:	5207a323          	sw	zero,1318(a5) # 2d40 <buffer_len>
		mutex_unlock(buffer_lock);
    1822:	10ca2503          	lw	a0,268(s4)
    1826:	100010ef          	jal	ra,2926 <mutex_unlock>
    182a:	bdd9                	j	1700 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    182c:	681000ef          	jal	ra,26ac <getpid>
    1830:	842a                	mv	s0,a0
    1832:	00001517          	auipc	a0,0x1
    1836:	2de50513          	addi	a0,a0,734 # 2b10 <enable_deadlock_detect+0x196>
    183a:	549000ef          	jal	ra,2582 <basename>
    183e:	872a                	mv	a4,a0
    1840:	00001617          	auipc	a2,0x1
    1844:	1b860613          	addi	a2,a2,440 # 29f8 <enable_deadlock_detect+0x7e>
    1848:	05400793          	li	a5,84
    184c:	86a2                	mv	a3,s0
    184e:	45fd                	li	a1,31
    1850:	00001517          	auipc	a0,0x1
    1854:	30050513          	addi	a0,a0,768 # 2b50 <enable_deadlock_detect+0x1d6>
    1858:	c23ff0ef          	jal	ra,147a <printf>
    185c:	557d                	li	a0,-1
    185e:	67f000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    1862:	000a2603          	lw	a2,0(s4)
    1866:	de55                	beqz	a2,1822 <printf+0x3a8>
    1868:	b755                	j	180c <printf+0x392>
		mutex_lock(buffer_lock);
    186a:	10ca2503          	lw	a0,268(s4)
    186e:	e42e                	sd	a1,8(sp)
		s += 2;
    1870:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1874:	0a6010ef          	jal	ra,291a <mutex_lock>
		len = out_unlocked(s, l);
    1878:	65a2                	ld	a1,8(sp)
    187a:	8522                	mv	a0,s0
    187c:	08a000ef          	jal	ra,1906 <out_unlocked>
		mutex_unlock(buffer_lock);
    1880:	10ca2503          	lw	a0,268(s4)
    1884:	0a2010ef          	jal	ra,2926 <mutex_unlock>
		s += 2;
    1888:	bb55                	j	163c <printf+0x1c2>
				a = "(null)";
    188a:	00001417          	auipc	s0,0x1
    188e:	27e40413          	addi	s0,s0,638 # 2b08 <enable_deadlock_detect+0x18e>
    1892:	bd2d                	j	16cc <printf+0x252>

0000000000001894 <enable_thread_io_buffer>:
{
    1894:	1101                	addi	sp,sp,-32
    1896:	e822                	sd	s0,16(sp)
    1898:	ec06                	sd	ra,24(sp)
    189a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    189c:	00001417          	auipc	s0,0x1
    18a0:	4a440413          	addi	s0,s0,1188 # 2d40 <buffer_len>
    18a4:	05a010ef          	jal	ra,28fe <mutex_create>
    18a8:	10a42623          	sw	a0,268(s0)
    18ac:	00054a63          	bltz	a0,18c0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18b0:	4785                	li	a5,1
}
    18b2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18b4:	10f42423          	sw	a5,264(s0)
}
    18b8:	6442                	ld	s0,16(sp)
    18ba:	64a2                	ld	s1,8(sp)
    18bc:	6105                	addi	sp,sp,32
    18be:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18c0:	5ed000ef          	jal	ra,26ac <getpid>
    18c4:	84aa                	mv	s1,a0
    18c6:	00001517          	auipc	a0,0x1
    18ca:	24a50513          	addi	a0,a0,586 # 2b10 <enable_deadlock_detect+0x196>
    18ce:	4b5000ef          	jal	ra,2582 <basename>
    18d2:	872a                	mv	a4,a0
    18d4:	04800793          	li	a5,72
    18d8:	86a6                	mv	a3,s1
    18da:	00001517          	auipc	a0,0x1
    18de:	2b650513          	addi	a0,a0,694 # 2b90 <enable_deadlock_detect+0x216>
    18e2:	00001617          	auipc	a2,0x1
    18e6:	11660613          	addi	a2,a2,278 # 29f8 <enable_deadlock_detect+0x7e>
    18ea:	45fd                	li	a1,31
    18ec:	b8fff0ef          	jal	ra,147a <printf>
    18f0:	557d                	li	a0,-1
    18f2:	5eb000ef          	jal	ra,26dc <exit>
	buffer_lock_enabled = 1;
    18f6:	4785                	li	a5,1
}
    18f8:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18fa:	10f42423          	sw	a5,264(s0)
}
    18fe:	6442                	ld	s0,16(sp)
    1900:	64a2                	ld	s1,8(sp)
    1902:	6105                	addi	sp,sp,32
    1904:	8082                	ret

0000000000001906 <out_unlocked>:
{
    1906:	7159                	addi	sp,sp,-112
    1908:	f486                	sd	ra,104(sp)
    190a:	f0a2                	sd	s0,96(sp)
    190c:	eca6                	sd	s1,88(sp)
    190e:	e8ca                	sd	s2,80(sp)
    1910:	e4ce                	sd	s3,72(sp)
    1912:	e0d2                	sd	s4,64(sp)
    1914:	fc56                	sd	s5,56(sp)
    1916:	f85a                	sd	s6,48(sp)
    1918:	f45e                	sd	s7,40(sp)
    191a:	f062                	sd	s8,32(sp)
    191c:	ec66                	sd	s9,24(sp)
    191e:	e86a                	sd	s10,16(sp)
    1920:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1922:	0e058663          	beqz	a1,1a0e <out_unlocked+0x108>
    1926:	842a                	mv	s0,a0
    1928:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    192c:	4981                	li	s3,0
    192e:	00001d17          	auipc	s10,0x1
    1932:	412d0d13          	addi	s10,s10,1042 # 2d40 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1936:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    193a:	00001b17          	auipc	s6,0x1
    193e:	40eb0b13          	addi	s6,s6,1038 # 2d48 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1942:	10000a93          	li	s5,256
    1946:	00001c97          	auipc	s9,0x1
    194a:	1cac8c93          	addi	s9,s9,458 # 2b10 <enable_deadlock_detect+0x196>
    194e:	00001c17          	auipc	s8,0x1
    1952:	0aac0c13          	addi	s8,s8,170 # 29f8 <enable_deadlock_detect+0x7e>
    1956:	00001b97          	auipc	s7,0x1
    195a:	1fab8b93          	addi	s7,s7,506 # 2b50 <enable_deadlock_detect+0x1d6>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    195e:	4a29                	li	s4,10
    1960:	a031                	j	196c <out_unlocked+0x66>
    1962:	09468863          	beq	a3,s4,19f2 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1966:	0405                	addi	s0,s0,1
    1968:	04848163          	beq	s1,s0,19aa <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    196c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1970:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1974:	0017861b          	addiw	a2,a5,1
    1978:	97ea                	add	a5,a5,s10
    197a:	00cd2023          	sw	a2,0(s10)
    197e:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1982:	fec950e3          	bge	s2,a2,1962 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1986:	05561263          	bne	a2,s5,19ca <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    198a:	85da                	mv	a1,s6
    198c:	4505                	li	a0,1
    198e:	515000ef          	jal	ra,26a2 <write>
    1992:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1994:	00001797          	auipc	a5,0x1
    1998:	3a07a623          	sw	zero,940(a5) # 2d40 <buffer_len>
			if (r < 0) {
    199c:	06054763          	bltz	a0,1a0a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19a0:	0405                	addi	s0,s0,1
			ret += r;
    19a2:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19a6:	fc8493e3          	bne	s1,s0,196c <out_unlocked+0x66>
}
    19aa:	70a6                	ld	ra,104(sp)
    19ac:	7406                	ld	s0,96(sp)
    19ae:	64e6                	ld	s1,88(sp)
    19b0:	6946                	ld	s2,80(sp)
    19b2:	6a06                	ld	s4,64(sp)
    19b4:	7ae2                	ld	s5,56(sp)
    19b6:	7b42                	ld	s6,48(sp)
    19b8:	7ba2                	ld	s7,40(sp)
    19ba:	7c02                	ld	s8,32(sp)
    19bc:	6ce2                	ld	s9,24(sp)
    19be:	6d42                	ld	s10,16(sp)
    19c0:	6da2                	ld	s11,8(sp)
    19c2:	854e                	mv	a0,s3
    19c4:	69a6                	ld	s3,72(sp)
    19c6:	6165                	addi	sp,sp,112
    19c8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19ca:	4e3000ef          	jal	ra,26ac <getpid>
    19ce:	8daa                	mv	s11,a0
    19d0:	8566                	mv	a0,s9
    19d2:	3b1000ef          	jal	ra,2582 <basename>
    19d6:	872a                	mv	a4,a0
    19d8:	8662                	mv	a2,s8
    19da:	05400793          	li	a5,84
    19de:	86ee                	mv	a3,s11
    19e0:	45fd                	li	a1,31
    19e2:	855e                	mv	a0,s7
    19e4:	a97ff0ef          	jal	ra,147a <printf>
    19e8:	557d                	li	a0,-1
    19ea:	4f3000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    19ee:	000d2603          	lw	a2,0(s10)
    19f2:	da35                	beqz	a2,1966 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    19f4:	85da                	mv	a1,s6
    19f6:	4505                	li	a0,1
    19f8:	4ab000ef          	jal	ra,26a2 <write>
    19fc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19fe:	00001797          	auipc	a5,0x1
    1a02:	3407a123          	sw	zero,834(a5) # 2d40 <buffer_len>
			if (r < 0) {
    1a06:	f8055de3          	bgez	a0,19a0 <out_unlocked+0x9a>
    1a0a:	89aa                	mv	s3,a0
    1a0c:	bf79                	j	19aa <out_unlocked+0xa4>
	int ret = 0;
    1a0e:	4981                	li	s3,0
    1a10:	bf69                	j	19aa <out_unlocked+0xa4>

0000000000001a12 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a12:	1101                	addi	sp,sp,-32
    1a14:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a16:	00001497          	auipc	s1,0x1
    1a1a:	32a48493          	addi	s1,s1,810 # 2d40 <buffer_len>
    1a1e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a20:	ec06                	sd	ra,24(sp)
    1a22:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a24:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a28:	0017861b          	addiw	a2,a5,1
    1a2c:	97a6                	add	a5,a5,s1
    1a2e:	00e78423          	sb	a4,8(a5)
    1a32:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a34:	0ff00793          	li	a5,255
    1a38:	00c7cc63          	blt	a5,a2,1a50 <out_unlocked.constprop.0+0x3e>
    1a3c:	47a9                	li	a5,10
    1a3e:	06f70c63          	beq	a4,a5,1ab6 <out_unlocked.constprop.0+0xa4>
    1a42:	4601                	li	a2,0
}
    1a44:	60e2                	ld	ra,24(sp)
    1a46:	6442                	ld	s0,16(sp)
    1a48:	64a2                	ld	s1,8(sp)
    1a4a:	8532                	mv	a0,a2
    1a4c:	6105                	addi	sp,sp,32
    1a4e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a50:	10000793          	li	a5,256
    1a54:	02f61563          	bne	a2,a5,1a7e <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a58:	00001597          	auipc	a1,0x1
    1a5c:	2f058593          	addi	a1,a1,752 # 2d48 <buffer>
    1a60:	4505                	li	a0,1
    1a62:	441000ef          	jal	ra,26a2 <write>
}
    1a66:	60e2                	ld	ra,24(sp)
    1a68:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a6a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a6e:	00001797          	auipc	a5,0x1
    1a72:	2c07a923          	sw	zero,722(a5) # 2d40 <buffer_len>
}
    1a76:	64a2                	ld	s1,8(sp)
    1a78:	8532                	mv	a0,a2
    1a7a:	6105                	addi	sp,sp,32
    1a7c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a7e:	42f000ef          	jal	ra,26ac <getpid>
    1a82:	842a                	mv	s0,a0
    1a84:	00001517          	auipc	a0,0x1
    1a88:	08c50513          	addi	a0,a0,140 # 2b10 <enable_deadlock_detect+0x196>
    1a8c:	2f7000ef          	jal	ra,2582 <basename>
    1a90:	872a                	mv	a4,a0
    1a92:	00001617          	auipc	a2,0x1
    1a96:	f6660613          	addi	a2,a2,-154 # 29f8 <enable_deadlock_detect+0x7e>
    1a9a:	05400793          	li	a5,84
    1a9e:	86a2                	mv	a3,s0
    1aa0:	45fd                	li	a1,31
    1aa2:	00001517          	auipc	a0,0x1
    1aa6:	0ae50513          	addi	a0,a0,174 # 2b50 <enable_deadlock_detect+0x1d6>
    1aaa:	9d1ff0ef          	jal	ra,147a <printf>
    1aae:	557d                	li	a0,-1
    1ab0:	42d000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    1ab4:	4090                	lw	a2,0(s1)
    1ab6:	d659                	beqz	a2,1a44 <out_unlocked.constprop.0+0x32>
    1ab8:	b745                	j	1a58 <out_unlocked.constprop.0+0x46>

0000000000001aba <putchar>:
{
    1aba:	7139                	addi	sp,sp,-64
    1abc:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1abe:	00001497          	auipc	s1,0x1
    1ac2:	28248493          	addi	s1,s1,642 # 2d40 <buffer_len>
    1ac6:	1084a703          	lw	a4,264(s1)
{
    1aca:	f822                	sd	s0,48(sp)
	char byte = c;
    1acc:	0ff57413          	zext.b	s0,a0
{
    1ad0:	fc06                	sd	ra,56(sp)
	char byte = c;
    1ad2:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1ad6:	4785                	li	a5,1
    1ad8:	00f70d63          	beq	a4,a5,1af2 <putchar+0x38>
		len = out_unlocked(s, l);
    1adc:	01f10513          	addi	a0,sp,31
    1ae0:	f33ff0ef          	jal	ra,1a12 <out_unlocked.constprop.0>
}
    1ae4:	70e2                	ld	ra,56(sp)
    1ae6:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1ae8:	862a                	mv	a2,a0
}
    1aea:	74a2                	ld	s1,40(sp)
    1aec:	8532                	mv	a0,a2
    1aee:	6121                	addi	sp,sp,64
    1af0:	8082                	ret
		mutex_lock(buffer_lock);
    1af2:	10c4a503          	lw	a0,268(s1)
    1af6:	625000ef          	jal	ra,291a <mutex_lock>
		buffer[buffer_len++] = c;
    1afa:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1afc:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b00:	0017861b          	addiw	a2,a5,1
    1b04:	97a6                	add	a5,a5,s1
    1b06:	c090                	sw	a2,0(s1)
    1b08:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b0c:	02c6c263          	blt	a3,a2,1b30 <putchar+0x76>
    1b10:	47a9                	li	a5,10
    1b12:	06f40d63          	beq	s0,a5,1b8c <putchar+0xd2>
    1b16:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b18:	10c4a503          	lw	a0,268(s1)
    1b1c:	e432                	sd	a2,8(sp)
    1b1e:	609000ef          	jal	ra,2926 <mutex_unlock>
    1b22:	6622                	ld	a2,8(sp)
}
    1b24:	70e2                	ld	ra,56(sp)
    1b26:	7442                	ld	s0,48(sp)
    1b28:	74a2                	ld	s1,40(sp)
    1b2a:	8532                	mv	a0,a2
    1b2c:	6121                	addi	sp,sp,64
    1b2e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b30:	10000793          	li	a5,256
    1b34:	02f61063          	bne	a2,a5,1b54 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b38:	00001597          	auipc	a1,0x1
    1b3c:	21058593          	addi	a1,a1,528 # 2d48 <buffer>
    1b40:	4505                	li	a0,1
    1b42:	361000ef          	jal	ra,26a2 <write>
    1b46:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b4a:	00001797          	auipc	a5,0x1
    1b4e:	1e07ab23          	sw	zero,502(a5) # 2d40 <buffer_len>
			if (r < 0) {
    1b52:	b7d9                	j	1b18 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b54:	359000ef          	jal	ra,26ac <getpid>
    1b58:	842a                	mv	s0,a0
    1b5a:	00001517          	auipc	a0,0x1
    1b5e:	fb650513          	addi	a0,a0,-74 # 2b10 <enable_deadlock_detect+0x196>
    1b62:	221000ef          	jal	ra,2582 <basename>
    1b66:	872a                	mv	a4,a0
    1b68:	00001617          	auipc	a2,0x1
    1b6c:	e9060613          	addi	a2,a2,-368 # 29f8 <enable_deadlock_detect+0x7e>
    1b70:	05400793          	li	a5,84
    1b74:	86a2                	mv	a3,s0
    1b76:	45fd                	li	a1,31
    1b78:	00001517          	auipc	a0,0x1
    1b7c:	fd850513          	addi	a0,a0,-40 # 2b50 <enable_deadlock_detect+0x1d6>
    1b80:	8fbff0ef          	jal	ra,147a <printf>
    1b84:	557d                	li	a0,-1
    1b86:	357000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    1b8a:	4090                	lw	a2,0(s1)
    1b8c:	d651                	beqz	a2,1b18 <putchar+0x5e>
    1b8e:	b76d                	j	1b38 <putchar+0x7e>

0000000000001b90 <puts>:
{
    1b90:	7139                	addi	sp,sp,-64
    1b92:	f822                	sd	s0,48(sp)
    1b94:	f426                	sd	s1,40(sp)
    1b96:	fc06                	sd	ra,56(sp)
    1b98:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1b9a:	00001417          	auipc	s0,0x1
    1b9e:	1a640413          	addi	s0,s0,422 # 2d40 <buffer_len>
{
    1ba2:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ba4:	638000ef          	jal	ra,21dc <strlen>
	if (buffer_lock_enabled == 1) {
    1ba8:	10842703          	lw	a4,264(s0)
    1bac:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bae:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bb0:	04f70563          	beq	a4,a5,1bfa <puts+0x6a>
		len = out_unlocked(s, l);
    1bb4:	8526                	mv	a0,s1
    1bb6:	d51ff0ef          	jal	ra,1906 <out_unlocked>
    1bba:	892a                	mv	s2,a0
    1bbc:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bbe:	00095963          	bgez	s2,1bd0 <puts+0x40>
}
    1bc2:	70e2                	ld	ra,56(sp)
    1bc4:	7442                	ld	s0,48(sp)
    1bc6:	7902                	ld	s2,32(sp)
    1bc8:	8526                	mv	a0,s1
    1bca:	74a2                	ld	s1,40(sp)
    1bcc:	6121                	addi	sp,sp,64
    1bce:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1bd0:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bd4:	44a9                	li	s1,10
    1bd6:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bda:	4785                	li	a5,1
    1bdc:	02f70e63          	beq	a4,a5,1c18 <puts+0x88>
		len = out_unlocked(s, l);
    1be0:	01f10513          	addi	a0,sp,31
    1be4:	e2fff0ef          	jal	ra,1a12 <out_unlocked.constprop.0>
}
    1be8:	70e2                	ld	ra,56(sp)
    1bea:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bec:	41f5549b          	sraiw	s1,a0,0x1f
}
    1bf0:	7902                	ld	s2,32(sp)
    1bf2:	8526                	mv	a0,s1
    1bf4:	74a2                	ld	s1,40(sp)
    1bf6:	6121                	addi	sp,sp,64
    1bf8:	8082                	ret
		mutex_lock(buffer_lock);
    1bfa:	e42a                	sd	a0,8(sp)
    1bfc:	10c42503          	lw	a0,268(s0)
    1c00:	51b000ef          	jal	ra,291a <mutex_lock>
		len = out_unlocked(s, l);
    1c04:	65a2                	ld	a1,8(sp)
    1c06:	8526                	mv	a0,s1
    1c08:	cffff0ef          	jal	ra,1906 <out_unlocked>
    1c0c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c0e:	10c42503          	lw	a0,268(s0)
    1c12:	515000ef          	jal	ra,2926 <mutex_unlock>
    1c16:	b75d                	j	1bbc <puts+0x2c>
		mutex_lock(buffer_lock);
    1c18:	10c42503          	lw	a0,268(s0)
    1c1c:	4ff000ef          	jal	ra,291a <mutex_lock>
		buffer[buffer_len++] = c;
    1c20:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c22:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c26:	0017861b          	addiw	a2,a5,1
    1c2a:	97a2                	add	a5,a5,s0
    1c2c:	c010                	sw	a2,0(s0)
    1c2e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c32:	06c6dc63          	bge	a3,a2,1caa <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c36:	10000793          	li	a5,256
    1c3a:	02f61c63          	bne	a2,a5,1c72 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c3e:	00001597          	auipc	a1,0x1
    1c42:	10a58593          	addi	a1,a1,266 # 2d48 <buffer>
    1c46:	4505                	li	a0,1
    1c48:	25b000ef          	jal	ra,26a2 <write>
			if (r < 0) {
    1c4c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c4e:	00001797          	auipc	a5,0x1
    1c52:	0e07a923          	sw	zero,242(a5) # 2d40 <buffer_len>
			if (r < 0) {
    1c56:	04054c63          	bltz	a0,1cae <puts+0x11e>
			if (r < buffer_len) {
    1c5a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c5c:	10c42503          	lw	a0,268(s0)
    1c60:	4c7000ef          	jal	ra,2926 <mutex_unlock>
}
    1c64:	70e2                	ld	ra,56(sp)
    1c66:	7442                	ld	s0,48(sp)
    1c68:	7902                	ld	s2,32(sp)
    1c6a:	8526                	mv	a0,s1
    1c6c:	74a2                	ld	s1,40(sp)
    1c6e:	6121                	addi	sp,sp,64
    1c70:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c72:	23b000ef          	jal	ra,26ac <getpid>
    1c76:	84aa                	mv	s1,a0
    1c78:	00001517          	auipc	a0,0x1
    1c7c:	e9850513          	addi	a0,a0,-360 # 2b10 <enable_deadlock_detect+0x196>
    1c80:	103000ef          	jal	ra,2582 <basename>
    1c84:	872a                	mv	a4,a0
    1c86:	00001617          	auipc	a2,0x1
    1c8a:	d7260613          	addi	a2,a2,-654 # 29f8 <enable_deadlock_detect+0x7e>
    1c8e:	05400793          	li	a5,84
    1c92:	86a6                	mv	a3,s1
    1c94:	45fd                	li	a1,31
    1c96:	00001517          	auipc	a0,0x1
    1c9a:	eba50513          	addi	a0,a0,-326 # 2b50 <enable_deadlock_detect+0x1d6>
    1c9e:	fdcff0ef          	jal	ra,147a <printf>
    1ca2:	557d                	li	a0,-1
    1ca4:	239000ef          	jal	ra,26dc <exit>
	if (buffer_len == 0)
    1ca8:	4010                	lw	a2,0(s0)
    1caa:	da45                	beqz	a2,1c5a <puts+0xca>
    1cac:	bf49                	j	1c3e <puts+0xae>
    1cae:	54fd                	li	s1,-1
    1cb0:	b775                	j	1c5c <puts+0xcc>

0000000000001cb2 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cb2:	715d                	addi	sp,sp,-80
    1cb4:	e486                	sd	ra,72(sp)
    1cb6:	e0a2                	sd	s0,64(sp)
    1cb8:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1cba:	14054363          	bltz	a0,1e00 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1cbe:	02b577bb          	remuw	a5,a0,a1
    1cc2:	00001617          	auipc	a2,0x1
    1cc6:	22e60613          	addi	a2,a2,558 # 2ef0 <digits>
	buf[16] = 0;
    1cca:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1cce:	0005871b          	sext.w	a4,a1
    1cd2:	1782                	slli	a5,a5,0x20
    1cd4:	9381                	srli	a5,a5,0x20
    1cd6:	97b2                	add	a5,a5,a2
    1cd8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cdc:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ce0:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1ce4:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1ce6:	0eb56763          	bltu	a0,a1,1dd4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1cea:	02e877bb          	remuw	a5,a6,a4
    1cee:	1782                	slli	a5,a5,0x20
    1cf0:	9381                	srli	a5,a5,0x20
    1cf2:	97b2                	add	a5,a5,a2
    1cf4:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cf8:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1cfc:	02f10323          	sb	a5,38(sp)
    1d00:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d02:	0ce86963          	bltu	a6,a4,1dd4 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d06:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d0a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d0e:	1582                	slli	a1,a1,0x20
    1d10:	9181                	srli	a1,a1,0x20
    1d12:	95b2                	add	a1,a1,a2
    1d14:	0005c583          	lbu	a1,0(a1)
    1d18:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d1c:	0007859b          	sext.w	a1,a5
    1d20:	16e6e563          	bltu	a3,a4,1e8a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d24:	02e7f6bb          	remuw	a3,a5,a4
    1d28:	1682                	slli	a3,a3,0x20
    1d2a:	9281                	srli	a3,a3,0x20
    1d2c:	96b2                	add	a3,a3,a2
    1d2e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d32:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d36:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d3a:	16e5e163          	bltu	a1,a4,1e9c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d3e:	02e876bb          	remuw	a3,a6,a4
    1d42:	1682                	slli	a3,a3,0x20
    1d44:	9281                	srli	a3,a3,0x20
    1d46:	96b2                	add	a3,a3,a2
    1d48:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d4c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d50:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d54:	14e86d63          	bltu	a6,a4,1eae <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d58:	02e5f6bb          	remuw	a3,a1,a4
    1d5c:	1682                	slli	a3,a3,0x20
    1d5e:	9281                	srli	a3,a3,0x20
    1d60:	96b2                	add	a3,a3,a2
    1d62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d66:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d6a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d6e:	10e5e563          	bltu	a1,a4,1e78 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d72:	02e876bb          	remuw	a3,a6,a4
    1d76:	1682                	slli	a3,a3,0x20
    1d78:	9281                	srli	a3,a3,0x20
    1d7a:	96b2                	add	a3,a3,a2
    1d7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d80:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d84:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1d88:	14e86263          	bltu	a6,a4,1ecc <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1d8c:	02e5f6bb          	remuw	a3,a1,a4
    1d90:	1682                	slli	a3,a3,0x20
    1d92:	9281                	srli	a3,a3,0x20
    1d94:	96b2                	add	a3,a3,a2
    1d96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d9a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d9e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1da2:	14e5e463          	bltu	a1,a4,1eea <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1da6:	02e876bb          	remuw	a3,a6,a4
    1daa:	1682                	slli	a3,a3,0x20
    1dac:	9281                	srli	a3,a3,0x20
    1dae:	96b2                	add	a3,a3,a2
    1db0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1db4:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1db8:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1dbc:	14e86063          	bltu	a6,a4,1efc <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1dc0:	1782                	slli	a5,a5,0x20
    1dc2:	9381                	srli	a5,a5,0x20
    1dc4:	97b2                	add	a5,a5,a2
    1dc6:	0007c703          	lbu	a4,0(a5)
    1dca:	4799                	li	a5,6
    1dcc:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1dd0:	10054763          	bltz	a0,1ede <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1dd4:	00001497          	auipc	s1,0x1
    1dd8:	f6c48493          	addi	s1,s1,-148 # 2d40 <buffer_len>
    1ddc:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1de0:	0828                	addi	a0,sp,24
    1de2:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1de4:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1de6:	00f50433          	add	s0,a0,a5
    1dea:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1dec:	06e68463          	beq	a3,a4,1e54 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1df0:	8522                	mv	a0,s0
    1df2:	b15ff0ef          	jal	ra,1906 <out_unlocked>
}
    1df6:	60a6                	ld	ra,72(sp)
    1df8:	6406                	ld	s0,64(sp)
    1dfa:	74e2                	ld	s1,56(sp)
    1dfc:	6161                	addi	sp,sp,80
    1dfe:	8082                	ret
		x = -xx;
    1e00:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e04:	02b877bb          	remuw	a5,a6,a1
    1e08:	00001617          	auipc	a2,0x1
    1e0c:	0e860613          	addi	a2,a2,232 # 2ef0 <digits>
	buf[16] = 0;
    1e10:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e14:	0005871b          	sext.w	a4,a1
    1e18:	1782                	slli	a5,a5,0x20
    1e1a:	9381                	srli	a5,a5,0x20
    1e1c:	97b2                	add	a5,a5,a2
    1e1e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e22:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e26:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e2a:	08b86b63          	bltu	a6,a1,1ec0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e2e:	02e8f7bb          	remuw	a5,a7,a4
    1e32:	1782                	slli	a5,a5,0x20
    1e34:	9381                	srli	a5,a5,0x20
    1e36:	97b2                	add	a5,a5,a2
    1e38:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e3c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e40:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e44:	ece8f1e3          	bgeu	a7,a4,1d06 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e48:	02d00793          	li	a5,45
    1e4c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e50:	47b5                	li	a5,13
    1e52:	b749                	j	1dd4 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e54:	10c4a503          	lw	a0,268(s1)
    1e58:	e42e                	sd	a1,8(sp)
    1e5a:	2c1000ef          	jal	ra,291a <mutex_lock>
		len = out_unlocked(s, l);
    1e5e:	65a2                	ld	a1,8(sp)
    1e60:	8522                	mv	a0,s0
    1e62:	aa5ff0ef          	jal	ra,1906 <out_unlocked>
		mutex_unlock(buffer_lock);
    1e66:	10c4a503          	lw	a0,268(s1)
    1e6a:	2bd000ef          	jal	ra,2926 <mutex_unlock>
}
    1e6e:	60a6                	ld	ra,72(sp)
    1e70:	6406                	ld	s0,64(sp)
    1e72:	74e2                	ld	s1,56(sp)
    1e74:	6161                	addi	sp,sp,80
    1e76:	8082                	ret
		buf[i--] = digits[x % base];
    1e78:	47a9                	li	a5,10
	if (sign)
    1e7a:	f4055de3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e7e:	02d00793          	li	a5,45
    1e82:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e86:	47a5                	li	a5,9
    1e88:	b7b1                	j	1dd4 <printint.constprop.0+0x122>
    1e8a:	47b5                	li	a5,13
	if (sign)
    1e8c:	f40554e3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e90:	02d00793          	li	a5,45
    1e94:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1e98:	47b1                	li	a5,12
    1e9a:	bf2d                	j	1dd4 <printint.constprop.0+0x122>
    1e9c:	47b1                	li	a5,12
	if (sign)
    1e9e:	f2055be3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea2:	02d00793          	li	a5,45
    1ea6:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1eaa:	47ad                	li	a5,11
    1eac:	b725                	j	1dd4 <printint.constprop.0+0x122>
    1eae:	47ad                	li	a5,11
	if (sign)
    1eb0:	f20552e3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eb4:	02d00793          	li	a5,45
    1eb8:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ebc:	47a9                	li	a5,10
    1ebe:	bf19                	j	1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ec0:	02d00793          	li	a5,45
    1ec4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ec8:	47b9                	li	a5,14
    1eca:	b729                	j	1dd4 <printint.constprop.0+0x122>
    1ecc:	47a5                	li	a5,9
	if (sign)
    1ece:	f00553e3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed2:	02d00793          	li	a5,45
    1ed6:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1eda:	47a1                	li	a5,8
    1edc:	bde5                	j	1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ede:	02d00793          	li	a5,45
    1ee2:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ee6:	4795                	li	a5,5
    1ee8:	b5f5                	j	1dd4 <printint.constprop.0+0x122>
    1eea:	47a1                	li	a5,8
	if (sign)
    1eec:	ee0554e3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef0:	02d00793          	li	a5,45
    1ef4:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1ef8:	479d                	li	a5,7
    1efa:	bde9                	j	1dd4 <printint.constprop.0+0x122>
    1efc:	479d                	li	a5,7
	if (sign)
    1efe:	ec055be3          	bgez	a0,1dd4 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f02:	02d00793          	li	a5,45
    1f06:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f0a:	4799                	li	a5,6
    1f0c:	b5e1                	j	1dd4 <printint.constprop.0+0x122>

0000000000001f0e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f0e:	02000793          	li	a5,32
    1f12:	00f50663          	beq	a0,a5,1f1e <isspace+0x10>
    1f16:	355d                	addiw	a0,a0,-9
    1f18:	00553513          	sltiu	a0,a0,5
    1f1c:	8082                	ret
    1f1e:	4505                	li	a0,1
}
    1f20:	8082                	ret

0000000000001f22 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f22:	fd05051b          	addiw	a0,a0,-48
}
    1f26:	00a53513          	sltiu	a0,a0,10
    1f2a:	8082                	ret

0000000000001f2c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f2c:	02000613          	li	a2,32
    1f30:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f32:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f36:	ff77869b          	addiw	a3,a5,-9
    1f3a:	04c78c63          	beq	a5,a2,1f92 <atoi+0x66>
    1f3e:	0007871b          	sext.w	a4,a5
    1f42:	04d5f863          	bgeu	a1,a3,1f92 <atoi+0x66>
		s++;
	switch (*s) {
    1f46:	02b00693          	li	a3,43
    1f4a:	04d78963          	beq	a5,a3,1f9c <atoi+0x70>
    1f4e:	02d00693          	li	a3,45
    1f52:	06d78263          	beq	a5,a3,1fb6 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f56:	fd07061b          	addiw	a2,a4,-48
    1f5a:	47a5                	li	a5,9
    1f5c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f5e:	4e01                	li	t3,0
	while (isdigit(*s))
    1f60:	04c7e963          	bltu	a5,a2,1fb2 <atoi+0x86>
	int n = 0, neg = 0;
    1f64:	4501                	li	a0,0
	while (isdigit(*s))
    1f66:	4825                	li	a6,9
    1f68:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f6c:	0025179b          	slliw	a5,a0,0x2
    1f70:	9fa9                	addw	a5,a5,a0
    1f72:	fd07031b          	addiw	t1,a4,-48
    1f76:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f7a:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f7e:	0685                	addi	a3,a3,1
    1f80:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f84:	0006071b          	sext.w	a4,a2
    1f88:	feb870e3          	bgeu	a6,a1,1f68 <atoi+0x3c>
	return neg ? n : -n;
    1f8c:	000e0563          	beqz	t3,1f96 <atoi+0x6a>
}
    1f90:	8082                	ret
		s++;
    1f92:	0505                	addi	a0,a0,1
    1f94:	bf79                	j	1f32 <atoi+0x6>
	return neg ? n : -n;
    1f96:	4113053b          	subw	a0,t1,a7
    1f9a:	8082                	ret
	while (isdigit(*s))
    1f9c:	00154703          	lbu	a4,1(a0)
    1fa0:	47a5                	li	a5,9
		s++;
    1fa2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fa6:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1faa:	4e01                	li	t3,0
	while (isdigit(*s))
    1fac:	2701                	sext.w	a4,a4
    1fae:	fac7fbe3          	bgeu	a5,a2,1f64 <atoi+0x38>
    1fb2:	4501                	li	a0,0
}
    1fb4:	8082                	ret
	while (isdigit(*s))
    1fb6:	00154703          	lbu	a4,1(a0)
    1fba:	47a5                	li	a5,9
		s++;
    1fbc:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fc0:	fd07061b          	addiw	a2,a4,-48
    1fc4:	2701                	sext.w	a4,a4
    1fc6:	fec7e6e3          	bltu	a5,a2,1fb2 <atoi+0x86>
		neg = 1;
    1fca:	4e05                	li	t3,1
    1fcc:	bf61                	j	1f64 <atoi+0x38>

0000000000001fce <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fce:	16060d63          	beqz	a2,2148 <memset+0x17a>
    1fd2:	40a007b3          	neg	a5,a0
    1fd6:	8b9d                	andi	a5,a5,7
    1fd8:	00778693          	addi	a3,a5,7
    1fdc:	482d                	li	a6,11
    1fde:	0ff5f713          	zext.b	a4,a1
    1fe2:	fff60593          	addi	a1,a2,-1
    1fe6:	1706e263          	bltu	a3,a6,214a <memset+0x17c>
    1fea:	16d5ea63          	bltu	a1,a3,215e <memset+0x190>
    1fee:	16078563          	beqz	a5,2158 <memset+0x18a>
    1ff2:	00e50023          	sb	a4,0(a0)
    1ff6:	4685                	li	a3,1
    1ff8:	00150593          	addi	a1,a0,1
    1ffc:	14d78c63          	beq	a5,a3,2154 <memset+0x186>
    2000:	00e500a3          	sb	a4,1(a0)
    2004:	4689                	li	a3,2
    2006:	00250593          	addi	a1,a0,2
    200a:	14d78d63          	beq	a5,a3,2164 <memset+0x196>
    200e:	00e50123          	sb	a4,2(a0)
    2012:	468d                	li	a3,3
    2014:	00350593          	addi	a1,a0,3
    2018:	12d78b63          	beq	a5,a3,214e <memset+0x180>
    201c:	00e501a3          	sb	a4,3(a0)
    2020:	4691                	li	a3,4
    2022:	00450593          	addi	a1,a0,4
    2026:	14d78163          	beq	a5,a3,2168 <memset+0x19a>
    202a:	00e50223          	sb	a4,4(a0)
    202e:	4695                	li	a3,5
    2030:	00550593          	addi	a1,a0,5
    2034:	12d78c63          	beq	a5,a3,216c <memset+0x19e>
    2038:	00e502a3          	sb	a4,5(a0)
    203c:	469d                	li	a3,7
    203e:	00650593          	addi	a1,a0,6
    2042:	12d79763          	bne	a5,a3,2170 <memset+0x1a2>
    2046:	00750593          	addi	a1,a0,7
    204a:	00e50323          	sb	a4,6(a0)
    204e:	481d                	li	a6,7
    2050:	00871693          	slli	a3,a4,0x8
    2054:	01071893          	slli	a7,a4,0x10
    2058:	8ed9                	or	a3,a3,a4
    205a:	01871313          	slli	t1,a4,0x18
    205e:	0116e6b3          	or	a3,a3,a7
    2062:	0066e6b3          	or	a3,a3,t1
    2066:	02071893          	slli	a7,a4,0x20
    206a:	02871e13          	slli	t3,a4,0x28
    206e:	0116e6b3          	or	a3,a3,a7
    2072:	40f60333          	sub	t1,a2,a5
    2076:	03071893          	slli	a7,a4,0x30
    207a:	01c6e6b3          	or	a3,a3,t3
    207e:	0116e6b3          	or	a3,a3,a7
    2082:	03871e13          	slli	t3,a4,0x38
    2086:	97aa                	add	a5,a5,a0
    2088:	ff837893          	andi	a7,t1,-8
    208c:	01c6e6b3          	or	a3,a3,t3
    2090:	98be                	add	a7,a7,a5
    2092:	e394                	sd	a3,0(a5)
    2094:	07a1                	addi	a5,a5,8
    2096:	ff179ee3          	bne	a5,a7,2092 <memset+0xc4>
    209a:	ff837893          	andi	a7,t1,-8
    209e:	011587b3          	add	a5,a1,a7
    20a2:	010886bb          	addw	a3,a7,a6
    20a6:	0b130663          	beq	t1,a7,2152 <memset+0x184>
    20aa:	00e78023          	sb	a4,0(a5)
    20ae:	0016859b          	addiw	a1,a3,1
    20b2:	08c5fb63          	bgeu	a1,a2,2148 <memset+0x17a>
    20b6:	00e780a3          	sb	a4,1(a5)
    20ba:	0026859b          	addiw	a1,a3,2
    20be:	08c5f563          	bgeu	a1,a2,2148 <memset+0x17a>
    20c2:	00e78123          	sb	a4,2(a5)
    20c6:	0036859b          	addiw	a1,a3,3
    20ca:	06c5ff63          	bgeu	a1,a2,2148 <memset+0x17a>
    20ce:	00e781a3          	sb	a4,3(a5)
    20d2:	0046859b          	addiw	a1,a3,4
    20d6:	06c5f963          	bgeu	a1,a2,2148 <memset+0x17a>
    20da:	00e78223          	sb	a4,4(a5)
    20de:	0056859b          	addiw	a1,a3,5
    20e2:	06c5f363          	bgeu	a1,a2,2148 <memset+0x17a>
    20e6:	00e782a3          	sb	a4,5(a5)
    20ea:	0066859b          	addiw	a1,a3,6
    20ee:	04c5fd63          	bgeu	a1,a2,2148 <memset+0x17a>
    20f2:	00e78323          	sb	a4,6(a5)
    20f6:	0076859b          	addiw	a1,a3,7
    20fa:	04c5f763          	bgeu	a1,a2,2148 <memset+0x17a>
    20fe:	00e783a3          	sb	a4,7(a5)
    2102:	0086859b          	addiw	a1,a3,8
    2106:	04c5f163          	bgeu	a1,a2,2148 <memset+0x17a>
    210a:	00e78423          	sb	a4,8(a5)
    210e:	0096859b          	addiw	a1,a3,9
    2112:	02c5fb63          	bgeu	a1,a2,2148 <memset+0x17a>
    2116:	00e784a3          	sb	a4,9(a5)
    211a:	00a6859b          	addiw	a1,a3,10
    211e:	02c5f563          	bgeu	a1,a2,2148 <memset+0x17a>
    2122:	00e78523          	sb	a4,10(a5)
    2126:	00b6859b          	addiw	a1,a3,11
    212a:	00c5ff63          	bgeu	a1,a2,2148 <memset+0x17a>
    212e:	00e785a3          	sb	a4,11(a5)
    2132:	00c6859b          	addiw	a1,a3,12
    2136:	00c5f963          	bgeu	a1,a2,2148 <memset+0x17a>
    213a:	00e78623          	sb	a4,12(a5)
    213e:	26b5                	addiw	a3,a3,13
    2140:	00c6f463          	bgeu	a3,a2,2148 <memset+0x17a>
    2144:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2148:	8082                	ret
    214a:	46ad                	li	a3,11
    214c:	bd79                	j	1fea <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    214e:	480d                	li	a6,3
    2150:	b701                	j	2050 <memset+0x82>
    2152:	8082                	ret
    2154:	4805                	li	a6,1
    2156:	bded                	j	2050 <memset+0x82>
    2158:	85aa                	mv	a1,a0
    215a:	4801                	li	a6,0
    215c:	bdd5                	j	2050 <memset+0x82>
    215e:	87aa                	mv	a5,a0
    2160:	4681                	li	a3,0
    2162:	b7a1                	j	20aa <memset+0xdc>
    2164:	4809                	li	a6,2
    2166:	b5ed                	j	2050 <memset+0x82>
    2168:	4811                	li	a6,4
    216a:	b5dd                	j	2050 <memset+0x82>
    216c:	4815                	li	a6,5
    216e:	b5cd                	j	2050 <memset+0x82>
    2170:	4819                	li	a6,6
    2172:	bdf9                	j	2050 <memset+0x82>

0000000000002174 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    2174:	00054783          	lbu	a5,0(a0)
    2178:	0005c703          	lbu	a4,0(a1)
    217c:	00e79863          	bne	a5,a4,218c <strcmp+0x18>
    2180:	0505                	addi	a0,a0,1
    2182:	0585                	addi	a1,a1,1
    2184:	fbe5                	bnez	a5,2174 <strcmp>
    2186:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    2188:	9d19                	subw	a0,a0,a4
    218a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    218c:	0007851b          	sext.w	a0,a5
    2190:	bfe5                	j	2188 <strcmp+0x14>

0000000000002192 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    2192:	ca15                	beqz	a2,21c6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    2194:	00054783          	lbu	a5,0(a0)
	if (!n--)
    2198:	167d                	addi	a2,a2,-1
    219a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    219e:	eb99                	bnez	a5,21b4 <strncmp+0x22>
    21a0:	a815                	j	21d4 <strncmp+0x42>
    21a2:	00a68e63          	beq	a3,a0,21be <strncmp+0x2c>
    21a6:	0505                	addi	a0,a0,1
    21a8:	00f71b63          	bne	a4,a5,21be <strncmp+0x2c>
    21ac:	00054783          	lbu	a5,0(a0)
    21b0:	cf89                	beqz	a5,21ca <strncmp+0x38>
    21b2:	85b2                	mv	a1,a2
    21b4:	0005c703          	lbu	a4,0(a1)
    21b8:	00158613          	addi	a2,a1,1
    21bc:	f37d                	bnez	a4,21a2 <strncmp+0x10>
		;
	return *l - *r;
    21be:	0007851b          	sext.w	a0,a5
    21c2:	9d19                	subw	a0,a0,a4
    21c4:	8082                	ret
		return 0;
    21c6:	4501                	li	a0,0
}
    21c8:	8082                	ret
	return *l - *r;
    21ca:	0015c703          	lbu	a4,1(a1)
    21ce:	4501                	li	a0,0
    21d0:	9d19                	subw	a0,a0,a4
    21d2:	8082                	ret
    21d4:	0005c703          	lbu	a4,0(a1)
    21d8:	4501                	li	a0,0
    21da:	b7e5                	j	21c2 <strncmp+0x30>

00000000000021dc <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21dc:	00757793          	andi	a5,a0,7
    21e0:	cf89                	beqz	a5,21fa <strlen+0x1e>
    21e2:	87aa                	mv	a5,a0
    21e4:	a029                	j	21ee <strlen+0x12>
    21e6:	0785                	addi	a5,a5,1
    21e8:	0077f713          	andi	a4,a5,7
    21ec:	cb01                	beqz	a4,21fc <strlen+0x20>
		if (!*s)
    21ee:	0007c703          	lbu	a4,0(a5)
    21f2:	fb75                	bnez	a4,21e6 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    21f4:	40a78533          	sub	a0,a5,a0
}
    21f8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    21fa:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    21fc:	6394                	ld	a3,0(a5)
    21fe:	00001597          	auipc	a1,0x1
    2202:	9ea5b583          	ld	a1,-1558(a1) # 2be8 <enable_deadlock_detect+0x26e>
    2206:	00001617          	auipc	a2,0x1
    220a:	9ea63603          	ld	a2,-1558(a2) # 2bf0 <enable_deadlock_detect+0x276>
    220e:	a019                	j	2214 <strlen+0x38>
    2210:	6794                	ld	a3,8(a5)
    2212:	07a1                	addi	a5,a5,8
    2214:	00b68733          	add	a4,a3,a1
    2218:	fff6c693          	not	a3,a3
    221c:	8f75                	and	a4,a4,a3
    221e:	8f71                	and	a4,a4,a2
    2220:	db65                	beqz	a4,2210 <strlen+0x34>
	for (; *s; s++)
    2222:	0007c703          	lbu	a4,0(a5)
    2226:	d779                	beqz	a4,21f4 <strlen+0x18>
    2228:	0017c703          	lbu	a4,1(a5)
    222c:	0785                	addi	a5,a5,1
    222e:	d379                	beqz	a4,21f4 <strlen+0x18>
    2230:	0017c703          	lbu	a4,1(a5)
    2234:	0785                	addi	a5,a5,1
    2236:	fb6d                	bnez	a4,2228 <strlen+0x4c>
    2238:	bf75                	j	21f4 <strlen+0x18>

000000000000223a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    223a:	00757713          	andi	a4,a0,7
{
    223e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2240:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2244:	cb19                	beqz	a4,225a <memchr+0x20>
    2246:	ce25                	beqz	a2,22be <memchr+0x84>
    2248:	0007c703          	lbu	a4,0(a5)
    224c:	04b70e63          	beq	a4,a1,22a8 <memchr+0x6e>
    2250:	0785                	addi	a5,a5,1
    2252:	0077f713          	andi	a4,a5,7
    2256:	167d                	addi	a2,a2,-1
    2258:	f77d                	bnez	a4,2246 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    225a:	4501                	li	a0,0
	if (n && *s != c) {
    225c:	c235                	beqz	a2,22c0 <memchr+0x86>
    225e:	0007c703          	lbu	a4,0(a5)
    2262:	04b70363          	beq	a4,a1,22a8 <memchr+0x6e>
		size_t k = ONES * c;
    2266:	00001517          	auipc	a0,0x1
    226a:	99253503          	ld	a0,-1646(a0) # 2bf8 <enable_deadlock_detect+0x27e>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    226e:	471d                	li	a4,7
		size_t k = ONES * c;
    2270:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2274:	02c77a63          	bgeu	a4,a2,22a8 <memchr+0x6e>
    2278:	00001897          	auipc	a7,0x1
    227c:	9708b883          	ld	a7,-1680(a7) # 2be8 <enable_deadlock_detect+0x26e>
    2280:	00001817          	auipc	a6,0x1
    2284:	97083803          	ld	a6,-1680(a6) # 2bf0 <enable_deadlock_detect+0x276>
    2288:	431d                	li	t1,7
    228a:	a029                	j	2294 <memchr+0x5a>
		     w++, n -= SS)
    228c:	1661                	addi	a2,a2,-8
    228e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2290:	02c37963          	bgeu	t1,a2,22c2 <memchr+0x88>
    2294:	6398                	ld	a4,0(a5)
    2296:	8f29                	xor	a4,a4,a0
    2298:	011706b3          	add	a3,a4,a7
    229c:	fff74713          	not	a4,a4
    22a0:	8f75                	and	a4,a4,a3
    22a2:	01077733          	and	a4,a4,a6
    22a6:	d37d                	beqz	a4,228c <memchr+0x52>
{
    22a8:	853e                	mv	a0,a5
    22aa:	97b2                	add	a5,a5,a2
    22ac:	a021                	j	22b4 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22ae:	0505                	addi	a0,a0,1
    22b0:	00f50763          	beq	a0,a5,22be <memchr+0x84>
    22b4:	00054703          	lbu	a4,0(a0)
    22b8:	feb71be3          	bne	a4,a1,22ae <memchr+0x74>
    22bc:	8082                	ret
	return n ? (void *)s : 0;
    22be:	4501                	li	a0,0
}
    22c0:	8082                	ret
	return n ? (void *)s : 0;
    22c2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22c4:	f275                	bnez	a2,22a8 <memchr+0x6e>
}
    22c6:	8082                	ret

00000000000022c8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22c8:	1101                	addi	sp,sp,-32
    22ca:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22cc:	862e                	mv	a2,a1
{
    22ce:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22d0:	4581                	li	a1,0
{
    22d2:	e426                	sd	s1,8(sp)
    22d4:	ec06                	sd	ra,24(sp)
    22d6:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22d8:	f63ff0ef          	jal	ra,223a <memchr>
	return p ? p - s : n;
    22dc:	c519                	beqz	a0,22ea <strnlen+0x22>
}
    22de:	60e2                	ld	ra,24(sp)
    22e0:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22e2:	8d05                	sub	a0,a0,s1
}
    22e4:	64a2                	ld	s1,8(sp)
    22e6:	6105                	addi	sp,sp,32
    22e8:	8082                	ret
    22ea:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    22ec:	8522                	mv	a0,s0
}
    22ee:	6442                	ld	s0,16(sp)
    22f0:	64a2                	ld	s1,8(sp)
    22f2:	6105                	addi	sp,sp,32
    22f4:	8082                	ret

00000000000022f6 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    22f6:	00a5c7b3          	xor	a5,a1,a0
    22fa:	8b9d                	andi	a5,a5,7
    22fc:	eb95                	bnez	a5,2330 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    22fe:	0075f793          	andi	a5,a1,7
    2302:	e7b1                	bnez	a5,234e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2304:	6198                	ld	a4,0(a1)
    2306:	00001617          	auipc	a2,0x1
    230a:	8e263603          	ld	a2,-1822(a2) # 2be8 <enable_deadlock_detect+0x26e>
    230e:	00001817          	auipc	a6,0x1
    2312:	8e283803          	ld	a6,-1822(a6) # 2bf0 <enable_deadlock_detect+0x276>
    2316:	a029                	j	2320 <stpcpy+0x2a>
    2318:	05a1                	addi	a1,a1,8
    231a:	e118                	sd	a4,0(a0)
    231c:	6198                	ld	a4,0(a1)
    231e:	0521                	addi	a0,a0,8
    2320:	00c707b3          	add	a5,a4,a2
    2324:	fff74693          	not	a3,a4
    2328:	8ff5                	and	a5,a5,a3
    232a:	0107f7b3          	and	a5,a5,a6
    232e:	d7ed                	beqz	a5,2318 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2330:	0005c783          	lbu	a5,0(a1)
    2334:	00f50023          	sb	a5,0(a0)
    2338:	c785                	beqz	a5,2360 <stpcpy+0x6a>
    233a:	0015c783          	lbu	a5,1(a1)
    233e:	0505                	addi	a0,a0,1
    2340:	0585                	addi	a1,a1,1
    2342:	00f50023          	sb	a5,0(a0)
    2346:	fbf5                	bnez	a5,233a <stpcpy+0x44>
		;
	return d;
}
    2348:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    234a:	0505                	addi	a0,a0,1
    234c:	df45                	beqz	a4,2304 <stpcpy+0xe>
			if (!(*d = *s))
    234e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2352:	0585                	addi	a1,a1,1
    2354:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2358:	00f50023          	sb	a5,0(a0)
    235c:	f7fd                	bnez	a5,234a <stpcpy+0x54>
}
    235e:	8082                	ret
    2360:	8082                	ret

0000000000002362 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2362:	00a5c7b3          	xor	a5,a1,a0
    2366:	8b9d                	andi	a5,a5,7
    2368:	1a079863          	bnez	a5,2518 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    236c:	0075f793          	andi	a5,a1,7
    2370:	16078463          	beqz	a5,24d8 <stpncpy+0x176>
    2374:	ea01                	bnez	a2,2384 <stpncpy+0x22>
    2376:	a421                	j	257e <stpncpy+0x21c>
    2378:	167d                	addi	a2,a2,-1
    237a:	0505                	addi	a0,a0,1
    237c:	14070e63          	beqz	a4,24d8 <stpncpy+0x176>
    2380:	1a060863          	beqz	a2,2530 <stpncpy+0x1ce>
    2384:	0005c783          	lbu	a5,0(a1)
    2388:	0585                	addi	a1,a1,1
    238a:	0075f713          	andi	a4,a1,7
    238e:	00f50023          	sb	a5,0(a0)
    2392:	f3fd                	bnez	a5,2378 <stpncpy+0x16>
    2394:	4805                	li	a6,1
    2396:	1a061863          	bnez	a2,2546 <stpncpy+0x1e4>
    239a:	40a007b3          	neg	a5,a0
    239e:	8b9d                	andi	a5,a5,7
    23a0:	4681                	li	a3,0
    23a2:	18061a63          	bnez	a2,2536 <stpncpy+0x1d4>
    23a6:	00778713          	addi	a4,a5,7
    23aa:	45ad                	li	a1,11
    23ac:	18b76363          	bltu	a4,a1,2532 <stpncpy+0x1d0>
    23b0:	1ae6eb63          	bltu	a3,a4,2566 <stpncpy+0x204>
    23b4:	1a078363          	beqz	a5,255a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23b8:	00050023          	sb	zero,0(a0)
    23bc:	4685                	li	a3,1
    23be:	00150713          	addi	a4,a0,1
    23c2:	18d78f63          	beq	a5,a3,2560 <stpncpy+0x1fe>
    23c6:	000500a3          	sb	zero,1(a0)
    23ca:	4689                	li	a3,2
    23cc:	00250713          	addi	a4,a0,2
    23d0:	18d78e63          	beq	a5,a3,256c <stpncpy+0x20a>
    23d4:	00050123          	sb	zero,2(a0)
    23d8:	468d                	li	a3,3
    23da:	00350713          	addi	a4,a0,3
    23de:	16d78c63          	beq	a5,a3,2556 <stpncpy+0x1f4>
    23e2:	000501a3          	sb	zero,3(a0)
    23e6:	4691                	li	a3,4
    23e8:	00450713          	addi	a4,a0,4
    23ec:	18d78263          	beq	a5,a3,2570 <stpncpy+0x20e>
    23f0:	00050223          	sb	zero,4(a0)
    23f4:	4695                	li	a3,5
    23f6:	00550713          	addi	a4,a0,5
    23fa:	16d78d63          	beq	a5,a3,2574 <stpncpy+0x212>
    23fe:	000502a3          	sb	zero,5(a0)
    2402:	469d                	li	a3,7
    2404:	00650713          	addi	a4,a0,6
    2408:	16d79863          	bne	a5,a3,2578 <stpncpy+0x216>
    240c:	00750713          	addi	a4,a0,7
    2410:	00050323          	sb	zero,6(a0)
    2414:	40f80833          	sub	a6,a6,a5
    2418:	ff887593          	andi	a1,a6,-8
    241c:	97aa                	add	a5,a5,a0
    241e:	95be                	add	a1,a1,a5
    2420:	0007b023          	sd	zero,0(a5)
    2424:	07a1                	addi	a5,a5,8
    2426:	feb79de3          	bne	a5,a1,2420 <stpncpy+0xbe>
    242a:	ff887593          	andi	a1,a6,-8
    242e:	9ead                	addw	a3,a3,a1
    2430:	00b707b3          	add	a5,a4,a1
    2434:	12b80863          	beq	a6,a1,2564 <stpncpy+0x202>
    2438:	00078023          	sb	zero,0(a5)
    243c:	0016871b          	addiw	a4,a3,1
    2440:	0ec77863          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2444:	000780a3          	sb	zero,1(a5)
    2448:	0026871b          	addiw	a4,a3,2
    244c:	0ec77263          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2450:	00078123          	sb	zero,2(a5)
    2454:	0036871b          	addiw	a4,a3,3
    2458:	0cc77c63          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    245c:	000781a3          	sb	zero,3(a5)
    2460:	0046871b          	addiw	a4,a3,4
    2464:	0cc77663          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2468:	00078223          	sb	zero,4(a5)
    246c:	0056871b          	addiw	a4,a3,5
    2470:	0cc77063          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2474:	000782a3          	sb	zero,5(a5)
    2478:	0066871b          	addiw	a4,a3,6
    247c:	0ac77a63          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2480:	00078323          	sb	zero,6(a5)
    2484:	0076871b          	addiw	a4,a3,7
    2488:	0ac77463          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    248c:	000783a3          	sb	zero,7(a5)
    2490:	0086871b          	addiw	a4,a3,8
    2494:	08c77e63          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    2498:	00078423          	sb	zero,8(a5)
    249c:	0096871b          	addiw	a4,a3,9
    24a0:	08c77863          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    24a4:	000784a3          	sb	zero,9(a5)
    24a8:	00a6871b          	addiw	a4,a3,10
    24ac:	08c77263          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    24b0:	00078523          	sb	zero,10(a5)
    24b4:	00b6871b          	addiw	a4,a3,11
    24b8:	06c77c63          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    24bc:	000785a3          	sb	zero,11(a5)
    24c0:	00c6871b          	addiw	a4,a3,12
    24c4:	06c77663          	bgeu	a4,a2,2530 <stpncpy+0x1ce>
    24c8:	00078623          	sb	zero,12(a5)
    24cc:	26b5                	addiw	a3,a3,13
    24ce:	06c6f163          	bgeu	a3,a2,2530 <stpncpy+0x1ce>
    24d2:	000786a3          	sb	zero,13(a5)
    24d6:	8082                	ret
			;
		if (!n || !*s)
    24d8:	c645                	beqz	a2,2580 <stpncpy+0x21e>
    24da:	0005c783          	lbu	a5,0(a1)
    24de:	ea078be3          	beqz	a5,2394 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24e2:	479d                	li	a5,7
    24e4:	02c7ff63          	bgeu	a5,a2,2522 <stpncpy+0x1c0>
    24e8:	00000897          	auipc	a7,0x0
    24ec:	7008b883          	ld	a7,1792(a7) # 2be8 <enable_deadlock_detect+0x26e>
    24f0:	00000817          	auipc	a6,0x0
    24f4:	70083803          	ld	a6,1792(a6) # 2bf0 <enable_deadlock_detect+0x276>
    24f8:	431d                	li	t1,7
    24fa:	6198                	ld	a4,0(a1)
    24fc:	011707b3          	add	a5,a4,a7
    2500:	fff74693          	not	a3,a4
    2504:	8ff5                	and	a5,a5,a3
    2506:	0107f7b3          	and	a5,a5,a6
    250a:	ef81                	bnez	a5,2522 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    250c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    250e:	1661                	addi	a2,a2,-8
    2510:	05a1                	addi	a1,a1,8
    2512:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2514:	fec363e3          	bltu	t1,a2,24fa <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2518:	e609                	bnez	a2,2522 <stpncpy+0x1c0>
    251a:	a08d                	j	257c <stpncpy+0x21a>
    251c:	167d                	addi	a2,a2,-1
    251e:	0505                	addi	a0,a0,1
    2520:	ca01                	beqz	a2,2530 <stpncpy+0x1ce>
    2522:	0005c783          	lbu	a5,0(a1)
    2526:	0585                	addi	a1,a1,1
    2528:	00f50023          	sb	a5,0(a0)
    252c:	fbe5                	bnez	a5,251c <stpncpy+0x1ba>
		;
tail:
    252e:	b59d                	j	2394 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2530:	8082                	ret
    2532:	472d                	li	a4,11
    2534:	bdb5                	j	23b0 <stpncpy+0x4e>
    2536:	00778713          	addi	a4,a5,7
    253a:	45ad                	li	a1,11
    253c:	fff60693          	addi	a3,a2,-1
    2540:	e6b778e3          	bgeu	a4,a1,23b0 <stpncpy+0x4e>
    2544:	b7fd                	j	2532 <stpncpy+0x1d0>
    2546:	40a007b3          	neg	a5,a0
    254a:	8832                	mv	a6,a2
    254c:	8b9d                	andi	a5,a5,7
    254e:	4681                	li	a3,0
    2550:	e4060be3          	beqz	a2,23a6 <stpncpy+0x44>
    2554:	b7cd                	j	2536 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2556:	468d                	li	a3,3
    2558:	bd75                	j	2414 <stpncpy+0xb2>
    255a:	872a                	mv	a4,a0
    255c:	4681                	li	a3,0
    255e:	bd5d                	j	2414 <stpncpy+0xb2>
    2560:	4685                	li	a3,1
    2562:	bd4d                	j	2414 <stpncpy+0xb2>
    2564:	8082                	ret
    2566:	87aa                	mv	a5,a0
    2568:	4681                	li	a3,0
    256a:	b5f9                	j	2438 <stpncpy+0xd6>
    256c:	4689                	li	a3,2
    256e:	b55d                	j	2414 <stpncpy+0xb2>
    2570:	4691                	li	a3,4
    2572:	b54d                	j	2414 <stpncpy+0xb2>
    2574:	4695                	li	a3,5
    2576:	bd79                	j	2414 <stpncpy+0xb2>
    2578:	4699                	li	a3,6
    257a:	bd69                	j	2414 <stpncpy+0xb2>
    257c:	8082                	ret
    257e:	8082                	ret
    2580:	8082                	ret

0000000000002582 <basename>:

char *basename(char *s)
{
    2582:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2584:	c54d                	beqz	a0,262e <basename+0xac>
    2586:	00054783          	lbu	a5,0(a0)
		return ".";
    258a:	00000517          	auipc	a0,0x0
    258e:	65650513          	addi	a0,a0,1622 # 2be0 <enable_deadlock_detect+0x266>
	if (!s || !*s)
    2592:	e391                	bnez	a5,2596 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2594:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2596:	0076f713          	andi	a4,a3,7
    259a:	87b6                	mv	a5,a3
    259c:	cf51                	beqz	a4,2638 <basename+0xb6>
    259e:	0785                	addi	a5,a5,1
    25a0:	0077f713          	andi	a4,a5,7
    25a4:	c729                	beqz	a4,25ee <basename+0x6c>
		if (!*s)
    25a6:	0007c703          	lbu	a4,0(a5)
    25aa:	fb75                	bnez	a4,259e <basename+0x1c>
	return s - a;
    25ac:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25ae:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25b0:	cf8d                	beqz	a5,25ea <basename+0x68>
    25b2:	00f68733          	add	a4,a3,a5
    25b6:	02f00593          	li	a1,47
    25ba:	a031                	j	25c6 <basename+0x44>
		s[i] = 0;
    25bc:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25c0:	17fd                	addi	a5,a5,-1
    25c2:	177d                	addi	a4,a4,-1
    25c4:	c39d                	beqz	a5,25ea <basename+0x68>
    25c6:	00074603          	lbu	a2,0(a4)
    25ca:	feb609e3          	beq	a2,a1,25bc <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25ce:	02f00613          	li	a2,47
    25d2:	a011                	j	25d6 <basename+0x54>
    25d4:	cb99                	beqz	a5,25ea <basename+0x68>
    25d6:	853e                	mv	a0,a5
    25d8:	17fd                	addi	a5,a5,-1
    25da:	00f68733          	add	a4,a3,a5
    25de:	00074703          	lbu	a4,0(a4)
    25e2:	fec719e3          	bne	a4,a2,25d4 <basename+0x52>
	return s + i;
    25e6:	9536                	add	a0,a0,a3
    25e8:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    25ea:	8536                	mv	a0,a3
    25ec:	8082                	ret
    25ee:	6390                	ld	a2,0(a5)
    25f0:	00000517          	auipc	a0,0x0
    25f4:	5f853503          	ld	a0,1528(a0) # 2be8 <enable_deadlock_detect+0x26e>
    25f8:	00000597          	auipc	a1,0x0
    25fc:	5f85b583          	ld	a1,1528(a1) # 2bf0 <enable_deadlock_detect+0x276>
    2600:	fff64713          	not	a4,a2
    2604:	962a                	add	a2,a2,a0
    2606:	8f71                	and	a4,a4,a2
    2608:	8f6d                	and	a4,a4,a1
    260a:	eb11                	bnez	a4,261e <basename+0x9c>
    260c:	6790                	ld	a2,8(a5)
    260e:	07a1                	addi	a5,a5,8
    2610:	00a60733          	add	a4,a2,a0
    2614:	fff64613          	not	a2,a2
    2618:	8f71                	and	a4,a4,a2
    261a:	8f6d                	and	a4,a4,a1
    261c:	db65                	beqz	a4,260c <basename+0x8a>
	for (; *s; s++)
    261e:	0007c703          	lbu	a4,0(a5)
    2622:	d749                	beqz	a4,25ac <basename+0x2a>
    2624:	0017c703          	lbu	a4,1(a5)
    2628:	0785                	addi	a5,a5,1
    262a:	ff6d                	bnez	a4,2624 <basename+0xa2>
    262c:	b741                	j	25ac <basename+0x2a>
		return ".";
    262e:	00000517          	auipc	a0,0x0
    2632:	5b250513          	addi	a0,a0,1458 # 2be0 <enable_deadlock_detect+0x266>
    2636:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2638:	6290                	ld	a2,0(a3)
    263a:	00000517          	auipc	a0,0x0
    263e:	5ae53503          	ld	a0,1454(a0) # 2be8 <enable_deadlock_detect+0x26e>
    2642:	00000597          	auipc	a1,0x0
    2646:	5ae5b583          	ld	a1,1454(a1) # 2bf0 <enable_deadlock_detect+0x276>
    264a:	fff64713          	not	a4,a2
    264e:	962a                	add	a2,a2,a0
    2650:	8f71                	and	a4,a4,a2
    2652:	8f6d                	and	a4,a4,a1
    2654:	df45                	beqz	a4,260c <basename+0x8a>
    2656:	b7f9                	j	2624 <basename+0xa2>

0000000000002658 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2658:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    265c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    265e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2662:	2501                	sext.w	a0,a0
    2664:	8082                	ret

0000000000002666 <close>:

int close(int fd)
{
	if (fd == 1) {
    2666:	4785                	li	a5,1
    2668:	00f50863          	beq	a0,a5,2678 <close+0x12>
	register long a7 __asm__("a7") = n;
    266c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2670:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2674:	2501                	sext.w	a0,a0
    2676:	8082                	ret
{
    2678:	1101                	addi	sp,sp,-32
    267a:	ec06                	sd	ra,24(sp)
    267c:	e42a                	sd	a0,8(sp)
		__write_buffer();
    267e:	cdffe0ef          	jal	ra,135c <__write_buffer>
		__clear_buffer();
    2682:	d03fe0ef          	jal	ra,1384 <__clear_buffer>
    2686:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2688:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    268c:	00000073          	ecall
}
    2690:	60e2                	ld	ra,24(sp)
    2692:	2501                	sext.w	a0,a0
    2694:	6105                	addi	sp,sp,32
    2696:	8082                	ret

0000000000002698 <read>:
	register long a7 __asm__("a7") = n;
    2698:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    269c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    26a0:	8082                	ret

00000000000026a2 <write>:
	register long a7 __asm__("a7") = n;
    26a2:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26a6:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    26aa:	8082                	ret

00000000000026ac <getpid>:
	register long a7 __asm__("a7") = n;
    26ac:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    26b0:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    26b4:	2501                	sext.w	a0,a0
    26b6:	8082                	ret

00000000000026b8 <getppid>:
	register long a7 __asm__("a7") = n;
    26b8:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    26bc:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    26c0:	2501                	sext.w	a0,a0
    26c2:	8082                	ret

00000000000026c4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    26c4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26c8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    26cc:	2501                	sext.w	a0,a0
    26ce:	8082                	ret

00000000000026d0 <fork>:
	register long a7 __asm__("a7") = n;
    26d0:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    26d4:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    26d8:	2501                	sext.w	a0,a0
    26da:	8082                	ret

00000000000026dc <exit>:

void exit(int code)
{
    26dc:	1141                	addi	sp,sp,-16
    26de:	e406                	sd	ra,8(sp)
    26e0:	e022                	sd	s0,0(sp)
    26e2:	842a                	mv	s0,a0
	__write_buffer();
    26e4:	c79fe0ef          	jal	ra,135c <__write_buffer>
	__clear_buffer();
    26e8:	c9dfe0ef          	jal	ra,1384 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    26ec:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    26f0:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    26f2:	00000073          	ecall
	syscall(SYS_exit, code);
}
    26f6:	60a2                	ld	ra,8(sp)
    26f8:	6402                	ld	s0,0(sp)
    26fa:	0141                	addi	sp,sp,16
    26fc:	8082                	ret

00000000000026fe <waitpid>:
	register long a7 __asm__("a7") = n;
    26fe:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2702:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2706:	2501                	sext.w	a0,a0
    2708:	8082                	ret

000000000000270a <exec>:
	register long a7 __asm__("a7") = n;
    270a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    270e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2712:	2501                	sext.w	a0,a0
    2714:	8082                	ret

0000000000002716 <get_mtime>:

int64 get_mtime()
{
    2716:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2718:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    271c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    271e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2720:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2724:	2501                	sext.w	a0,a0
    2726:	ed01                	bnez	a0,273e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2728:	6722                	ld	a4,8(sp)
    272a:	3e800793          	li	a5,1000
    272e:	6682                	ld	a3,0(sp)
    2730:	02f75733          	divu	a4,a4,a5
    2734:	02d78533          	mul	a0,a5,a3
    2738:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    273a:	0141                	addi	sp,sp,16
    273c:	8082                	ret
	return -1;
    273e:	557d                	li	a0,-1
    2740:	bfed                	j	273a <get_mtime+0x24>

0000000000002742 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2742:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2746:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <sleep>:

int sleep(unsigned long long time)
{
    274e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2750:	880a                	mv	a6,sp
{
    2752:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2754:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2758:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    275a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    275c:	00000073          	ecall
	if (err == 0) {
    2760:	2501                	sext.w	a0,a0
    2762:	ed31                	bnez	a0,27be <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2764:	6722                	ld	a4,8(sp)
    2766:	3e800793          	li	a5,1000
    276a:	6682                	ld	a3,0(sp)
    276c:	02f75733          	divu	a4,a4,a5
    2770:	02d787b3          	mul	a5,a5,a3
    2774:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2776:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    277a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    277c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    277e:	00000073          	ecall
	if (err == 0) {
    2782:	2501                	sext.w	a0,a0
    2784:	e915                	bnez	a0,27b8 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2786:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2788:	3e800693          	li	a3,1000
    278c:	a819                	j	27a2 <sleep+0x54>
	__asm_syscall("r"(a7))
    278e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2792:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2796:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2798:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    279a:	00000073          	ecall
	if (err == 0) {
    279e:	2501                	sext.w	a0,a0
    27a0:	ed01                	bnez	a0,27b8 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    27a2:	6722                	ld	a4,8(sp)
    27a4:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    27a6:	07c00893          	li	a7,124
    27aa:	02d75733          	divu	a4,a4,a3
    27ae:	02f687b3          	mul	a5,a3,a5
    27b2:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    27b4:	fcc7ede3          	bltu	a5,a2,278e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    27b8:	4501                	li	a0,0
    27ba:	0141                	addi	sp,sp,16
    27bc:	8082                	ret
    27be:	57fd                	li	a5,-1
    27c0:	bf5d                	j	2776 <sleep+0x28>

00000000000027c2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    27c2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    27c6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    27ca:	2501                	sext.w	a0,a0
    27cc:	8082                	ret

00000000000027ce <set_priority>:
	register long a7 __asm__("a7") = n;
    27ce:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    27d2:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    27d6:	2501                	sext.w	a0,a0
    27d8:	8082                	ret

00000000000027da <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    27da:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27de:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    27e2:	2501                	sext.w	a0,a0
    27e4:	8082                	ret

00000000000027e6 <munmap>:
	register long a7 __asm__("a7") = n;
    27e6:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ea:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    27ee:	2501                	sext.w	a0,a0
    27f0:	8082                	ret

00000000000027f2 <wait>:

int wait(int *code)
{
    27f2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27f4:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    27f8:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27fa:	00000073          	ecall
	return waitpid(-1, code);
}
    27fe:	2501                	sext.w	a0,a0
    2800:	8082                	ret

0000000000002802 <spawn>:
	register long a7 __asm__("a7") = n;
    2802:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2806:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    280a:	2501                	sext.w	a0,a0
    280c:	8082                	ret

000000000000280e <pipe>:
	register long a7 __asm__("a7") = n;
    280e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2812:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2816:	2501                	sext.w	a0,a0
    2818:	8082                	ret

000000000000281a <mailread>:
	register long a7 __asm__("a7") = n;
    281a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    281e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2822:	2501                	sext.w	a0,a0
    2824:	8082                	ret

0000000000002826 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2826:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    282a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    282e:	2501                	sext.w	a0,a0
    2830:	8082                	ret

0000000000002832 <fstat>:
	register long a7 __asm__("a7") = n;
    2832:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2836:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    283a:	2501                	sext.w	a0,a0
    283c:	8082                	ret

000000000000283e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    283e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2840:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2844:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2846:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    284a:	2501                	sext.w	a0,a0
    284c:	8082                	ret

000000000000284e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    284e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2850:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2854:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2856:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    285a:	2501                	sext.w	a0,a0
    285c:	8082                	ret

000000000000285e <link>:

int link(char *old_path, char *new_path)
{
    285e:	87aa                	mv	a5,a0
    2860:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2862:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2866:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    286a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    286c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2870:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2872:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2876:	2501                	sext.w	a0,a0
    2878:	8082                	ret

000000000000287a <unlink>:

int unlink(char *path)
{
    287a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    287c:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2880:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2884:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2886:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    288a:	2501                	sext.w	a0,a0
    288c:	8082                	ret

000000000000288e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    288e:	00000797          	auipc	a5,0x0
    2892:	6827b783          	ld	a5,1666(a5) # 2f10 <_GLOBAL_OFFSET_TABLE_+0x8>
    2896:	439c                	lw	a5,0(a5)
    2898:	c799                	beqz	a5,28a6 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    289a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    289e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    28a2:	2501                	sext.w	a0,a0
    28a4:	8082                	ret
{
    28a6:	1101                	addi	sp,sp,-32
    28a8:	ec06                	sd	ra,24(sp)
    28aa:	e42e                	sd	a1,8(sp)
    28ac:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    28ae:	fe7fe0ef          	jal	ra,1894 <enable_thread_io_buffer>
    28b2:	65a2                	ld	a1,8(sp)
    28b4:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    28b6:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28ba:	00000073          	ecall
}
    28be:	60e2                	ld	ra,24(sp)
    28c0:	2501                	sext.w	a0,a0
    28c2:	6105                	addi	sp,sp,32
    28c4:	8082                	ret

00000000000028c6 <gettid>:
	register long a7 __asm__("a7") = n;
    28c6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    28ca:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    28ce:	2501                	sext.w	a0,a0
    28d0:	8082                	ret

00000000000028d2 <waittid>:

int waittid(int tid)
{
    28d2:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    28d4:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    28d8:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    28dc:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    28de:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28e0:	00e51e63          	bne	a0,a4,28fc <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    28e4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    28e8:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    28ec:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    28f0:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    28f2:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    28f6:	2501                	sext.w	a0,a0
	while (ret == -2) {
    28f8:	fee506e3          	beq	a0,a4,28e4 <waittid+0x12>
	}
	return ret;
}
    28fc:	8082                	ret

00000000000028fe <mutex_create>:
	register long a7 __asm__("a7") = n;
    28fe:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2902:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2904:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2908:	2501                	sext.w	a0,a0
    290a:	8082                	ret

000000000000290c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    290c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2910:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2912:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2916:	2501                	sext.w	a0,a0
    2918:	8082                	ret

000000000000291a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    291a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    291e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2922:	2501                	sext.w	a0,a0
    2924:	8082                	ret

0000000000002926 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2926:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    292a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    292e:	2501                	sext.w	a0,a0
    2930:	8082                	ret

0000000000002932 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2932:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2936:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    293a:	2501                	sext.w	a0,a0
    293c:	8082                	ret

000000000000293e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    293e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2942:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2946:	2501                	sext.w	a0,a0
    2948:	8082                	ret

000000000000294a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    294a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    294e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2952:	2501                	sext.w	a0,a0
    2954:	8082                	ret

0000000000002956 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2956:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    295a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    295e:	2501                	sext.w	a0,a0
    2960:	8082                	ret

0000000000002962 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2962:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2966:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    296a:	2501                	sext.w	a0,a0
    296c:	8082                	ret

000000000000296e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    296e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2972:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2976:	2501                	sext.w	a0,a0
    2978:	8082                	ret

000000000000297a <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    297a:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    297e:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2982:	2501                	sext.w	a0,a0
    2984:	8082                	ret
