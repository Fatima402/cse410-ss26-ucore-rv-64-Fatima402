
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_forktest1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a219                	j	1106 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

const int MAX_CHILD = 40;

int main()
{
    1002:	715d                	addi	sp,sp,-80
    1004:	e0a2                	sd	s0,64(sp)
    1006:	fc26                	sd	s1,56(sp)
    1008:	f84a                	sd	s2,48(sp)
    100a:	f44e                	sd	s3,40(sp)
    100c:	e486                	sd	ra,72(sp)
    100e:	f052                	sd	s4,32(sp)
    1010:	ec56                	sd	s5,24(sp)
	for (int i = 0; i < MAX_CHILD; ++i) {
    1012:	4401                	li	s0,0
		int pid = fork();
		if (pid == 0) {
			printf("I am child %d\n", i);
			exit(0);
		} else {
			printf("forked child pid = %d\n", pid);
    1014:	00001997          	auipc	s3,0x1
    1018:	76c98993          	addi	s3,s3,1900 # 2780 <enable_deadlock_detect+0x20>
			printf("I am child %d\n", i);
    101c:	00001917          	auipc	s2,0x1
    1020:	75490913          	addi	s2,s2,1876 # 2770 <enable_deadlock_detect+0x10>
	for (int i = 0; i < MAX_CHILD; ++i) {
    1024:	02800493          	li	s1,40
    1028:	a809                	j	103a <main+0x38>
			printf("I am child %d\n", i);
    102a:	236000ef          	jal	ra,1260 <printf>
			exit(0);
    102e:	4501                	li	a0,0
	for (int i = 0; i < MAX_CHILD; ++i) {
    1030:	2405                	addiw	s0,s0,1
			exit(0);
    1032:	490010ef          	jal	ra,24c2 <exit>
	for (int i = 0; i < MAX_CHILD; ++i) {
    1036:	00940f63          	beq	s0,s1,1054 <main+0x52>
		int pid = fork();
    103a:	47c010ef          	jal	ra,24b6 <fork>
    103e:	87aa                	mv	a5,a0
			printf("I am child %d\n", i);
    1040:	85a2                	mv	a1,s0
    1042:	854a                	mv	a0,s2
		if (pid == 0) {
    1044:	d3fd                	beqz	a5,102a <main+0x28>
			printf("forked child pid = %d\n", pid);
    1046:	85be                	mv	a1,a5
    1048:	854e                	mv	a0,s3
	for (int i = 0; i < MAX_CHILD; ++i) {
    104a:	2405                	addiw	s0,s0,1
			printf("forked child pid = %d\n", pid);
    104c:	214000ef          	jal	ra,1260 <printf>
	for (int i = 0; i < MAX_CHILD; ++i) {
    1050:	fe9415e3          	bne	s0,s1,103a <main+0x38>
		}
	}

	int exit_code = 0;
    1054:	c602                	sw	zero,12(sp)
    1056:	02800413          	li	s0,40
    105a:	0064                	addi	s1,sp,12
	for (int i = 0; i < MAX_CHILD; ++i) {
		if (wait(&exit_code) <= 0) {
			panic("wait stopped early");
    105c:	00001a97          	auipc	s5,0x1
    1060:	73ca8a93          	addi	s5,s5,1852 # 2798 <enable_deadlock_detect+0x38>
    1064:	00001a17          	auipc	s4,0x1
    1068:	77ca0a13          	addi	s4,s4,1916 # 27e0 <enable_deadlock_detect+0x80>
    106c:	00001997          	auipc	s3,0x1
    1070:	77c98993          	addi	s3,s3,1916 # 27e8 <enable_deadlock_detect+0x88>
		if (wait(&exit_code) <= 0) {
    1074:	8526                	mv	a0,s1
    1076:	562010ef          	jal	ra,25d8 <wait>
	for (int i = 0; i < MAX_CHILD; ++i) {
    107a:	347d                	addiw	s0,s0,-1
		if (wait(&exit_code) <= 0) {
    107c:	06a05263          	blez	a0,10e0 <main+0xde>
	for (int i = 0; i < MAX_CHILD; ++i) {
    1080:	f875                	bnez	s0,1074 <main+0x72>
		}
	}
	if (wait(&exit_code) > 0) {
    1082:	8526                	mv	a0,s1
    1084:	554010ef          	jal	ra,25d8 <wait>
    1088:	02a05c63          	blez	a0,10c0 <main+0xbe>
		panic("wait got too many");
    108c:	406010ef          	jal	ra,2492 <getpid>
    1090:	842a                	mv	s0,a0
    1092:	00001517          	auipc	a0,0x1
    1096:	70650513          	addi	a0,a0,1798 # 2798 <enable_deadlock_detect+0x38>
    109a:	2ce010ef          	jal	ra,2368 <basename>
    109e:	872a                	mv	a4,a0
    10a0:	47e9                	li	a5,26
    10a2:	00001517          	auipc	a0,0x1
    10a6:	77650513          	addi	a0,a0,1910 # 2818 <enable_deadlock_detect+0xb8>
    10aa:	86a2                	mv	a3,s0
    10ac:	00001617          	auipc	a2,0x1
    10b0:	73460613          	addi	a2,a2,1844 # 27e0 <enable_deadlock_detect+0x80>
    10b4:	45fd                	li	a1,31
    10b6:	1aa000ef          	jal	ra,1260 <printf>
    10ba:	557d                	li	a0,-1
    10bc:	406010ef          	jal	ra,24c2 <exit>
	}
	printf("forktest1 pass.\n");
    10c0:	00001517          	auipc	a0,0x1
    10c4:	78850513          	addi	a0,a0,1928 # 2848 <enable_deadlock_detect+0xe8>
    10c8:	198000ef          	jal	ra,1260 <printf>
	return 0;
    10cc:	60a6                	ld	ra,72(sp)
    10ce:	6406                	ld	s0,64(sp)
    10d0:	74e2                	ld	s1,56(sp)
    10d2:	7942                	ld	s2,48(sp)
    10d4:	79a2                	ld	s3,40(sp)
    10d6:	7a02                	ld	s4,32(sp)
    10d8:	6ae2                	ld	s5,24(sp)
    10da:	4501                	li	a0,0
    10dc:	6161                	addi	sp,sp,80
    10de:	8082                	ret
			panic("wait stopped early");
    10e0:	3b2010ef          	jal	ra,2492 <getpid>
    10e4:	892a                	mv	s2,a0
    10e6:	8556                	mv	a0,s5
    10e8:	280010ef          	jal	ra,2368 <basename>
    10ec:	872a                	mv	a4,a0
    10ee:	47d9                	li	a5,22
    10f0:	854e                	mv	a0,s3
    10f2:	86ca                	mv	a3,s2
    10f4:	8652                	mv	a2,s4
    10f6:	45fd                	li	a1,31
    10f8:	168000ef          	jal	ra,1260 <printf>
    10fc:	557d                	li	a0,-1
    10fe:	3c4010ef          	jal	ra,24c2 <exit>
	for (int i = 0; i < MAX_CHILD; ++i) {
    1102:	f82d                	bnez	s0,1074 <main+0x72>
    1104:	bfbd                	j	1082 <main+0x80>

0000000000001106 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1106:	1141                	addi	sp,sp,-16
    1108:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    110a:	ef9ff0ef          	jal	ra,1002 <main>
    110e:	3b4010ef          	jal	ra,24c2 <exit>
	return 0;
    1112:	60a2                	ld	ra,8(sp)
    1114:	4501                	li	a0,0
    1116:	0141                	addi	sp,sp,16
    1118:	8082                	ret

000000000000111a <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    111a:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    111c:	4605                	li	a2,1
    111e:	00f10593          	addi	a1,sp,15
    1122:	4501                	li	a0,0
{
    1124:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1126:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    112a:	354010ef          	jal	ra,247e <read>
    112e:	4785                	li	a5,1
    1130:	00f51763          	bne	a0,a5,113e <getchar+0x24>
		return byte;
    1134:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1138:	60e2                	ld	ra,24(sp)
    113a:	6105                	addi	sp,sp,32
    113c:	8082                	ret
		return EOF;
    113e:	557d                	li	a0,-1
    1140:	bfe5                	j	1138 <getchar+0x1e>

0000000000001142 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1142:	00002517          	auipc	a0,0x2
    1146:	81652503          	lw	a0,-2026(a0) # 2958 <buffer_len>
    114a:	e111                	bnez	a0,114e <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    114c:	8082                	ret
{
    114e:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1150:	862a                	mv	a2,a0
    1152:	00002597          	auipc	a1,0x2
    1156:	80e58593          	addi	a1,a1,-2034 # 2960 <buffer>
    115a:	4505                	li	a0,1
{
    115c:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    115e:	32a010ef          	jal	ra,2488 <write>
}
    1162:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1164:	2501                	sext.w	a0,a0
}
    1166:	0141                	addi	sp,sp,16
    1168:	8082                	ret

000000000000116a <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    116a:	00001797          	auipc	a5,0x1
    116e:	7e07a723          	sw	zero,2030(a5) # 2958 <buffer_len>
}
    1172:	8082                	ret

0000000000001174 <__fflush>:
	if (buffer_len == 0)
    1174:	00001517          	auipc	a0,0x1
    1178:	7e452503          	lw	a0,2020(a0) # 2958 <buffer_len>
    117c:	e511                	bnez	a0,1188 <__fflush+0x14>
	buffer_len = 0;
    117e:	00001797          	auipc	a5,0x1
    1182:	7c07ad23          	sw	zero,2010(a5) # 2958 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1186:	8082                	ret
{
    1188:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    118a:	862a                	mv	a2,a0
    118c:	00001597          	auipc	a1,0x1
    1190:	7d458593          	addi	a1,a1,2004 # 2960 <buffer>
    1194:	4505                	li	a0,1
{
    1196:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1198:	2f0010ef          	jal	ra,2488 <write>
	return r >= 0 ? 0 : r;
    119c:	0005079b          	sext.w	a5,a0
}
    11a0:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11a2:	0017a793          	slti	a5,a5,1
    11a6:	40f007bb          	negw	a5,a5
    11aa:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11ac:	00001797          	auipc	a5,0x1
    11b0:	7a07a623          	sw	zero,1964(a5) # 2958 <buffer_len>
	return r >= 0 ? 0 : r;
    11b4:	2501                	sext.w	a0,a0
}
    11b6:	0141                	addi	sp,sp,16
    11b8:	8082                	ret

00000000000011ba <fflush>:

int fflush(int fd)
{
    11ba:	1101                	addi	sp,sp,-32
    11bc:	e822                	sd	s0,16(sp)
    11be:	ec06                	sd	ra,24(sp)
    11c0:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11c2:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    11c4:	4401                	li	s0,0
	if (fd == 1) {
    11c6:	00e50863          	beq	a0,a4,11d6 <fflush+0x1c>
}
    11ca:	60e2                	ld	ra,24(sp)
    11cc:	8522                	mv	a0,s0
    11ce:	6442                	ld	s0,16(sp)
    11d0:	64a2                	ld	s1,8(sp)
    11d2:	6105                	addi	sp,sp,32
    11d4:	8082                	ret
		if (buffer_lock_enabled == 1) {
    11d6:	00001497          	auipc	s1,0x1
    11da:	78248493          	addi	s1,s1,1922 # 2958 <buffer_len>
    11de:	1084a703          	lw	a4,264(s1)
    11e2:	02a70e63          	beq	a4,a0,121e <fflush+0x64>
	if (buffer_len == 0)
    11e6:	4080                	lw	s0,0(s1)
    11e8:	c00d                	beqz	s0,120a <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    11ea:	8622                	mv	a2,s0
    11ec:	00001597          	auipc	a1,0x1
    11f0:	77458593          	addi	a1,a1,1908 # 2960 <buffer>
    11f4:	294010ef          	jal	ra,2488 <write>
	return r >= 0 ? 0 : r;
    11f8:	0005079b          	sext.w	a5,a0
    11fc:	0017a793          	slti	a5,a5,1
    1200:	40f007bb          	negw	a5,a5
    1204:	8d7d                	and	a0,a0,a5
    1206:	0005041b          	sext.w	s0,a0
}
    120a:	60e2                	ld	ra,24(sp)
    120c:	8522                	mv	a0,s0
    120e:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1210:	00001797          	auipc	a5,0x1
    1214:	7407a423          	sw	zero,1864(a5) # 2958 <buffer_len>
}
    1218:	64a2                	ld	s1,8(sp)
    121a:	6105                	addi	sp,sp,32
    121c:	8082                	ret
			mutex_lock(buffer_lock);
    121e:	10c4a503          	lw	a0,268(s1)
    1222:	4de010ef          	jal	ra,2700 <mutex_lock>
	if (buffer_len == 0)
    1226:	4080                	lw	s0,0(s1)
    1228:	e811                	bnez	s0,123c <fflush+0x82>
			mutex_unlock(buffer_lock);
    122a:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    122e:	00001797          	auipc	a5,0x1
    1232:	7207a523          	sw	zero,1834(a5) # 2958 <buffer_len>
			mutex_unlock(buffer_lock);
    1236:	4d6010ef          	jal	ra,270c <mutex_unlock>
    123a:	bf41                	j	11ca <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    123c:	8622                	mv	a2,s0
    123e:	00001597          	auipc	a1,0x1
    1242:	72258593          	addi	a1,a1,1826 # 2960 <buffer>
    1246:	4505                	li	a0,1
    1248:	240010ef          	jal	ra,2488 <write>
	return r >= 0 ? 0 : r;
    124c:	0005079b          	sext.w	a5,a0
    1250:	0017a793          	slti	a5,a5,1
    1254:	40f007bb          	negw	a5,a5
    1258:	8d7d                	and	a0,a0,a5
    125a:	0005041b          	sext.w	s0,a0
	return r;
    125e:	b7f1                	j	122a <fflush+0x70>

0000000000001260 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1260:	7131                	addi	sp,sp,-192
    1262:	e0da                	sd	s6,64(sp)
    1264:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1266:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1268:	013c                	addi	a5,sp,136
{
    126a:	f0ca                	sd	s2,96(sp)
    126c:	ecce                	sd	s3,88(sp)
    126e:	e8d2                	sd	s4,80(sp)
    1270:	e4d6                	sd	s5,72(sp)
    1272:	fc86                	sd	ra,120(sp)
    1274:	f8a2                	sd	s0,112(sp)
    1276:	f4a6                	sd	s1,104(sp)
    1278:	89aa                	mv	s3,a0
    127a:	e52e                	sd	a1,136(sp)
    127c:	e932                	sd	a2,144(sp)
    127e:	ed36                	sd	a3,152(sp)
    1280:	f13a                	sd	a4,160(sp)
    1282:	f942                	sd	a6,176(sp)
    1284:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1286:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1288:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    128c:	00001a17          	auipc	s4,0x1
    1290:	6cca0a13          	addi	s4,s4,1740 # 2958 <buffer_len>
    1294:	4a85                	li	s5,1
	buf[i++] = '0';
    1296:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    129a:	0009c783          	lbu	a5,0(s3)
    129e:	18078663          	beqz	a5,142a <printf+0x1ca>
    12a2:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12a4:	19278d63          	beq	a5,s2,143e <printf+0x1de>
    12a8:	0015c783          	lbu	a5,1(a1)
    12ac:	0585                	addi	a1,a1,1
    12ae:	fbfd                	bnez	a5,12a4 <printf+0x44>
    12b0:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12b2:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12b6:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12ba:	1b578863          	beq	a5,s5,146a <printf+0x20a>
		len = out_unlocked(s, l);
    12be:	85a2                	mv	a1,s0
    12c0:	854e                	mv	a0,s3
    12c2:	42a000ef          	jal	ra,16ec <out_unlocked>
		out(f, a, l);
		if (l)
    12c6:	1c041063          	bnez	s0,1486 <printf+0x226>
			continue;
		if (s[1] == 0)
    12ca:	0014c783          	lbu	a5,1(s1)
    12ce:	14078e63          	beqz	a5,142a <printf+0x1ca>
			break;
		switch (s[1]) {
    12d2:	07300713          	li	a4,115
    12d6:	1ce78863          	beq	a5,a4,14a6 <printf+0x246>
    12da:	1af76863          	bltu	a4,a5,148a <printf+0x22a>
    12de:	06400713          	li	a4,100
    12e2:	22e78063          	beq	a5,a4,1502 <printf+0x2a2>
    12e6:	07000713          	li	a4,112
    12ea:	1ee79563          	bne	a5,a4,14d4 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    12ee:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12f0:	00001797          	auipc	a5,0x1
    12f4:	78078793          	addi	a5,a5,1920 # 2a70 <digits>
	buf[i++] = '0';
    12f8:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    12fc:	6298                	ld	a4,0(a3)
    12fe:	06a1                	addi	a3,a3,8
    1300:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1302:	00471393          	slli	t2,a4,0x4
    1306:	00871293          	slli	t0,a4,0x8
    130a:	00c71f93          	slli	t6,a4,0xc
    130e:	01071f13          	slli	t5,a4,0x10
    1312:	01471e93          	slli	t4,a4,0x14
    1316:	01871e13          	slli	t3,a4,0x18
    131a:	01c71893          	slli	a7,a4,0x1c
    131e:	02471813          	slli	a6,a4,0x24
    1322:	02871513          	slli	a0,a4,0x28
    1326:	02c71593          	slli	a1,a4,0x2c
    132a:	03071613          	slli	a2,a4,0x30
    132e:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1332:	03c75413          	srli	s0,a4,0x3c
    1336:	01c7531b          	srliw	t1,a4,0x1c
    133a:	03c3d393          	srli	t2,t2,0x3c
    133e:	03c2d293          	srli	t0,t0,0x3c
    1342:	03cfdf93          	srli	t6,t6,0x3c
    1346:	03cf5f13          	srli	t5,t5,0x3c
    134a:	03cede93          	srli	t4,t4,0x3c
    134e:	03ce5e13          	srli	t3,t3,0x3c
    1352:	03c8d893          	srli	a7,a7,0x3c
    1356:	03c85813          	srli	a6,a6,0x3c
    135a:	9171                	srli	a0,a0,0x3c
    135c:	91f1                	srli	a1,a1,0x3c
    135e:	9271                	srli	a2,a2,0x3c
    1360:	92f1                	srli	a3,a3,0x3c
    1362:	95be                	add	a1,a1,a5
    1364:	963e                	add	a2,a2,a5
    1366:	96be                	add	a3,a3,a5
    1368:	943e                	add	s0,s0,a5
    136a:	93be                	add	t2,t2,a5
    136c:	92be                	add	t0,t0,a5
    136e:	9fbe                	add	t6,t6,a5
    1370:	9f3e                	add	t5,t5,a5
    1372:	9ebe                	add	t4,t4,a5
    1374:	9e3e                	add	t3,t3,a5
    1376:	98be                	add	a7,a7,a5
    1378:	933e                	add	t1,t1,a5
    137a:	983e                	add	a6,a6,a5
    137c:	953e                	add	a0,a0,a5
    137e:	0005c983          	lbu	s3,0(a1)
    1382:	00044403          	lbu	s0,0(s0)
    1386:	00064583          	lbu	a1,0(a2)
    138a:	0003c383          	lbu	t2,0(t2)
    138e:	0006c603          	lbu	a2,0(a3)
    1392:	0002c283          	lbu	t0,0(t0)
    1396:	000fcf83          	lbu	t6,0(t6)
    139a:	000f4f03          	lbu	t5,0(t5)
    139e:	000ece83          	lbu	t4,0(t4)
    13a2:	000e4e03          	lbu	t3,0(t3)
    13a6:	0008c883          	lbu	a7,0(a7)
    13aa:	00034303          	lbu	t1,0(t1)
    13ae:	00084803          	lbu	a6,0(a6)
    13b2:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13b6:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13ba:	92f1                	srli	a3,a3,0x3c
    13bc:	8b3d                	andi	a4,a4,15
    13be:	96be                	add	a3,a3,a5
    13c0:	97ba                	add	a5,a5,a4
    13c2:	00810d23          	sb	s0,26(sp)
    13c6:	00710da3          	sb	t2,27(sp)
    13ca:	00510e23          	sb	t0,28(sp)
    13ce:	01f10ea3          	sb	t6,29(sp)
    13d2:	01e10f23          	sb	t5,30(sp)
    13d6:	01d10fa3          	sb	t4,31(sp)
    13da:	03c10023          	sb	t3,32(sp)
    13de:	031100a3          	sb	a7,33(sp)
    13e2:	02610123          	sb	t1,34(sp)
    13e6:	030101a3          	sb	a6,35(sp)
    13ea:	02a10223          	sb	a0,36(sp)
    13ee:	033102a3          	sb	s3,37(sp)
    13f2:	02b10323          	sb	a1,38(sp)
    13f6:	02c103a3          	sb	a2,39(sp)
    13fa:	0006c683          	lbu	a3,0(a3)
    13fe:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1402:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1406:	02d10423          	sb	a3,40(sp)
    140a:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    140e:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1412:	11578263          	beq	a5,s5,1516 <printf+0x2b6>
		len = out_unlocked(s, l);
    1416:	45c9                	li	a1,18
    1418:	0828                	addi	a0,sp,24
    141a:	2d2000ef          	jal	ra,16ec <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    141e:	00248993          	addi	s3,s1,2
		if (!*s)
    1422:	0009c783          	lbu	a5,0(s3)
    1426:	e6079ee3          	bnez	a5,12a2 <printf+0x42>
	}
	va_end(ap);
    142a:	70e6                	ld	ra,120(sp)
    142c:	7446                	ld	s0,112(sp)
    142e:	74a6                	ld	s1,104(sp)
    1430:	7906                	ld	s2,96(sp)
    1432:	69e6                	ld	s3,88(sp)
    1434:	6a46                	ld	s4,80(sp)
    1436:	6aa6                	ld	s5,72(sp)
    1438:	6b06                	ld	s6,64(sp)
    143a:	6129                	addi	sp,sp,192
    143c:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    143e:	0005c783          	lbu	a5,0(a1)
    1442:	84ae                	mv	s1,a1
    1444:	01278963          	beq	a5,s2,1456 <printf+0x1f6>
    1448:	b5ad                	j	12b2 <printf+0x52>
    144a:	0024c783          	lbu	a5,2(s1)
    144e:	0585                	addi	a1,a1,1
    1450:	0489                	addi	s1,s1,2
    1452:	e72790e3          	bne	a5,s2,12b2 <printf+0x52>
    1456:	0014c783          	lbu	a5,1(s1)
    145a:	ff2788e3          	beq	a5,s2,144a <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    145e:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1462:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1466:	e5579ce3          	bne	a5,s5,12be <printf+0x5e>
		mutex_lock(buffer_lock);
    146a:	10ca2503          	lw	a0,268(s4)
    146e:	292010ef          	jal	ra,2700 <mutex_lock>
		len = out_unlocked(s, l);
    1472:	85a2                	mv	a1,s0
    1474:	854e                	mv	a0,s3
    1476:	276000ef          	jal	ra,16ec <out_unlocked>
		mutex_unlock(buffer_lock);
    147a:	10ca2503          	lw	a0,268(s4)
    147e:	28e010ef          	jal	ra,270c <mutex_unlock>
		if (l)
    1482:	e40404e3          	beqz	s0,12ca <printf+0x6a>
    1486:	89a6                	mv	s3,s1
    1488:	bd09                	j	129a <printf+0x3a>
		switch (s[1]) {
    148a:	07800713          	li	a4,120
    148e:	04e79363          	bne	a5,a4,14d4 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1492:	67c2                	ld	a5,16(sp)
    1494:	45c1                	li	a1,16
		s += 2;
    1496:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    149a:	4388                	lw	a0,0(a5)
    149c:	07a1                	addi	a5,a5,8
    149e:	e83e                	sd	a5,16(sp)
    14a0:	5f8000ef          	jal	ra,1a98 <printint.constprop.0>
		s += 2;
    14a4:	bfbd                	j	1422 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14a6:	67c2                	ld	a5,16(sp)
    14a8:	6380                	ld	s0,0(a5)
    14aa:	07a1                	addi	a5,a5,8
    14ac:	e83e                	sd	a5,16(sp)
    14ae:	1c040163          	beqz	s0,1670 <printf+0x410>
			l = strnlen(a, 200);
    14b2:	0c800593          	li	a1,200
    14b6:	8522                	mv	a0,s0
    14b8:	3f7000ef          	jal	ra,20ae <strnlen>
	if (buffer_lock_enabled == 1) {
    14bc:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14c0:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    14c4:	19578663          	beq	a5,s5,1650 <printf+0x3f0>
		len = out_unlocked(s, l);
    14c8:	8522                	mv	a0,s0
    14ca:	222000ef          	jal	ra,16ec <out_unlocked>
		s += 2;
    14ce:	00248993          	addi	s3,s1,2
    14d2:	bf81                	j	1422 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    14d4:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14d8:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    14dc:	0f578663          	beq	a5,s5,15c8 <printf+0x368>
		len = out_unlocked(s, l);
    14e0:	0828                	addi	a0,sp,24
    14e2:	316000ef          	jal	ra,17f8 <out_unlocked.constprop.0>
			putchar(s[1]);
    14e6:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    14ea:	108a2783          	lw	a5,264(s4)
	char byte = c;
    14ee:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    14f2:	05578163          	beq	a5,s5,1534 <printf+0x2d4>
		len = out_unlocked(s, l);
    14f6:	0828                	addi	a0,sp,24
    14f8:	300000ef          	jal	ra,17f8 <out_unlocked.constprop.0>
		s += 2;
    14fc:	00248993          	addi	s3,s1,2
    1500:	b70d                	j	1422 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1502:	67c2                	ld	a5,16(sp)
    1504:	45a9                	li	a1,10
		s += 2;
    1506:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    150a:	4388                	lw	a0,0(a5)
    150c:	07a1                	addi	a5,a5,8
    150e:	e83e                	sd	a5,16(sp)
    1510:	588000ef          	jal	ra,1a98 <printint.constprop.0>
		s += 2;
    1514:	b739                	j	1422 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1516:	10ca2503          	lw	a0,268(s4)
		s += 2;
    151a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    151e:	1e2010ef          	jal	ra,2700 <mutex_lock>
		len = out_unlocked(s, l);
    1522:	45c9                	li	a1,18
    1524:	0828                	addi	a0,sp,24
    1526:	1c6000ef          	jal	ra,16ec <out_unlocked>
		mutex_unlock(buffer_lock);
    152a:	10ca2503          	lw	a0,268(s4)
    152e:	1de010ef          	jal	ra,270c <mutex_unlock>
		s += 2;
    1532:	bdc5                	j	1422 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1534:	10ca2503          	lw	a0,268(s4)
    1538:	1c8010ef          	jal	ra,2700 <mutex_lock>
		buffer[buffer_len++] = c;
    153c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1540:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1544:	0017861b          	addiw	a2,a5,1
    1548:	97d2                	add	a5,a5,s4
    154a:	00ca2023          	sw	a2,0(s4)
    154e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1552:	00c6cc63          	blt	a3,a2,156a <printf+0x30a>
    1556:	47a9                	li	a5,10
    1558:	06f40663          	beq	s0,a5,15c4 <printf+0x364>
		mutex_unlock(buffer_lock);
    155c:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1560:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1564:	1a8010ef          	jal	ra,270c <mutex_unlock>
		s += 2;
    1568:	bd6d                	j	1422 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    156a:	10000793          	li	a5,256
    156e:	00f61e63          	bne	a2,a5,158a <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    1572:	00001597          	auipc	a1,0x1
    1576:	3ee58593          	addi	a1,a1,1006 # 2960 <buffer>
    157a:	4505                	li	a0,1
    157c:	70d000ef          	jal	ra,2488 <write>
	buffer_len = 0;
    1580:	00001797          	auipc	a5,0x1
    1584:	3c07ac23          	sw	zero,984(a5) # 2958 <buffer_len>
			if (r < 0) {
    1588:	bfd1                	j	155c <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    158a:	709000ef          	jal	ra,2492 <getpid>
    158e:	842a                	mv	s0,a0
    1590:	00001517          	auipc	a0,0x1
    1594:	2d850513          	addi	a0,a0,728 # 2868 <enable_deadlock_detect+0x108>
    1598:	5d1000ef          	jal	ra,2368 <basename>
    159c:	872a                	mv	a4,a0
    159e:	00001617          	auipc	a2,0x1
    15a2:	24260613          	addi	a2,a2,578 # 27e0 <enable_deadlock_detect+0x80>
    15a6:	05400793          	li	a5,84
    15aa:	86a2                	mv	a3,s0
    15ac:	45fd                	li	a1,31
    15ae:	00001517          	auipc	a0,0x1
    15b2:	2fa50513          	addi	a0,a0,762 # 28a8 <enable_deadlock_detect+0x148>
    15b6:	cabff0ef          	jal	ra,1260 <printf>
    15ba:	557d                	li	a0,-1
    15bc:	707000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    15c0:	000a2603          	lw	a2,0(s4)
    15c4:	de41                	beqz	a2,155c <printf+0x2fc>
    15c6:	b775                	j	1572 <printf+0x312>
		mutex_lock(buffer_lock);
    15c8:	10ca2503          	lw	a0,268(s4)
    15cc:	134010ef          	jal	ra,2700 <mutex_lock>
		buffer[buffer_len++] = c;
    15d0:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15d4:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15d8:	0017861b          	addiw	a2,a5,1
    15dc:	97d2                	add	a5,a5,s4
    15de:	00ca2023          	sw	a2,0(s4)
    15e2:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15e6:	02c6d163          	bge	a3,a2,1608 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    15ea:	10000793          	li	a5,256
    15ee:	02f61263          	bne	a2,a5,1612 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    15f2:	00001597          	auipc	a1,0x1
    15f6:	36e58593          	addi	a1,a1,878 # 2960 <buffer>
    15fa:	4505                	li	a0,1
    15fc:	68d000ef          	jal	ra,2488 <write>
	buffer_len = 0;
    1600:	00001797          	auipc	a5,0x1
    1604:	3407ac23          	sw	zero,856(a5) # 2958 <buffer_len>
		mutex_unlock(buffer_lock);
    1608:	10ca2503          	lw	a0,268(s4)
    160c:	100010ef          	jal	ra,270c <mutex_unlock>
    1610:	bdd9                	j	14e6 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1612:	681000ef          	jal	ra,2492 <getpid>
    1616:	842a                	mv	s0,a0
    1618:	00001517          	auipc	a0,0x1
    161c:	25050513          	addi	a0,a0,592 # 2868 <enable_deadlock_detect+0x108>
    1620:	549000ef          	jal	ra,2368 <basename>
    1624:	872a                	mv	a4,a0
    1626:	00001617          	auipc	a2,0x1
    162a:	1ba60613          	addi	a2,a2,442 # 27e0 <enable_deadlock_detect+0x80>
    162e:	05400793          	li	a5,84
    1632:	86a2                	mv	a3,s0
    1634:	45fd                	li	a1,31
    1636:	00001517          	auipc	a0,0x1
    163a:	27250513          	addi	a0,a0,626 # 28a8 <enable_deadlock_detect+0x148>
    163e:	c23ff0ef          	jal	ra,1260 <printf>
    1642:	557d                	li	a0,-1
    1644:	67f000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    1648:	000a2603          	lw	a2,0(s4)
    164c:	de55                	beqz	a2,1608 <printf+0x3a8>
    164e:	b755                	j	15f2 <printf+0x392>
		mutex_lock(buffer_lock);
    1650:	10ca2503          	lw	a0,268(s4)
    1654:	e42e                	sd	a1,8(sp)
		s += 2;
    1656:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    165a:	0a6010ef          	jal	ra,2700 <mutex_lock>
		len = out_unlocked(s, l);
    165e:	65a2                	ld	a1,8(sp)
    1660:	8522                	mv	a0,s0
    1662:	08a000ef          	jal	ra,16ec <out_unlocked>
		mutex_unlock(buffer_lock);
    1666:	10ca2503          	lw	a0,268(s4)
    166a:	0a2010ef          	jal	ra,270c <mutex_unlock>
		s += 2;
    166e:	bb55                	j	1422 <printf+0x1c2>
				a = "(null)";
    1670:	00001417          	auipc	s0,0x1
    1674:	1f040413          	addi	s0,s0,496 # 2860 <enable_deadlock_detect+0x100>
    1678:	bd2d                	j	14b2 <printf+0x252>

000000000000167a <enable_thread_io_buffer>:
{
    167a:	1101                	addi	sp,sp,-32
    167c:	e822                	sd	s0,16(sp)
    167e:	ec06                	sd	ra,24(sp)
    1680:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1682:	00001417          	auipc	s0,0x1
    1686:	2d640413          	addi	s0,s0,726 # 2958 <buffer_len>
    168a:	05a010ef          	jal	ra,26e4 <mutex_create>
    168e:	10a42623          	sw	a0,268(s0)
    1692:	00054a63          	bltz	a0,16a6 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1696:	4785                	li	a5,1
}
    1698:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    169a:	10f42423          	sw	a5,264(s0)
}
    169e:	6442                	ld	s0,16(sp)
    16a0:	64a2                	ld	s1,8(sp)
    16a2:	6105                	addi	sp,sp,32
    16a4:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16a6:	5ed000ef          	jal	ra,2492 <getpid>
    16aa:	84aa                	mv	s1,a0
    16ac:	00001517          	auipc	a0,0x1
    16b0:	1bc50513          	addi	a0,a0,444 # 2868 <enable_deadlock_detect+0x108>
    16b4:	4b5000ef          	jal	ra,2368 <basename>
    16b8:	872a                	mv	a4,a0
    16ba:	04800793          	li	a5,72
    16be:	86a6                	mv	a3,s1
    16c0:	00001517          	auipc	a0,0x1
    16c4:	22850513          	addi	a0,a0,552 # 28e8 <enable_deadlock_detect+0x188>
    16c8:	00001617          	auipc	a2,0x1
    16cc:	11860613          	addi	a2,a2,280 # 27e0 <enable_deadlock_detect+0x80>
    16d0:	45fd                	li	a1,31
    16d2:	b8fff0ef          	jal	ra,1260 <printf>
    16d6:	557d                	li	a0,-1
    16d8:	5eb000ef          	jal	ra,24c2 <exit>
	buffer_lock_enabled = 1;
    16dc:	4785                	li	a5,1
}
    16de:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16e0:	10f42423          	sw	a5,264(s0)
}
    16e4:	6442                	ld	s0,16(sp)
    16e6:	64a2                	ld	s1,8(sp)
    16e8:	6105                	addi	sp,sp,32
    16ea:	8082                	ret

00000000000016ec <out_unlocked>:
{
    16ec:	7159                	addi	sp,sp,-112
    16ee:	f486                	sd	ra,104(sp)
    16f0:	f0a2                	sd	s0,96(sp)
    16f2:	eca6                	sd	s1,88(sp)
    16f4:	e8ca                	sd	s2,80(sp)
    16f6:	e4ce                	sd	s3,72(sp)
    16f8:	e0d2                	sd	s4,64(sp)
    16fa:	fc56                	sd	s5,56(sp)
    16fc:	f85a                	sd	s6,48(sp)
    16fe:	f45e                	sd	s7,40(sp)
    1700:	f062                	sd	s8,32(sp)
    1702:	ec66                	sd	s9,24(sp)
    1704:	e86a                	sd	s10,16(sp)
    1706:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1708:	0e058663          	beqz	a1,17f4 <out_unlocked+0x108>
    170c:	842a                	mv	s0,a0
    170e:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1712:	4981                	li	s3,0
    1714:	00001d17          	auipc	s10,0x1
    1718:	244d0d13          	addi	s10,s10,580 # 2958 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    171c:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1720:	00001b17          	auipc	s6,0x1
    1724:	240b0b13          	addi	s6,s6,576 # 2960 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1728:	10000a93          	li	s5,256
    172c:	00001c97          	auipc	s9,0x1
    1730:	13cc8c93          	addi	s9,s9,316 # 2868 <enable_deadlock_detect+0x108>
    1734:	00001c17          	auipc	s8,0x1
    1738:	0acc0c13          	addi	s8,s8,172 # 27e0 <enable_deadlock_detect+0x80>
    173c:	00001b97          	auipc	s7,0x1
    1740:	16cb8b93          	addi	s7,s7,364 # 28a8 <enable_deadlock_detect+0x148>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1744:	4a29                	li	s4,10
    1746:	a031                	j	1752 <out_unlocked+0x66>
    1748:	09468863          	beq	a3,s4,17d8 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    174c:	0405                	addi	s0,s0,1
    174e:	04848163          	beq	s1,s0,1790 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1752:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1756:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    175a:	0017861b          	addiw	a2,a5,1
    175e:	97ea                	add	a5,a5,s10
    1760:	00cd2023          	sw	a2,0(s10)
    1764:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1768:	fec950e3          	bge	s2,a2,1748 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    176c:	05561263          	bne	a2,s5,17b0 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    1770:	85da                	mv	a1,s6
    1772:	4505                	li	a0,1
    1774:	515000ef          	jal	ra,2488 <write>
    1778:	2501                	sext.w	a0,a0
	buffer_len = 0;
    177a:	00001797          	auipc	a5,0x1
    177e:	1c07af23          	sw	zero,478(a5) # 2958 <buffer_len>
			if (r < 0) {
    1782:	06054763          	bltz	a0,17f0 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1786:	0405                	addi	s0,s0,1
			ret += r;
    1788:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    178c:	fc8493e3          	bne	s1,s0,1752 <out_unlocked+0x66>
}
    1790:	70a6                	ld	ra,104(sp)
    1792:	7406                	ld	s0,96(sp)
    1794:	64e6                	ld	s1,88(sp)
    1796:	6946                	ld	s2,80(sp)
    1798:	6a06                	ld	s4,64(sp)
    179a:	7ae2                	ld	s5,56(sp)
    179c:	7b42                	ld	s6,48(sp)
    179e:	7ba2                	ld	s7,40(sp)
    17a0:	7c02                	ld	s8,32(sp)
    17a2:	6ce2                	ld	s9,24(sp)
    17a4:	6d42                	ld	s10,16(sp)
    17a6:	6da2                	ld	s11,8(sp)
    17a8:	854e                	mv	a0,s3
    17aa:	69a6                	ld	s3,72(sp)
    17ac:	6165                	addi	sp,sp,112
    17ae:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17b0:	4e3000ef          	jal	ra,2492 <getpid>
    17b4:	8daa                	mv	s11,a0
    17b6:	8566                	mv	a0,s9
    17b8:	3b1000ef          	jal	ra,2368 <basename>
    17bc:	872a                	mv	a4,a0
    17be:	8662                	mv	a2,s8
    17c0:	05400793          	li	a5,84
    17c4:	86ee                	mv	a3,s11
    17c6:	45fd                	li	a1,31
    17c8:	855e                	mv	a0,s7
    17ca:	a97ff0ef          	jal	ra,1260 <printf>
    17ce:	557d                	li	a0,-1
    17d0:	4f3000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    17d4:	000d2603          	lw	a2,0(s10)
    17d8:	da35                	beqz	a2,174c <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    17da:	85da                	mv	a1,s6
    17dc:	4505                	li	a0,1
    17de:	4ab000ef          	jal	ra,2488 <write>
    17e2:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17e4:	00001797          	auipc	a5,0x1
    17e8:	1607aa23          	sw	zero,372(a5) # 2958 <buffer_len>
			if (r < 0) {
    17ec:	f8055de3          	bgez	a0,1786 <out_unlocked+0x9a>
    17f0:	89aa                	mv	s3,a0
    17f2:	bf79                	j	1790 <out_unlocked+0xa4>
	int ret = 0;
    17f4:	4981                	li	s3,0
    17f6:	bf69                	j	1790 <out_unlocked+0xa4>

00000000000017f8 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    17f8:	1101                	addi	sp,sp,-32
    17fa:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    17fc:	00001497          	auipc	s1,0x1
    1800:	15c48493          	addi	s1,s1,348 # 2958 <buffer_len>
    1804:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1806:	ec06                	sd	ra,24(sp)
    1808:	e822                	sd	s0,16(sp)
		char c = s[i];
    180a:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    180e:	0017861b          	addiw	a2,a5,1
    1812:	97a6                	add	a5,a5,s1
    1814:	00e78423          	sb	a4,8(a5)
    1818:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    181a:	0ff00793          	li	a5,255
    181e:	00c7cc63          	blt	a5,a2,1836 <out_unlocked.constprop.0+0x3e>
    1822:	47a9                	li	a5,10
    1824:	06f70c63          	beq	a4,a5,189c <out_unlocked.constprop.0+0xa4>
    1828:	4601                	li	a2,0
}
    182a:	60e2                	ld	ra,24(sp)
    182c:	6442                	ld	s0,16(sp)
    182e:	64a2                	ld	s1,8(sp)
    1830:	8532                	mv	a0,a2
    1832:	6105                	addi	sp,sp,32
    1834:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1836:	10000793          	li	a5,256
    183a:	02f61563          	bne	a2,a5,1864 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    183e:	00001597          	auipc	a1,0x1
    1842:	12258593          	addi	a1,a1,290 # 2960 <buffer>
    1846:	4505                	li	a0,1
    1848:	441000ef          	jal	ra,2488 <write>
}
    184c:	60e2                	ld	ra,24(sp)
    184e:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1850:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1854:	00001797          	auipc	a5,0x1
    1858:	1007a223          	sw	zero,260(a5) # 2958 <buffer_len>
}
    185c:	64a2                	ld	s1,8(sp)
    185e:	8532                	mv	a0,a2
    1860:	6105                	addi	sp,sp,32
    1862:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1864:	42f000ef          	jal	ra,2492 <getpid>
    1868:	842a                	mv	s0,a0
    186a:	00001517          	auipc	a0,0x1
    186e:	ffe50513          	addi	a0,a0,-2 # 2868 <enable_deadlock_detect+0x108>
    1872:	2f7000ef          	jal	ra,2368 <basename>
    1876:	872a                	mv	a4,a0
    1878:	00001617          	auipc	a2,0x1
    187c:	f6860613          	addi	a2,a2,-152 # 27e0 <enable_deadlock_detect+0x80>
    1880:	05400793          	li	a5,84
    1884:	86a2                	mv	a3,s0
    1886:	45fd                	li	a1,31
    1888:	00001517          	auipc	a0,0x1
    188c:	02050513          	addi	a0,a0,32 # 28a8 <enable_deadlock_detect+0x148>
    1890:	9d1ff0ef          	jal	ra,1260 <printf>
    1894:	557d                	li	a0,-1
    1896:	42d000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    189a:	4090                	lw	a2,0(s1)
    189c:	d659                	beqz	a2,182a <out_unlocked.constprop.0+0x32>
    189e:	b745                	j	183e <out_unlocked.constprop.0+0x46>

00000000000018a0 <putchar>:
{
    18a0:	7139                	addi	sp,sp,-64
    18a2:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18a4:	00001497          	auipc	s1,0x1
    18a8:	0b448493          	addi	s1,s1,180 # 2958 <buffer_len>
    18ac:	1084a703          	lw	a4,264(s1)
{
    18b0:	f822                	sd	s0,48(sp)
	char byte = c;
    18b2:	0ff57413          	zext.b	s0,a0
{
    18b6:	fc06                	sd	ra,56(sp)
	char byte = c;
    18b8:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18bc:	4785                	li	a5,1
    18be:	00f70d63          	beq	a4,a5,18d8 <putchar+0x38>
		len = out_unlocked(s, l);
    18c2:	01f10513          	addi	a0,sp,31
    18c6:	f33ff0ef          	jal	ra,17f8 <out_unlocked.constprop.0>
}
    18ca:	70e2                	ld	ra,56(sp)
    18cc:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    18ce:	862a                	mv	a2,a0
}
    18d0:	74a2                	ld	s1,40(sp)
    18d2:	8532                	mv	a0,a2
    18d4:	6121                	addi	sp,sp,64
    18d6:	8082                	ret
		mutex_lock(buffer_lock);
    18d8:	10c4a503          	lw	a0,268(s1)
    18dc:	625000ef          	jal	ra,2700 <mutex_lock>
		buffer[buffer_len++] = c;
    18e0:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18e2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    18e6:	0017861b          	addiw	a2,a5,1
    18ea:	97a6                	add	a5,a5,s1
    18ec:	c090                	sw	a2,0(s1)
    18ee:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18f2:	02c6c263          	blt	a3,a2,1916 <putchar+0x76>
    18f6:	47a9                	li	a5,10
    18f8:	06f40d63          	beq	s0,a5,1972 <putchar+0xd2>
    18fc:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    18fe:	10c4a503          	lw	a0,268(s1)
    1902:	e432                	sd	a2,8(sp)
    1904:	609000ef          	jal	ra,270c <mutex_unlock>
    1908:	6622                	ld	a2,8(sp)
}
    190a:	70e2                	ld	ra,56(sp)
    190c:	7442                	ld	s0,48(sp)
    190e:	74a2                	ld	s1,40(sp)
    1910:	8532                	mv	a0,a2
    1912:	6121                	addi	sp,sp,64
    1914:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1916:	10000793          	li	a5,256
    191a:	02f61063          	bne	a2,a5,193a <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    191e:	00001597          	auipc	a1,0x1
    1922:	04258593          	addi	a1,a1,66 # 2960 <buffer>
    1926:	4505                	li	a0,1
    1928:	361000ef          	jal	ra,2488 <write>
    192c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1930:	00001797          	auipc	a5,0x1
    1934:	0207a423          	sw	zero,40(a5) # 2958 <buffer_len>
			if (r < 0) {
    1938:	b7d9                	j	18fe <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    193a:	359000ef          	jal	ra,2492 <getpid>
    193e:	842a                	mv	s0,a0
    1940:	00001517          	auipc	a0,0x1
    1944:	f2850513          	addi	a0,a0,-216 # 2868 <enable_deadlock_detect+0x108>
    1948:	221000ef          	jal	ra,2368 <basename>
    194c:	872a                	mv	a4,a0
    194e:	00001617          	auipc	a2,0x1
    1952:	e9260613          	addi	a2,a2,-366 # 27e0 <enable_deadlock_detect+0x80>
    1956:	05400793          	li	a5,84
    195a:	86a2                	mv	a3,s0
    195c:	45fd                	li	a1,31
    195e:	00001517          	auipc	a0,0x1
    1962:	f4a50513          	addi	a0,a0,-182 # 28a8 <enable_deadlock_detect+0x148>
    1966:	8fbff0ef          	jal	ra,1260 <printf>
    196a:	557d                	li	a0,-1
    196c:	357000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    1970:	4090                	lw	a2,0(s1)
    1972:	d651                	beqz	a2,18fe <putchar+0x5e>
    1974:	b76d                	j	191e <putchar+0x7e>

0000000000001976 <puts>:
{
    1976:	7139                	addi	sp,sp,-64
    1978:	f822                	sd	s0,48(sp)
    197a:	f426                	sd	s1,40(sp)
    197c:	fc06                	sd	ra,56(sp)
    197e:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1980:	00001417          	auipc	s0,0x1
    1984:	fd840413          	addi	s0,s0,-40 # 2958 <buffer_len>
{
    1988:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    198a:	638000ef          	jal	ra,1fc2 <strlen>
	if (buffer_lock_enabled == 1) {
    198e:	10842703          	lw	a4,264(s0)
    1992:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1994:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1996:	04f70563          	beq	a4,a5,19e0 <puts+0x6a>
		len = out_unlocked(s, l);
    199a:	8526                	mv	a0,s1
    199c:	d51ff0ef          	jal	ra,16ec <out_unlocked>
    19a0:	892a                	mv	s2,a0
    19a2:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19a4:	00095963          	bgez	s2,19b6 <puts+0x40>
}
    19a8:	70e2                	ld	ra,56(sp)
    19aa:	7442                	ld	s0,48(sp)
    19ac:	7902                	ld	s2,32(sp)
    19ae:	8526                	mv	a0,s1
    19b0:	74a2                	ld	s1,40(sp)
    19b2:	6121                	addi	sp,sp,64
    19b4:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19b6:	10842703          	lw	a4,264(s0)
	char byte = c;
    19ba:	44a9                	li	s1,10
    19bc:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19c0:	4785                	li	a5,1
    19c2:	02f70e63          	beq	a4,a5,19fe <puts+0x88>
		len = out_unlocked(s, l);
    19c6:	01f10513          	addi	a0,sp,31
    19ca:	e2fff0ef          	jal	ra,17f8 <out_unlocked.constprop.0>
}
    19ce:	70e2                	ld	ra,56(sp)
    19d0:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19d2:	41f5549b          	sraiw	s1,a0,0x1f
}
    19d6:	7902                	ld	s2,32(sp)
    19d8:	8526                	mv	a0,s1
    19da:	74a2                	ld	s1,40(sp)
    19dc:	6121                	addi	sp,sp,64
    19de:	8082                	ret
		mutex_lock(buffer_lock);
    19e0:	e42a                	sd	a0,8(sp)
    19e2:	10c42503          	lw	a0,268(s0)
    19e6:	51b000ef          	jal	ra,2700 <mutex_lock>
		len = out_unlocked(s, l);
    19ea:	65a2                	ld	a1,8(sp)
    19ec:	8526                	mv	a0,s1
    19ee:	cffff0ef          	jal	ra,16ec <out_unlocked>
    19f2:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    19f4:	10c42503          	lw	a0,268(s0)
    19f8:	515000ef          	jal	ra,270c <mutex_unlock>
    19fc:	b75d                	j	19a2 <puts+0x2c>
		mutex_lock(buffer_lock);
    19fe:	10c42503          	lw	a0,268(s0)
    1a02:	4ff000ef          	jal	ra,2700 <mutex_lock>
		buffer[buffer_len++] = c;
    1a06:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a08:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a0c:	0017861b          	addiw	a2,a5,1
    1a10:	97a2                	add	a5,a5,s0
    1a12:	c010                	sw	a2,0(s0)
    1a14:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a18:	06c6dc63          	bge	a3,a2,1a90 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a1c:	10000793          	li	a5,256
    1a20:	02f61c63          	bne	a2,a5,1a58 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a24:	00001597          	auipc	a1,0x1
    1a28:	f3c58593          	addi	a1,a1,-196 # 2960 <buffer>
    1a2c:	4505                	li	a0,1
    1a2e:	25b000ef          	jal	ra,2488 <write>
			if (r < 0) {
    1a32:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a34:	00001797          	auipc	a5,0x1
    1a38:	f207a223          	sw	zero,-220(a5) # 2958 <buffer_len>
			if (r < 0) {
    1a3c:	04054c63          	bltz	a0,1a94 <puts+0x11e>
			if (r < buffer_len) {
    1a40:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a42:	10c42503          	lw	a0,268(s0)
    1a46:	4c7000ef          	jal	ra,270c <mutex_unlock>
}
    1a4a:	70e2                	ld	ra,56(sp)
    1a4c:	7442                	ld	s0,48(sp)
    1a4e:	7902                	ld	s2,32(sp)
    1a50:	8526                	mv	a0,s1
    1a52:	74a2                	ld	s1,40(sp)
    1a54:	6121                	addi	sp,sp,64
    1a56:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a58:	23b000ef          	jal	ra,2492 <getpid>
    1a5c:	84aa                	mv	s1,a0
    1a5e:	00001517          	auipc	a0,0x1
    1a62:	e0a50513          	addi	a0,a0,-502 # 2868 <enable_deadlock_detect+0x108>
    1a66:	103000ef          	jal	ra,2368 <basename>
    1a6a:	872a                	mv	a4,a0
    1a6c:	00001617          	auipc	a2,0x1
    1a70:	d7460613          	addi	a2,a2,-652 # 27e0 <enable_deadlock_detect+0x80>
    1a74:	05400793          	li	a5,84
    1a78:	86a6                	mv	a3,s1
    1a7a:	45fd                	li	a1,31
    1a7c:	00001517          	auipc	a0,0x1
    1a80:	e2c50513          	addi	a0,a0,-468 # 28a8 <enable_deadlock_detect+0x148>
    1a84:	fdcff0ef          	jal	ra,1260 <printf>
    1a88:	557d                	li	a0,-1
    1a8a:	239000ef          	jal	ra,24c2 <exit>
	if (buffer_len == 0)
    1a8e:	4010                	lw	a2,0(s0)
    1a90:	da45                	beqz	a2,1a40 <puts+0xca>
    1a92:	bf49                	j	1a24 <puts+0xae>
    1a94:	54fd                	li	s1,-1
    1a96:	b775                	j	1a42 <puts+0xcc>

0000000000001a98 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a98:	715d                	addi	sp,sp,-80
    1a9a:	e486                	sd	ra,72(sp)
    1a9c:	e0a2                	sd	s0,64(sp)
    1a9e:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1aa0:	14054363          	bltz	a0,1be6 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1aa4:	02b577bb          	remuw	a5,a0,a1
    1aa8:	00001617          	auipc	a2,0x1
    1aac:	fc860613          	addi	a2,a2,-56 # 2a70 <digits>
	buf[16] = 0;
    1ab0:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ab4:	0005871b          	sext.w	a4,a1
    1ab8:	1782                	slli	a5,a5,0x20
    1aba:	9381                	srli	a5,a5,0x20
    1abc:	97b2                	add	a5,a5,a2
    1abe:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ac2:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1ac6:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1aca:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1acc:	0eb56763          	bltu	a0,a1,1bba <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1ad0:	02e877bb          	remuw	a5,a6,a4
    1ad4:	1782                	slli	a5,a5,0x20
    1ad6:	9381                	srli	a5,a5,0x20
    1ad8:	97b2                	add	a5,a5,a2
    1ada:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ade:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1ae2:	02f10323          	sb	a5,38(sp)
    1ae6:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1ae8:	0ce86963          	bltu	a6,a4,1bba <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1aec:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1af0:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1af4:	1582                	slli	a1,a1,0x20
    1af6:	9181                	srli	a1,a1,0x20
    1af8:	95b2                	add	a1,a1,a2
    1afa:	0005c583          	lbu	a1,0(a1)
    1afe:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b02:	0007859b          	sext.w	a1,a5
    1b06:	16e6e563          	bltu	a3,a4,1c70 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b0a:	02e7f6bb          	remuw	a3,a5,a4
    1b0e:	1682                	slli	a3,a3,0x20
    1b10:	9281                	srli	a3,a3,0x20
    1b12:	96b2                	add	a3,a3,a2
    1b14:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b18:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b1c:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b20:	16e5e163          	bltu	a1,a4,1c82 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b24:	02e876bb          	remuw	a3,a6,a4
    1b28:	1682                	slli	a3,a3,0x20
    1b2a:	9281                	srli	a3,a3,0x20
    1b2c:	96b2                	add	a3,a3,a2
    1b2e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b32:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b36:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b3a:	14e86d63          	bltu	a6,a4,1c94 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b3e:	02e5f6bb          	remuw	a3,a1,a4
    1b42:	1682                	slli	a3,a3,0x20
    1b44:	9281                	srli	a3,a3,0x20
    1b46:	96b2                	add	a3,a3,a2
    1b48:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b4c:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b50:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b54:	10e5e563          	bltu	a1,a4,1c5e <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b58:	02e876bb          	remuw	a3,a6,a4
    1b5c:	1682                	slli	a3,a3,0x20
    1b5e:	9281                	srli	a3,a3,0x20
    1b60:	96b2                	add	a3,a3,a2
    1b62:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b66:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b6a:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b6e:	14e86263          	bltu	a6,a4,1cb2 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b72:	02e5f6bb          	remuw	a3,a1,a4
    1b76:	1682                	slli	a3,a3,0x20
    1b78:	9281                	srli	a3,a3,0x20
    1b7a:	96b2                	add	a3,a3,a2
    1b7c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b80:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b84:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b88:	14e5e463          	bltu	a1,a4,1cd0 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b8c:	02e876bb          	remuw	a3,a6,a4
    1b90:	1682                	slli	a3,a3,0x20
    1b92:	9281                	srli	a3,a3,0x20
    1b94:	96b2                	add	a3,a3,a2
    1b96:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b9a:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b9e:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1ba2:	14e86063          	bltu	a6,a4,1ce2 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1ba6:	1782                	slli	a5,a5,0x20
    1ba8:	9381                	srli	a5,a5,0x20
    1baa:	97b2                	add	a5,a5,a2
    1bac:	0007c703          	lbu	a4,0(a5)
    1bb0:	4799                	li	a5,6
    1bb2:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1bb6:	10054763          	bltz	a0,1cc4 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1bba:	00001497          	auipc	s1,0x1
    1bbe:	d9e48493          	addi	s1,s1,-610 # 2958 <buffer_len>
    1bc2:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1bc6:	0828                	addi	a0,sp,24
    1bc8:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1bca:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1bcc:	00f50433          	add	s0,a0,a5
    1bd0:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1bd2:	06e68463          	beq	a3,a4,1c3a <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1bd6:	8522                	mv	a0,s0
    1bd8:	b15ff0ef          	jal	ra,16ec <out_unlocked>
}
    1bdc:	60a6                	ld	ra,72(sp)
    1bde:	6406                	ld	s0,64(sp)
    1be0:	74e2                	ld	s1,56(sp)
    1be2:	6161                	addi	sp,sp,80
    1be4:	8082                	ret
		x = -xx;
    1be6:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1bea:	02b877bb          	remuw	a5,a6,a1
    1bee:	00001617          	auipc	a2,0x1
    1bf2:	e8260613          	addi	a2,a2,-382 # 2a70 <digits>
	buf[16] = 0;
    1bf6:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1bfa:	0005871b          	sext.w	a4,a1
    1bfe:	1782                	slli	a5,a5,0x20
    1c00:	9381                	srli	a5,a5,0x20
    1c02:	97b2                	add	a5,a5,a2
    1c04:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c08:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c0c:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c10:	08b86b63          	bltu	a6,a1,1ca6 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c14:	02e8f7bb          	remuw	a5,a7,a4
    1c18:	1782                	slli	a5,a5,0x20
    1c1a:	9381                	srli	a5,a5,0x20
    1c1c:	97b2                	add	a5,a5,a2
    1c1e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c22:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c26:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c2a:	ece8f1e3          	bgeu	a7,a4,1aec <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c2e:	02d00793          	li	a5,45
    1c32:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c36:	47b5                	li	a5,13
    1c38:	b749                	j	1bba <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c3a:	10c4a503          	lw	a0,268(s1)
    1c3e:	e42e                	sd	a1,8(sp)
    1c40:	2c1000ef          	jal	ra,2700 <mutex_lock>
		len = out_unlocked(s, l);
    1c44:	65a2                	ld	a1,8(sp)
    1c46:	8522                	mv	a0,s0
    1c48:	aa5ff0ef          	jal	ra,16ec <out_unlocked>
		mutex_unlock(buffer_lock);
    1c4c:	10c4a503          	lw	a0,268(s1)
    1c50:	2bd000ef          	jal	ra,270c <mutex_unlock>
}
    1c54:	60a6                	ld	ra,72(sp)
    1c56:	6406                	ld	s0,64(sp)
    1c58:	74e2                	ld	s1,56(sp)
    1c5a:	6161                	addi	sp,sp,80
    1c5c:	8082                	ret
		buf[i--] = digits[x % base];
    1c5e:	47a9                	li	a5,10
	if (sign)
    1c60:	f4055de3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c64:	02d00793          	li	a5,45
    1c68:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c6c:	47a5                	li	a5,9
    1c6e:	b7b1                	j	1bba <printint.constprop.0+0x122>
    1c70:	47b5                	li	a5,13
	if (sign)
    1c72:	f40554e3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c76:	02d00793          	li	a5,45
    1c7a:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c7e:	47b1                	li	a5,12
    1c80:	bf2d                	j	1bba <printint.constprop.0+0x122>
    1c82:	47b1                	li	a5,12
	if (sign)
    1c84:	f2055be3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c88:	02d00793          	li	a5,45
    1c8c:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c90:	47ad                	li	a5,11
    1c92:	b725                	j	1bba <printint.constprop.0+0x122>
    1c94:	47ad                	li	a5,11
	if (sign)
    1c96:	f20552e3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c9a:	02d00793          	li	a5,45
    1c9e:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ca2:	47a9                	li	a5,10
    1ca4:	bf19                	j	1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca6:	02d00793          	li	a5,45
    1caa:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cae:	47b9                	li	a5,14
    1cb0:	b729                	j	1bba <printint.constprop.0+0x122>
    1cb2:	47a5                	li	a5,9
	if (sign)
    1cb4:	f00553e3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb8:	02d00793          	li	a5,45
    1cbc:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1cc0:	47a1                	li	a5,8
    1cc2:	bde5                	j	1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc4:	02d00793          	li	a5,45
    1cc8:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1ccc:	4795                	li	a5,5
    1cce:	b5f5                	j	1bba <printint.constprop.0+0x122>
    1cd0:	47a1                	li	a5,8
	if (sign)
    1cd2:	ee0554e3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd6:	02d00793          	li	a5,45
    1cda:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1cde:	479d                	li	a5,7
    1ce0:	bde9                	j	1bba <printint.constprop.0+0x122>
    1ce2:	479d                	li	a5,7
	if (sign)
    1ce4:	ec055be3          	bgez	a0,1bba <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce8:	02d00793          	li	a5,45
    1cec:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1cf0:	4799                	li	a5,6
    1cf2:	b5e1                	j	1bba <printint.constprop.0+0x122>

0000000000001cf4 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cf4:	02000793          	li	a5,32
    1cf8:	00f50663          	beq	a0,a5,1d04 <isspace+0x10>
    1cfc:	355d                	addiw	a0,a0,-9
    1cfe:	00553513          	sltiu	a0,a0,5
    1d02:	8082                	ret
    1d04:	4505                	li	a0,1
}
    1d06:	8082                	ret

0000000000001d08 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d08:	fd05051b          	addiw	a0,a0,-48
}
    1d0c:	00a53513          	sltiu	a0,a0,10
    1d10:	8082                	ret

0000000000001d12 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d12:	02000613          	li	a2,32
    1d16:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d18:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d1c:	ff77869b          	addiw	a3,a5,-9
    1d20:	04c78c63          	beq	a5,a2,1d78 <atoi+0x66>
    1d24:	0007871b          	sext.w	a4,a5
    1d28:	04d5f863          	bgeu	a1,a3,1d78 <atoi+0x66>
		s++;
	switch (*s) {
    1d2c:	02b00693          	li	a3,43
    1d30:	04d78963          	beq	a5,a3,1d82 <atoi+0x70>
    1d34:	02d00693          	li	a3,45
    1d38:	06d78263          	beq	a5,a3,1d9c <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d3c:	fd07061b          	addiw	a2,a4,-48
    1d40:	47a5                	li	a5,9
    1d42:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d44:	4e01                	li	t3,0
	while (isdigit(*s))
    1d46:	04c7e963          	bltu	a5,a2,1d98 <atoi+0x86>
	int n = 0, neg = 0;
    1d4a:	4501                	li	a0,0
	while (isdigit(*s))
    1d4c:	4825                	li	a6,9
    1d4e:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d52:	0025179b          	slliw	a5,a0,0x2
    1d56:	9fa9                	addw	a5,a5,a0
    1d58:	fd07031b          	addiw	t1,a4,-48
    1d5c:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d60:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1d64:	0685                	addi	a3,a3,1
    1d66:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d6a:	0006071b          	sext.w	a4,a2
    1d6e:	feb870e3          	bgeu	a6,a1,1d4e <atoi+0x3c>
	return neg ? n : -n;
    1d72:	000e0563          	beqz	t3,1d7c <atoi+0x6a>
}
    1d76:	8082                	ret
		s++;
    1d78:	0505                	addi	a0,a0,1
    1d7a:	bf79                	j	1d18 <atoi+0x6>
	return neg ? n : -n;
    1d7c:	4113053b          	subw	a0,t1,a7
    1d80:	8082                	ret
	while (isdigit(*s))
    1d82:	00154703          	lbu	a4,1(a0)
    1d86:	47a5                	li	a5,9
		s++;
    1d88:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d8c:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d90:	4e01                	li	t3,0
	while (isdigit(*s))
    1d92:	2701                	sext.w	a4,a4
    1d94:	fac7fbe3          	bgeu	a5,a2,1d4a <atoi+0x38>
    1d98:	4501                	li	a0,0
}
    1d9a:	8082                	ret
	while (isdigit(*s))
    1d9c:	00154703          	lbu	a4,1(a0)
    1da0:	47a5                	li	a5,9
		s++;
    1da2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1da6:	fd07061b          	addiw	a2,a4,-48
    1daa:	2701                	sext.w	a4,a4
    1dac:	fec7e6e3          	bltu	a5,a2,1d98 <atoi+0x86>
		neg = 1;
    1db0:	4e05                	li	t3,1
    1db2:	bf61                	j	1d4a <atoi+0x38>

0000000000001db4 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1db4:	16060d63          	beqz	a2,1f2e <memset+0x17a>
    1db8:	40a007b3          	neg	a5,a0
    1dbc:	8b9d                	andi	a5,a5,7
    1dbe:	00778693          	addi	a3,a5,7
    1dc2:	482d                	li	a6,11
    1dc4:	0ff5f713          	zext.b	a4,a1
    1dc8:	fff60593          	addi	a1,a2,-1
    1dcc:	1706e263          	bltu	a3,a6,1f30 <memset+0x17c>
    1dd0:	16d5ea63          	bltu	a1,a3,1f44 <memset+0x190>
    1dd4:	16078563          	beqz	a5,1f3e <memset+0x18a>
    1dd8:	00e50023          	sb	a4,0(a0)
    1ddc:	4685                	li	a3,1
    1dde:	00150593          	addi	a1,a0,1
    1de2:	14d78c63          	beq	a5,a3,1f3a <memset+0x186>
    1de6:	00e500a3          	sb	a4,1(a0)
    1dea:	4689                	li	a3,2
    1dec:	00250593          	addi	a1,a0,2
    1df0:	14d78d63          	beq	a5,a3,1f4a <memset+0x196>
    1df4:	00e50123          	sb	a4,2(a0)
    1df8:	468d                	li	a3,3
    1dfa:	00350593          	addi	a1,a0,3
    1dfe:	12d78b63          	beq	a5,a3,1f34 <memset+0x180>
    1e02:	00e501a3          	sb	a4,3(a0)
    1e06:	4691                	li	a3,4
    1e08:	00450593          	addi	a1,a0,4
    1e0c:	14d78163          	beq	a5,a3,1f4e <memset+0x19a>
    1e10:	00e50223          	sb	a4,4(a0)
    1e14:	4695                	li	a3,5
    1e16:	00550593          	addi	a1,a0,5
    1e1a:	12d78c63          	beq	a5,a3,1f52 <memset+0x19e>
    1e1e:	00e502a3          	sb	a4,5(a0)
    1e22:	469d                	li	a3,7
    1e24:	00650593          	addi	a1,a0,6
    1e28:	12d79763          	bne	a5,a3,1f56 <memset+0x1a2>
    1e2c:	00750593          	addi	a1,a0,7
    1e30:	00e50323          	sb	a4,6(a0)
    1e34:	481d                	li	a6,7
    1e36:	00871693          	slli	a3,a4,0x8
    1e3a:	01071893          	slli	a7,a4,0x10
    1e3e:	8ed9                	or	a3,a3,a4
    1e40:	01871313          	slli	t1,a4,0x18
    1e44:	0116e6b3          	or	a3,a3,a7
    1e48:	0066e6b3          	or	a3,a3,t1
    1e4c:	02071893          	slli	a7,a4,0x20
    1e50:	02871e13          	slli	t3,a4,0x28
    1e54:	0116e6b3          	or	a3,a3,a7
    1e58:	40f60333          	sub	t1,a2,a5
    1e5c:	03071893          	slli	a7,a4,0x30
    1e60:	01c6e6b3          	or	a3,a3,t3
    1e64:	0116e6b3          	or	a3,a3,a7
    1e68:	03871e13          	slli	t3,a4,0x38
    1e6c:	97aa                	add	a5,a5,a0
    1e6e:	ff837893          	andi	a7,t1,-8
    1e72:	01c6e6b3          	or	a3,a3,t3
    1e76:	98be                	add	a7,a7,a5
    1e78:	e394                	sd	a3,0(a5)
    1e7a:	07a1                	addi	a5,a5,8
    1e7c:	ff179ee3          	bne	a5,a7,1e78 <memset+0xc4>
    1e80:	ff837893          	andi	a7,t1,-8
    1e84:	011587b3          	add	a5,a1,a7
    1e88:	010886bb          	addw	a3,a7,a6
    1e8c:	0b130663          	beq	t1,a7,1f38 <memset+0x184>
    1e90:	00e78023          	sb	a4,0(a5)
    1e94:	0016859b          	addiw	a1,a3,1
    1e98:	08c5fb63          	bgeu	a1,a2,1f2e <memset+0x17a>
    1e9c:	00e780a3          	sb	a4,1(a5)
    1ea0:	0026859b          	addiw	a1,a3,2
    1ea4:	08c5f563          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ea8:	00e78123          	sb	a4,2(a5)
    1eac:	0036859b          	addiw	a1,a3,3
    1eb0:	06c5ff63          	bgeu	a1,a2,1f2e <memset+0x17a>
    1eb4:	00e781a3          	sb	a4,3(a5)
    1eb8:	0046859b          	addiw	a1,a3,4
    1ebc:	06c5f963          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ec0:	00e78223          	sb	a4,4(a5)
    1ec4:	0056859b          	addiw	a1,a3,5
    1ec8:	06c5f363          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ecc:	00e782a3          	sb	a4,5(a5)
    1ed0:	0066859b          	addiw	a1,a3,6
    1ed4:	04c5fd63          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ed8:	00e78323          	sb	a4,6(a5)
    1edc:	0076859b          	addiw	a1,a3,7
    1ee0:	04c5f763          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ee4:	00e783a3          	sb	a4,7(a5)
    1ee8:	0086859b          	addiw	a1,a3,8
    1eec:	04c5f163          	bgeu	a1,a2,1f2e <memset+0x17a>
    1ef0:	00e78423          	sb	a4,8(a5)
    1ef4:	0096859b          	addiw	a1,a3,9
    1ef8:	02c5fb63          	bgeu	a1,a2,1f2e <memset+0x17a>
    1efc:	00e784a3          	sb	a4,9(a5)
    1f00:	00a6859b          	addiw	a1,a3,10
    1f04:	02c5f563          	bgeu	a1,a2,1f2e <memset+0x17a>
    1f08:	00e78523          	sb	a4,10(a5)
    1f0c:	00b6859b          	addiw	a1,a3,11
    1f10:	00c5ff63          	bgeu	a1,a2,1f2e <memset+0x17a>
    1f14:	00e785a3          	sb	a4,11(a5)
    1f18:	00c6859b          	addiw	a1,a3,12
    1f1c:	00c5f963          	bgeu	a1,a2,1f2e <memset+0x17a>
    1f20:	00e78623          	sb	a4,12(a5)
    1f24:	26b5                	addiw	a3,a3,13
    1f26:	00c6f463          	bgeu	a3,a2,1f2e <memset+0x17a>
    1f2a:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f2e:	8082                	ret
    1f30:	46ad                	li	a3,11
    1f32:	bd79                	j	1dd0 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f34:	480d                	li	a6,3
    1f36:	b701                	j	1e36 <memset+0x82>
    1f38:	8082                	ret
    1f3a:	4805                	li	a6,1
    1f3c:	bded                	j	1e36 <memset+0x82>
    1f3e:	85aa                	mv	a1,a0
    1f40:	4801                	li	a6,0
    1f42:	bdd5                	j	1e36 <memset+0x82>
    1f44:	87aa                	mv	a5,a0
    1f46:	4681                	li	a3,0
    1f48:	b7a1                	j	1e90 <memset+0xdc>
    1f4a:	4809                	li	a6,2
    1f4c:	b5ed                	j	1e36 <memset+0x82>
    1f4e:	4811                	li	a6,4
    1f50:	b5dd                	j	1e36 <memset+0x82>
    1f52:	4815                	li	a6,5
    1f54:	b5cd                	j	1e36 <memset+0x82>
    1f56:	4819                	li	a6,6
    1f58:	bdf9                	j	1e36 <memset+0x82>

0000000000001f5a <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f5a:	00054783          	lbu	a5,0(a0)
    1f5e:	0005c703          	lbu	a4,0(a1)
    1f62:	00e79863          	bne	a5,a4,1f72 <strcmp+0x18>
    1f66:	0505                	addi	a0,a0,1
    1f68:	0585                	addi	a1,a1,1
    1f6a:	fbe5                	bnez	a5,1f5a <strcmp>
    1f6c:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f6e:	9d19                	subw	a0,a0,a4
    1f70:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f72:	0007851b          	sext.w	a0,a5
    1f76:	bfe5                	j	1f6e <strcmp+0x14>

0000000000001f78 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f78:	ca15                	beqz	a2,1fac <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f7a:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f7e:	167d                	addi	a2,a2,-1
    1f80:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f84:	eb99                	bnez	a5,1f9a <strncmp+0x22>
    1f86:	a815                	j	1fba <strncmp+0x42>
    1f88:	00a68e63          	beq	a3,a0,1fa4 <strncmp+0x2c>
    1f8c:	0505                	addi	a0,a0,1
    1f8e:	00f71b63          	bne	a4,a5,1fa4 <strncmp+0x2c>
    1f92:	00054783          	lbu	a5,0(a0)
    1f96:	cf89                	beqz	a5,1fb0 <strncmp+0x38>
    1f98:	85b2                	mv	a1,a2
    1f9a:	0005c703          	lbu	a4,0(a1)
    1f9e:	00158613          	addi	a2,a1,1
    1fa2:	f37d                	bnez	a4,1f88 <strncmp+0x10>
		;
	return *l - *r;
    1fa4:	0007851b          	sext.w	a0,a5
    1fa8:	9d19                	subw	a0,a0,a4
    1faa:	8082                	ret
		return 0;
    1fac:	4501                	li	a0,0
}
    1fae:	8082                	ret
	return *l - *r;
    1fb0:	0015c703          	lbu	a4,1(a1)
    1fb4:	4501                	li	a0,0
    1fb6:	9d19                	subw	a0,a0,a4
    1fb8:	8082                	ret
    1fba:	0005c703          	lbu	a4,0(a1)
    1fbe:	4501                	li	a0,0
    1fc0:	b7e5                	j	1fa8 <strncmp+0x30>

0000000000001fc2 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1fc2:	00757793          	andi	a5,a0,7
    1fc6:	cf89                	beqz	a5,1fe0 <strlen+0x1e>
    1fc8:	87aa                	mv	a5,a0
    1fca:	a029                	j	1fd4 <strlen+0x12>
    1fcc:	0785                	addi	a5,a5,1
    1fce:	0077f713          	andi	a4,a5,7
    1fd2:	cb01                	beqz	a4,1fe2 <strlen+0x20>
		if (!*s)
    1fd4:	0007c703          	lbu	a4,0(a5)
    1fd8:	fb75                	bnez	a4,1fcc <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1fda:	40a78533          	sub	a0,a5,a0
}
    1fde:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1fe0:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1fe2:	6394                	ld	a3,0(a5)
    1fe4:	00001597          	auipc	a1,0x1
    1fe8:	95c5b583          	ld	a1,-1700(a1) # 2940 <enable_deadlock_detect+0x1e0>
    1fec:	00001617          	auipc	a2,0x1
    1ff0:	95c63603          	ld	a2,-1700(a2) # 2948 <enable_deadlock_detect+0x1e8>
    1ff4:	a019                	j	1ffa <strlen+0x38>
    1ff6:	6794                	ld	a3,8(a5)
    1ff8:	07a1                	addi	a5,a5,8
    1ffa:	00b68733          	add	a4,a3,a1
    1ffe:	fff6c693          	not	a3,a3
    2002:	8f75                	and	a4,a4,a3
    2004:	8f71                	and	a4,a4,a2
    2006:	db65                	beqz	a4,1ff6 <strlen+0x34>
	for (; *s; s++)
    2008:	0007c703          	lbu	a4,0(a5)
    200c:	d779                	beqz	a4,1fda <strlen+0x18>
    200e:	0017c703          	lbu	a4,1(a5)
    2012:	0785                	addi	a5,a5,1
    2014:	d379                	beqz	a4,1fda <strlen+0x18>
    2016:	0017c703          	lbu	a4,1(a5)
    201a:	0785                	addi	a5,a5,1
    201c:	fb6d                	bnez	a4,200e <strlen+0x4c>
    201e:	bf75                	j	1fda <strlen+0x18>

0000000000002020 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2020:	00757713          	andi	a4,a0,7
{
    2024:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2026:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    202a:	cb19                	beqz	a4,2040 <memchr+0x20>
    202c:	ce25                	beqz	a2,20a4 <memchr+0x84>
    202e:	0007c703          	lbu	a4,0(a5)
    2032:	04b70e63          	beq	a4,a1,208e <memchr+0x6e>
    2036:	0785                	addi	a5,a5,1
    2038:	0077f713          	andi	a4,a5,7
    203c:	167d                	addi	a2,a2,-1
    203e:	f77d                	bnez	a4,202c <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2040:	4501                	li	a0,0
	if (n && *s != c) {
    2042:	c235                	beqz	a2,20a6 <memchr+0x86>
    2044:	0007c703          	lbu	a4,0(a5)
    2048:	04b70363          	beq	a4,a1,208e <memchr+0x6e>
		size_t k = ONES * c;
    204c:	00001517          	auipc	a0,0x1
    2050:	90453503          	ld	a0,-1788(a0) # 2950 <enable_deadlock_detect+0x1f0>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2054:	471d                	li	a4,7
		size_t k = ONES * c;
    2056:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    205a:	02c77a63          	bgeu	a4,a2,208e <memchr+0x6e>
    205e:	00001897          	auipc	a7,0x1
    2062:	8e28b883          	ld	a7,-1822(a7) # 2940 <enable_deadlock_detect+0x1e0>
    2066:	00001817          	auipc	a6,0x1
    206a:	8e283803          	ld	a6,-1822(a6) # 2948 <enable_deadlock_detect+0x1e8>
    206e:	431d                	li	t1,7
    2070:	a029                	j	207a <memchr+0x5a>
		     w++, n -= SS)
    2072:	1661                	addi	a2,a2,-8
    2074:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2076:	02c37963          	bgeu	t1,a2,20a8 <memchr+0x88>
    207a:	6398                	ld	a4,0(a5)
    207c:	8f29                	xor	a4,a4,a0
    207e:	011706b3          	add	a3,a4,a7
    2082:	fff74713          	not	a4,a4
    2086:	8f75                	and	a4,a4,a3
    2088:	01077733          	and	a4,a4,a6
    208c:	d37d                	beqz	a4,2072 <memchr+0x52>
{
    208e:	853e                	mv	a0,a5
    2090:	97b2                	add	a5,a5,a2
    2092:	a021                	j	209a <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2094:	0505                	addi	a0,a0,1
    2096:	00f50763          	beq	a0,a5,20a4 <memchr+0x84>
    209a:	00054703          	lbu	a4,0(a0)
    209e:	feb71be3          	bne	a4,a1,2094 <memchr+0x74>
    20a2:	8082                	ret
	return n ? (void *)s : 0;
    20a4:	4501                	li	a0,0
}
    20a6:	8082                	ret
	return n ? (void *)s : 0;
    20a8:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20aa:	f275                	bnez	a2,208e <memchr+0x6e>
}
    20ac:	8082                	ret

00000000000020ae <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20ae:	1101                	addi	sp,sp,-32
    20b0:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20b2:	862e                	mv	a2,a1
{
    20b4:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20b6:	4581                	li	a1,0
{
    20b8:	e426                	sd	s1,8(sp)
    20ba:	ec06                	sd	ra,24(sp)
    20bc:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20be:	f63ff0ef          	jal	ra,2020 <memchr>
	return p ? p - s : n;
    20c2:	c519                	beqz	a0,20d0 <strnlen+0x22>
}
    20c4:	60e2                	ld	ra,24(sp)
    20c6:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    20c8:	8d05                	sub	a0,a0,s1
}
    20ca:	64a2                	ld	s1,8(sp)
    20cc:	6105                	addi	sp,sp,32
    20ce:	8082                	ret
    20d0:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    20d2:	8522                	mv	a0,s0
}
    20d4:	6442                	ld	s0,16(sp)
    20d6:	64a2                	ld	s1,8(sp)
    20d8:	6105                	addi	sp,sp,32
    20da:	8082                	ret

00000000000020dc <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    20dc:	00a5c7b3          	xor	a5,a1,a0
    20e0:	8b9d                	andi	a5,a5,7
    20e2:	eb95                	bnez	a5,2116 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    20e4:	0075f793          	andi	a5,a1,7
    20e8:	e7b1                	bnez	a5,2134 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    20ea:	6198                	ld	a4,0(a1)
    20ec:	00001617          	auipc	a2,0x1
    20f0:	85463603          	ld	a2,-1964(a2) # 2940 <enable_deadlock_detect+0x1e0>
    20f4:	00001817          	auipc	a6,0x1
    20f8:	85483803          	ld	a6,-1964(a6) # 2948 <enable_deadlock_detect+0x1e8>
    20fc:	a029                	j	2106 <stpcpy+0x2a>
    20fe:	05a1                	addi	a1,a1,8
    2100:	e118                	sd	a4,0(a0)
    2102:	6198                	ld	a4,0(a1)
    2104:	0521                	addi	a0,a0,8
    2106:	00c707b3          	add	a5,a4,a2
    210a:	fff74693          	not	a3,a4
    210e:	8ff5                	and	a5,a5,a3
    2110:	0107f7b3          	and	a5,a5,a6
    2114:	d7ed                	beqz	a5,20fe <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2116:	0005c783          	lbu	a5,0(a1)
    211a:	00f50023          	sb	a5,0(a0)
    211e:	c785                	beqz	a5,2146 <stpcpy+0x6a>
    2120:	0015c783          	lbu	a5,1(a1)
    2124:	0505                	addi	a0,a0,1
    2126:	0585                	addi	a1,a1,1
    2128:	00f50023          	sb	a5,0(a0)
    212c:	fbf5                	bnez	a5,2120 <stpcpy+0x44>
		;
	return d;
}
    212e:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2130:	0505                	addi	a0,a0,1
    2132:	df45                	beqz	a4,20ea <stpcpy+0xe>
			if (!(*d = *s))
    2134:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2138:	0585                	addi	a1,a1,1
    213a:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    213e:	00f50023          	sb	a5,0(a0)
    2142:	f7fd                	bnez	a5,2130 <stpcpy+0x54>
}
    2144:	8082                	ret
    2146:	8082                	ret

0000000000002148 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2148:	00a5c7b3          	xor	a5,a1,a0
    214c:	8b9d                	andi	a5,a5,7
    214e:	1a079863          	bnez	a5,22fe <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2152:	0075f793          	andi	a5,a1,7
    2156:	16078463          	beqz	a5,22be <stpncpy+0x176>
    215a:	ea01                	bnez	a2,216a <stpncpy+0x22>
    215c:	a421                	j	2364 <stpncpy+0x21c>
    215e:	167d                	addi	a2,a2,-1
    2160:	0505                	addi	a0,a0,1
    2162:	14070e63          	beqz	a4,22be <stpncpy+0x176>
    2166:	1a060863          	beqz	a2,2316 <stpncpy+0x1ce>
    216a:	0005c783          	lbu	a5,0(a1)
    216e:	0585                	addi	a1,a1,1
    2170:	0075f713          	andi	a4,a1,7
    2174:	00f50023          	sb	a5,0(a0)
    2178:	f3fd                	bnez	a5,215e <stpncpy+0x16>
    217a:	4805                	li	a6,1
    217c:	1a061863          	bnez	a2,232c <stpncpy+0x1e4>
    2180:	40a007b3          	neg	a5,a0
    2184:	8b9d                	andi	a5,a5,7
    2186:	4681                	li	a3,0
    2188:	18061a63          	bnez	a2,231c <stpncpy+0x1d4>
    218c:	00778713          	addi	a4,a5,7
    2190:	45ad                	li	a1,11
    2192:	18b76363          	bltu	a4,a1,2318 <stpncpy+0x1d0>
    2196:	1ae6eb63          	bltu	a3,a4,234c <stpncpy+0x204>
    219a:	1a078363          	beqz	a5,2340 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    219e:	00050023          	sb	zero,0(a0)
    21a2:	4685                	li	a3,1
    21a4:	00150713          	addi	a4,a0,1
    21a8:	18d78f63          	beq	a5,a3,2346 <stpncpy+0x1fe>
    21ac:	000500a3          	sb	zero,1(a0)
    21b0:	4689                	li	a3,2
    21b2:	00250713          	addi	a4,a0,2
    21b6:	18d78e63          	beq	a5,a3,2352 <stpncpy+0x20a>
    21ba:	00050123          	sb	zero,2(a0)
    21be:	468d                	li	a3,3
    21c0:	00350713          	addi	a4,a0,3
    21c4:	16d78c63          	beq	a5,a3,233c <stpncpy+0x1f4>
    21c8:	000501a3          	sb	zero,3(a0)
    21cc:	4691                	li	a3,4
    21ce:	00450713          	addi	a4,a0,4
    21d2:	18d78263          	beq	a5,a3,2356 <stpncpy+0x20e>
    21d6:	00050223          	sb	zero,4(a0)
    21da:	4695                	li	a3,5
    21dc:	00550713          	addi	a4,a0,5
    21e0:	16d78d63          	beq	a5,a3,235a <stpncpy+0x212>
    21e4:	000502a3          	sb	zero,5(a0)
    21e8:	469d                	li	a3,7
    21ea:	00650713          	addi	a4,a0,6
    21ee:	16d79863          	bne	a5,a3,235e <stpncpy+0x216>
    21f2:	00750713          	addi	a4,a0,7
    21f6:	00050323          	sb	zero,6(a0)
    21fa:	40f80833          	sub	a6,a6,a5
    21fe:	ff887593          	andi	a1,a6,-8
    2202:	97aa                	add	a5,a5,a0
    2204:	95be                	add	a1,a1,a5
    2206:	0007b023          	sd	zero,0(a5)
    220a:	07a1                	addi	a5,a5,8
    220c:	feb79de3          	bne	a5,a1,2206 <stpncpy+0xbe>
    2210:	ff887593          	andi	a1,a6,-8
    2214:	9ead                	addw	a3,a3,a1
    2216:	00b707b3          	add	a5,a4,a1
    221a:	12b80863          	beq	a6,a1,234a <stpncpy+0x202>
    221e:	00078023          	sb	zero,0(a5)
    2222:	0016871b          	addiw	a4,a3,1
    2226:	0ec77863          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    222a:	000780a3          	sb	zero,1(a5)
    222e:	0026871b          	addiw	a4,a3,2
    2232:	0ec77263          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    2236:	00078123          	sb	zero,2(a5)
    223a:	0036871b          	addiw	a4,a3,3
    223e:	0cc77c63          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    2242:	000781a3          	sb	zero,3(a5)
    2246:	0046871b          	addiw	a4,a3,4
    224a:	0cc77663          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    224e:	00078223          	sb	zero,4(a5)
    2252:	0056871b          	addiw	a4,a3,5
    2256:	0cc77063          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    225a:	000782a3          	sb	zero,5(a5)
    225e:	0066871b          	addiw	a4,a3,6
    2262:	0ac77a63          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    2266:	00078323          	sb	zero,6(a5)
    226a:	0076871b          	addiw	a4,a3,7
    226e:	0ac77463          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    2272:	000783a3          	sb	zero,7(a5)
    2276:	0086871b          	addiw	a4,a3,8
    227a:	08c77e63          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    227e:	00078423          	sb	zero,8(a5)
    2282:	0096871b          	addiw	a4,a3,9
    2286:	08c77863          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    228a:	000784a3          	sb	zero,9(a5)
    228e:	00a6871b          	addiw	a4,a3,10
    2292:	08c77263          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    2296:	00078523          	sb	zero,10(a5)
    229a:	00b6871b          	addiw	a4,a3,11
    229e:	06c77c63          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    22a2:	000785a3          	sb	zero,11(a5)
    22a6:	00c6871b          	addiw	a4,a3,12
    22aa:	06c77663          	bgeu	a4,a2,2316 <stpncpy+0x1ce>
    22ae:	00078623          	sb	zero,12(a5)
    22b2:	26b5                	addiw	a3,a3,13
    22b4:	06c6f163          	bgeu	a3,a2,2316 <stpncpy+0x1ce>
    22b8:	000786a3          	sb	zero,13(a5)
    22bc:	8082                	ret
			;
		if (!n || !*s)
    22be:	c645                	beqz	a2,2366 <stpncpy+0x21e>
    22c0:	0005c783          	lbu	a5,0(a1)
    22c4:	ea078be3          	beqz	a5,217a <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22c8:	479d                	li	a5,7
    22ca:	02c7ff63          	bgeu	a5,a2,2308 <stpncpy+0x1c0>
    22ce:	00000897          	auipc	a7,0x0
    22d2:	6728b883          	ld	a7,1650(a7) # 2940 <enable_deadlock_detect+0x1e0>
    22d6:	00000817          	auipc	a6,0x0
    22da:	67283803          	ld	a6,1650(a6) # 2948 <enable_deadlock_detect+0x1e8>
    22de:	431d                	li	t1,7
    22e0:	6198                	ld	a4,0(a1)
    22e2:	011707b3          	add	a5,a4,a7
    22e6:	fff74693          	not	a3,a4
    22ea:	8ff5                	and	a5,a5,a3
    22ec:	0107f7b3          	and	a5,a5,a6
    22f0:	ef81                	bnez	a5,2308 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    22f2:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    22f4:	1661                	addi	a2,a2,-8
    22f6:	05a1                	addi	a1,a1,8
    22f8:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    22fa:	fec363e3          	bltu	t1,a2,22e0 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    22fe:	e609                	bnez	a2,2308 <stpncpy+0x1c0>
    2300:	a08d                	j	2362 <stpncpy+0x21a>
    2302:	167d                	addi	a2,a2,-1
    2304:	0505                	addi	a0,a0,1
    2306:	ca01                	beqz	a2,2316 <stpncpy+0x1ce>
    2308:	0005c783          	lbu	a5,0(a1)
    230c:	0585                	addi	a1,a1,1
    230e:	00f50023          	sb	a5,0(a0)
    2312:	fbe5                	bnez	a5,2302 <stpncpy+0x1ba>
		;
tail:
    2314:	b59d                	j	217a <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2316:	8082                	ret
    2318:	472d                	li	a4,11
    231a:	bdb5                	j	2196 <stpncpy+0x4e>
    231c:	00778713          	addi	a4,a5,7
    2320:	45ad                	li	a1,11
    2322:	fff60693          	addi	a3,a2,-1
    2326:	e6b778e3          	bgeu	a4,a1,2196 <stpncpy+0x4e>
    232a:	b7fd                	j	2318 <stpncpy+0x1d0>
    232c:	40a007b3          	neg	a5,a0
    2330:	8832                	mv	a6,a2
    2332:	8b9d                	andi	a5,a5,7
    2334:	4681                	li	a3,0
    2336:	e4060be3          	beqz	a2,218c <stpncpy+0x44>
    233a:	b7cd                	j	231c <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    233c:	468d                	li	a3,3
    233e:	bd75                	j	21fa <stpncpy+0xb2>
    2340:	872a                	mv	a4,a0
    2342:	4681                	li	a3,0
    2344:	bd5d                	j	21fa <stpncpy+0xb2>
    2346:	4685                	li	a3,1
    2348:	bd4d                	j	21fa <stpncpy+0xb2>
    234a:	8082                	ret
    234c:	87aa                	mv	a5,a0
    234e:	4681                	li	a3,0
    2350:	b5f9                	j	221e <stpncpy+0xd6>
    2352:	4689                	li	a3,2
    2354:	b55d                	j	21fa <stpncpy+0xb2>
    2356:	4691                	li	a3,4
    2358:	b54d                	j	21fa <stpncpy+0xb2>
    235a:	4695                	li	a3,5
    235c:	bd79                	j	21fa <stpncpy+0xb2>
    235e:	4699                	li	a3,6
    2360:	bd69                	j	21fa <stpncpy+0xb2>
    2362:	8082                	ret
    2364:	8082                	ret
    2366:	8082                	ret

0000000000002368 <basename>:

char *basename(char *s)
{
    2368:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    236a:	c54d                	beqz	a0,2414 <basename+0xac>
    236c:	00054783          	lbu	a5,0(a0)
		return ".";
    2370:	00000517          	auipc	a0,0x0
    2374:	5c850513          	addi	a0,a0,1480 # 2938 <enable_deadlock_detect+0x1d8>
	if (!s || !*s)
    2378:	e391                	bnez	a5,237c <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    237a:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    237c:	0076f713          	andi	a4,a3,7
    2380:	87b6                	mv	a5,a3
    2382:	cf51                	beqz	a4,241e <basename+0xb6>
    2384:	0785                	addi	a5,a5,1
    2386:	0077f713          	andi	a4,a5,7
    238a:	c729                	beqz	a4,23d4 <basename+0x6c>
		if (!*s)
    238c:	0007c703          	lbu	a4,0(a5)
    2390:	fb75                	bnez	a4,2384 <basename+0x1c>
	return s - a;
    2392:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2394:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2396:	cf8d                	beqz	a5,23d0 <basename+0x68>
    2398:	00f68733          	add	a4,a3,a5
    239c:	02f00593          	li	a1,47
    23a0:	a031                	j	23ac <basename+0x44>
		s[i] = 0;
    23a2:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23a6:	17fd                	addi	a5,a5,-1
    23a8:	177d                	addi	a4,a4,-1
    23aa:	c39d                	beqz	a5,23d0 <basename+0x68>
    23ac:	00074603          	lbu	a2,0(a4)
    23b0:	feb609e3          	beq	a2,a1,23a2 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23b4:	02f00613          	li	a2,47
    23b8:	a011                	j	23bc <basename+0x54>
    23ba:	cb99                	beqz	a5,23d0 <basename+0x68>
    23bc:	853e                	mv	a0,a5
    23be:	17fd                	addi	a5,a5,-1
    23c0:	00f68733          	add	a4,a3,a5
    23c4:	00074703          	lbu	a4,0(a4)
    23c8:	fec719e3          	bne	a4,a2,23ba <basename+0x52>
	return s + i;
    23cc:	9536                	add	a0,a0,a3
    23ce:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23d0:	8536                	mv	a0,a3
    23d2:	8082                	ret
    23d4:	6390                	ld	a2,0(a5)
    23d6:	00000517          	auipc	a0,0x0
    23da:	56a53503          	ld	a0,1386(a0) # 2940 <enable_deadlock_detect+0x1e0>
    23de:	00000597          	auipc	a1,0x0
    23e2:	56a5b583          	ld	a1,1386(a1) # 2948 <enable_deadlock_detect+0x1e8>
    23e6:	fff64713          	not	a4,a2
    23ea:	962a                	add	a2,a2,a0
    23ec:	8f71                	and	a4,a4,a2
    23ee:	8f6d                	and	a4,a4,a1
    23f0:	eb11                	bnez	a4,2404 <basename+0x9c>
    23f2:	6790                	ld	a2,8(a5)
    23f4:	07a1                	addi	a5,a5,8
    23f6:	00a60733          	add	a4,a2,a0
    23fa:	fff64613          	not	a2,a2
    23fe:	8f71                	and	a4,a4,a2
    2400:	8f6d                	and	a4,a4,a1
    2402:	db65                	beqz	a4,23f2 <basename+0x8a>
	for (; *s; s++)
    2404:	0007c703          	lbu	a4,0(a5)
    2408:	d749                	beqz	a4,2392 <basename+0x2a>
    240a:	0017c703          	lbu	a4,1(a5)
    240e:	0785                	addi	a5,a5,1
    2410:	ff6d                	bnez	a4,240a <basename+0xa2>
    2412:	b741                	j	2392 <basename+0x2a>
		return ".";
    2414:	00000517          	auipc	a0,0x0
    2418:	52450513          	addi	a0,a0,1316 # 2938 <enable_deadlock_detect+0x1d8>
    241c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    241e:	6290                	ld	a2,0(a3)
    2420:	00000517          	auipc	a0,0x0
    2424:	52053503          	ld	a0,1312(a0) # 2940 <enable_deadlock_detect+0x1e0>
    2428:	00000597          	auipc	a1,0x0
    242c:	5205b583          	ld	a1,1312(a1) # 2948 <enable_deadlock_detect+0x1e8>
    2430:	fff64713          	not	a4,a2
    2434:	962a                	add	a2,a2,a0
    2436:	8f71                	and	a4,a4,a2
    2438:	8f6d                	and	a4,a4,a1
    243a:	df45                	beqz	a4,23f2 <basename+0x8a>
    243c:	b7f9                	j	240a <basename+0xa2>

000000000000243e <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    243e:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    2442:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2444:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2448:	2501                	sext.w	a0,a0
    244a:	8082                	ret

000000000000244c <close>:

int close(int fd)
{
	if (fd == 1) {
    244c:	4785                	li	a5,1
    244e:	00f50863          	beq	a0,a5,245e <close+0x12>
	register long a7 __asm__("a7") = n;
    2452:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2456:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    245a:	2501                	sext.w	a0,a0
    245c:	8082                	ret
{
    245e:	1101                	addi	sp,sp,-32
    2460:	ec06                	sd	ra,24(sp)
    2462:	e42a                	sd	a0,8(sp)
		__write_buffer();
    2464:	cdffe0ef          	jal	ra,1142 <__write_buffer>
		__clear_buffer();
    2468:	d03fe0ef          	jal	ra,116a <__clear_buffer>
    246c:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    246e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2472:	00000073          	ecall
}
    2476:	60e2                	ld	ra,24(sp)
    2478:	2501                	sext.w	a0,a0
    247a:	6105                	addi	sp,sp,32
    247c:	8082                	ret

000000000000247e <read>:
	register long a7 __asm__("a7") = n;
    247e:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2482:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2486:	8082                	ret

0000000000002488 <write>:
	register long a7 __asm__("a7") = n;
    2488:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    248c:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2490:	8082                	ret

0000000000002492 <getpid>:
	register long a7 __asm__("a7") = n;
    2492:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2496:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    249a:	2501                	sext.w	a0,a0
    249c:	8082                	ret

000000000000249e <getppid>:
	register long a7 __asm__("a7") = n;
    249e:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24a2:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24a6:	2501                	sext.w	a0,a0
    24a8:	8082                	ret

00000000000024aa <sched_yield>:
	register long a7 __asm__("a7") = n;
    24aa:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24ae:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24b2:	2501                	sext.w	a0,a0
    24b4:	8082                	ret

00000000000024b6 <fork>:
	register long a7 __asm__("a7") = n;
    24b6:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24ba:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24be:	2501                	sext.w	a0,a0
    24c0:	8082                	ret

00000000000024c2 <exit>:

void exit(int code)
{
    24c2:	1141                	addi	sp,sp,-16
    24c4:	e406                	sd	ra,8(sp)
    24c6:	e022                	sd	s0,0(sp)
    24c8:	842a                	mv	s0,a0
	__write_buffer();
    24ca:	c79fe0ef          	jal	ra,1142 <__write_buffer>
	__clear_buffer();
    24ce:	c9dfe0ef          	jal	ra,116a <__clear_buffer>
	register long a7 __asm__("a7") = n;
    24d2:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    24d6:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    24d8:	00000073          	ecall
	syscall(SYS_exit, code);
}
    24dc:	60a2                	ld	ra,8(sp)
    24de:	6402                	ld	s0,0(sp)
    24e0:	0141                	addi	sp,sp,16
    24e2:	8082                	ret

00000000000024e4 <waitpid>:
	register long a7 __asm__("a7") = n;
    24e4:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e8:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    24ec:	2501                	sext.w	a0,a0
    24ee:	8082                	ret

00000000000024f0 <exec>:
	register long a7 __asm__("a7") = n;
    24f0:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24f4:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    24f8:	2501                	sext.w	a0,a0
    24fa:	8082                	ret

00000000000024fc <get_mtime>:

int64 get_mtime()
{
    24fc:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    24fe:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2502:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2504:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2506:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    250a:	2501                	sext.w	a0,a0
    250c:	ed01                	bnez	a0,2524 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    250e:	6722                	ld	a4,8(sp)
    2510:	3e800793          	li	a5,1000
    2514:	6682                	ld	a3,0(sp)
    2516:	02f75733          	divu	a4,a4,a5
    251a:	02d78533          	mul	a0,a5,a3
    251e:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2520:	0141                	addi	sp,sp,16
    2522:	8082                	ret
	return -1;
    2524:	557d                	li	a0,-1
    2526:	bfed                	j	2520 <get_mtime+0x24>

0000000000002528 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2528:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    252c:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    2530:	2501                	sext.w	a0,a0
    2532:	8082                	ret

0000000000002534 <sleep>:

int sleep(unsigned long long time)
{
    2534:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2536:	880a                	mv	a6,sp
{
    2538:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    253a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    253e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2540:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2542:	00000073          	ecall
	if (err == 0) {
    2546:	2501                	sext.w	a0,a0
    2548:	ed31                	bnez	a0,25a4 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    254a:	6722                	ld	a4,8(sp)
    254c:	3e800793          	li	a5,1000
    2550:	6682                	ld	a3,0(sp)
    2552:	02f75733          	divu	a4,a4,a5
    2556:	02d787b3          	mul	a5,a5,a3
    255a:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    255c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2560:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2562:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2564:	00000073          	ecall
	if (err == 0) {
    2568:	2501                	sext.w	a0,a0
    256a:	e915                	bnez	a0,259e <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    256c:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    256e:	3e800693          	li	a3,1000
    2572:	a819                	j	2588 <sleep+0x54>
	__asm_syscall("r"(a7))
    2574:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2578:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    257c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    257e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2580:	00000073          	ecall
	if (err == 0) {
    2584:	2501                	sext.w	a0,a0
    2586:	ed01                	bnez	a0,259e <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2588:	6722                	ld	a4,8(sp)
    258a:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    258c:	07c00893          	li	a7,124
    2590:	02d75733          	divu	a4,a4,a3
    2594:	02f687b3          	mul	a5,a3,a5
    2598:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    259a:	fcc7ede3          	bltu	a5,a2,2574 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    259e:	4501                	li	a0,0
    25a0:	0141                	addi	sp,sp,16
    25a2:	8082                	ret
    25a4:	57fd                	li	a5,-1
    25a6:	bf5d                	j	255c <sleep+0x28>

00000000000025a8 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25a8:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25ac:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25b0:	2501                	sext.w	a0,a0
    25b2:	8082                	ret

00000000000025b4 <set_priority>:
	register long a7 __asm__("a7") = n;
    25b4:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25b8:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25bc:	2501                	sext.w	a0,a0
    25be:	8082                	ret

00000000000025c0 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25c0:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25c4:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    25c8:	2501                	sext.w	a0,a0
    25ca:	8082                	ret

00000000000025cc <munmap>:
	register long a7 __asm__("a7") = n;
    25cc:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25d0:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    25d4:	2501                	sext.w	a0,a0
    25d6:	8082                	ret

00000000000025d8 <wait>:

int wait(int *code)
{
    25d8:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25da:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    25de:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25e0:	00000073          	ecall
	return waitpid(-1, code);
}
    25e4:	2501                	sext.w	a0,a0
    25e6:	8082                	ret

00000000000025e8 <spawn>:
	register long a7 __asm__("a7") = n;
    25e8:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    25ec:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    25f0:	2501                	sext.w	a0,a0
    25f2:	8082                	ret

00000000000025f4 <pipe>:
	register long a7 __asm__("a7") = n;
    25f4:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    25f8:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    25fc:	2501                	sext.w	a0,a0
    25fe:	8082                	ret

0000000000002600 <mailread>:
	register long a7 __asm__("a7") = n;
    2600:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2604:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2608:	2501                	sext.w	a0,a0
    260a:	8082                	ret

000000000000260c <mailwrite>:
	register long a7 __asm__("a7") = n;
    260c:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2610:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2614:	2501                	sext.w	a0,a0
    2616:	8082                	ret

0000000000002618 <fstat>:
	register long a7 __asm__("a7") = n;
    2618:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261c:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2620:	2501                	sext.w	a0,a0
    2622:	8082                	ret

0000000000002624 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2624:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2626:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    262a:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    262c:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    2630:	2501                	sext.w	a0,a0
    2632:	8082                	ret

0000000000002634 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2634:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2636:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    263a:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    263c:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    2640:	2501                	sext.w	a0,a0
    2642:	8082                	ret

0000000000002644 <link>:

int link(char *old_path, char *new_path)
{
    2644:	87aa                	mv	a5,a0
    2646:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2648:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    264c:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    2650:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    2652:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2656:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2658:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    265c:	2501                	sext.w	a0,a0
    265e:	8082                	ret

0000000000002660 <unlink>:

int unlink(char *path)
{
    2660:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2662:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2666:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    266a:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    266c:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    2670:	2501                	sext.w	a0,a0
    2672:	8082                	ret

0000000000002674 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    2674:	00000797          	auipc	a5,0x0
    2678:	41c7b783          	ld	a5,1052(a5) # 2a90 <_GLOBAL_OFFSET_TABLE_+0x8>
    267c:	439c                	lw	a5,0(a5)
    267e:	c799                	beqz	a5,268c <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2680:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2684:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret
{
    268c:	1101                	addi	sp,sp,-32
    268e:	ec06                	sd	ra,24(sp)
    2690:	e42e                	sd	a1,8(sp)
    2692:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2694:	fe7fe0ef          	jal	ra,167a <enable_thread_io_buffer>
    2698:	65a2                	ld	a1,8(sp)
    269a:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    269c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26a0:	00000073          	ecall
}
    26a4:	60e2                	ld	ra,24(sp)
    26a6:	2501                	sext.w	a0,a0
    26a8:	6105                	addi	sp,sp,32
    26aa:	8082                	ret

00000000000026ac <gettid>:
	register long a7 __asm__("a7") = n;
    26ac:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26b0:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26b4:	2501                	sext.w	a0,a0
    26b6:	8082                	ret

00000000000026b8 <waittid>:

int waittid(int tid)
{
    26b8:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26ba:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26be:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26c2:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    26c4:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26c6:	00e51e63          	bne	a0,a4,26e2 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    26ca:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    26ce:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26d2:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    26d6:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    26d8:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    26dc:	2501                	sext.w	a0,a0
	while (ret == -2) {
    26de:	fee506e3          	beq	a0,a4,26ca <waittid+0x12>
	}
	return ret;
}
    26e2:	8082                	ret

00000000000026e4 <mutex_create>:
	register long a7 __asm__("a7") = n;
    26e4:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26e8:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    26ea:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    26ee:	2501                	sext.w	a0,a0
    26f0:	8082                	ret

00000000000026f2 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    26f2:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    26f6:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    26f8:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    26fc:	2501                	sext.w	a0,a0
    26fe:	8082                	ret

0000000000002700 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2700:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2704:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2708:	2501                	sext.w	a0,a0
    270a:	8082                	ret

000000000000270c <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    270c:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2710:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2714:	2501                	sext.w	a0,a0
    2716:	8082                	ret

0000000000002718 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2718:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    271c:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2720:	2501                	sext.w	a0,a0
    2722:	8082                	ret

0000000000002724 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2724:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2728:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    272c:	2501                	sext.w	a0,a0
    272e:	8082                	ret

0000000000002730 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    2730:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2734:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2738:	2501                	sext.w	a0,a0
    273a:	8082                	ret

000000000000273c <condvar_create>:
	register long a7 __asm__("a7") = n;
    273c:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    2740:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2744:	2501                	sext.w	a0,a0
    2746:	8082                	ret

0000000000002748 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2748:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    274c:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    2750:	2501                	sext.w	a0,a0
    2752:	8082                	ret

0000000000002754 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2754:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2758:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    275c:	2501                	sext.w	a0,a0
    275e:	8082                	ret

0000000000002760 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    2760:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    2764:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret
