
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_exit0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a881                	j	1050 <__start_main>

0000000000001002 <main>:
辅助测例，正常退出，不输出 FAIL 即可。
*/

int main()
{
	exit(66778);
    1002:	6541                	lui	a0,0x10
{
    1004:	1141                	addi	sp,sp,-16
	exit(66778);
    1006:	4da50513          	addi	a0,a0,1242 # 104da <.got.plt+0xdb7a>
{
    100a:	e406                	sd	ra,8(sp)
    100c:	e022                	sd	s0,0(sp)
	exit(66778);
    100e:	3fe010ef          	jal	ra,240c <exit>
	panic("FAIL: T.T\n");
    1012:	3ca010ef          	jal	ra,23dc <getpid>
    1016:	842a                	mv	s0,a0
    1018:	00001517          	auipc	a0,0x1
    101c:	6a050513          	addi	a0,a0,1696 # 26b8 <enable_deadlock_detect+0xe>
    1020:	292010ef          	jal	ra,22b2 <basename>
    1024:	872a                	mv	a4,a0
    1026:	86a2                	mv	a3,s0
    1028:	47ad                	li	a5,11
    102a:	00001617          	auipc	a2,0x1
    102e:	6d660613          	addi	a2,a2,1750 # 2700 <enable_deadlock_detect+0x56>
    1032:	45fd                	li	a1,31
    1034:	00001517          	auipc	a0,0x1
    1038:	6d450513          	addi	a0,a0,1748 # 2708 <enable_deadlock_detect+0x5e>
    103c:	16e000ef          	jal	ra,11aa <printf>
    1040:	557d                	li	a0,-1
    1042:	3ca010ef          	jal	ra,240c <exit>
	return 0;
    1046:	60a2                	ld	ra,8(sp)
    1048:	6402                	ld	s0,0(sp)
    104a:	4501                	li	a0,0
    104c:	0141                	addi	sp,sp,16
    104e:	8082                	ret

0000000000001050 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1050:	1141                	addi	sp,sp,-16
    1052:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1054:	fafff0ef          	jal	ra,1002 <main>
    1058:	3b4010ef          	jal	ra,240c <exit>
	return 0;
    105c:	60a2                	ld	ra,8(sp)
    105e:	4501                	li	a0,0
    1060:	0141                	addi	sp,sp,16
    1062:	8082                	ret

0000000000001064 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1064:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1066:	4605                	li	a2,1
    1068:	00f10593          	addi	a1,sp,15
    106c:	4501                	li	a0,0
{
    106e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1070:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1074:	354010ef          	jal	ra,23c8 <read>
    1078:	4785                	li	a5,1
    107a:	00f51763          	bne	a0,a5,1088 <getchar+0x24>
		return byte;
    107e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1082:	60e2                	ld	ra,24(sp)
    1084:	6105                	addi	sp,sp,32
    1086:	8082                	ret
		return EOF;
    1088:	557d                	li	a0,-1
    108a:	bfe5                	j	1082 <getchar+0x1e>

000000000000108c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    108c:	00001517          	auipc	a0,0x1
    1090:	79c52503          	lw	a0,1948(a0) # 2828 <buffer_len>
    1094:	e111                	bnez	a0,1098 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1096:	8082                	ret
{
    1098:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    109a:	862a                	mv	a2,a0
    109c:	00001597          	auipc	a1,0x1
    10a0:	79458593          	addi	a1,a1,1940 # 2830 <buffer>
    10a4:	4505                	li	a0,1
{
    10a6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10a8:	32a010ef          	jal	ra,23d2 <write>
}
    10ac:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10ae:	2501                	sext.w	a0,a0
}
    10b0:	0141                	addi	sp,sp,16
    10b2:	8082                	ret

00000000000010b4 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10b4:	00001797          	auipc	a5,0x1
    10b8:	7607aa23          	sw	zero,1908(a5) # 2828 <buffer_len>
}
    10bc:	8082                	ret

00000000000010be <__fflush>:
	if (buffer_len == 0)
    10be:	00001517          	auipc	a0,0x1
    10c2:	76a52503          	lw	a0,1898(a0) # 2828 <buffer_len>
    10c6:	e511                	bnez	a0,10d2 <__fflush+0x14>
	buffer_len = 0;
    10c8:	00001797          	auipc	a5,0x1
    10cc:	7607a023          	sw	zero,1888(a5) # 2828 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    10d0:	8082                	ret
{
    10d2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10d4:	862a                	mv	a2,a0
    10d6:	00001597          	auipc	a1,0x1
    10da:	75a58593          	addi	a1,a1,1882 # 2830 <buffer>
    10de:	4505                	li	a0,1
{
    10e0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10e2:	2f0010ef          	jal	ra,23d2 <write>
	return r >= 0 ? 0 : r;
    10e6:	0005079b          	sext.w	a5,a0
}
    10ea:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    10ec:	0017a793          	slti	a5,a5,1
    10f0:	40f007bb          	negw	a5,a5
    10f4:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    10f6:	00001797          	auipc	a5,0x1
    10fa:	7207a923          	sw	zero,1842(a5) # 2828 <buffer_len>
	return r >= 0 ? 0 : r;
    10fe:	2501                	sext.w	a0,a0
}
    1100:	0141                	addi	sp,sp,16
    1102:	8082                	ret

0000000000001104 <fflush>:

int fflush(int fd)
{
    1104:	1101                	addi	sp,sp,-32
    1106:	e822                	sd	s0,16(sp)
    1108:	ec06                	sd	ra,24(sp)
    110a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    110c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    110e:	4401                	li	s0,0
	if (fd == 1) {
    1110:	00e50863          	beq	a0,a4,1120 <fflush+0x1c>
}
    1114:	60e2                	ld	ra,24(sp)
    1116:	8522                	mv	a0,s0
    1118:	6442                	ld	s0,16(sp)
    111a:	64a2                	ld	s1,8(sp)
    111c:	6105                	addi	sp,sp,32
    111e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1120:	00001497          	auipc	s1,0x1
    1124:	70848493          	addi	s1,s1,1800 # 2828 <buffer_len>
    1128:	1084a703          	lw	a4,264(s1)
    112c:	02a70e63          	beq	a4,a0,1168 <fflush+0x64>
	if (buffer_len == 0)
    1130:	4080                	lw	s0,0(s1)
    1132:	c00d                	beqz	s0,1154 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1134:	8622                	mv	a2,s0
    1136:	00001597          	auipc	a1,0x1
    113a:	6fa58593          	addi	a1,a1,1786 # 2830 <buffer>
    113e:	294010ef          	jal	ra,23d2 <write>
	return r >= 0 ? 0 : r;
    1142:	0005079b          	sext.w	a5,a0
    1146:	0017a793          	slti	a5,a5,1
    114a:	40f007bb          	negw	a5,a5
    114e:	8d7d                	and	a0,a0,a5
    1150:	0005041b          	sext.w	s0,a0
}
    1154:	60e2                	ld	ra,24(sp)
    1156:	8522                	mv	a0,s0
    1158:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    115a:	00001797          	auipc	a5,0x1
    115e:	6c07a723          	sw	zero,1742(a5) # 2828 <buffer_len>
}
    1162:	64a2                	ld	s1,8(sp)
    1164:	6105                	addi	sp,sp,32
    1166:	8082                	ret
			mutex_lock(buffer_lock);
    1168:	10c4a503          	lw	a0,268(s1)
    116c:	4de010ef          	jal	ra,264a <mutex_lock>
	if (buffer_len == 0)
    1170:	4080                	lw	s0,0(s1)
    1172:	e811                	bnez	s0,1186 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1174:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1178:	00001797          	auipc	a5,0x1
    117c:	6a07a823          	sw	zero,1712(a5) # 2828 <buffer_len>
			mutex_unlock(buffer_lock);
    1180:	4d6010ef          	jal	ra,2656 <mutex_unlock>
    1184:	bf41                	j	1114 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1186:	8622                	mv	a2,s0
    1188:	00001597          	auipc	a1,0x1
    118c:	6a858593          	addi	a1,a1,1704 # 2830 <buffer>
    1190:	4505                	li	a0,1
    1192:	240010ef          	jal	ra,23d2 <write>
	return r >= 0 ? 0 : r;
    1196:	0005079b          	sext.w	a5,a0
    119a:	0017a793          	slti	a5,a5,1
    119e:	40f007bb          	negw	a5,a5
    11a2:	8d7d                	and	a0,a0,a5
    11a4:	0005041b          	sext.w	s0,a0
	return r;
    11a8:	b7f1                	j	1174 <fflush+0x70>

00000000000011aa <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11aa:	7131                	addi	sp,sp,-192
    11ac:	e0da                	sd	s6,64(sp)
    11ae:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11b0:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11b2:	013c                	addi	a5,sp,136
{
    11b4:	f0ca                	sd	s2,96(sp)
    11b6:	ecce                	sd	s3,88(sp)
    11b8:	e8d2                	sd	s4,80(sp)
    11ba:	e4d6                	sd	s5,72(sp)
    11bc:	fc86                	sd	ra,120(sp)
    11be:	f8a2                	sd	s0,112(sp)
    11c0:	f4a6                	sd	s1,104(sp)
    11c2:	89aa                	mv	s3,a0
    11c4:	e52e                	sd	a1,136(sp)
    11c6:	e932                	sd	a2,144(sp)
    11c8:	ed36                	sd	a3,152(sp)
    11ca:	f13a                	sd	a4,160(sp)
    11cc:	f942                	sd	a6,176(sp)
    11ce:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    11d0:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    11d2:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    11d6:	00001a17          	auipc	s4,0x1
    11da:	652a0a13          	addi	s4,s4,1618 # 2828 <buffer_len>
    11de:	4a85                	li	s5,1
	buf[i++] = '0';
    11e0:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    11e4:	0009c783          	lbu	a5,0(s3)
    11e8:	18078663          	beqz	a5,1374 <printf+0x1ca>
    11ec:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    11ee:	19278d63          	beq	a5,s2,1388 <printf+0x1de>
    11f2:	0015c783          	lbu	a5,1(a1)
    11f6:	0585                	addi	a1,a1,1
    11f8:	fbfd                	bnez	a5,11ee <printf+0x44>
    11fa:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    11fc:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1200:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1204:	1b578863          	beq	a5,s5,13b4 <printf+0x20a>
		len = out_unlocked(s, l);
    1208:	85a2                	mv	a1,s0
    120a:	854e                	mv	a0,s3
    120c:	42a000ef          	jal	ra,1636 <out_unlocked>
		out(f, a, l);
		if (l)
    1210:	1c041063          	bnez	s0,13d0 <printf+0x226>
			continue;
		if (s[1] == 0)
    1214:	0014c783          	lbu	a5,1(s1)
    1218:	14078e63          	beqz	a5,1374 <printf+0x1ca>
			break;
		switch (s[1]) {
    121c:	07300713          	li	a4,115
    1220:	1ce78863          	beq	a5,a4,13f0 <printf+0x246>
    1224:	1af76863          	bltu	a4,a5,13d4 <printf+0x22a>
    1228:	06400713          	li	a4,100
    122c:	22e78063          	beq	a5,a4,144c <printf+0x2a2>
    1230:	07000713          	li	a4,112
    1234:	1ee79563          	bne	a5,a4,141e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1238:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    123a:	00001797          	auipc	a5,0x1
    123e:	6fe78793          	addi	a5,a5,1790 # 2938 <digits>
	buf[i++] = '0';
    1242:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1246:	6298                	ld	a4,0(a3)
    1248:	06a1                	addi	a3,a3,8
    124a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    124c:	00471393          	slli	t2,a4,0x4
    1250:	00871293          	slli	t0,a4,0x8
    1254:	00c71f93          	slli	t6,a4,0xc
    1258:	01071f13          	slli	t5,a4,0x10
    125c:	01471e93          	slli	t4,a4,0x14
    1260:	01871e13          	slli	t3,a4,0x18
    1264:	01c71893          	slli	a7,a4,0x1c
    1268:	02471813          	slli	a6,a4,0x24
    126c:	02871513          	slli	a0,a4,0x28
    1270:	02c71593          	slli	a1,a4,0x2c
    1274:	03071613          	slli	a2,a4,0x30
    1278:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    127c:	03c75413          	srli	s0,a4,0x3c
    1280:	01c7531b          	srliw	t1,a4,0x1c
    1284:	03c3d393          	srli	t2,t2,0x3c
    1288:	03c2d293          	srli	t0,t0,0x3c
    128c:	03cfdf93          	srli	t6,t6,0x3c
    1290:	03cf5f13          	srli	t5,t5,0x3c
    1294:	03cede93          	srli	t4,t4,0x3c
    1298:	03ce5e13          	srli	t3,t3,0x3c
    129c:	03c8d893          	srli	a7,a7,0x3c
    12a0:	03c85813          	srli	a6,a6,0x3c
    12a4:	9171                	srli	a0,a0,0x3c
    12a6:	91f1                	srli	a1,a1,0x3c
    12a8:	9271                	srli	a2,a2,0x3c
    12aa:	92f1                	srli	a3,a3,0x3c
    12ac:	95be                	add	a1,a1,a5
    12ae:	963e                	add	a2,a2,a5
    12b0:	96be                	add	a3,a3,a5
    12b2:	943e                	add	s0,s0,a5
    12b4:	93be                	add	t2,t2,a5
    12b6:	92be                	add	t0,t0,a5
    12b8:	9fbe                	add	t6,t6,a5
    12ba:	9f3e                	add	t5,t5,a5
    12bc:	9ebe                	add	t4,t4,a5
    12be:	9e3e                	add	t3,t3,a5
    12c0:	98be                	add	a7,a7,a5
    12c2:	933e                	add	t1,t1,a5
    12c4:	983e                	add	a6,a6,a5
    12c6:	953e                	add	a0,a0,a5
    12c8:	0005c983          	lbu	s3,0(a1)
    12cc:	00044403          	lbu	s0,0(s0)
    12d0:	00064583          	lbu	a1,0(a2)
    12d4:	0003c383          	lbu	t2,0(t2)
    12d8:	0006c603          	lbu	a2,0(a3)
    12dc:	0002c283          	lbu	t0,0(t0)
    12e0:	000fcf83          	lbu	t6,0(t6)
    12e4:	000f4f03          	lbu	t5,0(t5)
    12e8:	000ece83          	lbu	t4,0(t4)
    12ec:	000e4e03          	lbu	t3,0(t3)
    12f0:	0008c883          	lbu	a7,0(a7)
    12f4:	00034303          	lbu	t1,0(t1)
    12f8:	00084803          	lbu	a6,0(a6)
    12fc:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1300:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1304:	92f1                	srli	a3,a3,0x3c
    1306:	8b3d                	andi	a4,a4,15
    1308:	96be                	add	a3,a3,a5
    130a:	97ba                	add	a5,a5,a4
    130c:	00810d23          	sb	s0,26(sp)
    1310:	00710da3          	sb	t2,27(sp)
    1314:	00510e23          	sb	t0,28(sp)
    1318:	01f10ea3          	sb	t6,29(sp)
    131c:	01e10f23          	sb	t5,30(sp)
    1320:	01d10fa3          	sb	t4,31(sp)
    1324:	03c10023          	sb	t3,32(sp)
    1328:	031100a3          	sb	a7,33(sp)
    132c:	02610123          	sb	t1,34(sp)
    1330:	030101a3          	sb	a6,35(sp)
    1334:	02a10223          	sb	a0,36(sp)
    1338:	033102a3          	sb	s3,37(sp)
    133c:	02b10323          	sb	a1,38(sp)
    1340:	02c103a3          	sb	a2,39(sp)
    1344:	0006c683          	lbu	a3,0(a3)
    1348:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    134c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1350:	02d10423          	sb	a3,40(sp)
    1354:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1358:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    135c:	11578263          	beq	a5,s5,1460 <printf+0x2b6>
		len = out_unlocked(s, l);
    1360:	45c9                	li	a1,18
    1362:	0828                	addi	a0,sp,24
    1364:	2d2000ef          	jal	ra,1636 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1368:	00248993          	addi	s3,s1,2
		if (!*s)
    136c:	0009c783          	lbu	a5,0(s3)
    1370:	e6079ee3          	bnez	a5,11ec <printf+0x42>
	}
	va_end(ap);
    1374:	70e6                	ld	ra,120(sp)
    1376:	7446                	ld	s0,112(sp)
    1378:	74a6                	ld	s1,104(sp)
    137a:	7906                	ld	s2,96(sp)
    137c:	69e6                	ld	s3,88(sp)
    137e:	6a46                	ld	s4,80(sp)
    1380:	6aa6                	ld	s5,72(sp)
    1382:	6b06                	ld	s6,64(sp)
    1384:	6129                	addi	sp,sp,192
    1386:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1388:	0005c783          	lbu	a5,0(a1)
    138c:	84ae                	mv	s1,a1
    138e:	01278963          	beq	a5,s2,13a0 <printf+0x1f6>
    1392:	b5ad                	j	11fc <printf+0x52>
    1394:	0024c783          	lbu	a5,2(s1)
    1398:	0585                	addi	a1,a1,1
    139a:	0489                	addi	s1,s1,2
    139c:	e72790e3          	bne	a5,s2,11fc <printf+0x52>
    13a0:	0014c783          	lbu	a5,1(s1)
    13a4:	ff2788e3          	beq	a5,s2,1394 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13a8:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13ac:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13b0:	e5579ce3          	bne	a5,s5,1208 <printf+0x5e>
		mutex_lock(buffer_lock);
    13b4:	10ca2503          	lw	a0,268(s4)
    13b8:	292010ef          	jal	ra,264a <mutex_lock>
		len = out_unlocked(s, l);
    13bc:	85a2                	mv	a1,s0
    13be:	854e                	mv	a0,s3
    13c0:	276000ef          	jal	ra,1636 <out_unlocked>
		mutex_unlock(buffer_lock);
    13c4:	10ca2503          	lw	a0,268(s4)
    13c8:	28e010ef          	jal	ra,2656 <mutex_unlock>
		if (l)
    13cc:	e40404e3          	beqz	s0,1214 <printf+0x6a>
    13d0:	89a6                	mv	s3,s1
    13d2:	bd09                	j	11e4 <printf+0x3a>
		switch (s[1]) {
    13d4:	07800713          	li	a4,120
    13d8:	04e79363          	bne	a5,a4,141e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    13dc:	67c2                	ld	a5,16(sp)
    13de:	45c1                	li	a1,16
		s += 2;
    13e0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    13e4:	4388                	lw	a0,0(a5)
    13e6:	07a1                	addi	a5,a5,8
    13e8:	e83e                	sd	a5,16(sp)
    13ea:	5f8000ef          	jal	ra,19e2 <printint.constprop.0>
		s += 2;
    13ee:	bfbd                	j	136c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    13f0:	67c2                	ld	a5,16(sp)
    13f2:	6380                	ld	s0,0(a5)
    13f4:	07a1                	addi	a5,a5,8
    13f6:	e83e                	sd	a5,16(sp)
    13f8:	1c040163          	beqz	s0,15ba <printf+0x410>
			l = strnlen(a, 200);
    13fc:	0c800593          	li	a1,200
    1400:	8522                	mv	a0,s0
    1402:	3f7000ef          	jal	ra,1ff8 <strnlen>
	if (buffer_lock_enabled == 1) {
    1406:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    140a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    140e:	19578663          	beq	a5,s5,159a <printf+0x3f0>
		len = out_unlocked(s, l);
    1412:	8522                	mv	a0,s0
    1414:	222000ef          	jal	ra,1636 <out_unlocked>
		s += 2;
    1418:	00248993          	addi	s3,s1,2
    141c:	bf81                	j	136c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    141e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1422:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1426:	0f578663          	beq	a5,s5,1512 <printf+0x368>
		len = out_unlocked(s, l);
    142a:	0828                	addi	a0,sp,24
    142c:	316000ef          	jal	ra,1742 <out_unlocked.constprop.0>
			putchar(s[1]);
    1430:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1434:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1438:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    143c:	05578163          	beq	a5,s5,147e <printf+0x2d4>
		len = out_unlocked(s, l);
    1440:	0828                	addi	a0,sp,24
    1442:	300000ef          	jal	ra,1742 <out_unlocked.constprop.0>
		s += 2;
    1446:	00248993          	addi	s3,s1,2
    144a:	b70d                	j	136c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    144c:	67c2                	ld	a5,16(sp)
    144e:	45a9                	li	a1,10
		s += 2;
    1450:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1454:	4388                	lw	a0,0(a5)
    1456:	07a1                	addi	a5,a5,8
    1458:	e83e                	sd	a5,16(sp)
    145a:	588000ef          	jal	ra,19e2 <printint.constprop.0>
		s += 2;
    145e:	b739                	j	136c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1460:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1464:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1468:	1e2010ef          	jal	ra,264a <mutex_lock>
		len = out_unlocked(s, l);
    146c:	45c9                	li	a1,18
    146e:	0828                	addi	a0,sp,24
    1470:	1c6000ef          	jal	ra,1636 <out_unlocked>
		mutex_unlock(buffer_lock);
    1474:	10ca2503          	lw	a0,268(s4)
    1478:	1de010ef          	jal	ra,2656 <mutex_unlock>
		s += 2;
    147c:	bdc5                	j	136c <printf+0x1c2>
		mutex_lock(buffer_lock);
    147e:	10ca2503          	lw	a0,268(s4)
    1482:	1c8010ef          	jal	ra,264a <mutex_lock>
		buffer[buffer_len++] = c;
    1486:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    148a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    148e:	0017861b          	addiw	a2,a5,1
    1492:	97d2                	add	a5,a5,s4
    1494:	00ca2023          	sw	a2,0(s4)
    1498:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    149c:	00c6cc63          	blt	a3,a2,14b4 <printf+0x30a>
    14a0:	47a9                	li	a5,10
    14a2:	06f40663          	beq	s0,a5,150e <printf+0x364>
		mutex_unlock(buffer_lock);
    14a6:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14aa:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14ae:	1a8010ef          	jal	ra,2656 <mutex_unlock>
		s += 2;
    14b2:	bd6d                	j	136c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14b4:	10000793          	li	a5,256
    14b8:	00f61e63          	bne	a2,a5,14d4 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14bc:	00001597          	auipc	a1,0x1
    14c0:	37458593          	addi	a1,a1,884 # 2830 <buffer>
    14c4:	4505                	li	a0,1
    14c6:	70d000ef          	jal	ra,23d2 <write>
	buffer_len = 0;
    14ca:	00001797          	auipc	a5,0x1
    14ce:	3407af23          	sw	zero,862(a5) # 2828 <buffer_len>
			if (r < 0) {
    14d2:	bfd1                	j	14a6 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    14d4:	709000ef          	jal	ra,23dc <getpid>
    14d8:	842a                	mv	s0,a0
    14da:	00001517          	auipc	a0,0x1
    14de:	25e50513          	addi	a0,a0,606 # 2738 <enable_deadlock_detect+0x8e>
    14e2:	5d1000ef          	jal	ra,22b2 <basename>
    14e6:	872a                	mv	a4,a0
    14e8:	00001617          	auipc	a2,0x1
    14ec:	21860613          	addi	a2,a2,536 # 2700 <enable_deadlock_detect+0x56>
    14f0:	05400793          	li	a5,84
    14f4:	86a2                	mv	a3,s0
    14f6:	45fd                	li	a1,31
    14f8:	00001517          	auipc	a0,0x1
    14fc:	28050513          	addi	a0,a0,640 # 2778 <enable_deadlock_detect+0xce>
    1500:	cabff0ef          	jal	ra,11aa <printf>
    1504:	557d                	li	a0,-1
    1506:	707000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    150a:	000a2603          	lw	a2,0(s4)
    150e:	de41                	beqz	a2,14a6 <printf+0x2fc>
    1510:	b775                	j	14bc <printf+0x312>
		mutex_lock(buffer_lock);
    1512:	10ca2503          	lw	a0,268(s4)
    1516:	134010ef          	jal	ra,264a <mutex_lock>
		buffer[buffer_len++] = c;
    151a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    151e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1522:	0017861b          	addiw	a2,a5,1
    1526:	97d2                	add	a5,a5,s4
    1528:	00ca2023          	sw	a2,0(s4)
    152c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1530:	02c6d163          	bge	a3,a2,1552 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1534:	10000793          	li	a5,256
    1538:	02f61263          	bne	a2,a5,155c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    153c:	00001597          	auipc	a1,0x1
    1540:	2f458593          	addi	a1,a1,756 # 2830 <buffer>
    1544:	4505                	li	a0,1
    1546:	68d000ef          	jal	ra,23d2 <write>
	buffer_len = 0;
    154a:	00001797          	auipc	a5,0x1
    154e:	2c07af23          	sw	zero,734(a5) # 2828 <buffer_len>
		mutex_unlock(buffer_lock);
    1552:	10ca2503          	lw	a0,268(s4)
    1556:	100010ef          	jal	ra,2656 <mutex_unlock>
    155a:	bdd9                	j	1430 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    155c:	681000ef          	jal	ra,23dc <getpid>
    1560:	842a                	mv	s0,a0
    1562:	00001517          	auipc	a0,0x1
    1566:	1d650513          	addi	a0,a0,470 # 2738 <enable_deadlock_detect+0x8e>
    156a:	549000ef          	jal	ra,22b2 <basename>
    156e:	872a                	mv	a4,a0
    1570:	00001617          	auipc	a2,0x1
    1574:	19060613          	addi	a2,a2,400 # 2700 <enable_deadlock_detect+0x56>
    1578:	05400793          	li	a5,84
    157c:	86a2                	mv	a3,s0
    157e:	45fd                	li	a1,31
    1580:	00001517          	auipc	a0,0x1
    1584:	1f850513          	addi	a0,a0,504 # 2778 <enable_deadlock_detect+0xce>
    1588:	c23ff0ef          	jal	ra,11aa <printf>
    158c:	557d                	li	a0,-1
    158e:	67f000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    1592:	000a2603          	lw	a2,0(s4)
    1596:	de55                	beqz	a2,1552 <printf+0x3a8>
    1598:	b755                	j	153c <printf+0x392>
		mutex_lock(buffer_lock);
    159a:	10ca2503          	lw	a0,268(s4)
    159e:	e42e                	sd	a1,8(sp)
		s += 2;
    15a0:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15a4:	0a6010ef          	jal	ra,264a <mutex_lock>
		len = out_unlocked(s, l);
    15a8:	65a2                	ld	a1,8(sp)
    15aa:	8522                	mv	a0,s0
    15ac:	08a000ef          	jal	ra,1636 <out_unlocked>
		mutex_unlock(buffer_lock);
    15b0:	10ca2503          	lw	a0,268(s4)
    15b4:	0a2010ef          	jal	ra,2656 <mutex_unlock>
		s += 2;
    15b8:	bb55                	j	136c <printf+0x1c2>
				a = "(null)";
    15ba:	00001417          	auipc	s0,0x1
    15be:	17640413          	addi	s0,s0,374 # 2730 <enable_deadlock_detect+0x86>
    15c2:	bd2d                	j	13fc <printf+0x252>

00000000000015c4 <enable_thread_io_buffer>:
{
    15c4:	1101                	addi	sp,sp,-32
    15c6:	e822                	sd	s0,16(sp)
    15c8:	ec06                	sd	ra,24(sp)
    15ca:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    15cc:	00001417          	auipc	s0,0x1
    15d0:	25c40413          	addi	s0,s0,604 # 2828 <buffer_len>
    15d4:	05a010ef          	jal	ra,262e <mutex_create>
    15d8:	10a42623          	sw	a0,268(s0)
    15dc:	00054a63          	bltz	a0,15f0 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    15e0:	4785                	li	a5,1
}
    15e2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    15e4:	10f42423          	sw	a5,264(s0)
}
    15e8:	6442                	ld	s0,16(sp)
    15ea:	64a2                	ld	s1,8(sp)
    15ec:	6105                	addi	sp,sp,32
    15ee:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    15f0:	5ed000ef          	jal	ra,23dc <getpid>
    15f4:	84aa                	mv	s1,a0
    15f6:	00001517          	auipc	a0,0x1
    15fa:	14250513          	addi	a0,a0,322 # 2738 <enable_deadlock_detect+0x8e>
    15fe:	4b5000ef          	jal	ra,22b2 <basename>
    1602:	872a                	mv	a4,a0
    1604:	04800793          	li	a5,72
    1608:	86a6                	mv	a3,s1
    160a:	00001517          	auipc	a0,0x1
    160e:	1ae50513          	addi	a0,a0,430 # 27b8 <enable_deadlock_detect+0x10e>
    1612:	00001617          	auipc	a2,0x1
    1616:	0ee60613          	addi	a2,a2,238 # 2700 <enable_deadlock_detect+0x56>
    161a:	45fd                	li	a1,31
    161c:	b8fff0ef          	jal	ra,11aa <printf>
    1620:	557d                	li	a0,-1
    1622:	5eb000ef          	jal	ra,240c <exit>
	buffer_lock_enabled = 1;
    1626:	4785                	li	a5,1
}
    1628:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    162a:	10f42423          	sw	a5,264(s0)
}
    162e:	6442                	ld	s0,16(sp)
    1630:	64a2                	ld	s1,8(sp)
    1632:	6105                	addi	sp,sp,32
    1634:	8082                	ret

0000000000001636 <out_unlocked>:
{
    1636:	7159                	addi	sp,sp,-112
    1638:	f486                	sd	ra,104(sp)
    163a:	f0a2                	sd	s0,96(sp)
    163c:	eca6                	sd	s1,88(sp)
    163e:	e8ca                	sd	s2,80(sp)
    1640:	e4ce                	sd	s3,72(sp)
    1642:	e0d2                	sd	s4,64(sp)
    1644:	fc56                	sd	s5,56(sp)
    1646:	f85a                	sd	s6,48(sp)
    1648:	f45e                	sd	s7,40(sp)
    164a:	f062                	sd	s8,32(sp)
    164c:	ec66                	sd	s9,24(sp)
    164e:	e86a                	sd	s10,16(sp)
    1650:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1652:	0e058663          	beqz	a1,173e <out_unlocked+0x108>
    1656:	842a                	mv	s0,a0
    1658:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    165c:	4981                	li	s3,0
    165e:	00001d17          	auipc	s10,0x1
    1662:	1cad0d13          	addi	s10,s10,458 # 2828 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1666:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    166a:	00001b17          	auipc	s6,0x1
    166e:	1c6b0b13          	addi	s6,s6,454 # 2830 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1672:	10000a93          	li	s5,256
    1676:	00001c97          	auipc	s9,0x1
    167a:	0c2c8c93          	addi	s9,s9,194 # 2738 <enable_deadlock_detect+0x8e>
    167e:	00001c17          	auipc	s8,0x1
    1682:	082c0c13          	addi	s8,s8,130 # 2700 <enable_deadlock_detect+0x56>
    1686:	00001b97          	auipc	s7,0x1
    168a:	0f2b8b93          	addi	s7,s7,242 # 2778 <enable_deadlock_detect+0xce>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    168e:	4a29                	li	s4,10
    1690:	a031                	j	169c <out_unlocked+0x66>
    1692:	09468863          	beq	a3,s4,1722 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1696:	0405                	addi	s0,s0,1
    1698:	04848163          	beq	s1,s0,16da <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    169c:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16a0:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16a4:	0017861b          	addiw	a2,a5,1
    16a8:	97ea                	add	a5,a5,s10
    16aa:	00cd2023          	sw	a2,0(s10)
    16ae:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16b2:	fec950e3          	bge	s2,a2,1692 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16b6:	05561263          	bne	a2,s5,16fa <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16ba:	85da                	mv	a1,s6
    16bc:	4505                	li	a0,1
    16be:	515000ef          	jal	ra,23d2 <write>
    16c2:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16c4:	00001797          	auipc	a5,0x1
    16c8:	1607a223          	sw	zero,356(a5) # 2828 <buffer_len>
			if (r < 0) {
    16cc:	06054763          	bltz	a0,173a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    16d0:	0405                	addi	s0,s0,1
			ret += r;
    16d2:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    16d6:	fc8493e3          	bne	s1,s0,169c <out_unlocked+0x66>
}
    16da:	70a6                	ld	ra,104(sp)
    16dc:	7406                	ld	s0,96(sp)
    16de:	64e6                	ld	s1,88(sp)
    16e0:	6946                	ld	s2,80(sp)
    16e2:	6a06                	ld	s4,64(sp)
    16e4:	7ae2                	ld	s5,56(sp)
    16e6:	7b42                	ld	s6,48(sp)
    16e8:	7ba2                	ld	s7,40(sp)
    16ea:	7c02                	ld	s8,32(sp)
    16ec:	6ce2                	ld	s9,24(sp)
    16ee:	6d42                	ld	s10,16(sp)
    16f0:	6da2                	ld	s11,8(sp)
    16f2:	854e                	mv	a0,s3
    16f4:	69a6                	ld	s3,72(sp)
    16f6:	6165                	addi	sp,sp,112
    16f8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    16fa:	4e3000ef          	jal	ra,23dc <getpid>
    16fe:	8daa                	mv	s11,a0
    1700:	8566                	mv	a0,s9
    1702:	3b1000ef          	jal	ra,22b2 <basename>
    1706:	872a                	mv	a4,a0
    1708:	8662                	mv	a2,s8
    170a:	05400793          	li	a5,84
    170e:	86ee                	mv	a3,s11
    1710:	45fd                	li	a1,31
    1712:	855e                	mv	a0,s7
    1714:	a97ff0ef          	jal	ra,11aa <printf>
    1718:	557d                	li	a0,-1
    171a:	4f3000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    171e:	000d2603          	lw	a2,0(s10)
    1722:	da35                	beqz	a2,1696 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1724:	85da                	mv	a1,s6
    1726:	4505                	li	a0,1
    1728:	4ab000ef          	jal	ra,23d2 <write>
    172c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    172e:	00001797          	auipc	a5,0x1
    1732:	0e07ad23          	sw	zero,250(a5) # 2828 <buffer_len>
			if (r < 0) {
    1736:	f8055de3          	bgez	a0,16d0 <out_unlocked+0x9a>
    173a:	89aa                	mv	s3,a0
    173c:	bf79                	j	16da <out_unlocked+0xa4>
	int ret = 0;
    173e:	4981                	li	s3,0
    1740:	bf69                	j	16da <out_unlocked+0xa4>

0000000000001742 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1742:	1101                	addi	sp,sp,-32
    1744:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1746:	00001497          	auipc	s1,0x1
    174a:	0e248493          	addi	s1,s1,226 # 2828 <buffer_len>
    174e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1750:	ec06                	sd	ra,24(sp)
    1752:	e822                	sd	s0,16(sp)
		char c = s[i];
    1754:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1758:	0017861b          	addiw	a2,a5,1
    175c:	97a6                	add	a5,a5,s1
    175e:	00e78423          	sb	a4,8(a5)
    1762:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1764:	0ff00793          	li	a5,255
    1768:	00c7cc63          	blt	a5,a2,1780 <out_unlocked.constprop.0+0x3e>
    176c:	47a9                	li	a5,10
    176e:	06f70c63          	beq	a4,a5,17e6 <out_unlocked.constprop.0+0xa4>
    1772:	4601                	li	a2,0
}
    1774:	60e2                	ld	ra,24(sp)
    1776:	6442                	ld	s0,16(sp)
    1778:	64a2                	ld	s1,8(sp)
    177a:	8532                	mv	a0,a2
    177c:	6105                	addi	sp,sp,32
    177e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1780:	10000793          	li	a5,256
    1784:	02f61563          	bne	a2,a5,17ae <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1788:	00001597          	auipc	a1,0x1
    178c:	0a858593          	addi	a1,a1,168 # 2830 <buffer>
    1790:	4505                	li	a0,1
    1792:	441000ef          	jal	ra,23d2 <write>
}
    1796:	60e2                	ld	ra,24(sp)
    1798:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    179a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    179e:	00001797          	auipc	a5,0x1
    17a2:	0807a523          	sw	zero,138(a5) # 2828 <buffer_len>
}
    17a6:	64a2                	ld	s1,8(sp)
    17a8:	8532                	mv	a0,a2
    17aa:	6105                	addi	sp,sp,32
    17ac:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17ae:	42f000ef          	jal	ra,23dc <getpid>
    17b2:	842a                	mv	s0,a0
    17b4:	00001517          	auipc	a0,0x1
    17b8:	f8450513          	addi	a0,a0,-124 # 2738 <enable_deadlock_detect+0x8e>
    17bc:	2f7000ef          	jal	ra,22b2 <basename>
    17c0:	872a                	mv	a4,a0
    17c2:	00001617          	auipc	a2,0x1
    17c6:	f3e60613          	addi	a2,a2,-194 # 2700 <enable_deadlock_detect+0x56>
    17ca:	05400793          	li	a5,84
    17ce:	86a2                	mv	a3,s0
    17d0:	45fd                	li	a1,31
    17d2:	00001517          	auipc	a0,0x1
    17d6:	fa650513          	addi	a0,a0,-90 # 2778 <enable_deadlock_detect+0xce>
    17da:	9d1ff0ef          	jal	ra,11aa <printf>
    17de:	557d                	li	a0,-1
    17e0:	42d000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    17e4:	4090                	lw	a2,0(s1)
    17e6:	d659                	beqz	a2,1774 <out_unlocked.constprop.0+0x32>
    17e8:	b745                	j	1788 <out_unlocked.constprop.0+0x46>

00000000000017ea <putchar>:
{
    17ea:	7139                	addi	sp,sp,-64
    17ec:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    17ee:	00001497          	auipc	s1,0x1
    17f2:	03a48493          	addi	s1,s1,58 # 2828 <buffer_len>
    17f6:	1084a703          	lw	a4,264(s1)
{
    17fa:	f822                	sd	s0,48(sp)
	char byte = c;
    17fc:	0ff57413          	zext.b	s0,a0
{
    1800:	fc06                	sd	ra,56(sp)
	char byte = c;
    1802:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1806:	4785                	li	a5,1
    1808:	00f70d63          	beq	a4,a5,1822 <putchar+0x38>
		len = out_unlocked(s, l);
    180c:	01f10513          	addi	a0,sp,31
    1810:	f33ff0ef          	jal	ra,1742 <out_unlocked.constprop.0>
}
    1814:	70e2                	ld	ra,56(sp)
    1816:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1818:	862a                	mv	a2,a0
}
    181a:	74a2                	ld	s1,40(sp)
    181c:	8532                	mv	a0,a2
    181e:	6121                	addi	sp,sp,64
    1820:	8082                	ret
		mutex_lock(buffer_lock);
    1822:	10c4a503          	lw	a0,268(s1)
    1826:	625000ef          	jal	ra,264a <mutex_lock>
		buffer[buffer_len++] = c;
    182a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    182c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1830:	0017861b          	addiw	a2,a5,1
    1834:	97a6                	add	a5,a5,s1
    1836:	c090                	sw	a2,0(s1)
    1838:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    183c:	02c6c263          	blt	a3,a2,1860 <putchar+0x76>
    1840:	47a9                	li	a5,10
    1842:	06f40d63          	beq	s0,a5,18bc <putchar+0xd2>
    1846:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1848:	10c4a503          	lw	a0,268(s1)
    184c:	e432                	sd	a2,8(sp)
    184e:	609000ef          	jal	ra,2656 <mutex_unlock>
    1852:	6622                	ld	a2,8(sp)
}
    1854:	70e2                	ld	ra,56(sp)
    1856:	7442                	ld	s0,48(sp)
    1858:	74a2                	ld	s1,40(sp)
    185a:	8532                	mv	a0,a2
    185c:	6121                	addi	sp,sp,64
    185e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1860:	10000793          	li	a5,256
    1864:	02f61063          	bne	a2,a5,1884 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1868:	00001597          	auipc	a1,0x1
    186c:	fc858593          	addi	a1,a1,-56 # 2830 <buffer>
    1870:	4505                	li	a0,1
    1872:	361000ef          	jal	ra,23d2 <write>
    1876:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    187a:	00001797          	auipc	a5,0x1
    187e:	fa07a723          	sw	zero,-82(a5) # 2828 <buffer_len>
			if (r < 0) {
    1882:	b7d9                	j	1848 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1884:	359000ef          	jal	ra,23dc <getpid>
    1888:	842a                	mv	s0,a0
    188a:	00001517          	auipc	a0,0x1
    188e:	eae50513          	addi	a0,a0,-338 # 2738 <enable_deadlock_detect+0x8e>
    1892:	221000ef          	jal	ra,22b2 <basename>
    1896:	872a                	mv	a4,a0
    1898:	00001617          	auipc	a2,0x1
    189c:	e6860613          	addi	a2,a2,-408 # 2700 <enable_deadlock_detect+0x56>
    18a0:	05400793          	li	a5,84
    18a4:	86a2                	mv	a3,s0
    18a6:	45fd                	li	a1,31
    18a8:	00001517          	auipc	a0,0x1
    18ac:	ed050513          	addi	a0,a0,-304 # 2778 <enable_deadlock_detect+0xce>
    18b0:	8fbff0ef          	jal	ra,11aa <printf>
    18b4:	557d                	li	a0,-1
    18b6:	357000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    18ba:	4090                	lw	a2,0(s1)
    18bc:	d651                	beqz	a2,1848 <putchar+0x5e>
    18be:	b76d                	j	1868 <putchar+0x7e>

00000000000018c0 <puts>:
{
    18c0:	7139                	addi	sp,sp,-64
    18c2:	f822                	sd	s0,48(sp)
    18c4:	f426                	sd	s1,40(sp)
    18c6:	fc06                	sd	ra,56(sp)
    18c8:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    18ca:	00001417          	auipc	s0,0x1
    18ce:	f5e40413          	addi	s0,s0,-162 # 2828 <buffer_len>
{
    18d2:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18d4:	638000ef          	jal	ra,1f0c <strlen>
	if (buffer_lock_enabled == 1) {
    18d8:	10842703          	lw	a4,264(s0)
    18dc:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18de:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    18e0:	04f70563          	beq	a4,a5,192a <puts+0x6a>
		len = out_unlocked(s, l);
    18e4:	8526                	mv	a0,s1
    18e6:	d51ff0ef          	jal	ra,1636 <out_unlocked>
    18ea:	892a                	mv	s2,a0
    18ec:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    18ee:	00095963          	bgez	s2,1900 <puts+0x40>
}
    18f2:	70e2                	ld	ra,56(sp)
    18f4:	7442                	ld	s0,48(sp)
    18f6:	7902                	ld	s2,32(sp)
    18f8:	8526                	mv	a0,s1
    18fa:	74a2                	ld	s1,40(sp)
    18fc:	6121                	addi	sp,sp,64
    18fe:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1900:	10842703          	lw	a4,264(s0)
	char byte = c;
    1904:	44a9                	li	s1,10
    1906:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    190a:	4785                	li	a5,1
    190c:	02f70e63          	beq	a4,a5,1948 <puts+0x88>
		len = out_unlocked(s, l);
    1910:	01f10513          	addi	a0,sp,31
    1914:	e2fff0ef          	jal	ra,1742 <out_unlocked.constprop.0>
}
    1918:	70e2                	ld	ra,56(sp)
    191a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    191c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1920:	7902                	ld	s2,32(sp)
    1922:	8526                	mv	a0,s1
    1924:	74a2                	ld	s1,40(sp)
    1926:	6121                	addi	sp,sp,64
    1928:	8082                	ret
		mutex_lock(buffer_lock);
    192a:	e42a                	sd	a0,8(sp)
    192c:	10c42503          	lw	a0,268(s0)
    1930:	51b000ef          	jal	ra,264a <mutex_lock>
		len = out_unlocked(s, l);
    1934:	65a2                	ld	a1,8(sp)
    1936:	8526                	mv	a0,s1
    1938:	cffff0ef          	jal	ra,1636 <out_unlocked>
    193c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    193e:	10c42503          	lw	a0,268(s0)
    1942:	515000ef          	jal	ra,2656 <mutex_unlock>
    1946:	b75d                	j	18ec <puts+0x2c>
		mutex_lock(buffer_lock);
    1948:	10c42503          	lw	a0,268(s0)
    194c:	4ff000ef          	jal	ra,264a <mutex_lock>
		buffer[buffer_len++] = c;
    1950:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1952:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1956:	0017861b          	addiw	a2,a5,1
    195a:	97a2                	add	a5,a5,s0
    195c:	c010                	sw	a2,0(s0)
    195e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1962:	06c6dc63          	bge	a3,a2,19da <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1966:	10000793          	li	a5,256
    196a:	02f61c63          	bne	a2,a5,19a2 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    196e:	00001597          	auipc	a1,0x1
    1972:	ec258593          	addi	a1,a1,-318 # 2830 <buffer>
    1976:	4505                	li	a0,1
    1978:	25b000ef          	jal	ra,23d2 <write>
			if (r < 0) {
    197c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    197e:	00001797          	auipc	a5,0x1
    1982:	ea07a523          	sw	zero,-342(a5) # 2828 <buffer_len>
			if (r < 0) {
    1986:	04054c63          	bltz	a0,19de <puts+0x11e>
			if (r < buffer_len) {
    198a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    198c:	10c42503          	lw	a0,268(s0)
    1990:	4c7000ef          	jal	ra,2656 <mutex_unlock>
}
    1994:	70e2                	ld	ra,56(sp)
    1996:	7442                	ld	s0,48(sp)
    1998:	7902                	ld	s2,32(sp)
    199a:	8526                	mv	a0,s1
    199c:	74a2                	ld	s1,40(sp)
    199e:	6121                	addi	sp,sp,64
    19a0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19a2:	23b000ef          	jal	ra,23dc <getpid>
    19a6:	84aa                	mv	s1,a0
    19a8:	00001517          	auipc	a0,0x1
    19ac:	d9050513          	addi	a0,a0,-624 # 2738 <enable_deadlock_detect+0x8e>
    19b0:	103000ef          	jal	ra,22b2 <basename>
    19b4:	872a                	mv	a4,a0
    19b6:	00001617          	auipc	a2,0x1
    19ba:	d4a60613          	addi	a2,a2,-694 # 2700 <enable_deadlock_detect+0x56>
    19be:	05400793          	li	a5,84
    19c2:	86a6                	mv	a3,s1
    19c4:	45fd                	li	a1,31
    19c6:	00001517          	auipc	a0,0x1
    19ca:	db250513          	addi	a0,a0,-590 # 2778 <enable_deadlock_detect+0xce>
    19ce:	fdcff0ef          	jal	ra,11aa <printf>
    19d2:	557d                	li	a0,-1
    19d4:	239000ef          	jal	ra,240c <exit>
	if (buffer_len == 0)
    19d8:	4010                	lw	a2,0(s0)
    19da:	da45                	beqz	a2,198a <puts+0xca>
    19dc:	bf49                	j	196e <puts+0xae>
    19de:	54fd                	li	s1,-1
    19e0:	b775                	j	198c <puts+0xcc>

00000000000019e2 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    19e2:	715d                	addi	sp,sp,-80
    19e4:	e486                	sd	ra,72(sp)
    19e6:	e0a2                	sd	s0,64(sp)
    19e8:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    19ea:	14054363          	bltz	a0,1b30 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    19ee:	02b577bb          	remuw	a5,a0,a1
    19f2:	00001617          	auipc	a2,0x1
    19f6:	f4660613          	addi	a2,a2,-186 # 2938 <digits>
	buf[16] = 0;
    19fa:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    19fe:	0005871b          	sext.w	a4,a1
    1a02:	1782                	slli	a5,a5,0x20
    1a04:	9381                	srli	a5,a5,0x20
    1a06:	97b2                	add	a5,a5,a2
    1a08:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a0c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a10:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a14:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a16:	0eb56763          	bltu	a0,a1,1b04 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a1a:	02e877bb          	remuw	a5,a6,a4
    1a1e:	1782                	slli	a5,a5,0x20
    1a20:	9381                	srli	a5,a5,0x20
    1a22:	97b2                	add	a5,a5,a2
    1a24:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a28:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a2c:	02f10323          	sb	a5,38(sp)
    1a30:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a32:	0ce86963          	bltu	a6,a4,1b04 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a36:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a3a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a3e:	1582                	slli	a1,a1,0x20
    1a40:	9181                	srli	a1,a1,0x20
    1a42:	95b2                	add	a1,a1,a2
    1a44:	0005c583          	lbu	a1,0(a1)
    1a48:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a4c:	0007859b          	sext.w	a1,a5
    1a50:	16e6e563          	bltu	a3,a4,1bba <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a54:	02e7f6bb          	remuw	a3,a5,a4
    1a58:	1682                	slli	a3,a3,0x20
    1a5a:	9281                	srli	a3,a3,0x20
    1a5c:	96b2                	add	a3,a3,a2
    1a5e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a62:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a66:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1a6a:	16e5e163          	bltu	a1,a4,1bcc <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1a6e:	02e876bb          	remuw	a3,a6,a4
    1a72:	1682                	slli	a3,a3,0x20
    1a74:	9281                	srli	a3,a3,0x20
    1a76:	96b2                	add	a3,a3,a2
    1a78:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a7c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1a80:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1a84:	14e86d63          	bltu	a6,a4,1bde <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1a88:	02e5f6bb          	remuw	a3,a1,a4
    1a8c:	1682                	slli	a3,a3,0x20
    1a8e:	9281                	srli	a3,a3,0x20
    1a90:	96b2                	add	a3,a3,a2
    1a92:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a96:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1a9a:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1a9e:	10e5e563          	bltu	a1,a4,1ba8 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1aa2:	02e876bb          	remuw	a3,a6,a4
    1aa6:	1682                	slli	a3,a3,0x20
    1aa8:	9281                	srli	a3,a3,0x20
    1aaa:	96b2                	add	a3,a3,a2
    1aac:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab0:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ab4:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1ab8:	14e86263          	bltu	a6,a4,1bfc <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1abc:	02e5f6bb          	remuw	a3,a1,a4
    1ac0:	1682                	slli	a3,a3,0x20
    1ac2:	9281                	srli	a3,a3,0x20
    1ac4:	96b2                	add	a3,a3,a2
    1ac6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1aca:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ace:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ad2:	14e5e463          	bltu	a1,a4,1c1a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ad6:	02e876bb          	remuw	a3,a6,a4
    1ada:	1682                	slli	a3,a3,0x20
    1adc:	9281                	srli	a3,a3,0x20
    1ade:	96b2                	add	a3,a3,a2
    1ae0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae4:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1ae8:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1aec:	14e86063          	bltu	a6,a4,1c2c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1af0:	1782                	slli	a5,a5,0x20
    1af2:	9381                	srli	a5,a5,0x20
    1af4:	97b2                	add	a5,a5,a2
    1af6:	0007c703          	lbu	a4,0(a5)
    1afa:	4799                	li	a5,6
    1afc:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b00:	10054763          	bltz	a0,1c0e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b04:	00001497          	auipc	s1,0x1
    1b08:	d2448493          	addi	s1,s1,-732 # 2828 <buffer_len>
    1b0c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b10:	0828                	addi	a0,sp,24
    1b12:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b14:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b16:	00f50433          	add	s0,a0,a5
    1b1a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b1c:	06e68463          	beq	a3,a4,1b84 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b20:	8522                	mv	a0,s0
    1b22:	b15ff0ef          	jal	ra,1636 <out_unlocked>
}
    1b26:	60a6                	ld	ra,72(sp)
    1b28:	6406                	ld	s0,64(sp)
    1b2a:	74e2                	ld	s1,56(sp)
    1b2c:	6161                	addi	sp,sp,80
    1b2e:	8082                	ret
		x = -xx;
    1b30:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b34:	02b877bb          	remuw	a5,a6,a1
    1b38:	00001617          	auipc	a2,0x1
    1b3c:	e0060613          	addi	a2,a2,-512 # 2938 <digits>
	buf[16] = 0;
    1b40:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b44:	0005871b          	sext.w	a4,a1
    1b48:	1782                	slli	a5,a5,0x20
    1b4a:	9381                	srli	a5,a5,0x20
    1b4c:	97b2                	add	a5,a5,a2
    1b4e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b52:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b56:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b5a:	08b86b63          	bltu	a6,a1,1bf0 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b5e:	02e8f7bb          	remuw	a5,a7,a4
    1b62:	1782                	slli	a5,a5,0x20
    1b64:	9381                	srli	a5,a5,0x20
    1b66:	97b2                	add	a5,a5,a2
    1b68:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b6c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1b70:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1b74:	ece8f1e3          	bgeu	a7,a4,1a36 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1b78:	02d00793          	li	a5,45
    1b7c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1b80:	47b5                	li	a5,13
    1b82:	b749                	j	1b04 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1b84:	10c4a503          	lw	a0,268(s1)
    1b88:	e42e                	sd	a1,8(sp)
    1b8a:	2c1000ef          	jal	ra,264a <mutex_lock>
		len = out_unlocked(s, l);
    1b8e:	65a2                	ld	a1,8(sp)
    1b90:	8522                	mv	a0,s0
    1b92:	aa5ff0ef          	jal	ra,1636 <out_unlocked>
		mutex_unlock(buffer_lock);
    1b96:	10c4a503          	lw	a0,268(s1)
    1b9a:	2bd000ef          	jal	ra,2656 <mutex_unlock>
}
    1b9e:	60a6                	ld	ra,72(sp)
    1ba0:	6406                	ld	s0,64(sp)
    1ba2:	74e2                	ld	s1,56(sp)
    1ba4:	6161                	addi	sp,sp,80
    1ba6:	8082                	ret
		buf[i--] = digits[x % base];
    1ba8:	47a9                	li	a5,10
	if (sign)
    1baa:	f4055de3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bae:	02d00793          	li	a5,45
    1bb2:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bb6:	47a5                	li	a5,9
    1bb8:	b7b1                	j	1b04 <printint.constprop.0+0x122>
    1bba:	47b5                	li	a5,13
	if (sign)
    1bbc:	f40554e3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bc0:	02d00793          	li	a5,45
    1bc4:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1bc8:	47b1                	li	a5,12
    1bca:	bf2d                	j	1b04 <printint.constprop.0+0x122>
    1bcc:	47b1                	li	a5,12
	if (sign)
    1bce:	f2055be3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bd2:	02d00793          	li	a5,45
    1bd6:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1bda:	47ad                	li	a5,11
    1bdc:	b725                	j	1b04 <printint.constprop.0+0x122>
    1bde:	47ad                	li	a5,11
	if (sign)
    1be0:	f20552e3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be4:	02d00793          	li	a5,45
    1be8:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1bec:	47a9                	li	a5,10
    1bee:	bf19                	j	1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf0:	02d00793          	li	a5,45
    1bf4:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1bf8:	47b9                	li	a5,14
    1bfa:	b729                	j	1b04 <printint.constprop.0+0x122>
    1bfc:	47a5                	li	a5,9
	if (sign)
    1bfe:	f00553e3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c02:	02d00793          	li	a5,45
    1c06:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c0a:	47a1                	li	a5,8
    1c0c:	bde5                	j	1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c0e:	02d00793          	li	a5,45
    1c12:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c16:	4795                	li	a5,5
    1c18:	b5f5                	j	1b04 <printint.constprop.0+0x122>
    1c1a:	47a1                	li	a5,8
	if (sign)
    1c1c:	ee0554e3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c20:	02d00793          	li	a5,45
    1c24:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c28:	479d                	li	a5,7
    1c2a:	bde9                	j	1b04 <printint.constprop.0+0x122>
    1c2c:	479d                	li	a5,7
	if (sign)
    1c2e:	ec055be3          	bgez	a0,1b04 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c32:	02d00793          	li	a5,45
    1c36:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c3a:	4799                	li	a5,6
    1c3c:	b5e1                	j	1b04 <printint.constprop.0+0x122>

0000000000001c3e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c3e:	02000793          	li	a5,32
    1c42:	00f50663          	beq	a0,a5,1c4e <isspace+0x10>
    1c46:	355d                	addiw	a0,a0,-9
    1c48:	00553513          	sltiu	a0,a0,5
    1c4c:	8082                	ret
    1c4e:	4505                	li	a0,1
}
    1c50:	8082                	ret

0000000000001c52 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c52:	fd05051b          	addiw	a0,a0,-48
}
    1c56:	00a53513          	sltiu	a0,a0,10
    1c5a:	8082                	ret

0000000000001c5c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c5c:	02000613          	li	a2,32
    1c60:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c62:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c66:	ff77869b          	addiw	a3,a5,-9
    1c6a:	04c78c63          	beq	a5,a2,1cc2 <atoi+0x66>
    1c6e:	0007871b          	sext.w	a4,a5
    1c72:	04d5f863          	bgeu	a1,a3,1cc2 <atoi+0x66>
		s++;
	switch (*s) {
    1c76:	02b00693          	li	a3,43
    1c7a:	04d78963          	beq	a5,a3,1ccc <atoi+0x70>
    1c7e:	02d00693          	li	a3,45
    1c82:	06d78263          	beq	a5,a3,1ce6 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1c86:	fd07061b          	addiw	a2,a4,-48
    1c8a:	47a5                	li	a5,9
    1c8c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1c8e:	4e01                	li	t3,0
	while (isdigit(*s))
    1c90:	04c7e963          	bltu	a5,a2,1ce2 <atoi+0x86>
	int n = 0, neg = 0;
    1c94:	4501                	li	a0,0
	while (isdigit(*s))
    1c96:	4825                	li	a6,9
    1c98:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1c9c:	0025179b          	slliw	a5,a0,0x2
    1ca0:	9fa9                	addw	a5,a5,a0
    1ca2:	fd07031b          	addiw	t1,a4,-48
    1ca6:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1caa:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1cae:	0685                	addi	a3,a3,1
    1cb0:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cb4:	0006071b          	sext.w	a4,a2
    1cb8:	feb870e3          	bgeu	a6,a1,1c98 <atoi+0x3c>
	return neg ? n : -n;
    1cbc:	000e0563          	beqz	t3,1cc6 <atoi+0x6a>
}
    1cc0:	8082                	ret
		s++;
    1cc2:	0505                	addi	a0,a0,1
    1cc4:	bf79                	j	1c62 <atoi+0x6>
	return neg ? n : -n;
    1cc6:	4113053b          	subw	a0,t1,a7
    1cca:	8082                	ret
	while (isdigit(*s))
    1ccc:	00154703          	lbu	a4,1(a0)
    1cd0:	47a5                	li	a5,9
		s++;
    1cd2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cd6:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1cda:	4e01                	li	t3,0
	while (isdigit(*s))
    1cdc:	2701                	sext.w	a4,a4
    1cde:	fac7fbe3          	bgeu	a5,a2,1c94 <atoi+0x38>
    1ce2:	4501                	li	a0,0
}
    1ce4:	8082                	ret
	while (isdigit(*s))
    1ce6:	00154703          	lbu	a4,1(a0)
    1cea:	47a5                	li	a5,9
		s++;
    1cec:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1cf0:	fd07061b          	addiw	a2,a4,-48
    1cf4:	2701                	sext.w	a4,a4
    1cf6:	fec7e6e3          	bltu	a5,a2,1ce2 <atoi+0x86>
		neg = 1;
    1cfa:	4e05                	li	t3,1
    1cfc:	bf61                	j	1c94 <atoi+0x38>

0000000000001cfe <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1cfe:	16060d63          	beqz	a2,1e78 <memset+0x17a>
    1d02:	40a007b3          	neg	a5,a0
    1d06:	8b9d                	andi	a5,a5,7
    1d08:	00778693          	addi	a3,a5,7
    1d0c:	482d                	li	a6,11
    1d0e:	0ff5f713          	zext.b	a4,a1
    1d12:	fff60593          	addi	a1,a2,-1
    1d16:	1706e263          	bltu	a3,a6,1e7a <memset+0x17c>
    1d1a:	16d5ea63          	bltu	a1,a3,1e8e <memset+0x190>
    1d1e:	16078563          	beqz	a5,1e88 <memset+0x18a>
    1d22:	00e50023          	sb	a4,0(a0)
    1d26:	4685                	li	a3,1
    1d28:	00150593          	addi	a1,a0,1
    1d2c:	14d78c63          	beq	a5,a3,1e84 <memset+0x186>
    1d30:	00e500a3          	sb	a4,1(a0)
    1d34:	4689                	li	a3,2
    1d36:	00250593          	addi	a1,a0,2
    1d3a:	14d78d63          	beq	a5,a3,1e94 <memset+0x196>
    1d3e:	00e50123          	sb	a4,2(a0)
    1d42:	468d                	li	a3,3
    1d44:	00350593          	addi	a1,a0,3
    1d48:	12d78b63          	beq	a5,a3,1e7e <memset+0x180>
    1d4c:	00e501a3          	sb	a4,3(a0)
    1d50:	4691                	li	a3,4
    1d52:	00450593          	addi	a1,a0,4
    1d56:	14d78163          	beq	a5,a3,1e98 <memset+0x19a>
    1d5a:	00e50223          	sb	a4,4(a0)
    1d5e:	4695                	li	a3,5
    1d60:	00550593          	addi	a1,a0,5
    1d64:	12d78c63          	beq	a5,a3,1e9c <memset+0x19e>
    1d68:	00e502a3          	sb	a4,5(a0)
    1d6c:	469d                	li	a3,7
    1d6e:	00650593          	addi	a1,a0,6
    1d72:	12d79763          	bne	a5,a3,1ea0 <memset+0x1a2>
    1d76:	00750593          	addi	a1,a0,7
    1d7a:	00e50323          	sb	a4,6(a0)
    1d7e:	481d                	li	a6,7
    1d80:	00871693          	slli	a3,a4,0x8
    1d84:	01071893          	slli	a7,a4,0x10
    1d88:	8ed9                	or	a3,a3,a4
    1d8a:	01871313          	slli	t1,a4,0x18
    1d8e:	0116e6b3          	or	a3,a3,a7
    1d92:	0066e6b3          	or	a3,a3,t1
    1d96:	02071893          	slli	a7,a4,0x20
    1d9a:	02871e13          	slli	t3,a4,0x28
    1d9e:	0116e6b3          	or	a3,a3,a7
    1da2:	40f60333          	sub	t1,a2,a5
    1da6:	03071893          	slli	a7,a4,0x30
    1daa:	01c6e6b3          	or	a3,a3,t3
    1dae:	0116e6b3          	or	a3,a3,a7
    1db2:	03871e13          	slli	t3,a4,0x38
    1db6:	97aa                	add	a5,a5,a0
    1db8:	ff837893          	andi	a7,t1,-8
    1dbc:	01c6e6b3          	or	a3,a3,t3
    1dc0:	98be                	add	a7,a7,a5
    1dc2:	e394                	sd	a3,0(a5)
    1dc4:	07a1                	addi	a5,a5,8
    1dc6:	ff179ee3          	bne	a5,a7,1dc2 <memset+0xc4>
    1dca:	ff837893          	andi	a7,t1,-8
    1dce:	011587b3          	add	a5,a1,a7
    1dd2:	010886bb          	addw	a3,a7,a6
    1dd6:	0b130663          	beq	t1,a7,1e82 <memset+0x184>
    1dda:	00e78023          	sb	a4,0(a5)
    1dde:	0016859b          	addiw	a1,a3,1
    1de2:	08c5fb63          	bgeu	a1,a2,1e78 <memset+0x17a>
    1de6:	00e780a3          	sb	a4,1(a5)
    1dea:	0026859b          	addiw	a1,a3,2
    1dee:	08c5f563          	bgeu	a1,a2,1e78 <memset+0x17a>
    1df2:	00e78123          	sb	a4,2(a5)
    1df6:	0036859b          	addiw	a1,a3,3
    1dfa:	06c5ff63          	bgeu	a1,a2,1e78 <memset+0x17a>
    1dfe:	00e781a3          	sb	a4,3(a5)
    1e02:	0046859b          	addiw	a1,a3,4
    1e06:	06c5f963          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e0a:	00e78223          	sb	a4,4(a5)
    1e0e:	0056859b          	addiw	a1,a3,5
    1e12:	06c5f363          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e16:	00e782a3          	sb	a4,5(a5)
    1e1a:	0066859b          	addiw	a1,a3,6
    1e1e:	04c5fd63          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e22:	00e78323          	sb	a4,6(a5)
    1e26:	0076859b          	addiw	a1,a3,7
    1e2a:	04c5f763          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e2e:	00e783a3          	sb	a4,7(a5)
    1e32:	0086859b          	addiw	a1,a3,8
    1e36:	04c5f163          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e3a:	00e78423          	sb	a4,8(a5)
    1e3e:	0096859b          	addiw	a1,a3,9
    1e42:	02c5fb63          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e46:	00e784a3          	sb	a4,9(a5)
    1e4a:	00a6859b          	addiw	a1,a3,10
    1e4e:	02c5f563          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e52:	00e78523          	sb	a4,10(a5)
    1e56:	00b6859b          	addiw	a1,a3,11
    1e5a:	00c5ff63          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e5e:	00e785a3          	sb	a4,11(a5)
    1e62:	00c6859b          	addiw	a1,a3,12
    1e66:	00c5f963          	bgeu	a1,a2,1e78 <memset+0x17a>
    1e6a:	00e78623          	sb	a4,12(a5)
    1e6e:	26b5                	addiw	a3,a3,13
    1e70:	00c6f463          	bgeu	a3,a2,1e78 <memset+0x17a>
    1e74:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1e78:	8082                	ret
    1e7a:	46ad                	li	a3,11
    1e7c:	bd79                	j	1d1a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e7e:	480d                	li	a6,3
    1e80:	b701                	j	1d80 <memset+0x82>
    1e82:	8082                	ret
    1e84:	4805                	li	a6,1
    1e86:	bded                	j	1d80 <memset+0x82>
    1e88:	85aa                	mv	a1,a0
    1e8a:	4801                	li	a6,0
    1e8c:	bdd5                	j	1d80 <memset+0x82>
    1e8e:	87aa                	mv	a5,a0
    1e90:	4681                	li	a3,0
    1e92:	b7a1                	j	1dda <memset+0xdc>
    1e94:	4809                	li	a6,2
    1e96:	b5ed                	j	1d80 <memset+0x82>
    1e98:	4811                	li	a6,4
    1e9a:	b5dd                	j	1d80 <memset+0x82>
    1e9c:	4815                	li	a6,5
    1e9e:	b5cd                	j	1d80 <memset+0x82>
    1ea0:	4819                	li	a6,6
    1ea2:	bdf9                	j	1d80 <memset+0x82>

0000000000001ea4 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ea4:	00054783          	lbu	a5,0(a0)
    1ea8:	0005c703          	lbu	a4,0(a1)
    1eac:	00e79863          	bne	a5,a4,1ebc <strcmp+0x18>
    1eb0:	0505                	addi	a0,a0,1
    1eb2:	0585                	addi	a1,a1,1
    1eb4:	fbe5                	bnez	a5,1ea4 <strcmp>
    1eb6:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1eb8:	9d19                	subw	a0,a0,a4
    1eba:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1ebc:	0007851b          	sext.w	a0,a5
    1ec0:	bfe5                	j	1eb8 <strcmp+0x14>

0000000000001ec2 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ec2:	ca15                	beqz	a2,1ef6 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ec4:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ec8:	167d                	addi	a2,a2,-1
    1eca:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ece:	eb99                	bnez	a5,1ee4 <strncmp+0x22>
    1ed0:	a815                	j	1f04 <strncmp+0x42>
    1ed2:	00a68e63          	beq	a3,a0,1eee <strncmp+0x2c>
    1ed6:	0505                	addi	a0,a0,1
    1ed8:	00f71b63          	bne	a4,a5,1eee <strncmp+0x2c>
    1edc:	00054783          	lbu	a5,0(a0)
    1ee0:	cf89                	beqz	a5,1efa <strncmp+0x38>
    1ee2:	85b2                	mv	a1,a2
    1ee4:	0005c703          	lbu	a4,0(a1)
    1ee8:	00158613          	addi	a2,a1,1
    1eec:	f37d                	bnez	a4,1ed2 <strncmp+0x10>
		;
	return *l - *r;
    1eee:	0007851b          	sext.w	a0,a5
    1ef2:	9d19                	subw	a0,a0,a4
    1ef4:	8082                	ret
		return 0;
    1ef6:	4501                	li	a0,0
}
    1ef8:	8082                	ret
	return *l - *r;
    1efa:	0015c703          	lbu	a4,1(a1)
    1efe:	4501                	li	a0,0
    1f00:	9d19                	subw	a0,a0,a4
    1f02:	8082                	ret
    1f04:	0005c703          	lbu	a4,0(a1)
    1f08:	4501                	li	a0,0
    1f0a:	b7e5                	j	1ef2 <strncmp+0x30>

0000000000001f0c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f0c:	00757793          	andi	a5,a0,7
    1f10:	cf89                	beqz	a5,1f2a <strlen+0x1e>
    1f12:	87aa                	mv	a5,a0
    1f14:	a029                	j	1f1e <strlen+0x12>
    1f16:	0785                	addi	a5,a5,1
    1f18:	0077f713          	andi	a4,a5,7
    1f1c:	cb01                	beqz	a4,1f2c <strlen+0x20>
		if (!*s)
    1f1e:	0007c703          	lbu	a4,0(a5)
    1f22:	fb75                	bnez	a4,1f16 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f24:	40a78533          	sub	a0,a5,a0
}
    1f28:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f2a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f2c:	6394                	ld	a3,0(a5)
    1f2e:	00001597          	auipc	a1,0x1
    1f32:	8e25b583          	ld	a1,-1822(a1) # 2810 <enable_deadlock_detect+0x166>
    1f36:	00001617          	auipc	a2,0x1
    1f3a:	8e263603          	ld	a2,-1822(a2) # 2818 <enable_deadlock_detect+0x16e>
    1f3e:	a019                	j	1f44 <strlen+0x38>
    1f40:	6794                	ld	a3,8(a5)
    1f42:	07a1                	addi	a5,a5,8
    1f44:	00b68733          	add	a4,a3,a1
    1f48:	fff6c693          	not	a3,a3
    1f4c:	8f75                	and	a4,a4,a3
    1f4e:	8f71                	and	a4,a4,a2
    1f50:	db65                	beqz	a4,1f40 <strlen+0x34>
	for (; *s; s++)
    1f52:	0007c703          	lbu	a4,0(a5)
    1f56:	d779                	beqz	a4,1f24 <strlen+0x18>
    1f58:	0017c703          	lbu	a4,1(a5)
    1f5c:	0785                	addi	a5,a5,1
    1f5e:	d379                	beqz	a4,1f24 <strlen+0x18>
    1f60:	0017c703          	lbu	a4,1(a5)
    1f64:	0785                	addi	a5,a5,1
    1f66:	fb6d                	bnez	a4,1f58 <strlen+0x4c>
    1f68:	bf75                	j	1f24 <strlen+0x18>

0000000000001f6a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f6a:	00757713          	andi	a4,a0,7
{
    1f6e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1f70:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1f74:	cb19                	beqz	a4,1f8a <memchr+0x20>
    1f76:	ce25                	beqz	a2,1fee <memchr+0x84>
    1f78:	0007c703          	lbu	a4,0(a5)
    1f7c:	04b70e63          	beq	a4,a1,1fd8 <memchr+0x6e>
    1f80:	0785                	addi	a5,a5,1
    1f82:	0077f713          	andi	a4,a5,7
    1f86:	167d                	addi	a2,a2,-1
    1f88:	f77d                	bnez	a4,1f76 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1f8a:	4501                	li	a0,0
	if (n && *s != c) {
    1f8c:	c235                	beqz	a2,1ff0 <memchr+0x86>
    1f8e:	0007c703          	lbu	a4,0(a5)
    1f92:	04b70363          	beq	a4,a1,1fd8 <memchr+0x6e>
		size_t k = ONES * c;
    1f96:	00001517          	auipc	a0,0x1
    1f9a:	88a53503          	ld	a0,-1910(a0) # 2820 <enable_deadlock_detect+0x176>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1f9e:	471d                	li	a4,7
		size_t k = ONES * c;
    1fa0:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fa4:	02c77a63          	bgeu	a4,a2,1fd8 <memchr+0x6e>
    1fa8:	00001897          	auipc	a7,0x1
    1fac:	8688b883          	ld	a7,-1944(a7) # 2810 <enable_deadlock_detect+0x166>
    1fb0:	00001817          	auipc	a6,0x1
    1fb4:	86883803          	ld	a6,-1944(a6) # 2818 <enable_deadlock_detect+0x16e>
    1fb8:	431d                	li	t1,7
    1fba:	a029                	j	1fc4 <memchr+0x5a>
		     w++, n -= SS)
    1fbc:	1661                	addi	a2,a2,-8
    1fbe:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fc0:	02c37963          	bgeu	t1,a2,1ff2 <memchr+0x88>
    1fc4:	6398                	ld	a4,0(a5)
    1fc6:	8f29                	xor	a4,a4,a0
    1fc8:	011706b3          	add	a3,a4,a7
    1fcc:	fff74713          	not	a4,a4
    1fd0:	8f75                	and	a4,a4,a3
    1fd2:	01077733          	and	a4,a4,a6
    1fd6:	d37d                	beqz	a4,1fbc <memchr+0x52>
{
    1fd8:	853e                	mv	a0,a5
    1fda:	97b2                	add	a5,a5,a2
    1fdc:	a021                	j	1fe4 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    1fde:	0505                	addi	a0,a0,1
    1fe0:	00f50763          	beq	a0,a5,1fee <memchr+0x84>
    1fe4:	00054703          	lbu	a4,0(a0)
    1fe8:	feb71be3          	bne	a4,a1,1fde <memchr+0x74>
    1fec:	8082                	ret
	return n ? (void *)s : 0;
    1fee:	4501                	li	a0,0
}
    1ff0:	8082                	ret
	return n ? (void *)s : 0;
    1ff2:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    1ff4:	f275                	bnez	a2,1fd8 <memchr+0x6e>
}
    1ff6:	8082                	ret

0000000000001ff8 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    1ff8:	1101                	addi	sp,sp,-32
    1ffa:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    1ffc:	862e                	mv	a2,a1
{
    1ffe:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2000:	4581                	li	a1,0
{
    2002:	e426                	sd	s1,8(sp)
    2004:	ec06                	sd	ra,24(sp)
    2006:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2008:	f63ff0ef          	jal	ra,1f6a <memchr>
	return p ? p - s : n;
    200c:	c519                	beqz	a0,201a <strnlen+0x22>
}
    200e:	60e2                	ld	ra,24(sp)
    2010:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2012:	8d05                	sub	a0,a0,s1
}
    2014:	64a2                	ld	s1,8(sp)
    2016:	6105                	addi	sp,sp,32
    2018:	8082                	ret
    201a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    201c:	8522                	mv	a0,s0
}
    201e:	6442                	ld	s0,16(sp)
    2020:	64a2                	ld	s1,8(sp)
    2022:	6105                	addi	sp,sp,32
    2024:	8082                	ret

0000000000002026 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2026:	00a5c7b3          	xor	a5,a1,a0
    202a:	8b9d                	andi	a5,a5,7
    202c:	eb95                	bnez	a5,2060 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    202e:	0075f793          	andi	a5,a1,7
    2032:	e7b1                	bnez	a5,207e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2034:	6198                	ld	a4,0(a1)
    2036:	00000617          	auipc	a2,0x0
    203a:	7da63603          	ld	a2,2010(a2) # 2810 <enable_deadlock_detect+0x166>
    203e:	00000817          	auipc	a6,0x0
    2042:	7da83803          	ld	a6,2010(a6) # 2818 <enable_deadlock_detect+0x16e>
    2046:	a029                	j	2050 <stpcpy+0x2a>
    2048:	05a1                	addi	a1,a1,8
    204a:	e118                	sd	a4,0(a0)
    204c:	6198                	ld	a4,0(a1)
    204e:	0521                	addi	a0,a0,8
    2050:	00c707b3          	add	a5,a4,a2
    2054:	fff74693          	not	a3,a4
    2058:	8ff5                	and	a5,a5,a3
    205a:	0107f7b3          	and	a5,a5,a6
    205e:	d7ed                	beqz	a5,2048 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2060:	0005c783          	lbu	a5,0(a1)
    2064:	00f50023          	sb	a5,0(a0)
    2068:	c785                	beqz	a5,2090 <stpcpy+0x6a>
    206a:	0015c783          	lbu	a5,1(a1)
    206e:	0505                	addi	a0,a0,1
    2070:	0585                	addi	a1,a1,1
    2072:	00f50023          	sb	a5,0(a0)
    2076:	fbf5                	bnez	a5,206a <stpcpy+0x44>
		;
	return d;
}
    2078:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    207a:	0505                	addi	a0,a0,1
    207c:	df45                	beqz	a4,2034 <stpcpy+0xe>
			if (!(*d = *s))
    207e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2082:	0585                	addi	a1,a1,1
    2084:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2088:	00f50023          	sb	a5,0(a0)
    208c:	f7fd                	bnez	a5,207a <stpcpy+0x54>
}
    208e:	8082                	ret
    2090:	8082                	ret

0000000000002092 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2092:	00a5c7b3          	xor	a5,a1,a0
    2096:	8b9d                	andi	a5,a5,7
    2098:	1a079863          	bnez	a5,2248 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    209c:	0075f793          	andi	a5,a1,7
    20a0:	16078463          	beqz	a5,2208 <stpncpy+0x176>
    20a4:	ea01                	bnez	a2,20b4 <stpncpy+0x22>
    20a6:	a421                	j	22ae <stpncpy+0x21c>
    20a8:	167d                	addi	a2,a2,-1
    20aa:	0505                	addi	a0,a0,1
    20ac:	14070e63          	beqz	a4,2208 <stpncpy+0x176>
    20b0:	1a060863          	beqz	a2,2260 <stpncpy+0x1ce>
    20b4:	0005c783          	lbu	a5,0(a1)
    20b8:	0585                	addi	a1,a1,1
    20ba:	0075f713          	andi	a4,a1,7
    20be:	00f50023          	sb	a5,0(a0)
    20c2:	f3fd                	bnez	a5,20a8 <stpncpy+0x16>
    20c4:	4805                	li	a6,1
    20c6:	1a061863          	bnez	a2,2276 <stpncpy+0x1e4>
    20ca:	40a007b3          	neg	a5,a0
    20ce:	8b9d                	andi	a5,a5,7
    20d0:	4681                	li	a3,0
    20d2:	18061a63          	bnez	a2,2266 <stpncpy+0x1d4>
    20d6:	00778713          	addi	a4,a5,7
    20da:	45ad                	li	a1,11
    20dc:	18b76363          	bltu	a4,a1,2262 <stpncpy+0x1d0>
    20e0:	1ae6eb63          	bltu	a3,a4,2296 <stpncpy+0x204>
    20e4:	1a078363          	beqz	a5,228a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    20e8:	00050023          	sb	zero,0(a0)
    20ec:	4685                	li	a3,1
    20ee:	00150713          	addi	a4,a0,1
    20f2:	18d78f63          	beq	a5,a3,2290 <stpncpy+0x1fe>
    20f6:	000500a3          	sb	zero,1(a0)
    20fa:	4689                	li	a3,2
    20fc:	00250713          	addi	a4,a0,2
    2100:	18d78e63          	beq	a5,a3,229c <stpncpy+0x20a>
    2104:	00050123          	sb	zero,2(a0)
    2108:	468d                	li	a3,3
    210a:	00350713          	addi	a4,a0,3
    210e:	16d78c63          	beq	a5,a3,2286 <stpncpy+0x1f4>
    2112:	000501a3          	sb	zero,3(a0)
    2116:	4691                	li	a3,4
    2118:	00450713          	addi	a4,a0,4
    211c:	18d78263          	beq	a5,a3,22a0 <stpncpy+0x20e>
    2120:	00050223          	sb	zero,4(a0)
    2124:	4695                	li	a3,5
    2126:	00550713          	addi	a4,a0,5
    212a:	16d78d63          	beq	a5,a3,22a4 <stpncpy+0x212>
    212e:	000502a3          	sb	zero,5(a0)
    2132:	469d                	li	a3,7
    2134:	00650713          	addi	a4,a0,6
    2138:	16d79863          	bne	a5,a3,22a8 <stpncpy+0x216>
    213c:	00750713          	addi	a4,a0,7
    2140:	00050323          	sb	zero,6(a0)
    2144:	40f80833          	sub	a6,a6,a5
    2148:	ff887593          	andi	a1,a6,-8
    214c:	97aa                	add	a5,a5,a0
    214e:	95be                	add	a1,a1,a5
    2150:	0007b023          	sd	zero,0(a5)
    2154:	07a1                	addi	a5,a5,8
    2156:	feb79de3          	bne	a5,a1,2150 <stpncpy+0xbe>
    215a:	ff887593          	andi	a1,a6,-8
    215e:	9ead                	addw	a3,a3,a1
    2160:	00b707b3          	add	a5,a4,a1
    2164:	12b80863          	beq	a6,a1,2294 <stpncpy+0x202>
    2168:	00078023          	sb	zero,0(a5)
    216c:	0016871b          	addiw	a4,a3,1
    2170:	0ec77863          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    2174:	000780a3          	sb	zero,1(a5)
    2178:	0026871b          	addiw	a4,a3,2
    217c:	0ec77263          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    2180:	00078123          	sb	zero,2(a5)
    2184:	0036871b          	addiw	a4,a3,3
    2188:	0cc77c63          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    218c:	000781a3          	sb	zero,3(a5)
    2190:	0046871b          	addiw	a4,a3,4
    2194:	0cc77663          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    2198:	00078223          	sb	zero,4(a5)
    219c:	0056871b          	addiw	a4,a3,5
    21a0:	0cc77063          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21a4:	000782a3          	sb	zero,5(a5)
    21a8:	0066871b          	addiw	a4,a3,6
    21ac:	0ac77a63          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21b0:	00078323          	sb	zero,6(a5)
    21b4:	0076871b          	addiw	a4,a3,7
    21b8:	0ac77463          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21bc:	000783a3          	sb	zero,7(a5)
    21c0:	0086871b          	addiw	a4,a3,8
    21c4:	08c77e63          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21c8:	00078423          	sb	zero,8(a5)
    21cc:	0096871b          	addiw	a4,a3,9
    21d0:	08c77863          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21d4:	000784a3          	sb	zero,9(a5)
    21d8:	00a6871b          	addiw	a4,a3,10
    21dc:	08c77263          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21e0:	00078523          	sb	zero,10(a5)
    21e4:	00b6871b          	addiw	a4,a3,11
    21e8:	06c77c63          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21ec:	000785a3          	sb	zero,11(a5)
    21f0:	00c6871b          	addiw	a4,a3,12
    21f4:	06c77663          	bgeu	a4,a2,2260 <stpncpy+0x1ce>
    21f8:	00078623          	sb	zero,12(a5)
    21fc:	26b5                	addiw	a3,a3,13
    21fe:	06c6f163          	bgeu	a3,a2,2260 <stpncpy+0x1ce>
    2202:	000786a3          	sb	zero,13(a5)
    2206:	8082                	ret
			;
		if (!n || !*s)
    2208:	c645                	beqz	a2,22b0 <stpncpy+0x21e>
    220a:	0005c783          	lbu	a5,0(a1)
    220e:	ea078be3          	beqz	a5,20c4 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2212:	479d                	li	a5,7
    2214:	02c7ff63          	bgeu	a5,a2,2252 <stpncpy+0x1c0>
    2218:	00000897          	auipc	a7,0x0
    221c:	5f88b883          	ld	a7,1528(a7) # 2810 <enable_deadlock_detect+0x166>
    2220:	00000817          	auipc	a6,0x0
    2224:	5f883803          	ld	a6,1528(a6) # 2818 <enable_deadlock_detect+0x16e>
    2228:	431d                	li	t1,7
    222a:	6198                	ld	a4,0(a1)
    222c:	011707b3          	add	a5,a4,a7
    2230:	fff74693          	not	a3,a4
    2234:	8ff5                	and	a5,a5,a3
    2236:	0107f7b3          	and	a5,a5,a6
    223a:	ef81                	bnez	a5,2252 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    223c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    223e:	1661                	addi	a2,a2,-8
    2240:	05a1                	addi	a1,a1,8
    2242:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2244:	fec363e3          	bltu	t1,a2,222a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2248:	e609                	bnez	a2,2252 <stpncpy+0x1c0>
    224a:	a08d                	j	22ac <stpncpy+0x21a>
    224c:	167d                	addi	a2,a2,-1
    224e:	0505                	addi	a0,a0,1
    2250:	ca01                	beqz	a2,2260 <stpncpy+0x1ce>
    2252:	0005c783          	lbu	a5,0(a1)
    2256:	0585                	addi	a1,a1,1
    2258:	00f50023          	sb	a5,0(a0)
    225c:	fbe5                	bnez	a5,224c <stpncpy+0x1ba>
		;
tail:
    225e:	b59d                	j	20c4 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2260:	8082                	ret
    2262:	472d                	li	a4,11
    2264:	bdb5                	j	20e0 <stpncpy+0x4e>
    2266:	00778713          	addi	a4,a5,7
    226a:	45ad                	li	a1,11
    226c:	fff60693          	addi	a3,a2,-1
    2270:	e6b778e3          	bgeu	a4,a1,20e0 <stpncpy+0x4e>
    2274:	b7fd                	j	2262 <stpncpy+0x1d0>
    2276:	40a007b3          	neg	a5,a0
    227a:	8832                	mv	a6,a2
    227c:	8b9d                	andi	a5,a5,7
    227e:	4681                	li	a3,0
    2280:	e4060be3          	beqz	a2,20d6 <stpncpy+0x44>
    2284:	b7cd                	j	2266 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2286:	468d                	li	a3,3
    2288:	bd75                	j	2144 <stpncpy+0xb2>
    228a:	872a                	mv	a4,a0
    228c:	4681                	li	a3,0
    228e:	bd5d                	j	2144 <stpncpy+0xb2>
    2290:	4685                	li	a3,1
    2292:	bd4d                	j	2144 <stpncpy+0xb2>
    2294:	8082                	ret
    2296:	87aa                	mv	a5,a0
    2298:	4681                	li	a3,0
    229a:	b5f9                	j	2168 <stpncpy+0xd6>
    229c:	4689                	li	a3,2
    229e:	b55d                	j	2144 <stpncpy+0xb2>
    22a0:	4691                	li	a3,4
    22a2:	b54d                	j	2144 <stpncpy+0xb2>
    22a4:	4695                	li	a3,5
    22a6:	bd79                	j	2144 <stpncpy+0xb2>
    22a8:	4699                	li	a3,6
    22aa:	bd69                	j	2144 <stpncpy+0xb2>
    22ac:	8082                	ret
    22ae:	8082                	ret
    22b0:	8082                	ret

00000000000022b2 <basename>:

char *basename(char *s)
{
    22b2:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22b4:	c54d                	beqz	a0,235e <basename+0xac>
    22b6:	00054783          	lbu	a5,0(a0)
		return ".";
    22ba:	00000517          	auipc	a0,0x0
    22be:	54e50513          	addi	a0,a0,1358 # 2808 <enable_deadlock_detect+0x15e>
	if (!s || !*s)
    22c2:	e391                	bnez	a5,22c6 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22c4:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22c6:	0076f713          	andi	a4,a3,7
    22ca:	87b6                	mv	a5,a3
    22cc:	cf51                	beqz	a4,2368 <basename+0xb6>
    22ce:	0785                	addi	a5,a5,1
    22d0:	0077f713          	andi	a4,a5,7
    22d4:	c729                	beqz	a4,231e <basename+0x6c>
		if (!*s)
    22d6:	0007c703          	lbu	a4,0(a5)
    22da:	fb75                	bnez	a4,22ce <basename+0x1c>
	return s - a;
    22dc:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    22de:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    22e0:	cf8d                	beqz	a5,231a <basename+0x68>
    22e2:	00f68733          	add	a4,a3,a5
    22e6:	02f00593          	li	a1,47
    22ea:	a031                	j	22f6 <basename+0x44>
		s[i] = 0;
    22ec:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    22f0:	17fd                	addi	a5,a5,-1
    22f2:	177d                	addi	a4,a4,-1
    22f4:	c39d                	beqz	a5,231a <basename+0x68>
    22f6:	00074603          	lbu	a2,0(a4)
    22fa:	feb609e3          	beq	a2,a1,22ec <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    22fe:	02f00613          	li	a2,47
    2302:	a011                	j	2306 <basename+0x54>
    2304:	cb99                	beqz	a5,231a <basename+0x68>
    2306:	853e                	mv	a0,a5
    2308:	17fd                	addi	a5,a5,-1
    230a:	00f68733          	add	a4,a3,a5
    230e:	00074703          	lbu	a4,0(a4)
    2312:	fec719e3          	bne	a4,a2,2304 <basename+0x52>
	return s + i;
    2316:	9536                	add	a0,a0,a3
    2318:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    231a:	8536                	mv	a0,a3
    231c:	8082                	ret
    231e:	6390                	ld	a2,0(a5)
    2320:	00000517          	auipc	a0,0x0
    2324:	4f053503          	ld	a0,1264(a0) # 2810 <enable_deadlock_detect+0x166>
    2328:	00000597          	auipc	a1,0x0
    232c:	4f05b583          	ld	a1,1264(a1) # 2818 <enable_deadlock_detect+0x16e>
    2330:	fff64713          	not	a4,a2
    2334:	962a                	add	a2,a2,a0
    2336:	8f71                	and	a4,a4,a2
    2338:	8f6d                	and	a4,a4,a1
    233a:	eb11                	bnez	a4,234e <basename+0x9c>
    233c:	6790                	ld	a2,8(a5)
    233e:	07a1                	addi	a5,a5,8
    2340:	00a60733          	add	a4,a2,a0
    2344:	fff64613          	not	a2,a2
    2348:	8f71                	and	a4,a4,a2
    234a:	8f6d                	and	a4,a4,a1
    234c:	db65                	beqz	a4,233c <basename+0x8a>
	for (; *s; s++)
    234e:	0007c703          	lbu	a4,0(a5)
    2352:	d749                	beqz	a4,22dc <basename+0x2a>
    2354:	0017c703          	lbu	a4,1(a5)
    2358:	0785                	addi	a5,a5,1
    235a:	ff6d                	bnez	a4,2354 <basename+0xa2>
    235c:	b741                	j	22dc <basename+0x2a>
		return ".";
    235e:	00000517          	auipc	a0,0x0
    2362:	4aa50513          	addi	a0,a0,1194 # 2808 <enable_deadlock_detect+0x15e>
    2366:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2368:	6290                	ld	a2,0(a3)
    236a:	00000517          	auipc	a0,0x0
    236e:	4a653503          	ld	a0,1190(a0) # 2810 <enable_deadlock_detect+0x166>
    2372:	00000597          	auipc	a1,0x0
    2376:	4a65b583          	ld	a1,1190(a1) # 2818 <enable_deadlock_detect+0x16e>
    237a:	fff64713          	not	a4,a2
    237e:	962a                	add	a2,a2,a0
    2380:	8f71                	and	a4,a4,a2
    2382:	8f6d                	and	a4,a4,a1
    2384:	df45                	beqz	a4,233c <basename+0x8a>
    2386:	b7f9                	j	2354 <basename+0xa2>

0000000000002388 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2388:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    238c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    238e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2392:	2501                	sext.w	a0,a0
    2394:	8082                	ret

0000000000002396 <close>:

int close(int fd)
{
	if (fd == 1) {
    2396:	4785                	li	a5,1
    2398:	00f50863          	beq	a0,a5,23a8 <close+0x12>
	register long a7 __asm__("a7") = n;
    239c:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23a0:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23a4:	2501                	sext.w	a0,a0
    23a6:	8082                	ret
{
    23a8:	1101                	addi	sp,sp,-32
    23aa:	ec06                	sd	ra,24(sp)
    23ac:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23ae:	cdffe0ef          	jal	ra,108c <__write_buffer>
		__clear_buffer();
    23b2:	d03fe0ef          	jal	ra,10b4 <__clear_buffer>
    23b6:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23b8:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23bc:	00000073          	ecall
}
    23c0:	60e2                	ld	ra,24(sp)
    23c2:	2501                	sext.w	a0,a0
    23c4:	6105                	addi	sp,sp,32
    23c6:	8082                	ret

00000000000023c8 <read>:
	register long a7 __asm__("a7") = n;
    23c8:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23cc:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    23d0:	8082                	ret

00000000000023d2 <write>:
	register long a7 __asm__("a7") = n;
    23d2:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23d6:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    23da:	8082                	ret

00000000000023dc <getpid>:
	register long a7 __asm__("a7") = n;
    23dc:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    23e0:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    23e4:	2501                	sext.w	a0,a0
    23e6:	8082                	ret

00000000000023e8 <getppid>:
	register long a7 __asm__("a7") = n;
    23e8:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    23ec:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    23f0:	2501                	sext.w	a0,a0
    23f2:	8082                	ret

00000000000023f4 <sched_yield>:
	register long a7 __asm__("a7") = n;
    23f4:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    23f8:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    23fc:	2501                	sext.w	a0,a0
    23fe:	8082                	ret

0000000000002400 <fork>:
	register long a7 __asm__("a7") = n;
    2400:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2404:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2408:	2501                	sext.w	a0,a0
    240a:	8082                	ret

000000000000240c <exit>:

void exit(int code)
{
    240c:	1141                	addi	sp,sp,-16
    240e:	e406                	sd	ra,8(sp)
    2410:	e022                	sd	s0,0(sp)
    2412:	842a                	mv	s0,a0
	__write_buffer();
    2414:	c79fe0ef          	jal	ra,108c <__write_buffer>
	__clear_buffer();
    2418:	c9dfe0ef          	jal	ra,10b4 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    241c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2420:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2422:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2426:	60a2                	ld	ra,8(sp)
    2428:	6402                	ld	s0,0(sp)
    242a:	0141                	addi	sp,sp,16
    242c:	8082                	ret

000000000000242e <waitpid>:
	register long a7 __asm__("a7") = n;
    242e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2432:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2436:	2501                	sext.w	a0,a0
    2438:	8082                	ret

000000000000243a <exec>:
	register long a7 __asm__("a7") = n;
    243a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    243e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2442:	2501                	sext.w	a0,a0
    2444:	8082                	ret

0000000000002446 <get_mtime>:

int64 get_mtime()
{
    2446:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2448:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    244c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    244e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2450:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2454:	2501                	sext.w	a0,a0
    2456:	ed01                	bnez	a0,246e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2458:	6722                	ld	a4,8(sp)
    245a:	3e800793          	li	a5,1000
    245e:	6682                	ld	a3,0(sp)
    2460:	02f75733          	divu	a4,a4,a5
    2464:	02d78533          	mul	a0,a5,a3
    2468:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    246a:	0141                	addi	sp,sp,16
    246c:	8082                	ret
	return -1;
    246e:	557d                	li	a0,-1
    2470:	bfed                	j	246a <get_mtime+0x24>

0000000000002472 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2472:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2476:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    247a:	2501                	sext.w	a0,a0
    247c:	8082                	ret

000000000000247e <sleep>:

int sleep(unsigned long long time)
{
    247e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2480:	880a                	mv	a6,sp
{
    2482:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2484:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2488:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    248a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    248c:	00000073          	ecall
	if (err == 0) {
    2490:	2501                	sext.w	a0,a0
    2492:	ed31                	bnez	a0,24ee <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2494:	6722                	ld	a4,8(sp)
    2496:	3e800793          	li	a5,1000
    249a:	6682                	ld	a3,0(sp)
    249c:	02f75733          	divu	a4,a4,a5
    24a0:	02d787b3          	mul	a5,a5,a3
    24a4:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24a6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24aa:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24ac:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ae:	00000073          	ecall
	if (err == 0) {
    24b2:	2501                	sext.w	a0,a0
    24b4:	e915                	bnez	a0,24e8 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24b6:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24b8:	3e800693          	li	a3,1000
    24bc:	a819                	j	24d2 <sleep+0x54>
	__asm_syscall("r"(a7))
    24be:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24c2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24c6:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ca:	00000073          	ecall
	if (err == 0) {
    24ce:	2501                	sext.w	a0,a0
    24d0:	ed01                	bnez	a0,24e8 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    24d2:	6722                	ld	a4,8(sp)
    24d4:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    24d6:	07c00893          	li	a7,124
    24da:	02d75733          	divu	a4,a4,a3
    24de:	02f687b3          	mul	a5,a3,a5
    24e2:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    24e4:	fcc7ede3          	bltu	a5,a2,24be <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    24e8:	4501                	li	a0,0
    24ea:	0141                	addi	sp,sp,16
    24ec:	8082                	ret
    24ee:	57fd                	li	a5,-1
    24f0:	bf5d                	j	24a6 <sleep+0x28>

00000000000024f2 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    24f2:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    24f6:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    24fa:	2501                	sext.w	a0,a0
    24fc:	8082                	ret

00000000000024fe <set_priority>:
	register long a7 __asm__("a7") = n;
    24fe:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2502:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2506:	2501                	sext.w	a0,a0
    2508:	8082                	ret

000000000000250a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    250a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    250e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2512:	2501                	sext.w	a0,a0
    2514:	8082                	ret

0000000000002516 <munmap>:
	register long a7 __asm__("a7") = n;
    2516:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    251a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    251e:	2501                	sext.w	a0,a0
    2520:	8082                	ret

0000000000002522 <wait>:

int wait(int *code)
{
    2522:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2524:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2528:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    252a:	00000073          	ecall
	return waitpid(-1, code);
}
    252e:	2501                	sext.w	a0,a0
    2530:	8082                	ret

0000000000002532 <spawn>:
	register long a7 __asm__("a7") = n;
    2532:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2536:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    253a:	2501                	sext.w	a0,a0
    253c:	8082                	ret

000000000000253e <pipe>:
	register long a7 __asm__("a7") = n;
    253e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2542:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2546:	2501                	sext.w	a0,a0
    2548:	8082                	ret

000000000000254a <mailread>:
	register long a7 __asm__("a7") = n;
    254a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    254e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2552:	2501                	sext.w	a0,a0
    2554:	8082                	ret

0000000000002556 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2556:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    255a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    255e:	2501                	sext.w	a0,a0
    2560:	8082                	ret

0000000000002562 <fstat>:
	register long a7 __asm__("a7") = n;
    2562:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2566:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    256a:	2501                	sext.w	a0,a0
    256c:	8082                	ret

000000000000256e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    256e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2570:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2574:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2576:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    257a:	2501                	sext.w	a0,a0
    257c:	8082                	ret

000000000000257e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    257e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2580:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2584:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2586:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    258a:	2501                	sext.w	a0,a0
    258c:	8082                	ret

000000000000258e <link>:

int link(char *old_path, char *new_path)
{
    258e:	87aa                	mv	a5,a0
    2590:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2592:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2596:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    259a:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    259c:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25a0:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25a2:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25a6:	2501                	sext.w	a0,a0
    25a8:	8082                	ret

00000000000025aa <unlink>:

int unlink(char *path)
{
    25aa:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25ac:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25b0:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25b4:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25b6:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25ba:	2501                	sext.w	a0,a0
    25bc:	8082                	ret

00000000000025be <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25be:	00000797          	auipc	a5,0x0
    25c2:	39a7b783          	ld	a5,922(a5) # 2958 <_GLOBAL_OFFSET_TABLE_+0x8>
    25c6:	439c                	lw	a5,0(a5)
    25c8:	c799                	beqz	a5,25d6 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    25ca:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ce:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    25d2:	2501                	sext.w	a0,a0
    25d4:	8082                	ret
{
    25d6:	1101                	addi	sp,sp,-32
    25d8:	ec06                	sd	ra,24(sp)
    25da:	e42e                	sd	a1,8(sp)
    25dc:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    25de:	fe7fe0ef          	jal	ra,15c4 <enable_thread_io_buffer>
    25e2:	65a2                	ld	a1,8(sp)
    25e4:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    25e6:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25ea:	00000073          	ecall
}
    25ee:	60e2                	ld	ra,24(sp)
    25f0:	2501                	sext.w	a0,a0
    25f2:	6105                	addi	sp,sp,32
    25f4:	8082                	ret

00000000000025f6 <gettid>:
	register long a7 __asm__("a7") = n;
    25f6:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    25fa:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    25fe:	2501                	sext.w	a0,a0
    2600:	8082                	ret

0000000000002602 <waittid>:

int waittid(int tid)
{
    2602:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2604:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2608:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    260c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    260e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2610:	00e51e63          	bne	a0,a4,262c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2614:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2618:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    261c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2620:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2622:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2626:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2628:	fee506e3          	beq	a0,a4,2614 <waittid+0x12>
	}
	return ret;
}
    262c:	8082                	ret

000000000000262e <mutex_create>:
	register long a7 __asm__("a7") = n;
    262e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2632:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2634:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2638:	2501                	sext.w	a0,a0
    263a:	8082                	ret

000000000000263c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    263c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2640:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2642:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret

000000000000264a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    264a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    264e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2652:	2501                	sext.w	a0,a0
    2654:	8082                	ret

0000000000002656 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2656:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    265a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    265e:	2501                	sext.w	a0,a0
    2660:	8082                	ret

0000000000002662 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2662:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2666:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    266a:	2501                	sext.w	a0,a0
    266c:	8082                	ret

000000000000266e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    266e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2672:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2676:	2501                	sext.w	a0,a0
    2678:	8082                	ret

000000000000267a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    267a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    267e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2682:	2501                	sext.w	a0,a0
    2684:	8082                	ret

0000000000002686 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2686:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    268a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    268e:	2501                	sext.w	a0,a0
    2690:	8082                	ret

0000000000002692 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2692:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2696:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    269a:	2501                	sext.w	a0,a0
    269c:	8082                	ret

000000000000269e <condvar_wait>:
	register long a7 __asm__("a7") = n;
    269e:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26a2:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26a6:	2501                	sext.w	a0,a0
    26a8:	8082                	ret

00000000000026aa <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26aa:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26ae:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26b2:	2501                	sext.w	a0,a0
    26b4:	8082                	ret
