
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6_file1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a289                	j	1142 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

/// 测试 fstat，输出　Test fstat OK! 就算正确。

int main()
{
    1002:	7159                	addi	sp,sp,-112
	char *fname = "fname1";
	int fd = open(fname, O_CREATE | O_WRONLY);
    1004:	20100593          	li	a1,513
    1008:	00001517          	auipc	a0,0x1
    100c:	7a050513          	addi	a0,a0,1952 # 27a8 <enable_deadlock_detect+0xc>
{
    1010:	f0a2                	sd	s0,96(sp)
    1012:	f486                	sd	ra,104(sp)
    1014:	eca6                	sd	s1,88(sp)
    1016:	e8ca                	sd	s2,80(sp)
	int fd = open(fname, O_CREATE | O_WRONLY);
    1018:	462010ef          	jal	ra,247a <open>
    101c:	842a                	mv	s0,a0
	assert(fd > 0);
    101e:	0ea05763          	blez	a0,110c <main+0x10a>
	Stat stat;
	int ret = fstat(fd, &stat);
    1022:	858a                	mv	a1,sp
    1024:	8522                	mv	a0,s0
    1026:	62e010ef          	jal	ra,2654 <fstat>
    102a:	84aa                	mv	s1,a0
	assert_eq(ret, 0);
    102c:	e15d                	bnez	a0,10d2 <main+0xd0>
	assert_eq(stat.mode, FILE);
    102e:	4742                	lw	a4,16(sp)
    1030:	001007b7          	lui	a5,0x100
    1034:	02f70f63          	beq	a4,a5,1072 <main+0x70>
    1038:	496010ef          	jal	ra,24ce <getpid>
    103c:	84aa                	mv	s1,a0
    103e:	00001517          	auipc	a0,0x1
    1042:	77250513          	addi	a0,a0,1906 # 27b0 <enable_deadlock_detect+0x14>
    1046:	35e010ef          	jal	ra,23a4 <basename>
    104a:	4842                	lw	a6,16(sp)
    104c:	872a                	mv	a4,a0
    104e:	001008b7          	lui	a7,0x100
    1052:	00001517          	auipc	a0,0x1
    1056:	7de50513          	addi	a0,a0,2014 # 2830 <enable_deadlock_detect+0x94>
    105a:	47c5                	li	a5,17
    105c:	86a6                	mv	a3,s1
    105e:	00001617          	auipc	a2,0x1
    1062:	79a60613          	addi	a2,a2,1946 # 27f8 <enable_deadlock_detect+0x5c>
    1066:	45fd                	li	a1,31
    1068:	234000ef          	jal	ra,129c <printf>
    106c:	557d                	li	a0,-1
    106e:	490010ef          	jal	ra,24fe <exit>
	assert_eq(stat.nlink, 1);
    1072:	4752                	lw	a4,20(sp)
    1074:	4785                	li	a5,1
    1076:	02f70e63          	beq	a4,a5,10b2 <main+0xb0>
    107a:	454010ef          	jal	ra,24ce <getpid>
    107e:	84aa                	mv	s1,a0
    1080:	00001517          	auipc	a0,0x1
    1084:	73050513          	addi	a0,a0,1840 # 27b0 <enable_deadlock_detect+0x14>
    1088:	31c010ef          	jal	ra,23a4 <basename>
    108c:	4852                	lw	a6,20(sp)
    108e:	872a                	mv	a4,a0
    1090:	4885                	li	a7,1
    1092:	00001517          	auipc	a0,0x1
    1096:	79e50513          	addi	a0,a0,1950 # 2830 <enable_deadlock_detect+0x94>
    109a:	47c9                	li	a5,18
    109c:	86a6                	mv	a3,s1
    109e:	00001617          	auipc	a2,0x1
    10a2:	75a60613          	addi	a2,a2,1882 # 27f8 <enable_deadlock_detect+0x5c>
    10a6:	45fd                	li	a1,31
    10a8:	1f4000ef          	jal	ra,129c <printf>
    10ac:	557d                	li	a0,-1
    10ae:	450010ef          	jal	ra,24fe <exit>
	close(fd);
    10b2:	8522                	mv	a0,s0
    10b4:	3d4010ef          	jal	ra,2488 <close>
	// unlink(fname);
	// It's recommended to rebuild the disk image. This program will not clean
	// the file "fname1".
	puts("Test fstat OK!");
    10b8:	00001517          	auipc	a0,0x1
    10bc:	7b050513          	addi	a0,a0,1968 # 2868 <enable_deadlock_detect+0xcc>
    10c0:	0f3000ef          	jal	ra,19b2 <puts>
	return 0;
    10c4:	70a6                	ld	ra,104(sp)
    10c6:	7406                	ld	s0,96(sp)
    10c8:	64e6                	ld	s1,88(sp)
    10ca:	6946                	ld	s2,80(sp)
    10cc:	4501                	li	a0,0
    10ce:	6165                	addi	sp,sp,112
    10d0:	8082                	ret
	assert_eq(ret, 0);
    10d2:	3fc010ef          	jal	ra,24ce <getpid>
    10d6:	892a                	mv	s2,a0
    10d8:	00001517          	auipc	a0,0x1
    10dc:	6d850513          	addi	a0,a0,1752 # 27b0 <enable_deadlock_detect+0x14>
    10e0:	2c4010ef          	jal	ra,23a4 <basename>
    10e4:	872a                	mv	a4,a0
    10e6:	4881                	li	a7,0
    10e8:	00001517          	auipc	a0,0x1
    10ec:	74850513          	addi	a0,a0,1864 # 2830 <enable_deadlock_detect+0x94>
    10f0:	8826                	mv	a6,s1
    10f2:	47c1                	li	a5,16
    10f4:	86ca                	mv	a3,s2
    10f6:	00001617          	auipc	a2,0x1
    10fa:	70260613          	addi	a2,a2,1794 # 27f8 <enable_deadlock_detect+0x5c>
    10fe:	45fd                	li	a1,31
    1100:	19c000ef          	jal	ra,129c <printf>
    1104:	557d                	li	a0,-1
    1106:	3f8010ef          	jal	ra,24fe <exit>
    110a:	b715                	j	102e <main+0x2c>
	assert(fd > 0);
    110c:	3c2010ef          	jal	ra,24ce <getpid>
    1110:	84aa                	mv	s1,a0
    1112:	00001517          	auipc	a0,0x1
    1116:	69e50513          	addi	a0,a0,1694 # 27b0 <enable_deadlock_detect+0x14>
    111a:	28a010ef          	jal	ra,23a4 <basename>
    111e:	872a                	mv	a4,a0
    1120:	47b5                	li	a5,13
    1122:	00001517          	auipc	a0,0x1
    1126:	6de50513          	addi	a0,a0,1758 # 2800 <enable_deadlock_detect+0x64>
    112a:	86a6                	mv	a3,s1
    112c:	00001617          	auipc	a2,0x1
    1130:	6cc60613          	addi	a2,a2,1740 # 27f8 <enable_deadlock_detect+0x5c>
    1134:	45fd                	li	a1,31
    1136:	166000ef          	jal	ra,129c <printf>
    113a:	557d                	li	a0,-1
    113c:	3c2010ef          	jal	ra,24fe <exit>
    1140:	b5cd                	j	1022 <main+0x20>

0000000000001142 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1142:	1141                	addi	sp,sp,-16
    1144:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1146:	ebdff0ef          	jal	ra,1002 <main>
    114a:	3b4010ef          	jal	ra,24fe <exit>
	return 0;
    114e:	60a2                	ld	ra,8(sp)
    1150:	4501                	li	a0,0
    1152:	0141                	addi	sp,sp,16
    1154:	8082                	ret

0000000000001156 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1156:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1158:	4605                	li	a2,1
    115a:	00f10593          	addi	a1,sp,15
    115e:	4501                	li	a0,0
{
    1160:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1162:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1166:	354010ef          	jal	ra,24ba <read>
    116a:	4785                	li	a5,1
    116c:	00f51763          	bne	a0,a5,117a <getchar+0x24>
		return byte;
    1170:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1174:	60e2                	ld	ra,24(sp)
    1176:	6105                	addi	sp,sp,32
    1178:	8082                	ret
		return EOF;
    117a:	557d                	li	a0,-1
    117c:	bfe5                	j	1174 <getchar+0x1e>

000000000000117e <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    117e:	00001517          	auipc	a0,0x1
    1182:	7f252503          	lw	a0,2034(a0) # 2970 <buffer_len>
    1186:	e111                	bnez	a0,118a <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    1188:	8082                	ret
{
    118a:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    118c:	862a                	mv	a2,a0
    118e:	00001597          	auipc	a1,0x1
    1192:	7ea58593          	addi	a1,a1,2026 # 2978 <buffer>
    1196:	4505                	li	a0,1
{
    1198:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    119a:	32a010ef          	jal	ra,24c4 <write>
}
    119e:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11a0:	2501                	sext.w	a0,a0
}
    11a2:	0141                	addi	sp,sp,16
    11a4:	8082                	ret

00000000000011a6 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    11a6:	00001797          	auipc	a5,0x1
    11aa:	7c07a523          	sw	zero,1994(a5) # 2970 <buffer_len>
}
    11ae:	8082                	ret

00000000000011b0 <__fflush>:
	if (buffer_len == 0)
    11b0:	00001517          	auipc	a0,0x1
    11b4:	7c052503          	lw	a0,1984(a0) # 2970 <buffer_len>
    11b8:	e511                	bnez	a0,11c4 <__fflush+0x14>
	buffer_len = 0;
    11ba:	00001797          	auipc	a5,0x1
    11be:	7a07ab23          	sw	zero,1974(a5) # 2970 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11c2:	8082                	ret
{
    11c4:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11c6:	862a                	mv	a2,a0
    11c8:	00001597          	auipc	a1,0x1
    11cc:	7b058593          	addi	a1,a1,1968 # 2978 <buffer>
    11d0:	4505                	li	a0,1
{
    11d2:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11d4:	2f0010ef          	jal	ra,24c4 <write>
	return r >= 0 ? 0 : r;
    11d8:	0005079b          	sext.w	a5,a0
}
    11dc:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    11de:	0017a793          	slti	a5,a5,1
    11e2:	40f007bb          	negw	a5,a5
    11e6:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    11e8:	00001797          	auipc	a5,0x1
    11ec:	7807a423          	sw	zero,1928(a5) # 2970 <buffer_len>
	return r >= 0 ? 0 : r;
    11f0:	2501                	sext.w	a0,a0
}
    11f2:	0141                	addi	sp,sp,16
    11f4:	8082                	ret

00000000000011f6 <fflush>:

int fflush(int fd)
{
    11f6:	1101                	addi	sp,sp,-32
    11f8:	e822                	sd	s0,16(sp)
    11fa:	ec06                	sd	ra,24(sp)
    11fc:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    11fe:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1200:	4401                	li	s0,0
	if (fd == 1) {
    1202:	00e50863          	beq	a0,a4,1212 <fflush+0x1c>
}
    1206:	60e2                	ld	ra,24(sp)
    1208:	8522                	mv	a0,s0
    120a:	6442                	ld	s0,16(sp)
    120c:	64a2                	ld	s1,8(sp)
    120e:	6105                	addi	sp,sp,32
    1210:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1212:	00001497          	auipc	s1,0x1
    1216:	75e48493          	addi	s1,s1,1886 # 2970 <buffer_len>
    121a:	1084a703          	lw	a4,264(s1)
    121e:	02a70e63          	beq	a4,a0,125a <fflush+0x64>
	if (buffer_len == 0)
    1222:	4080                	lw	s0,0(s1)
    1224:	c00d                	beqz	s0,1246 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1226:	8622                	mv	a2,s0
    1228:	00001597          	auipc	a1,0x1
    122c:	75058593          	addi	a1,a1,1872 # 2978 <buffer>
    1230:	294010ef          	jal	ra,24c4 <write>
	return r >= 0 ? 0 : r;
    1234:	0005079b          	sext.w	a5,a0
    1238:	0017a793          	slti	a5,a5,1
    123c:	40f007bb          	negw	a5,a5
    1240:	8d7d                	and	a0,a0,a5
    1242:	0005041b          	sext.w	s0,a0
}
    1246:	60e2                	ld	ra,24(sp)
    1248:	8522                	mv	a0,s0
    124a:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    124c:	00001797          	auipc	a5,0x1
    1250:	7207a223          	sw	zero,1828(a5) # 2970 <buffer_len>
}
    1254:	64a2                	ld	s1,8(sp)
    1256:	6105                	addi	sp,sp,32
    1258:	8082                	ret
			mutex_lock(buffer_lock);
    125a:	10c4a503          	lw	a0,268(s1)
    125e:	4de010ef          	jal	ra,273c <mutex_lock>
	if (buffer_len == 0)
    1262:	4080                	lw	s0,0(s1)
    1264:	e811                	bnez	s0,1278 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1266:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    126a:	00001797          	auipc	a5,0x1
    126e:	7007a323          	sw	zero,1798(a5) # 2970 <buffer_len>
			mutex_unlock(buffer_lock);
    1272:	4d6010ef          	jal	ra,2748 <mutex_unlock>
    1276:	bf41                	j	1206 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1278:	8622                	mv	a2,s0
    127a:	00001597          	auipc	a1,0x1
    127e:	6fe58593          	addi	a1,a1,1790 # 2978 <buffer>
    1282:	4505                	li	a0,1
    1284:	240010ef          	jal	ra,24c4 <write>
	return r >= 0 ? 0 : r;
    1288:	0005079b          	sext.w	a5,a0
    128c:	0017a793          	slti	a5,a5,1
    1290:	40f007bb          	negw	a5,a5
    1294:	8d7d                	and	a0,a0,a5
    1296:	0005041b          	sext.w	s0,a0
	return r;
    129a:	b7f1                	j	1266 <fflush+0x70>

000000000000129c <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    129c:	7131                	addi	sp,sp,-192
    129e:	e0da                	sd	s6,64(sp)
    12a0:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    12a2:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    12a4:	013c                	addi	a5,sp,136
{
    12a6:	f0ca                	sd	s2,96(sp)
    12a8:	ecce                	sd	s3,88(sp)
    12aa:	e8d2                	sd	s4,80(sp)
    12ac:	e4d6                	sd	s5,72(sp)
    12ae:	fc86                	sd	ra,120(sp)
    12b0:	f8a2                	sd	s0,112(sp)
    12b2:	f4a6                	sd	s1,104(sp)
    12b4:	89aa                	mv	s3,a0
    12b6:	e52e                	sd	a1,136(sp)
    12b8:	e932                	sd	a2,144(sp)
    12ba:	ed36                	sd	a3,152(sp)
    12bc:	f13a                	sd	a4,160(sp)
    12be:	f942                	sd	a6,176(sp)
    12c0:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12c2:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12c4:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12c8:	00001a17          	auipc	s4,0x1
    12cc:	6a8a0a13          	addi	s4,s4,1704 # 2970 <buffer_len>
    12d0:	4a85                	li	s5,1
	buf[i++] = '0';
    12d2:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12d6:	0009c783          	lbu	a5,0(s3)
    12da:	18078663          	beqz	a5,1466 <printf+0x1ca>
    12de:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    12e0:	19278d63          	beq	a5,s2,147a <printf+0x1de>
    12e4:	0015c783          	lbu	a5,1(a1)
    12e8:	0585                	addi	a1,a1,1
    12ea:	fbfd                	bnez	a5,12e0 <printf+0x44>
    12ec:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    12ee:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    12f2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    12f6:	1b578863          	beq	a5,s5,14a6 <printf+0x20a>
		len = out_unlocked(s, l);
    12fa:	85a2                	mv	a1,s0
    12fc:	854e                	mv	a0,s3
    12fe:	42a000ef          	jal	ra,1728 <out_unlocked>
		out(f, a, l);
		if (l)
    1302:	1c041063          	bnez	s0,14c2 <printf+0x226>
			continue;
		if (s[1] == 0)
    1306:	0014c783          	lbu	a5,1(s1)
    130a:	14078e63          	beqz	a5,1466 <printf+0x1ca>
			break;
		switch (s[1]) {
    130e:	07300713          	li	a4,115
    1312:	1ce78863          	beq	a5,a4,14e2 <printf+0x246>
    1316:	1af76863          	bltu	a4,a5,14c6 <printf+0x22a>
    131a:	06400713          	li	a4,100
    131e:	22e78063          	beq	a5,a4,153e <printf+0x2a2>
    1322:	07000713          	li	a4,112
    1326:	1ee79563          	bne	a5,a4,1510 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    132a:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    132c:	00001797          	auipc	a5,0x1
    1330:	75478793          	addi	a5,a5,1876 # 2a80 <digits>
	buf[i++] = '0';
    1334:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1338:	6298                	ld	a4,0(a3)
    133a:	06a1                	addi	a3,a3,8
    133c:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    133e:	00471393          	slli	t2,a4,0x4
    1342:	00871293          	slli	t0,a4,0x8
    1346:	00c71f93          	slli	t6,a4,0xc
    134a:	01071f13          	slli	t5,a4,0x10
    134e:	01471e93          	slli	t4,a4,0x14
    1352:	01871e13          	slli	t3,a4,0x18
    1356:	01c71893          	slli	a7,a4,0x1c
    135a:	02471813          	slli	a6,a4,0x24
    135e:	02871513          	slli	a0,a4,0x28
    1362:	02c71593          	slli	a1,a4,0x2c
    1366:	03071613          	slli	a2,a4,0x30
    136a:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    136e:	03c75413          	srli	s0,a4,0x3c
    1372:	01c7531b          	srliw	t1,a4,0x1c
    1376:	03c3d393          	srli	t2,t2,0x3c
    137a:	03c2d293          	srli	t0,t0,0x3c
    137e:	03cfdf93          	srli	t6,t6,0x3c
    1382:	03cf5f13          	srli	t5,t5,0x3c
    1386:	03cede93          	srli	t4,t4,0x3c
    138a:	03ce5e13          	srli	t3,t3,0x3c
    138e:	03c8d893          	srli	a7,a7,0x3c
    1392:	03c85813          	srli	a6,a6,0x3c
    1396:	9171                	srli	a0,a0,0x3c
    1398:	91f1                	srli	a1,a1,0x3c
    139a:	9271                	srli	a2,a2,0x3c
    139c:	92f1                	srli	a3,a3,0x3c
    139e:	95be                	add	a1,a1,a5
    13a0:	963e                	add	a2,a2,a5
    13a2:	96be                	add	a3,a3,a5
    13a4:	943e                	add	s0,s0,a5
    13a6:	93be                	add	t2,t2,a5
    13a8:	92be                	add	t0,t0,a5
    13aa:	9fbe                	add	t6,t6,a5
    13ac:	9f3e                	add	t5,t5,a5
    13ae:	9ebe                	add	t4,t4,a5
    13b0:	9e3e                	add	t3,t3,a5
    13b2:	98be                	add	a7,a7,a5
    13b4:	933e                	add	t1,t1,a5
    13b6:	983e                	add	a6,a6,a5
    13b8:	953e                	add	a0,a0,a5
    13ba:	0005c983          	lbu	s3,0(a1)
    13be:	00044403          	lbu	s0,0(s0)
    13c2:	00064583          	lbu	a1,0(a2)
    13c6:	0003c383          	lbu	t2,0(t2)
    13ca:	0006c603          	lbu	a2,0(a3)
    13ce:	0002c283          	lbu	t0,0(t0)
    13d2:	000fcf83          	lbu	t6,0(t6)
    13d6:	000f4f03          	lbu	t5,0(t5)
    13da:	000ece83          	lbu	t4,0(t4)
    13de:	000e4e03          	lbu	t3,0(t3)
    13e2:	0008c883          	lbu	a7,0(a7) # 100000 <.got.plt+0xfd558>
    13e6:	00034303          	lbu	t1,0(t1)
    13ea:	00084803          	lbu	a6,0(a6)
    13ee:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    13f2:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13f6:	92f1                	srli	a3,a3,0x3c
    13f8:	8b3d                	andi	a4,a4,15
    13fa:	96be                	add	a3,a3,a5
    13fc:	97ba                	add	a5,a5,a4
    13fe:	00810d23          	sb	s0,26(sp)
    1402:	00710da3          	sb	t2,27(sp)
    1406:	00510e23          	sb	t0,28(sp)
    140a:	01f10ea3          	sb	t6,29(sp)
    140e:	01e10f23          	sb	t5,30(sp)
    1412:	01d10fa3          	sb	t4,31(sp)
    1416:	03c10023          	sb	t3,32(sp)
    141a:	031100a3          	sb	a7,33(sp)
    141e:	02610123          	sb	t1,34(sp)
    1422:	030101a3          	sb	a6,35(sp)
    1426:	02a10223          	sb	a0,36(sp)
    142a:	033102a3          	sb	s3,37(sp)
    142e:	02b10323          	sb	a1,38(sp)
    1432:	02c103a3          	sb	a2,39(sp)
    1436:	0006c683          	lbu	a3,0(a3)
    143a:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    143e:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1442:	02d10423          	sb	a3,40(sp)
    1446:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    144a:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    144e:	11578263          	beq	a5,s5,1552 <printf+0x2b6>
		len = out_unlocked(s, l);
    1452:	45c9                	li	a1,18
    1454:	0828                	addi	a0,sp,24
    1456:	2d2000ef          	jal	ra,1728 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    145a:	00248993          	addi	s3,s1,2
		if (!*s)
    145e:	0009c783          	lbu	a5,0(s3)
    1462:	e6079ee3          	bnez	a5,12de <printf+0x42>
	}
	va_end(ap);
    1466:	70e6                	ld	ra,120(sp)
    1468:	7446                	ld	s0,112(sp)
    146a:	74a6                	ld	s1,104(sp)
    146c:	7906                	ld	s2,96(sp)
    146e:	69e6                	ld	s3,88(sp)
    1470:	6a46                	ld	s4,80(sp)
    1472:	6aa6                	ld	s5,72(sp)
    1474:	6b06                	ld	s6,64(sp)
    1476:	6129                	addi	sp,sp,192
    1478:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    147a:	0005c783          	lbu	a5,0(a1)
    147e:	84ae                	mv	s1,a1
    1480:	01278963          	beq	a5,s2,1492 <printf+0x1f6>
    1484:	b5ad                	j	12ee <printf+0x52>
    1486:	0024c783          	lbu	a5,2(s1)
    148a:	0585                	addi	a1,a1,1
    148c:	0489                	addi	s1,s1,2
    148e:	e72790e3          	bne	a5,s2,12ee <printf+0x52>
    1492:	0014c783          	lbu	a5,1(s1)
    1496:	ff2788e3          	beq	a5,s2,1486 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    149a:	108a2783          	lw	a5,264(s4)
		l = z - a;
    149e:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14a2:	e5579ce3          	bne	a5,s5,12fa <printf+0x5e>
		mutex_lock(buffer_lock);
    14a6:	10ca2503          	lw	a0,268(s4)
    14aa:	292010ef          	jal	ra,273c <mutex_lock>
		len = out_unlocked(s, l);
    14ae:	85a2                	mv	a1,s0
    14b0:	854e                	mv	a0,s3
    14b2:	276000ef          	jal	ra,1728 <out_unlocked>
		mutex_unlock(buffer_lock);
    14b6:	10ca2503          	lw	a0,268(s4)
    14ba:	28e010ef          	jal	ra,2748 <mutex_unlock>
		if (l)
    14be:	e40404e3          	beqz	s0,1306 <printf+0x6a>
    14c2:	89a6                	mv	s3,s1
    14c4:	bd09                	j	12d6 <printf+0x3a>
		switch (s[1]) {
    14c6:	07800713          	li	a4,120
    14ca:	04e79363          	bne	a5,a4,1510 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    14ce:	67c2                	ld	a5,16(sp)
    14d0:	45c1                	li	a1,16
		s += 2;
    14d2:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14d6:	4388                	lw	a0,0(a5)
    14d8:	07a1                	addi	a5,a5,8
    14da:	e83e                	sd	a5,16(sp)
    14dc:	5f8000ef          	jal	ra,1ad4 <printint.constprop.0>
		s += 2;
    14e0:	bfbd                	j	145e <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    14e2:	67c2                	ld	a5,16(sp)
    14e4:	6380                	ld	s0,0(a5)
    14e6:	07a1                	addi	a5,a5,8
    14e8:	e83e                	sd	a5,16(sp)
    14ea:	1c040163          	beqz	s0,16ac <printf+0x410>
			l = strnlen(a, 200);
    14ee:	0c800593          	li	a1,200
    14f2:	8522                	mv	a0,s0
    14f4:	3f7000ef          	jal	ra,20ea <strnlen>
	if (buffer_lock_enabled == 1) {
    14f8:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    14fc:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1500:	19578663          	beq	a5,s5,168c <printf+0x3f0>
		len = out_unlocked(s, l);
    1504:	8522                	mv	a0,s0
    1506:	222000ef          	jal	ra,1728 <out_unlocked>
		s += 2;
    150a:	00248993          	addi	s3,s1,2
    150e:	bf81                	j	145e <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1510:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1514:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1518:	0f578663          	beq	a5,s5,1604 <printf+0x368>
		len = out_unlocked(s, l);
    151c:	0828                	addi	a0,sp,24
    151e:	316000ef          	jal	ra,1834 <out_unlocked.constprop.0>
			putchar(s[1]);
    1522:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1526:	108a2783          	lw	a5,264(s4)
	char byte = c;
    152a:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    152e:	05578163          	beq	a5,s5,1570 <printf+0x2d4>
		len = out_unlocked(s, l);
    1532:	0828                	addi	a0,sp,24
    1534:	300000ef          	jal	ra,1834 <out_unlocked.constprop.0>
		s += 2;
    1538:	00248993          	addi	s3,s1,2
    153c:	b70d                	j	145e <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    153e:	67c2                	ld	a5,16(sp)
    1540:	45a9                	li	a1,10
		s += 2;
    1542:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1546:	4388                	lw	a0,0(a5)
    1548:	07a1                	addi	a5,a5,8
    154a:	e83e                	sd	a5,16(sp)
    154c:	588000ef          	jal	ra,1ad4 <printint.constprop.0>
		s += 2;
    1550:	b739                	j	145e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1552:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1556:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    155a:	1e2010ef          	jal	ra,273c <mutex_lock>
		len = out_unlocked(s, l);
    155e:	45c9                	li	a1,18
    1560:	0828                	addi	a0,sp,24
    1562:	1c6000ef          	jal	ra,1728 <out_unlocked>
		mutex_unlock(buffer_lock);
    1566:	10ca2503          	lw	a0,268(s4)
    156a:	1de010ef          	jal	ra,2748 <mutex_unlock>
		s += 2;
    156e:	bdc5                	j	145e <printf+0x1c2>
		mutex_lock(buffer_lock);
    1570:	10ca2503          	lw	a0,268(s4)
    1574:	1c8010ef          	jal	ra,273c <mutex_lock>
		buffer[buffer_len++] = c;
    1578:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    157c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1580:	0017861b          	addiw	a2,a5,1
    1584:	97d2                	add	a5,a5,s4
    1586:	00ca2023          	sw	a2,0(s4)
    158a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    158e:	00c6cc63          	blt	a3,a2,15a6 <printf+0x30a>
    1592:	47a9                	li	a5,10
    1594:	06f40663          	beq	s0,a5,1600 <printf+0x364>
		mutex_unlock(buffer_lock);
    1598:	10ca2503          	lw	a0,268(s4)
		s += 2;
    159c:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    15a0:	1a8010ef          	jal	ra,2748 <mutex_unlock>
		s += 2;
    15a4:	bd6d                	j	145e <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    15a6:	10000793          	li	a5,256
    15aa:	00f61e63          	bne	a2,a5,15c6 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    15ae:	00001597          	auipc	a1,0x1
    15b2:	3ca58593          	addi	a1,a1,970 # 2978 <buffer>
    15b6:	4505                	li	a0,1
    15b8:	70d000ef          	jal	ra,24c4 <write>
	buffer_len = 0;
    15bc:	00001797          	auipc	a5,0x1
    15c0:	3a07aa23          	sw	zero,948(a5) # 2970 <buffer_len>
			if (r < 0) {
    15c4:	bfd1                	j	1598 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15c6:	709000ef          	jal	ra,24ce <getpid>
    15ca:	842a                	mv	s0,a0
    15cc:	00001517          	auipc	a0,0x1
    15d0:	2b450513          	addi	a0,a0,692 # 2880 <enable_deadlock_detect+0xe4>
    15d4:	5d1000ef          	jal	ra,23a4 <basename>
    15d8:	872a                	mv	a4,a0
    15da:	00001617          	auipc	a2,0x1
    15de:	21e60613          	addi	a2,a2,542 # 27f8 <enable_deadlock_detect+0x5c>
    15e2:	05400793          	li	a5,84
    15e6:	86a2                	mv	a3,s0
    15e8:	45fd                	li	a1,31
    15ea:	00001517          	auipc	a0,0x1
    15ee:	2d650513          	addi	a0,a0,726 # 28c0 <enable_deadlock_detect+0x124>
    15f2:	cabff0ef          	jal	ra,129c <printf>
    15f6:	557d                	li	a0,-1
    15f8:	707000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    15fc:	000a2603          	lw	a2,0(s4)
    1600:	de41                	beqz	a2,1598 <printf+0x2fc>
    1602:	b775                	j	15ae <printf+0x312>
		mutex_lock(buffer_lock);
    1604:	10ca2503          	lw	a0,268(s4)
    1608:	134010ef          	jal	ra,273c <mutex_lock>
		buffer[buffer_len++] = c;
    160c:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1610:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1614:	0017861b          	addiw	a2,a5,1
    1618:	97d2                	add	a5,a5,s4
    161a:	00ca2023          	sw	a2,0(s4)
    161e:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1622:	02c6d163          	bge	a3,a2,1644 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1626:	10000793          	li	a5,256
    162a:	02f61263          	bne	a2,a5,164e <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    162e:	00001597          	auipc	a1,0x1
    1632:	34a58593          	addi	a1,a1,842 # 2978 <buffer>
    1636:	4505                	li	a0,1
    1638:	68d000ef          	jal	ra,24c4 <write>
	buffer_len = 0;
    163c:	00001797          	auipc	a5,0x1
    1640:	3207aa23          	sw	zero,820(a5) # 2970 <buffer_len>
		mutex_unlock(buffer_lock);
    1644:	10ca2503          	lw	a0,268(s4)
    1648:	100010ef          	jal	ra,2748 <mutex_unlock>
    164c:	bdd9                	j	1522 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    164e:	681000ef          	jal	ra,24ce <getpid>
    1652:	842a                	mv	s0,a0
    1654:	00001517          	auipc	a0,0x1
    1658:	22c50513          	addi	a0,a0,556 # 2880 <enable_deadlock_detect+0xe4>
    165c:	549000ef          	jal	ra,23a4 <basename>
    1660:	872a                	mv	a4,a0
    1662:	00001617          	auipc	a2,0x1
    1666:	19660613          	addi	a2,a2,406 # 27f8 <enable_deadlock_detect+0x5c>
    166a:	05400793          	li	a5,84
    166e:	86a2                	mv	a3,s0
    1670:	45fd                	li	a1,31
    1672:	00001517          	auipc	a0,0x1
    1676:	24e50513          	addi	a0,a0,590 # 28c0 <enable_deadlock_detect+0x124>
    167a:	c23ff0ef          	jal	ra,129c <printf>
    167e:	557d                	li	a0,-1
    1680:	67f000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    1684:	000a2603          	lw	a2,0(s4)
    1688:	de55                	beqz	a2,1644 <printf+0x3a8>
    168a:	b755                	j	162e <printf+0x392>
		mutex_lock(buffer_lock);
    168c:	10ca2503          	lw	a0,268(s4)
    1690:	e42e                	sd	a1,8(sp)
		s += 2;
    1692:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1696:	0a6010ef          	jal	ra,273c <mutex_lock>
		len = out_unlocked(s, l);
    169a:	65a2                	ld	a1,8(sp)
    169c:	8522                	mv	a0,s0
    169e:	08a000ef          	jal	ra,1728 <out_unlocked>
		mutex_unlock(buffer_lock);
    16a2:	10ca2503          	lw	a0,268(s4)
    16a6:	0a2010ef          	jal	ra,2748 <mutex_unlock>
		s += 2;
    16aa:	bb55                	j	145e <printf+0x1c2>
				a = "(null)";
    16ac:	00001417          	auipc	s0,0x1
    16b0:	1cc40413          	addi	s0,s0,460 # 2878 <enable_deadlock_detect+0xdc>
    16b4:	bd2d                	j	14ee <printf+0x252>

00000000000016b6 <enable_thread_io_buffer>:
{
    16b6:	1101                	addi	sp,sp,-32
    16b8:	e822                	sd	s0,16(sp)
    16ba:	ec06                	sd	ra,24(sp)
    16bc:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    16be:	00001417          	auipc	s0,0x1
    16c2:	2b240413          	addi	s0,s0,690 # 2970 <buffer_len>
    16c6:	05a010ef          	jal	ra,2720 <mutex_create>
    16ca:	10a42623          	sw	a0,268(s0)
    16ce:	00054a63          	bltz	a0,16e2 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16d2:	4785                	li	a5,1
}
    16d4:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16d6:	10f42423          	sw	a5,264(s0)
}
    16da:	6442                	ld	s0,16(sp)
    16dc:	64a2                	ld	s1,8(sp)
    16de:	6105                	addi	sp,sp,32
    16e0:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    16e2:	5ed000ef          	jal	ra,24ce <getpid>
    16e6:	84aa                	mv	s1,a0
    16e8:	00001517          	auipc	a0,0x1
    16ec:	19850513          	addi	a0,a0,408 # 2880 <enable_deadlock_detect+0xe4>
    16f0:	4b5000ef          	jal	ra,23a4 <basename>
    16f4:	872a                	mv	a4,a0
    16f6:	04800793          	li	a5,72
    16fa:	86a6                	mv	a3,s1
    16fc:	00001517          	auipc	a0,0x1
    1700:	20450513          	addi	a0,a0,516 # 2900 <enable_deadlock_detect+0x164>
    1704:	00001617          	auipc	a2,0x1
    1708:	0f460613          	addi	a2,a2,244 # 27f8 <enable_deadlock_detect+0x5c>
    170c:	45fd                	li	a1,31
    170e:	b8fff0ef          	jal	ra,129c <printf>
    1712:	557d                	li	a0,-1
    1714:	5eb000ef          	jal	ra,24fe <exit>
	buffer_lock_enabled = 1;
    1718:	4785                	li	a5,1
}
    171a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    171c:	10f42423          	sw	a5,264(s0)
}
    1720:	6442                	ld	s0,16(sp)
    1722:	64a2                	ld	s1,8(sp)
    1724:	6105                	addi	sp,sp,32
    1726:	8082                	ret

0000000000001728 <out_unlocked>:
{
    1728:	7159                	addi	sp,sp,-112
    172a:	f486                	sd	ra,104(sp)
    172c:	f0a2                	sd	s0,96(sp)
    172e:	eca6                	sd	s1,88(sp)
    1730:	e8ca                	sd	s2,80(sp)
    1732:	e4ce                	sd	s3,72(sp)
    1734:	e0d2                	sd	s4,64(sp)
    1736:	fc56                	sd	s5,56(sp)
    1738:	f85a                	sd	s6,48(sp)
    173a:	f45e                	sd	s7,40(sp)
    173c:	f062                	sd	s8,32(sp)
    173e:	ec66                	sd	s9,24(sp)
    1740:	e86a                	sd	s10,16(sp)
    1742:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1744:	0e058663          	beqz	a1,1830 <out_unlocked+0x108>
    1748:	842a                	mv	s0,a0
    174a:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    174e:	4981                	li	s3,0
    1750:	00001d17          	auipc	s10,0x1
    1754:	220d0d13          	addi	s10,s10,544 # 2970 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1758:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    175c:	00001b17          	auipc	s6,0x1
    1760:	21cb0b13          	addi	s6,s6,540 # 2978 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1764:	10000a93          	li	s5,256
    1768:	00001c97          	auipc	s9,0x1
    176c:	118c8c93          	addi	s9,s9,280 # 2880 <enable_deadlock_detect+0xe4>
    1770:	00001c17          	auipc	s8,0x1
    1774:	088c0c13          	addi	s8,s8,136 # 27f8 <enable_deadlock_detect+0x5c>
    1778:	00001b97          	auipc	s7,0x1
    177c:	148b8b93          	addi	s7,s7,328 # 28c0 <enable_deadlock_detect+0x124>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1780:	4a29                	li	s4,10
    1782:	a031                	j	178e <out_unlocked+0x66>
    1784:	09468863          	beq	a3,s4,1814 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    1788:	0405                	addi	s0,s0,1
    178a:	04848163          	beq	s1,s0,17cc <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    178e:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1792:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    1796:	0017861b          	addiw	a2,a5,1
    179a:	97ea                	add	a5,a5,s10
    179c:	00cd2023          	sw	a2,0(s10)
    17a0:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17a4:	fec950e3          	bge	s2,a2,1784 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    17a8:	05561263          	bne	a2,s5,17ec <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    17ac:	85da                	mv	a1,s6
    17ae:	4505                	li	a0,1
    17b0:	515000ef          	jal	ra,24c4 <write>
    17b4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17b6:	00001797          	auipc	a5,0x1
    17ba:	1a07ad23          	sw	zero,442(a5) # 2970 <buffer_len>
			if (r < 0) {
    17be:	06054763          	bltz	a0,182c <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17c2:	0405                	addi	s0,s0,1
			ret += r;
    17c4:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17c8:	fc8493e3          	bne	s1,s0,178e <out_unlocked+0x66>
}
    17cc:	70a6                	ld	ra,104(sp)
    17ce:	7406                	ld	s0,96(sp)
    17d0:	64e6                	ld	s1,88(sp)
    17d2:	6946                	ld	s2,80(sp)
    17d4:	6a06                	ld	s4,64(sp)
    17d6:	7ae2                	ld	s5,56(sp)
    17d8:	7b42                	ld	s6,48(sp)
    17da:	7ba2                	ld	s7,40(sp)
    17dc:	7c02                	ld	s8,32(sp)
    17de:	6ce2                	ld	s9,24(sp)
    17e0:	6d42                	ld	s10,16(sp)
    17e2:	6da2                	ld	s11,8(sp)
    17e4:	854e                	mv	a0,s3
    17e6:	69a6                	ld	s3,72(sp)
    17e8:	6165                	addi	sp,sp,112
    17ea:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17ec:	4e3000ef          	jal	ra,24ce <getpid>
    17f0:	8daa                	mv	s11,a0
    17f2:	8566                	mv	a0,s9
    17f4:	3b1000ef          	jal	ra,23a4 <basename>
    17f8:	872a                	mv	a4,a0
    17fa:	8662                	mv	a2,s8
    17fc:	05400793          	li	a5,84
    1800:	86ee                	mv	a3,s11
    1802:	45fd                	li	a1,31
    1804:	855e                	mv	a0,s7
    1806:	a97ff0ef          	jal	ra,129c <printf>
    180a:	557d                	li	a0,-1
    180c:	4f3000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    1810:	000d2603          	lw	a2,0(s10)
    1814:	da35                	beqz	a2,1788 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1816:	85da                	mv	a1,s6
    1818:	4505                	li	a0,1
    181a:	4ab000ef          	jal	ra,24c4 <write>
    181e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1820:	00001797          	auipc	a5,0x1
    1824:	1407a823          	sw	zero,336(a5) # 2970 <buffer_len>
			if (r < 0) {
    1828:	f8055de3          	bgez	a0,17c2 <out_unlocked+0x9a>
    182c:	89aa                	mv	s3,a0
    182e:	bf79                	j	17cc <out_unlocked+0xa4>
	int ret = 0;
    1830:	4981                	li	s3,0
    1832:	bf69                	j	17cc <out_unlocked+0xa4>

0000000000001834 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1834:	1101                	addi	sp,sp,-32
    1836:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1838:	00001497          	auipc	s1,0x1
    183c:	13848493          	addi	s1,s1,312 # 2970 <buffer_len>
    1840:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1842:	ec06                	sd	ra,24(sp)
    1844:	e822                	sd	s0,16(sp)
		char c = s[i];
    1846:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    184a:	0017861b          	addiw	a2,a5,1
    184e:	97a6                	add	a5,a5,s1
    1850:	00e78423          	sb	a4,8(a5)
    1854:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1856:	0ff00793          	li	a5,255
    185a:	00c7cc63          	blt	a5,a2,1872 <out_unlocked.constprop.0+0x3e>
    185e:	47a9                	li	a5,10
    1860:	06f70c63          	beq	a4,a5,18d8 <out_unlocked.constprop.0+0xa4>
    1864:	4601                	li	a2,0
}
    1866:	60e2                	ld	ra,24(sp)
    1868:	6442                	ld	s0,16(sp)
    186a:	64a2                	ld	s1,8(sp)
    186c:	8532                	mv	a0,a2
    186e:	6105                	addi	sp,sp,32
    1870:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1872:	10000793          	li	a5,256
    1876:	02f61563          	bne	a2,a5,18a0 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    187a:	00001597          	auipc	a1,0x1
    187e:	0fe58593          	addi	a1,a1,254 # 2978 <buffer>
    1882:	4505                	li	a0,1
    1884:	441000ef          	jal	ra,24c4 <write>
}
    1888:	60e2                	ld	ra,24(sp)
    188a:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    188c:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1890:	00001797          	auipc	a5,0x1
    1894:	0e07a023          	sw	zero,224(a5) # 2970 <buffer_len>
}
    1898:	64a2                	ld	s1,8(sp)
    189a:	8532                	mv	a0,a2
    189c:	6105                	addi	sp,sp,32
    189e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18a0:	42f000ef          	jal	ra,24ce <getpid>
    18a4:	842a                	mv	s0,a0
    18a6:	00001517          	auipc	a0,0x1
    18aa:	fda50513          	addi	a0,a0,-38 # 2880 <enable_deadlock_detect+0xe4>
    18ae:	2f7000ef          	jal	ra,23a4 <basename>
    18b2:	872a                	mv	a4,a0
    18b4:	00001617          	auipc	a2,0x1
    18b8:	f4460613          	addi	a2,a2,-188 # 27f8 <enable_deadlock_detect+0x5c>
    18bc:	05400793          	li	a5,84
    18c0:	86a2                	mv	a3,s0
    18c2:	45fd                	li	a1,31
    18c4:	00001517          	auipc	a0,0x1
    18c8:	ffc50513          	addi	a0,a0,-4 # 28c0 <enable_deadlock_detect+0x124>
    18cc:	9d1ff0ef          	jal	ra,129c <printf>
    18d0:	557d                	li	a0,-1
    18d2:	42d000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    18d6:	4090                	lw	a2,0(s1)
    18d8:	d659                	beqz	a2,1866 <out_unlocked.constprop.0+0x32>
    18da:	b745                	j	187a <out_unlocked.constprop.0+0x46>

00000000000018dc <putchar>:
{
    18dc:	7139                	addi	sp,sp,-64
    18de:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    18e0:	00001497          	auipc	s1,0x1
    18e4:	09048493          	addi	s1,s1,144 # 2970 <buffer_len>
    18e8:	1084a703          	lw	a4,264(s1)
{
    18ec:	f822                	sd	s0,48(sp)
	char byte = c;
    18ee:	0ff57413          	zext.b	s0,a0
{
    18f2:	fc06                	sd	ra,56(sp)
	char byte = c;
    18f4:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    18f8:	4785                	li	a5,1
    18fa:	00f70d63          	beq	a4,a5,1914 <putchar+0x38>
		len = out_unlocked(s, l);
    18fe:	01f10513          	addi	a0,sp,31
    1902:	f33ff0ef          	jal	ra,1834 <out_unlocked.constprop.0>
}
    1906:	70e2                	ld	ra,56(sp)
    1908:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    190a:	862a                	mv	a2,a0
}
    190c:	74a2                	ld	s1,40(sp)
    190e:	8532                	mv	a0,a2
    1910:	6121                	addi	sp,sp,64
    1912:	8082                	ret
		mutex_lock(buffer_lock);
    1914:	10c4a503          	lw	a0,268(s1)
    1918:	625000ef          	jal	ra,273c <mutex_lock>
		buffer[buffer_len++] = c;
    191c:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    191e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1922:	0017861b          	addiw	a2,a5,1
    1926:	97a6                	add	a5,a5,s1
    1928:	c090                	sw	a2,0(s1)
    192a:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    192e:	02c6c263          	blt	a3,a2,1952 <putchar+0x76>
    1932:	47a9                	li	a5,10
    1934:	06f40d63          	beq	s0,a5,19ae <putchar+0xd2>
    1938:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    193a:	10c4a503          	lw	a0,268(s1)
    193e:	e432                	sd	a2,8(sp)
    1940:	609000ef          	jal	ra,2748 <mutex_unlock>
    1944:	6622                	ld	a2,8(sp)
}
    1946:	70e2                	ld	ra,56(sp)
    1948:	7442                	ld	s0,48(sp)
    194a:	74a2                	ld	s1,40(sp)
    194c:	8532                	mv	a0,a2
    194e:	6121                	addi	sp,sp,64
    1950:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1952:	10000793          	li	a5,256
    1956:	02f61063          	bne	a2,a5,1976 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    195a:	00001597          	auipc	a1,0x1
    195e:	01e58593          	addi	a1,a1,30 # 2978 <buffer>
    1962:	4505                	li	a0,1
    1964:	361000ef          	jal	ra,24c4 <write>
    1968:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    196c:	00001797          	auipc	a5,0x1
    1970:	0007a223          	sw	zero,4(a5) # 2970 <buffer_len>
			if (r < 0) {
    1974:	b7d9                	j	193a <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1976:	359000ef          	jal	ra,24ce <getpid>
    197a:	842a                	mv	s0,a0
    197c:	00001517          	auipc	a0,0x1
    1980:	f0450513          	addi	a0,a0,-252 # 2880 <enable_deadlock_detect+0xe4>
    1984:	221000ef          	jal	ra,23a4 <basename>
    1988:	872a                	mv	a4,a0
    198a:	00001617          	auipc	a2,0x1
    198e:	e6e60613          	addi	a2,a2,-402 # 27f8 <enable_deadlock_detect+0x5c>
    1992:	05400793          	li	a5,84
    1996:	86a2                	mv	a3,s0
    1998:	45fd                	li	a1,31
    199a:	00001517          	auipc	a0,0x1
    199e:	f2650513          	addi	a0,a0,-218 # 28c0 <enable_deadlock_detect+0x124>
    19a2:	8fbff0ef          	jal	ra,129c <printf>
    19a6:	557d                	li	a0,-1
    19a8:	357000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    19ac:	4090                	lw	a2,0(s1)
    19ae:	d651                	beqz	a2,193a <putchar+0x5e>
    19b0:	b76d                	j	195a <putchar+0x7e>

00000000000019b2 <puts>:
{
    19b2:	7139                	addi	sp,sp,-64
    19b4:	f822                	sd	s0,48(sp)
    19b6:	f426                	sd	s1,40(sp)
    19b8:	fc06                	sd	ra,56(sp)
    19ba:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    19bc:	00001417          	auipc	s0,0x1
    19c0:	fb440413          	addi	s0,s0,-76 # 2970 <buffer_len>
{
    19c4:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19c6:	638000ef          	jal	ra,1ffe <strlen>
	if (buffer_lock_enabled == 1) {
    19ca:	10842703          	lw	a4,264(s0)
    19ce:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19d0:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19d2:	04f70563          	beq	a4,a5,1a1c <puts+0x6a>
		len = out_unlocked(s, l);
    19d6:	8526                	mv	a0,s1
    19d8:	d51ff0ef          	jal	ra,1728 <out_unlocked>
    19dc:	892a                	mv	s2,a0
    19de:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19e0:	00095963          	bgez	s2,19f2 <puts+0x40>
}
    19e4:	70e2                	ld	ra,56(sp)
    19e6:	7442                	ld	s0,48(sp)
    19e8:	7902                	ld	s2,32(sp)
    19ea:	8526                	mv	a0,s1
    19ec:	74a2                	ld	s1,40(sp)
    19ee:	6121                	addi	sp,sp,64
    19f0:	8082                	ret
	if (buffer_lock_enabled == 1) {
    19f2:	10842703          	lw	a4,264(s0)
	char byte = c;
    19f6:	44a9                	li	s1,10
    19f8:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    19fc:	4785                	li	a5,1
    19fe:	02f70e63          	beq	a4,a5,1a3a <puts+0x88>
		len = out_unlocked(s, l);
    1a02:	01f10513          	addi	a0,sp,31
    1a06:	e2fff0ef          	jal	ra,1834 <out_unlocked.constprop.0>
}
    1a0a:	70e2                	ld	ra,56(sp)
    1a0c:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a0e:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a12:	7902                	ld	s2,32(sp)
    1a14:	8526                	mv	a0,s1
    1a16:	74a2                	ld	s1,40(sp)
    1a18:	6121                	addi	sp,sp,64
    1a1a:	8082                	ret
		mutex_lock(buffer_lock);
    1a1c:	e42a                	sd	a0,8(sp)
    1a1e:	10c42503          	lw	a0,268(s0)
    1a22:	51b000ef          	jal	ra,273c <mutex_lock>
		len = out_unlocked(s, l);
    1a26:	65a2                	ld	a1,8(sp)
    1a28:	8526                	mv	a0,s1
    1a2a:	cffff0ef          	jal	ra,1728 <out_unlocked>
    1a2e:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a30:	10c42503          	lw	a0,268(s0)
    1a34:	515000ef          	jal	ra,2748 <mutex_unlock>
    1a38:	b75d                	j	19de <puts+0x2c>
		mutex_lock(buffer_lock);
    1a3a:	10c42503          	lw	a0,268(s0)
    1a3e:	4ff000ef          	jal	ra,273c <mutex_lock>
		buffer[buffer_len++] = c;
    1a42:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a44:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a48:	0017861b          	addiw	a2,a5,1
    1a4c:	97a2                	add	a5,a5,s0
    1a4e:	c010                	sw	a2,0(s0)
    1a50:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a54:	06c6dc63          	bge	a3,a2,1acc <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a58:	10000793          	li	a5,256
    1a5c:	02f61c63          	bne	a2,a5,1a94 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a60:	00001597          	auipc	a1,0x1
    1a64:	f1858593          	addi	a1,a1,-232 # 2978 <buffer>
    1a68:	4505                	li	a0,1
    1a6a:	25b000ef          	jal	ra,24c4 <write>
			if (r < 0) {
    1a6e:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a70:	00001797          	auipc	a5,0x1
    1a74:	f007a023          	sw	zero,-256(a5) # 2970 <buffer_len>
			if (r < 0) {
    1a78:	04054c63          	bltz	a0,1ad0 <puts+0x11e>
			if (r < buffer_len) {
    1a7c:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1a7e:	10c42503          	lw	a0,268(s0)
    1a82:	4c7000ef          	jal	ra,2748 <mutex_unlock>
}
    1a86:	70e2                	ld	ra,56(sp)
    1a88:	7442                	ld	s0,48(sp)
    1a8a:	7902                	ld	s2,32(sp)
    1a8c:	8526                	mv	a0,s1
    1a8e:	74a2                	ld	s1,40(sp)
    1a90:	6121                	addi	sp,sp,64
    1a92:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a94:	23b000ef          	jal	ra,24ce <getpid>
    1a98:	84aa                	mv	s1,a0
    1a9a:	00001517          	auipc	a0,0x1
    1a9e:	de650513          	addi	a0,a0,-538 # 2880 <enable_deadlock_detect+0xe4>
    1aa2:	103000ef          	jal	ra,23a4 <basename>
    1aa6:	872a                	mv	a4,a0
    1aa8:	00001617          	auipc	a2,0x1
    1aac:	d5060613          	addi	a2,a2,-688 # 27f8 <enable_deadlock_detect+0x5c>
    1ab0:	05400793          	li	a5,84
    1ab4:	86a6                	mv	a3,s1
    1ab6:	45fd                	li	a1,31
    1ab8:	00001517          	auipc	a0,0x1
    1abc:	e0850513          	addi	a0,a0,-504 # 28c0 <enable_deadlock_detect+0x124>
    1ac0:	fdcff0ef          	jal	ra,129c <printf>
    1ac4:	557d                	li	a0,-1
    1ac6:	239000ef          	jal	ra,24fe <exit>
	if (buffer_len == 0)
    1aca:	4010                	lw	a2,0(s0)
    1acc:	da45                	beqz	a2,1a7c <puts+0xca>
    1ace:	bf49                	j	1a60 <puts+0xae>
    1ad0:	54fd                	li	s1,-1
    1ad2:	b775                	j	1a7e <puts+0xcc>

0000000000001ad4 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1ad4:	715d                	addi	sp,sp,-80
    1ad6:	e486                	sd	ra,72(sp)
    1ad8:	e0a2                	sd	s0,64(sp)
    1ada:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1adc:	14054363          	bltz	a0,1c22 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1ae0:	02b577bb          	remuw	a5,a0,a1
    1ae4:	00001617          	auipc	a2,0x1
    1ae8:	f9c60613          	addi	a2,a2,-100 # 2a80 <digits>
	buf[16] = 0;
    1aec:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1af0:	0005871b          	sext.w	a4,a1
    1af4:	1782                	slli	a5,a5,0x20
    1af6:	9381                	srli	a5,a5,0x20
    1af8:	97b2                	add	a5,a5,a2
    1afa:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1afe:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b02:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b06:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b08:	0eb56763          	bltu	a0,a1,1bf6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b0c:	02e877bb          	remuw	a5,a6,a4
    1b10:	1782                	slli	a5,a5,0x20
    1b12:	9381                	srli	a5,a5,0x20
    1b14:	97b2                	add	a5,a5,a2
    1b16:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b1a:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b1e:	02f10323          	sb	a5,38(sp)
    1b22:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b24:	0ce86963          	bltu	a6,a4,1bf6 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b28:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b2c:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b30:	1582                	slli	a1,a1,0x20
    1b32:	9181                	srli	a1,a1,0x20
    1b34:	95b2                	add	a1,a1,a2
    1b36:	0005c583          	lbu	a1,0(a1)
    1b3a:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b3e:	0007859b          	sext.w	a1,a5
    1b42:	16e6e563          	bltu	a3,a4,1cac <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b46:	02e7f6bb          	remuw	a3,a5,a4
    1b4a:	1682                	slli	a3,a3,0x20
    1b4c:	9281                	srli	a3,a3,0x20
    1b4e:	96b2                	add	a3,a3,a2
    1b50:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b54:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b58:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b5c:	16e5e163          	bltu	a1,a4,1cbe <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b60:	02e876bb          	remuw	a3,a6,a4
    1b64:	1682                	slli	a3,a3,0x20
    1b66:	9281                	srli	a3,a3,0x20
    1b68:	96b2                	add	a3,a3,a2
    1b6a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b6e:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b72:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b76:	14e86d63          	bltu	a6,a4,1cd0 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b7a:	02e5f6bb          	remuw	a3,a1,a4
    1b7e:	1682                	slli	a3,a3,0x20
    1b80:	9281                	srli	a3,a3,0x20
    1b82:	96b2                	add	a3,a3,a2
    1b84:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b88:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b8c:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1b90:	10e5e563          	bltu	a1,a4,1c9a <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1b94:	02e876bb          	remuw	a3,a6,a4
    1b98:	1682                	slli	a3,a3,0x20
    1b9a:	9281                	srli	a3,a3,0x20
    1b9c:	96b2                	add	a3,a3,a2
    1b9e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ba2:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ba6:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1baa:	14e86263          	bltu	a6,a4,1cee <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1bae:	02e5f6bb          	remuw	a3,a1,a4
    1bb2:	1682                	slli	a3,a3,0x20
    1bb4:	9281                	srli	a3,a3,0x20
    1bb6:	96b2                	add	a3,a3,a2
    1bb8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bbc:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bc0:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1bc4:	14e5e463          	bltu	a1,a4,1d0c <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1bc8:	02e876bb          	remuw	a3,a6,a4
    1bcc:	1682                	slli	a3,a3,0x20
    1bce:	9281                	srli	a3,a3,0x20
    1bd0:	96b2                	add	a3,a3,a2
    1bd2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bd6:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1bda:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1bde:	14e86063          	bltu	a6,a4,1d1e <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1be2:	1782                	slli	a5,a5,0x20
    1be4:	9381                	srli	a5,a5,0x20
    1be6:	97b2                	add	a5,a5,a2
    1be8:	0007c703          	lbu	a4,0(a5)
    1bec:	4799                	li	a5,6
    1bee:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1bf2:	10054763          	bltz	a0,1d00 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1bf6:	00001497          	auipc	s1,0x1
    1bfa:	d7a48493          	addi	s1,s1,-646 # 2970 <buffer_len>
    1bfe:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c02:	0828                	addi	a0,sp,24
    1c04:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c06:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c08:	00f50433          	add	s0,a0,a5
    1c0c:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c0e:	06e68463          	beq	a3,a4,1c76 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c12:	8522                	mv	a0,s0
    1c14:	b15ff0ef          	jal	ra,1728 <out_unlocked>
}
    1c18:	60a6                	ld	ra,72(sp)
    1c1a:	6406                	ld	s0,64(sp)
    1c1c:	74e2                	ld	s1,56(sp)
    1c1e:	6161                	addi	sp,sp,80
    1c20:	8082                	ret
		x = -xx;
    1c22:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c26:	02b877bb          	remuw	a5,a6,a1
    1c2a:	00001617          	auipc	a2,0x1
    1c2e:	e5660613          	addi	a2,a2,-426 # 2a80 <digits>
	buf[16] = 0;
    1c32:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c36:	0005871b          	sext.w	a4,a1
    1c3a:	1782                	slli	a5,a5,0x20
    1c3c:	9381                	srli	a5,a5,0x20
    1c3e:	97b2                	add	a5,a5,a2
    1c40:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c44:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c48:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c4c:	08b86b63          	bltu	a6,a1,1ce2 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c50:	02e8f7bb          	remuw	a5,a7,a4
    1c54:	1782                	slli	a5,a5,0x20
    1c56:	9381                	srli	a5,a5,0x20
    1c58:	97b2                	add	a5,a5,a2
    1c5a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c5e:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c62:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c66:	ece8f1e3          	bgeu	a7,a4,1b28 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c6a:	02d00793          	li	a5,45
    1c6e:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c72:	47b5                	li	a5,13
    1c74:	b749                	j	1bf6 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c76:	10c4a503          	lw	a0,268(s1)
    1c7a:	e42e                	sd	a1,8(sp)
    1c7c:	2c1000ef          	jal	ra,273c <mutex_lock>
		len = out_unlocked(s, l);
    1c80:	65a2                	ld	a1,8(sp)
    1c82:	8522                	mv	a0,s0
    1c84:	aa5ff0ef          	jal	ra,1728 <out_unlocked>
		mutex_unlock(buffer_lock);
    1c88:	10c4a503          	lw	a0,268(s1)
    1c8c:	2bd000ef          	jal	ra,2748 <mutex_unlock>
}
    1c90:	60a6                	ld	ra,72(sp)
    1c92:	6406                	ld	s0,64(sp)
    1c94:	74e2                	ld	s1,56(sp)
    1c96:	6161                	addi	sp,sp,80
    1c98:	8082                	ret
		buf[i--] = digits[x % base];
    1c9a:	47a9                	li	a5,10
	if (sign)
    1c9c:	f4055de3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ca0:	02d00793          	li	a5,45
    1ca4:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1ca8:	47a5                	li	a5,9
    1caa:	b7b1                	j	1bf6 <printint.constprop.0+0x122>
    1cac:	47b5                	li	a5,13
	if (sign)
    1cae:	f40554e3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cb2:	02d00793          	li	a5,45
    1cb6:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1cba:	47b1                	li	a5,12
    1cbc:	bf2d                	j	1bf6 <printint.constprop.0+0x122>
    1cbe:	47b1                	li	a5,12
	if (sign)
    1cc0:	f2055be3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc4:	02d00793          	li	a5,45
    1cc8:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ccc:	47ad                	li	a5,11
    1cce:	b725                	j	1bf6 <printint.constprop.0+0x122>
    1cd0:	47ad                	li	a5,11
	if (sign)
    1cd2:	f20552e3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd6:	02d00793          	li	a5,45
    1cda:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1cde:	47a9                	li	a5,10
    1ce0:	bf19                	j	1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce2:	02d00793          	li	a5,45
    1ce6:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1cea:	47b9                	li	a5,14
    1cec:	b729                	j	1bf6 <printint.constprop.0+0x122>
    1cee:	47a5                	li	a5,9
	if (sign)
    1cf0:	f00553e3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf4:	02d00793          	li	a5,45
    1cf8:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1cfc:	47a1                	li	a5,8
    1cfe:	bde5                	j	1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d00:	02d00793          	li	a5,45
    1d04:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d08:	4795                	li	a5,5
    1d0a:	b5f5                	j	1bf6 <printint.constprop.0+0x122>
    1d0c:	47a1                	li	a5,8
	if (sign)
    1d0e:	ee0554e3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d12:	02d00793          	li	a5,45
    1d16:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d1a:	479d                	li	a5,7
    1d1c:	bde9                	j	1bf6 <printint.constprop.0+0x122>
    1d1e:	479d                	li	a5,7
	if (sign)
    1d20:	ec055be3          	bgez	a0,1bf6 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d24:	02d00793          	li	a5,45
    1d28:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d2c:	4799                	li	a5,6
    1d2e:	b5e1                	j	1bf6 <printint.constprop.0+0x122>

0000000000001d30 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d30:	02000793          	li	a5,32
    1d34:	00f50663          	beq	a0,a5,1d40 <isspace+0x10>
    1d38:	355d                	addiw	a0,a0,-9
    1d3a:	00553513          	sltiu	a0,a0,5
    1d3e:	8082                	ret
    1d40:	4505                	li	a0,1
}
    1d42:	8082                	ret

0000000000001d44 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d44:	fd05051b          	addiw	a0,a0,-48
}
    1d48:	00a53513          	sltiu	a0,a0,10
    1d4c:	8082                	ret

0000000000001d4e <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d4e:	02000613          	li	a2,32
    1d52:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d54:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d58:	ff77869b          	addiw	a3,a5,-9
    1d5c:	04c78c63          	beq	a5,a2,1db4 <atoi+0x66>
    1d60:	0007871b          	sext.w	a4,a5
    1d64:	04d5f863          	bgeu	a1,a3,1db4 <atoi+0x66>
		s++;
	switch (*s) {
    1d68:	02b00693          	li	a3,43
    1d6c:	04d78963          	beq	a5,a3,1dbe <atoi+0x70>
    1d70:	02d00693          	li	a3,45
    1d74:	06d78263          	beq	a5,a3,1dd8 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d78:	fd07061b          	addiw	a2,a4,-48
    1d7c:	47a5                	li	a5,9
    1d7e:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1d80:	4e01                	li	t3,0
	while (isdigit(*s))
    1d82:	04c7e963          	bltu	a5,a2,1dd4 <atoi+0x86>
	int n = 0, neg = 0;
    1d86:	4501                	li	a0,0
	while (isdigit(*s))
    1d88:	4825                	li	a6,9
    1d8a:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1d8e:	0025179b          	slliw	a5,a0,0x2
    1d92:	9fa9                	addw	a5,a5,a0
    1d94:	fd07031b          	addiw	t1,a4,-48
    1d98:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1d9c:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1da0:	0685                	addi	a3,a3,1
    1da2:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1da6:	0006071b          	sext.w	a4,a2
    1daa:	feb870e3          	bgeu	a6,a1,1d8a <atoi+0x3c>
	return neg ? n : -n;
    1dae:	000e0563          	beqz	t3,1db8 <atoi+0x6a>
}
    1db2:	8082                	ret
		s++;
    1db4:	0505                	addi	a0,a0,1
    1db6:	bf79                	j	1d54 <atoi+0x6>
	return neg ? n : -n;
    1db8:	4113053b          	subw	a0,t1,a7
    1dbc:	8082                	ret
	while (isdigit(*s))
    1dbe:	00154703          	lbu	a4,1(a0)
    1dc2:	47a5                	li	a5,9
		s++;
    1dc4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dc8:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1dcc:	4e01                	li	t3,0
	while (isdigit(*s))
    1dce:	2701                	sext.w	a4,a4
    1dd0:	fac7fbe3          	bgeu	a5,a2,1d86 <atoi+0x38>
    1dd4:	4501                	li	a0,0
}
    1dd6:	8082                	ret
	while (isdigit(*s))
    1dd8:	00154703          	lbu	a4,1(a0)
    1ddc:	47a5                	li	a5,9
		s++;
    1dde:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1de2:	fd07061b          	addiw	a2,a4,-48
    1de6:	2701                	sext.w	a4,a4
    1de8:	fec7e6e3          	bltu	a5,a2,1dd4 <atoi+0x86>
		neg = 1;
    1dec:	4e05                	li	t3,1
    1dee:	bf61                	j	1d86 <atoi+0x38>

0000000000001df0 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1df0:	16060d63          	beqz	a2,1f6a <memset+0x17a>
    1df4:	40a007b3          	neg	a5,a0
    1df8:	8b9d                	andi	a5,a5,7
    1dfa:	00778693          	addi	a3,a5,7
    1dfe:	482d                	li	a6,11
    1e00:	0ff5f713          	zext.b	a4,a1
    1e04:	fff60593          	addi	a1,a2,-1
    1e08:	1706e263          	bltu	a3,a6,1f6c <memset+0x17c>
    1e0c:	16d5ea63          	bltu	a1,a3,1f80 <memset+0x190>
    1e10:	16078563          	beqz	a5,1f7a <memset+0x18a>
    1e14:	00e50023          	sb	a4,0(a0)
    1e18:	4685                	li	a3,1
    1e1a:	00150593          	addi	a1,a0,1
    1e1e:	14d78c63          	beq	a5,a3,1f76 <memset+0x186>
    1e22:	00e500a3          	sb	a4,1(a0)
    1e26:	4689                	li	a3,2
    1e28:	00250593          	addi	a1,a0,2
    1e2c:	14d78d63          	beq	a5,a3,1f86 <memset+0x196>
    1e30:	00e50123          	sb	a4,2(a0)
    1e34:	468d                	li	a3,3
    1e36:	00350593          	addi	a1,a0,3
    1e3a:	12d78b63          	beq	a5,a3,1f70 <memset+0x180>
    1e3e:	00e501a3          	sb	a4,3(a0)
    1e42:	4691                	li	a3,4
    1e44:	00450593          	addi	a1,a0,4
    1e48:	14d78163          	beq	a5,a3,1f8a <memset+0x19a>
    1e4c:	00e50223          	sb	a4,4(a0)
    1e50:	4695                	li	a3,5
    1e52:	00550593          	addi	a1,a0,5
    1e56:	12d78c63          	beq	a5,a3,1f8e <memset+0x19e>
    1e5a:	00e502a3          	sb	a4,5(a0)
    1e5e:	469d                	li	a3,7
    1e60:	00650593          	addi	a1,a0,6
    1e64:	12d79763          	bne	a5,a3,1f92 <memset+0x1a2>
    1e68:	00750593          	addi	a1,a0,7
    1e6c:	00e50323          	sb	a4,6(a0)
    1e70:	481d                	li	a6,7
    1e72:	00871693          	slli	a3,a4,0x8
    1e76:	01071893          	slli	a7,a4,0x10
    1e7a:	8ed9                	or	a3,a3,a4
    1e7c:	01871313          	slli	t1,a4,0x18
    1e80:	0116e6b3          	or	a3,a3,a7
    1e84:	0066e6b3          	or	a3,a3,t1
    1e88:	02071893          	slli	a7,a4,0x20
    1e8c:	02871e13          	slli	t3,a4,0x28
    1e90:	0116e6b3          	or	a3,a3,a7
    1e94:	40f60333          	sub	t1,a2,a5
    1e98:	03071893          	slli	a7,a4,0x30
    1e9c:	01c6e6b3          	or	a3,a3,t3
    1ea0:	0116e6b3          	or	a3,a3,a7
    1ea4:	03871e13          	slli	t3,a4,0x38
    1ea8:	97aa                	add	a5,a5,a0
    1eaa:	ff837893          	andi	a7,t1,-8
    1eae:	01c6e6b3          	or	a3,a3,t3
    1eb2:	98be                	add	a7,a7,a5
    1eb4:	e394                	sd	a3,0(a5)
    1eb6:	07a1                	addi	a5,a5,8
    1eb8:	ff179ee3          	bne	a5,a7,1eb4 <memset+0xc4>
    1ebc:	ff837893          	andi	a7,t1,-8
    1ec0:	011587b3          	add	a5,a1,a7
    1ec4:	010886bb          	addw	a3,a7,a6
    1ec8:	0b130663          	beq	t1,a7,1f74 <memset+0x184>
    1ecc:	00e78023          	sb	a4,0(a5)
    1ed0:	0016859b          	addiw	a1,a3,1
    1ed4:	08c5fb63          	bgeu	a1,a2,1f6a <memset+0x17a>
    1ed8:	00e780a3          	sb	a4,1(a5)
    1edc:	0026859b          	addiw	a1,a3,2
    1ee0:	08c5f563          	bgeu	a1,a2,1f6a <memset+0x17a>
    1ee4:	00e78123          	sb	a4,2(a5)
    1ee8:	0036859b          	addiw	a1,a3,3
    1eec:	06c5ff63          	bgeu	a1,a2,1f6a <memset+0x17a>
    1ef0:	00e781a3          	sb	a4,3(a5)
    1ef4:	0046859b          	addiw	a1,a3,4
    1ef8:	06c5f963          	bgeu	a1,a2,1f6a <memset+0x17a>
    1efc:	00e78223          	sb	a4,4(a5)
    1f00:	0056859b          	addiw	a1,a3,5
    1f04:	06c5f363          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f08:	00e782a3          	sb	a4,5(a5)
    1f0c:	0066859b          	addiw	a1,a3,6
    1f10:	04c5fd63          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f14:	00e78323          	sb	a4,6(a5)
    1f18:	0076859b          	addiw	a1,a3,7
    1f1c:	04c5f763          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f20:	00e783a3          	sb	a4,7(a5)
    1f24:	0086859b          	addiw	a1,a3,8
    1f28:	04c5f163          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f2c:	00e78423          	sb	a4,8(a5)
    1f30:	0096859b          	addiw	a1,a3,9
    1f34:	02c5fb63          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f38:	00e784a3          	sb	a4,9(a5)
    1f3c:	00a6859b          	addiw	a1,a3,10
    1f40:	02c5f563          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f44:	00e78523          	sb	a4,10(a5)
    1f48:	00b6859b          	addiw	a1,a3,11
    1f4c:	00c5ff63          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f50:	00e785a3          	sb	a4,11(a5)
    1f54:	00c6859b          	addiw	a1,a3,12
    1f58:	00c5f963          	bgeu	a1,a2,1f6a <memset+0x17a>
    1f5c:	00e78623          	sb	a4,12(a5)
    1f60:	26b5                	addiw	a3,a3,13
    1f62:	00c6f463          	bgeu	a3,a2,1f6a <memset+0x17a>
    1f66:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f6a:	8082                	ret
    1f6c:	46ad                	li	a3,11
    1f6e:	bd79                	j	1e0c <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f70:	480d                	li	a6,3
    1f72:	b701                	j	1e72 <memset+0x82>
    1f74:	8082                	ret
    1f76:	4805                	li	a6,1
    1f78:	bded                	j	1e72 <memset+0x82>
    1f7a:	85aa                	mv	a1,a0
    1f7c:	4801                	li	a6,0
    1f7e:	bdd5                	j	1e72 <memset+0x82>
    1f80:	87aa                	mv	a5,a0
    1f82:	4681                	li	a3,0
    1f84:	b7a1                	j	1ecc <memset+0xdc>
    1f86:	4809                	li	a6,2
    1f88:	b5ed                	j	1e72 <memset+0x82>
    1f8a:	4811                	li	a6,4
    1f8c:	b5dd                	j	1e72 <memset+0x82>
    1f8e:	4815                	li	a6,5
    1f90:	b5cd                	j	1e72 <memset+0x82>
    1f92:	4819                	li	a6,6
    1f94:	bdf9                	j	1e72 <memset+0x82>

0000000000001f96 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1f96:	00054783          	lbu	a5,0(a0)
    1f9a:	0005c703          	lbu	a4,0(a1)
    1f9e:	00e79863          	bne	a5,a4,1fae <strcmp+0x18>
    1fa2:	0505                	addi	a0,a0,1
    1fa4:	0585                	addi	a1,a1,1
    1fa6:	fbe5                	bnez	a5,1f96 <strcmp>
    1fa8:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1faa:	9d19                	subw	a0,a0,a4
    1fac:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1fae:	0007851b          	sext.w	a0,a5
    1fb2:	bfe5                	j	1faa <strcmp+0x14>

0000000000001fb4 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1fb4:	ca15                	beqz	a2,1fe8 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fb6:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1fba:	167d                	addi	a2,a2,-1
    1fbc:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fc0:	eb99                	bnez	a5,1fd6 <strncmp+0x22>
    1fc2:	a815                	j	1ff6 <strncmp+0x42>
    1fc4:	00a68e63          	beq	a3,a0,1fe0 <strncmp+0x2c>
    1fc8:	0505                	addi	a0,a0,1
    1fca:	00f71b63          	bne	a4,a5,1fe0 <strncmp+0x2c>
    1fce:	00054783          	lbu	a5,0(a0)
    1fd2:	cf89                	beqz	a5,1fec <strncmp+0x38>
    1fd4:	85b2                	mv	a1,a2
    1fd6:	0005c703          	lbu	a4,0(a1)
    1fda:	00158613          	addi	a2,a1,1
    1fde:	f37d                	bnez	a4,1fc4 <strncmp+0x10>
		;
	return *l - *r;
    1fe0:	0007851b          	sext.w	a0,a5
    1fe4:	9d19                	subw	a0,a0,a4
    1fe6:	8082                	ret
		return 0;
    1fe8:	4501                	li	a0,0
}
    1fea:	8082                	ret
	return *l - *r;
    1fec:	0015c703          	lbu	a4,1(a1)
    1ff0:	4501                	li	a0,0
    1ff2:	9d19                	subw	a0,a0,a4
    1ff4:	8082                	ret
    1ff6:	0005c703          	lbu	a4,0(a1)
    1ffa:	4501                	li	a0,0
    1ffc:	b7e5                	j	1fe4 <strncmp+0x30>

0000000000001ffe <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1ffe:	00757793          	andi	a5,a0,7
    2002:	cf89                	beqz	a5,201c <strlen+0x1e>
    2004:	87aa                	mv	a5,a0
    2006:	a029                	j	2010 <strlen+0x12>
    2008:	0785                	addi	a5,a5,1
    200a:	0077f713          	andi	a4,a5,7
    200e:	cb01                	beqz	a4,201e <strlen+0x20>
		if (!*s)
    2010:	0007c703          	lbu	a4,0(a5)
    2014:	fb75                	bnez	a4,2008 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2016:	40a78533          	sub	a0,a5,a0
}
    201a:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    201c:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    201e:	6394                	ld	a3,0(a5)
    2020:	00001597          	auipc	a1,0x1
    2024:	9385b583          	ld	a1,-1736(a1) # 2958 <enable_deadlock_detect+0x1bc>
    2028:	00001617          	auipc	a2,0x1
    202c:	93863603          	ld	a2,-1736(a2) # 2960 <enable_deadlock_detect+0x1c4>
    2030:	a019                	j	2036 <strlen+0x38>
    2032:	6794                	ld	a3,8(a5)
    2034:	07a1                	addi	a5,a5,8
    2036:	00b68733          	add	a4,a3,a1
    203a:	fff6c693          	not	a3,a3
    203e:	8f75                	and	a4,a4,a3
    2040:	8f71                	and	a4,a4,a2
    2042:	db65                	beqz	a4,2032 <strlen+0x34>
	for (; *s; s++)
    2044:	0007c703          	lbu	a4,0(a5)
    2048:	d779                	beqz	a4,2016 <strlen+0x18>
    204a:	0017c703          	lbu	a4,1(a5)
    204e:	0785                	addi	a5,a5,1
    2050:	d379                	beqz	a4,2016 <strlen+0x18>
    2052:	0017c703          	lbu	a4,1(a5)
    2056:	0785                	addi	a5,a5,1
    2058:	fb6d                	bnez	a4,204a <strlen+0x4c>
    205a:	bf75                	j	2016 <strlen+0x18>

000000000000205c <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    205c:	00757713          	andi	a4,a0,7
{
    2060:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2062:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2066:	cb19                	beqz	a4,207c <memchr+0x20>
    2068:	ce25                	beqz	a2,20e0 <memchr+0x84>
    206a:	0007c703          	lbu	a4,0(a5)
    206e:	04b70e63          	beq	a4,a1,20ca <memchr+0x6e>
    2072:	0785                	addi	a5,a5,1
    2074:	0077f713          	andi	a4,a5,7
    2078:	167d                	addi	a2,a2,-1
    207a:	f77d                	bnez	a4,2068 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    207c:	4501                	li	a0,0
	if (n && *s != c) {
    207e:	c235                	beqz	a2,20e2 <memchr+0x86>
    2080:	0007c703          	lbu	a4,0(a5)
    2084:	04b70363          	beq	a4,a1,20ca <memchr+0x6e>
		size_t k = ONES * c;
    2088:	00001517          	auipc	a0,0x1
    208c:	8e053503          	ld	a0,-1824(a0) # 2968 <enable_deadlock_detect+0x1cc>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2090:	471d                	li	a4,7
		size_t k = ONES * c;
    2092:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2096:	02c77a63          	bgeu	a4,a2,20ca <memchr+0x6e>
    209a:	00001897          	auipc	a7,0x1
    209e:	8be8b883          	ld	a7,-1858(a7) # 2958 <enable_deadlock_detect+0x1bc>
    20a2:	00001817          	auipc	a6,0x1
    20a6:	8be83803          	ld	a6,-1858(a6) # 2960 <enable_deadlock_detect+0x1c4>
    20aa:	431d                	li	t1,7
    20ac:	a029                	j	20b6 <memchr+0x5a>
		     w++, n -= SS)
    20ae:	1661                	addi	a2,a2,-8
    20b0:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20b2:	02c37963          	bgeu	t1,a2,20e4 <memchr+0x88>
    20b6:	6398                	ld	a4,0(a5)
    20b8:	8f29                	xor	a4,a4,a0
    20ba:	011706b3          	add	a3,a4,a7
    20be:	fff74713          	not	a4,a4
    20c2:	8f75                	and	a4,a4,a3
    20c4:	01077733          	and	a4,a4,a6
    20c8:	d37d                	beqz	a4,20ae <memchr+0x52>
{
    20ca:	853e                	mv	a0,a5
    20cc:	97b2                	add	a5,a5,a2
    20ce:	a021                	j	20d6 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20d0:	0505                	addi	a0,a0,1
    20d2:	00f50763          	beq	a0,a5,20e0 <memchr+0x84>
    20d6:	00054703          	lbu	a4,0(a0)
    20da:	feb71be3          	bne	a4,a1,20d0 <memchr+0x74>
    20de:	8082                	ret
	return n ? (void *)s : 0;
    20e0:	4501                	li	a0,0
}
    20e2:	8082                	ret
	return n ? (void *)s : 0;
    20e4:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    20e6:	f275                	bnez	a2,20ca <memchr+0x6e>
}
    20e8:	8082                	ret

00000000000020ea <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    20ea:	1101                	addi	sp,sp,-32
    20ec:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    20ee:	862e                	mv	a2,a1
{
    20f0:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    20f2:	4581                	li	a1,0
{
    20f4:	e426                	sd	s1,8(sp)
    20f6:	ec06                	sd	ra,24(sp)
    20f8:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    20fa:	f63ff0ef          	jal	ra,205c <memchr>
	return p ? p - s : n;
    20fe:	c519                	beqz	a0,210c <strnlen+0x22>
}
    2100:	60e2                	ld	ra,24(sp)
    2102:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2104:	8d05                	sub	a0,a0,s1
}
    2106:	64a2                	ld	s1,8(sp)
    2108:	6105                	addi	sp,sp,32
    210a:	8082                	ret
    210c:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    210e:	8522                	mv	a0,s0
}
    2110:	6442                	ld	s0,16(sp)
    2112:	64a2                	ld	s1,8(sp)
    2114:	6105                	addi	sp,sp,32
    2116:	8082                	ret

0000000000002118 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2118:	00a5c7b3          	xor	a5,a1,a0
    211c:	8b9d                	andi	a5,a5,7
    211e:	eb95                	bnez	a5,2152 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2120:	0075f793          	andi	a5,a1,7
    2124:	e7b1                	bnez	a5,2170 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2126:	6198                	ld	a4,0(a1)
    2128:	00001617          	auipc	a2,0x1
    212c:	83063603          	ld	a2,-2000(a2) # 2958 <enable_deadlock_detect+0x1bc>
    2130:	00001817          	auipc	a6,0x1
    2134:	83083803          	ld	a6,-2000(a6) # 2960 <enable_deadlock_detect+0x1c4>
    2138:	a029                	j	2142 <stpcpy+0x2a>
    213a:	05a1                	addi	a1,a1,8
    213c:	e118                	sd	a4,0(a0)
    213e:	6198                	ld	a4,0(a1)
    2140:	0521                	addi	a0,a0,8
    2142:	00c707b3          	add	a5,a4,a2
    2146:	fff74693          	not	a3,a4
    214a:	8ff5                	and	a5,a5,a3
    214c:	0107f7b3          	and	a5,a5,a6
    2150:	d7ed                	beqz	a5,213a <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2152:	0005c783          	lbu	a5,0(a1)
    2156:	00f50023          	sb	a5,0(a0)
    215a:	c785                	beqz	a5,2182 <stpcpy+0x6a>
    215c:	0015c783          	lbu	a5,1(a1)
    2160:	0505                	addi	a0,a0,1
    2162:	0585                	addi	a1,a1,1
    2164:	00f50023          	sb	a5,0(a0)
    2168:	fbf5                	bnez	a5,215c <stpcpy+0x44>
		;
	return d;
}
    216a:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    216c:	0505                	addi	a0,a0,1
    216e:	df45                	beqz	a4,2126 <stpcpy+0xe>
			if (!(*d = *s))
    2170:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2174:	0585                	addi	a1,a1,1
    2176:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    217a:	00f50023          	sb	a5,0(a0)
    217e:	f7fd                	bnez	a5,216c <stpcpy+0x54>
}
    2180:	8082                	ret
    2182:	8082                	ret

0000000000002184 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    2184:	00a5c7b3          	xor	a5,a1,a0
    2188:	8b9d                	andi	a5,a5,7
    218a:	1a079863          	bnez	a5,233a <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    218e:	0075f793          	andi	a5,a1,7
    2192:	16078463          	beqz	a5,22fa <stpncpy+0x176>
    2196:	ea01                	bnez	a2,21a6 <stpncpy+0x22>
    2198:	a421                	j	23a0 <stpncpy+0x21c>
    219a:	167d                	addi	a2,a2,-1
    219c:	0505                	addi	a0,a0,1
    219e:	14070e63          	beqz	a4,22fa <stpncpy+0x176>
    21a2:	1a060863          	beqz	a2,2352 <stpncpy+0x1ce>
    21a6:	0005c783          	lbu	a5,0(a1)
    21aa:	0585                	addi	a1,a1,1
    21ac:	0075f713          	andi	a4,a1,7
    21b0:	00f50023          	sb	a5,0(a0)
    21b4:	f3fd                	bnez	a5,219a <stpncpy+0x16>
    21b6:	4805                	li	a6,1
    21b8:	1a061863          	bnez	a2,2368 <stpncpy+0x1e4>
    21bc:	40a007b3          	neg	a5,a0
    21c0:	8b9d                	andi	a5,a5,7
    21c2:	4681                	li	a3,0
    21c4:	18061a63          	bnez	a2,2358 <stpncpy+0x1d4>
    21c8:	00778713          	addi	a4,a5,7
    21cc:	45ad                	li	a1,11
    21ce:	18b76363          	bltu	a4,a1,2354 <stpncpy+0x1d0>
    21d2:	1ae6eb63          	bltu	a3,a4,2388 <stpncpy+0x204>
    21d6:	1a078363          	beqz	a5,237c <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21da:	00050023          	sb	zero,0(a0)
    21de:	4685                	li	a3,1
    21e0:	00150713          	addi	a4,a0,1
    21e4:	18d78f63          	beq	a5,a3,2382 <stpncpy+0x1fe>
    21e8:	000500a3          	sb	zero,1(a0)
    21ec:	4689                	li	a3,2
    21ee:	00250713          	addi	a4,a0,2
    21f2:	18d78e63          	beq	a5,a3,238e <stpncpy+0x20a>
    21f6:	00050123          	sb	zero,2(a0)
    21fa:	468d                	li	a3,3
    21fc:	00350713          	addi	a4,a0,3
    2200:	16d78c63          	beq	a5,a3,2378 <stpncpy+0x1f4>
    2204:	000501a3          	sb	zero,3(a0)
    2208:	4691                	li	a3,4
    220a:	00450713          	addi	a4,a0,4
    220e:	18d78263          	beq	a5,a3,2392 <stpncpy+0x20e>
    2212:	00050223          	sb	zero,4(a0)
    2216:	4695                	li	a3,5
    2218:	00550713          	addi	a4,a0,5
    221c:	16d78d63          	beq	a5,a3,2396 <stpncpy+0x212>
    2220:	000502a3          	sb	zero,5(a0)
    2224:	469d                	li	a3,7
    2226:	00650713          	addi	a4,a0,6
    222a:	16d79863          	bne	a5,a3,239a <stpncpy+0x216>
    222e:	00750713          	addi	a4,a0,7
    2232:	00050323          	sb	zero,6(a0)
    2236:	40f80833          	sub	a6,a6,a5
    223a:	ff887593          	andi	a1,a6,-8
    223e:	97aa                	add	a5,a5,a0
    2240:	95be                	add	a1,a1,a5
    2242:	0007b023          	sd	zero,0(a5)
    2246:	07a1                	addi	a5,a5,8
    2248:	feb79de3          	bne	a5,a1,2242 <stpncpy+0xbe>
    224c:	ff887593          	andi	a1,a6,-8
    2250:	9ead                	addw	a3,a3,a1
    2252:	00b707b3          	add	a5,a4,a1
    2256:	12b80863          	beq	a6,a1,2386 <stpncpy+0x202>
    225a:	00078023          	sb	zero,0(a5)
    225e:	0016871b          	addiw	a4,a3,1
    2262:	0ec77863          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    2266:	000780a3          	sb	zero,1(a5)
    226a:	0026871b          	addiw	a4,a3,2
    226e:	0ec77263          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    2272:	00078123          	sb	zero,2(a5)
    2276:	0036871b          	addiw	a4,a3,3
    227a:	0cc77c63          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    227e:	000781a3          	sb	zero,3(a5)
    2282:	0046871b          	addiw	a4,a3,4
    2286:	0cc77663          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    228a:	00078223          	sb	zero,4(a5)
    228e:	0056871b          	addiw	a4,a3,5
    2292:	0cc77063          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    2296:	000782a3          	sb	zero,5(a5)
    229a:	0066871b          	addiw	a4,a3,6
    229e:	0ac77a63          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22a2:	00078323          	sb	zero,6(a5)
    22a6:	0076871b          	addiw	a4,a3,7
    22aa:	0ac77463          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22ae:	000783a3          	sb	zero,7(a5)
    22b2:	0086871b          	addiw	a4,a3,8
    22b6:	08c77e63          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22ba:	00078423          	sb	zero,8(a5)
    22be:	0096871b          	addiw	a4,a3,9
    22c2:	08c77863          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22c6:	000784a3          	sb	zero,9(a5)
    22ca:	00a6871b          	addiw	a4,a3,10
    22ce:	08c77263          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22d2:	00078523          	sb	zero,10(a5)
    22d6:	00b6871b          	addiw	a4,a3,11
    22da:	06c77c63          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22de:	000785a3          	sb	zero,11(a5)
    22e2:	00c6871b          	addiw	a4,a3,12
    22e6:	06c77663          	bgeu	a4,a2,2352 <stpncpy+0x1ce>
    22ea:	00078623          	sb	zero,12(a5)
    22ee:	26b5                	addiw	a3,a3,13
    22f0:	06c6f163          	bgeu	a3,a2,2352 <stpncpy+0x1ce>
    22f4:	000786a3          	sb	zero,13(a5)
    22f8:	8082                	ret
			;
		if (!n || !*s)
    22fa:	c645                	beqz	a2,23a2 <stpncpy+0x21e>
    22fc:	0005c783          	lbu	a5,0(a1)
    2300:	ea078be3          	beqz	a5,21b6 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2304:	479d                	li	a5,7
    2306:	02c7ff63          	bgeu	a5,a2,2344 <stpncpy+0x1c0>
    230a:	00000897          	auipc	a7,0x0
    230e:	64e8b883          	ld	a7,1614(a7) # 2958 <enable_deadlock_detect+0x1bc>
    2312:	00000817          	auipc	a6,0x0
    2316:	64e83803          	ld	a6,1614(a6) # 2960 <enable_deadlock_detect+0x1c4>
    231a:	431d                	li	t1,7
    231c:	6198                	ld	a4,0(a1)
    231e:	011707b3          	add	a5,a4,a7
    2322:	fff74693          	not	a3,a4
    2326:	8ff5                	and	a5,a5,a3
    2328:	0107f7b3          	and	a5,a5,a6
    232c:	ef81                	bnez	a5,2344 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    232e:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2330:	1661                	addi	a2,a2,-8
    2332:	05a1                	addi	a1,a1,8
    2334:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2336:	fec363e3          	bltu	t1,a2,231c <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    233a:	e609                	bnez	a2,2344 <stpncpy+0x1c0>
    233c:	a08d                	j	239e <stpncpy+0x21a>
    233e:	167d                	addi	a2,a2,-1
    2340:	0505                	addi	a0,a0,1
    2342:	ca01                	beqz	a2,2352 <stpncpy+0x1ce>
    2344:	0005c783          	lbu	a5,0(a1)
    2348:	0585                	addi	a1,a1,1
    234a:	00f50023          	sb	a5,0(a0)
    234e:	fbe5                	bnez	a5,233e <stpncpy+0x1ba>
		;
tail:
    2350:	b59d                	j	21b6 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2352:	8082                	ret
    2354:	472d                	li	a4,11
    2356:	bdb5                	j	21d2 <stpncpy+0x4e>
    2358:	00778713          	addi	a4,a5,7
    235c:	45ad                	li	a1,11
    235e:	fff60693          	addi	a3,a2,-1
    2362:	e6b778e3          	bgeu	a4,a1,21d2 <stpncpy+0x4e>
    2366:	b7fd                	j	2354 <stpncpy+0x1d0>
    2368:	40a007b3          	neg	a5,a0
    236c:	8832                	mv	a6,a2
    236e:	8b9d                	andi	a5,a5,7
    2370:	4681                	li	a3,0
    2372:	e4060be3          	beqz	a2,21c8 <stpncpy+0x44>
    2376:	b7cd                	j	2358 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2378:	468d                	li	a3,3
    237a:	bd75                	j	2236 <stpncpy+0xb2>
    237c:	872a                	mv	a4,a0
    237e:	4681                	li	a3,0
    2380:	bd5d                	j	2236 <stpncpy+0xb2>
    2382:	4685                	li	a3,1
    2384:	bd4d                	j	2236 <stpncpy+0xb2>
    2386:	8082                	ret
    2388:	87aa                	mv	a5,a0
    238a:	4681                	li	a3,0
    238c:	b5f9                	j	225a <stpncpy+0xd6>
    238e:	4689                	li	a3,2
    2390:	b55d                	j	2236 <stpncpy+0xb2>
    2392:	4691                	li	a3,4
    2394:	b54d                	j	2236 <stpncpy+0xb2>
    2396:	4695                	li	a3,5
    2398:	bd79                	j	2236 <stpncpy+0xb2>
    239a:	4699                	li	a3,6
    239c:	bd69                	j	2236 <stpncpy+0xb2>
    239e:	8082                	ret
    23a0:	8082                	ret
    23a2:	8082                	ret

00000000000023a4 <basename>:

char *basename(char *s)
{
    23a4:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    23a6:	c54d                	beqz	a0,2450 <basename+0xac>
    23a8:	00054783          	lbu	a5,0(a0)
		return ".";
    23ac:	00000517          	auipc	a0,0x0
    23b0:	5a450513          	addi	a0,a0,1444 # 2950 <enable_deadlock_detect+0x1b4>
	if (!s || !*s)
    23b4:	e391                	bnez	a5,23b8 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    23b6:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23b8:	0076f713          	andi	a4,a3,7
    23bc:	87b6                	mv	a5,a3
    23be:	cf51                	beqz	a4,245a <basename+0xb6>
    23c0:	0785                	addi	a5,a5,1
    23c2:	0077f713          	andi	a4,a5,7
    23c6:	c729                	beqz	a4,2410 <basename+0x6c>
		if (!*s)
    23c8:	0007c703          	lbu	a4,0(a5)
    23cc:	fb75                	bnez	a4,23c0 <basename+0x1c>
	return s - a;
    23ce:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23d0:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23d2:	cf8d                	beqz	a5,240c <basename+0x68>
    23d4:	00f68733          	add	a4,a3,a5
    23d8:	02f00593          	li	a1,47
    23dc:	a031                	j	23e8 <basename+0x44>
		s[i] = 0;
    23de:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    23e2:	17fd                	addi	a5,a5,-1
    23e4:	177d                	addi	a4,a4,-1
    23e6:	c39d                	beqz	a5,240c <basename+0x68>
    23e8:	00074603          	lbu	a2,0(a4)
    23ec:	feb609e3          	beq	a2,a1,23de <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    23f0:	02f00613          	li	a2,47
    23f4:	a011                	j	23f8 <basename+0x54>
    23f6:	cb99                	beqz	a5,240c <basename+0x68>
    23f8:	853e                	mv	a0,a5
    23fa:	17fd                	addi	a5,a5,-1
    23fc:	00f68733          	add	a4,a3,a5
    2400:	00074703          	lbu	a4,0(a4)
    2404:	fec719e3          	bne	a4,a2,23f6 <basename+0x52>
	return s + i;
    2408:	9536                	add	a0,a0,a3
    240a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    240c:	8536                	mv	a0,a3
    240e:	8082                	ret
    2410:	6390                	ld	a2,0(a5)
    2412:	00000517          	auipc	a0,0x0
    2416:	54653503          	ld	a0,1350(a0) # 2958 <enable_deadlock_detect+0x1bc>
    241a:	00000597          	auipc	a1,0x0
    241e:	5465b583          	ld	a1,1350(a1) # 2960 <enable_deadlock_detect+0x1c4>
    2422:	fff64713          	not	a4,a2
    2426:	962a                	add	a2,a2,a0
    2428:	8f71                	and	a4,a4,a2
    242a:	8f6d                	and	a4,a4,a1
    242c:	eb11                	bnez	a4,2440 <basename+0x9c>
    242e:	6790                	ld	a2,8(a5)
    2430:	07a1                	addi	a5,a5,8
    2432:	00a60733          	add	a4,a2,a0
    2436:	fff64613          	not	a2,a2
    243a:	8f71                	and	a4,a4,a2
    243c:	8f6d                	and	a4,a4,a1
    243e:	db65                	beqz	a4,242e <basename+0x8a>
	for (; *s; s++)
    2440:	0007c703          	lbu	a4,0(a5)
    2444:	d749                	beqz	a4,23ce <basename+0x2a>
    2446:	0017c703          	lbu	a4,1(a5)
    244a:	0785                	addi	a5,a5,1
    244c:	ff6d                	bnez	a4,2446 <basename+0xa2>
    244e:	b741                	j	23ce <basename+0x2a>
		return ".";
    2450:	00000517          	auipc	a0,0x0
    2454:	50050513          	addi	a0,a0,1280 # 2950 <enable_deadlock_detect+0x1b4>
    2458:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    245a:	6290                	ld	a2,0(a3)
    245c:	00000517          	auipc	a0,0x0
    2460:	4fc53503          	ld	a0,1276(a0) # 2958 <enable_deadlock_detect+0x1bc>
    2464:	00000597          	auipc	a1,0x0
    2468:	4fc5b583          	ld	a1,1276(a1) # 2960 <enable_deadlock_detect+0x1c4>
    246c:	fff64713          	not	a4,a2
    2470:	962a                	add	a2,a2,a0
    2472:	8f71                	and	a4,a4,a2
    2474:	8f6d                	and	a4,a4,a1
    2476:	df45                	beqz	a4,242e <basename+0x8a>
    2478:	b7f9                	j	2446 <basename+0xa2>

000000000000247a <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    247a:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    247e:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2480:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    2484:	2501                	sext.w	a0,a0
    2486:	8082                	ret

0000000000002488 <close>:

int close(int fd)
{
	if (fd == 1) {
    2488:	4785                	li	a5,1
    248a:	00f50863          	beq	a0,a5,249a <close+0x12>
	register long a7 __asm__("a7") = n;
    248e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    2492:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    2496:	2501                	sext.w	a0,a0
    2498:	8082                	ret
{
    249a:	1101                	addi	sp,sp,-32
    249c:	ec06                	sd	ra,24(sp)
    249e:	e42a                	sd	a0,8(sp)
		__write_buffer();
    24a0:	cdffe0ef          	jal	ra,117e <__write_buffer>
		__clear_buffer();
    24a4:	d03fe0ef          	jal	ra,11a6 <__clear_buffer>
    24a8:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    24aa:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24ae:	00000073          	ecall
}
    24b2:	60e2                	ld	ra,24(sp)
    24b4:	2501                	sext.w	a0,a0
    24b6:	6105                	addi	sp,sp,32
    24b8:	8082                	ret

00000000000024ba <read>:
	register long a7 __asm__("a7") = n;
    24ba:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24be:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24c2:	8082                	ret

00000000000024c4 <write>:
	register long a7 __asm__("a7") = n;
    24c4:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24c8:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    24cc:	8082                	ret

00000000000024ce <getpid>:
	register long a7 __asm__("a7") = n;
    24ce:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24d2:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24d6:	2501                	sext.w	a0,a0
    24d8:	8082                	ret

00000000000024da <getppid>:
	register long a7 __asm__("a7") = n;
    24da:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    24de:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    24e2:	2501                	sext.w	a0,a0
    24e4:	8082                	ret

00000000000024e6 <sched_yield>:
	register long a7 __asm__("a7") = n;
    24e6:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    24ea:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    24ee:	2501                	sext.w	a0,a0
    24f0:	8082                	ret

00000000000024f2 <fork>:
	register long a7 __asm__("a7") = n;
    24f2:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    24f6:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    24fa:	2501                	sext.w	a0,a0
    24fc:	8082                	ret

00000000000024fe <exit>:

void exit(int code)
{
    24fe:	1141                	addi	sp,sp,-16
    2500:	e406                	sd	ra,8(sp)
    2502:	e022                	sd	s0,0(sp)
    2504:	842a                	mv	s0,a0
	__write_buffer();
    2506:	c79fe0ef          	jal	ra,117e <__write_buffer>
	__clear_buffer();
    250a:	c9dfe0ef          	jal	ra,11a6 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    250e:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2512:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2514:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2518:	60a2                	ld	ra,8(sp)
    251a:	6402                	ld	s0,0(sp)
    251c:	0141                	addi	sp,sp,16
    251e:	8082                	ret

0000000000002520 <waitpid>:
	register long a7 __asm__("a7") = n;
    2520:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2524:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2528:	2501                	sext.w	a0,a0
    252a:	8082                	ret

000000000000252c <exec>:
	register long a7 __asm__("a7") = n;
    252c:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2530:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2534:	2501                	sext.w	a0,a0
    2536:	8082                	ret

0000000000002538 <get_mtime>:

int64 get_mtime()
{
    2538:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    253a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    253e:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2540:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2542:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2546:	2501                	sext.w	a0,a0
    2548:	ed01                	bnez	a0,2560 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    254a:	6722                	ld	a4,8(sp)
    254c:	3e800793          	li	a5,1000
    2550:	6682                	ld	a3,0(sp)
    2552:	02f75733          	divu	a4,a4,a5
    2556:	02d78533          	mul	a0,a5,a3
    255a:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    255c:	0141                	addi	sp,sp,16
    255e:	8082                	ret
	return -1;
    2560:	557d                	li	a0,-1
    2562:	bfed                	j	255c <get_mtime+0x24>

0000000000002564 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2564:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2568:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    256c:	2501                	sext.w	a0,a0
    256e:	8082                	ret

0000000000002570 <sleep>:

int sleep(unsigned long long time)
{
    2570:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2572:	880a                	mv	a6,sp
{
    2574:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2576:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    257a:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    257c:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    257e:	00000073          	ecall
	if (err == 0) {
    2582:	2501                	sext.w	a0,a0
    2584:	ed31                	bnez	a0,25e0 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    2586:	6722                	ld	a4,8(sp)
    2588:	3e800793          	li	a5,1000
    258c:	6682                	ld	a3,0(sp)
    258e:	02f75733          	divu	a4,a4,a5
    2592:	02d787b3          	mul	a5,a5,a3
    2596:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    2598:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    259c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    259e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25a0:	00000073          	ecall
	if (err == 0) {
    25a4:	2501                	sext.w	a0,a0
    25a6:	e915                	bnez	a0,25da <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    25a8:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    25aa:	3e800693          	li	a3,1000
    25ae:	a819                	j	25c4 <sleep+0x54>
	__asm_syscall("r"(a7))
    25b0:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25b4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25b8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25ba:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25bc:	00000073          	ecall
	if (err == 0) {
    25c0:	2501                	sext.w	a0,a0
    25c2:	ed01                	bnez	a0,25da <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25c4:	6722                	ld	a4,8(sp)
    25c6:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25c8:	07c00893          	li	a7,124
    25cc:	02d75733          	divu	a4,a4,a3
    25d0:	02f687b3          	mul	a5,a3,a5
    25d4:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25d6:	fcc7ede3          	bltu	a5,a2,25b0 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25da:	4501                	li	a0,0
    25dc:	0141                	addi	sp,sp,16
    25de:	8082                	ret
    25e0:	57fd                	li	a5,-1
    25e2:	bf5d                	j	2598 <sleep+0x28>

00000000000025e4 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    25e4:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    25e8:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    25ec:	2501                	sext.w	a0,a0
    25ee:	8082                	ret

00000000000025f0 <set_priority>:
	register long a7 __asm__("a7") = n;
    25f0:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    25f4:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    25f8:	2501                	sext.w	a0,a0
    25fa:	8082                	ret

00000000000025fc <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    25fc:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2600:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2604:	2501                	sext.w	a0,a0
    2606:	8082                	ret

0000000000002608 <munmap>:
	register long a7 __asm__("a7") = n;
    2608:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    260c:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2610:	2501                	sext.w	a0,a0
    2612:	8082                	ret

0000000000002614 <wait>:

int wait(int *code)
{
    2614:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2616:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    261a:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261c:	00000073          	ecall
	return waitpid(-1, code);
}
    2620:	2501                	sext.w	a0,a0
    2622:	8082                	ret

0000000000002624 <spawn>:
	register long a7 __asm__("a7") = n;
    2624:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2628:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    262c:	2501                	sext.w	a0,a0
    262e:	8082                	ret

0000000000002630 <pipe>:
	register long a7 __asm__("a7") = n;
    2630:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2634:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2638:	2501                	sext.w	a0,a0
    263a:	8082                	ret

000000000000263c <mailread>:
	register long a7 __asm__("a7") = n;
    263c:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2640:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2644:	2501                	sext.w	a0,a0
    2646:	8082                	ret

0000000000002648 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2648:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    264c:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2650:	2501                	sext.w	a0,a0
    2652:	8082                	ret

0000000000002654 <fstat>:
	register long a7 __asm__("a7") = n;
    2654:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2658:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    265c:	2501                	sext.w	a0,a0
    265e:	8082                	ret

0000000000002660 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2660:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2662:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2666:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2668:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    266c:	2501                	sext.w	a0,a0
    266e:	8082                	ret

0000000000002670 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2670:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2672:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2676:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2678:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <link>:

int link(char *old_path, char *new_path)
{
    2680:	87aa                	mv	a5,a0
    2682:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    2684:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    2688:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    268c:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    268e:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    2692:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2694:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    2698:	2501                	sext.w	a0,a0
    269a:	8082                	ret

000000000000269c <unlink>:

int unlink(char *path)
{
    269c:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    269e:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    26a2:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    26a6:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26a8:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    26b0:	00000797          	auipc	a5,0x0
    26b4:	3f07b783          	ld	a5,1008(a5) # 2aa0 <_GLOBAL_OFFSET_TABLE_+0x8>
    26b8:	439c                	lw	a5,0(a5)
    26ba:	c799                	beqz	a5,26c8 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    26bc:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26c0:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26c4:	2501                	sext.w	a0,a0
    26c6:	8082                	ret
{
    26c8:	1101                	addi	sp,sp,-32
    26ca:	ec06                	sd	ra,24(sp)
    26cc:	e42e                	sd	a1,8(sp)
    26ce:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26d0:	fe7fe0ef          	jal	ra,16b6 <enable_thread_io_buffer>
    26d4:	65a2                	ld	a1,8(sp)
    26d6:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26d8:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26dc:	00000073          	ecall
}
    26e0:	60e2                	ld	ra,24(sp)
    26e2:	2501                	sext.w	a0,a0
    26e4:	6105                	addi	sp,sp,32
    26e6:	8082                	ret

00000000000026e8 <gettid>:
	register long a7 __asm__("a7") = n;
    26e8:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    26ec:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    26f0:	2501                	sext.w	a0,a0
    26f2:	8082                	ret

00000000000026f4 <waittid>:

int waittid(int tid)
{
    26f4:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    26f6:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    26fa:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    26fe:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2700:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2702:	00e51e63          	bne	a0,a4,271e <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2706:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    270a:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    270e:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2712:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2714:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2718:	2501                	sext.w	a0,a0
	while (ret == -2) {
    271a:	fee506e3          	beq	a0,a4,2706 <waittid+0x12>
	}
	return ret;
}
    271e:	8082                	ret

0000000000002720 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2720:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2724:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2726:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    272a:	2501                	sext.w	a0,a0
    272c:	8082                	ret

000000000000272e <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    272e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2732:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2734:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2738:	2501                	sext.w	a0,a0
    273a:	8082                	ret

000000000000273c <mutex_lock>:
	register long a7 __asm__("a7") = n;
    273c:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2740:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2744:	2501                	sext.w	a0,a0
    2746:	8082                	ret

0000000000002748 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2748:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    274c:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2750:	2501                	sext.w	a0,a0
    2752:	8082                	ret

0000000000002754 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2754:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2758:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    275c:	2501                	sext.w	a0,a0
    275e:	8082                	ret

0000000000002760 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2760:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2764:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2768:	2501                	sext.w	a0,a0
    276a:	8082                	ret

000000000000276c <semaphore_down>:
	register long a7 __asm__("a7") = n;
    276c:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2770:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2774:	2501                	sext.w	a0,a0
    2776:	8082                	ret

0000000000002778 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2778:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    277c:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    2780:	2501                	sext.w	a0,a0
    2782:	8082                	ret

0000000000002784 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    2784:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    2788:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    278c:	2501                	sext.w	a0,a0
    278e:	8082                	ret

0000000000002790 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    2790:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2794:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    2798:	2501                	sext.w	a0,a0
    279a:	8082                	ret

000000000000279c <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    279c:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    27a0:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    27a4:	2501                	sext.w	a0,a0
    27a6:	8082                	ret
