
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5_spawn0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	aaa5                	j	1178 <__start_main>

0000000000001002 <main>:
*/

const int MAX_CHILD = 40;

int main()
{
    1002:	711d                	addi	sp,sp,-96
    1004:	e4a6                	sd	s1,72(sp)
    1006:	e0ca                	sd	s2,64(sp)
    1008:	fc4e                	sd	s3,56(sp)
    100a:	f456                	sd	s5,40(sp)
    100c:	f05a                	sd	s6,32(sp)
    100e:	ec5e                	sd	s7,24(sp)
    1010:	ec86                	sd	ra,88(sp)
    1012:	e8a2                	sd	s0,80(sp)
    1014:	f852                	sd	s4,48(sp)
    1016:	02800493          	li	s1,40
	for (int _ = 0; _ < MAX_CHILD; ++_) {
		int cpid = spawn("ch5b_getpid\0");
    101a:	00002997          	auipc	s3,0x2
    101e:	b3698993          	addi	s3,s3,-1226 # 2b50 <buffer_lock+0x4>
		assert(cpid >= 0); // "child pid invalid"
		printf("new child %d\n", cpid);
    1022:	00002917          	auipc	s2,0x2
    1026:	84690913          	addi	s2,s2,-1978 # 2868 <enable_deadlock_detect+0x96>
		assert(cpid >= 0); // "child pid invalid"
    102a:	00001b97          	auipc	s7,0x1
    102e:	7b6b8b93          	addi	s7,s7,1974 # 27e0 <enable_deadlock_detect+0xe>
    1032:	00001b17          	auipc	s6,0x1
    1036:	7f6b0b13          	addi	s6,s6,2038 # 2828 <enable_deadlock_detect+0x56>
    103a:	00001a97          	auipc	s5,0x1
    103e:	7f6a8a93          	addi	s5,s5,2038 # 2830 <enable_deadlock_detect+0x5e>
		int cpid = spawn("ch5b_getpid\0");
    1042:	854e                	mv	a0,s3
    1044:	616010ef          	jal	ra,265a <spawn>
    1048:	842a                	mv	s0,a0
		printf("new child %d\n", cpid);
    104a:	85aa                	mv	a1,a0
    104c:	854a                	mv	a0,s2
		assert(cpid >= 0); // "child pid invalid"
    104e:	0e044c63          	bltz	s0,1146 <main+0x144>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    1052:	34fd                	addiw	s1,s1,-1
		printf("new child %d\n", cpid);
    1054:	27e000ef          	jal	ra,12d2 <printf>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    1058:	f4ed                	bnez	s1,1042 <main+0x40>
	}
	int exit_code = 0;
    105a:	c602                	sw	zero,12(sp)
    105c:	02800413          	li	s0,40
    1060:	00c10913          	addi	s2,sp,12
	for (int _ = 0; _ < MAX_CHILD; ++_) {
		assert(wait(&exit_code) > 0); // "wait stopped early"
    1064:	00001a17          	auipc	s4,0x1
    1068:	77ca0a13          	addi	s4,s4,1916 # 27e0 <enable_deadlock_detect+0xe>
    106c:	00001997          	auipc	s3,0x1
    1070:	7bc98993          	addi	s3,s3,1980 # 2828 <enable_deadlock_detect+0x56>
    1074:	00002b17          	auipc	s6,0x2
    1078:	804b0b13          	addi	s6,s6,-2044 # 2878 <enable_deadlock_detect+0xa6>
		assert_eq(exit_code, 0); // "error exit code"
    107c:	00002a97          	auipc	s5,0x2
    1080:	83ca8a93          	addi	s5,s5,-1988 # 28b8 <enable_deadlock_detect+0xe6>
		assert(wait(&exit_code) > 0); // "wait stopped early"
    1084:	854a                	mv	a0,s2
    1086:	5c4010ef          	jal	ra,264a <wait>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    108a:	347d                	addiw	s0,s0,-1
		assert(wait(&exit_code) > 0); // "wait stopped early"
    108c:	08a05b63          	blez	a0,1122 <main+0x120>
		assert_eq(exit_code, 0); // "error exit code"
    1090:	47b2                	lw	a5,12(sp)
    1092:	e3bd                	bnez	a5,10f8 <main+0xf6>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    1094:	f865                	bnez	s0,1084 <main+0x82>
	}
	assert(wait(&exit_code) < 0); // "wait got too many"
    1096:	854a                	mv	a0,s2
    1098:	5b2010ef          	jal	ra,264a <wait>
    109c:	02054c63          	bltz	a0,10d4 <main+0xd2>
    10a0:	464010ef          	jal	ra,2504 <getpid>
    10a4:	842a                	mv	s0,a0
    10a6:	00001517          	auipc	a0,0x1
    10aa:	73a50513          	addi	a0,a0,1850 # 27e0 <enable_deadlock_detect+0xe>
    10ae:	32c010ef          	jal	ra,23da <basename>
    10b2:	872a                	mv	a4,a0
    10b4:	47dd                	li	a5,23
    10b6:	00002517          	auipc	a0,0x2
    10ba:	83a50513          	addi	a0,a0,-1990 # 28f0 <enable_deadlock_detect+0x11e>
    10be:	86a2                	mv	a3,s0
    10c0:	00001617          	auipc	a2,0x1
    10c4:	76860613          	addi	a2,a2,1896 # 2828 <enable_deadlock_detect+0x56>
    10c8:	45fd                	li	a1,31
    10ca:	208000ef          	jal	ra,12d2 <printf>
    10ce:	557d                	li	a0,-1
    10d0:	464010ef          	jal	ra,2534 <exit>
	puts("Test many spawn OK!");
    10d4:	00002517          	auipc	a0,0x2
    10d8:	85c50513          	addi	a0,a0,-1956 # 2930 <enable_deadlock_detect+0x15e>
    10dc:	10d000ef          	jal	ra,19e8 <puts>
	return 0;
    10e0:	60e6                	ld	ra,88(sp)
    10e2:	6446                	ld	s0,80(sp)
    10e4:	64a6                	ld	s1,72(sp)
    10e6:	6906                	ld	s2,64(sp)
    10e8:	79e2                	ld	s3,56(sp)
    10ea:	7a42                	ld	s4,48(sp)
    10ec:	7aa2                	ld	s5,40(sp)
    10ee:	7b02                	ld	s6,32(sp)
    10f0:	6be2                	ld	s7,24(sp)
    10f2:	4501                	li	a0,0
    10f4:	6125                	addi	sp,sp,96
    10f6:	8082                	ret
		assert_eq(exit_code, 0); // "error exit code"
    10f8:	40c010ef          	jal	ra,2504 <getpid>
    10fc:	84aa                	mv	s1,a0
    10fe:	8552                	mv	a0,s4
    1100:	2da010ef          	jal	ra,23da <basename>
    1104:	4832                	lw	a6,12(sp)
    1106:	872a                	mv	a4,a0
    1108:	4881                	li	a7,0
    110a:	8556                	mv	a0,s5
    110c:	47d5                	li	a5,21
    110e:	86a6                	mv	a3,s1
    1110:	864e                	mv	a2,s3
    1112:	45fd                	li	a1,31
    1114:	1be000ef          	jal	ra,12d2 <printf>
    1118:	557d                	li	a0,-1
    111a:	41a010ef          	jal	ra,2534 <exit>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    111e:	f03d                	bnez	s0,1084 <main+0x82>
    1120:	bf9d                	j	1096 <main+0x94>
		assert(wait(&exit_code) > 0); // "wait stopped early"
    1122:	3e2010ef          	jal	ra,2504 <getpid>
    1126:	84aa                	mv	s1,a0
    1128:	8552                	mv	a0,s4
    112a:	2b0010ef          	jal	ra,23da <basename>
    112e:	872a                	mv	a4,a0
    1130:	47d1                	li	a5,20
    1132:	855a                	mv	a0,s6
    1134:	86a6                	mv	a3,s1
    1136:	864e                	mv	a2,s3
    1138:	45fd                	li	a1,31
    113a:	198000ef          	jal	ra,12d2 <printf>
    113e:	557d                	li	a0,-1
    1140:	3f4010ef          	jal	ra,2534 <exit>
    1144:	b7b1                	j	1090 <main+0x8e>
		assert(cpid >= 0); // "child pid invalid"
    1146:	3be010ef          	jal	ra,2504 <getpid>
    114a:	8a2a                	mv	s4,a0
    114c:	855e                	mv	a0,s7
    114e:	28c010ef          	jal	ra,23da <basename>
    1152:	872a                	mv	a4,a0
    1154:	45fd                	li	a1,31
    1156:	47bd                	li	a5,15
    1158:	86d2                	mv	a3,s4
    115a:	865a                	mv	a2,s6
    115c:	8556                	mv	a0,s5
    115e:	174000ef          	jal	ra,12d2 <printf>
    1162:	557d                	li	a0,-1
    1164:	3d0010ef          	jal	ra,2534 <exit>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    1168:	34fd                	addiw	s1,s1,-1
		printf("new child %d\n", cpid);
    116a:	85a2                	mv	a1,s0
    116c:	854a                	mv	a0,s2
    116e:	164000ef          	jal	ra,12d2 <printf>
	for (int _ = 0; _ < MAX_CHILD; ++_) {
    1172:	ec0498e3          	bnez	s1,1042 <main+0x40>
    1176:	b5d5                	j	105a <main+0x58>

0000000000001178 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1178:	1141                	addi	sp,sp,-16
    117a:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    117c:	e87ff0ef          	jal	ra,1002 <main>
    1180:	3b4010ef          	jal	ra,2534 <exit>
	return 0;
    1184:	60a2                	ld	ra,8(sp)
    1186:	4501                	li	a0,0
    1188:	0141                	addi	sp,sp,16
    118a:	8082                	ret

000000000000118c <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    118c:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    118e:	4605                	li	a2,1
    1190:	00f10593          	addi	a1,sp,15
    1194:	4501                	li	a0,0
{
    1196:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1198:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    119c:	354010ef          	jal	ra,24f0 <read>
    11a0:	4785                	li	a5,1
    11a2:	00f51763          	bne	a0,a5,11b0 <getchar+0x24>
		return byte;
    11a6:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    11aa:	60e2                	ld	ra,24(sp)
    11ac:	6105                	addi	sp,sp,32
    11ae:	8082                	ret
		return EOF;
    11b0:	557d                	li	a0,-1
    11b2:	bfe5                	j	11aa <getchar+0x1e>

00000000000011b4 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    11b4:	00002517          	auipc	a0,0x2
    11b8:	88c52503          	lw	a0,-1908(a0) # 2a40 <buffer_len>
    11bc:	e111                	bnez	a0,11c0 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    11be:	8082                	ret
{
    11c0:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11c2:	862a                	mv	a2,a0
    11c4:	00002597          	auipc	a1,0x2
    11c8:	88458593          	addi	a1,a1,-1916 # 2a48 <buffer>
    11cc:	4505                	li	a0,1
{
    11ce:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11d0:	32a010ef          	jal	ra,24fa <write>
}
    11d4:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11d6:	2501                	sext.w	a0,a0
}
    11d8:	0141                	addi	sp,sp,16
    11da:	8082                	ret

00000000000011dc <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    11dc:	00002797          	auipc	a5,0x2
    11e0:	8607a223          	sw	zero,-1948(a5) # 2a40 <buffer_len>
}
    11e4:	8082                	ret

00000000000011e6 <__fflush>:
	if (buffer_len == 0)
    11e6:	00002517          	auipc	a0,0x2
    11ea:	85a52503          	lw	a0,-1958(a0) # 2a40 <buffer_len>
    11ee:	e511                	bnez	a0,11fa <__fflush+0x14>
	buffer_len = 0;
    11f0:	00002797          	auipc	a5,0x2
    11f4:	8407a823          	sw	zero,-1968(a5) # 2a40 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11f8:	8082                	ret
{
    11fa:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11fc:	862a                	mv	a2,a0
    11fe:	00002597          	auipc	a1,0x2
    1202:	84a58593          	addi	a1,a1,-1974 # 2a48 <buffer>
    1206:	4505                	li	a0,1
{
    1208:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    120a:	2f0010ef          	jal	ra,24fa <write>
	return r >= 0 ? 0 : r;
    120e:	0005079b          	sext.w	a5,a0
}
    1212:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1214:	0017a793          	slti	a5,a5,1
    1218:	40f007bb          	negw	a5,a5
    121c:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    121e:	00002797          	auipc	a5,0x2
    1222:	8207a123          	sw	zero,-2014(a5) # 2a40 <buffer_len>
	return r >= 0 ? 0 : r;
    1226:	2501                	sext.w	a0,a0
}
    1228:	0141                	addi	sp,sp,16
    122a:	8082                	ret

000000000000122c <fflush>:

int fflush(int fd)
{
    122c:	1101                	addi	sp,sp,-32
    122e:	e822                	sd	s0,16(sp)
    1230:	ec06                	sd	ra,24(sp)
    1232:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1234:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1236:	4401                	li	s0,0
	if (fd == 1) {
    1238:	00e50863          	beq	a0,a4,1248 <fflush+0x1c>
}
    123c:	60e2                	ld	ra,24(sp)
    123e:	8522                	mv	a0,s0
    1240:	6442                	ld	s0,16(sp)
    1242:	64a2                	ld	s1,8(sp)
    1244:	6105                	addi	sp,sp,32
    1246:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1248:	00001497          	auipc	s1,0x1
    124c:	7f848493          	addi	s1,s1,2040 # 2a40 <buffer_len>
    1250:	1084a703          	lw	a4,264(s1)
    1254:	02a70e63          	beq	a4,a0,1290 <fflush+0x64>
	if (buffer_len == 0)
    1258:	4080                	lw	s0,0(s1)
    125a:	c00d                	beqz	s0,127c <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    125c:	8622                	mv	a2,s0
    125e:	00001597          	auipc	a1,0x1
    1262:	7ea58593          	addi	a1,a1,2026 # 2a48 <buffer>
    1266:	294010ef          	jal	ra,24fa <write>
	return r >= 0 ? 0 : r;
    126a:	0005079b          	sext.w	a5,a0
    126e:	0017a793          	slti	a5,a5,1
    1272:	40f007bb          	negw	a5,a5
    1276:	8d7d                	and	a0,a0,a5
    1278:	0005041b          	sext.w	s0,a0
}
    127c:	60e2                	ld	ra,24(sp)
    127e:	8522                	mv	a0,s0
    1280:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1282:	00001797          	auipc	a5,0x1
    1286:	7a07af23          	sw	zero,1982(a5) # 2a40 <buffer_len>
}
    128a:	64a2                	ld	s1,8(sp)
    128c:	6105                	addi	sp,sp,32
    128e:	8082                	ret
			mutex_lock(buffer_lock);
    1290:	10c4a503          	lw	a0,268(s1)
    1294:	4de010ef          	jal	ra,2772 <mutex_lock>
	if (buffer_len == 0)
    1298:	4080                	lw	s0,0(s1)
    129a:	e811                	bnez	s0,12ae <fflush+0x82>
			mutex_unlock(buffer_lock);
    129c:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    12a0:	00001797          	auipc	a5,0x1
    12a4:	7a07a023          	sw	zero,1952(a5) # 2a40 <buffer_len>
			mutex_unlock(buffer_lock);
    12a8:	4d6010ef          	jal	ra,277e <mutex_unlock>
    12ac:	bf41                	j	123c <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    12ae:	8622                	mv	a2,s0
    12b0:	00001597          	auipc	a1,0x1
    12b4:	79858593          	addi	a1,a1,1944 # 2a48 <buffer>
    12b8:	4505                	li	a0,1
    12ba:	240010ef          	jal	ra,24fa <write>
	return r >= 0 ? 0 : r;
    12be:	0005079b          	sext.w	a5,a0
    12c2:	0017a793          	slti	a5,a5,1
    12c6:	40f007bb          	negw	a5,a5
    12ca:	8d7d                	and	a0,a0,a5
    12cc:	0005041b          	sext.w	s0,a0
	return r;
    12d0:	b7f1                	j	129c <fflush+0x70>

00000000000012d2 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    12d2:	7131                	addi	sp,sp,-192
    12d4:	e0da                	sd	s6,64(sp)
    12d6:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    12d8:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    12da:	013c                	addi	a5,sp,136
{
    12dc:	f0ca                	sd	s2,96(sp)
    12de:	ecce                	sd	s3,88(sp)
    12e0:	e8d2                	sd	s4,80(sp)
    12e2:	e4d6                	sd	s5,72(sp)
    12e4:	fc86                	sd	ra,120(sp)
    12e6:	f8a2                	sd	s0,112(sp)
    12e8:	f4a6                	sd	s1,104(sp)
    12ea:	89aa                	mv	s3,a0
    12ec:	e52e                	sd	a1,136(sp)
    12ee:	e932                	sd	a2,144(sp)
    12f0:	ed36                	sd	a3,152(sp)
    12f2:	f13a                	sd	a4,160(sp)
    12f4:	f942                	sd	a6,176(sp)
    12f6:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12f8:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12fa:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12fe:	00001a17          	auipc	s4,0x1
    1302:	742a0a13          	addi	s4,s4,1858 # 2a40 <buffer_len>
    1306:	4a85                	li	s5,1
	buf[i++] = '0';
    1308:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    130c:	0009c783          	lbu	a5,0(s3)
    1310:	18078663          	beqz	a5,149c <printf+0x1ca>
    1314:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1316:	19278d63          	beq	a5,s2,14b0 <printf+0x1de>
    131a:	0015c783          	lbu	a5,1(a1)
    131e:	0585                	addi	a1,a1,1
    1320:	fbfd                	bnez	a5,1316 <printf+0x44>
    1322:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1324:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1328:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    132c:	1b578863          	beq	a5,s5,14dc <printf+0x20a>
		len = out_unlocked(s, l);
    1330:	85a2                	mv	a1,s0
    1332:	854e                	mv	a0,s3
    1334:	42a000ef          	jal	ra,175e <out_unlocked>
		out(f, a, l);
		if (l)
    1338:	1c041063          	bnez	s0,14f8 <printf+0x226>
			continue;
		if (s[1] == 0)
    133c:	0014c783          	lbu	a5,1(s1)
    1340:	14078e63          	beqz	a5,149c <printf+0x1ca>
			break;
		switch (s[1]) {
    1344:	07300713          	li	a4,115
    1348:	1ce78863          	beq	a5,a4,1518 <printf+0x246>
    134c:	1af76863          	bltu	a4,a5,14fc <printf+0x22a>
    1350:	06400713          	li	a4,100
    1354:	22e78063          	beq	a5,a4,1574 <printf+0x2a2>
    1358:	07000713          	li	a4,112
    135c:	1ee79563          	bne	a5,a4,1546 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1360:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1362:	00002797          	auipc	a5,0x2
    1366:	80678793          	addi	a5,a5,-2042 # 2b68 <digits>
	buf[i++] = '0';
    136a:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    136e:	6298                	ld	a4,0(a3)
    1370:	06a1                	addi	a3,a3,8
    1372:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1374:	00471393          	slli	t2,a4,0x4
    1378:	00871293          	slli	t0,a4,0x8
    137c:	00c71f93          	slli	t6,a4,0xc
    1380:	01071f13          	slli	t5,a4,0x10
    1384:	01471e93          	slli	t4,a4,0x14
    1388:	01871e13          	slli	t3,a4,0x18
    138c:	01c71893          	slli	a7,a4,0x1c
    1390:	02471813          	slli	a6,a4,0x24
    1394:	02871513          	slli	a0,a4,0x28
    1398:	02c71593          	slli	a1,a4,0x2c
    139c:	03071613          	slli	a2,a4,0x30
    13a0:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13a4:	03c75413          	srli	s0,a4,0x3c
    13a8:	01c7531b          	srliw	t1,a4,0x1c
    13ac:	03c3d393          	srli	t2,t2,0x3c
    13b0:	03c2d293          	srli	t0,t0,0x3c
    13b4:	03cfdf93          	srli	t6,t6,0x3c
    13b8:	03cf5f13          	srli	t5,t5,0x3c
    13bc:	03cede93          	srli	t4,t4,0x3c
    13c0:	03ce5e13          	srli	t3,t3,0x3c
    13c4:	03c8d893          	srli	a7,a7,0x3c
    13c8:	03c85813          	srli	a6,a6,0x3c
    13cc:	9171                	srli	a0,a0,0x3c
    13ce:	91f1                	srli	a1,a1,0x3c
    13d0:	9271                	srli	a2,a2,0x3c
    13d2:	92f1                	srli	a3,a3,0x3c
    13d4:	95be                	add	a1,a1,a5
    13d6:	963e                	add	a2,a2,a5
    13d8:	96be                	add	a3,a3,a5
    13da:	943e                	add	s0,s0,a5
    13dc:	93be                	add	t2,t2,a5
    13de:	92be                	add	t0,t0,a5
    13e0:	9fbe                	add	t6,t6,a5
    13e2:	9f3e                	add	t5,t5,a5
    13e4:	9ebe                	add	t4,t4,a5
    13e6:	9e3e                	add	t3,t3,a5
    13e8:	98be                	add	a7,a7,a5
    13ea:	933e                	add	t1,t1,a5
    13ec:	983e                	add	a6,a6,a5
    13ee:	953e                	add	a0,a0,a5
    13f0:	0005c983          	lbu	s3,0(a1)
    13f4:	00044403          	lbu	s0,0(s0)
    13f8:	00064583          	lbu	a1,0(a2)
    13fc:	0003c383          	lbu	t2,0(t2)
    1400:	0006c603          	lbu	a2,0(a3)
    1404:	0002c283          	lbu	t0,0(t0)
    1408:	000fcf83          	lbu	t6,0(t6)
    140c:	000f4f03          	lbu	t5,0(t5)
    1410:	000ece83          	lbu	t4,0(t4)
    1414:	000e4e03          	lbu	t3,0(t3)
    1418:	0008c883          	lbu	a7,0(a7)
    141c:	00034303          	lbu	t1,0(t1)
    1420:	00084803          	lbu	a6,0(a6)
    1424:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1428:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    142c:	92f1                	srli	a3,a3,0x3c
    142e:	8b3d                	andi	a4,a4,15
    1430:	96be                	add	a3,a3,a5
    1432:	97ba                	add	a5,a5,a4
    1434:	00810d23          	sb	s0,26(sp)
    1438:	00710da3          	sb	t2,27(sp)
    143c:	00510e23          	sb	t0,28(sp)
    1440:	01f10ea3          	sb	t6,29(sp)
    1444:	01e10f23          	sb	t5,30(sp)
    1448:	01d10fa3          	sb	t4,31(sp)
    144c:	03c10023          	sb	t3,32(sp)
    1450:	031100a3          	sb	a7,33(sp)
    1454:	02610123          	sb	t1,34(sp)
    1458:	030101a3          	sb	a6,35(sp)
    145c:	02a10223          	sb	a0,36(sp)
    1460:	033102a3          	sb	s3,37(sp)
    1464:	02b10323          	sb	a1,38(sp)
    1468:	02c103a3          	sb	a2,39(sp)
    146c:	0006c683          	lbu	a3,0(a3)
    1470:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1474:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1478:	02d10423          	sb	a3,40(sp)
    147c:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1480:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1484:	11578263          	beq	a5,s5,1588 <printf+0x2b6>
		len = out_unlocked(s, l);
    1488:	45c9                	li	a1,18
    148a:	0828                	addi	a0,sp,24
    148c:	2d2000ef          	jal	ra,175e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1490:	00248993          	addi	s3,s1,2
		if (!*s)
    1494:	0009c783          	lbu	a5,0(s3)
    1498:	e6079ee3          	bnez	a5,1314 <printf+0x42>
	}
	va_end(ap);
    149c:	70e6                	ld	ra,120(sp)
    149e:	7446                	ld	s0,112(sp)
    14a0:	74a6                	ld	s1,104(sp)
    14a2:	7906                	ld	s2,96(sp)
    14a4:	69e6                	ld	s3,88(sp)
    14a6:	6a46                	ld	s4,80(sp)
    14a8:	6aa6                	ld	s5,72(sp)
    14aa:	6b06                	ld	s6,64(sp)
    14ac:	6129                	addi	sp,sp,192
    14ae:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    14b0:	0005c783          	lbu	a5,0(a1)
    14b4:	84ae                	mv	s1,a1
    14b6:	01278963          	beq	a5,s2,14c8 <printf+0x1f6>
    14ba:	b5ad                	j	1324 <printf+0x52>
    14bc:	0024c783          	lbu	a5,2(s1)
    14c0:	0585                	addi	a1,a1,1
    14c2:	0489                	addi	s1,s1,2
    14c4:	e72790e3          	bne	a5,s2,1324 <printf+0x52>
    14c8:	0014c783          	lbu	a5,1(s1)
    14cc:	ff2788e3          	beq	a5,s2,14bc <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    14d0:	108a2783          	lw	a5,264(s4)
		l = z - a;
    14d4:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14d8:	e5579ce3          	bne	a5,s5,1330 <printf+0x5e>
		mutex_lock(buffer_lock);
    14dc:	10ca2503          	lw	a0,268(s4)
    14e0:	292010ef          	jal	ra,2772 <mutex_lock>
		len = out_unlocked(s, l);
    14e4:	85a2                	mv	a1,s0
    14e6:	854e                	mv	a0,s3
    14e8:	276000ef          	jal	ra,175e <out_unlocked>
		mutex_unlock(buffer_lock);
    14ec:	10ca2503          	lw	a0,268(s4)
    14f0:	28e010ef          	jal	ra,277e <mutex_unlock>
		if (l)
    14f4:	e40404e3          	beqz	s0,133c <printf+0x6a>
    14f8:	89a6                	mv	s3,s1
    14fa:	bd09                	j	130c <printf+0x3a>
		switch (s[1]) {
    14fc:	07800713          	li	a4,120
    1500:	04e79363          	bne	a5,a4,1546 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1504:	67c2                	ld	a5,16(sp)
    1506:	45c1                	li	a1,16
		s += 2;
    1508:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    150c:	4388                	lw	a0,0(a5)
    150e:	07a1                	addi	a5,a5,8
    1510:	e83e                	sd	a5,16(sp)
    1512:	5f8000ef          	jal	ra,1b0a <printint.constprop.0>
		s += 2;
    1516:	bfbd                	j	1494 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1518:	67c2                	ld	a5,16(sp)
    151a:	6380                	ld	s0,0(a5)
    151c:	07a1                	addi	a5,a5,8
    151e:	e83e                	sd	a5,16(sp)
    1520:	1c040163          	beqz	s0,16e2 <printf+0x410>
			l = strnlen(a, 200);
    1524:	0c800593          	li	a1,200
    1528:	8522                	mv	a0,s0
    152a:	3f7000ef          	jal	ra,2120 <strnlen>
	if (buffer_lock_enabled == 1) {
    152e:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1532:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1536:	19578663          	beq	a5,s5,16c2 <printf+0x3f0>
		len = out_unlocked(s, l);
    153a:	8522                	mv	a0,s0
    153c:	222000ef          	jal	ra,175e <out_unlocked>
		s += 2;
    1540:	00248993          	addi	s3,s1,2
    1544:	bf81                	j	1494 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1546:	108a2783          	lw	a5,264(s4)
	char byte = c;
    154a:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    154e:	0f578663          	beq	a5,s5,163a <printf+0x368>
		len = out_unlocked(s, l);
    1552:	0828                	addi	a0,sp,24
    1554:	316000ef          	jal	ra,186a <out_unlocked.constprop.0>
			putchar(s[1]);
    1558:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    155c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1560:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1564:	05578163          	beq	a5,s5,15a6 <printf+0x2d4>
		len = out_unlocked(s, l);
    1568:	0828                	addi	a0,sp,24
    156a:	300000ef          	jal	ra,186a <out_unlocked.constprop.0>
		s += 2;
    156e:	00248993          	addi	s3,s1,2
    1572:	b70d                	j	1494 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1574:	67c2                	ld	a5,16(sp)
    1576:	45a9                	li	a1,10
		s += 2;
    1578:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    157c:	4388                	lw	a0,0(a5)
    157e:	07a1                	addi	a5,a5,8
    1580:	e83e                	sd	a5,16(sp)
    1582:	588000ef          	jal	ra,1b0a <printint.constprop.0>
		s += 2;
    1586:	b739                	j	1494 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1588:	10ca2503          	lw	a0,268(s4)
		s += 2;
    158c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1590:	1e2010ef          	jal	ra,2772 <mutex_lock>
		len = out_unlocked(s, l);
    1594:	45c9                	li	a1,18
    1596:	0828                	addi	a0,sp,24
    1598:	1c6000ef          	jal	ra,175e <out_unlocked>
		mutex_unlock(buffer_lock);
    159c:	10ca2503          	lw	a0,268(s4)
    15a0:	1de010ef          	jal	ra,277e <mutex_unlock>
		s += 2;
    15a4:	bdc5                	j	1494 <printf+0x1c2>
		mutex_lock(buffer_lock);
    15a6:	10ca2503          	lw	a0,268(s4)
    15aa:	1c8010ef          	jal	ra,2772 <mutex_lock>
		buffer[buffer_len++] = c;
    15ae:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15b2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15b6:	0017861b          	addiw	a2,a5,1
    15ba:	97d2                	add	a5,a5,s4
    15bc:	00ca2023          	sw	a2,0(s4)
    15c0:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15c4:	00c6cc63          	blt	a3,a2,15dc <printf+0x30a>
    15c8:	47a9                	li	a5,10
    15ca:	06f40663          	beq	s0,a5,1636 <printf+0x364>
		mutex_unlock(buffer_lock);
    15ce:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15d2:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    15d6:	1a8010ef          	jal	ra,277e <mutex_unlock>
		s += 2;
    15da:	bd6d                	j	1494 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    15dc:	10000793          	li	a5,256
    15e0:	00f61e63          	bne	a2,a5,15fc <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    15e4:	00001597          	auipc	a1,0x1
    15e8:	46458593          	addi	a1,a1,1124 # 2a48 <buffer>
    15ec:	4505                	li	a0,1
    15ee:	70d000ef          	jal	ra,24fa <write>
	buffer_len = 0;
    15f2:	00001797          	auipc	a5,0x1
    15f6:	4407a723          	sw	zero,1102(a5) # 2a40 <buffer_len>
			if (r < 0) {
    15fa:	bfd1                	j	15ce <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15fc:	709000ef          	jal	ra,2504 <getpid>
    1600:	842a                	mv	s0,a0
    1602:	00001517          	auipc	a0,0x1
    1606:	34e50513          	addi	a0,a0,846 # 2950 <enable_deadlock_detect+0x17e>
    160a:	5d1000ef          	jal	ra,23da <basename>
    160e:	872a                	mv	a4,a0
    1610:	00001617          	auipc	a2,0x1
    1614:	21860613          	addi	a2,a2,536 # 2828 <enable_deadlock_detect+0x56>
    1618:	05400793          	li	a5,84
    161c:	86a2                	mv	a3,s0
    161e:	45fd                	li	a1,31
    1620:	00001517          	auipc	a0,0x1
    1624:	37050513          	addi	a0,a0,880 # 2990 <enable_deadlock_detect+0x1be>
    1628:	cabff0ef          	jal	ra,12d2 <printf>
    162c:	557d                	li	a0,-1
    162e:	707000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    1632:	000a2603          	lw	a2,0(s4)
    1636:	de41                	beqz	a2,15ce <printf+0x2fc>
    1638:	b775                	j	15e4 <printf+0x312>
		mutex_lock(buffer_lock);
    163a:	10ca2503          	lw	a0,268(s4)
    163e:	134010ef          	jal	ra,2772 <mutex_lock>
		buffer[buffer_len++] = c;
    1642:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1646:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    164a:	0017861b          	addiw	a2,a5,1
    164e:	97d2                	add	a5,a5,s4
    1650:	00ca2023          	sw	a2,0(s4)
    1654:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1658:	02c6d163          	bge	a3,a2,167a <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    165c:	10000793          	li	a5,256
    1660:	02f61263          	bne	a2,a5,1684 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1664:	00001597          	auipc	a1,0x1
    1668:	3e458593          	addi	a1,a1,996 # 2a48 <buffer>
    166c:	4505                	li	a0,1
    166e:	68d000ef          	jal	ra,24fa <write>
	buffer_len = 0;
    1672:	00001797          	auipc	a5,0x1
    1676:	3c07a723          	sw	zero,974(a5) # 2a40 <buffer_len>
		mutex_unlock(buffer_lock);
    167a:	10ca2503          	lw	a0,268(s4)
    167e:	100010ef          	jal	ra,277e <mutex_unlock>
    1682:	bdd9                	j	1558 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1684:	681000ef          	jal	ra,2504 <getpid>
    1688:	842a                	mv	s0,a0
    168a:	00001517          	auipc	a0,0x1
    168e:	2c650513          	addi	a0,a0,710 # 2950 <enable_deadlock_detect+0x17e>
    1692:	549000ef          	jal	ra,23da <basename>
    1696:	872a                	mv	a4,a0
    1698:	00001617          	auipc	a2,0x1
    169c:	19060613          	addi	a2,a2,400 # 2828 <enable_deadlock_detect+0x56>
    16a0:	05400793          	li	a5,84
    16a4:	86a2                	mv	a3,s0
    16a6:	45fd                	li	a1,31
    16a8:	00001517          	auipc	a0,0x1
    16ac:	2e850513          	addi	a0,a0,744 # 2990 <enable_deadlock_detect+0x1be>
    16b0:	c23ff0ef          	jal	ra,12d2 <printf>
    16b4:	557d                	li	a0,-1
    16b6:	67f000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    16ba:	000a2603          	lw	a2,0(s4)
    16be:	de55                	beqz	a2,167a <printf+0x3a8>
    16c0:	b755                	j	1664 <printf+0x392>
		mutex_lock(buffer_lock);
    16c2:	10ca2503          	lw	a0,268(s4)
    16c6:	e42e                	sd	a1,8(sp)
		s += 2;
    16c8:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16cc:	0a6010ef          	jal	ra,2772 <mutex_lock>
		len = out_unlocked(s, l);
    16d0:	65a2                	ld	a1,8(sp)
    16d2:	8522                	mv	a0,s0
    16d4:	08a000ef          	jal	ra,175e <out_unlocked>
		mutex_unlock(buffer_lock);
    16d8:	10ca2503          	lw	a0,268(s4)
    16dc:	0a2010ef          	jal	ra,277e <mutex_unlock>
		s += 2;
    16e0:	bb55                	j	1494 <printf+0x1c2>
				a = "(null)";
    16e2:	00001417          	auipc	s0,0x1
    16e6:	26640413          	addi	s0,s0,614 # 2948 <enable_deadlock_detect+0x176>
    16ea:	bd2d                	j	1524 <printf+0x252>

00000000000016ec <enable_thread_io_buffer>:
{
    16ec:	1101                	addi	sp,sp,-32
    16ee:	e822                	sd	s0,16(sp)
    16f0:	ec06                	sd	ra,24(sp)
    16f2:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    16f4:	00001417          	auipc	s0,0x1
    16f8:	34c40413          	addi	s0,s0,844 # 2a40 <buffer_len>
    16fc:	05a010ef          	jal	ra,2756 <mutex_create>
    1700:	10a42623          	sw	a0,268(s0)
    1704:	00054a63          	bltz	a0,1718 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1708:	4785                	li	a5,1
}
    170a:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    170c:	10f42423          	sw	a5,264(s0)
}
    1710:	6442                	ld	s0,16(sp)
    1712:	64a2                	ld	s1,8(sp)
    1714:	6105                	addi	sp,sp,32
    1716:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1718:	5ed000ef          	jal	ra,2504 <getpid>
    171c:	84aa                	mv	s1,a0
    171e:	00001517          	auipc	a0,0x1
    1722:	23250513          	addi	a0,a0,562 # 2950 <enable_deadlock_detect+0x17e>
    1726:	4b5000ef          	jal	ra,23da <basename>
    172a:	872a                	mv	a4,a0
    172c:	04800793          	li	a5,72
    1730:	86a6                	mv	a3,s1
    1732:	00001517          	auipc	a0,0x1
    1736:	29e50513          	addi	a0,a0,670 # 29d0 <enable_deadlock_detect+0x1fe>
    173a:	00001617          	auipc	a2,0x1
    173e:	0ee60613          	addi	a2,a2,238 # 2828 <enable_deadlock_detect+0x56>
    1742:	45fd                	li	a1,31
    1744:	b8fff0ef          	jal	ra,12d2 <printf>
    1748:	557d                	li	a0,-1
    174a:	5eb000ef          	jal	ra,2534 <exit>
	buffer_lock_enabled = 1;
    174e:	4785                	li	a5,1
}
    1750:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1752:	10f42423          	sw	a5,264(s0)
}
    1756:	6442                	ld	s0,16(sp)
    1758:	64a2                	ld	s1,8(sp)
    175a:	6105                	addi	sp,sp,32
    175c:	8082                	ret

000000000000175e <out_unlocked>:
{
    175e:	7159                	addi	sp,sp,-112
    1760:	f486                	sd	ra,104(sp)
    1762:	f0a2                	sd	s0,96(sp)
    1764:	eca6                	sd	s1,88(sp)
    1766:	e8ca                	sd	s2,80(sp)
    1768:	e4ce                	sd	s3,72(sp)
    176a:	e0d2                	sd	s4,64(sp)
    176c:	fc56                	sd	s5,56(sp)
    176e:	f85a                	sd	s6,48(sp)
    1770:	f45e                	sd	s7,40(sp)
    1772:	f062                	sd	s8,32(sp)
    1774:	ec66                	sd	s9,24(sp)
    1776:	e86a                	sd	s10,16(sp)
    1778:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    177a:	0e058663          	beqz	a1,1866 <out_unlocked+0x108>
    177e:	842a                	mv	s0,a0
    1780:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1784:	4981                	li	s3,0
    1786:	00001d17          	auipc	s10,0x1
    178a:	2bad0d13          	addi	s10,s10,698 # 2a40 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    178e:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1792:	00001b17          	auipc	s6,0x1
    1796:	2b6b0b13          	addi	s6,s6,694 # 2a48 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    179a:	10000a93          	li	s5,256
    179e:	00001c97          	auipc	s9,0x1
    17a2:	1b2c8c93          	addi	s9,s9,434 # 2950 <enable_deadlock_detect+0x17e>
    17a6:	00001c17          	auipc	s8,0x1
    17aa:	082c0c13          	addi	s8,s8,130 # 2828 <enable_deadlock_detect+0x56>
    17ae:	00001b97          	auipc	s7,0x1
    17b2:	1e2b8b93          	addi	s7,s7,482 # 2990 <enable_deadlock_detect+0x1be>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17b6:	4a29                	li	s4,10
    17b8:	a031                	j	17c4 <out_unlocked+0x66>
    17ba:	09468863          	beq	a3,s4,184a <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    17be:	0405                	addi	s0,s0,1
    17c0:	04848163          	beq	s1,s0,1802 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    17c4:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    17c8:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    17cc:	0017861b          	addiw	a2,a5,1
    17d0:	97ea                	add	a5,a5,s10
    17d2:	00cd2023          	sw	a2,0(s10)
    17d6:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17da:	fec950e3          	bge	s2,a2,17ba <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    17de:	05561263          	bne	a2,s5,1822 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    17e2:	85da                	mv	a1,s6
    17e4:	4505                	li	a0,1
    17e6:	515000ef          	jal	ra,24fa <write>
    17ea:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17ec:	00001797          	auipc	a5,0x1
    17f0:	2407aa23          	sw	zero,596(a5) # 2a40 <buffer_len>
			if (r < 0) {
    17f4:	06054763          	bltz	a0,1862 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17f8:	0405                	addi	s0,s0,1
			ret += r;
    17fa:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17fe:	fc8493e3          	bne	s1,s0,17c4 <out_unlocked+0x66>
}
    1802:	70a6                	ld	ra,104(sp)
    1804:	7406                	ld	s0,96(sp)
    1806:	64e6                	ld	s1,88(sp)
    1808:	6946                	ld	s2,80(sp)
    180a:	6a06                	ld	s4,64(sp)
    180c:	7ae2                	ld	s5,56(sp)
    180e:	7b42                	ld	s6,48(sp)
    1810:	7ba2                	ld	s7,40(sp)
    1812:	7c02                	ld	s8,32(sp)
    1814:	6ce2                	ld	s9,24(sp)
    1816:	6d42                	ld	s10,16(sp)
    1818:	6da2                	ld	s11,8(sp)
    181a:	854e                	mv	a0,s3
    181c:	69a6                	ld	s3,72(sp)
    181e:	6165                	addi	sp,sp,112
    1820:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1822:	4e3000ef          	jal	ra,2504 <getpid>
    1826:	8daa                	mv	s11,a0
    1828:	8566                	mv	a0,s9
    182a:	3b1000ef          	jal	ra,23da <basename>
    182e:	872a                	mv	a4,a0
    1830:	8662                	mv	a2,s8
    1832:	05400793          	li	a5,84
    1836:	86ee                	mv	a3,s11
    1838:	45fd                	li	a1,31
    183a:	855e                	mv	a0,s7
    183c:	a97ff0ef          	jal	ra,12d2 <printf>
    1840:	557d                	li	a0,-1
    1842:	4f3000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    1846:	000d2603          	lw	a2,0(s10)
    184a:	da35                	beqz	a2,17be <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    184c:	85da                	mv	a1,s6
    184e:	4505                	li	a0,1
    1850:	4ab000ef          	jal	ra,24fa <write>
    1854:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1856:	00001797          	auipc	a5,0x1
    185a:	1e07a523          	sw	zero,490(a5) # 2a40 <buffer_len>
			if (r < 0) {
    185e:	f8055de3          	bgez	a0,17f8 <out_unlocked+0x9a>
    1862:	89aa                	mv	s3,a0
    1864:	bf79                	j	1802 <out_unlocked+0xa4>
	int ret = 0;
    1866:	4981                	li	s3,0
    1868:	bf69                	j	1802 <out_unlocked+0xa4>

000000000000186a <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    186a:	1101                	addi	sp,sp,-32
    186c:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    186e:	00001497          	auipc	s1,0x1
    1872:	1d248493          	addi	s1,s1,466 # 2a40 <buffer_len>
    1876:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1878:	ec06                	sd	ra,24(sp)
    187a:	e822                	sd	s0,16(sp)
		char c = s[i];
    187c:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1880:	0017861b          	addiw	a2,a5,1
    1884:	97a6                	add	a5,a5,s1
    1886:	00e78423          	sb	a4,8(a5)
    188a:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    188c:	0ff00793          	li	a5,255
    1890:	00c7cc63          	blt	a5,a2,18a8 <out_unlocked.constprop.0+0x3e>
    1894:	47a9                	li	a5,10
    1896:	06f70c63          	beq	a4,a5,190e <out_unlocked.constprop.0+0xa4>
    189a:	4601                	li	a2,0
}
    189c:	60e2                	ld	ra,24(sp)
    189e:	6442                	ld	s0,16(sp)
    18a0:	64a2                	ld	s1,8(sp)
    18a2:	8532                	mv	a0,a2
    18a4:	6105                	addi	sp,sp,32
    18a6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18a8:	10000793          	li	a5,256
    18ac:	02f61563          	bne	a2,a5,18d6 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    18b0:	00001597          	auipc	a1,0x1
    18b4:	19858593          	addi	a1,a1,408 # 2a48 <buffer>
    18b8:	4505                	li	a0,1
    18ba:	441000ef          	jal	ra,24fa <write>
}
    18be:	60e2                	ld	ra,24(sp)
    18c0:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    18c2:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18c6:	00001797          	auipc	a5,0x1
    18ca:	1607ad23          	sw	zero,378(a5) # 2a40 <buffer_len>
}
    18ce:	64a2                	ld	s1,8(sp)
    18d0:	8532                	mv	a0,a2
    18d2:	6105                	addi	sp,sp,32
    18d4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18d6:	42f000ef          	jal	ra,2504 <getpid>
    18da:	842a                	mv	s0,a0
    18dc:	00001517          	auipc	a0,0x1
    18e0:	07450513          	addi	a0,a0,116 # 2950 <enable_deadlock_detect+0x17e>
    18e4:	2f7000ef          	jal	ra,23da <basename>
    18e8:	872a                	mv	a4,a0
    18ea:	00001617          	auipc	a2,0x1
    18ee:	f3e60613          	addi	a2,a2,-194 # 2828 <enable_deadlock_detect+0x56>
    18f2:	05400793          	li	a5,84
    18f6:	86a2                	mv	a3,s0
    18f8:	45fd                	li	a1,31
    18fa:	00001517          	auipc	a0,0x1
    18fe:	09650513          	addi	a0,a0,150 # 2990 <enable_deadlock_detect+0x1be>
    1902:	9d1ff0ef          	jal	ra,12d2 <printf>
    1906:	557d                	li	a0,-1
    1908:	42d000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    190c:	4090                	lw	a2,0(s1)
    190e:	d659                	beqz	a2,189c <out_unlocked.constprop.0+0x32>
    1910:	b745                	j	18b0 <out_unlocked.constprop.0+0x46>

0000000000001912 <putchar>:
{
    1912:	7139                	addi	sp,sp,-64
    1914:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1916:	00001497          	auipc	s1,0x1
    191a:	12a48493          	addi	s1,s1,298 # 2a40 <buffer_len>
    191e:	1084a703          	lw	a4,264(s1)
{
    1922:	f822                	sd	s0,48(sp)
	char byte = c;
    1924:	0ff57413          	zext.b	s0,a0
{
    1928:	fc06                	sd	ra,56(sp)
	char byte = c;
    192a:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    192e:	4785                	li	a5,1
    1930:	00f70d63          	beq	a4,a5,194a <putchar+0x38>
		len = out_unlocked(s, l);
    1934:	01f10513          	addi	a0,sp,31
    1938:	f33ff0ef          	jal	ra,186a <out_unlocked.constprop.0>
}
    193c:	70e2                	ld	ra,56(sp)
    193e:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1940:	862a                	mv	a2,a0
}
    1942:	74a2                	ld	s1,40(sp)
    1944:	8532                	mv	a0,a2
    1946:	6121                	addi	sp,sp,64
    1948:	8082                	ret
		mutex_lock(buffer_lock);
    194a:	10c4a503          	lw	a0,268(s1)
    194e:	625000ef          	jal	ra,2772 <mutex_lock>
		buffer[buffer_len++] = c;
    1952:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1954:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1958:	0017861b          	addiw	a2,a5,1
    195c:	97a6                	add	a5,a5,s1
    195e:	c090                	sw	a2,0(s1)
    1960:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1964:	02c6c263          	blt	a3,a2,1988 <putchar+0x76>
    1968:	47a9                	li	a5,10
    196a:	06f40d63          	beq	s0,a5,19e4 <putchar+0xd2>
    196e:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1970:	10c4a503          	lw	a0,268(s1)
    1974:	e432                	sd	a2,8(sp)
    1976:	609000ef          	jal	ra,277e <mutex_unlock>
    197a:	6622                	ld	a2,8(sp)
}
    197c:	70e2                	ld	ra,56(sp)
    197e:	7442                	ld	s0,48(sp)
    1980:	74a2                	ld	s1,40(sp)
    1982:	8532                	mv	a0,a2
    1984:	6121                	addi	sp,sp,64
    1986:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1988:	10000793          	li	a5,256
    198c:	02f61063          	bne	a2,a5,19ac <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1990:	00001597          	auipc	a1,0x1
    1994:	0b858593          	addi	a1,a1,184 # 2a48 <buffer>
    1998:	4505                	li	a0,1
    199a:	361000ef          	jal	ra,24fa <write>
    199e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19a2:	00001797          	auipc	a5,0x1
    19a6:	0807af23          	sw	zero,158(a5) # 2a40 <buffer_len>
			if (r < 0) {
    19aa:	b7d9                	j	1970 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    19ac:	359000ef          	jal	ra,2504 <getpid>
    19b0:	842a                	mv	s0,a0
    19b2:	00001517          	auipc	a0,0x1
    19b6:	f9e50513          	addi	a0,a0,-98 # 2950 <enable_deadlock_detect+0x17e>
    19ba:	221000ef          	jal	ra,23da <basename>
    19be:	872a                	mv	a4,a0
    19c0:	00001617          	auipc	a2,0x1
    19c4:	e6860613          	addi	a2,a2,-408 # 2828 <enable_deadlock_detect+0x56>
    19c8:	05400793          	li	a5,84
    19cc:	86a2                	mv	a3,s0
    19ce:	45fd                	li	a1,31
    19d0:	00001517          	auipc	a0,0x1
    19d4:	fc050513          	addi	a0,a0,-64 # 2990 <enable_deadlock_detect+0x1be>
    19d8:	8fbff0ef          	jal	ra,12d2 <printf>
    19dc:	557d                	li	a0,-1
    19de:	357000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    19e2:	4090                	lw	a2,0(s1)
    19e4:	d651                	beqz	a2,1970 <putchar+0x5e>
    19e6:	b76d                	j	1990 <putchar+0x7e>

00000000000019e8 <puts>:
{
    19e8:	7139                	addi	sp,sp,-64
    19ea:	f822                	sd	s0,48(sp)
    19ec:	f426                	sd	s1,40(sp)
    19ee:	fc06                	sd	ra,56(sp)
    19f0:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    19f2:	00001417          	auipc	s0,0x1
    19f6:	04e40413          	addi	s0,s0,78 # 2a40 <buffer_len>
{
    19fa:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19fc:	638000ef          	jal	ra,2034 <strlen>
	if (buffer_lock_enabled == 1) {
    1a00:	10842703          	lw	a4,264(s0)
    1a04:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a06:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1a08:	04f70563          	beq	a4,a5,1a52 <puts+0x6a>
		len = out_unlocked(s, l);
    1a0c:	8526                	mv	a0,s1
    1a0e:	d51ff0ef          	jal	ra,175e <out_unlocked>
    1a12:	892a                	mv	s2,a0
    1a14:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a16:	00095963          	bgez	s2,1a28 <puts+0x40>
}
    1a1a:	70e2                	ld	ra,56(sp)
    1a1c:	7442                	ld	s0,48(sp)
    1a1e:	7902                	ld	s2,32(sp)
    1a20:	8526                	mv	a0,s1
    1a22:	74a2                	ld	s1,40(sp)
    1a24:	6121                	addi	sp,sp,64
    1a26:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a28:	10842703          	lw	a4,264(s0)
	char byte = c;
    1a2c:	44a9                	li	s1,10
    1a2e:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1a32:	4785                	li	a5,1
    1a34:	02f70e63          	beq	a4,a5,1a70 <puts+0x88>
		len = out_unlocked(s, l);
    1a38:	01f10513          	addi	a0,sp,31
    1a3c:	e2fff0ef          	jal	ra,186a <out_unlocked.constprop.0>
}
    1a40:	70e2                	ld	ra,56(sp)
    1a42:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a44:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a48:	7902                	ld	s2,32(sp)
    1a4a:	8526                	mv	a0,s1
    1a4c:	74a2                	ld	s1,40(sp)
    1a4e:	6121                	addi	sp,sp,64
    1a50:	8082                	ret
		mutex_lock(buffer_lock);
    1a52:	e42a                	sd	a0,8(sp)
    1a54:	10c42503          	lw	a0,268(s0)
    1a58:	51b000ef          	jal	ra,2772 <mutex_lock>
		len = out_unlocked(s, l);
    1a5c:	65a2                	ld	a1,8(sp)
    1a5e:	8526                	mv	a0,s1
    1a60:	cffff0ef          	jal	ra,175e <out_unlocked>
    1a64:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a66:	10c42503          	lw	a0,268(s0)
    1a6a:	515000ef          	jal	ra,277e <mutex_unlock>
    1a6e:	b75d                	j	1a14 <puts+0x2c>
		mutex_lock(buffer_lock);
    1a70:	10c42503          	lw	a0,268(s0)
    1a74:	4ff000ef          	jal	ra,2772 <mutex_lock>
		buffer[buffer_len++] = c;
    1a78:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a7a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a7e:	0017861b          	addiw	a2,a5,1
    1a82:	97a2                	add	a5,a5,s0
    1a84:	c010                	sw	a2,0(s0)
    1a86:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a8a:	06c6dc63          	bge	a3,a2,1b02 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a8e:	10000793          	li	a5,256
    1a92:	02f61c63          	bne	a2,a5,1aca <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a96:	00001597          	auipc	a1,0x1
    1a9a:	fb258593          	addi	a1,a1,-78 # 2a48 <buffer>
    1a9e:	4505                	li	a0,1
    1aa0:	25b000ef          	jal	ra,24fa <write>
			if (r < 0) {
    1aa4:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1aa6:	00001797          	auipc	a5,0x1
    1aaa:	f807ad23          	sw	zero,-102(a5) # 2a40 <buffer_len>
			if (r < 0) {
    1aae:	04054c63          	bltz	a0,1b06 <puts+0x11e>
			if (r < buffer_len) {
    1ab2:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1ab4:	10c42503          	lw	a0,268(s0)
    1ab8:	4c7000ef          	jal	ra,277e <mutex_unlock>
}
    1abc:	70e2                	ld	ra,56(sp)
    1abe:	7442                	ld	s0,48(sp)
    1ac0:	7902                	ld	s2,32(sp)
    1ac2:	8526                	mv	a0,s1
    1ac4:	74a2                	ld	s1,40(sp)
    1ac6:	6121                	addi	sp,sp,64
    1ac8:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1aca:	23b000ef          	jal	ra,2504 <getpid>
    1ace:	84aa                	mv	s1,a0
    1ad0:	00001517          	auipc	a0,0x1
    1ad4:	e8050513          	addi	a0,a0,-384 # 2950 <enable_deadlock_detect+0x17e>
    1ad8:	103000ef          	jal	ra,23da <basename>
    1adc:	872a                	mv	a4,a0
    1ade:	00001617          	auipc	a2,0x1
    1ae2:	d4a60613          	addi	a2,a2,-694 # 2828 <enable_deadlock_detect+0x56>
    1ae6:	05400793          	li	a5,84
    1aea:	86a6                	mv	a3,s1
    1aec:	45fd                	li	a1,31
    1aee:	00001517          	auipc	a0,0x1
    1af2:	ea250513          	addi	a0,a0,-350 # 2990 <enable_deadlock_detect+0x1be>
    1af6:	fdcff0ef          	jal	ra,12d2 <printf>
    1afa:	557d                	li	a0,-1
    1afc:	239000ef          	jal	ra,2534 <exit>
	if (buffer_len == 0)
    1b00:	4010                	lw	a2,0(s0)
    1b02:	da45                	beqz	a2,1ab2 <puts+0xca>
    1b04:	bf49                	j	1a96 <puts+0xae>
    1b06:	54fd                	li	s1,-1
    1b08:	b775                	j	1ab4 <puts+0xcc>

0000000000001b0a <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1b0a:	715d                	addi	sp,sp,-80
    1b0c:	e486                	sd	ra,72(sp)
    1b0e:	e0a2                	sd	s0,64(sp)
    1b10:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1b12:	14054363          	bltz	a0,1c58 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1b16:	02b577bb          	remuw	a5,a0,a1
    1b1a:	00001617          	auipc	a2,0x1
    1b1e:	04e60613          	addi	a2,a2,78 # 2b68 <digits>
	buf[16] = 0;
    1b22:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b26:	0005871b          	sext.w	a4,a1
    1b2a:	1782                	slli	a5,a5,0x20
    1b2c:	9381                	srli	a5,a5,0x20
    1b2e:	97b2                	add	a5,a5,a2
    1b30:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b34:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b38:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b3c:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b3e:	0eb56763          	bltu	a0,a1,1c2c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b42:	02e877bb          	remuw	a5,a6,a4
    1b46:	1782                	slli	a5,a5,0x20
    1b48:	9381                	srli	a5,a5,0x20
    1b4a:	97b2                	add	a5,a5,a2
    1b4c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b50:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b54:	02f10323          	sb	a5,38(sp)
    1b58:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b5a:	0ce86963          	bltu	a6,a4,1c2c <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b5e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b62:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b66:	1582                	slli	a1,a1,0x20
    1b68:	9181                	srli	a1,a1,0x20
    1b6a:	95b2                	add	a1,a1,a2
    1b6c:	0005c583          	lbu	a1,0(a1)
    1b70:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b74:	0007859b          	sext.w	a1,a5
    1b78:	16e6e563          	bltu	a3,a4,1ce2 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b7c:	02e7f6bb          	remuw	a3,a5,a4
    1b80:	1682                	slli	a3,a3,0x20
    1b82:	9281                	srli	a3,a3,0x20
    1b84:	96b2                	add	a3,a3,a2
    1b86:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b8a:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b8e:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b92:	16e5e163          	bltu	a1,a4,1cf4 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b96:	02e876bb          	remuw	a3,a6,a4
    1b9a:	1682                	slli	a3,a3,0x20
    1b9c:	9281                	srli	a3,a3,0x20
    1b9e:	96b2                	add	a3,a3,a2
    1ba0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ba4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ba8:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1bac:	14e86d63          	bltu	a6,a4,1d06 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1bb0:	02e5f6bb          	remuw	a3,a1,a4
    1bb4:	1682                	slli	a3,a3,0x20
    1bb6:	9281                	srli	a3,a3,0x20
    1bb8:	96b2                	add	a3,a3,a2
    1bba:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bbe:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bc2:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1bc6:	10e5e563          	bltu	a1,a4,1cd0 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1bca:	02e876bb          	remuw	a3,a6,a4
    1bce:	1682                	slli	a3,a3,0x20
    1bd0:	9281                	srli	a3,a3,0x20
    1bd2:	96b2                	add	a3,a3,a2
    1bd4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bd8:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1bdc:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1be0:	14e86263          	bltu	a6,a4,1d24 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1be4:	02e5f6bb          	remuw	a3,a1,a4
    1be8:	1682                	slli	a3,a3,0x20
    1bea:	9281                	srli	a3,a3,0x20
    1bec:	96b2                	add	a3,a3,a2
    1bee:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bf2:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bf6:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1bfa:	14e5e463          	bltu	a1,a4,1d42 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1bfe:	02e876bb          	remuw	a3,a6,a4
    1c02:	1682                	slli	a3,a3,0x20
    1c04:	9281                	srli	a3,a3,0x20
    1c06:	96b2                	add	a3,a3,a2
    1c08:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c0c:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1c10:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1c14:	14e86063          	bltu	a6,a4,1d54 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1c18:	1782                	slli	a5,a5,0x20
    1c1a:	9381                	srli	a5,a5,0x20
    1c1c:	97b2                	add	a5,a5,a2
    1c1e:	0007c703          	lbu	a4,0(a5)
    1c22:	4799                	li	a5,6
    1c24:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c28:	10054763          	bltz	a0,1d36 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1c2c:	00001497          	auipc	s1,0x1
    1c30:	e1448493          	addi	s1,s1,-492 # 2a40 <buffer_len>
    1c34:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c38:	0828                	addi	a0,sp,24
    1c3a:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c3c:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c3e:	00f50433          	add	s0,a0,a5
    1c42:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c44:	06e68463          	beq	a3,a4,1cac <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c48:	8522                	mv	a0,s0
    1c4a:	b15ff0ef          	jal	ra,175e <out_unlocked>
}
    1c4e:	60a6                	ld	ra,72(sp)
    1c50:	6406                	ld	s0,64(sp)
    1c52:	74e2                	ld	s1,56(sp)
    1c54:	6161                	addi	sp,sp,80
    1c56:	8082                	ret
		x = -xx;
    1c58:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c5c:	02b877bb          	remuw	a5,a6,a1
    1c60:	00001617          	auipc	a2,0x1
    1c64:	f0860613          	addi	a2,a2,-248 # 2b68 <digits>
	buf[16] = 0;
    1c68:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c6c:	0005871b          	sext.w	a4,a1
    1c70:	1782                	slli	a5,a5,0x20
    1c72:	9381                	srli	a5,a5,0x20
    1c74:	97b2                	add	a5,a5,a2
    1c76:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c7a:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c7e:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c82:	08b86b63          	bltu	a6,a1,1d18 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c86:	02e8f7bb          	remuw	a5,a7,a4
    1c8a:	1782                	slli	a5,a5,0x20
    1c8c:	9381                	srli	a5,a5,0x20
    1c8e:	97b2                	add	a5,a5,a2
    1c90:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c94:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c98:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c9c:	ece8f1e3          	bgeu	a7,a4,1b5e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1ca0:	02d00793          	li	a5,45
    1ca4:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1ca8:	47b5                	li	a5,13
    1caa:	b749                	j	1c2c <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1cac:	10c4a503          	lw	a0,268(s1)
    1cb0:	e42e                	sd	a1,8(sp)
    1cb2:	2c1000ef          	jal	ra,2772 <mutex_lock>
		len = out_unlocked(s, l);
    1cb6:	65a2                	ld	a1,8(sp)
    1cb8:	8522                	mv	a0,s0
    1cba:	aa5ff0ef          	jal	ra,175e <out_unlocked>
		mutex_unlock(buffer_lock);
    1cbe:	10c4a503          	lw	a0,268(s1)
    1cc2:	2bd000ef          	jal	ra,277e <mutex_unlock>
}
    1cc6:	60a6                	ld	ra,72(sp)
    1cc8:	6406                	ld	s0,64(sp)
    1cca:	74e2                	ld	s1,56(sp)
    1ccc:	6161                	addi	sp,sp,80
    1cce:	8082                	ret
		buf[i--] = digits[x % base];
    1cd0:	47a9                	li	a5,10
	if (sign)
    1cd2:	f4055de3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd6:	02d00793          	li	a5,45
    1cda:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1cde:	47a5                	li	a5,9
    1ce0:	b7b1                	j	1c2c <printint.constprop.0+0x122>
    1ce2:	47b5                	li	a5,13
	if (sign)
    1ce4:	f40554e3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce8:	02d00793          	li	a5,45
    1cec:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1cf0:	47b1                	li	a5,12
    1cf2:	bf2d                	j	1c2c <printint.constprop.0+0x122>
    1cf4:	47b1                	li	a5,12
	if (sign)
    1cf6:	f2055be3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cfa:	02d00793          	li	a5,45
    1cfe:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1d02:	47ad                	li	a5,11
    1d04:	b725                	j	1c2c <printint.constprop.0+0x122>
    1d06:	47ad                	li	a5,11
	if (sign)
    1d08:	f20552e3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d0c:	02d00793          	li	a5,45
    1d10:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1d14:	47a9                	li	a5,10
    1d16:	bf19                	j	1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d18:	02d00793          	li	a5,45
    1d1c:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1d20:	47b9                	li	a5,14
    1d22:	b729                	j	1c2c <printint.constprop.0+0x122>
    1d24:	47a5                	li	a5,9
	if (sign)
    1d26:	f00553e3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d2a:	02d00793          	li	a5,45
    1d2e:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1d32:	47a1                	li	a5,8
    1d34:	bde5                	j	1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d36:	02d00793          	li	a5,45
    1d3a:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d3e:	4795                	li	a5,5
    1d40:	b5f5                	j	1c2c <printint.constprop.0+0x122>
    1d42:	47a1                	li	a5,8
	if (sign)
    1d44:	ee0554e3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d48:	02d00793          	li	a5,45
    1d4c:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d50:	479d                	li	a5,7
    1d52:	bde9                	j	1c2c <printint.constprop.0+0x122>
    1d54:	479d                	li	a5,7
	if (sign)
    1d56:	ec055be3          	bgez	a0,1c2c <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d5a:	02d00793          	li	a5,45
    1d5e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d62:	4799                	li	a5,6
    1d64:	b5e1                	j	1c2c <printint.constprop.0+0x122>

0000000000001d66 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d66:	02000793          	li	a5,32
    1d6a:	00f50663          	beq	a0,a5,1d76 <isspace+0x10>
    1d6e:	355d                	addiw	a0,a0,-9
    1d70:	00553513          	sltiu	a0,a0,5
    1d74:	8082                	ret
    1d76:	4505                	li	a0,1
}
    1d78:	8082                	ret

0000000000001d7a <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d7a:	fd05051b          	addiw	a0,a0,-48
}
    1d7e:	00a53513          	sltiu	a0,a0,10
    1d82:	8082                	ret

0000000000001d84 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d84:	02000613          	li	a2,32
    1d88:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d8a:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d8e:	ff77869b          	addiw	a3,a5,-9
    1d92:	04c78c63          	beq	a5,a2,1dea <atoi+0x66>
    1d96:	0007871b          	sext.w	a4,a5
    1d9a:	04d5f863          	bgeu	a1,a3,1dea <atoi+0x66>
		s++;
	switch (*s) {
    1d9e:	02b00693          	li	a3,43
    1da2:	04d78963          	beq	a5,a3,1df4 <atoi+0x70>
    1da6:	02d00693          	li	a3,45
    1daa:	06d78263          	beq	a5,a3,1e0e <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1dae:	fd07061b          	addiw	a2,a4,-48
    1db2:	47a5                	li	a5,9
    1db4:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1db6:	4e01                	li	t3,0
	while (isdigit(*s))
    1db8:	04c7e963          	bltu	a5,a2,1e0a <atoi+0x86>
	int n = 0, neg = 0;
    1dbc:	4501                	li	a0,0
	while (isdigit(*s))
    1dbe:	4825                	li	a6,9
    1dc0:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1dc4:	0025179b          	slliw	a5,a0,0x2
    1dc8:	9fa9                	addw	a5,a5,a0
    1dca:	fd07031b          	addiw	t1,a4,-48
    1dce:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1dd2:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1dd6:	0685                	addi	a3,a3,1
    1dd8:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1ddc:	0006071b          	sext.w	a4,a2
    1de0:	feb870e3          	bgeu	a6,a1,1dc0 <atoi+0x3c>
	return neg ? n : -n;
    1de4:	000e0563          	beqz	t3,1dee <atoi+0x6a>
}
    1de8:	8082                	ret
		s++;
    1dea:	0505                	addi	a0,a0,1
    1dec:	bf79                	j	1d8a <atoi+0x6>
	return neg ? n : -n;
    1dee:	4113053b          	subw	a0,t1,a7
    1df2:	8082                	ret
	while (isdigit(*s))
    1df4:	00154703          	lbu	a4,1(a0)
    1df8:	47a5                	li	a5,9
		s++;
    1dfa:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dfe:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1e02:	4e01                	li	t3,0
	while (isdigit(*s))
    1e04:	2701                	sext.w	a4,a4
    1e06:	fac7fbe3          	bgeu	a5,a2,1dbc <atoi+0x38>
    1e0a:	4501                	li	a0,0
}
    1e0c:	8082                	ret
	while (isdigit(*s))
    1e0e:	00154703          	lbu	a4,1(a0)
    1e12:	47a5                	li	a5,9
		s++;
    1e14:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e18:	fd07061b          	addiw	a2,a4,-48
    1e1c:	2701                	sext.w	a4,a4
    1e1e:	fec7e6e3          	bltu	a5,a2,1e0a <atoi+0x86>
		neg = 1;
    1e22:	4e05                	li	t3,1
    1e24:	bf61                	j	1dbc <atoi+0x38>

0000000000001e26 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e26:	16060d63          	beqz	a2,1fa0 <memset+0x17a>
    1e2a:	40a007b3          	neg	a5,a0
    1e2e:	8b9d                	andi	a5,a5,7
    1e30:	00778693          	addi	a3,a5,7
    1e34:	482d                	li	a6,11
    1e36:	0ff5f713          	zext.b	a4,a1
    1e3a:	fff60593          	addi	a1,a2,-1
    1e3e:	1706e263          	bltu	a3,a6,1fa2 <memset+0x17c>
    1e42:	16d5ea63          	bltu	a1,a3,1fb6 <memset+0x190>
    1e46:	16078563          	beqz	a5,1fb0 <memset+0x18a>
    1e4a:	00e50023          	sb	a4,0(a0)
    1e4e:	4685                	li	a3,1
    1e50:	00150593          	addi	a1,a0,1
    1e54:	14d78c63          	beq	a5,a3,1fac <memset+0x186>
    1e58:	00e500a3          	sb	a4,1(a0)
    1e5c:	4689                	li	a3,2
    1e5e:	00250593          	addi	a1,a0,2
    1e62:	14d78d63          	beq	a5,a3,1fbc <memset+0x196>
    1e66:	00e50123          	sb	a4,2(a0)
    1e6a:	468d                	li	a3,3
    1e6c:	00350593          	addi	a1,a0,3
    1e70:	12d78b63          	beq	a5,a3,1fa6 <memset+0x180>
    1e74:	00e501a3          	sb	a4,3(a0)
    1e78:	4691                	li	a3,4
    1e7a:	00450593          	addi	a1,a0,4
    1e7e:	14d78163          	beq	a5,a3,1fc0 <memset+0x19a>
    1e82:	00e50223          	sb	a4,4(a0)
    1e86:	4695                	li	a3,5
    1e88:	00550593          	addi	a1,a0,5
    1e8c:	12d78c63          	beq	a5,a3,1fc4 <memset+0x19e>
    1e90:	00e502a3          	sb	a4,5(a0)
    1e94:	469d                	li	a3,7
    1e96:	00650593          	addi	a1,a0,6
    1e9a:	12d79763          	bne	a5,a3,1fc8 <memset+0x1a2>
    1e9e:	00750593          	addi	a1,a0,7
    1ea2:	00e50323          	sb	a4,6(a0)
    1ea6:	481d                	li	a6,7
    1ea8:	00871693          	slli	a3,a4,0x8
    1eac:	01071893          	slli	a7,a4,0x10
    1eb0:	8ed9                	or	a3,a3,a4
    1eb2:	01871313          	slli	t1,a4,0x18
    1eb6:	0116e6b3          	or	a3,a3,a7
    1eba:	0066e6b3          	or	a3,a3,t1
    1ebe:	02071893          	slli	a7,a4,0x20
    1ec2:	02871e13          	slli	t3,a4,0x28
    1ec6:	0116e6b3          	or	a3,a3,a7
    1eca:	40f60333          	sub	t1,a2,a5
    1ece:	03071893          	slli	a7,a4,0x30
    1ed2:	01c6e6b3          	or	a3,a3,t3
    1ed6:	0116e6b3          	or	a3,a3,a7
    1eda:	03871e13          	slli	t3,a4,0x38
    1ede:	97aa                	add	a5,a5,a0
    1ee0:	ff837893          	andi	a7,t1,-8
    1ee4:	01c6e6b3          	or	a3,a3,t3
    1ee8:	98be                	add	a7,a7,a5
    1eea:	e394                	sd	a3,0(a5)
    1eec:	07a1                	addi	a5,a5,8
    1eee:	ff179ee3          	bne	a5,a7,1eea <memset+0xc4>
    1ef2:	ff837893          	andi	a7,t1,-8
    1ef6:	011587b3          	add	a5,a1,a7
    1efa:	010886bb          	addw	a3,a7,a6
    1efe:	0b130663          	beq	t1,a7,1faa <memset+0x184>
    1f02:	00e78023          	sb	a4,0(a5)
    1f06:	0016859b          	addiw	a1,a3,1
    1f0a:	08c5fb63          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f0e:	00e780a3          	sb	a4,1(a5)
    1f12:	0026859b          	addiw	a1,a3,2
    1f16:	08c5f563          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f1a:	00e78123          	sb	a4,2(a5)
    1f1e:	0036859b          	addiw	a1,a3,3
    1f22:	06c5ff63          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f26:	00e781a3          	sb	a4,3(a5)
    1f2a:	0046859b          	addiw	a1,a3,4
    1f2e:	06c5f963          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f32:	00e78223          	sb	a4,4(a5)
    1f36:	0056859b          	addiw	a1,a3,5
    1f3a:	06c5f363          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f3e:	00e782a3          	sb	a4,5(a5)
    1f42:	0066859b          	addiw	a1,a3,6
    1f46:	04c5fd63          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f4a:	00e78323          	sb	a4,6(a5)
    1f4e:	0076859b          	addiw	a1,a3,7
    1f52:	04c5f763          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f56:	00e783a3          	sb	a4,7(a5)
    1f5a:	0086859b          	addiw	a1,a3,8
    1f5e:	04c5f163          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f62:	00e78423          	sb	a4,8(a5)
    1f66:	0096859b          	addiw	a1,a3,9
    1f6a:	02c5fb63          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f6e:	00e784a3          	sb	a4,9(a5)
    1f72:	00a6859b          	addiw	a1,a3,10
    1f76:	02c5f563          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f7a:	00e78523          	sb	a4,10(a5)
    1f7e:	00b6859b          	addiw	a1,a3,11
    1f82:	00c5ff63          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f86:	00e785a3          	sb	a4,11(a5)
    1f8a:	00c6859b          	addiw	a1,a3,12
    1f8e:	00c5f963          	bgeu	a1,a2,1fa0 <memset+0x17a>
    1f92:	00e78623          	sb	a4,12(a5)
    1f96:	26b5                	addiw	a3,a3,13
    1f98:	00c6f463          	bgeu	a3,a2,1fa0 <memset+0x17a>
    1f9c:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1fa0:	8082                	ret
    1fa2:	46ad                	li	a3,11
    1fa4:	bd79                	j	1e42 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fa6:	480d                	li	a6,3
    1fa8:	b701                	j	1ea8 <memset+0x82>
    1faa:	8082                	ret
    1fac:	4805                	li	a6,1
    1fae:	bded                	j	1ea8 <memset+0x82>
    1fb0:	85aa                	mv	a1,a0
    1fb2:	4801                	li	a6,0
    1fb4:	bdd5                	j	1ea8 <memset+0x82>
    1fb6:	87aa                	mv	a5,a0
    1fb8:	4681                	li	a3,0
    1fba:	b7a1                	j	1f02 <memset+0xdc>
    1fbc:	4809                	li	a6,2
    1fbe:	b5ed                	j	1ea8 <memset+0x82>
    1fc0:	4811                	li	a6,4
    1fc2:	b5dd                	j	1ea8 <memset+0x82>
    1fc4:	4815                	li	a6,5
    1fc6:	b5cd                	j	1ea8 <memset+0x82>
    1fc8:	4819                	li	a6,6
    1fca:	bdf9                	j	1ea8 <memset+0x82>

0000000000001fcc <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1fcc:	00054783          	lbu	a5,0(a0)
    1fd0:	0005c703          	lbu	a4,0(a1)
    1fd4:	00e79863          	bne	a5,a4,1fe4 <strcmp+0x18>
    1fd8:	0505                	addi	a0,a0,1
    1fda:	0585                	addi	a1,a1,1
    1fdc:	fbe5                	bnez	a5,1fcc <strcmp>
    1fde:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1fe0:	9d19                	subw	a0,a0,a4
    1fe2:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1fe4:	0007851b          	sext.w	a0,a5
    1fe8:	bfe5                	j	1fe0 <strcmp+0x14>

0000000000001fea <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1fea:	ca15                	beqz	a2,201e <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fec:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1ff0:	167d                	addi	a2,a2,-1
    1ff2:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1ff6:	eb99                	bnez	a5,200c <strncmp+0x22>
    1ff8:	a815                	j	202c <strncmp+0x42>
    1ffa:	00a68e63          	beq	a3,a0,2016 <strncmp+0x2c>
    1ffe:	0505                	addi	a0,a0,1
    2000:	00f71b63          	bne	a4,a5,2016 <strncmp+0x2c>
    2004:	00054783          	lbu	a5,0(a0)
    2008:	cf89                	beqz	a5,2022 <strncmp+0x38>
    200a:	85b2                	mv	a1,a2
    200c:	0005c703          	lbu	a4,0(a1)
    2010:	00158613          	addi	a2,a1,1
    2014:	f37d                	bnez	a4,1ffa <strncmp+0x10>
		;
	return *l - *r;
    2016:	0007851b          	sext.w	a0,a5
    201a:	9d19                	subw	a0,a0,a4
    201c:	8082                	ret
		return 0;
    201e:	4501                	li	a0,0
}
    2020:	8082                	ret
	return *l - *r;
    2022:	0015c703          	lbu	a4,1(a1)
    2026:	4501                	li	a0,0
    2028:	9d19                	subw	a0,a0,a4
    202a:	8082                	ret
    202c:	0005c703          	lbu	a4,0(a1)
    2030:	4501                	li	a0,0
    2032:	b7e5                	j	201a <strncmp+0x30>

0000000000002034 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2034:	00757793          	andi	a5,a0,7
    2038:	cf89                	beqz	a5,2052 <strlen+0x1e>
    203a:	87aa                	mv	a5,a0
    203c:	a029                	j	2046 <strlen+0x12>
    203e:	0785                	addi	a5,a5,1
    2040:	0077f713          	andi	a4,a5,7
    2044:	cb01                	beqz	a4,2054 <strlen+0x20>
		if (!*s)
    2046:	0007c703          	lbu	a4,0(a5)
    204a:	fb75                	bnez	a4,203e <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    204c:	40a78533          	sub	a0,a5,a0
}
    2050:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2052:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2054:	6394                	ld	a3,0(a5)
    2056:	00001597          	auipc	a1,0x1
    205a:	9d25b583          	ld	a1,-1582(a1) # 2a28 <enable_deadlock_detect+0x256>
    205e:	00001617          	auipc	a2,0x1
    2062:	9d263603          	ld	a2,-1582(a2) # 2a30 <enable_deadlock_detect+0x25e>
    2066:	a019                	j	206c <strlen+0x38>
    2068:	6794                	ld	a3,8(a5)
    206a:	07a1                	addi	a5,a5,8
    206c:	00b68733          	add	a4,a3,a1
    2070:	fff6c693          	not	a3,a3
    2074:	8f75                	and	a4,a4,a3
    2076:	8f71                	and	a4,a4,a2
    2078:	db65                	beqz	a4,2068 <strlen+0x34>
	for (; *s; s++)
    207a:	0007c703          	lbu	a4,0(a5)
    207e:	d779                	beqz	a4,204c <strlen+0x18>
    2080:	0017c703          	lbu	a4,1(a5)
    2084:	0785                	addi	a5,a5,1
    2086:	d379                	beqz	a4,204c <strlen+0x18>
    2088:	0017c703          	lbu	a4,1(a5)
    208c:	0785                	addi	a5,a5,1
    208e:	fb6d                	bnez	a4,2080 <strlen+0x4c>
    2090:	bf75                	j	204c <strlen+0x18>

0000000000002092 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2092:	00757713          	andi	a4,a0,7
{
    2096:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2098:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    209c:	cb19                	beqz	a4,20b2 <memchr+0x20>
    209e:	ce25                	beqz	a2,2116 <memchr+0x84>
    20a0:	0007c703          	lbu	a4,0(a5)
    20a4:	04b70e63          	beq	a4,a1,2100 <memchr+0x6e>
    20a8:	0785                	addi	a5,a5,1
    20aa:	0077f713          	andi	a4,a5,7
    20ae:	167d                	addi	a2,a2,-1
    20b0:	f77d                	bnez	a4,209e <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    20b2:	4501                	li	a0,0
	if (n && *s != c) {
    20b4:	c235                	beqz	a2,2118 <memchr+0x86>
    20b6:	0007c703          	lbu	a4,0(a5)
    20ba:	04b70363          	beq	a4,a1,2100 <memchr+0x6e>
		size_t k = ONES * c;
    20be:	00001517          	auipc	a0,0x1
    20c2:	97a53503          	ld	a0,-1670(a0) # 2a38 <enable_deadlock_detect+0x266>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20c6:	471d                	li	a4,7
		size_t k = ONES * c;
    20c8:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20cc:	02c77a63          	bgeu	a4,a2,2100 <memchr+0x6e>
    20d0:	00001897          	auipc	a7,0x1
    20d4:	9588b883          	ld	a7,-1704(a7) # 2a28 <enable_deadlock_detect+0x256>
    20d8:	00001817          	auipc	a6,0x1
    20dc:	95883803          	ld	a6,-1704(a6) # 2a30 <enable_deadlock_detect+0x25e>
    20e0:	431d                	li	t1,7
    20e2:	a029                	j	20ec <memchr+0x5a>
		     w++, n -= SS)
    20e4:	1661                	addi	a2,a2,-8
    20e6:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20e8:	02c37963          	bgeu	t1,a2,211a <memchr+0x88>
    20ec:	6398                	ld	a4,0(a5)
    20ee:	8f29                	xor	a4,a4,a0
    20f0:	011706b3          	add	a3,a4,a7
    20f4:	fff74713          	not	a4,a4
    20f8:	8f75                	and	a4,a4,a3
    20fa:	01077733          	and	a4,a4,a6
    20fe:	d37d                	beqz	a4,20e4 <memchr+0x52>
{
    2100:	853e                	mv	a0,a5
    2102:	97b2                	add	a5,a5,a2
    2104:	a021                	j	210c <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2106:	0505                	addi	a0,a0,1
    2108:	00f50763          	beq	a0,a5,2116 <memchr+0x84>
    210c:	00054703          	lbu	a4,0(a0)
    2110:	feb71be3          	bne	a4,a1,2106 <memchr+0x74>
    2114:	8082                	ret
	return n ? (void *)s : 0;
    2116:	4501                	li	a0,0
}
    2118:	8082                	ret
	return n ? (void *)s : 0;
    211a:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    211c:	f275                	bnez	a2,2100 <memchr+0x6e>
}
    211e:	8082                	ret

0000000000002120 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2120:	1101                	addi	sp,sp,-32
    2122:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2124:	862e                	mv	a2,a1
{
    2126:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2128:	4581                	li	a1,0
{
    212a:	e426                	sd	s1,8(sp)
    212c:	ec06                	sd	ra,24(sp)
    212e:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2130:	f63ff0ef          	jal	ra,2092 <memchr>
	return p ? p - s : n;
    2134:	c519                	beqz	a0,2142 <strnlen+0x22>
}
    2136:	60e2                	ld	ra,24(sp)
    2138:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    213a:	8d05                	sub	a0,a0,s1
}
    213c:	64a2                	ld	s1,8(sp)
    213e:	6105                	addi	sp,sp,32
    2140:	8082                	ret
    2142:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2144:	8522                	mv	a0,s0
}
    2146:	6442                	ld	s0,16(sp)
    2148:	64a2                	ld	s1,8(sp)
    214a:	6105                	addi	sp,sp,32
    214c:	8082                	ret

000000000000214e <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    214e:	00a5c7b3          	xor	a5,a1,a0
    2152:	8b9d                	andi	a5,a5,7
    2154:	eb95                	bnez	a5,2188 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2156:	0075f793          	andi	a5,a1,7
    215a:	e7b1                	bnez	a5,21a6 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    215c:	6198                	ld	a4,0(a1)
    215e:	00001617          	auipc	a2,0x1
    2162:	8ca63603          	ld	a2,-1846(a2) # 2a28 <enable_deadlock_detect+0x256>
    2166:	00001817          	auipc	a6,0x1
    216a:	8ca83803          	ld	a6,-1846(a6) # 2a30 <enable_deadlock_detect+0x25e>
    216e:	a029                	j	2178 <stpcpy+0x2a>
    2170:	05a1                	addi	a1,a1,8
    2172:	e118                	sd	a4,0(a0)
    2174:	6198                	ld	a4,0(a1)
    2176:	0521                	addi	a0,a0,8
    2178:	00c707b3          	add	a5,a4,a2
    217c:	fff74693          	not	a3,a4
    2180:	8ff5                	and	a5,a5,a3
    2182:	0107f7b3          	and	a5,a5,a6
    2186:	d7ed                	beqz	a5,2170 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2188:	0005c783          	lbu	a5,0(a1)
    218c:	00f50023          	sb	a5,0(a0)
    2190:	c785                	beqz	a5,21b8 <stpcpy+0x6a>
    2192:	0015c783          	lbu	a5,1(a1)
    2196:	0505                	addi	a0,a0,1
    2198:	0585                	addi	a1,a1,1
    219a:	00f50023          	sb	a5,0(a0)
    219e:	fbf5                	bnez	a5,2192 <stpcpy+0x44>
		;
	return d;
}
    21a0:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    21a2:	0505                	addi	a0,a0,1
    21a4:	df45                	beqz	a4,215c <stpcpy+0xe>
			if (!(*d = *s))
    21a6:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    21aa:	0585                	addi	a1,a1,1
    21ac:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    21b0:	00f50023          	sb	a5,0(a0)
    21b4:	f7fd                	bnez	a5,21a2 <stpcpy+0x54>
}
    21b6:	8082                	ret
    21b8:	8082                	ret

00000000000021ba <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    21ba:	00a5c7b3          	xor	a5,a1,a0
    21be:	8b9d                	andi	a5,a5,7
    21c0:	1a079863          	bnez	a5,2370 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    21c4:	0075f793          	andi	a5,a1,7
    21c8:	16078463          	beqz	a5,2330 <stpncpy+0x176>
    21cc:	ea01                	bnez	a2,21dc <stpncpy+0x22>
    21ce:	a421                	j	23d6 <stpncpy+0x21c>
    21d0:	167d                	addi	a2,a2,-1
    21d2:	0505                	addi	a0,a0,1
    21d4:	14070e63          	beqz	a4,2330 <stpncpy+0x176>
    21d8:	1a060863          	beqz	a2,2388 <stpncpy+0x1ce>
    21dc:	0005c783          	lbu	a5,0(a1)
    21e0:	0585                	addi	a1,a1,1
    21e2:	0075f713          	andi	a4,a1,7
    21e6:	00f50023          	sb	a5,0(a0)
    21ea:	f3fd                	bnez	a5,21d0 <stpncpy+0x16>
    21ec:	4805                	li	a6,1
    21ee:	1a061863          	bnez	a2,239e <stpncpy+0x1e4>
    21f2:	40a007b3          	neg	a5,a0
    21f6:	8b9d                	andi	a5,a5,7
    21f8:	4681                	li	a3,0
    21fa:	18061a63          	bnez	a2,238e <stpncpy+0x1d4>
    21fe:	00778713          	addi	a4,a5,7
    2202:	45ad                	li	a1,11
    2204:	18b76363          	bltu	a4,a1,238a <stpncpy+0x1d0>
    2208:	1ae6eb63          	bltu	a3,a4,23be <stpncpy+0x204>
    220c:	1a078363          	beqz	a5,23b2 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2210:	00050023          	sb	zero,0(a0)
    2214:	4685                	li	a3,1
    2216:	00150713          	addi	a4,a0,1
    221a:	18d78f63          	beq	a5,a3,23b8 <stpncpy+0x1fe>
    221e:	000500a3          	sb	zero,1(a0)
    2222:	4689                	li	a3,2
    2224:	00250713          	addi	a4,a0,2
    2228:	18d78e63          	beq	a5,a3,23c4 <stpncpy+0x20a>
    222c:	00050123          	sb	zero,2(a0)
    2230:	468d                	li	a3,3
    2232:	00350713          	addi	a4,a0,3
    2236:	16d78c63          	beq	a5,a3,23ae <stpncpy+0x1f4>
    223a:	000501a3          	sb	zero,3(a0)
    223e:	4691                	li	a3,4
    2240:	00450713          	addi	a4,a0,4
    2244:	18d78263          	beq	a5,a3,23c8 <stpncpy+0x20e>
    2248:	00050223          	sb	zero,4(a0)
    224c:	4695                	li	a3,5
    224e:	00550713          	addi	a4,a0,5
    2252:	16d78d63          	beq	a5,a3,23cc <stpncpy+0x212>
    2256:	000502a3          	sb	zero,5(a0)
    225a:	469d                	li	a3,7
    225c:	00650713          	addi	a4,a0,6
    2260:	16d79863          	bne	a5,a3,23d0 <stpncpy+0x216>
    2264:	00750713          	addi	a4,a0,7
    2268:	00050323          	sb	zero,6(a0)
    226c:	40f80833          	sub	a6,a6,a5
    2270:	ff887593          	andi	a1,a6,-8
    2274:	97aa                	add	a5,a5,a0
    2276:	95be                	add	a1,a1,a5
    2278:	0007b023          	sd	zero,0(a5)
    227c:	07a1                	addi	a5,a5,8
    227e:	feb79de3          	bne	a5,a1,2278 <stpncpy+0xbe>
    2282:	ff887593          	andi	a1,a6,-8
    2286:	9ead                	addw	a3,a3,a1
    2288:	00b707b3          	add	a5,a4,a1
    228c:	12b80863          	beq	a6,a1,23bc <stpncpy+0x202>
    2290:	00078023          	sb	zero,0(a5)
    2294:	0016871b          	addiw	a4,a3,1
    2298:	0ec77863          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    229c:	000780a3          	sb	zero,1(a5)
    22a0:	0026871b          	addiw	a4,a3,2
    22a4:	0ec77263          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22a8:	00078123          	sb	zero,2(a5)
    22ac:	0036871b          	addiw	a4,a3,3
    22b0:	0cc77c63          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22b4:	000781a3          	sb	zero,3(a5)
    22b8:	0046871b          	addiw	a4,a3,4
    22bc:	0cc77663          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22c0:	00078223          	sb	zero,4(a5)
    22c4:	0056871b          	addiw	a4,a3,5
    22c8:	0cc77063          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22cc:	000782a3          	sb	zero,5(a5)
    22d0:	0066871b          	addiw	a4,a3,6
    22d4:	0ac77a63          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22d8:	00078323          	sb	zero,6(a5)
    22dc:	0076871b          	addiw	a4,a3,7
    22e0:	0ac77463          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22e4:	000783a3          	sb	zero,7(a5)
    22e8:	0086871b          	addiw	a4,a3,8
    22ec:	08c77e63          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22f0:	00078423          	sb	zero,8(a5)
    22f4:	0096871b          	addiw	a4,a3,9
    22f8:	08c77863          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    22fc:	000784a3          	sb	zero,9(a5)
    2300:	00a6871b          	addiw	a4,a3,10
    2304:	08c77263          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    2308:	00078523          	sb	zero,10(a5)
    230c:	00b6871b          	addiw	a4,a3,11
    2310:	06c77c63          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    2314:	000785a3          	sb	zero,11(a5)
    2318:	00c6871b          	addiw	a4,a3,12
    231c:	06c77663          	bgeu	a4,a2,2388 <stpncpy+0x1ce>
    2320:	00078623          	sb	zero,12(a5)
    2324:	26b5                	addiw	a3,a3,13
    2326:	06c6f163          	bgeu	a3,a2,2388 <stpncpy+0x1ce>
    232a:	000786a3          	sb	zero,13(a5)
    232e:	8082                	ret
			;
		if (!n || !*s)
    2330:	c645                	beqz	a2,23d8 <stpncpy+0x21e>
    2332:	0005c783          	lbu	a5,0(a1)
    2336:	ea078be3          	beqz	a5,21ec <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    233a:	479d                	li	a5,7
    233c:	02c7ff63          	bgeu	a5,a2,237a <stpncpy+0x1c0>
    2340:	00000897          	auipc	a7,0x0
    2344:	6e88b883          	ld	a7,1768(a7) # 2a28 <enable_deadlock_detect+0x256>
    2348:	00000817          	auipc	a6,0x0
    234c:	6e883803          	ld	a6,1768(a6) # 2a30 <enable_deadlock_detect+0x25e>
    2350:	431d                	li	t1,7
    2352:	6198                	ld	a4,0(a1)
    2354:	011707b3          	add	a5,a4,a7
    2358:	fff74693          	not	a3,a4
    235c:	8ff5                	and	a5,a5,a3
    235e:	0107f7b3          	and	a5,a5,a6
    2362:	ef81                	bnez	a5,237a <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2364:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2366:	1661                	addi	a2,a2,-8
    2368:	05a1                	addi	a1,a1,8
    236a:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    236c:	fec363e3          	bltu	t1,a2,2352 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2370:	e609                	bnez	a2,237a <stpncpy+0x1c0>
    2372:	a08d                	j	23d4 <stpncpy+0x21a>
    2374:	167d                	addi	a2,a2,-1
    2376:	0505                	addi	a0,a0,1
    2378:	ca01                	beqz	a2,2388 <stpncpy+0x1ce>
    237a:	0005c783          	lbu	a5,0(a1)
    237e:	0585                	addi	a1,a1,1
    2380:	00f50023          	sb	a5,0(a0)
    2384:	fbe5                	bnez	a5,2374 <stpncpy+0x1ba>
		;
tail:
    2386:	b59d                	j	21ec <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2388:	8082                	ret
    238a:	472d                	li	a4,11
    238c:	bdb5                	j	2208 <stpncpy+0x4e>
    238e:	00778713          	addi	a4,a5,7
    2392:	45ad                	li	a1,11
    2394:	fff60693          	addi	a3,a2,-1
    2398:	e6b778e3          	bgeu	a4,a1,2208 <stpncpy+0x4e>
    239c:	b7fd                	j	238a <stpncpy+0x1d0>
    239e:	40a007b3          	neg	a5,a0
    23a2:	8832                	mv	a6,a2
    23a4:	8b9d                	andi	a5,a5,7
    23a6:	4681                	li	a3,0
    23a8:	e4060be3          	beqz	a2,21fe <stpncpy+0x44>
    23ac:	b7cd                	j	238e <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23ae:	468d                	li	a3,3
    23b0:	bd75                	j	226c <stpncpy+0xb2>
    23b2:	872a                	mv	a4,a0
    23b4:	4681                	li	a3,0
    23b6:	bd5d                	j	226c <stpncpy+0xb2>
    23b8:	4685                	li	a3,1
    23ba:	bd4d                	j	226c <stpncpy+0xb2>
    23bc:	8082                	ret
    23be:	87aa                	mv	a5,a0
    23c0:	4681                	li	a3,0
    23c2:	b5f9                	j	2290 <stpncpy+0xd6>
    23c4:	4689                	li	a3,2
    23c6:	b55d                	j	226c <stpncpy+0xb2>
    23c8:	4691                	li	a3,4
    23ca:	b54d                	j	226c <stpncpy+0xb2>
    23cc:	4695                	li	a3,5
    23ce:	bd79                	j	226c <stpncpy+0xb2>
    23d0:	4699                	li	a3,6
    23d2:	bd69                	j	226c <stpncpy+0xb2>
    23d4:	8082                	ret
    23d6:	8082                	ret
    23d8:	8082                	ret

00000000000023da <basename>:

char *basename(char *s)
{
    23da:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    23dc:	c54d                	beqz	a0,2486 <basename+0xac>
    23de:	00054783          	lbu	a5,0(a0)
		return ".";
    23e2:	00000517          	auipc	a0,0x0
    23e6:	63e50513          	addi	a0,a0,1598 # 2a20 <enable_deadlock_detect+0x24e>
	if (!s || !*s)
    23ea:	e391                	bnez	a5,23ee <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    23ec:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23ee:	0076f713          	andi	a4,a3,7
    23f2:	87b6                	mv	a5,a3
    23f4:	cf51                	beqz	a4,2490 <basename+0xb6>
    23f6:	0785                	addi	a5,a5,1
    23f8:	0077f713          	andi	a4,a5,7
    23fc:	c729                	beqz	a4,2446 <basename+0x6c>
		if (!*s)
    23fe:	0007c703          	lbu	a4,0(a5)
    2402:	fb75                	bnez	a4,23f6 <basename+0x1c>
	return s - a;
    2404:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2406:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2408:	cf8d                	beqz	a5,2442 <basename+0x68>
    240a:	00f68733          	add	a4,a3,a5
    240e:	02f00593          	li	a1,47
    2412:	a031                	j	241e <basename+0x44>
		s[i] = 0;
    2414:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2418:	17fd                	addi	a5,a5,-1
    241a:	177d                	addi	a4,a4,-1
    241c:	c39d                	beqz	a5,2442 <basename+0x68>
    241e:	00074603          	lbu	a2,0(a4)
    2422:	feb609e3          	beq	a2,a1,2414 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2426:	02f00613          	li	a2,47
    242a:	a011                	j	242e <basename+0x54>
    242c:	cb99                	beqz	a5,2442 <basename+0x68>
    242e:	853e                	mv	a0,a5
    2430:	17fd                	addi	a5,a5,-1
    2432:	00f68733          	add	a4,a3,a5
    2436:	00074703          	lbu	a4,0(a4)
    243a:	fec719e3          	bne	a4,a2,242c <basename+0x52>
	return s + i;
    243e:	9536                	add	a0,a0,a3
    2440:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2442:	8536                	mv	a0,a3
    2444:	8082                	ret
    2446:	6390                	ld	a2,0(a5)
    2448:	00000517          	auipc	a0,0x0
    244c:	5e053503          	ld	a0,1504(a0) # 2a28 <enable_deadlock_detect+0x256>
    2450:	00000597          	auipc	a1,0x0
    2454:	5e05b583          	ld	a1,1504(a1) # 2a30 <enable_deadlock_detect+0x25e>
    2458:	fff64713          	not	a4,a2
    245c:	962a                	add	a2,a2,a0
    245e:	8f71                	and	a4,a4,a2
    2460:	8f6d                	and	a4,a4,a1
    2462:	eb11                	bnez	a4,2476 <basename+0x9c>
    2464:	6790                	ld	a2,8(a5)
    2466:	07a1                	addi	a5,a5,8
    2468:	00a60733          	add	a4,a2,a0
    246c:	fff64613          	not	a2,a2
    2470:	8f71                	and	a4,a4,a2
    2472:	8f6d                	and	a4,a4,a1
    2474:	db65                	beqz	a4,2464 <basename+0x8a>
	for (; *s; s++)
    2476:	0007c703          	lbu	a4,0(a5)
    247a:	d749                	beqz	a4,2404 <basename+0x2a>
    247c:	0017c703          	lbu	a4,1(a5)
    2480:	0785                	addi	a5,a5,1
    2482:	ff6d                	bnez	a4,247c <basename+0xa2>
    2484:	b741                	j	2404 <basename+0x2a>
		return ".";
    2486:	00000517          	auipc	a0,0x0
    248a:	59a50513          	addi	a0,a0,1434 # 2a20 <enable_deadlock_detect+0x24e>
    248e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2490:	6290                	ld	a2,0(a3)
    2492:	00000517          	auipc	a0,0x0
    2496:	59653503          	ld	a0,1430(a0) # 2a28 <enable_deadlock_detect+0x256>
    249a:	00000597          	auipc	a1,0x0
    249e:	5965b583          	ld	a1,1430(a1) # 2a30 <enable_deadlock_detect+0x25e>
    24a2:	fff64713          	not	a4,a2
    24a6:	962a                	add	a2,a2,a0
    24a8:	8f71                	and	a4,a4,a2
    24aa:	8f6d                	and	a4,a4,a1
    24ac:	df45                	beqz	a4,2464 <basename+0x8a>
    24ae:	b7f9                	j	247c <basename+0xa2>

00000000000024b0 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    24b0:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    24b4:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24b6:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    24ba:	2501                	sext.w	a0,a0
    24bc:	8082                	ret

00000000000024be <close>:

int close(int fd)
{
	if (fd == 1) {
    24be:	4785                	li	a5,1
    24c0:	00f50863          	beq	a0,a5,24d0 <close+0x12>
	register long a7 __asm__("a7") = n;
    24c4:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24c8:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    24cc:	2501                	sext.w	a0,a0
    24ce:	8082                	ret
{
    24d0:	1101                	addi	sp,sp,-32
    24d2:	ec06                	sd	ra,24(sp)
    24d4:	e42a                	sd	a0,8(sp)
		__write_buffer();
    24d6:	cdffe0ef          	jal	ra,11b4 <__write_buffer>
		__clear_buffer();
    24da:	d03fe0ef          	jal	ra,11dc <__clear_buffer>
    24de:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    24e0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24e4:	00000073          	ecall
}
    24e8:	60e2                	ld	ra,24(sp)
    24ea:	2501                	sext.w	a0,a0
    24ec:	6105                	addi	sp,sp,32
    24ee:	8082                	ret

00000000000024f0 <read>:
	register long a7 __asm__("a7") = n;
    24f0:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24f4:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24f8:	8082                	ret

00000000000024fa <write>:
	register long a7 __asm__("a7") = n;
    24fa:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24fe:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2502:	8082                	ret

0000000000002504 <getpid>:
	register long a7 __asm__("a7") = n;
    2504:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2508:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    250c:	2501                	sext.w	a0,a0
    250e:	8082                	ret

0000000000002510 <getppid>:
	register long a7 __asm__("a7") = n;
    2510:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2514:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2518:	2501                	sext.w	a0,a0
    251a:	8082                	ret

000000000000251c <sched_yield>:
	register long a7 __asm__("a7") = n;
    251c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2520:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2524:	2501                	sext.w	a0,a0
    2526:	8082                	ret

0000000000002528 <fork>:
	register long a7 __asm__("a7") = n;
    2528:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    252c:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2530:	2501                	sext.w	a0,a0
    2532:	8082                	ret

0000000000002534 <exit>:

void exit(int code)
{
    2534:	1141                	addi	sp,sp,-16
    2536:	e406                	sd	ra,8(sp)
    2538:	e022                	sd	s0,0(sp)
    253a:	842a                	mv	s0,a0
	__write_buffer();
    253c:	c79fe0ef          	jal	ra,11b4 <__write_buffer>
	__clear_buffer();
    2540:	c9dfe0ef          	jal	ra,11dc <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2544:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2548:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    254a:	00000073          	ecall
	syscall(SYS_exit, code);
}
    254e:	60a2                	ld	ra,8(sp)
    2550:	6402                	ld	s0,0(sp)
    2552:	0141                	addi	sp,sp,16
    2554:	8082                	ret

0000000000002556 <waitpid>:
	register long a7 __asm__("a7") = n;
    2556:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    255a:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    255e:	2501                	sext.w	a0,a0
    2560:	8082                	ret

0000000000002562 <exec>:
	register long a7 __asm__("a7") = n;
    2562:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2566:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    256a:	2501                	sext.w	a0,a0
    256c:	8082                	ret

000000000000256e <get_mtime>:

int64 get_mtime()
{
    256e:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2570:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2574:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2576:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2578:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    257c:	2501                	sext.w	a0,a0
    257e:	ed01                	bnez	a0,2596 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2580:	6722                	ld	a4,8(sp)
    2582:	3e800793          	li	a5,1000
    2586:	6682                	ld	a3,0(sp)
    2588:	02f75733          	divu	a4,a4,a5
    258c:	02d78533          	mul	a0,a5,a3
    2590:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    2592:	0141                	addi	sp,sp,16
    2594:	8082                	ret
	return -1;
    2596:	557d                	li	a0,-1
    2598:	bfed                	j	2592 <get_mtime+0x24>

000000000000259a <sys_get_time>:
	register long a7 __asm__("a7") = n;
    259a:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259e:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <sleep>:

int sleep(unsigned long long time)
{
    25a6:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    25a8:	880a                	mv	a6,sp
{
    25aa:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    25ac:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25b0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25b2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25b4:	00000073          	ecall
	if (err == 0) {
    25b8:	2501                	sext.w	a0,a0
    25ba:	ed31                	bnez	a0,2616 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    25bc:	6722                	ld	a4,8(sp)
    25be:	3e800793          	li	a5,1000
    25c2:	6682                	ld	a3,0(sp)
    25c4:	02f75733          	divu	a4,a4,a5
    25c8:	02d787b3          	mul	a5,a5,a3
    25cc:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    25ce:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25d2:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25d4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25d6:	00000073          	ecall
	if (err == 0) {
    25da:	2501                	sext.w	a0,a0
    25dc:	e915                	bnez	a0,2610 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    25de:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    25e0:	3e800693          	li	a3,1000
    25e4:	a819                	j	25fa <sleep+0x54>
	__asm_syscall("r"(a7))
    25e6:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25ea:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25ee:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25f0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25f2:	00000073          	ecall
	if (err == 0) {
    25f6:	2501                	sext.w	a0,a0
    25f8:	ed01                	bnez	a0,2610 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25fa:	6722                	ld	a4,8(sp)
    25fc:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25fe:	07c00893          	li	a7,124
    2602:	02d75733          	divu	a4,a4,a3
    2606:	02f687b3          	mul	a5,a3,a5
    260a:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    260c:	fcc7ede3          	bltu	a5,a2,25e6 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2610:	4501                	li	a0,0
    2612:	0141                	addi	sp,sp,16
    2614:	8082                	ret
    2616:	57fd                	li	a5,-1
    2618:	bf5d                	j	25ce <sleep+0x28>

000000000000261a <sys_task_info>:
	register long a7 __asm__("a7") = n;
    261a:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    261e:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2622:	2501                	sext.w	a0,a0
    2624:	8082                	ret

0000000000002626 <set_priority>:
	register long a7 __asm__("a7") = n;
    2626:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    262a:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    262e:	2501                	sext.w	a0,a0
    2630:	8082                	ret

0000000000002632 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2632:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2636:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    263a:	2501                	sext.w	a0,a0
    263c:	8082                	ret

000000000000263e <munmap>:
	register long a7 __asm__("a7") = n;
    263e:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2642:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret

000000000000264a <wait>:

int wait(int *code)
{
    264a:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    264c:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2650:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2652:	00000073          	ecall
	return waitpid(-1, code);
}
    2656:	2501                	sext.w	a0,a0
    2658:	8082                	ret

000000000000265a <spawn>:
	register long a7 __asm__("a7") = n;
    265a:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    265e:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2662:	2501                	sext.w	a0,a0
    2664:	8082                	ret

0000000000002666 <pipe>:
	register long a7 __asm__("a7") = n;
    2666:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    266a:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    266e:	2501                	sext.w	a0,a0
    2670:	8082                	ret

0000000000002672 <mailread>:
	register long a7 __asm__("a7") = n;
    2672:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2676:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    267a:	2501                	sext.w	a0,a0
    267c:	8082                	ret

000000000000267e <mailwrite>:
	register long a7 __asm__("a7") = n;
    267e:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2682:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2686:	2501                	sext.w	a0,a0
    2688:	8082                	ret

000000000000268a <fstat>:
	register long a7 __asm__("a7") = n;
    268a:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    268e:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    2692:	2501                	sext.w	a0,a0
    2694:	8082                	ret

0000000000002696 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2696:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2698:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    269c:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    269e:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    26a6:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    26a8:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    26ac:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26ae:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    26b2:	2501                	sext.w	a0,a0
    26b4:	8082                	ret

00000000000026b6 <link>:

int link(char *old_path, char *new_path)
{
    26b6:	87aa                	mv	a5,a0
    26b8:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    26ba:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    26be:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    26c2:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    26c4:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    26c8:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26ca:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    26ce:	2501                	sext.w	a0,a0
    26d0:	8082                	ret

00000000000026d2 <unlink>:

int unlink(char *path)
{
    26d2:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26d4:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    26d8:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    26dc:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26de:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    26e2:	2501                	sext.w	a0,a0
    26e4:	8082                	ret

00000000000026e6 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    26e6:	00000797          	auipc	a5,0x0
    26ea:	4a27b783          	ld	a5,1186(a5) # 2b88 <_GLOBAL_OFFSET_TABLE_+0x8>
    26ee:	439c                	lw	a5,0(a5)
    26f0:	c799                	beqz	a5,26fe <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    26f2:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26f6:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26fa:	2501                	sext.w	a0,a0
    26fc:	8082                	ret
{
    26fe:	1101                	addi	sp,sp,-32
    2700:	ec06                	sd	ra,24(sp)
    2702:	e42e                	sd	a1,8(sp)
    2704:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2706:	fe7fe0ef          	jal	ra,16ec <enable_thread_io_buffer>
    270a:	65a2                	ld	a1,8(sp)
    270c:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    270e:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2712:	00000073          	ecall
}
    2716:	60e2                	ld	ra,24(sp)
    2718:	2501                	sext.w	a0,a0
    271a:	6105                	addi	sp,sp,32
    271c:	8082                	ret

000000000000271e <gettid>:
	register long a7 __asm__("a7") = n;
    271e:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2722:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2726:	2501                	sext.w	a0,a0
    2728:	8082                	ret

000000000000272a <waittid>:

int waittid(int tid)
{
    272a:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    272c:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2730:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2734:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2736:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2738:	00e51e63          	bne	a0,a4,2754 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    273c:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2740:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2744:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2748:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    274a:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    274e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2750:	fee506e3          	beq	a0,a4,273c <waittid+0x12>
	}
	return ret;
}
    2754:	8082                	ret

0000000000002756 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2756:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    275a:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    275c:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2760:	2501                	sext.w	a0,a0
    2762:	8082                	ret

0000000000002764 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2764:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2768:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    276a:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    276e:	2501                	sext.w	a0,a0
    2770:	8082                	ret

0000000000002772 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2772:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2776:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    277a:	2501                	sext.w	a0,a0
    277c:	8082                	ret

000000000000277e <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    277e:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2782:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2786:	2501                	sext.w	a0,a0
    2788:	8082                	ret

000000000000278a <semaphore_create>:
	register long a7 __asm__("a7") = n;
    278a:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    278e:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    2792:	2501                	sext.w	a0,a0
    2794:	8082                	ret

0000000000002796 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2796:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    279a:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    279e:	2501                	sext.w	a0,a0
    27a0:	8082                	ret

00000000000027a2 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    27a2:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    27a6:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    27aa:	2501                	sext.w	a0,a0
    27ac:	8082                	ret

00000000000027ae <condvar_create>:
	register long a7 __asm__("a7") = n;
    27ae:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    27b2:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    27b6:	2501                	sext.w	a0,a0
    27b8:	8082                	ret

00000000000027ba <condvar_signal>:
	register long a7 __asm__("a7") = n;
    27ba:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    27be:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    27c2:	2501                	sext.w	a0,a0
    27c4:	8082                	ret

00000000000027c6 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    27c6:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27ca:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    27ce:	2501                	sext.w	a0,a0
    27d0:	8082                	ret

00000000000027d2 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    27d2:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    27d6:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    27da:	2501                	sext.w	a0,a0
    27dc:	8082                	ret
