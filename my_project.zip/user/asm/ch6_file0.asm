
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6_file0:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a295                	j	1164 <__start_main>

0000000000001002 <main>:
#include <unistd.h>

/// 测试文件基本读写，输出　Test file0 OK! 就算正确。

int main()
{
    1002:	7175                	addi	sp,sp,-144
	char *test_str = "Hello, world!";
	char *fname = "fname";
	int fd = open(fname, O_CREATE | O_WRONLY);
    1004:	20100593          	li	a1,513
    1008:	00001517          	auipc	a0,0x1
    100c:	7c850513          	addi	a0,a0,1992 # 27d0 <enable_deadlock_detect+0x12>
{
    1010:	e122                	sd	s0,128(sp)
    1012:	e506                	sd	ra,136(sp)
    1014:	fca6                	sd	s1,120(sp)
    1016:	f8ca                	sd	s2,112(sp)
	int fd = open(fname, O_CREATE | O_WRONLY);
    1018:	484010ef          	jal	ra,249c <open>
    101c:	842a                	mv	s0,a0
	assert(fd > 0);
    101e:	10a05863          	blez	a0,112e <main+0x12c>
	write(fd, test_str, strlen(test_str));
    1022:	00002517          	auipc	a0,0x2
    1026:	83650513          	addi	a0,a0,-1994 # 2858 <enable_deadlock_detect+0x9a>
    102a:	7f7000ef          	jal	ra,2020 <strlen>
    102e:	862a                	mv	a2,a0
    1030:	00002597          	auipc	a1,0x2
    1034:	82858593          	addi	a1,a1,-2008 # 2858 <enable_deadlock_detect+0x9a>
    1038:	8522                	mv	a0,s0
    103a:	4ac010ef          	jal	ra,24e6 <write>
	close(fd);
    103e:	8522                	mv	a0,s0
    1040:	46a010ef          	jal	ra,24aa <close>

	fd = open(fname, O_RDONLY);
    1044:	4581                	li	a1,0
    1046:	00001517          	auipc	a0,0x1
    104a:	78a50513          	addi	a0,a0,1930 # 27d0 <enable_deadlock_detect+0x12>
    104e:	44e010ef          	jal	ra,249c <open>
    1052:	84aa                	mv	s1,a0
	assert(fd > 0);
    1054:	0aa05263          	blez	a0,10f8 <main+0xf6>

	char buffer[100];
	memset(buffer, 0, sizeof(buffer));
    1058:	00810913          	addi	s2,sp,8
    105c:	06400613          	li	a2,100
    1060:	4581                	li	a1,0
    1062:	854a                	mv	a0,s2
    1064:	5af000ef          	jal	ra,1e12 <memset>
	int read_len = read(fd, &buffer, sizeof(buffer));
    1068:	06400613          	li	a2,100
    106c:	85ca                	mv	a1,s2
    106e:	8526                	mv	a0,s1
    1070:	46c010ef          	jal	ra,24dc <read>
    1074:	842a                	mv	s0,a0
	close(fd);
    1076:	8526                	mv	a0,s1
    1078:	432010ef          	jal	ra,24aa <close>

	assert_eq(strncmp(buffer, test_str, read_len), 0);
    107c:	2401                	sext.w	s0,s0
    107e:	8622                	mv	a2,s0
    1080:	00001597          	auipc	a1,0x1
    1084:	7d858593          	addi	a1,a1,2008 # 2858 <enable_deadlock_detect+0x9a>
    1088:	854a                	mv	a0,s2
    108a:	74d000ef          	jal	ra,1fd6 <strncmp>
    108e:	ed11                	bnez	a0,10aa <main+0xa8>
	puts("Test file0 OK!");
    1090:	00002517          	auipc	a0,0x2
    1094:	81050513          	addi	a0,a0,-2032 # 28a0 <enable_deadlock_detect+0xe2>
    1098:	13d000ef          	jal	ra,19d4 <puts>
	return 0;
    109c:	60aa                	ld	ra,136(sp)
    109e:	640a                	ld	s0,128(sp)
    10a0:	74e6                	ld	s1,120(sp)
    10a2:	7946                	ld	s2,112(sp)
    10a4:	4501                	li	a0,0
    10a6:	6149                	addi	sp,sp,144
    10a8:	8082                	ret
	assert_eq(strncmp(buffer, test_str, read_len), 0);
    10aa:	446010ef          	jal	ra,24f0 <getpid>
    10ae:	84aa                	mv	s1,a0
    10b0:	00001517          	auipc	a0,0x1
    10b4:	72850513          	addi	a0,a0,1832 # 27d8 <enable_deadlock_detect+0x1a>
    10b8:	30e010ef          	jal	ra,23c6 <basename>
    10bc:	872a                	mv	a4,a0
    10be:	8622                	mv	a2,s0
    10c0:	00001597          	auipc	a1,0x1
    10c4:	79858593          	addi	a1,a1,1944 # 2858 <enable_deadlock_detect+0x9a>
    10c8:	854a                	mv	a0,s2
    10ca:	843a                	mv	s0,a4
    10cc:	70b000ef          	jal	ra,1fd6 <strncmp>
    10d0:	882a                	mv	a6,a0
    10d2:	4881                	li	a7,0
    10d4:	00001517          	auipc	a0,0x1
    10d8:	79450513          	addi	a0,a0,1940 # 2868 <enable_deadlock_detect+0xaa>
    10dc:	47e9                	li	a5,26
    10de:	8722                	mv	a4,s0
    10e0:	86a6                	mv	a3,s1
    10e2:	00001617          	auipc	a2,0x1
    10e6:	73e60613          	addi	a2,a2,1854 # 2820 <enable_deadlock_detect+0x62>
    10ea:	45fd                	li	a1,31
    10ec:	1d2000ef          	jal	ra,12be <printf>
    10f0:	557d                	li	a0,-1
    10f2:	42e010ef          	jal	ra,2520 <exit>
    10f6:	bf69                	j	1090 <main+0x8e>
	assert(fd > 0);
    10f8:	3f8010ef          	jal	ra,24f0 <getpid>
    10fc:	842a                	mv	s0,a0
    10fe:	00001517          	auipc	a0,0x1
    1102:	6da50513          	addi	a0,a0,1754 # 27d8 <enable_deadlock_detect+0x1a>
    1106:	2c0010ef          	jal	ra,23c6 <basename>
    110a:	872a                	mv	a4,a0
    110c:	47cd                	li	a5,19
    110e:	00001517          	auipc	a0,0x1
    1112:	71a50513          	addi	a0,a0,1818 # 2828 <enable_deadlock_detect+0x6a>
    1116:	86a2                	mv	a3,s0
    1118:	00001617          	auipc	a2,0x1
    111c:	70860613          	addi	a2,a2,1800 # 2820 <enable_deadlock_detect+0x62>
    1120:	45fd                	li	a1,31
    1122:	19c000ef          	jal	ra,12be <printf>
    1126:	557d                	li	a0,-1
    1128:	3f8010ef          	jal	ra,2520 <exit>
    112c:	b735                	j	1058 <main+0x56>
	assert(fd > 0);
    112e:	3c2010ef          	jal	ra,24f0 <getpid>
    1132:	84aa                	mv	s1,a0
    1134:	00001517          	auipc	a0,0x1
    1138:	6a450513          	addi	a0,a0,1700 # 27d8 <enable_deadlock_detect+0x1a>
    113c:	28a010ef          	jal	ra,23c6 <basename>
    1140:	872a                	mv	a4,a0
    1142:	47b9                	li	a5,14
    1144:	00001517          	auipc	a0,0x1
    1148:	6e450513          	addi	a0,a0,1764 # 2828 <enable_deadlock_detect+0x6a>
    114c:	86a6                	mv	a3,s1
    114e:	00001617          	auipc	a2,0x1
    1152:	6d260613          	addi	a2,a2,1746 # 2820 <enable_deadlock_detect+0x62>
    1156:	45fd                	li	a1,31
    1158:	166000ef          	jal	ra,12be <printf>
    115c:	557d                	li	a0,-1
    115e:	3c2010ef          	jal	ra,2520 <exit>
    1162:	b5c1                	j	1022 <main+0x20>

0000000000001164 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1164:	1141                	addi	sp,sp,-16
    1166:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1168:	e9bff0ef          	jal	ra,1002 <main>
    116c:	3b4010ef          	jal	ra,2520 <exit>
	return 0;
    1170:	60a2                	ld	ra,8(sp)
    1172:	4501                	li	a0,0
    1174:	0141                	addi	sp,sp,16
    1176:	8082                	ret

0000000000001178 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1178:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    117a:	4605                	li	a2,1
    117c:	00f10593          	addi	a1,sp,15
    1180:	4501                	li	a0,0
{
    1182:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1184:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1188:	354010ef          	jal	ra,24dc <read>
    118c:	4785                	li	a5,1
    118e:	00f51763          	bne	a0,a5,119c <getchar+0x24>
		return byte;
    1192:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1196:	60e2                	ld	ra,24(sp)
    1198:	6105                	addi	sp,sp,32
    119a:	8082                	ret
		return EOF;
    119c:	557d                	li	a0,-1
    119e:	bfe5                	j	1196 <getchar+0x1e>

00000000000011a0 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    11a0:	00002517          	auipc	a0,0x2
    11a4:	80852503          	lw	a0,-2040(a0) # 29a8 <buffer_len>
    11a8:	e111                	bnez	a0,11ac <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    11aa:	8082                	ret
{
    11ac:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11ae:	862a                	mv	a2,a0
    11b0:	00002597          	auipc	a1,0x2
    11b4:	80058593          	addi	a1,a1,-2048 # 29b0 <buffer>
    11b8:	4505                	li	a0,1
{
    11ba:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11bc:	32a010ef          	jal	ra,24e6 <write>
}
    11c0:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11c2:	2501                	sext.w	a0,a0
}
    11c4:	0141                	addi	sp,sp,16
    11c6:	8082                	ret

00000000000011c8 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    11c8:	00001797          	auipc	a5,0x1
    11cc:	7e07a023          	sw	zero,2016(a5) # 29a8 <buffer_len>
}
    11d0:	8082                	ret

00000000000011d2 <__fflush>:
	if (buffer_len == 0)
    11d2:	00001517          	auipc	a0,0x1
    11d6:	7d652503          	lw	a0,2006(a0) # 29a8 <buffer_len>
    11da:	e511                	bnez	a0,11e6 <__fflush+0x14>
	buffer_len = 0;
    11dc:	00001797          	auipc	a5,0x1
    11e0:	7c07a623          	sw	zero,1996(a5) # 29a8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    11e4:	8082                	ret
{
    11e6:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    11e8:	862a                	mv	a2,a0
    11ea:	00001597          	auipc	a1,0x1
    11ee:	7c658593          	addi	a1,a1,1990 # 29b0 <buffer>
    11f2:	4505                	li	a0,1
{
    11f4:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    11f6:	2f0010ef          	jal	ra,24e6 <write>
	return r >= 0 ? 0 : r;
    11fa:	0005079b          	sext.w	a5,a0
}
    11fe:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1200:	0017a793          	slti	a5,a5,1
    1204:	40f007bb          	negw	a5,a5
    1208:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    120a:	00001797          	auipc	a5,0x1
    120e:	7807af23          	sw	zero,1950(a5) # 29a8 <buffer_len>
	return r >= 0 ? 0 : r;
    1212:	2501                	sext.w	a0,a0
}
    1214:	0141                	addi	sp,sp,16
    1216:	8082                	ret

0000000000001218 <fflush>:

int fflush(int fd)
{
    1218:	1101                	addi	sp,sp,-32
    121a:	e822                	sd	s0,16(sp)
    121c:	ec06                	sd	ra,24(sp)
    121e:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1220:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1222:	4401                	li	s0,0
	if (fd == 1) {
    1224:	00e50863          	beq	a0,a4,1234 <fflush+0x1c>
}
    1228:	60e2                	ld	ra,24(sp)
    122a:	8522                	mv	a0,s0
    122c:	6442                	ld	s0,16(sp)
    122e:	64a2                	ld	s1,8(sp)
    1230:	6105                	addi	sp,sp,32
    1232:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1234:	00001497          	auipc	s1,0x1
    1238:	77448493          	addi	s1,s1,1908 # 29a8 <buffer_len>
    123c:	1084a703          	lw	a4,264(s1)
    1240:	02a70e63          	beq	a4,a0,127c <fflush+0x64>
	if (buffer_len == 0)
    1244:	4080                	lw	s0,0(s1)
    1246:	c00d                	beqz	s0,1268 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1248:	8622                	mv	a2,s0
    124a:	00001597          	auipc	a1,0x1
    124e:	76658593          	addi	a1,a1,1894 # 29b0 <buffer>
    1252:	294010ef          	jal	ra,24e6 <write>
	return r >= 0 ? 0 : r;
    1256:	0005079b          	sext.w	a5,a0
    125a:	0017a793          	slti	a5,a5,1
    125e:	40f007bb          	negw	a5,a5
    1262:	8d7d                	and	a0,a0,a5
    1264:	0005041b          	sext.w	s0,a0
}
    1268:	60e2                	ld	ra,24(sp)
    126a:	8522                	mv	a0,s0
    126c:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    126e:	00001797          	auipc	a5,0x1
    1272:	7207ad23          	sw	zero,1850(a5) # 29a8 <buffer_len>
}
    1276:	64a2                	ld	s1,8(sp)
    1278:	6105                	addi	sp,sp,32
    127a:	8082                	ret
			mutex_lock(buffer_lock);
    127c:	10c4a503          	lw	a0,268(s1)
    1280:	4de010ef          	jal	ra,275e <mutex_lock>
	if (buffer_len == 0)
    1284:	4080                	lw	s0,0(s1)
    1286:	e811                	bnez	s0,129a <fflush+0x82>
			mutex_unlock(buffer_lock);
    1288:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    128c:	00001797          	auipc	a5,0x1
    1290:	7007ae23          	sw	zero,1820(a5) # 29a8 <buffer_len>
			mutex_unlock(buffer_lock);
    1294:	4d6010ef          	jal	ra,276a <mutex_unlock>
    1298:	bf41                	j	1228 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    129a:	8622                	mv	a2,s0
    129c:	00001597          	auipc	a1,0x1
    12a0:	71458593          	addi	a1,a1,1812 # 29b0 <buffer>
    12a4:	4505                	li	a0,1
    12a6:	240010ef          	jal	ra,24e6 <write>
	return r >= 0 ? 0 : r;
    12aa:	0005079b          	sext.w	a5,a0
    12ae:	0017a793          	slti	a5,a5,1
    12b2:	40f007bb          	negw	a5,a5
    12b6:	8d7d                	and	a0,a0,a5
    12b8:	0005041b          	sext.w	s0,a0
	return r;
    12bc:	b7f1                	j	1288 <fflush+0x70>

00000000000012be <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    12be:	7131                	addi	sp,sp,-192
    12c0:	e0da                	sd	s6,64(sp)
    12c2:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    12c4:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    12c6:	013c                	addi	a5,sp,136
{
    12c8:	f0ca                	sd	s2,96(sp)
    12ca:	ecce                	sd	s3,88(sp)
    12cc:	e8d2                	sd	s4,80(sp)
    12ce:	e4d6                	sd	s5,72(sp)
    12d0:	fc86                	sd	ra,120(sp)
    12d2:	f8a2                	sd	s0,112(sp)
    12d4:	f4a6                	sd	s1,104(sp)
    12d6:	89aa                	mv	s3,a0
    12d8:	e52e                	sd	a1,136(sp)
    12da:	e932                	sd	a2,144(sp)
    12dc:	ed36                	sd	a3,152(sp)
    12de:	f13a                	sd	a4,160(sp)
    12e0:	f942                	sd	a6,176(sp)
    12e2:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    12e4:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    12e6:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    12ea:	00001a17          	auipc	s4,0x1
    12ee:	6bea0a13          	addi	s4,s4,1726 # 29a8 <buffer_len>
    12f2:	4a85                	li	s5,1
	buf[i++] = '0';
    12f4:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    12f8:	0009c783          	lbu	a5,0(s3)
    12fc:	18078663          	beqz	a5,1488 <printf+0x1ca>
    1300:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1302:	19278d63          	beq	a5,s2,149c <printf+0x1de>
    1306:	0015c783          	lbu	a5,1(a1)
    130a:	0585                	addi	a1,a1,1
    130c:	fbfd                	bnez	a5,1302 <printf+0x44>
    130e:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1310:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1314:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1318:	1b578863          	beq	a5,s5,14c8 <printf+0x20a>
		len = out_unlocked(s, l);
    131c:	85a2                	mv	a1,s0
    131e:	854e                	mv	a0,s3
    1320:	42a000ef          	jal	ra,174a <out_unlocked>
		out(f, a, l);
		if (l)
    1324:	1c041063          	bnez	s0,14e4 <printf+0x226>
			continue;
		if (s[1] == 0)
    1328:	0014c783          	lbu	a5,1(s1)
    132c:	14078e63          	beqz	a5,1488 <printf+0x1ca>
			break;
		switch (s[1]) {
    1330:	07300713          	li	a4,115
    1334:	1ce78863          	beq	a5,a4,1504 <printf+0x246>
    1338:	1af76863          	bltu	a4,a5,14e8 <printf+0x22a>
    133c:	06400713          	li	a4,100
    1340:	22e78063          	beq	a5,a4,1560 <printf+0x2a2>
    1344:	07000713          	li	a4,112
    1348:	1ee79563          	bne	a5,a4,1532 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    134c:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    134e:	00001797          	auipc	a5,0x1
    1352:	76a78793          	addi	a5,a5,1898 # 2ab8 <digits>
	buf[i++] = '0';
    1356:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    135a:	6298                	ld	a4,0(a3)
    135c:	06a1                	addi	a3,a3,8
    135e:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1360:	00471393          	slli	t2,a4,0x4
    1364:	00871293          	slli	t0,a4,0x8
    1368:	00c71f93          	slli	t6,a4,0xc
    136c:	01071f13          	slli	t5,a4,0x10
    1370:	01471e93          	slli	t4,a4,0x14
    1374:	01871e13          	slli	t3,a4,0x18
    1378:	01c71893          	slli	a7,a4,0x1c
    137c:	02471813          	slli	a6,a4,0x24
    1380:	02871513          	slli	a0,a4,0x28
    1384:	02c71593          	slli	a1,a4,0x2c
    1388:	03071613          	slli	a2,a4,0x30
    138c:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1390:	03c75413          	srli	s0,a4,0x3c
    1394:	01c7531b          	srliw	t1,a4,0x1c
    1398:	03c3d393          	srli	t2,t2,0x3c
    139c:	03c2d293          	srli	t0,t0,0x3c
    13a0:	03cfdf93          	srli	t6,t6,0x3c
    13a4:	03cf5f13          	srli	t5,t5,0x3c
    13a8:	03cede93          	srli	t4,t4,0x3c
    13ac:	03ce5e13          	srli	t3,t3,0x3c
    13b0:	03c8d893          	srli	a7,a7,0x3c
    13b4:	03c85813          	srli	a6,a6,0x3c
    13b8:	9171                	srli	a0,a0,0x3c
    13ba:	91f1                	srli	a1,a1,0x3c
    13bc:	9271                	srli	a2,a2,0x3c
    13be:	92f1                	srli	a3,a3,0x3c
    13c0:	95be                	add	a1,a1,a5
    13c2:	963e                	add	a2,a2,a5
    13c4:	96be                	add	a3,a3,a5
    13c6:	943e                	add	s0,s0,a5
    13c8:	93be                	add	t2,t2,a5
    13ca:	92be                	add	t0,t0,a5
    13cc:	9fbe                	add	t6,t6,a5
    13ce:	9f3e                	add	t5,t5,a5
    13d0:	9ebe                	add	t4,t4,a5
    13d2:	9e3e                	add	t3,t3,a5
    13d4:	98be                	add	a7,a7,a5
    13d6:	933e                	add	t1,t1,a5
    13d8:	983e                	add	a6,a6,a5
    13da:	953e                	add	a0,a0,a5
    13dc:	0005c983          	lbu	s3,0(a1)
    13e0:	00044403          	lbu	s0,0(s0)
    13e4:	00064583          	lbu	a1,0(a2)
    13e8:	0003c383          	lbu	t2,0(t2)
    13ec:	0006c603          	lbu	a2,0(a3)
    13f0:	0002c283          	lbu	t0,0(t0)
    13f4:	000fcf83          	lbu	t6,0(t6)
    13f8:	000f4f03          	lbu	t5,0(t5)
    13fc:	000ece83          	lbu	t4,0(t4)
    1400:	000e4e03          	lbu	t3,0(t3)
    1404:	0008c883          	lbu	a7,0(a7)
    1408:	00034303          	lbu	t1,0(t1)
    140c:	00084803          	lbu	a6,0(a6)
    1410:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1414:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1418:	92f1                	srli	a3,a3,0x3c
    141a:	8b3d                	andi	a4,a4,15
    141c:	96be                	add	a3,a3,a5
    141e:	97ba                	add	a5,a5,a4
    1420:	00810d23          	sb	s0,26(sp)
    1424:	00710da3          	sb	t2,27(sp)
    1428:	00510e23          	sb	t0,28(sp)
    142c:	01f10ea3          	sb	t6,29(sp)
    1430:	01e10f23          	sb	t5,30(sp)
    1434:	01d10fa3          	sb	t4,31(sp)
    1438:	03c10023          	sb	t3,32(sp)
    143c:	031100a3          	sb	a7,33(sp)
    1440:	02610123          	sb	t1,34(sp)
    1444:	030101a3          	sb	a6,35(sp)
    1448:	02a10223          	sb	a0,36(sp)
    144c:	033102a3          	sb	s3,37(sp)
    1450:	02b10323          	sb	a1,38(sp)
    1454:	02c103a3          	sb	a2,39(sp)
    1458:	0006c683          	lbu	a3,0(a3)
    145c:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1460:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1464:	02d10423          	sb	a3,40(sp)
    1468:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    146c:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1470:	11578263          	beq	a5,s5,1574 <printf+0x2b6>
		len = out_unlocked(s, l);
    1474:	45c9                	li	a1,18
    1476:	0828                	addi	a0,sp,24
    1478:	2d2000ef          	jal	ra,174a <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    147c:	00248993          	addi	s3,s1,2
		if (!*s)
    1480:	0009c783          	lbu	a5,0(s3)
    1484:	e6079ee3          	bnez	a5,1300 <printf+0x42>
	}
	va_end(ap);
    1488:	70e6                	ld	ra,120(sp)
    148a:	7446                	ld	s0,112(sp)
    148c:	74a6                	ld	s1,104(sp)
    148e:	7906                	ld	s2,96(sp)
    1490:	69e6                	ld	s3,88(sp)
    1492:	6a46                	ld	s4,80(sp)
    1494:	6aa6                	ld	s5,72(sp)
    1496:	6b06                	ld	s6,64(sp)
    1498:	6129                	addi	sp,sp,192
    149a:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    149c:	0005c783          	lbu	a5,0(a1)
    14a0:	84ae                	mv	s1,a1
    14a2:	01278963          	beq	a5,s2,14b4 <printf+0x1f6>
    14a6:	b5ad                	j	1310 <printf+0x52>
    14a8:	0024c783          	lbu	a5,2(s1)
    14ac:	0585                	addi	a1,a1,1
    14ae:	0489                	addi	s1,s1,2
    14b0:	e72790e3          	bne	a5,s2,1310 <printf+0x52>
    14b4:	0014c783          	lbu	a5,1(s1)
    14b8:	ff2788e3          	beq	a5,s2,14a8 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    14bc:	108a2783          	lw	a5,264(s4)
		l = z - a;
    14c0:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14c4:	e5579ce3          	bne	a5,s5,131c <printf+0x5e>
		mutex_lock(buffer_lock);
    14c8:	10ca2503          	lw	a0,268(s4)
    14cc:	292010ef          	jal	ra,275e <mutex_lock>
		len = out_unlocked(s, l);
    14d0:	85a2                	mv	a1,s0
    14d2:	854e                	mv	a0,s3
    14d4:	276000ef          	jal	ra,174a <out_unlocked>
		mutex_unlock(buffer_lock);
    14d8:	10ca2503          	lw	a0,268(s4)
    14dc:	28e010ef          	jal	ra,276a <mutex_unlock>
		if (l)
    14e0:	e40404e3          	beqz	s0,1328 <printf+0x6a>
    14e4:	89a6                	mv	s3,s1
    14e6:	bd09                	j	12f8 <printf+0x3a>
		switch (s[1]) {
    14e8:	07800713          	li	a4,120
    14ec:	04e79363          	bne	a5,a4,1532 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    14f0:	67c2                	ld	a5,16(sp)
    14f2:	45c1                	li	a1,16
		s += 2;
    14f4:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    14f8:	4388                	lw	a0,0(a5)
    14fa:	07a1                	addi	a5,a5,8
    14fc:	e83e                	sd	a5,16(sp)
    14fe:	5f8000ef          	jal	ra,1af6 <printint.constprop.0>
		s += 2;
    1502:	bfbd                	j	1480 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1504:	67c2                	ld	a5,16(sp)
    1506:	6380                	ld	s0,0(a5)
    1508:	07a1                	addi	a5,a5,8
    150a:	e83e                	sd	a5,16(sp)
    150c:	1c040163          	beqz	s0,16ce <printf+0x410>
			l = strnlen(a, 200);
    1510:	0c800593          	li	a1,200
    1514:	8522                	mv	a0,s0
    1516:	3f7000ef          	jal	ra,210c <strnlen>
	if (buffer_lock_enabled == 1) {
    151a:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    151e:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1522:	19578663          	beq	a5,s5,16ae <printf+0x3f0>
		len = out_unlocked(s, l);
    1526:	8522                	mv	a0,s0
    1528:	222000ef          	jal	ra,174a <out_unlocked>
		s += 2;
    152c:	00248993          	addi	s3,s1,2
    1530:	bf81                	j	1480 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1532:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1536:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    153a:	0f578663          	beq	a5,s5,1626 <printf+0x368>
		len = out_unlocked(s, l);
    153e:	0828                	addi	a0,sp,24
    1540:	316000ef          	jal	ra,1856 <out_unlocked.constprop.0>
			putchar(s[1]);
    1544:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1548:	108a2783          	lw	a5,264(s4)
	char byte = c;
    154c:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1550:	05578163          	beq	a5,s5,1592 <printf+0x2d4>
		len = out_unlocked(s, l);
    1554:	0828                	addi	a0,sp,24
    1556:	300000ef          	jal	ra,1856 <out_unlocked.constprop.0>
		s += 2;
    155a:	00248993          	addi	s3,s1,2
    155e:	b70d                	j	1480 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1560:	67c2                	ld	a5,16(sp)
    1562:	45a9                	li	a1,10
		s += 2;
    1564:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1568:	4388                	lw	a0,0(a5)
    156a:	07a1                	addi	a5,a5,8
    156c:	e83e                	sd	a5,16(sp)
    156e:	588000ef          	jal	ra,1af6 <printint.constprop.0>
		s += 2;
    1572:	b739                	j	1480 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1574:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1578:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    157c:	1e2010ef          	jal	ra,275e <mutex_lock>
		len = out_unlocked(s, l);
    1580:	45c9                	li	a1,18
    1582:	0828                	addi	a0,sp,24
    1584:	1c6000ef          	jal	ra,174a <out_unlocked>
		mutex_unlock(buffer_lock);
    1588:	10ca2503          	lw	a0,268(s4)
    158c:	1de010ef          	jal	ra,276a <mutex_unlock>
		s += 2;
    1590:	bdc5                	j	1480 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1592:	10ca2503          	lw	a0,268(s4)
    1596:	1c8010ef          	jal	ra,275e <mutex_lock>
		buffer[buffer_len++] = c;
    159a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    159e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    15a2:	0017861b          	addiw	a2,a5,1
    15a6:	97d2                	add	a5,a5,s4
    15a8:	00ca2023          	sw	a2,0(s4)
    15ac:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    15b0:	00c6cc63          	blt	a3,a2,15c8 <printf+0x30a>
    15b4:	47a9                	li	a5,10
    15b6:	06f40663          	beq	s0,a5,1622 <printf+0x364>
		mutex_unlock(buffer_lock);
    15ba:	10ca2503          	lw	a0,268(s4)
		s += 2;
    15be:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    15c2:	1a8010ef          	jal	ra,276a <mutex_unlock>
		s += 2;
    15c6:	bd6d                	j	1480 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    15c8:	10000793          	li	a5,256
    15cc:	00f61e63          	bne	a2,a5,15e8 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    15d0:	00001597          	auipc	a1,0x1
    15d4:	3e058593          	addi	a1,a1,992 # 29b0 <buffer>
    15d8:	4505                	li	a0,1
    15da:	70d000ef          	jal	ra,24e6 <write>
	buffer_len = 0;
    15de:	00001797          	auipc	a5,0x1
    15e2:	3c07a523          	sw	zero,970(a5) # 29a8 <buffer_len>
			if (r < 0) {
    15e6:	bfd1                	j	15ba <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    15e8:	709000ef          	jal	ra,24f0 <getpid>
    15ec:	842a                	mv	s0,a0
    15ee:	00001517          	auipc	a0,0x1
    15f2:	2ca50513          	addi	a0,a0,714 # 28b8 <enable_deadlock_detect+0xfa>
    15f6:	5d1000ef          	jal	ra,23c6 <basename>
    15fa:	872a                	mv	a4,a0
    15fc:	00001617          	auipc	a2,0x1
    1600:	22460613          	addi	a2,a2,548 # 2820 <enable_deadlock_detect+0x62>
    1604:	05400793          	li	a5,84
    1608:	86a2                	mv	a3,s0
    160a:	45fd                	li	a1,31
    160c:	00001517          	auipc	a0,0x1
    1610:	2ec50513          	addi	a0,a0,748 # 28f8 <enable_deadlock_detect+0x13a>
    1614:	cabff0ef          	jal	ra,12be <printf>
    1618:	557d                	li	a0,-1
    161a:	707000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    161e:	000a2603          	lw	a2,0(s4)
    1622:	de41                	beqz	a2,15ba <printf+0x2fc>
    1624:	b775                	j	15d0 <printf+0x312>
		mutex_lock(buffer_lock);
    1626:	10ca2503          	lw	a0,268(s4)
    162a:	134010ef          	jal	ra,275e <mutex_lock>
		buffer[buffer_len++] = c;
    162e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1632:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1636:	0017861b          	addiw	a2,a5,1
    163a:	97d2                	add	a5,a5,s4
    163c:	00ca2023          	sw	a2,0(s4)
    1640:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1644:	02c6d163          	bge	a3,a2,1666 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1648:	10000793          	li	a5,256
    164c:	02f61263          	bne	a2,a5,1670 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1650:	00001597          	auipc	a1,0x1
    1654:	36058593          	addi	a1,a1,864 # 29b0 <buffer>
    1658:	4505                	li	a0,1
    165a:	68d000ef          	jal	ra,24e6 <write>
	buffer_len = 0;
    165e:	00001797          	auipc	a5,0x1
    1662:	3407a523          	sw	zero,842(a5) # 29a8 <buffer_len>
		mutex_unlock(buffer_lock);
    1666:	10ca2503          	lw	a0,268(s4)
    166a:	100010ef          	jal	ra,276a <mutex_unlock>
    166e:	bdd9                	j	1544 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1670:	681000ef          	jal	ra,24f0 <getpid>
    1674:	842a                	mv	s0,a0
    1676:	00001517          	auipc	a0,0x1
    167a:	24250513          	addi	a0,a0,578 # 28b8 <enable_deadlock_detect+0xfa>
    167e:	549000ef          	jal	ra,23c6 <basename>
    1682:	872a                	mv	a4,a0
    1684:	00001617          	auipc	a2,0x1
    1688:	19c60613          	addi	a2,a2,412 # 2820 <enable_deadlock_detect+0x62>
    168c:	05400793          	li	a5,84
    1690:	86a2                	mv	a3,s0
    1692:	45fd                	li	a1,31
    1694:	00001517          	auipc	a0,0x1
    1698:	26450513          	addi	a0,a0,612 # 28f8 <enable_deadlock_detect+0x13a>
    169c:	c23ff0ef          	jal	ra,12be <printf>
    16a0:	557d                	li	a0,-1
    16a2:	67f000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    16a6:	000a2603          	lw	a2,0(s4)
    16aa:	de55                	beqz	a2,1666 <printf+0x3a8>
    16ac:	b755                	j	1650 <printf+0x392>
		mutex_lock(buffer_lock);
    16ae:	10ca2503          	lw	a0,268(s4)
    16b2:	e42e                	sd	a1,8(sp)
		s += 2;
    16b4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    16b8:	0a6010ef          	jal	ra,275e <mutex_lock>
		len = out_unlocked(s, l);
    16bc:	65a2                	ld	a1,8(sp)
    16be:	8522                	mv	a0,s0
    16c0:	08a000ef          	jal	ra,174a <out_unlocked>
		mutex_unlock(buffer_lock);
    16c4:	10ca2503          	lw	a0,268(s4)
    16c8:	0a2010ef          	jal	ra,276a <mutex_unlock>
		s += 2;
    16cc:	bb55                	j	1480 <printf+0x1c2>
				a = "(null)";
    16ce:	00001417          	auipc	s0,0x1
    16d2:	1e240413          	addi	s0,s0,482 # 28b0 <enable_deadlock_detect+0xf2>
    16d6:	bd2d                	j	1510 <printf+0x252>

00000000000016d8 <enable_thread_io_buffer>:
{
    16d8:	1101                	addi	sp,sp,-32
    16da:	e822                	sd	s0,16(sp)
    16dc:	ec06                	sd	ra,24(sp)
    16de:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    16e0:	00001417          	auipc	s0,0x1
    16e4:	2c840413          	addi	s0,s0,712 # 29a8 <buffer_len>
    16e8:	05a010ef          	jal	ra,2742 <mutex_create>
    16ec:	10a42623          	sw	a0,268(s0)
    16f0:	00054a63          	bltz	a0,1704 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    16f4:	4785                	li	a5,1
}
    16f6:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    16f8:	10f42423          	sw	a5,264(s0)
}
    16fc:	6442                	ld	s0,16(sp)
    16fe:	64a2                	ld	s1,8(sp)
    1700:	6105                	addi	sp,sp,32
    1702:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1704:	5ed000ef          	jal	ra,24f0 <getpid>
    1708:	84aa                	mv	s1,a0
    170a:	00001517          	auipc	a0,0x1
    170e:	1ae50513          	addi	a0,a0,430 # 28b8 <enable_deadlock_detect+0xfa>
    1712:	4b5000ef          	jal	ra,23c6 <basename>
    1716:	872a                	mv	a4,a0
    1718:	04800793          	li	a5,72
    171c:	86a6                	mv	a3,s1
    171e:	00001517          	auipc	a0,0x1
    1722:	21a50513          	addi	a0,a0,538 # 2938 <enable_deadlock_detect+0x17a>
    1726:	00001617          	auipc	a2,0x1
    172a:	0fa60613          	addi	a2,a2,250 # 2820 <enable_deadlock_detect+0x62>
    172e:	45fd                	li	a1,31
    1730:	b8fff0ef          	jal	ra,12be <printf>
    1734:	557d                	li	a0,-1
    1736:	5eb000ef          	jal	ra,2520 <exit>
	buffer_lock_enabled = 1;
    173a:	4785                	li	a5,1
}
    173c:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    173e:	10f42423          	sw	a5,264(s0)
}
    1742:	6442                	ld	s0,16(sp)
    1744:	64a2                	ld	s1,8(sp)
    1746:	6105                	addi	sp,sp,32
    1748:	8082                	ret

000000000000174a <out_unlocked>:
{
    174a:	7159                	addi	sp,sp,-112
    174c:	f486                	sd	ra,104(sp)
    174e:	f0a2                	sd	s0,96(sp)
    1750:	eca6                	sd	s1,88(sp)
    1752:	e8ca                	sd	s2,80(sp)
    1754:	e4ce                	sd	s3,72(sp)
    1756:	e0d2                	sd	s4,64(sp)
    1758:	fc56                	sd	s5,56(sp)
    175a:	f85a                	sd	s6,48(sp)
    175c:	f45e                	sd	s7,40(sp)
    175e:	f062                	sd	s8,32(sp)
    1760:	ec66                	sd	s9,24(sp)
    1762:	e86a                	sd	s10,16(sp)
    1764:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1766:	0e058663          	beqz	a1,1852 <out_unlocked+0x108>
    176a:	842a                	mv	s0,a0
    176c:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1770:	4981                	li	s3,0
    1772:	00001d17          	auipc	s10,0x1
    1776:	236d0d13          	addi	s10,s10,566 # 29a8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    177a:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    177e:	00001b17          	auipc	s6,0x1
    1782:	232b0b13          	addi	s6,s6,562 # 29b0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1786:	10000a93          	li	s5,256
    178a:	00001c97          	auipc	s9,0x1
    178e:	12ec8c93          	addi	s9,s9,302 # 28b8 <enable_deadlock_detect+0xfa>
    1792:	00001c17          	auipc	s8,0x1
    1796:	08ec0c13          	addi	s8,s8,142 # 2820 <enable_deadlock_detect+0x62>
    179a:	00001b97          	auipc	s7,0x1
    179e:	15eb8b93          	addi	s7,s7,350 # 28f8 <enable_deadlock_detect+0x13a>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17a2:	4a29                	li	s4,10
    17a4:	a031                	j	17b0 <out_unlocked+0x66>
    17a6:	09468863          	beq	a3,s4,1836 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    17aa:	0405                	addi	s0,s0,1
    17ac:	04848163          	beq	s1,s0,17ee <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    17b0:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    17b4:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    17b8:	0017861b          	addiw	a2,a5,1
    17bc:	97ea                	add	a5,a5,s10
    17be:	00cd2023          	sw	a2,0(s10)
    17c2:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17c6:	fec950e3          	bge	s2,a2,17a6 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    17ca:	05561263          	bne	a2,s5,180e <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    17ce:	85da                	mv	a1,s6
    17d0:	4505                	li	a0,1
    17d2:	515000ef          	jal	ra,24e6 <write>
    17d6:	2501                	sext.w	a0,a0
	buffer_len = 0;
    17d8:	00001797          	auipc	a5,0x1
    17dc:	1c07a823          	sw	zero,464(a5) # 29a8 <buffer_len>
			if (r < 0) {
    17e0:	06054763          	bltz	a0,184e <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    17e4:	0405                	addi	s0,s0,1
			ret += r;
    17e6:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    17ea:	fc8493e3          	bne	s1,s0,17b0 <out_unlocked+0x66>
}
    17ee:	70a6                	ld	ra,104(sp)
    17f0:	7406                	ld	s0,96(sp)
    17f2:	64e6                	ld	s1,88(sp)
    17f4:	6946                	ld	s2,80(sp)
    17f6:	6a06                	ld	s4,64(sp)
    17f8:	7ae2                	ld	s5,56(sp)
    17fa:	7b42                	ld	s6,48(sp)
    17fc:	7ba2                	ld	s7,40(sp)
    17fe:	7c02                	ld	s8,32(sp)
    1800:	6ce2                	ld	s9,24(sp)
    1802:	6d42                	ld	s10,16(sp)
    1804:	6da2                	ld	s11,8(sp)
    1806:	854e                	mv	a0,s3
    1808:	69a6                	ld	s3,72(sp)
    180a:	6165                	addi	sp,sp,112
    180c:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    180e:	4e3000ef          	jal	ra,24f0 <getpid>
    1812:	8daa                	mv	s11,a0
    1814:	8566                	mv	a0,s9
    1816:	3b1000ef          	jal	ra,23c6 <basename>
    181a:	872a                	mv	a4,a0
    181c:	8662                	mv	a2,s8
    181e:	05400793          	li	a5,84
    1822:	86ee                	mv	a3,s11
    1824:	45fd                	li	a1,31
    1826:	855e                	mv	a0,s7
    1828:	a97ff0ef          	jal	ra,12be <printf>
    182c:	557d                	li	a0,-1
    182e:	4f3000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    1832:	000d2603          	lw	a2,0(s10)
    1836:	da35                	beqz	a2,17aa <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1838:	85da                	mv	a1,s6
    183a:	4505                	li	a0,1
    183c:	4ab000ef          	jal	ra,24e6 <write>
    1840:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1842:	00001797          	auipc	a5,0x1
    1846:	1607a323          	sw	zero,358(a5) # 29a8 <buffer_len>
			if (r < 0) {
    184a:	f8055de3          	bgez	a0,17e4 <out_unlocked+0x9a>
    184e:	89aa                	mv	s3,a0
    1850:	bf79                	j	17ee <out_unlocked+0xa4>
	int ret = 0;
    1852:	4981                	li	s3,0
    1854:	bf69                	j	17ee <out_unlocked+0xa4>

0000000000001856 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1856:	1101                	addi	sp,sp,-32
    1858:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    185a:	00001497          	auipc	s1,0x1
    185e:	14e48493          	addi	s1,s1,334 # 29a8 <buffer_len>
    1862:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1864:	ec06                	sd	ra,24(sp)
    1866:	e822                	sd	s0,16(sp)
		char c = s[i];
    1868:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    186c:	0017861b          	addiw	a2,a5,1
    1870:	97a6                	add	a5,a5,s1
    1872:	00e78423          	sb	a4,8(a5)
    1876:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1878:	0ff00793          	li	a5,255
    187c:	00c7cc63          	blt	a5,a2,1894 <out_unlocked.constprop.0+0x3e>
    1880:	47a9                	li	a5,10
    1882:	06f70c63          	beq	a4,a5,18fa <out_unlocked.constprop.0+0xa4>
    1886:	4601                	li	a2,0
}
    1888:	60e2                	ld	ra,24(sp)
    188a:	6442                	ld	s0,16(sp)
    188c:	64a2                	ld	s1,8(sp)
    188e:	8532                	mv	a0,a2
    1890:	6105                	addi	sp,sp,32
    1892:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1894:	10000793          	li	a5,256
    1898:	02f61563          	bne	a2,a5,18c2 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    189c:	00001597          	auipc	a1,0x1
    18a0:	11458593          	addi	a1,a1,276 # 29b0 <buffer>
    18a4:	4505                	li	a0,1
    18a6:	441000ef          	jal	ra,24e6 <write>
}
    18aa:	60e2                	ld	ra,24(sp)
    18ac:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    18ae:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18b2:	00001797          	auipc	a5,0x1
    18b6:	0e07ab23          	sw	zero,246(a5) # 29a8 <buffer_len>
}
    18ba:	64a2                	ld	s1,8(sp)
    18bc:	8532                	mv	a0,a2
    18be:	6105                	addi	sp,sp,32
    18c0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18c2:	42f000ef          	jal	ra,24f0 <getpid>
    18c6:	842a                	mv	s0,a0
    18c8:	00001517          	auipc	a0,0x1
    18cc:	ff050513          	addi	a0,a0,-16 # 28b8 <enable_deadlock_detect+0xfa>
    18d0:	2f7000ef          	jal	ra,23c6 <basename>
    18d4:	872a                	mv	a4,a0
    18d6:	00001617          	auipc	a2,0x1
    18da:	f4a60613          	addi	a2,a2,-182 # 2820 <enable_deadlock_detect+0x62>
    18de:	05400793          	li	a5,84
    18e2:	86a2                	mv	a3,s0
    18e4:	45fd                	li	a1,31
    18e6:	00001517          	auipc	a0,0x1
    18ea:	01250513          	addi	a0,a0,18 # 28f8 <enable_deadlock_detect+0x13a>
    18ee:	9d1ff0ef          	jal	ra,12be <printf>
    18f2:	557d                	li	a0,-1
    18f4:	42d000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    18f8:	4090                	lw	a2,0(s1)
    18fa:	d659                	beqz	a2,1888 <out_unlocked.constprop.0+0x32>
    18fc:	b745                	j	189c <out_unlocked.constprop.0+0x46>

00000000000018fe <putchar>:
{
    18fe:	7139                	addi	sp,sp,-64
    1900:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1902:	00001497          	auipc	s1,0x1
    1906:	0a648493          	addi	s1,s1,166 # 29a8 <buffer_len>
    190a:	1084a703          	lw	a4,264(s1)
{
    190e:	f822                	sd	s0,48(sp)
	char byte = c;
    1910:	0ff57413          	zext.b	s0,a0
{
    1914:	fc06                	sd	ra,56(sp)
	char byte = c;
    1916:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    191a:	4785                	li	a5,1
    191c:	00f70d63          	beq	a4,a5,1936 <putchar+0x38>
		len = out_unlocked(s, l);
    1920:	01f10513          	addi	a0,sp,31
    1924:	f33ff0ef          	jal	ra,1856 <out_unlocked.constprop.0>
}
    1928:	70e2                	ld	ra,56(sp)
    192a:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    192c:	862a                	mv	a2,a0
}
    192e:	74a2                	ld	s1,40(sp)
    1930:	8532                	mv	a0,a2
    1932:	6121                	addi	sp,sp,64
    1934:	8082                	ret
		mutex_lock(buffer_lock);
    1936:	10c4a503          	lw	a0,268(s1)
    193a:	625000ef          	jal	ra,275e <mutex_lock>
		buffer[buffer_len++] = c;
    193e:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1940:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1944:	0017861b          	addiw	a2,a5,1
    1948:	97a6                	add	a5,a5,s1
    194a:	c090                	sw	a2,0(s1)
    194c:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1950:	02c6c263          	blt	a3,a2,1974 <putchar+0x76>
    1954:	47a9                	li	a5,10
    1956:	06f40d63          	beq	s0,a5,19d0 <putchar+0xd2>
    195a:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    195c:	10c4a503          	lw	a0,268(s1)
    1960:	e432                	sd	a2,8(sp)
    1962:	609000ef          	jal	ra,276a <mutex_unlock>
    1966:	6622                	ld	a2,8(sp)
}
    1968:	70e2                	ld	ra,56(sp)
    196a:	7442                	ld	s0,48(sp)
    196c:	74a2                	ld	s1,40(sp)
    196e:	8532                	mv	a0,a2
    1970:	6121                	addi	sp,sp,64
    1972:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1974:	10000793          	li	a5,256
    1978:	02f61063          	bne	a2,a5,1998 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    197c:	00001597          	auipc	a1,0x1
    1980:	03458593          	addi	a1,a1,52 # 29b0 <buffer>
    1984:	4505                	li	a0,1
    1986:	361000ef          	jal	ra,24e6 <write>
    198a:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    198e:	00001797          	auipc	a5,0x1
    1992:	0007ad23          	sw	zero,26(a5) # 29a8 <buffer_len>
			if (r < 0) {
    1996:	b7d9                	j	195c <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1998:	359000ef          	jal	ra,24f0 <getpid>
    199c:	842a                	mv	s0,a0
    199e:	00001517          	auipc	a0,0x1
    19a2:	f1a50513          	addi	a0,a0,-230 # 28b8 <enable_deadlock_detect+0xfa>
    19a6:	221000ef          	jal	ra,23c6 <basename>
    19aa:	872a                	mv	a4,a0
    19ac:	00001617          	auipc	a2,0x1
    19b0:	e7460613          	addi	a2,a2,-396 # 2820 <enable_deadlock_detect+0x62>
    19b4:	05400793          	li	a5,84
    19b8:	86a2                	mv	a3,s0
    19ba:	45fd                	li	a1,31
    19bc:	00001517          	auipc	a0,0x1
    19c0:	f3c50513          	addi	a0,a0,-196 # 28f8 <enable_deadlock_detect+0x13a>
    19c4:	8fbff0ef          	jal	ra,12be <printf>
    19c8:	557d                	li	a0,-1
    19ca:	357000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    19ce:	4090                	lw	a2,0(s1)
    19d0:	d651                	beqz	a2,195c <putchar+0x5e>
    19d2:	b76d                	j	197c <putchar+0x7e>

00000000000019d4 <puts>:
{
    19d4:	7139                	addi	sp,sp,-64
    19d6:	f822                	sd	s0,48(sp)
    19d8:	f426                	sd	s1,40(sp)
    19da:	fc06                	sd	ra,56(sp)
    19dc:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    19de:	00001417          	auipc	s0,0x1
    19e2:	fca40413          	addi	s0,s0,-54 # 29a8 <buffer_len>
{
    19e6:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19e8:	638000ef          	jal	ra,2020 <strlen>
	if (buffer_lock_enabled == 1) {
    19ec:	10842703          	lw	a4,264(s0)
    19f0:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    19f2:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    19f4:	04f70563          	beq	a4,a5,1a3e <puts+0x6a>
		len = out_unlocked(s, l);
    19f8:	8526                	mv	a0,s1
    19fa:	d51ff0ef          	jal	ra,174a <out_unlocked>
    19fe:	892a                	mv	s2,a0
    1a00:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a02:	00095963          	bgez	s2,1a14 <puts+0x40>
}
    1a06:	70e2                	ld	ra,56(sp)
    1a08:	7442                	ld	s0,48(sp)
    1a0a:	7902                	ld	s2,32(sp)
    1a0c:	8526                	mv	a0,s1
    1a0e:	74a2                	ld	s1,40(sp)
    1a10:	6121                	addi	sp,sp,64
    1a12:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1a14:	10842703          	lw	a4,264(s0)
	char byte = c;
    1a18:	44a9                	li	s1,10
    1a1a:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1a1e:	4785                	li	a5,1
    1a20:	02f70e63          	beq	a4,a5,1a5c <puts+0x88>
		len = out_unlocked(s, l);
    1a24:	01f10513          	addi	a0,sp,31
    1a28:	e2fff0ef          	jal	ra,1856 <out_unlocked.constprop.0>
}
    1a2c:	70e2                	ld	ra,56(sp)
    1a2e:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1a30:	41f5549b          	sraiw	s1,a0,0x1f
}
    1a34:	7902                	ld	s2,32(sp)
    1a36:	8526                	mv	a0,s1
    1a38:	74a2                	ld	s1,40(sp)
    1a3a:	6121                	addi	sp,sp,64
    1a3c:	8082                	ret
		mutex_lock(buffer_lock);
    1a3e:	e42a                	sd	a0,8(sp)
    1a40:	10c42503          	lw	a0,268(s0)
    1a44:	51b000ef          	jal	ra,275e <mutex_lock>
		len = out_unlocked(s, l);
    1a48:	65a2                	ld	a1,8(sp)
    1a4a:	8526                	mv	a0,s1
    1a4c:	cffff0ef          	jal	ra,174a <out_unlocked>
    1a50:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1a52:	10c42503          	lw	a0,268(s0)
    1a56:	515000ef          	jal	ra,276a <mutex_unlock>
    1a5a:	b75d                	j	1a00 <puts+0x2c>
		mutex_lock(buffer_lock);
    1a5c:	10c42503          	lw	a0,268(s0)
    1a60:	4ff000ef          	jal	ra,275e <mutex_lock>
		buffer[buffer_len++] = c;
    1a64:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a66:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a6a:	0017861b          	addiw	a2,a5,1
    1a6e:	97a2                	add	a5,a5,s0
    1a70:	c010                	sw	a2,0(s0)
    1a72:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a76:	06c6dc63          	bge	a3,a2,1aee <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1a7a:	10000793          	li	a5,256
    1a7e:	02f61c63          	bne	a2,a5,1ab6 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1a82:	00001597          	auipc	a1,0x1
    1a86:	f2e58593          	addi	a1,a1,-210 # 29b0 <buffer>
    1a8a:	4505                	li	a0,1
    1a8c:	25b000ef          	jal	ra,24e6 <write>
			if (r < 0) {
    1a90:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a92:	00001797          	auipc	a5,0x1
    1a96:	f007ab23          	sw	zero,-234(a5) # 29a8 <buffer_len>
			if (r < 0) {
    1a9a:	04054c63          	bltz	a0,1af2 <puts+0x11e>
			if (r < buffer_len) {
    1a9e:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1aa0:	10c42503          	lw	a0,268(s0)
    1aa4:	4c7000ef          	jal	ra,276a <mutex_unlock>
}
    1aa8:	70e2                	ld	ra,56(sp)
    1aaa:	7442                	ld	s0,48(sp)
    1aac:	7902                	ld	s2,32(sp)
    1aae:	8526                	mv	a0,s1
    1ab0:	74a2                	ld	s1,40(sp)
    1ab2:	6121                	addi	sp,sp,64
    1ab4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1ab6:	23b000ef          	jal	ra,24f0 <getpid>
    1aba:	84aa                	mv	s1,a0
    1abc:	00001517          	auipc	a0,0x1
    1ac0:	dfc50513          	addi	a0,a0,-516 # 28b8 <enable_deadlock_detect+0xfa>
    1ac4:	103000ef          	jal	ra,23c6 <basename>
    1ac8:	872a                	mv	a4,a0
    1aca:	00001617          	auipc	a2,0x1
    1ace:	d5660613          	addi	a2,a2,-682 # 2820 <enable_deadlock_detect+0x62>
    1ad2:	05400793          	li	a5,84
    1ad6:	86a6                	mv	a3,s1
    1ad8:	45fd                	li	a1,31
    1ada:	00001517          	auipc	a0,0x1
    1ade:	e1e50513          	addi	a0,a0,-482 # 28f8 <enable_deadlock_detect+0x13a>
    1ae2:	fdcff0ef          	jal	ra,12be <printf>
    1ae6:	557d                	li	a0,-1
    1ae8:	239000ef          	jal	ra,2520 <exit>
	if (buffer_len == 0)
    1aec:	4010                	lw	a2,0(s0)
    1aee:	da45                	beqz	a2,1a9e <puts+0xca>
    1af0:	bf49                	j	1a82 <puts+0xae>
    1af2:	54fd                	li	s1,-1
    1af4:	b775                	j	1aa0 <puts+0xcc>

0000000000001af6 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1af6:	715d                	addi	sp,sp,-80
    1af8:	e486                	sd	ra,72(sp)
    1afa:	e0a2                	sd	s0,64(sp)
    1afc:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1afe:	14054363          	bltz	a0,1c44 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1b02:	02b577bb          	remuw	a5,a0,a1
    1b06:	00001617          	auipc	a2,0x1
    1b0a:	fb260613          	addi	a2,a2,-78 # 2ab8 <digits>
	buf[16] = 0;
    1b0e:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b12:	0005871b          	sext.w	a4,a1
    1b16:	1782                	slli	a5,a5,0x20
    1b18:	9381                	srli	a5,a5,0x20
    1b1a:	97b2                	add	a5,a5,a2
    1b1c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b20:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1b24:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1b28:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1b2a:	0eb56763          	bltu	a0,a1,1c18 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b2e:	02e877bb          	remuw	a5,a6,a4
    1b32:	1782                	slli	a5,a5,0x20
    1b34:	9381                	srli	a5,a5,0x20
    1b36:	97b2                	add	a5,a5,a2
    1b38:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b3c:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1b40:	02f10323          	sb	a5,38(sp)
    1b44:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1b46:	0ce86963          	bltu	a6,a4,1c18 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1b4a:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1b4e:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1b52:	1582                	slli	a1,a1,0x20
    1b54:	9181                	srli	a1,a1,0x20
    1b56:	95b2                	add	a1,a1,a2
    1b58:	0005c583          	lbu	a1,0(a1)
    1b5c:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1b60:	0007859b          	sext.w	a1,a5
    1b64:	16e6e563          	bltu	a3,a4,1cce <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1b68:	02e7f6bb          	remuw	a3,a5,a4
    1b6c:	1682                	slli	a3,a3,0x20
    1b6e:	9281                	srli	a3,a3,0x20
    1b70:	96b2                	add	a3,a3,a2
    1b72:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b76:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1b7a:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1b7e:	16e5e163          	bltu	a1,a4,1ce0 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1b82:	02e876bb          	remuw	a3,a6,a4
    1b86:	1682                	slli	a3,a3,0x20
    1b88:	9281                	srli	a3,a3,0x20
    1b8a:	96b2                	add	a3,a3,a2
    1b8c:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b90:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b94:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1b98:	14e86d63          	bltu	a6,a4,1cf2 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1b9c:	02e5f6bb          	remuw	a3,a1,a4
    1ba0:	1682                	slli	a3,a3,0x20
    1ba2:	9281                	srli	a3,a3,0x20
    1ba4:	96b2                	add	a3,a3,a2
    1ba6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1baa:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1bae:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1bb2:	10e5e563          	bltu	a1,a4,1cbc <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1bb6:	02e876bb          	remuw	a3,a6,a4
    1bba:	1682                	slli	a3,a3,0x20
    1bbc:	9281                	srli	a3,a3,0x20
    1bbe:	96b2                	add	a3,a3,a2
    1bc0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bc4:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1bc8:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1bcc:	14e86263          	bltu	a6,a4,1d10 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1bd0:	02e5f6bb          	remuw	a3,a1,a4
    1bd4:	1682                	slli	a3,a3,0x20
    1bd6:	9281                	srli	a3,a3,0x20
    1bd8:	96b2                	add	a3,a3,a2
    1bda:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bde:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1be2:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1be6:	14e5e463          	bltu	a1,a4,1d2e <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1bea:	02e876bb          	remuw	a3,a6,a4
    1bee:	1682                	slli	a3,a3,0x20
    1bf0:	9281                	srli	a3,a3,0x20
    1bf2:	96b2                	add	a3,a3,a2
    1bf4:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1bf8:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1bfc:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1c00:	14e86063          	bltu	a6,a4,1d40 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1c04:	1782                	slli	a5,a5,0x20
    1c06:	9381                	srli	a5,a5,0x20
    1c08:	97b2                	add	a5,a5,a2
    1c0a:	0007c703          	lbu	a4,0(a5)
    1c0e:	4799                	li	a5,6
    1c10:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1c14:	10054763          	bltz	a0,1d22 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1c18:	00001497          	auipc	s1,0x1
    1c1c:	d9048493          	addi	s1,s1,-624 # 29a8 <buffer_len>
    1c20:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1c24:	0828                	addi	a0,sp,24
    1c26:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1c28:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1c2a:	00f50433          	add	s0,a0,a5
    1c2e:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1c30:	06e68463          	beq	a3,a4,1c98 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1c34:	8522                	mv	a0,s0
    1c36:	b15ff0ef          	jal	ra,174a <out_unlocked>
}
    1c3a:	60a6                	ld	ra,72(sp)
    1c3c:	6406                	ld	s0,64(sp)
    1c3e:	74e2                	ld	s1,56(sp)
    1c40:	6161                	addi	sp,sp,80
    1c42:	8082                	ret
		x = -xx;
    1c44:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1c48:	02b877bb          	remuw	a5,a6,a1
    1c4c:	00001617          	auipc	a2,0x1
    1c50:	e6c60613          	addi	a2,a2,-404 # 2ab8 <digits>
	buf[16] = 0;
    1c54:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c58:	0005871b          	sext.w	a4,a1
    1c5c:	1782                	slli	a5,a5,0x20
    1c5e:	9381                	srli	a5,a5,0x20
    1c60:	97b2                	add	a5,a5,a2
    1c62:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c66:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1c6a:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1c6e:	08b86b63          	bltu	a6,a1,1d04 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1c72:	02e8f7bb          	remuw	a5,a7,a4
    1c76:	1782                	slli	a5,a5,0x20
    1c78:	9381                	srli	a5,a5,0x20
    1c7a:	97b2                	add	a5,a5,a2
    1c7c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c80:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1c84:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1c88:	ece8f1e3          	bgeu	a7,a4,1b4a <printint.constprop.0+0x54>
		buf[i--] = '-';
    1c8c:	02d00793          	li	a5,45
    1c90:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1c94:	47b5                	li	a5,13
    1c96:	b749                	j	1c18 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1c98:	10c4a503          	lw	a0,268(s1)
    1c9c:	e42e                	sd	a1,8(sp)
    1c9e:	2c1000ef          	jal	ra,275e <mutex_lock>
		len = out_unlocked(s, l);
    1ca2:	65a2                	ld	a1,8(sp)
    1ca4:	8522                	mv	a0,s0
    1ca6:	aa5ff0ef          	jal	ra,174a <out_unlocked>
		mutex_unlock(buffer_lock);
    1caa:	10c4a503          	lw	a0,268(s1)
    1cae:	2bd000ef          	jal	ra,276a <mutex_unlock>
}
    1cb2:	60a6                	ld	ra,72(sp)
    1cb4:	6406                	ld	s0,64(sp)
    1cb6:	74e2                	ld	s1,56(sp)
    1cb8:	6161                	addi	sp,sp,80
    1cba:	8082                	ret
		buf[i--] = digits[x % base];
    1cbc:	47a9                	li	a5,10
	if (sign)
    1cbe:	f4055de3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cc2:	02d00793          	li	a5,45
    1cc6:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1cca:	47a5                	li	a5,9
    1ccc:	b7b1                	j	1c18 <printint.constprop.0+0x122>
    1cce:	47b5                	li	a5,13
	if (sign)
    1cd0:	f40554e3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cd4:	02d00793          	li	a5,45
    1cd8:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1cdc:	47b1                	li	a5,12
    1cde:	bf2d                	j	1c18 <printint.constprop.0+0x122>
    1ce0:	47b1                	li	a5,12
	if (sign)
    1ce2:	f2055be3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ce6:	02d00793          	li	a5,45
    1cea:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1cee:	47ad                	li	a5,11
    1cf0:	b725                	j	1c18 <printint.constprop.0+0x122>
    1cf2:	47ad                	li	a5,11
	if (sign)
    1cf4:	f20552e3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1cf8:	02d00793          	li	a5,45
    1cfc:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1d00:	47a9                	li	a5,10
    1d02:	bf19                	j	1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d04:	02d00793          	li	a5,45
    1d08:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1d0c:	47b9                	li	a5,14
    1d0e:	b729                	j	1c18 <printint.constprop.0+0x122>
    1d10:	47a5                	li	a5,9
	if (sign)
    1d12:	f00553e3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d16:	02d00793          	li	a5,45
    1d1a:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1d1e:	47a1                	li	a5,8
    1d20:	bde5                	j	1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d22:	02d00793          	li	a5,45
    1d26:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1d2a:	4795                	li	a5,5
    1d2c:	b5f5                	j	1c18 <printint.constprop.0+0x122>
    1d2e:	47a1                	li	a5,8
	if (sign)
    1d30:	ee0554e3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d34:	02d00793          	li	a5,45
    1d38:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1d3c:	479d                	li	a5,7
    1d3e:	bde9                	j	1c18 <printint.constprop.0+0x122>
    1d40:	479d                	li	a5,7
	if (sign)
    1d42:	ec055be3          	bgez	a0,1c18 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1d46:	02d00793          	li	a5,45
    1d4a:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1d4e:	4799                	li	a5,6
    1d50:	b5e1                	j	1c18 <printint.constprop.0+0x122>

0000000000001d52 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d52:	02000793          	li	a5,32
    1d56:	00f50663          	beq	a0,a5,1d62 <isspace+0x10>
    1d5a:	355d                	addiw	a0,a0,-9
    1d5c:	00553513          	sltiu	a0,a0,5
    1d60:	8082                	ret
    1d62:	4505                	li	a0,1
}
    1d64:	8082                	ret

0000000000001d66 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1d66:	fd05051b          	addiw	a0,a0,-48
}
    1d6a:	00a53513          	sltiu	a0,a0,10
    1d6e:	8082                	ret

0000000000001d70 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d70:	02000613          	li	a2,32
    1d74:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1d76:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1d7a:	ff77869b          	addiw	a3,a5,-9
    1d7e:	04c78c63          	beq	a5,a2,1dd6 <atoi+0x66>
    1d82:	0007871b          	sext.w	a4,a5
    1d86:	04d5f863          	bgeu	a1,a3,1dd6 <atoi+0x66>
		s++;
	switch (*s) {
    1d8a:	02b00693          	li	a3,43
    1d8e:	04d78963          	beq	a5,a3,1de0 <atoi+0x70>
    1d92:	02d00693          	li	a3,45
    1d96:	06d78263          	beq	a5,a3,1dfa <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1d9a:	fd07061b          	addiw	a2,a4,-48
    1d9e:	47a5                	li	a5,9
    1da0:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1da2:	4e01                	li	t3,0
	while (isdigit(*s))
    1da4:	04c7e963          	bltu	a5,a2,1df6 <atoi+0x86>
	int n = 0, neg = 0;
    1da8:	4501                	li	a0,0
	while (isdigit(*s))
    1daa:	4825                	li	a6,9
    1dac:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1db0:	0025179b          	slliw	a5,a0,0x2
    1db4:	9fa9                	addw	a5,a5,a0
    1db6:	fd07031b          	addiw	t1,a4,-48
    1dba:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1dbe:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1dc2:	0685                	addi	a3,a3,1
    1dc4:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1dc8:	0006071b          	sext.w	a4,a2
    1dcc:	feb870e3          	bgeu	a6,a1,1dac <atoi+0x3c>
	return neg ? n : -n;
    1dd0:	000e0563          	beqz	t3,1dda <atoi+0x6a>
}
    1dd4:	8082                	ret
		s++;
    1dd6:	0505                	addi	a0,a0,1
    1dd8:	bf79                	j	1d76 <atoi+0x6>
	return neg ? n : -n;
    1dda:	4113053b          	subw	a0,t1,a7
    1dde:	8082                	ret
	while (isdigit(*s))
    1de0:	00154703          	lbu	a4,1(a0)
    1de4:	47a5                	li	a5,9
		s++;
    1de6:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1dea:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1dee:	4e01                	li	t3,0
	while (isdigit(*s))
    1df0:	2701                	sext.w	a4,a4
    1df2:	fac7fbe3          	bgeu	a5,a2,1da8 <atoi+0x38>
    1df6:	4501                	li	a0,0
}
    1df8:	8082                	ret
	while (isdigit(*s))
    1dfa:	00154703          	lbu	a4,1(a0)
    1dfe:	47a5                	li	a5,9
		s++;
    1e00:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1e04:	fd07061b          	addiw	a2,a4,-48
    1e08:	2701                	sext.w	a4,a4
    1e0a:	fec7e6e3          	bltu	a5,a2,1df6 <atoi+0x86>
		neg = 1;
    1e0e:	4e05                	li	t3,1
    1e10:	bf61                	j	1da8 <atoi+0x38>

0000000000001e12 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1e12:	16060d63          	beqz	a2,1f8c <memset+0x17a>
    1e16:	40a007b3          	neg	a5,a0
    1e1a:	8b9d                	andi	a5,a5,7
    1e1c:	00778693          	addi	a3,a5,7
    1e20:	482d                	li	a6,11
    1e22:	0ff5f713          	zext.b	a4,a1
    1e26:	fff60593          	addi	a1,a2,-1
    1e2a:	1706e263          	bltu	a3,a6,1f8e <memset+0x17c>
    1e2e:	16d5ea63          	bltu	a1,a3,1fa2 <memset+0x190>
    1e32:	16078563          	beqz	a5,1f9c <memset+0x18a>
    1e36:	00e50023          	sb	a4,0(a0)
    1e3a:	4685                	li	a3,1
    1e3c:	00150593          	addi	a1,a0,1
    1e40:	14d78c63          	beq	a5,a3,1f98 <memset+0x186>
    1e44:	00e500a3          	sb	a4,1(a0)
    1e48:	4689                	li	a3,2
    1e4a:	00250593          	addi	a1,a0,2
    1e4e:	14d78d63          	beq	a5,a3,1fa8 <memset+0x196>
    1e52:	00e50123          	sb	a4,2(a0)
    1e56:	468d                	li	a3,3
    1e58:	00350593          	addi	a1,a0,3
    1e5c:	12d78b63          	beq	a5,a3,1f92 <memset+0x180>
    1e60:	00e501a3          	sb	a4,3(a0)
    1e64:	4691                	li	a3,4
    1e66:	00450593          	addi	a1,a0,4
    1e6a:	14d78163          	beq	a5,a3,1fac <memset+0x19a>
    1e6e:	00e50223          	sb	a4,4(a0)
    1e72:	4695                	li	a3,5
    1e74:	00550593          	addi	a1,a0,5
    1e78:	12d78c63          	beq	a5,a3,1fb0 <memset+0x19e>
    1e7c:	00e502a3          	sb	a4,5(a0)
    1e80:	469d                	li	a3,7
    1e82:	00650593          	addi	a1,a0,6
    1e86:	12d79763          	bne	a5,a3,1fb4 <memset+0x1a2>
    1e8a:	00750593          	addi	a1,a0,7
    1e8e:	00e50323          	sb	a4,6(a0)
    1e92:	481d                	li	a6,7
    1e94:	00871693          	slli	a3,a4,0x8
    1e98:	01071893          	slli	a7,a4,0x10
    1e9c:	8ed9                	or	a3,a3,a4
    1e9e:	01871313          	slli	t1,a4,0x18
    1ea2:	0116e6b3          	or	a3,a3,a7
    1ea6:	0066e6b3          	or	a3,a3,t1
    1eaa:	02071893          	slli	a7,a4,0x20
    1eae:	02871e13          	slli	t3,a4,0x28
    1eb2:	0116e6b3          	or	a3,a3,a7
    1eb6:	40f60333          	sub	t1,a2,a5
    1eba:	03071893          	slli	a7,a4,0x30
    1ebe:	01c6e6b3          	or	a3,a3,t3
    1ec2:	0116e6b3          	or	a3,a3,a7
    1ec6:	03871e13          	slli	t3,a4,0x38
    1eca:	97aa                	add	a5,a5,a0
    1ecc:	ff837893          	andi	a7,t1,-8
    1ed0:	01c6e6b3          	or	a3,a3,t3
    1ed4:	98be                	add	a7,a7,a5
    1ed6:	e394                	sd	a3,0(a5)
    1ed8:	07a1                	addi	a5,a5,8
    1eda:	ff179ee3          	bne	a5,a7,1ed6 <memset+0xc4>
    1ede:	ff837893          	andi	a7,t1,-8
    1ee2:	011587b3          	add	a5,a1,a7
    1ee6:	010886bb          	addw	a3,a7,a6
    1eea:	0b130663          	beq	t1,a7,1f96 <memset+0x184>
    1eee:	00e78023          	sb	a4,0(a5)
    1ef2:	0016859b          	addiw	a1,a3,1
    1ef6:	08c5fb63          	bgeu	a1,a2,1f8c <memset+0x17a>
    1efa:	00e780a3          	sb	a4,1(a5)
    1efe:	0026859b          	addiw	a1,a3,2
    1f02:	08c5f563          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f06:	00e78123          	sb	a4,2(a5)
    1f0a:	0036859b          	addiw	a1,a3,3
    1f0e:	06c5ff63          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f12:	00e781a3          	sb	a4,3(a5)
    1f16:	0046859b          	addiw	a1,a3,4
    1f1a:	06c5f963          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f1e:	00e78223          	sb	a4,4(a5)
    1f22:	0056859b          	addiw	a1,a3,5
    1f26:	06c5f363          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f2a:	00e782a3          	sb	a4,5(a5)
    1f2e:	0066859b          	addiw	a1,a3,6
    1f32:	04c5fd63          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f36:	00e78323          	sb	a4,6(a5)
    1f3a:	0076859b          	addiw	a1,a3,7
    1f3e:	04c5f763          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f42:	00e783a3          	sb	a4,7(a5)
    1f46:	0086859b          	addiw	a1,a3,8
    1f4a:	04c5f163          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f4e:	00e78423          	sb	a4,8(a5)
    1f52:	0096859b          	addiw	a1,a3,9
    1f56:	02c5fb63          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f5a:	00e784a3          	sb	a4,9(a5)
    1f5e:	00a6859b          	addiw	a1,a3,10
    1f62:	02c5f563          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f66:	00e78523          	sb	a4,10(a5)
    1f6a:	00b6859b          	addiw	a1,a3,11
    1f6e:	00c5ff63          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f72:	00e785a3          	sb	a4,11(a5)
    1f76:	00c6859b          	addiw	a1,a3,12
    1f7a:	00c5f963          	bgeu	a1,a2,1f8c <memset+0x17a>
    1f7e:	00e78623          	sb	a4,12(a5)
    1f82:	26b5                	addiw	a3,a3,13
    1f84:	00c6f463          	bgeu	a3,a2,1f8c <memset+0x17a>
    1f88:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1f8c:	8082                	ret
    1f8e:	46ad                	li	a3,11
    1f90:	bd79                	j	1e2e <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f92:	480d                	li	a6,3
    1f94:	b701                	j	1e94 <memset+0x82>
    1f96:	8082                	ret
    1f98:	4805                	li	a6,1
    1f9a:	bded                	j	1e94 <memset+0x82>
    1f9c:	85aa                	mv	a1,a0
    1f9e:	4801                	li	a6,0
    1fa0:	bdd5                	j	1e94 <memset+0x82>
    1fa2:	87aa                	mv	a5,a0
    1fa4:	4681                	li	a3,0
    1fa6:	b7a1                	j	1eee <memset+0xdc>
    1fa8:	4809                	li	a6,2
    1faa:	b5ed                	j	1e94 <memset+0x82>
    1fac:	4811                	li	a6,4
    1fae:	b5dd                	j	1e94 <memset+0x82>
    1fb0:	4815                	li	a6,5
    1fb2:	b5cd                	j	1e94 <memset+0x82>
    1fb4:	4819                	li	a6,6
    1fb6:	bdf9                	j	1e94 <memset+0x82>

0000000000001fb8 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1fb8:	00054783          	lbu	a5,0(a0)
    1fbc:	0005c703          	lbu	a4,0(a1)
    1fc0:	00e79863          	bne	a5,a4,1fd0 <strcmp+0x18>
    1fc4:	0505                	addi	a0,a0,1
    1fc6:	0585                	addi	a1,a1,1
    1fc8:	fbe5                	bnez	a5,1fb8 <strcmp>
    1fca:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1fcc:	9d19                	subw	a0,a0,a4
    1fce:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1fd0:	0007851b          	sext.w	a0,a5
    1fd4:	bfe5                	j	1fcc <strcmp+0x14>

0000000000001fd6 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1fd6:	ca15                	beqz	a2,200a <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fd8:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1fdc:	167d                	addi	a2,a2,-1
    1fde:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1fe2:	eb99                	bnez	a5,1ff8 <strncmp+0x22>
    1fe4:	a815                	j	2018 <strncmp+0x42>
    1fe6:	00a68e63          	beq	a3,a0,2002 <strncmp+0x2c>
    1fea:	0505                	addi	a0,a0,1
    1fec:	00f71b63          	bne	a4,a5,2002 <strncmp+0x2c>
    1ff0:	00054783          	lbu	a5,0(a0)
    1ff4:	cf89                	beqz	a5,200e <strncmp+0x38>
    1ff6:	85b2                	mv	a1,a2
    1ff8:	0005c703          	lbu	a4,0(a1)
    1ffc:	00158613          	addi	a2,a1,1
    2000:	f37d                	bnez	a4,1fe6 <strncmp+0x10>
		;
	return *l - *r;
    2002:	0007851b          	sext.w	a0,a5
    2006:	9d19                	subw	a0,a0,a4
    2008:	8082                	ret
		return 0;
    200a:	4501                	li	a0,0
}
    200c:	8082                	ret
	return *l - *r;
    200e:	0015c703          	lbu	a4,1(a1)
    2012:	4501                	li	a0,0
    2014:	9d19                	subw	a0,a0,a4
    2016:	8082                	ret
    2018:	0005c703          	lbu	a4,0(a1)
    201c:	4501                	li	a0,0
    201e:	b7e5                	j	2006 <strncmp+0x30>

0000000000002020 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    2020:	00757793          	andi	a5,a0,7
    2024:	cf89                	beqz	a5,203e <strlen+0x1e>
    2026:	87aa                	mv	a5,a0
    2028:	a029                	j	2032 <strlen+0x12>
    202a:	0785                	addi	a5,a5,1
    202c:	0077f713          	andi	a4,a5,7
    2030:	cb01                	beqz	a4,2040 <strlen+0x20>
		if (!*s)
    2032:	0007c703          	lbu	a4,0(a5)
    2036:	fb75                	bnez	a4,202a <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2038:	40a78533          	sub	a0,a5,a0
}
    203c:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    203e:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2040:	6394                	ld	a3,0(a5)
    2042:	00001597          	auipc	a1,0x1
    2046:	94e5b583          	ld	a1,-1714(a1) # 2990 <enable_deadlock_detect+0x1d2>
    204a:	00001617          	auipc	a2,0x1
    204e:	94e63603          	ld	a2,-1714(a2) # 2998 <enable_deadlock_detect+0x1da>
    2052:	a019                	j	2058 <strlen+0x38>
    2054:	6794                	ld	a3,8(a5)
    2056:	07a1                	addi	a5,a5,8
    2058:	00b68733          	add	a4,a3,a1
    205c:	fff6c693          	not	a3,a3
    2060:	8f75                	and	a4,a4,a3
    2062:	8f71                	and	a4,a4,a2
    2064:	db65                	beqz	a4,2054 <strlen+0x34>
	for (; *s; s++)
    2066:	0007c703          	lbu	a4,0(a5)
    206a:	d779                	beqz	a4,2038 <strlen+0x18>
    206c:	0017c703          	lbu	a4,1(a5)
    2070:	0785                	addi	a5,a5,1
    2072:	d379                	beqz	a4,2038 <strlen+0x18>
    2074:	0017c703          	lbu	a4,1(a5)
    2078:	0785                	addi	a5,a5,1
    207a:	fb6d                	bnez	a4,206c <strlen+0x4c>
    207c:	bf75                	j	2038 <strlen+0x18>

000000000000207e <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    207e:	00757713          	andi	a4,a0,7
{
    2082:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2084:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2088:	cb19                	beqz	a4,209e <memchr+0x20>
    208a:	ce25                	beqz	a2,2102 <memchr+0x84>
    208c:	0007c703          	lbu	a4,0(a5)
    2090:	04b70e63          	beq	a4,a1,20ec <memchr+0x6e>
    2094:	0785                	addi	a5,a5,1
    2096:	0077f713          	andi	a4,a5,7
    209a:	167d                	addi	a2,a2,-1
    209c:	f77d                	bnez	a4,208a <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    209e:	4501                	li	a0,0
	if (n && *s != c) {
    20a0:	c235                	beqz	a2,2104 <memchr+0x86>
    20a2:	0007c703          	lbu	a4,0(a5)
    20a6:	04b70363          	beq	a4,a1,20ec <memchr+0x6e>
		size_t k = ONES * c;
    20aa:	00001517          	auipc	a0,0x1
    20ae:	8f653503          	ld	a0,-1802(a0) # 29a0 <enable_deadlock_detect+0x1e2>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20b2:	471d                	li	a4,7
		size_t k = ONES * c;
    20b4:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20b8:	02c77a63          	bgeu	a4,a2,20ec <memchr+0x6e>
    20bc:	00001897          	auipc	a7,0x1
    20c0:	8d48b883          	ld	a7,-1836(a7) # 2990 <enable_deadlock_detect+0x1d2>
    20c4:	00001817          	auipc	a6,0x1
    20c8:	8d483803          	ld	a6,-1836(a6) # 2998 <enable_deadlock_detect+0x1da>
    20cc:	431d                	li	t1,7
    20ce:	a029                	j	20d8 <memchr+0x5a>
		     w++, n -= SS)
    20d0:	1661                	addi	a2,a2,-8
    20d2:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    20d4:	02c37963          	bgeu	t1,a2,2106 <memchr+0x88>
    20d8:	6398                	ld	a4,0(a5)
    20da:	8f29                	xor	a4,a4,a0
    20dc:	011706b3          	add	a3,a4,a7
    20e0:	fff74713          	not	a4,a4
    20e4:	8f75                	and	a4,a4,a3
    20e6:	01077733          	and	a4,a4,a6
    20ea:	d37d                	beqz	a4,20d0 <memchr+0x52>
{
    20ec:	853e                	mv	a0,a5
    20ee:	97b2                	add	a5,a5,a2
    20f0:	a021                	j	20f8 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    20f2:	0505                	addi	a0,a0,1
    20f4:	00f50763          	beq	a0,a5,2102 <memchr+0x84>
    20f8:	00054703          	lbu	a4,0(a0)
    20fc:	feb71be3          	bne	a4,a1,20f2 <memchr+0x74>
    2100:	8082                	ret
	return n ? (void *)s : 0;
    2102:	4501                	li	a0,0
}
    2104:	8082                	ret
	return n ? (void *)s : 0;
    2106:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2108:	f275                	bnez	a2,20ec <memchr+0x6e>
}
    210a:	8082                	ret

000000000000210c <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    210c:	1101                	addi	sp,sp,-32
    210e:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2110:	862e                	mv	a2,a1
{
    2112:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2114:	4581                	li	a1,0
{
    2116:	e426                	sd	s1,8(sp)
    2118:	ec06                	sd	ra,24(sp)
    211a:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    211c:	f63ff0ef          	jal	ra,207e <memchr>
	return p ? p - s : n;
    2120:	c519                	beqz	a0,212e <strnlen+0x22>
}
    2122:	60e2                	ld	ra,24(sp)
    2124:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2126:	8d05                	sub	a0,a0,s1
}
    2128:	64a2                	ld	s1,8(sp)
    212a:	6105                	addi	sp,sp,32
    212c:	8082                	ret
    212e:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2130:	8522                	mv	a0,s0
}
    2132:	6442                	ld	s0,16(sp)
    2134:	64a2                	ld	s1,8(sp)
    2136:	6105                	addi	sp,sp,32
    2138:	8082                	ret

000000000000213a <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    213a:	00a5c7b3          	xor	a5,a1,a0
    213e:	8b9d                	andi	a5,a5,7
    2140:	eb95                	bnez	a5,2174 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2142:	0075f793          	andi	a5,a1,7
    2146:	e7b1                	bnez	a5,2192 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2148:	6198                	ld	a4,0(a1)
    214a:	00001617          	auipc	a2,0x1
    214e:	84663603          	ld	a2,-1978(a2) # 2990 <enable_deadlock_detect+0x1d2>
    2152:	00001817          	auipc	a6,0x1
    2156:	84683803          	ld	a6,-1978(a6) # 2998 <enable_deadlock_detect+0x1da>
    215a:	a029                	j	2164 <stpcpy+0x2a>
    215c:	05a1                	addi	a1,a1,8
    215e:	e118                	sd	a4,0(a0)
    2160:	6198                	ld	a4,0(a1)
    2162:	0521                	addi	a0,a0,8
    2164:	00c707b3          	add	a5,a4,a2
    2168:	fff74693          	not	a3,a4
    216c:	8ff5                	and	a5,a5,a3
    216e:	0107f7b3          	and	a5,a5,a6
    2172:	d7ed                	beqz	a5,215c <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2174:	0005c783          	lbu	a5,0(a1)
    2178:	00f50023          	sb	a5,0(a0)
    217c:	c785                	beqz	a5,21a4 <stpcpy+0x6a>
    217e:	0015c783          	lbu	a5,1(a1)
    2182:	0505                	addi	a0,a0,1
    2184:	0585                	addi	a1,a1,1
    2186:	00f50023          	sb	a5,0(a0)
    218a:	fbf5                	bnez	a5,217e <stpcpy+0x44>
		;
	return d;
}
    218c:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    218e:	0505                	addi	a0,a0,1
    2190:	df45                	beqz	a4,2148 <stpcpy+0xe>
			if (!(*d = *s))
    2192:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2196:	0585                	addi	a1,a1,1
    2198:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    219c:	00f50023          	sb	a5,0(a0)
    21a0:	f7fd                	bnez	a5,218e <stpcpy+0x54>
}
    21a2:	8082                	ret
    21a4:	8082                	ret

00000000000021a6 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    21a6:	00a5c7b3          	xor	a5,a1,a0
    21aa:	8b9d                	andi	a5,a5,7
    21ac:	1a079863          	bnez	a5,235c <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    21b0:	0075f793          	andi	a5,a1,7
    21b4:	16078463          	beqz	a5,231c <stpncpy+0x176>
    21b8:	ea01                	bnez	a2,21c8 <stpncpy+0x22>
    21ba:	a421                	j	23c2 <stpncpy+0x21c>
    21bc:	167d                	addi	a2,a2,-1
    21be:	0505                	addi	a0,a0,1
    21c0:	14070e63          	beqz	a4,231c <stpncpy+0x176>
    21c4:	1a060863          	beqz	a2,2374 <stpncpy+0x1ce>
    21c8:	0005c783          	lbu	a5,0(a1)
    21cc:	0585                	addi	a1,a1,1
    21ce:	0075f713          	andi	a4,a1,7
    21d2:	00f50023          	sb	a5,0(a0)
    21d6:	f3fd                	bnez	a5,21bc <stpncpy+0x16>
    21d8:	4805                	li	a6,1
    21da:	1a061863          	bnez	a2,238a <stpncpy+0x1e4>
    21de:	40a007b3          	neg	a5,a0
    21e2:	8b9d                	andi	a5,a5,7
    21e4:	4681                	li	a3,0
    21e6:	18061a63          	bnez	a2,237a <stpncpy+0x1d4>
    21ea:	00778713          	addi	a4,a5,7
    21ee:	45ad                	li	a1,11
    21f0:	18b76363          	bltu	a4,a1,2376 <stpncpy+0x1d0>
    21f4:	1ae6eb63          	bltu	a3,a4,23aa <stpncpy+0x204>
    21f8:	1a078363          	beqz	a5,239e <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    21fc:	00050023          	sb	zero,0(a0)
    2200:	4685                	li	a3,1
    2202:	00150713          	addi	a4,a0,1
    2206:	18d78f63          	beq	a5,a3,23a4 <stpncpy+0x1fe>
    220a:	000500a3          	sb	zero,1(a0)
    220e:	4689                	li	a3,2
    2210:	00250713          	addi	a4,a0,2
    2214:	18d78e63          	beq	a5,a3,23b0 <stpncpy+0x20a>
    2218:	00050123          	sb	zero,2(a0)
    221c:	468d                	li	a3,3
    221e:	00350713          	addi	a4,a0,3
    2222:	16d78c63          	beq	a5,a3,239a <stpncpy+0x1f4>
    2226:	000501a3          	sb	zero,3(a0)
    222a:	4691                	li	a3,4
    222c:	00450713          	addi	a4,a0,4
    2230:	18d78263          	beq	a5,a3,23b4 <stpncpy+0x20e>
    2234:	00050223          	sb	zero,4(a0)
    2238:	4695                	li	a3,5
    223a:	00550713          	addi	a4,a0,5
    223e:	16d78d63          	beq	a5,a3,23b8 <stpncpy+0x212>
    2242:	000502a3          	sb	zero,5(a0)
    2246:	469d                	li	a3,7
    2248:	00650713          	addi	a4,a0,6
    224c:	16d79863          	bne	a5,a3,23bc <stpncpy+0x216>
    2250:	00750713          	addi	a4,a0,7
    2254:	00050323          	sb	zero,6(a0)
    2258:	40f80833          	sub	a6,a6,a5
    225c:	ff887593          	andi	a1,a6,-8
    2260:	97aa                	add	a5,a5,a0
    2262:	95be                	add	a1,a1,a5
    2264:	0007b023          	sd	zero,0(a5)
    2268:	07a1                	addi	a5,a5,8
    226a:	feb79de3          	bne	a5,a1,2264 <stpncpy+0xbe>
    226e:	ff887593          	andi	a1,a6,-8
    2272:	9ead                	addw	a3,a3,a1
    2274:	00b707b3          	add	a5,a4,a1
    2278:	12b80863          	beq	a6,a1,23a8 <stpncpy+0x202>
    227c:	00078023          	sb	zero,0(a5)
    2280:	0016871b          	addiw	a4,a3,1
    2284:	0ec77863          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    2288:	000780a3          	sb	zero,1(a5)
    228c:	0026871b          	addiw	a4,a3,2
    2290:	0ec77263          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    2294:	00078123          	sb	zero,2(a5)
    2298:	0036871b          	addiw	a4,a3,3
    229c:	0cc77c63          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22a0:	000781a3          	sb	zero,3(a5)
    22a4:	0046871b          	addiw	a4,a3,4
    22a8:	0cc77663          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22ac:	00078223          	sb	zero,4(a5)
    22b0:	0056871b          	addiw	a4,a3,5
    22b4:	0cc77063          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22b8:	000782a3          	sb	zero,5(a5)
    22bc:	0066871b          	addiw	a4,a3,6
    22c0:	0ac77a63          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22c4:	00078323          	sb	zero,6(a5)
    22c8:	0076871b          	addiw	a4,a3,7
    22cc:	0ac77463          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22d0:	000783a3          	sb	zero,7(a5)
    22d4:	0086871b          	addiw	a4,a3,8
    22d8:	08c77e63          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22dc:	00078423          	sb	zero,8(a5)
    22e0:	0096871b          	addiw	a4,a3,9
    22e4:	08c77863          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22e8:	000784a3          	sb	zero,9(a5)
    22ec:	00a6871b          	addiw	a4,a3,10
    22f0:	08c77263          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    22f4:	00078523          	sb	zero,10(a5)
    22f8:	00b6871b          	addiw	a4,a3,11
    22fc:	06c77c63          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    2300:	000785a3          	sb	zero,11(a5)
    2304:	00c6871b          	addiw	a4,a3,12
    2308:	06c77663          	bgeu	a4,a2,2374 <stpncpy+0x1ce>
    230c:	00078623          	sb	zero,12(a5)
    2310:	26b5                	addiw	a3,a3,13
    2312:	06c6f163          	bgeu	a3,a2,2374 <stpncpy+0x1ce>
    2316:	000786a3          	sb	zero,13(a5)
    231a:	8082                	ret
			;
		if (!n || !*s)
    231c:	c645                	beqz	a2,23c4 <stpncpy+0x21e>
    231e:	0005c783          	lbu	a5,0(a1)
    2322:	ea078be3          	beqz	a5,21d8 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2326:	479d                	li	a5,7
    2328:	02c7ff63          	bgeu	a5,a2,2366 <stpncpy+0x1c0>
    232c:	00000897          	auipc	a7,0x0
    2330:	6648b883          	ld	a7,1636(a7) # 2990 <enable_deadlock_detect+0x1d2>
    2334:	00000817          	auipc	a6,0x0
    2338:	66483803          	ld	a6,1636(a6) # 2998 <enable_deadlock_detect+0x1da>
    233c:	431d                	li	t1,7
    233e:	6198                	ld	a4,0(a1)
    2340:	011707b3          	add	a5,a4,a7
    2344:	fff74693          	not	a3,a4
    2348:	8ff5                	and	a5,a5,a3
    234a:	0107f7b3          	and	a5,a5,a6
    234e:	ef81                	bnez	a5,2366 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2350:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2352:	1661                	addi	a2,a2,-8
    2354:	05a1                	addi	a1,a1,8
    2356:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2358:	fec363e3          	bltu	t1,a2,233e <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    235c:	e609                	bnez	a2,2366 <stpncpy+0x1c0>
    235e:	a08d                	j	23c0 <stpncpy+0x21a>
    2360:	167d                	addi	a2,a2,-1
    2362:	0505                	addi	a0,a0,1
    2364:	ca01                	beqz	a2,2374 <stpncpy+0x1ce>
    2366:	0005c783          	lbu	a5,0(a1)
    236a:	0585                	addi	a1,a1,1
    236c:	00f50023          	sb	a5,0(a0)
    2370:	fbe5                	bnez	a5,2360 <stpncpy+0x1ba>
		;
tail:
    2372:	b59d                	j	21d8 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2374:	8082                	ret
    2376:	472d                	li	a4,11
    2378:	bdb5                	j	21f4 <stpncpy+0x4e>
    237a:	00778713          	addi	a4,a5,7
    237e:	45ad                	li	a1,11
    2380:	fff60693          	addi	a3,a2,-1
    2384:	e6b778e3          	bgeu	a4,a1,21f4 <stpncpy+0x4e>
    2388:	b7fd                	j	2376 <stpncpy+0x1d0>
    238a:	40a007b3          	neg	a5,a0
    238e:	8832                	mv	a6,a2
    2390:	8b9d                	andi	a5,a5,7
    2392:	4681                	li	a3,0
    2394:	e4060be3          	beqz	a2,21ea <stpncpy+0x44>
    2398:	b7cd                	j	237a <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    239a:	468d                	li	a3,3
    239c:	bd75                	j	2258 <stpncpy+0xb2>
    239e:	872a                	mv	a4,a0
    23a0:	4681                	li	a3,0
    23a2:	bd5d                	j	2258 <stpncpy+0xb2>
    23a4:	4685                	li	a3,1
    23a6:	bd4d                	j	2258 <stpncpy+0xb2>
    23a8:	8082                	ret
    23aa:	87aa                	mv	a5,a0
    23ac:	4681                	li	a3,0
    23ae:	b5f9                	j	227c <stpncpy+0xd6>
    23b0:	4689                	li	a3,2
    23b2:	b55d                	j	2258 <stpncpy+0xb2>
    23b4:	4691                	li	a3,4
    23b6:	b54d                	j	2258 <stpncpy+0xb2>
    23b8:	4695                	li	a3,5
    23ba:	bd79                	j	2258 <stpncpy+0xb2>
    23bc:	4699                	li	a3,6
    23be:	bd69                	j	2258 <stpncpy+0xb2>
    23c0:	8082                	ret
    23c2:	8082                	ret
    23c4:	8082                	ret

00000000000023c6 <basename>:

char *basename(char *s)
{
    23c6:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    23c8:	c54d                	beqz	a0,2472 <basename+0xac>
    23ca:	00054783          	lbu	a5,0(a0)
		return ".";
    23ce:	00000517          	auipc	a0,0x0
    23d2:	5ba50513          	addi	a0,a0,1466 # 2988 <enable_deadlock_detect+0x1ca>
	if (!s || !*s)
    23d6:	e391                	bnez	a5,23da <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    23d8:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    23da:	0076f713          	andi	a4,a3,7
    23de:	87b6                	mv	a5,a3
    23e0:	cf51                	beqz	a4,247c <basename+0xb6>
    23e2:	0785                	addi	a5,a5,1
    23e4:	0077f713          	andi	a4,a5,7
    23e8:	c729                	beqz	a4,2432 <basename+0x6c>
		if (!*s)
    23ea:	0007c703          	lbu	a4,0(a5)
    23ee:	fb75                	bnez	a4,23e2 <basename+0x1c>
	return s - a;
    23f0:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    23f2:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    23f4:	cf8d                	beqz	a5,242e <basename+0x68>
    23f6:	00f68733          	add	a4,a3,a5
    23fa:	02f00593          	li	a1,47
    23fe:	a031                	j	240a <basename+0x44>
		s[i] = 0;
    2400:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2404:	17fd                	addi	a5,a5,-1
    2406:	177d                	addi	a4,a4,-1
    2408:	c39d                	beqz	a5,242e <basename+0x68>
    240a:	00074603          	lbu	a2,0(a4)
    240e:	feb609e3          	beq	a2,a1,2400 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2412:	02f00613          	li	a2,47
    2416:	a011                	j	241a <basename+0x54>
    2418:	cb99                	beqz	a5,242e <basename+0x68>
    241a:	853e                	mv	a0,a5
    241c:	17fd                	addi	a5,a5,-1
    241e:	00f68733          	add	a4,a3,a5
    2422:	00074703          	lbu	a4,0(a4)
    2426:	fec719e3          	bne	a4,a2,2418 <basename+0x52>
	return s + i;
    242a:	9536                	add	a0,a0,a3
    242c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    242e:	8536                	mv	a0,a3
    2430:	8082                	ret
    2432:	6390                	ld	a2,0(a5)
    2434:	00000517          	auipc	a0,0x0
    2438:	55c53503          	ld	a0,1372(a0) # 2990 <enable_deadlock_detect+0x1d2>
    243c:	00000597          	auipc	a1,0x0
    2440:	55c5b583          	ld	a1,1372(a1) # 2998 <enable_deadlock_detect+0x1da>
    2444:	fff64713          	not	a4,a2
    2448:	962a                	add	a2,a2,a0
    244a:	8f71                	and	a4,a4,a2
    244c:	8f6d                	and	a4,a4,a1
    244e:	eb11                	bnez	a4,2462 <basename+0x9c>
    2450:	6790                	ld	a2,8(a5)
    2452:	07a1                	addi	a5,a5,8
    2454:	00a60733          	add	a4,a2,a0
    2458:	fff64613          	not	a2,a2
    245c:	8f71                	and	a4,a4,a2
    245e:	8f6d                	and	a4,a4,a1
    2460:	db65                	beqz	a4,2450 <basename+0x8a>
	for (; *s; s++)
    2462:	0007c703          	lbu	a4,0(a5)
    2466:	d749                	beqz	a4,23f0 <basename+0x2a>
    2468:	0017c703          	lbu	a4,1(a5)
    246c:	0785                	addi	a5,a5,1
    246e:	ff6d                	bnez	a4,2468 <basename+0xa2>
    2470:	b741                	j	23f0 <basename+0x2a>
		return ".";
    2472:	00000517          	auipc	a0,0x0
    2476:	51650513          	addi	a0,a0,1302 # 2988 <enable_deadlock_detect+0x1ca>
    247a:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    247c:	6290                	ld	a2,0(a3)
    247e:	00000517          	auipc	a0,0x0
    2482:	51253503          	ld	a0,1298(a0) # 2990 <enable_deadlock_detect+0x1d2>
    2486:	00000597          	auipc	a1,0x0
    248a:	5125b583          	ld	a1,1298(a1) # 2998 <enable_deadlock_detect+0x1da>
    248e:	fff64713          	not	a4,a2
    2492:	962a                	add	a2,a2,a0
    2494:	8f71                	and	a4,a4,a2
    2496:	8f6d                	and	a4,a4,a1
    2498:	df45                	beqz	a4,2450 <basename+0x8a>
    249a:	b7f9                	j	2468 <basename+0xa2>

000000000000249c <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    249c:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    24a0:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24a2:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    24a6:	2501                	sext.w	a0,a0
    24a8:	8082                	ret

00000000000024aa <close>:

int close(int fd)
{
	if (fd == 1) {
    24aa:	4785                	li	a5,1
    24ac:	00f50863          	beq	a0,a5,24bc <close+0x12>
	register long a7 __asm__("a7") = n;
    24b0:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24b4:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    24b8:	2501                	sext.w	a0,a0
    24ba:	8082                	ret
{
    24bc:	1101                	addi	sp,sp,-32
    24be:	ec06                	sd	ra,24(sp)
    24c0:	e42a                	sd	a0,8(sp)
		__write_buffer();
    24c2:	cdffe0ef          	jal	ra,11a0 <__write_buffer>
		__clear_buffer();
    24c6:	d03fe0ef          	jal	ra,11c8 <__clear_buffer>
    24ca:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    24cc:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    24d0:	00000073          	ecall
}
    24d4:	60e2                	ld	ra,24(sp)
    24d6:	2501                	sext.w	a0,a0
    24d8:	6105                	addi	sp,sp,32
    24da:	8082                	ret

00000000000024dc <read>:
	register long a7 __asm__("a7") = n;
    24dc:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24e0:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    24e4:	8082                	ret

00000000000024e6 <write>:
	register long a7 __asm__("a7") = n;
    24e6:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    24ea:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    24ee:	8082                	ret

00000000000024f0 <getpid>:
	register long a7 __asm__("a7") = n;
    24f0:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    24f4:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    24f8:	2501                	sext.w	a0,a0
    24fa:	8082                	ret

00000000000024fc <getppid>:
	register long a7 __asm__("a7") = n;
    24fc:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2500:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2504:	2501                	sext.w	a0,a0
    2506:	8082                	ret

0000000000002508 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2508:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    250c:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2510:	2501                	sext.w	a0,a0
    2512:	8082                	ret

0000000000002514 <fork>:
	register long a7 __asm__("a7") = n;
    2514:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2518:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    251c:	2501                	sext.w	a0,a0
    251e:	8082                	ret

0000000000002520 <exit>:

void exit(int code)
{
    2520:	1141                	addi	sp,sp,-16
    2522:	e406                	sd	ra,8(sp)
    2524:	e022                	sd	s0,0(sp)
    2526:	842a                	mv	s0,a0
	__write_buffer();
    2528:	c79fe0ef          	jal	ra,11a0 <__write_buffer>
	__clear_buffer();
    252c:	c9dfe0ef          	jal	ra,11c8 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2530:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2534:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2536:	00000073          	ecall
	syscall(SYS_exit, code);
}
    253a:	60a2                	ld	ra,8(sp)
    253c:	6402                	ld	s0,0(sp)
    253e:	0141                	addi	sp,sp,16
    2540:	8082                	ret

0000000000002542 <waitpid>:
	register long a7 __asm__("a7") = n;
    2542:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2546:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    254a:	2501                	sext.w	a0,a0
    254c:	8082                	ret

000000000000254e <exec>:
	register long a7 __asm__("a7") = n;
    254e:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2552:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2556:	2501                	sext.w	a0,a0
    2558:	8082                	ret

000000000000255a <get_mtime>:

int64 get_mtime()
{
    255a:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    255c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2560:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2562:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2564:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2568:	2501                	sext.w	a0,a0
    256a:	ed01                	bnez	a0,2582 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    256c:	6722                	ld	a4,8(sp)
    256e:	3e800793          	li	a5,1000
    2572:	6682                	ld	a3,0(sp)
    2574:	02f75733          	divu	a4,a4,a5
    2578:	02d78533          	mul	a0,a5,a3
    257c:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    257e:	0141                	addi	sp,sp,16
    2580:	8082                	ret
	return -1;
    2582:	557d                	li	a0,-1
    2584:	bfed                	j	257e <get_mtime+0x24>

0000000000002586 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2586:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    258a:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    258e:	2501                	sext.w	a0,a0
    2590:	8082                	ret

0000000000002592 <sleep>:

int sleep(unsigned long long time)
{
    2592:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2594:	880a                	mv	a6,sp
{
    2596:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2598:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    259c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    259e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25a0:	00000073          	ecall
	if (err == 0) {
    25a4:	2501                	sext.w	a0,a0
    25a6:	ed31                	bnez	a0,2602 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    25a8:	6722                	ld	a4,8(sp)
    25aa:	3e800793          	li	a5,1000
    25ae:	6682                	ld	a3,0(sp)
    25b0:	02f75733          	divu	a4,a4,a5
    25b4:	02d787b3          	mul	a5,a5,a3
    25b8:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    25ba:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25be:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25c0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25c2:	00000073          	ecall
	if (err == 0) {
    25c6:	2501                	sext.w	a0,a0
    25c8:	e915                	bnez	a0,25fc <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    25ca:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    25cc:	3e800693          	li	a3,1000
    25d0:	a819                	j	25e6 <sleep+0x54>
	__asm_syscall("r"(a7))
    25d2:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    25d6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    25da:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    25dc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25de:	00000073          	ecall
	if (err == 0) {
    25e2:	2501                	sext.w	a0,a0
    25e4:	ed01                	bnez	a0,25fc <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    25e6:	6722                	ld	a4,8(sp)
    25e8:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    25ea:	07c00893          	li	a7,124
    25ee:	02d75733          	divu	a4,a4,a3
    25f2:	02f687b3          	mul	a5,a3,a5
    25f6:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    25f8:	fcc7ede3          	bltu	a5,a2,25d2 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    25fc:	4501                	li	a0,0
    25fe:	0141                	addi	sp,sp,16
    2600:	8082                	ret
    2602:	57fd                	li	a5,-1
    2604:	bf5d                	j	25ba <sleep+0x28>

0000000000002606 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2606:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    260a:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    260e:	2501                	sext.w	a0,a0
    2610:	8082                	ret

0000000000002612 <set_priority>:
	register long a7 __asm__("a7") = n;
    2612:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2616:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    261a:	2501                	sext.w	a0,a0
    261c:	8082                	ret

000000000000261e <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    261e:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2622:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2626:	2501                	sext.w	a0,a0
    2628:	8082                	ret

000000000000262a <munmap>:
	register long a7 __asm__("a7") = n;
    262a:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    262e:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2632:	2501                	sext.w	a0,a0
    2634:	8082                	ret

0000000000002636 <wait>:

int wait(int *code)
{
    2636:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2638:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    263c:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    263e:	00000073          	ecall
	return waitpid(-1, code);
}
    2642:	2501                	sext.w	a0,a0
    2644:	8082                	ret

0000000000002646 <spawn>:
	register long a7 __asm__("a7") = n;
    2646:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    264a:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    264e:	2501                	sext.w	a0,a0
    2650:	8082                	ret

0000000000002652 <pipe>:
	register long a7 __asm__("a7") = n;
    2652:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2656:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    265a:	2501                	sext.w	a0,a0
    265c:	8082                	ret

000000000000265e <mailread>:
	register long a7 __asm__("a7") = n;
    265e:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2662:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2666:	2501                	sext.w	a0,a0
    2668:	8082                	ret

000000000000266a <mailwrite>:
	register long a7 __asm__("a7") = n;
    266a:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    266e:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2672:	2501                	sext.w	a0,a0
    2674:	8082                	ret

0000000000002676 <fstat>:
	register long a7 __asm__("a7") = n;
    2676:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    267a:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    267e:	2501                	sext.w	a0,a0
    2680:	8082                	ret

0000000000002682 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    2682:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2684:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2688:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    268a:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    268e:	2501                	sext.w	a0,a0
    2690:	8082                	ret

0000000000002692 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    2692:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2694:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2698:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    269a:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    269e:	2501                	sext.w	a0,a0
    26a0:	8082                	ret

00000000000026a2 <link>:

int link(char *old_path, char *new_path)
{
    26a2:	87aa                	mv	a5,a0
    26a4:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    26a6:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    26aa:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    26ae:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    26b0:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    26b4:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    26b6:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <unlink>:

int unlink(char *path)
{
    26be:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    26c0:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    26c4:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    26c8:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    26ca:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    26ce:	2501                	sext.w	a0,a0
    26d0:	8082                	ret

00000000000026d2 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    26d2:	00000797          	auipc	a5,0x0
    26d6:	4067b783          	ld	a5,1030(a5) # 2ad8 <_GLOBAL_OFFSET_TABLE_+0x8>
    26da:	439c                	lw	a5,0(a5)
    26dc:	c799                	beqz	a5,26ea <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    26de:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26e2:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    26e6:	2501                	sext.w	a0,a0
    26e8:	8082                	ret
{
    26ea:	1101                	addi	sp,sp,-32
    26ec:	ec06                	sd	ra,24(sp)
    26ee:	e42e                	sd	a1,8(sp)
    26f0:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    26f2:	fe7fe0ef          	jal	ra,16d8 <enable_thread_io_buffer>
    26f6:	65a2                	ld	a1,8(sp)
    26f8:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    26fa:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26fe:	00000073          	ecall
}
    2702:	60e2                	ld	ra,24(sp)
    2704:	2501                	sext.w	a0,a0
    2706:	6105                	addi	sp,sp,32
    2708:	8082                	ret

000000000000270a <gettid>:
	register long a7 __asm__("a7") = n;
    270a:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    270e:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2712:	2501                	sext.w	a0,a0
    2714:	8082                	ret

0000000000002716 <waittid>:

int waittid(int tid)
{
    2716:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2718:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    271c:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2720:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2722:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2724:	00e51e63          	bne	a0,a4,2740 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2728:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    272c:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2730:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2734:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2736:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    273a:	2501                	sext.w	a0,a0
	while (ret == -2) {
    273c:	fee506e3          	beq	a0,a4,2728 <waittid+0x12>
	}
	return ret;
}
    2740:	8082                	ret

0000000000002742 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2742:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2746:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2748:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    274c:	2501                	sext.w	a0,a0
    274e:	8082                	ret

0000000000002750 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2750:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2754:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2756:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    275a:	2501                	sext.w	a0,a0
    275c:	8082                	ret

000000000000275e <mutex_lock>:
	register long a7 __asm__("a7") = n;
    275e:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2762:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2766:	2501                	sext.w	a0,a0
    2768:	8082                	ret

000000000000276a <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    276a:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    276e:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2772:	2501                	sext.w	a0,a0
    2774:	8082                	ret

0000000000002776 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2776:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    277a:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    277e:	2501                	sext.w	a0,a0
    2780:	8082                	ret

0000000000002782 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    2782:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2786:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    278a:	2501                	sext.w	a0,a0
    278c:	8082                	ret

000000000000278e <semaphore_down>:
	register long a7 __asm__("a7") = n;
    278e:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    2792:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2796:	2501                	sext.w	a0,a0
    2798:	8082                	ret

000000000000279a <condvar_create>:
	register long a7 __asm__("a7") = n;
    279a:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    279e:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    27a2:	2501                	sext.w	a0,a0
    27a4:	8082                	ret

00000000000027a6 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    27a6:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    27aa:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    27ae:	2501                	sext.w	a0,a0
    27b0:	8082                	ret

00000000000027b2 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    27b2:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27b6:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    27ba:	2501                	sext.w	a0,a0
    27bc:	8082                	ret

00000000000027be <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    27be:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    27c2:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    27c6:	2501                	sext.w	a0,a0
    27c8:	8082                	ret
