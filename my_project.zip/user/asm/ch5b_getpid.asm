
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch5b_getpid:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a045                	j	10a0 <__start_main>

0000000000001002 <main>:
理想结果：得到进程 pid，注意要关注 pid 是否符合内核逻辑，不要单纯以 Test OK!
作为判断。
*/

int main()
{
    1002:	7139                	addi	sp,sp,-64
    1004:	fc06                	sd	ra,56(sp)
    1006:	f822                	sd	s0,48(sp)
    1008:	f426                	sd	s1,40(sp)
    100a:	f04a                	sd	s2,32(sp)
    100c:	ec4e                	sd	s3,24(sp)
	int pid = getpid();
    100e:	41e010ef          	jal	ra,242c <getpid>
    1012:	842a                	mv	s0,a0
	int ppid = getppid();
    1014:	424010ef          	jal	ra,2438 <getppid>
    1018:	84aa                	mv	s1,a0
	if (fork() == 0) {
    101a:	436010ef          	jal	ra,2450 <fork>
    101e:	c50d                	beqz	a0,1048 <main+0x46>
		assert_eq(cppid, pid);
		printf("Test getppid OK!\n");
		exit(0);
	}
	int xstate = 0;
	wait(&xstate);
    1020:	0068                	addi	a0,sp,12
	int xstate = 0;
    1022:	c602                	sw	zero,12(sp)
	wait(&xstate);
    1024:	54e010ef          	jal	ra,2572 <wait>
	printf("Test getpid OK! pid = %d, ppid = %d\n", pid, ppid);
    1028:	8626                	mv	a2,s1
    102a:	85a2                	mv	a1,s0
    102c:	00001517          	auipc	a0,0x1
    1030:	77c50513          	addi	a0,a0,1916 # 27a8 <enable_deadlock_detect+0xae>
    1034:	1c6000ef          	jal	ra,11fa <printf>
	return 0;
    1038:	70e2                	ld	ra,56(sp)
    103a:	7442                	ld	s0,48(sp)
    103c:	74a2                	ld	s1,40(sp)
    103e:	7902                	ld	s2,32(sp)
    1040:	69e2                	ld	s3,24(sp)
    1042:	4501                	li	a0,0
    1044:	6121                	addi	sp,sp,64
    1046:	8082                	ret
		int cppid = getppid();
    1048:	3f0010ef          	jal	ra,2438 <getppid>
    104c:	892a                	mv	s2,a0
		assert_eq(cppid, pid);
    104e:	00a41c63          	bne	s0,a0,1066 <main+0x64>
		printf("Test getppid OK!\n");
    1052:	00001517          	auipc	a0,0x1
    1056:	73e50513          	addi	a0,a0,1854 # 2790 <enable_deadlock_detect+0x96>
    105a:	1a0000ef          	jal	ra,11fa <printf>
		exit(0);
    105e:	4501                	li	a0,0
    1060:	3fc010ef          	jal	ra,245c <exit>
    1064:	bf75                	j	1020 <main+0x1e>
		assert_eq(cppid, pid);
    1066:	3c6010ef          	jal	ra,242c <getpid>
    106a:	89aa                	mv	s3,a0
    106c:	00001517          	auipc	a0,0x1
    1070:	69c50513          	addi	a0,a0,1692 # 2708 <enable_deadlock_detect+0xe>
    1074:	28e010ef          	jal	ra,2302 <basename>
    1078:	872a                	mv	a4,a0
    107a:	88a2                	mv	a7,s0
    107c:	884a                	mv	a6,s2
    107e:	00001517          	auipc	a0,0x1
    1082:	6da50513          	addi	a0,a0,1754 # 2758 <enable_deadlock_detect+0x5e>
    1086:	47c1                	li	a5,16
    1088:	86ce                	mv	a3,s3
    108a:	00001617          	auipc	a2,0x1
    108e:	6c660613          	addi	a2,a2,1734 # 2750 <enable_deadlock_detect+0x56>
    1092:	45fd                	li	a1,31
    1094:	166000ef          	jal	ra,11fa <printf>
    1098:	557d                	li	a0,-1
    109a:	3c2010ef          	jal	ra,245c <exit>
    109e:	bf55                	j	1052 <main+0x50>

00000000000010a0 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    10a0:	1141                	addi	sp,sp,-16
    10a2:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    10a4:	f5fff0ef          	jal	ra,1002 <main>
    10a8:	3b4010ef          	jal	ra,245c <exit>
	return 0;
    10ac:	60a2                	ld	ra,8(sp)
    10ae:	4501                	li	a0,0
    10b0:	0141                	addi	sp,sp,16
    10b2:	8082                	ret

00000000000010b4 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    10b4:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    10b6:	4605                	li	a2,1
    10b8:	00f10593          	addi	a1,sp,15
    10bc:	4501                	li	a0,0
{
    10be:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10c0:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10c4:	354010ef          	jal	ra,2418 <read>
    10c8:	4785                	li	a5,1
    10ca:	00f51763          	bne	a0,a5,10d8 <getchar+0x24>
		return byte;
    10ce:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10d2:	60e2                	ld	ra,24(sp)
    10d4:	6105                	addi	sp,sp,32
    10d6:	8082                	ret
		return EOF;
    10d8:	557d                	li	a0,-1
    10da:	bfe5                	j	10d2 <getchar+0x1e>

00000000000010dc <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10dc:	00001517          	auipc	a0,0x1
    10e0:	7ec52503          	lw	a0,2028(a0) # 28c8 <buffer_len>
    10e4:	e111                	bnez	a0,10e8 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10e6:	8082                	ret
{
    10e8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10ea:	862a                	mv	a2,a0
    10ec:	00001597          	auipc	a1,0x1
    10f0:	7e458593          	addi	a1,a1,2020 # 28d0 <buffer>
    10f4:	4505                	li	a0,1
{
    10f6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10f8:	32a010ef          	jal	ra,2422 <write>
}
    10fc:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10fe:	2501                	sext.w	a0,a0
}
    1100:	0141                	addi	sp,sp,16
    1102:	8082                	ret

0000000000001104 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    1104:	00001797          	auipc	a5,0x1
    1108:	7c07a223          	sw	zero,1988(a5) # 28c8 <buffer_len>
}
    110c:	8082                	ret

000000000000110e <__fflush>:
	if (buffer_len == 0)
    110e:	00001517          	auipc	a0,0x1
    1112:	7ba52503          	lw	a0,1978(a0) # 28c8 <buffer_len>
    1116:	e511                	bnez	a0,1122 <__fflush+0x14>
	buffer_len = 0;
    1118:	00001797          	auipc	a5,0x1
    111c:	7a07a823          	sw	zero,1968(a5) # 28c8 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1120:	8082                	ret
{
    1122:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1124:	862a                	mv	a2,a0
    1126:	00001597          	auipc	a1,0x1
    112a:	7aa58593          	addi	a1,a1,1962 # 28d0 <buffer>
    112e:	4505                	li	a0,1
{
    1130:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1132:	2f0010ef          	jal	ra,2422 <write>
	return r >= 0 ? 0 : r;
    1136:	0005079b          	sext.w	a5,a0
}
    113a:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    113c:	0017a793          	slti	a5,a5,1
    1140:	40f007bb          	negw	a5,a5
    1144:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1146:	00001797          	auipc	a5,0x1
    114a:	7807a123          	sw	zero,1922(a5) # 28c8 <buffer_len>
	return r >= 0 ? 0 : r;
    114e:	2501                	sext.w	a0,a0
}
    1150:	0141                	addi	sp,sp,16
    1152:	8082                	ret

0000000000001154 <fflush>:

int fflush(int fd)
{
    1154:	1101                	addi	sp,sp,-32
    1156:	e822                	sd	s0,16(sp)
    1158:	ec06                	sd	ra,24(sp)
    115a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    115c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    115e:	4401                	li	s0,0
	if (fd == 1) {
    1160:	00e50863          	beq	a0,a4,1170 <fflush+0x1c>
}
    1164:	60e2                	ld	ra,24(sp)
    1166:	8522                	mv	a0,s0
    1168:	6442                	ld	s0,16(sp)
    116a:	64a2                	ld	s1,8(sp)
    116c:	6105                	addi	sp,sp,32
    116e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1170:	00001497          	auipc	s1,0x1
    1174:	75848493          	addi	s1,s1,1880 # 28c8 <buffer_len>
    1178:	1084a703          	lw	a4,264(s1)
    117c:	02a70e63          	beq	a4,a0,11b8 <fflush+0x64>
	if (buffer_len == 0)
    1180:	4080                	lw	s0,0(s1)
    1182:	c00d                	beqz	s0,11a4 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1184:	8622                	mv	a2,s0
    1186:	00001597          	auipc	a1,0x1
    118a:	74a58593          	addi	a1,a1,1866 # 28d0 <buffer>
    118e:	294010ef          	jal	ra,2422 <write>
	return r >= 0 ? 0 : r;
    1192:	0005079b          	sext.w	a5,a0
    1196:	0017a793          	slti	a5,a5,1
    119a:	40f007bb          	negw	a5,a5
    119e:	8d7d                	and	a0,a0,a5
    11a0:	0005041b          	sext.w	s0,a0
}
    11a4:	60e2                	ld	ra,24(sp)
    11a6:	8522                	mv	a0,s0
    11a8:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    11aa:	00001797          	auipc	a5,0x1
    11ae:	7007af23          	sw	zero,1822(a5) # 28c8 <buffer_len>
}
    11b2:	64a2                	ld	s1,8(sp)
    11b4:	6105                	addi	sp,sp,32
    11b6:	8082                	ret
			mutex_lock(buffer_lock);
    11b8:	10c4a503          	lw	a0,268(s1)
    11bc:	4de010ef          	jal	ra,269a <mutex_lock>
	if (buffer_len == 0)
    11c0:	4080                	lw	s0,0(s1)
    11c2:	e811                	bnez	s0,11d6 <fflush+0x82>
			mutex_unlock(buffer_lock);
    11c4:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11c8:	00001797          	auipc	a5,0x1
    11cc:	7007a023          	sw	zero,1792(a5) # 28c8 <buffer_len>
			mutex_unlock(buffer_lock);
    11d0:	4d6010ef          	jal	ra,26a6 <mutex_unlock>
    11d4:	bf41                	j	1164 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11d6:	8622                	mv	a2,s0
    11d8:	00001597          	auipc	a1,0x1
    11dc:	6f858593          	addi	a1,a1,1784 # 28d0 <buffer>
    11e0:	4505                	li	a0,1
    11e2:	240010ef          	jal	ra,2422 <write>
	return r >= 0 ? 0 : r;
    11e6:	0005079b          	sext.w	a5,a0
    11ea:	0017a793          	slti	a5,a5,1
    11ee:	40f007bb          	negw	a5,a5
    11f2:	8d7d                	and	a0,a0,a5
    11f4:	0005041b          	sext.w	s0,a0
	return r;
    11f8:	b7f1                	j	11c4 <fflush+0x70>

00000000000011fa <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11fa:	7131                	addi	sp,sp,-192
    11fc:	e0da                	sd	s6,64(sp)
    11fe:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1200:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    1202:	013c                	addi	a5,sp,136
{
    1204:	f0ca                	sd	s2,96(sp)
    1206:	ecce                	sd	s3,88(sp)
    1208:	e8d2                	sd	s4,80(sp)
    120a:	e4d6                	sd	s5,72(sp)
    120c:	fc86                	sd	ra,120(sp)
    120e:	f8a2                	sd	s0,112(sp)
    1210:	f4a6                	sd	s1,104(sp)
    1212:	89aa                	mv	s3,a0
    1214:	e52e                	sd	a1,136(sp)
    1216:	e932                	sd	a2,144(sp)
    1218:	ed36                	sd	a3,152(sp)
    121a:	f13a                	sd	a4,160(sp)
    121c:	f942                	sd	a6,176(sp)
    121e:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1220:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1222:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    1226:	00001a17          	auipc	s4,0x1
    122a:	6a2a0a13          	addi	s4,s4,1698 # 28c8 <buffer_len>
    122e:	4a85                	li	s5,1
	buf[i++] = '0';
    1230:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    1234:	0009c783          	lbu	a5,0(s3)
    1238:	18078663          	beqz	a5,13c4 <printf+0x1ca>
    123c:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    123e:	19278d63          	beq	a5,s2,13d8 <printf+0x1de>
    1242:	0015c783          	lbu	a5,1(a1)
    1246:	0585                	addi	a1,a1,1
    1248:	fbfd                	bnez	a5,123e <printf+0x44>
    124a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    124c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1250:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1254:	1b578863          	beq	a5,s5,1404 <printf+0x20a>
		len = out_unlocked(s, l);
    1258:	85a2                	mv	a1,s0
    125a:	854e                	mv	a0,s3
    125c:	42a000ef          	jal	ra,1686 <out_unlocked>
		out(f, a, l);
		if (l)
    1260:	1c041063          	bnez	s0,1420 <printf+0x226>
			continue;
		if (s[1] == 0)
    1264:	0014c783          	lbu	a5,1(s1)
    1268:	14078e63          	beqz	a5,13c4 <printf+0x1ca>
			break;
		switch (s[1]) {
    126c:	07300713          	li	a4,115
    1270:	1ce78863          	beq	a5,a4,1440 <printf+0x246>
    1274:	1af76863          	bltu	a4,a5,1424 <printf+0x22a>
    1278:	06400713          	li	a4,100
    127c:	22e78063          	beq	a5,a4,149c <printf+0x2a2>
    1280:	07000713          	li	a4,112
    1284:	1ee79563          	bne	a5,a4,146e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1288:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    128a:	00001797          	auipc	a5,0x1
    128e:	74e78793          	addi	a5,a5,1870 # 29d8 <digits>
	buf[i++] = '0';
    1292:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1296:	6298                	ld	a4,0(a3)
    1298:	06a1                	addi	a3,a3,8
    129a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    129c:	00471393          	slli	t2,a4,0x4
    12a0:	00871293          	slli	t0,a4,0x8
    12a4:	00c71f93          	slli	t6,a4,0xc
    12a8:	01071f13          	slli	t5,a4,0x10
    12ac:	01471e93          	slli	t4,a4,0x14
    12b0:	01871e13          	slli	t3,a4,0x18
    12b4:	01c71893          	slli	a7,a4,0x1c
    12b8:	02471813          	slli	a6,a4,0x24
    12bc:	02871513          	slli	a0,a4,0x28
    12c0:	02c71593          	slli	a1,a4,0x2c
    12c4:	03071613          	slli	a2,a4,0x30
    12c8:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12cc:	03c75413          	srli	s0,a4,0x3c
    12d0:	01c7531b          	srliw	t1,a4,0x1c
    12d4:	03c3d393          	srli	t2,t2,0x3c
    12d8:	03c2d293          	srli	t0,t0,0x3c
    12dc:	03cfdf93          	srli	t6,t6,0x3c
    12e0:	03cf5f13          	srli	t5,t5,0x3c
    12e4:	03cede93          	srli	t4,t4,0x3c
    12e8:	03ce5e13          	srli	t3,t3,0x3c
    12ec:	03c8d893          	srli	a7,a7,0x3c
    12f0:	03c85813          	srli	a6,a6,0x3c
    12f4:	9171                	srli	a0,a0,0x3c
    12f6:	91f1                	srli	a1,a1,0x3c
    12f8:	9271                	srli	a2,a2,0x3c
    12fa:	92f1                	srli	a3,a3,0x3c
    12fc:	95be                	add	a1,a1,a5
    12fe:	963e                	add	a2,a2,a5
    1300:	96be                	add	a3,a3,a5
    1302:	943e                	add	s0,s0,a5
    1304:	93be                	add	t2,t2,a5
    1306:	92be                	add	t0,t0,a5
    1308:	9fbe                	add	t6,t6,a5
    130a:	9f3e                	add	t5,t5,a5
    130c:	9ebe                	add	t4,t4,a5
    130e:	9e3e                	add	t3,t3,a5
    1310:	98be                	add	a7,a7,a5
    1312:	933e                	add	t1,t1,a5
    1314:	983e                	add	a6,a6,a5
    1316:	953e                	add	a0,a0,a5
    1318:	0005c983          	lbu	s3,0(a1)
    131c:	00044403          	lbu	s0,0(s0)
    1320:	00064583          	lbu	a1,0(a2)
    1324:	0003c383          	lbu	t2,0(t2)
    1328:	0006c603          	lbu	a2,0(a3)
    132c:	0002c283          	lbu	t0,0(t0)
    1330:	000fcf83          	lbu	t6,0(t6)
    1334:	000f4f03          	lbu	t5,0(t5)
    1338:	000ece83          	lbu	t4,0(t4)
    133c:	000e4e03          	lbu	t3,0(t3)
    1340:	0008c883          	lbu	a7,0(a7)
    1344:	00034303          	lbu	t1,0(t1)
    1348:	00084803          	lbu	a6,0(a6)
    134c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1350:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1354:	92f1                	srli	a3,a3,0x3c
    1356:	8b3d                	andi	a4,a4,15
    1358:	96be                	add	a3,a3,a5
    135a:	97ba                	add	a5,a5,a4
    135c:	00810d23          	sb	s0,26(sp)
    1360:	00710da3          	sb	t2,27(sp)
    1364:	00510e23          	sb	t0,28(sp)
    1368:	01f10ea3          	sb	t6,29(sp)
    136c:	01e10f23          	sb	t5,30(sp)
    1370:	01d10fa3          	sb	t4,31(sp)
    1374:	03c10023          	sb	t3,32(sp)
    1378:	031100a3          	sb	a7,33(sp)
    137c:	02610123          	sb	t1,34(sp)
    1380:	030101a3          	sb	a6,35(sp)
    1384:	02a10223          	sb	a0,36(sp)
    1388:	033102a3          	sb	s3,37(sp)
    138c:	02b10323          	sb	a1,38(sp)
    1390:	02c103a3          	sb	a2,39(sp)
    1394:	0006c683          	lbu	a3,0(a3)
    1398:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    139c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    13a0:	02d10423          	sb	a3,40(sp)
    13a4:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    13a8:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    13ac:	11578263          	beq	a5,s5,14b0 <printf+0x2b6>
		len = out_unlocked(s, l);
    13b0:	45c9                	li	a1,18
    13b2:	0828                	addi	a0,sp,24
    13b4:	2d2000ef          	jal	ra,1686 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    13b8:	00248993          	addi	s3,s1,2
		if (!*s)
    13bc:	0009c783          	lbu	a5,0(s3)
    13c0:	e6079ee3          	bnez	a5,123c <printf+0x42>
	}
	va_end(ap);
    13c4:	70e6                	ld	ra,120(sp)
    13c6:	7446                	ld	s0,112(sp)
    13c8:	74a6                	ld	s1,104(sp)
    13ca:	7906                	ld	s2,96(sp)
    13cc:	69e6                	ld	s3,88(sp)
    13ce:	6a46                	ld	s4,80(sp)
    13d0:	6aa6                	ld	s5,72(sp)
    13d2:	6b06                	ld	s6,64(sp)
    13d4:	6129                	addi	sp,sp,192
    13d6:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13d8:	0005c783          	lbu	a5,0(a1)
    13dc:	84ae                	mv	s1,a1
    13de:	01278963          	beq	a5,s2,13f0 <printf+0x1f6>
    13e2:	b5ad                	j	124c <printf+0x52>
    13e4:	0024c783          	lbu	a5,2(s1)
    13e8:	0585                	addi	a1,a1,1
    13ea:	0489                	addi	s1,s1,2
    13ec:	e72790e3          	bne	a5,s2,124c <printf+0x52>
    13f0:	0014c783          	lbu	a5,1(s1)
    13f4:	ff2788e3          	beq	a5,s2,13e4 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13f8:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13fc:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1400:	e5579ce3          	bne	a5,s5,1258 <printf+0x5e>
		mutex_lock(buffer_lock);
    1404:	10ca2503          	lw	a0,268(s4)
    1408:	292010ef          	jal	ra,269a <mutex_lock>
		len = out_unlocked(s, l);
    140c:	85a2                	mv	a1,s0
    140e:	854e                	mv	a0,s3
    1410:	276000ef          	jal	ra,1686 <out_unlocked>
		mutex_unlock(buffer_lock);
    1414:	10ca2503          	lw	a0,268(s4)
    1418:	28e010ef          	jal	ra,26a6 <mutex_unlock>
		if (l)
    141c:	e40404e3          	beqz	s0,1264 <printf+0x6a>
    1420:	89a6                	mv	s3,s1
    1422:	bd09                	j	1234 <printf+0x3a>
		switch (s[1]) {
    1424:	07800713          	li	a4,120
    1428:	04e79363          	bne	a5,a4,146e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    142c:	67c2                	ld	a5,16(sp)
    142e:	45c1                	li	a1,16
		s += 2;
    1430:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    1434:	4388                	lw	a0,0(a5)
    1436:	07a1                	addi	a5,a5,8
    1438:	e83e                	sd	a5,16(sp)
    143a:	5f8000ef          	jal	ra,1a32 <printint.constprop.0>
		s += 2;
    143e:	bfbd                	j	13bc <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1440:	67c2                	ld	a5,16(sp)
    1442:	6380                	ld	s0,0(a5)
    1444:	07a1                	addi	a5,a5,8
    1446:	e83e                	sd	a5,16(sp)
    1448:	1c040163          	beqz	s0,160a <printf+0x410>
			l = strnlen(a, 200);
    144c:	0c800593          	li	a1,200
    1450:	8522                	mv	a0,s0
    1452:	3f7000ef          	jal	ra,2048 <strnlen>
	if (buffer_lock_enabled == 1) {
    1456:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    145a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    145e:	19578663          	beq	a5,s5,15ea <printf+0x3f0>
		len = out_unlocked(s, l);
    1462:	8522                	mv	a0,s0
    1464:	222000ef          	jal	ra,1686 <out_unlocked>
		s += 2;
    1468:	00248993          	addi	s3,s1,2
    146c:	bf81                	j	13bc <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    146e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1472:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1476:	0f578663          	beq	a5,s5,1562 <printf+0x368>
		len = out_unlocked(s, l);
    147a:	0828                	addi	a0,sp,24
    147c:	316000ef          	jal	ra,1792 <out_unlocked.constprop.0>
			putchar(s[1]);
    1480:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1484:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1488:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    148c:	05578163          	beq	a5,s5,14ce <printf+0x2d4>
		len = out_unlocked(s, l);
    1490:	0828                	addi	a0,sp,24
    1492:	300000ef          	jal	ra,1792 <out_unlocked.constprop.0>
		s += 2;
    1496:	00248993          	addi	s3,s1,2
    149a:	b70d                	j	13bc <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    149c:	67c2                	ld	a5,16(sp)
    149e:	45a9                	li	a1,10
		s += 2;
    14a0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    14a4:	4388                	lw	a0,0(a5)
    14a6:	07a1                	addi	a5,a5,8
    14a8:	e83e                	sd	a5,16(sp)
    14aa:	588000ef          	jal	ra,1a32 <printint.constprop.0>
		s += 2;
    14ae:	b739                	j	13bc <printf+0x1c2>
		mutex_lock(buffer_lock);
    14b0:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14b4:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    14b8:	1e2010ef          	jal	ra,269a <mutex_lock>
		len = out_unlocked(s, l);
    14bc:	45c9                	li	a1,18
    14be:	0828                	addi	a0,sp,24
    14c0:	1c6000ef          	jal	ra,1686 <out_unlocked>
		mutex_unlock(buffer_lock);
    14c4:	10ca2503          	lw	a0,268(s4)
    14c8:	1de010ef          	jal	ra,26a6 <mutex_unlock>
		s += 2;
    14cc:	bdc5                	j	13bc <printf+0x1c2>
		mutex_lock(buffer_lock);
    14ce:	10ca2503          	lw	a0,268(s4)
    14d2:	1c8010ef          	jal	ra,269a <mutex_lock>
		buffer[buffer_len++] = c;
    14d6:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14da:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14de:	0017861b          	addiw	a2,a5,1
    14e2:	97d2                	add	a5,a5,s4
    14e4:	00ca2023          	sw	a2,0(s4)
    14e8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14ec:	00c6cc63          	blt	a3,a2,1504 <printf+0x30a>
    14f0:	47a9                	li	a5,10
    14f2:	06f40663          	beq	s0,a5,155e <printf+0x364>
		mutex_unlock(buffer_lock);
    14f6:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14fa:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14fe:	1a8010ef          	jal	ra,26a6 <mutex_unlock>
		s += 2;
    1502:	bd6d                	j	13bc <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    1504:	10000793          	li	a5,256
    1508:	00f61e63          	bne	a2,a5,1524 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    150c:	00001597          	auipc	a1,0x1
    1510:	3c458593          	addi	a1,a1,964 # 28d0 <buffer>
    1514:	4505                	li	a0,1
    1516:	70d000ef          	jal	ra,2422 <write>
	buffer_len = 0;
    151a:	00001797          	auipc	a5,0x1
    151e:	3a07a723          	sw	zero,942(a5) # 28c8 <buffer_len>
			if (r < 0) {
    1522:	bfd1                	j	14f6 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    1524:	709000ef          	jal	ra,242c <getpid>
    1528:	842a                	mv	s0,a0
    152a:	00001517          	auipc	a0,0x1
    152e:	2ae50513          	addi	a0,a0,686 # 27d8 <enable_deadlock_detect+0xde>
    1532:	5d1000ef          	jal	ra,2302 <basename>
    1536:	872a                	mv	a4,a0
    1538:	00001617          	auipc	a2,0x1
    153c:	21860613          	addi	a2,a2,536 # 2750 <enable_deadlock_detect+0x56>
    1540:	05400793          	li	a5,84
    1544:	86a2                	mv	a3,s0
    1546:	45fd                	li	a1,31
    1548:	00001517          	auipc	a0,0x1
    154c:	2d050513          	addi	a0,a0,720 # 2818 <enable_deadlock_detect+0x11e>
    1550:	cabff0ef          	jal	ra,11fa <printf>
    1554:	557d                	li	a0,-1
    1556:	707000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    155a:	000a2603          	lw	a2,0(s4)
    155e:	de41                	beqz	a2,14f6 <printf+0x2fc>
    1560:	b775                	j	150c <printf+0x312>
		mutex_lock(buffer_lock);
    1562:	10ca2503          	lw	a0,268(s4)
    1566:	134010ef          	jal	ra,269a <mutex_lock>
		buffer[buffer_len++] = c;
    156a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    156e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1572:	0017861b          	addiw	a2,a5,1
    1576:	97d2                	add	a5,a5,s4
    1578:	00ca2023          	sw	a2,0(s4)
    157c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1580:	02c6d163          	bge	a3,a2,15a2 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1584:	10000793          	li	a5,256
    1588:	02f61263          	bne	a2,a5,15ac <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    158c:	00001597          	auipc	a1,0x1
    1590:	34458593          	addi	a1,a1,836 # 28d0 <buffer>
    1594:	4505                	li	a0,1
    1596:	68d000ef          	jal	ra,2422 <write>
	buffer_len = 0;
    159a:	00001797          	auipc	a5,0x1
    159e:	3207a723          	sw	zero,814(a5) # 28c8 <buffer_len>
		mutex_unlock(buffer_lock);
    15a2:	10ca2503          	lw	a0,268(s4)
    15a6:	100010ef          	jal	ra,26a6 <mutex_unlock>
    15aa:	bdd9                	j	1480 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    15ac:	681000ef          	jal	ra,242c <getpid>
    15b0:	842a                	mv	s0,a0
    15b2:	00001517          	auipc	a0,0x1
    15b6:	22650513          	addi	a0,a0,550 # 27d8 <enable_deadlock_detect+0xde>
    15ba:	549000ef          	jal	ra,2302 <basename>
    15be:	872a                	mv	a4,a0
    15c0:	00001617          	auipc	a2,0x1
    15c4:	19060613          	addi	a2,a2,400 # 2750 <enable_deadlock_detect+0x56>
    15c8:	05400793          	li	a5,84
    15cc:	86a2                	mv	a3,s0
    15ce:	45fd                	li	a1,31
    15d0:	00001517          	auipc	a0,0x1
    15d4:	24850513          	addi	a0,a0,584 # 2818 <enable_deadlock_detect+0x11e>
    15d8:	c23ff0ef          	jal	ra,11fa <printf>
    15dc:	557d                	li	a0,-1
    15de:	67f000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    15e2:	000a2603          	lw	a2,0(s4)
    15e6:	de55                	beqz	a2,15a2 <printf+0x3a8>
    15e8:	b755                	j	158c <printf+0x392>
		mutex_lock(buffer_lock);
    15ea:	10ca2503          	lw	a0,268(s4)
    15ee:	e42e                	sd	a1,8(sp)
		s += 2;
    15f0:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15f4:	0a6010ef          	jal	ra,269a <mutex_lock>
		len = out_unlocked(s, l);
    15f8:	65a2                	ld	a1,8(sp)
    15fa:	8522                	mv	a0,s0
    15fc:	08a000ef          	jal	ra,1686 <out_unlocked>
		mutex_unlock(buffer_lock);
    1600:	10ca2503          	lw	a0,268(s4)
    1604:	0a2010ef          	jal	ra,26a6 <mutex_unlock>
		s += 2;
    1608:	bb55                	j	13bc <printf+0x1c2>
				a = "(null)";
    160a:	00001417          	auipc	s0,0x1
    160e:	1c640413          	addi	s0,s0,454 # 27d0 <enable_deadlock_detect+0xd6>
    1612:	bd2d                	j	144c <printf+0x252>

0000000000001614 <enable_thread_io_buffer>:
{
    1614:	1101                	addi	sp,sp,-32
    1616:	e822                	sd	s0,16(sp)
    1618:	ec06                	sd	ra,24(sp)
    161a:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    161c:	00001417          	auipc	s0,0x1
    1620:	2ac40413          	addi	s0,s0,684 # 28c8 <buffer_len>
    1624:	05a010ef          	jal	ra,267e <mutex_create>
    1628:	10a42623          	sw	a0,268(s0)
    162c:	00054a63          	bltz	a0,1640 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1630:	4785                	li	a5,1
}
    1632:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1634:	10f42423          	sw	a5,264(s0)
}
    1638:	6442                	ld	s0,16(sp)
    163a:	64a2                	ld	s1,8(sp)
    163c:	6105                	addi	sp,sp,32
    163e:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1640:	5ed000ef          	jal	ra,242c <getpid>
    1644:	84aa                	mv	s1,a0
    1646:	00001517          	auipc	a0,0x1
    164a:	19250513          	addi	a0,a0,402 # 27d8 <enable_deadlock_detect+0xde>
    164e:	4b5000ef          	jal	ra,2302 <basename>
    1652:	872a                	mv	a4,a0
    1654:	04800793          	li	a5,72
    1658:	86a6                	mv	a3,s1
    165a:	00001517          	auipc	a0,0x1
    165e:	1fe50513          	addi	a0,a0,510 # 2858 <enable_deadlock_detect+0x15e>
    1662:	00001617          	auipc	a2,0x1
    1666:	0ee60613          	addi	a2,a2,238 # 2750 <enable_deadlock_detect+0x56>
    166a:	45fd                	li	a1,31
    166c:	b8fff0ef          	jal	ra,11fa <printf>
    1670:	557d                	li	a0,-1
    1672:	5eb000ef          	jal	ra,245c <exit>
	buffer_lock_enabled = 1;
    1676:	4785                	li	a5,1
}
    1678:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    167a:	10f42423          	sw	a5,264(s0)
}
    167e:	6442                	ld	s0,16(sp)
    1680:	64a2                	ld	s1,8(sp)
    1682:	6105                	addi	sp,sp,32
    1684:	8082                	ret

0000000000001686 <out_unlocked>:
{
    1686:	7159                	addi	sp,sp,-112
    1688:	f486                	sd	ra,104(sp)
    168a:	f0a2                	sd	s0,96(sp)
    168c:	eca6                	sd	s1,88(sp)
    168e:	e8ca                	sd	s2,80(sp)
    1690:	e4ce                	sd	s3,72(sp)
    1692:	e0d2                	sd	s4,64(sp)
    1694:	fc56                	sd	s5,56(sp)
    1696:	f85a                	sd	s6,48(sp)
    1698:	f45e                	sd	s7,40(sp)
    169a:	f062                	sd	s8,32(sp)
    169c:	ec66                	sd	s9,24(sp)
    169e:	e86a                	sd	s10,16(sp)
    16a0:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    16a2:	0e058663          	beqz	a1,178e <out_unlocked+0x108>
    16a6:	842a                	mv	s0,a0
    16a8:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    16ac:	4981                	li	s3,0
    16ae:	00001d17          	auipc	s10,0x1
    16b2:	21ad0d13          	addi	s10,s10,538 # 28c8 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16b6:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16ba:	00001b17          	auipc	s6,0x1
    16be:	216b0b13          	addi	s6,s6,534 # 28d0 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16c2:	10000a93          	li	s5,256
    16c6:	00001c97          	auipc	s9,0x1
    16ca:	112c8c93          	addi	s9,s9,274 # 27d8 <enable_deadlock_detect+0xde>
    16ce:	00001c17          	auipc	s8,0x1
    16d2:	082c0c13          	addi	s8,s8,130 # 2750 <enable_deadlock_detect+0x56>
    16d6:	00001b97          	auipc	s7,0x1
    16da:	142b8b93          	addi	s7,s7,322 # 2818 <enable_deadlock_detect+0x11e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16de:	4a29                	li	s4,10
    16e0:	a031                	j	16ec <out_unlocked+0x66>
    16e2:	09468863          	beq	a3,s4,1772 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16e6:	0405                	addi	s0,s0,1
    16e8:	04848163          	beq	s1,s0,172a <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16ec:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16f0:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16f4:	0017861b          	addiw	a2,a5,1
    16f8:	97ea                	add	a5,a5,s10
    16fa:	00cd2023          	sw	a2,0(s10)
    16fe:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1702:	fec950e3          	bge	s2,a2,16e2 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    1706:	05561263          	bne	a2,s5,174a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    170a:	85da                	mv	a1,s6
    170c:	4505                	li	a0,1
    170e:	515000ef          	jal	ra,2422 <write>
    1712:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1714:	00001797          	auipc	a5,0x1
    1718:	1a07aa23          	sw	zero,436(a5) # 28c8 <buffer_len>
			if (r < 0) {
    171c:	06054763          	bltz	a0,178a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1720:	0405                	addi	s0,s0,1
			ret += r;
    1722:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    1726:	fc8493e3          	bne	s1,s0,16ec <out_unlocked+0x66>
}
    172a:	70a6                	ld	ra,104(sp)
    172c:	7406                	ld	s0,96(sp)
    172e:	64e6                	ld	s1,88(sp)
    1730:	6946                	ld	s2,80(sp)
    1732:	6a06                	ld	s4,64(sp)
    1734:	7ae2                	ld	s5,56(sp)
    1736:	7b42                	ld	s6,48(sp)
    1738:	7ba2                	ld	s7,40(sp)
    173a:	7c02                	ld	s8,32(sp)
    173c:	6ce2                	ld	s9,24(sp)
    173e:	6d42                	ld	s10,16(sp)
    1740:	6da2                	ld	s11,8(sp)
    1742:	854e                	mv	a0,s3
    1744:	69a6                	ld	s3,72(sp)
    1746:	6165                	addi	sp,sp,112
    1748:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    174a:	4e3000ef          	jal	ra,242c <getpid>
    174e:	8daa                	mv	s11,a0
    1750:	8566                	mv	a0,s9
    1752:	3b1000ef          	jal	ra,2302 <basename>
    1756:	872a                	mv	a4,a0
    1758:	8662                	mv	a2,s8
    175a:	05400793          	li	a5,84
    175e:	86ee                	mv	a3,s11
    1760:	45fd                	li	a1,31
    1762:	855e                	mv	a0,s7
    1764:	a97ff0ef          	jal	ra,11fa <printf>
    1768:	557d                	li	a0,-1
    176a:	4f3000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    176e:	000d2603          	lw	a2,0(s10)
    1772:	da35                	beqz	a2,16e6 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1774:	85da                	mv	a1,s6
    1776:	4505                	li	a0,1
    1778:	4ab000ef          	jal	ra,2422 <write>
    177c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    177e:	00001797          	auipc	a5,0x1
    1782:	1407a523          	sw	zero,330(a5) # 28c8 <buffer_len>
			if (r < 0) {
    1786:	f8055de3          	bgez	a0,1720 <out_unlocked+0x9a>
    178a:	89aa                	mv	s3,a0
    178c:	bf79                	j	172a <out_unlocked+0xa4>
	int ret = 0;
    178e:	4981                	li	s3,0
    1790:	bf69                	j	172a <out_unlocked+0xa4>

0000000000001792 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1792:	1101                	addi	sp,sp,-32
    1794:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1796:	00001497          	auipc	s1,0x1
    179a:	13248493          	addi	s1,s1,306 # 28c8 <buffer_len>
    179e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    17a0:	ec06                	sd	ra,24(sp)
    17a2:	e822                	sd	s0,16(sp)
		char c = s[i];
    17a4:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    17a8:	0017861b          	addiw	a2,a5,1
    17ac:	97a6                	add	a5,a5,s1
    17ae:	00e78423          	sb	a4,8(a5)
    17b2:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    17b4:	0ff00793          	li	a5,255
    17b8:	00c7cc63          	blt	a5,a2,17d0 <out_unlocked.constprop.0+0x3e>
    17bc:	47a9                	li	a5,10
    17be:	06f70c63          	beq	a4,a5,1836 <out_unlocked.constprop.0+0xa4>
    17c2:	4601                	li	a2,0
}
    17c4:	60e2                	ld	ra,24(sp)
    17c6:	6442                	ld	s0,16(sp)
    17c8:	64a2                	ld	s1,8(sp)
    17ca:	8532                	mv	a0,a2
    17cc:	6105                	addi	sp,sp,32
    17ce:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17d0:	10000793          	li	a5,256
    17d4:	02f61563          	bne	a2,a5,17fe <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17d8:	00001597          	auipc	a1,0x1
    17dc:	0f858593          	addi	a1,a1,248 # 28d0 <buffer>
    17e0:	4505                	li	a0,1
    17e2:	441000ef          	jal	ra,2422 <write>
}
    17e6:	60e2                	ld	ra,24(sp)
    17e8:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17ea:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17ee:	00001797          	auipc	a5,0x1
    17f2:	0c07ad23          	sw	zero,218(a5) # 28c8 <buffer_len>
}
    17f6:	64a2                	ld	s1,8(sp)
    17f8:	8532                	mv	a0,a2
    17fa:	6105                	addi	sp,sp,32
    17fc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17fe:	42f000ef          	jal	ra,242c <getpid>
    1802:	842a                	mv	s0,a0
    1804:	00001517          	auipc	a0,0x1
    1808:	fd450513          	addi	a0,a0,-44 # 27d8 <enable_deadlock_detect+0xde>
    180c:	2f7000ef          	jal	ra,2302 <basename>
    1810:	872a                	mv	a4,a0
    1812:	00001617          	auipc	a2,0x1
    1816:	f3e60613          	addi	a2,a2,-194 # 2750 <enable_deadlock_detect+0x56>
    181a:	05400793          	li	a5,84
    181e:	86a2                	mv	a3,s0
    1820:	45fd                	li	a1,31
    1822:	00001517          	auipc	a0,0x1
    1826:	ff650513          	addi	a0,a0,-10 # 2818 <enable_deadlock_detect+0x11e>
    182a:	9d1ff0ef          	jal	ra,11fa <printf>
    182e:	557d                	li	a0,-1
    1830:	42d000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    1834:	4090                	lw	a2,0(s1)
    1836:	d659                	beqz	a2,17c4 <out_unlocked.constprop.0+0x32>
    1838:	b745                	j	17d8 <out_unlocked.constprop.0+0x46>

000000000000183a <putchar>:
{
    183a:	7139                	addi	sp,sp,-64
    183c:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    183e:	00001497          	auipc	s1,0x1
    1842:	08a48493          	addi	s1,s1,138 # 28c8 <buffer_len>
    1846:	1084a703          	lw	a4,264(s1)
{
    184a:	f822                	sd	s0,48(sp)
	char byte = c;
    184c:	0ff57413          	zext.b	s0,a0
{
    1850:	fc06                	sd	ra,56(sp)
	char byte = c;
    1852:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1856:	4785                	li	a5,1
    1858:	00f70d63          	beq	a4,a5,1872 <putchar+0x38>
		len = out_unlocked(s, l);
    185c:	01f10513          	addi	a0,sp,31
    1860:	f33ff0ef          	jal	ra,1792 <out_unlocked.constprop.0>
}
    1864:	70e2                	ld	ra,56(sp)
    1866:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1868:	862a                	mv	a2,a0
}
    186a:	74a2                	ld	s1,40(sp)
    186c:	8532                	mv	a0,a2
    186e:	6121                	addi	sp,sp,64
    1870:	8082                	ret
		mutex_lock(buffer_lock);
    1872:	10c4a503          	lw	a0,268(s1)
    1876:	625000ef          	jal	ra,269a <mutex_lock>
		buffer[buffer_len++] = c;
    187a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    187c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1880:	0017861b          	addiw	a2,a5,1
    1884:	97a6                	add	a5,a5,s1
    1886:	c090                	sw	a2,0(s1)
    1888:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    188c:	02c6c263          	blt	a3,a2,18b0 <putchar+0x76>
    1890:	47a9                	li	a5,10
    1892:	06f40d63          	beq	s0,a5,190c <putchar+0xd2>
    1896:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1898:	10c4a503          	lw	a0,268(s1)
    189c:	e432                	sd	a2,8(sp)
    189e:	609000ef          	jal	ra,26a6 <mutex_unlock>
    18a2:	6622                	ld	a2,8(sp)
}
    18a4:	70e2                	ld	ra,56(sp)
    18a6:	7442                	ld	s0,48(sp)
    18a8:	74a2                	ld	s1,40(sp)
    18aa:	8532                	mv	a0,a2
    18ac:	6121                	addi	sp,sp,64
    18ae:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    18b0:	10000793          	li	a5,256
    18b4:	02f61063          	bne	a2,a5,18d4 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    18b8:	00001597          	auipc	a1,0x1
    18bc:	01858593          	addi	a1,a1,24 # 28d0 <buffer>
    18c0:	4505                	li	a0,1
    18c2:	361000ef          	jal	ra,2422 <write>
    18c6:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18ca:	00001797          	auipc	a5,0x1
    18ce:	fe07af23          	sw	zero,-2(a5) # 28c8 <buffer_len>
			if (r < 0) {
    18d2:	b7d9                	j	1898 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18d4:	359000ef          	jal	ra,242c <getpid>
    18d8:	842a                	mv	s0,a0
    18da:	00001517          	auipc	a0,0x1
    18de:	efe50513          	addi	a0,a0,-258 # 27d8 <enable_deadlock_detect+0xde>
    18e2:	221000ef          	jal	ra,2302 <basename>
    18e6:	872a                	mv	a4,a0
    18e8:	00001617          	auipc	a2,0x1
    18ec:	e6860613          	addi	a2,a2,-408 # 2750 <enable_deadlock_detect+0x56>
    18f0:	05400793          	li	a5,84
    18f4:	86a2                	mv	a3,s0
    18f6:	45fd                	li	a1,31
    18f8:	00001517          	auipc	a0,0x1
    18fc:	f2050513          	addi	a0,a0,-224 # 2818 <enable_deadlock_detect+0x11e>
    1900:	8fbff0ef          	jal	ra,11fa <printf>
    1904:	557d                	li	a0,-1
    1906:	357000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    190a:	4090                	lw	a2,0(s1)
    190c:	d651                	beqz	a2,1898 <putchar+0x5e>
    190e:	b76d                	j	18b8 <putchar+0x7e>

0000000000001910 <puts>:
{
    1910:	7139                	addi	sp,sp,-64
    1912:	f822                	sd	s0,48(sp)
    1914:	f426                	sd	s1,40(sp)
    1916:	fc06                	sd	ra,56(sp)
    1918:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    191a:	00001417          	auipc	s0,0x1
    191e:	fae40413          	addi	s0,s0,-82 # 28c8 <buffer_len>
{
    1922:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1924:	638000ef          	jal	ra,1f5c <strlen>
	if (buffer_lock_enabled == 1) {
    1928:	10842703          	lw	a4,264(s0)
    192c:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    192e:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1930:	04f70563          	beq	a4,a5,197a <puts+0x6a>
		len = out_unlocked(s, l);
    1934:	8526                	mv	a0,s1
    1936:	d51ff0ef          	jal	ra,1686 <out_unlocked>
    193a:	892a                	mv	s2,a0
    193c:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    193e:	00095963          	bgez	s2,1950 <puts+0x40>
}
    1942:	70e2                	ld	ra,56(sp)
    1944:	7442                	ld	s0,48(sp)
    1946:	7902                	ld	s2,32(sp)
    1948:	8526                	mv	a0,s1
    194a:	74a2                	ld	s1,40(sp)
    194c:	6121                	addi	sp,sp,64
    194e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1950:	10842703          	lw	a4,264(s0)
	char byte = c;
    1954:	44a9                	li	s1,10
    1956:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    195a:	4785                	li	a5,1
    195c:	02f70e63          	beq	a4,a5,1998 <puts+0x88>
		len = out_unlocked(s, l);
    1960:	01f10513          	addi	a0,sp,31
    1964:	e2fff0ef          	jal	ra,1792 <out_unlocked.constprop.0>
}
    1968:	70e2                	ld	ra,56(sp)
    196a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    196c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1970:	7902                	ld	s2,32(sp)
    1972:	8526                	mv	a0,s1
    1974:	74a2                	ld	s1,40(sp)
    1976:	6121                	addi	sp,sp,64
    1978:	8082                	ret
		mutex_lock(buffer_lock);
    197a:	e42a                	sd	a0,8(sp)
    197c:	10c42503          	lw	a0,268(s0)
    1980:	51b000ef          	jal	ra,269a <mutex_lock>
		len = out_unlocked(s, l);
    1984:	65a2                	ld	a1,8(sp)
    1986:	8526                	mv	a0,s1
    1988:	cffff0ef          	jal	ra,1686 <out_unlocked>
    198c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    198e:	10c42503          	lw	a0,268(s0)
    1992:	515000ef          	jal	ra,26a6 <mutex_unlock>
    1996:	b75d                	j	193c <puts+0x2c>
		mutex_lock(buffer_lock);
    1998:	10c42503          	lw	a0,268(s0)
    199c:	4ff000ef          	jal	ra,269a <mutex_lock>
		buffer[buffer_len++] = c;
    19a0:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19a2:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    19a6:	0017861b          	addiw	a2,a5,1
    19aa:	97a2                	add	a5,a5,s0
    19ac:	c010                	sw	a2,0(s0)
    19ae:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    19b2:	06c6dc63          	bge	a3,a2,1a2a <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    19b6:	10000793          	li	a5,256
    19ba:	02f61c63          	bne	a2,a5,19f2 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19be:	00001597          	auipc	a1,0x1
    19c2:	f1258593          	addi	a1,a1,-238 # 28d0 <buffer>
    19c6:	4505                	li	a0,1
    19c8:	25b000ef          	jal	ra,2422 <write>
			if (r < 0) {
    19cc:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19ce:	00001797          	auipc	a5,0x1
    19d2:	ee07ad23          	sw	zero,-262(a5) # 28c8 <buffer_len>
			if (r < 0) {
    19d6:	04054c63          	bltz	a0,1a2e <puts+0x11e>
			if (r < buffer_len) {
    19da:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19dc:	10c42503          	lw	a0,268(s0)
    19e0:	4c7000ef          	jal	ra,26a6 <mutex_unlock>
}
    19e4:	70e2                	ld	ra,56(sp)
    19e6:	7442                	ld	s0,48(sp)
    19e8:	7902                	ld	s2,32(sp)
    19ea:	8526                	mv	a0,s1
    19ec:	74a2                	ld	s1,40(sp)
    19ee:	6121                	addi	sp,sp,64
    19f0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19f2:	23b000ef          	jal	ra,242c <getpid>
    19f6:	84aa                	mv	s1,a0
    19f8:	00001517          	auipc	a0,0x1
    19fc:	de050513          	addi	a0,a0,-544 # 27d8 <enable_deadlock_detect+0xde>
    1a00:	103000ef          	jal	ra,2302 <basename>
    1a04:	872a                	mv	a4,a0
    1a06:	00001617          	auipc	a2,0x1
    1a0a:	d4a60613          	addi	a2,a2,-694 # 2750 <enable_deadlock_detect+0x56>
    1a0e:	05400793          	li	a5,84
    1a12:	86a6                	mv	a3,s1
    1a14:	45fd                	li	a1,31
    1a16:	00001517          	auipc	a0,0x1
    1a1a:	e0250513          	addi	a0,a0,-510 # 2818 <enable_deadlock_detect+0x11e>
    1a1e:	fdcff0ef          	jal	ra,11fa <printf>
    1a22:	557d                	li	a0,-1
    1a24:	239000ef          	jal	ra,245c <exit>
	if (buffer_len == 0)
    1a28:	4010                	lw	a2,0(s0)
    1a2a:	da45                	beqz	a2,19da <puts+0xca>
    1a2c:	bf49                	j	19be <puts+0xae>
    1a2e:	54fd                	li	s1,-1
    1a30:	b775                	j	19dc <puts+0xcc>

0000000000001a32 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a32:	715d                	addi	sp,sp,-80
    1a34:	e486                	sd	ra,72(sp)
    1a36:	e0a2                	sd	s0,64(sp)
    1a38:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a3a:	14054363          	bltz	a0,1b80 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a3e:	02b577bb          	remuw	a5,a0,a1
    1a42:	00001617          	auipc	a2,0x1
    1a46:	f9660613          	addi	a2,a2,-106 # 29d8 <digits>
	buf[16] = 0;
    1a4a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a4e:	0005871b          	sext.w	a4,a1
    1a52:	1782                	slli	a5,a5,0x20
    1a54:	9381                	srli	a5,a5,0x20
    1a56:	97b2                	add	a5,a5,a2
    1a58:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a5c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a60:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a64:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a66:	0eb56763          	bltu	a0,a1,1b54 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a6a:	02e877bb          	remuw	a5,a6,a4
    1a6e:	1782                	slli	a5,a5,0x20
    1a70:	9381                	srli	a5,a5,0x20
    1a72:	97b2                	add	a5,a5,a2
    1a74:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a78:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a7c:	02f10323          	sb	a5,38(sp)
    1a80:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a82:	0ce86963          	bltu	a6,a4,1b54 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a86:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a8a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a8e:	1582                	slli	a1,a1,0x20
    1a90:	9181                	srli	a1,a1,0x20
    1a92:	95b2                	add	a1,a1,a2
    1a94:	0005c583          	lbu	a1,0(a1)
    1a98:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a9c:	0007859b          	sext.w	a1,a5
    1aa0:	16e6e563          	bltu	a3,a4,1c0a <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1aa4:	02e7f6bb          	remuw	a3,a5,a4
    1aa8:	1682                	slli	a3,a3,0x20
    1aaa:	9281                	srli	a3,a3,0x20
    1aac:	96b2                	add	a3,a3,a2
    1aae:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab2:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1ab6:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1aba:	16e5e163          	bltu	a1,a4,1c1c <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1abe:	02e876bb          	remuw	a3,a6,a4
    1ac2:	1682                	slli	a3,a3,0x20
    1ac4:	9281                	srli	a3,a3,0x20
    1ac6:	96b2                	add	a3,a3,a2
    1ac8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1acc:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ad0:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1ad4:	14e86d63          	bltu	a6,a4,1c2e <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1ad8:	02e5f6bb          	remuw	a3,a1,a4
    1adc:	1682                	slli	a3,a3,0x20
    1ade:	9281                	srli	a3,a3,0x20
    1ae0:	96b2                	add	a3,a3,a2
    1ae2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae6:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1aea:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1aee:	10e5e563          	bltu	a1,a4,1bf8 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1af2:	02e876bb          	remuw	a3,a6,a4
    1af6:	1682                	slli	a3,a3,0x20
    1af8:	9281                	srli	a3,a3,0x20
    1afa:	96b2                	add	a3,a3,a2
    1afc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b00:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1b04:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1b08:	14e86263          	bltu	a6,a4,1c4c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1b0c:	02e5f6bb          	remuw	a3,a1,a4
    1b10:	1682                	slli	a3,a3,0x20
    1b12:	9281                	srli	a3,a3,0x20
    1b14:	96b2                	add	a3,a3,a2
    1b16:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b1a:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b1e:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b22:	14e5e463          	bltu	a1,a4,1c6a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b26:	02e876bb          	remuw	a3,a6,a4
    1b2a:	1682                	slli	a3,a3,0x20
    1b2c:	9281                	srli	a3,a3,0x20
    1b2e:	96b2                	add	a3,a3,a2
    1b30:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b34:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b38:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b3c:	14e86063          	bltu	a6,a4,1c7c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b40:	1782                	slli	a5,a5,0x20
    1b42:	9381                	srli	a5,a5,0x20
    1b44:	97b2                	add	a5,a5,a2
    1b46:	0007c703          	lbu	a4,0(a5)
    1b4a:	4799                	li	a5,6
    1b4c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b50:	10054763          	bltz	a0,1c5e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b54:	00001497          	auipc	s1,0x1
    1b58:	d7448493          	addi	s1,s1,-652 # 28c8 <buffer_len>
    1b5c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b60:	0828                	addi	a0,sp,24
    1b62:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b64:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b66:	00f50433          	add	s0,a0,a5
    1b6a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b6c:	06e68463          	beq	a3,a4,1bd4 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b70:	8522                	mv	a0,s0
    1b72:	b15ff0ef          	jal	ra,1686 <out_unlocked>
}
    1b76:	60a6                	ld	ra,72(sp)
    1b78:	6406                	ld	s0,64(sp)
    1b7a:	74e2                	ld	s1,56(sp)
    1b7c:	6161                	addi	sp,sp,80
    1b7e:	8082                	ret
		x = -xx;
    1b80:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b84:	02b877bb          	remuw	a5,a6,a1
    1b88:	00001617          	auipc	a2,0x1
    1b8c:	e5060613          	addi	a2,a2,-432 # 29d8 <digits>
	buf[16] = 0;
    1b90:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b94:	0005871b          	sext.w	a4,a1
    1b98:	1782                	slli	a5,a5,0x20
    1b9a:	9381                	srli	a5,a5,0x20
    1b9c:	97b2                	add	a5,a5,a2
    1b9e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ba2:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1ba6:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1baa:	08b86b63          	bltu	a6,a1,1c40 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1bae:	02e8f7bb          	remuw	a5,a7,a4
    1bb2:	1782                	slli	a5,a5,0x20
    1bb4:	9381                	srli	a5,a5,0x20
    1bb6:	97b2                	add	a5,a5,a2
    1bb8:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1bbc:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1bc0:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1bc4:	ece8f1e3          	bgeu	a7,a4,1a86 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bc8:	02d00793          	li	a5,45
    1bcc:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1bd0:	47b5                	li	a5,13
    1bd2:	b749                	j	1b54 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1bd4:	10c4a503          	lw	a0,268(s1)
    1bd8:	e42e                	sd	a1,8(sp)
    1bda:	2c1000ef          	jal	ra,269a <mutex_lock>
		len = out_unlocked(s, l);
    1bde:	65a2                	ld	a1,8(sp)
    1be0:	8522                	mv	a0,s0
    1be2:	aa5ff0ef          	jal	ra,1686 <out_unlocked>
		mutex_unlock(buffer_lock);
    1be6:	10c4a503          	lw	a0,268(s1)
    1bea:	2bd000ef          	jal	ra,26a6 <mutex_unlock>
}
    1bee:	60a6                	ld	ra,72(sp)
    1bf0:	6406                	ld	s0,64(sp)
    1bf2:	74e2                	ld	s1,56(sp)
    1bf4:	6161                	addi	sp,sp,80
    1bf6:	8082                	ret
		buf[i--] = digits[x % base];
    1bf8:	47a9                	li	a5,10
	if (sign)
    1bfa:	f4055de3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bfe:	02d00793          	li	a5,45
    1c02:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1c06:	47a5                	li	a5,9
    1c08:	b7b1                	j	1b54 <printint.constprop.0+0x122>
    1c0a:	47b5                	li	a5,13
	if (sign)
    1c0c:	f40554e3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c10:	02d00793          	li	a5,45
    1c14:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1c18:	47b1                	li	a5,12
    1c1a:	bf2d                	j	1b54 <printint.constprop.0+0x122>
    1c1c:	47b1                	li	a5,12
	if (sign)
    1c1e:	f2055be3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c22:	02d00793          	li	a5,45
    1c26:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c2a:	47ad                	li	a5,11
    1c2c:	b725                	j	1b54 <printint.constprop.0+0x122>
    1c2e:	47ad                	li	a5,11
	if (sign)
    1c30:	f20552e3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c34:	02d00793          	li	a5,45
    1c38:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c3c:	47a9                	li	a5,10
    1c3e:	bf19                	j	1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c40:	02d00793          	li	a5,45
    1c44:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c48:	47b9                	li	a5,14
    1c4a:	b729                	j	1b54 <printint.constprop.0+0x122>
    1c4c:	47a5                	li	a5,9
	if (sign)
    1c4e:	f00553e3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c52:	02d00793          	li	a5,45
    1c56:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c5a:	47a1                	li	a5,8
    1c5c:	bde5                	j	1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c5e:	02d00793          	li	a5,45
    1c62:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c66:	4795                	li	a5,5
    1c68:	b5f5                	j	1b54 <printint.constprop.0+0x122>
    1c6a:	47a1                	li	a5,8
	if (sign)
    1c6c:	ee0554e3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c70:	02d00793          	li	a5,45
    1c74:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c78:	479d                	li	a5,7
    1c7a:	bde9                	j	1b54 <printint.constprop.0+0x122>
    1c7c:	479d                	li	a5,7
	if (sign)
    1c7e:	ec055be3          	bgez	a0,1b54 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c82:	02d00793          	li	a5,45
    1c86:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c8a:	4799                	li	a5,6
    1c8c:	b5e1                	j	1b54 <printint.constprop.0+0x122>

0000000000001c8e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c8e:	02000793          	li	a5,32
    1c92:	00f50663          	beq	a0,a5,1c9e <isspace+0x10>
    1c96:	355d                	addiw	a0,a0,-9
    1c98:	00553513          	sltiu	a0,a0,5
    1c9c:	8082                	ret
    1c9e:	4505                	li	a0,1
}
    1ca0:	8082                	ret

0000000000001ca2 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1ca2:	fd05051b          	addiw	a0,a0,-48
}
    1ca6:	00a53513          	sltiu	a0,a0,10
    1caa:	8082                	ret

0000000000001cac <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cac:	02000613          	li	a2,32
    1cb0:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1cb2:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1cb6:	ff77869b          	addiw	a3,a5,-9
    1cba:	04c78c63          	beq	a5,a2,1d12 <atoi+0x66>
    1cbe:	0007871b          	sext.w	a4,a5
    1cc2:	04d5f863          	bgeu	a1,a3,1d12 <atoi+0x66>
		s++;
	switch (*s) {
    1cc6:	02b00693          	li	a3,43
    1cca:	04d78963          	beq	a5,a3,1d1c <atoi+0x70>
    1cce:	02d00693          	li	a3,45
    1cd2:	06d78263          	beq	a5,a3,1d36 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1cd6:	fd07061b          	addiw	a2,a4,-48
    1cda:	47a5                	li	a5,9
    1cdc:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cde:	4e01                	li	t3,0
	while (isdigit(*s))
    1ce0:	04c7e963          	bltu	a5,a2,1d32 <atoi+0x86>
	int n = 0, neg = 0;
    1ce4:	4501                	li	a0,0
	while (isdigit(*s))
    1ce6:	4825                	li	a6,9
    1ce8:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cec:	0025179b          	slliw	a5,a0,0x2
    1cf0:	9fa9                	addw	a5,a5,a0
    1cf2:	fd07031b          	addiw	t1,a4,-48
    1cf6:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1cfa:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1cfe:	0685                	addi	a3,a3,1
    1d00:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1d04:	0006071b          	sext.w	a4,a2
    1d08:	feb870e3          	bgeu	a6,a1,1ce8 <atoi+0x3c>
	return neg ? n : -n;
    1d0c:	000e0563          	beqz	t3,1d16 <atoi+0x6a>
}
    1d10:	8082                	ret
		s++;
    1d12:	0505                	addi	a0,a0,1
    1d14:	bf79                	j	1cb2 <atoi+0x6>
	return neg ? n : -n;
    1d16:	4113053b          	subw	a0,t1,a7
    1d1a:	8082                	ret
	while (isdigit(*s))
    1d1c:	00154703          	lbu	a4,1(a0)
    1d20:	47a5                	li	a5,9
		s++;
    1d22:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d26:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d2a:	4e01                	li	t3,0
	while (isdigit(*s))
    1d2c:	2701                	sext.w	a4,a4
    1d2e:	fac7fbe3          	bgeu	a5,a2,1ce4 <atoi+0x38>
    1d32:	4501                	li	a0,0
}
    1d34:	8082                	ret
	while (isdigit(*s))
    1d36:	00154703          	lbu	a4,1(a0)
    1d3a:	47a5                	li	a5,9
		s++;
    1d3c:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d40:	fd07061b          	addiw	a2,a4,-48
    1d44:	2701                	sext.w	a4,a4
    1d46:	fec7e6e3          	bltu	a5,a2,1d32 <atoi+0x86>
		neg = 1;
    1d4a:	4e05                	li	t3,1
    1d4c:	bf61                	j	1ce4 <atoi+0x38>

0000000000001d4e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d4e:	16060d63          	beqz	a2,1ec8 <memset+0x17a>
    1d52:	40a007b3          	neg	a5,a0
    1d56:	8b9d                	andi	a5,a5,7
    1d58:	00778693          	addi	a3,a5,7
    1d5c:	482d                	li	a6,11
    1d5e:	0ff5f713          	zext.b	a4,a1
    1d62:	fff60593          	addi	a1,a2,-1
    1d66:	1706e263          	bltu	a3,a6,1eca <memset+0x17c>
    1d6a:	16d5ea63          	bltu	a1,a3,1ede <memset+0x190>
    1d6e:	16078563          	beqz	a5,1ed8 <memset+0x18a>
    1d72:	00e50023          	sb	a4,0(a0)
    1d76:	4685                	li	a3,1
    1d78:	00150593          	addi	a1,a0,1
    1d7c:	14d78c63          	beq	a5,a3,1ed4 <memset+0x186>
    1d80:	00e500a3          	sb	a4,1(a0)
    1d84:	4689                	li	a3,2
    1d86:	00250593          	addi	a1,a0,2
    1d8a:	14d78d63          	beq	a5,a3,1ee4 <memset+0x196>
    1d8e:	00e50123          	sb	a4,2(a0)
    1d92:	468d                	li	a3,3
    1d94:	00350593          	addi	a1,a0,3
    1d98:	12d78b63          	beq	a5,a3,1ece <memset+0x180>
    1d9c:	00e501a3          	sb	a4,3(a0)
    1da0:	4691                	li	a3,4
    1da2:	00450593          	addi	a1,a0,4
    1da6:	14d78163          	beq	a5,a3,1ee8 <memset+0x19a>
    1daa:	00e50223          	sb	a4,4(a0)
    1dae:	4695                	li	a3,5
    1db0:	00550593          	addi	a1,a0,5
    1db4:	12d78c63          	beq	a5,a3,1eec <memset+0x19e>
    1db8:	00e502a3          	sb	a4,5(a0)
    1dbc:	469d                	li	a3,7
    1dbe:	00650593          	addi	a1,a0,6
    1dc2:	12d79763          	bne	a5,a3,1ef0 <memset+0x1a2>
    1dc6:	00750593          	addi	a1,a0,7
    1dca:	00e50323          	sb	a4,6(a0)
    1dce:	481d                	li	a6,7
    1dd0:	00871693          	slli	a3,a4,0x8
    1dd4:	01071893          	slli	a7,a4,0x10
    1dd8:	8ed9                	or	a3,a3,a4
    1dda:	01871313          	slli	t1,a4,0x18
    1dde:	0116e6b3          	or	a3,a3,a7
    1de2:	0066e6b3          	or	a3,a3,t1
    1de6:	02071893          	slli	a7,a4,0x20
    1dea:	02871e13          	slli	t3,a4,0x28
    1dee:	0116e6b3          	or	a3,a3,a7
    1df2:	40f60333          	sub	t1,a2,a5
    1df6:	03071893          	slli	a7,a4,0x30
    1dfa:	01c6e6b3          	or	a3,a3,t3
    1dfe:	0116e6b3          	or	a3,a3,a7
    1e02:	03871e13          	slli	t3,a4,0x38
    1e06:	97aa                	add	a5,a5,a0
    1e08:	ff837893          	andi	a7,t1,-8
    1e0c:	01c6e6b3          	or	a3,a3,t3
    1e10:	98be                	add	a7,a7,a5
    1e12:	e394                	sd	a3,0(a5)
    1e14:	07a1                	addi	a5,a5,8
    1e16:	ff179ee3          	bne	a5,a7,1e12 <memset+0xc4>
    1e1a:	ff837893          	andi	a7,t1,-8
    1e1e:	011587b3          	add	a5,a1,a7
    1e22:	010886bb          	addw	a3,a7,a6
    1e26:	0b130663          	beq	t1,a7,1ed2 <memset+0x184>
    1e2a:	00e78023          	sb	a4,0(a5)
    1e2e:	0016859b          	addiw	a1,a3,1
    1e32:	08c5fb63          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e36:	00e780a3          	sb	a4,1(a5)
    1e3a:	0026859b          	addiw	a1,a3,2
    1e3e:	08c5f563          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e42:	00e78123          	sb	a4,2(a5)
    1e46:	0036859b          	addiw	a1,a3,3
    1e4a:	06c5ff63          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e4e:	00e781a3          	sb	a4,3(a5)
    1e52:	0046859b          	addiw	a1,a3,4
    1e56:	06c5f963          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e5a:	00e78223          	sb	a4,4(a5)
    1e5e:	0056859b          	addiw	a1,a3,5
    1e62:	06c5f363          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e66:	00e782a3          	sb	a4,5(a5)
    1e6a:	0066859b          	addiw	a1,a3,6
    1e6e:	04c5fd63          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e72:	00e78323          	sb	a4,6(a5)
    1e76:	0076859b          	addiw	a1,a3,7
    1e7a:	04c5f763          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e7e:	00e783a3          	sb	a4,7(a5)
    1e82:	0086859b          	addiw	a1,a3,8
    1e86:	04c5f163          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e8a:	00e78423          	sb	a4,8(a5)
    1e8e:	0096859b          	addiw	a1,a3,9
    1e92:	02c5fb63          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1e96:	00e784a3          	sb	a4,9(a5)
    1e9a:	00a6859b          	addiw	a1,a3,10
    1e9e:	02c5f563          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1ea2:	00e78523          	sb	a4,10(a5)
    1ea6:	00b6859b          	addiw	a1,a3,11
    1eaa:	00c5ff63          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1eae:	00e785a3          	sb	a4,11(a5)
    1eb2:	00c6859b          	addiw	a1,a3,12
    1eb6:	00c5f963          	bgeu	a1,a2,1ec8 <memset+0x17a>
    1eba:	00e78623          	sb	a4,12(a5)
    1ebe:	26b5                	addiw	a3,a3,13
    1ec0:	00c6f463          	bgeu	a3,a2,1ec8 <memset+0x17a>
    1ec4:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1ec8:	8082                	ret
    1eca:	46ad                	li	a3,11
    1ecc:	bd79                	j	1d6a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1ece:	480d                	li	a6,3
    1ed0:	b701                	j	1dd0 <memset+0x82>
    1ed2:	8082                	ret
    1ed4:	4805                	li	a6,1
    1ed6:	bded                	j	1dd0 <memset+0x82>
    1ed8:	85aa                	mv	a1,a0
    1eda:	4801                	li	a6,0
    1edc:	bdd5                	j	1dd0 <memset+0x82>
    1ede:	87aa                	mv	a5,a0
    1ee0:	4681                	li	a3,0
    1ee2:	b7a1                	j	1e2a <memset+0xdc>
    1ee4:	4809                	li	a6,2
    1ee6:	b5ed                	j	1dd0 <memset+0x82>
    1ee8:	4811                	li	a6,4
    1eea:	b5dd                	j	1dd0 <memset+0x82>
    1eec:	4815                	li	a6,5
    1eee:	b5cd                	j	1dd0 <memset+0x82>
    1ef0:	4819                	li	a6,6
    1ef2:	bdf9                	j	1dd0 <memset+0x82>

0000000000001ef4 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1ef4:	00054783          	lbu	a5,0(a0)
    1ef8:	0005c703          	lbu	a4,0(a1)
    1efc:	00e79863          	bne	a5,a4,1f0c <strcmp+0x18>
    1f00:	0505                	addi	a0,a0,1
    1f02:	0585                	addi	a1,a1,1
    1f04:	fbe5                	bnez	a5,1ef4 <strcmp>
    1f06:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1f08:	9d19                	subw	a0,a0,a4
    1f0a:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1f0c:	0007851b          	sext.w	a0,a5
    1f10:	bfe5                	j	1f08 <strcmp+0x14>

0000000000001f12 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1f12:	ca15                	beqz	a2,1f46 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f14:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1f18:	167d                	addi	a2,a2,-1
    1f1a:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f1e:	eb99                	bnez	a5,1f34 <strncmp+0x22>
    1f20:	a815                	j	1f54 <strncmp+0x42>
    1f22:	00a68e63          	beq	a3,a0,1f3e <strncmp+0x2c>
    1f26:	0505                	addi	a0,a0,1
    1f28:	00f71b63          	bne	a4,a5,1f3e <strncmp+0x2c>
    1f2c:	00054783          	lbu	a5,0(a0)
    1f30:	cf89                	beqz	a5,1f4a <strncmp+0x38>
    1f32:	85b2                	mv	a1,a2
    1f34:	0005c703          	lbu	a4,0(a1)
    1f38:	00158613          	addi	a2,a1,1
    1f3c:	f37d                	bnez	a4,1f22 <strncmp+0x10>
		;
	return *l - *r;
    1f3e:	0007851b          	sext.w	a0,a5
    1f42:	9d19                	subw	a0,a0,a4
    1f44:	8082                	ret
		return 0;
    1f46:	4501                	li	a0,0
}
    1f48:	8082                	ret
	return *l - *r;
    1f4a:	0015c703          	lbu	a4,1(a1)
    1f4e:	4501                	li	a0,0
    1f50:	9d19                	subw	a0,a0,a4
    1f52:	8082                	ret
    1f54:	0005c703          	lbu	a4,0(a1)
    1f58:	4501                	li	a0,0
    1f5a:	b7e5                	j	1f42 <strncmp+0x30>

0000000000001f5c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f5c:	00757793          	andi	a5,a0,7
    1f60:	cf89                	beqz	a5,1f7a <strlen+0x1e>
    1f62:	87aa                	mv	a5,a0
    1f64:	a029                	j	1f6e <strlen+0x12>
    1f66:	0785                	addi	a5,a5,1
    1f68:	0077f713          	andi	a4,a5,7
    1f6c:	cb01                	beqz	a4,1f7c <strlen+0x20>
		if (!*s)
    1f6e:	0007c703          	lbu	a4,0(a5)
    1f72:	fb75                	bnez	a4,1f66 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f74:	40a78533          	sub	a0,a5,a0
}
    1f78:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f7a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f7c:	6394                	ld	a3,0(a5)
    1f7e:	00001597          	auipc	a1,0x1
    1f82:	9325b583          	ld	a1,-1742(a1) # 28b0 <enable_deadlock_detect+0x1b6>
    1f86:	00001617          	auipc	a2,0x1
    1f8a:	93263603          	ld	a2,-1742(a2) # 28b8 <enable_deadlock_detect+0x1be>
    1f8e:	a019                	j	1f94 <strlen+0x38>
    1f90:	6794                	ld	a3,8(a5)
    1f92:	07a1                	addi	a5,a5,8
    1f94:	00b68733          	add	a4,a3,a1
    1f98:	fff6c693          	not	a3,a3
    1f9c:	8f75                	and	a4,a4,a3
    1f9e:	8f71                	and	a4,a4,a2
    1fa0:	db65                	beqz	a4,1f90 <strlen+0x34>
	for (; *s; s++)
    1fa2:	0007c703          	lbu	a4,0(a5)
    1fa6:	d779                	beqz	a4,1f74 <strlen+0x18>
    1fa8:	0017c703          	lbu	a4,1(a5)
    1fac:	0785                	addi	a5,a5,1
    1fae:	d379                	beqz	a4,1f74 <strlen+0x18>
    1fb0:	0017c703          	lbu	a4,1(a5)
    1fb4:	0785                	addi	a5,a5,1
    1fb6:	fb6d                	bnez	a4,1fa8 <strlen+0x4c>
    1fb8:	bf75                	j	1f74 <strlen+0x18>

0000000000001fba <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fba:	00757713          	andi	a4,a0,7
{
    1fbe:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1fc0:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fc4:	cb19                	beqz	a4,1fda <memchr+0x20>
    1fc6:	ce25                	beqz	a2,203e <memchr+0x84>
    1fc8:	0007c703          	lbu	a4,0(a5)
    1fcc:	04b70e63          	beq	a4,a1,2028 <memchr+0x6e>
    1fd0:	0785                	addi	a5,a5,1
    1fd2:	0077f713          	andi	a4,a5,7
    1fd6:	167d                	addi	a2,a2,-1
    1fd8:	f77d                	bnez	a4,1fc6 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1fda:	4501                	li	a0,0
	if (n && *s != c) {
    1fdc:	c235                	beqz	a2,2040 <memchr+0x86>
    1fde:	0007c703          	lbu	a4,0(a5)
    1fe2:	04b70363          	beq	a4,a1,2028 <memchr+0x6e>
		size_t k = ONES * c;
    1fe6:	00001517          	auipc	a0,0x1
    1fea:	8da53503          	ld	a0,-1830(a0) # 28c0 <enable_deadlock_detect+0x1c6>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fee:	471d                	li	a4,7
		size_t k = ONES * c;
    1ff0:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1ff4:	02c77a63          	bgeu	a4,a2,2028 <memchr+0x6e>
    1ff8:	00001897          	auipc	a7,0x1
    1ffc:	8b88b883          	ld	a7,-1864(a7) # 28b0 <enable_deadlock_detect+0x1b6>
    2000:	00001817          	auipc	a6,0x1
    2004:	8b883803          	ld	a6,-1864(a6) # 28b8 <enable_deadlock_detect+0x1be>
    2008:	431d                	li	t1,7
    200a:	a029                	j	2014 <memchr+0x5a>
		     w++, n -= SS)
    200c:	1661                	addi	a2,a2,-8
    200e:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2010:	02c37963          	bgeu	t1,a2,2042 <memchr+0x88>
    2014:	6398                	ld	a4,0(a5)
    2016:	8f29                	xor	a4,a4,a0
    2018:	011706b3          	add	a3,a4,a7
    201c:	fff74713          	not	a4,a4
    2020:	8f75                	and	a4,a4,a3
    2022:	01077733          	and	a4,a4,a6
    2026:	d37d                	beqz	a4,200c <memchr+0x52>
{
    2028:	853e                	mv	a0,a5
    202a:	97b2                	add	a5,a5,a2
    202c:	a021                	j	2034 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    202e:	0505                	addi	a0,a0,1
    2030:	00f50763          	beq	a0,a5,203e <memchr+0x84>
    2034:	00054703          	lbu	a4,0(a0)
    2038:	feb71be3          	bne	a4,a1,202e <memchr+0x74>
    203c:	8082                	ret
	return n ? (void *)s : 0;
    203e:	4501                	li	a0,0
}
    2040:	8082                	ret
	return n ? (void *)s : 0;
    2042:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2044:	f275                	bnez	a2,2028 <memchr+0x6e>
}
    2046:	8082                	ret

0000000000002048 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2048:	1101                	addi	sp,sp,-32
    204a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    204c:	862e                	mv	a2,a1
{
    204e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2050:	4581                	li	a1,0
{
    2052:	e426                	sd	s1,8(sp)
    2054:	ec06                	sd	ra,24(sp)
    2056:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2058:	f63ff0ef          	jal	ra,1fba <memchr>
	return p ? p - s : n;
    205c:	c519                	beqz	a0,206a <strnlen+0x22>
}
    205e:	60e2                	ld	ra,24(sp)
    2060:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2062:	8d05                	sub	a0,a0,s1
}
    2064:	64a2                	ld	s1,8(sp)
    2066:	6105                	addi	sp,sp,32
    2068:	8082                	ret
    206a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    206c:	8522                	mv	a0,s0
}
    206e:	6442                	ld	s0,16(sp)
    2070:	64a2                	ld	s1,8(sp)
    2072:	6105                	addi	sp,sp,32
    2074:	8082                	ret

0000000000002076 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2076:	00a5c7b3          	xor	a5,a1,a0
    207a:	8b9d                	andi	a5,a5,7
    207c:	eb95                	bnez	a5,20b0 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    207e:	0075f793          	andi	a5,a1,7
    2082:	e7b1                	bnez	a5,20ce <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2084:	6198                	ld	a4,0(a1)
    2086:	00001617          	auipc	a2,0x1
    208a:	82a63603          	ld	a2,-2006(a2) # 28b0 <enable_deadlock_detect+0x1b6>
    208e:	00001817          	auipc	a6,0x1
    2092:	82a83803          	ld	a6,-2006(a6) # 28b8 <enable_deadlock_detect+0x1be>
    2096:	a029                	j	20a0 <stpcpy+0x2a>
    2098:	05a1                	addi	a1,a1,8
    209a:	e118                	sd	a4,0(a0)
    209c:	6198                	ld	a4,0(a1)
    209e:	0521                	addi	a0,a0,8
    20a0:	00c707b3          	add	a5,a4,a2
    20a4:	fff74693          	not	a3,a4
    20a8:	8ff5                	and	a5,a5,a3
    20aa:	0107f7b3          	and	a5,a5,a6
    20ae:	d7ed                	beqz	a5,2098 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    20b0:	0005c783          	lbu	a5,0(a1)
    20b4:	00f50023          	sb	a5,0(a0)
    20b8:	c785                	beqz	a5,20e0 <stpcpy+0x6a>
    20ba:	0015c783          	lbu	a5,1(a1)
    20be:	0505                	addi	a0,a0,1
    20c0:	0585                	addi	a1,a1,1
    20c2:	00f50023          	sb	a5,0(a0)
    20c6:	fbf5                	bnez	a5,20ba <stpcpy+0x44>
		;
	return d;
}
    20c8:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20ca:	0505                	addi	a0,a0,1
    20cc:	df45                	beqz	a4,2084 <stpcpy+0xe>
			if (!(*d = *s))
    20ce:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20d2:	0585                	addi	a1,a1,1
    20d4:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20d8:	00f50023          	sb	a5,0(a0)
    20dc:	f7fd                	bnez	a5,20ca <stpcpy+0x54>
}
    20de:	8082                	ret
    20e0:	8082                	ret

00000000000020e2 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20e2:	00a5c7b3          	xor	a5,a1,a0
    20e6:	8b9d                	andi	a5,a5,7
    20e8:	1a079863          	bnez	a5,2298 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20ec:	0075f793          	andi	a5,a1,7
    20f0:	16078463          	beqz	a5,2258 <stpncpy+0x176>
    20f4:	ea01                	bnez	a2,2104 <stpncpy+0x22>
    20f6:	a421                	j	22fe <stpncpy+0x21c>
    20f8:	167d                	addi	a2,a2,-1
    20fa:	0505                	addi	a0,a0,1
    20fc:	14070e63          	beqz	a4,2258 <stpncpy+0x176>
    2100:	1a060863          	beqz	a2,22b0 <stpncpy+0x1ce>
    2104:	0005c783          	lbu	a5,0(a1)
    2108:	0585                	addi	a1,a1,1
    210a:	0075f713          	andi	a4,a1,7
    210e:	00f50023          	sb	a5,0(a0)
    2112:	f3fd                	bnez	a5,20f8 <stpncpy+0x16>
    2114:	4805                	li	a6,1
    2116:	1a061863          	bnez	a2,22c6 <stpncpy+0x1e4>
    211a:	40a007b3          	neg	a5,a0
    211e:	8b9d                	andi	a5,a5,7
    2120:	4681                	li	a3,0
    2122:	18061a63          	bnez	a2,22b6 <stpncpy+0x1d4>
    2126:	00778713          	addi	a4,a5,7
    212a:	45ad                	li	a1,11
    212c:	18b76363          	bltu	a4,a1,22b2 <stpncpy+0x1d0>
    2130:	1ae6eb63          	bltu	a3,a4,22e6 <stpncpy+0x204>
    2134:	1a078363          	beqz	a5,22da <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2138:	00050023          	sb	zero,0(a0)
    213c:	4685                	li	a3,1
    213e:	00150713          	addi	a4,a0,1
    2142:	18d78f63          	beq	a5,a3,22e0 <stpncpy+0x1fe>
    2146:	000500a3          	sb	zero,1(a0)
    214a:	4689                	li	a3,2
    214c:	00250713          	addi	a4,a0,2
    2150:	18d78e63          	beq	a5,a3,22ec <stpncpy+0x20a>
    2154:	00050123          	sb	zero,2(a0)
    2158:	468d                	li	a3,3
    215a:	00350713          	addi	a4,a0,3
    215e:	16d78c63          	beq	a5,a3,22d6 <stpncpy+0x1f4>
    2162:	000501a3          	sb	zero,3(a0)
    2166:	4691                	li	a3,4
    2168:	00450713          	addi	a4,a0,4
    216c:	18d78263          	beq	a5,a3,22f0 <stpncpy+0x20e>
    2170:	00050223          	sb	zero,4(a0)
    2174:	4695                	li	a3,5
    2176:	00550713          	addi	a4,a0,5
    217a:	16d78d63          	beq	a5,a3,22f4 <stpncpy+0x212>
    217e:	000502a3          	sb	zero,5(a0)
    2182:	469d                	li	a3,7
    2184:	00650713          	addi	a4,a0,6
    2188:	16d79863          	bne	a5,a3,22f8 <stpncpy+0x216>
    218c:	00750713          	addi	a4,a0,7
    2190:	00050323          	sb	zero,6(a0)
    2194:	40f80833          	sub	a6,a6,a5
    2198:	ff887593          	andi	a1,a6,-8
    219c:	97aa                	add	a5,a5,a0
    219e:	95be                	add	a1,a1,a5
    21a0:	0007b023          	sd	zero,0(a5)
    21a4:	07a1                	addi	a5,a5,8
    21a6:	feb79de3          	bne	a5,a1,21a0 <stpncpy+0xbe>
    21aa:	ff887593          	andi	a1,a6,-8
    21ae:	9ead                	addw	a3,a3,a1
    21b0:	00b707b3          	add	a5,a4,a1
    21b4:	12b80863          	beq	a6,a1,22e4 <stpncpy+0x202>
    21b8:	00078023          	sb	zero,0(a5)
    21bc:	0016871b          	addiw	a4,a3,1
    21c0:	0ec77863          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    21c4:	000780a3          	sb	zero,1(a5)
    21c8:	0026871b          	addiw	a4,a3,2
    21cc:	0ec77263          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    21d0:	00078123          	sb	zero,2(a5)
    21d4:	0036871b          	addiw	a4,a3,3
    21d8:	0cc77c63          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    21dc:	000781a3          	sb	zero,3(a5)
    21e0:	0046871b          	addiw	a4,a3,4
    21e4:	0cc77663          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    21e8:	00078223          	sb	zero,4(a5)
    21ec:	0056871b          	addiw	a4,a3,5
    21f0:	0cc77063          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    21f4:	000782a3          	sb	zero,5(a5)
    21f8:	0066871b          	addiw	a4,a3,6
    21fc:	0ac77a63          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    2200:	00078323          	sb	zero,6(a5)
    2204:	0076871b          	addiw	a4,a3,7
    2208:	0ac77463          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    220c:	000783a3          	sb	zero,7(a5)
    2210:	0086871b          	addiw	a4,a3,8
    2214:	08c77e63          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    2218:	00078423          	sb	zero,8(a5)
    221c:	0096871b          	addiw	a4,a3,9
    2220:	08c77863          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    2224:	000784a3          	sb	zero,9(a5)
    2228:	00a6871b          	addiw	a4,a3,10
    222c:	08c77263          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    2230:	00078523          	sb	zero,10(a5)
    2234:	00b6871b          	addiw	a4,a3,11
    2238:	06c77c63          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    223c:	000785a3          	sb	zero,11(a5)
    2240:	00c6871b          	addiw	a4,a3,12
    2244:	06c77663          	bgeu	a4,a2,22b0 <stpncpy+0x1ce>
    2248:	00078623          	sb	zero,12(a5)
    224c:	26b5                	addiw	a3,a3,13
    224e:	06c6f163          	bgeu	a3,a2,22b0 <stpncpy+0x1ce>
    2252:	000786a3          	sb	zero,13(a5)
    2256:	8082                	ret
			;
		if (!n || !*s)
    2258:	c645                	beqz	a2,2300 <stpncpy+0x21e>
    225a:	0005c783          	lbu	a5,0(a1)
    225e:	ea078be3          	beqz	a5,2114 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2262:	479d                	li	a5,7
    2264:	02c7ff63          	bgeu	a5,a2,22a2 <stpncpy+0x1c0>
    2268:	00000897          	auipc	a7,0x0
    226c:	6488b883          	ld	a7,1608(a7) # 28b0 <enable_deadlock_detect+0x1b6>
    2270:	00000817          	auipc	a6,0x0
    2274:	64883803          	ld	a6,1608(a6) # 28b8 <enable_deadlock_detect+0x1be>
    2278:	431d                	li	t1,7
    227a:	6198                	ld	a4,0(a1)
    227c:	011707b3          	add	a5,a4,a7
    2280:	fff74693          	not	a3,a4
    2284:	8ff5                	and	a5,a5,a3
    2286:	0107f7b3          	and	a5,a5,a6
    228a:	ef81                	bnez	a5,22a2 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    228c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    228e:	1661                	addi	a2,a2,-8
    2290:	05a1                	addi	a1,a1,8
    2292:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2294:	fec363e3          	bltu	t1,a2,227a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2298:	e609                	bnez	a2,22a2 <stpncpy+0x1c0>
    229a:	a08d                	j	22fc <stpncpy+0x21a>
    229c:	167d                	addi	a2,a2,-1
    229e:	0505                	addi	a0,a0,1
    22a0:	ca01                	beqz	a2,22b0 <stpncpy+0x1ce>
    22a2:	0005c783          	lbu	a5,0(a1)
    22a6:	0585                	addi	a1,a1,1
    22a8:	00f50023          	sb	a5,0(a0)
    22ac:	fbe5                	bnez	a5,229c <stpncpy+0x1ba>
		;
tail:
    22ae:	b59d                	j	2114 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    22b0:	8082                	ret
    22b2:	472d                	li	a4,11
    22b4:	bdb5                	j	2130 <stpncpy+0x4e>
    22b6:	00778713          	addi	a4,a5,7
    22ba:	45ad                	li	a1,11
    22bc:	fff60693          	addi	a3,a2,-1
    22c0:	e6b778e3          	bgeu	a4,a1,2130 <stpncpy+0x4e>
    22c4:	b7fd                	j	22b2 <stpncpy+0x1d0>
    22c6:	40a007b3          	neg	a5,a0
    22ca:	8832                	mv	a6,a2
    22cc:	8b9d                	andi	a5,a5,7
    22ce:	4681                	li	a3,0
    22d0:	e4060be3          	beqz	a2,2126 <stpncpy+0x44>
    22d4:	b7cd                	j	22b6 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22d6:	468d                	li	a3,3
    22d8:	bd75                	j	2194 <stpncpy+0xb2>
    22da:	872a                	mv	a4,a0
    22dc:	4681                	li	a3,0
    22de:	bd5d                	j	2194 <stpncpy+0xb2>
    22e0:	4685                	li	a3,1
    22e2:	bd4d                	j	2194 <stpncpy+0xb2>
    22e4:	8082                	ret
    22e6:	87aa                	mv	a5,a0
    22e8:	4681                	li	a3,0
    22ea:	b5f9                	j	21b8 <stpncpy+0xd6>
    22ec:	4689                	li	a3,2
    22ee:	b55d                	j	2194 <stpncpy+0xb2>
    22f0:	4691                	li	a3,4
    22f2:	b54d                	j	2194 <stpncpy+0xb2>
    22f4:	4695                	li	a3,5
    22f6:	bd79                	j	2194 <stpncpy+0xb2>
    22f8:	4699                	li	a3,6
    22fa:	bd69                	j	2194 <stpncpy+0xb2>
    22fc:	8082                	ret
    22fe:	8082                	ret
    2300:	8082                	ret

0000000000002302 <basename>:

char *basename(char *s)
{
    2302:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    2304:	c54d                	beqz	a0,23ae <basename+0xac>
    2306:	00054783          	lbu	a5,0(a0)
		return ".";
    230a:	00000517          	auipc	a0,0x0
    230e:	59e50513          	addi	a0,a0,1438 # 28a8 <enable_deadlock_detect+0x1ae>
	if (!s || !*s)
    2312:	e391                	bnez	a5,2316 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    2314:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2316:	0076f713          	andi	a4,a3,7
    231a:	87b6                	mv	a5,a3
    231c:	cf51                	beqz	a4,23b8 <basename+0xb6>
    231e:	0785                	addi	a5,a5,1
    2320:	0077f713          	andi	a4,a5,7
    2324:	c729                	beqz	a4,236e <basename+0x6c>
		if (!*s)
    2326:	0007c703          	lbu	a4,0(a5)
    232a:	fb75                	bnez	a4,231e <basename+0x1c>
	return s - a;
    232c:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    232e:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2330:	cf8d                	beqz	a5,236a <basename+0x68>
    2332:	00f68733          	add	a4,a3,a5
    2336:	02f00593          	li	a1,47
    233a:	a031                	j	2346 <basename+0x44>
		s[i] = 0;
    233c:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2340:	17fd                	addi	a5,a5,-1
    2342:	177d                	addi	a4,a4,-1
    2344:	c39d                	beqz	a5,236a <basename+0x68>
    2346:	00074603          	lbu	a2,0(a4)
    234a:	feb609e3          	beq	a2,a1,233c <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    234e:	02f00613          	li	a2,47
    2352:	a011                	j	2356 <basename+0x54>
    2354:	cb99                	beqz	a5,236a <basename+0x68>
    2356:	853e                	mv	a0,a5
    2358:	17fd                	addi	a5,a5,-1
    235a:	00f68733          	add	a4,a3,a5
    235e:	00074703          	lbu	a4,0(a4)
    2362:	fec719e3          	bne	a4,a2,2354 <basename+0x52>
	return s + i;
    2366:	9536                	add	a0,a0,a3
    2368:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    236a:	8536                	mv	a0,a3
    236c:	8082                	ret
    236e:	6390                	ld	a2,0(a5)
    2370:	00000517          	auipc	a0,0x0
    2374:	54053503          	ld	a0,1344(a0) # 28b0 <enable_deadlock_detect+0x1b6>
    2378:	00000597          	auipc	a1,0x0
    237c:	5405b583          	ld	a1,1344(a1) # 28b8 <enable_deadlock_detect+0x1be>
    2380:	fff64713          	not	a4,a2
    2384:	962a                	add	a2,a2,a0
    2386:	8f71                	and	a4,a4,a2
    2388:	8f6d                	and	a4,a4,a1
    238a:	eb11                	bnez	a4,239e <basename+0x9c>
    238c:	6790                	ld	a2,8(a5)
    238e:	07a1                	addi	a5,a5,8
    2390:	00a60733          	add	a4,a2,a0
    2394:	fff64613          	not	a2,a2
    2398:	8f71                	and	a4,a4,a2
    239a:	8f6d                	and	a4,a4,a1
    239c:	db65                	beqz	a4,238c <basename+0x8a>
	for (; *s; s++)
    239e:	0007c703          	lbu	a4,0(a5)
    23a2:	d749                	beqz	a4,232c <basename+0x2a>
    23a4:	0017c703          	lbu	a4,1(a5)
    23a8:	0785                	addi	a5,a5,1
    23aa:	ff6d                	bnez	a4,23a4 <basename+0xa2>
    23ac:	b741                	j	232c <basename+0x2a>
		return ".";
    23ae:	00000517          	auipc	a0,0x0
    23b2:	4fa50513          	addi	a0,a0,1274 # 28a8 <enable_deadlock_detect+0x1ae>
    23b6:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    23b8:	6290                	ld	a2,0(a3)
    23ba:	00000517          	auipc	a0,0x0
    23be:	4f653503          	ld	a0,1270(a0) # 28b0 <enable_deadlock_detect+0x1b6>
    23c2:	00000597          	auipc	a1,0x0
    23c6:	4f65b583          	ld	a1,1270(a1) # 28b8 <enable_deadlock_detect+0x1be>
    23ca:	fff64713          	not	a4,a2
    23ce:	962a                	add	a2,a2,a0
    23d0:	8f71                	and	a4,a4,a2
    23d2:	8f6d                	and	a4,a4,a1
    23d4:	df45                	beqz	a4,238c <basename+0x8a>
    23d6:	b7f9                	j	23a4 <basename+0xa2>

00000000000023d8 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23d8:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23dc:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23de:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23e2:	2501                	sext.w	a0,a0
    23e4:	8082                	ret

00000000000023e6 <close>:

int close(int fd)
{
	if (fd == 1) {
    23e6:	4785                	li	a5,1
    23e8:	00f50863          	beq	a0,a5,23f8 <close+0x12>
	register long a7 __asm__("a7") = n;
    23ec:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23f0:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23f4:	2501                	sext.w	a0,a0
    23f6:	8082                	ret
{
    23f8:	1101                	addi	sp,sp,-32
    23fa:	ec06                	sd	ra,24(sp)
    23fc:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23fe:	cdffe0ef          	jal	ra,10dc <__write_buffer>
		__clear_buffer();
    2402:	d03fe0ef          	jal	ra,1104 <__clear_buffer>
    2406:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    2408:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    240c:	00000073          	ecall
}
    2410:	60e2                	ld	ra,24(sp)
    2412:	2501                	sext.w	a0,a0
    2414:	6105                	addi	sp,sp,32
    2416:	8082                	ret

0000000000002418 <read>:
	register long a7 __asm__("a7") = n;
    2418:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    241c:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2420:	8082                	ret

0000000000002422 <write>:
	register long a7 __asm__("a7") = n;
    2422:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2426:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    242a:	8082                	ret

000000000000242c <getpid>:
	register long a7 __asm__("a7") = n;
    242c:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2430:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    2434:	2501                	sext.w	a0,a0
    2436:	8082                	ret

0000000000002438 <getppid>:
	register long a7 __asm__("a7") = n;
    2438:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    243c:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2440:	2501                	sext.w	a0,a0
    2442:	8082                	ret

0000000000002444 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2444:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2448:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    244c:	2501                	sext.w	a0,a0
    244e:	8082                	ret

0000000000002450 <fork>:
	register long a7 __asm__("a7") = n;
    2450:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2454:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2458:	2501                	sext.w	a0,a0
    245a:	8082                	ret

000000000000245c <exit>:

void exit(int code)
{
    245c:	1141                	addi	sp,sp,-16
    245e:	e406                	sd	ra,8(sp)
    2460:	e022                	sd	s0,0(sp)
    2462:	842a                	mv	s0,a0
	__write_buffer();
    2464:	c79fe0ef          	jal	ra,10dc <__write_buffer>
	__clear_buffer();
    2468:	c9dfe0ef          	jal	ra,1104 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    246c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2470:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2472:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2476:	60a2                	ld	ra,8(sp)
    2478:	6402                	ld	s0,0(sp)
    247a:	0141                	addi	sp,sp,16
    247c:	8082                	ret

000000000000247e <waitpid>:
	register long a7 __asm__("a7") = n;
    247e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2482:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2486:	2501                	sext.w	a0,a0
    2488:	8082                	ret

000000000000248a <exec>:
	register long a7 __asm__("a7") = n;
    248a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    248e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2492:	2501                	sext.w	a0,a0
    2494:	8082                	ret

0000000000002496 <get_mtime>:

int64 get_mtime()
{
    2496:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2498:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    249c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    249e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24a0:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    24a4:	2501                	sext.w	a0,a0
    24a6:	ed01                	bnez	a0,24be <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    24a8:	6722                	ld	a4,8(sp)
    24aa:	3e800793          	li	a5,1000
    24ae:	6682                	ld	a3,0(sp)
    24b0:	02f75733          	divu	a4,a4,a5
    24b4:	02d78533          	mul	a0,a5,a3
    24b8:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24ba:	0141                	addi	sp,sp,16
    24bc:	8082                	ret
	return -1;
    24be:	557d                	li	a0,-1
    24c0:	bfed                	j	24ba <get_mtime+0x24>

00000000000024c2 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24c2:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c6:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24ca:	2501                	sext.w	a0,a0
    24cc:	8082                	ret

00000000000024ce <sleep>:

int sleep(unsigned long long time)
{
    24ce:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24d0:	880a                	mv	a6,sp
{
    24d2:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24d4:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24d8:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24da:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24dc:	00000073          	ecall
	if (err == 0) {
    24e0:	2501                	sext.w	a0,a0
    24e2:	ed31                	bnez	a0,253e <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24e4:	6722                	ld	a4,8(sp)
    24e6:	3e800793          	li	a5,1000
    24ea:	6682                	ld	a3,0(sp)
    24ec:	02f75733          	divu	a4,a4,a5
    24f0:	02d787b3          	mul	a5,a5,a3
    24f4:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24f6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24fa:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24fc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24fe:	00000073          	ecall
	if (err == 0) {
    2502:	2501                	sext.w	a0,a0
    2504:	e915                	bnez	a0,2538 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    2506:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    2508:	3e800693          	li	a3,1000
    250c:	a819                	j	2522 <sleep+0x54>
	__asm_syscall("r"(a7))
    250e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2512:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2516:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    2518:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    251a:	00000073          	ecall
	if (err == 0) {
    251e:	2501                	sext.w	a0,a0
    2520:	ed01                	bnez	a0,2538 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2522:	6722                	ld	a4,8(sp)
    2524:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    2526:	07c00893          	li	a7,124
    252a:	02d75733          	divu	a4,a4,a3
    252e:	02f687b3          	mul	a5,a3,a5
    2532:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    2534:	fcc7ede3          	bltu	a5,a2,250e <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    2538:	4501                	li	a0,0
    253a:	0141                	addi	sp,sp,16
    253c:	8082                	ret
    253e:	57fd                	li	a5,-1
    2540:	bf5d                	j	24f6 <sleep+0x28>

0000000000002542 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2542:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2546:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    254a:	2501                	sext.w	a0,a0
    254c:	8082                	ret

000000000000254e <set_priority>:
	register long a7 __asm__("a7") = n;
    254e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2552:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2556:	2501                	sext.w	a0,a0
    2558:	8082                	ret

000000000000255a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    255a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    255e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2562:	2501                	sext.w	a0,a0
    2564:	8082                	ret

0000000000002566 <munmap>:
	register long a7 __asm__("a7") = n;
    2566:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    256a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    256e:	2501                	sext.w	a0,a0
    2570:	8082                	ret

0000000000002572 <wait>:

int wait(int *code)
{
    2572:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2574:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2578:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    257a:	00000073          	ecall
	return waitpid(-1, code);
}
    257e:	2501                	sext.w	a0,a0
    2580:	8082                	ret

0000000000002582 <spawn>:
	register long a7 __asm__("a7") = n;
    2582:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2586:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    258a:	2501                	sext.w	a0,a0
    258c:	8082                	ret

000000000000258e <pipe>:
	register long a7 __asm__("a7") = n;
    258e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2592:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2596:	2501                	sext.w	a0,a0
    2598:	8082                	ret

000000000000259a <mailread>:
	register long a7 __asm__("a7") = n;
    259a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <mailwrite>:
	register long a7 __asm__("a7") = n;
    25a6:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25aa:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    25ae:	2501                	sext.w	a0,a0
    25b0:	8082                	ret

00000000000025b2 <fstat>:
	register long a7 __asm__("a7") = n;
    25b2:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    25b6:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25ba:	2501                	sext.w	a0,a0
    25bc:	8082                	ret

00000000000025be <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25be:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25c0:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25c4:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25c6:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25ca:	2501                	sext.w	a0,a0
    25cc:	8082                	ret

00000000000025ce <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25ce:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25d0:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25d4:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25d6:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25da:	2501                	sext.w	a0,a0
    25dc:	8082                	ret

00000000000025de <link>:

int link(char *old_path, char *new_path)
{
    25de:	87aa                	mv	a5,a0
    25e0:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25e2:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25e6:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25ea:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25ec:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25f0:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25f2:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25f6:	2501                	sext.w	a0,a0
    25f8:	8082                	ret

00000000000025fa <unlink>:

int unlink(char *path)
{
    25fa:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25fc:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    2600:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    2604:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2606:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    260a:	2501                	sext.w	a0,a0
    260c:	8082                	ret

000000000000260e <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    260e:	00000797          	auipc	a5,0x0
    2612:	3ea7b783          	ld	a5,1002(a5) # 29f8 <_GLOBAL_OFFSET_TABLE_+0x8>
    2616:	439c                	lw	a5,0(a5)
    2618:	c799                	beqz	a5,2626 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    261a:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    261e:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2622:	2501                	sext.w	a0,a0
    2624:	8082                	ret
{
    2626:	1101                	addi	sp,sp,-32
    2628:	ec06                	sd	ra,24(sp)
    262a:	e42e                	sd	a1,8(sp)
    262c:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    262e:	fe7fe0ef          	jal	ra,1614 <enable_thread_io_buffer>
    2632:	65a2                	ld	a1,8(sp)
    2634:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    2636:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    263a:	00000073          	ecall
}
    263e:	60e2                	ld	ra,24(sp)
    2640:	2501                	sext.w	a0,a0
    2642:	6105                	addi	sp,sp,32
    2644:	8082                	ret

0000000000002646 <gettid>:
	register long a7 __asm__("a7") = n;
    2646:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    264a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    264e:	2501                	sext.w	a0,a0
    2650:	8082                	ret

0000000000002652 <waittid>:

int waittid(int tid)
{
    2652:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2654:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2658:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    265c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    265e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2660:	00e51e63          	bne	a0,a4,267c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2664:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2668:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    266c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2670:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2672:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2676:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2678:	fee506e3          	beq	a0,a4,2664 <waittid+0x12>
	}
	return ret;
}
    267c:	8082                	ret

000000000000267e <mutex_create>:
	register long a7 __asm__("a7") = n;
    267e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2682:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2684:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    268c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2690:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2692:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2696:	2501                	sext.w	a0,a0
    2698:	8082                	ret

000000000000269a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    269a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    269e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    26a2:	2501                	sext.w	a0,a0
    26a4:	8082                	ret

00000000000026a6 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    26a6:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    26aa:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    26ae:	2501                	sext.w	a0,a0
    26b0:	8082                	ret

00000000000026b2 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    26b2:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    26b6:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26ba:	2501                	sext.w	a0,a0
    26bc:	8082                	ret

00000000000026be <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26be:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26c2:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26c6:	2501                	sext.w	a0,a0
    26c8:	8082                	ret

00000000000026ca <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26ca:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26ce:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26d2:	2501                	sext.w	a0,a0
    26d4:	8082                	ret

00000000000026d6 <condvar_create>:
	register long a7 __asm__("a7") = n;
    26d6:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26da:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26de:	2501                	sext.w	a0,a0
    26e0:	8082                	ret

00000000000026e2 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26e2:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26e6:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26ea:	2501                	sext.w	a0,a0
    26ec:	8082                	ret

00000000000026ee <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26ee:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26f2:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26f6:	2501                	sext.w	a0,a0
    26f8:	8082                	ret

00000000000026fa <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26fa:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26fe:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    2702:	2501                	sext.w	a0,a0
    2704:	8082                	ret
