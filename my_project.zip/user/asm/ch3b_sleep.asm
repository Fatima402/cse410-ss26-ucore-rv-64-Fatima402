
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch3b_sleep:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a059                	j	1086 <__start_main>

0000000000001002 <main>:
/// Test sleep OK!

/// 注意不要单纯以 OK! 作为判断，还要注意输出时间是否符合实际。

int main()
{
    1002:	1101                	addi	sp,sp,-32
    1004:	e822                	sd	s0,16(sp)
    1006:	ec06                	sd	ra,24(sp)
    1008:	e426                	sd	s1,8(sp)
	int64 current_time = get_mtime();
    100a:	472010ef          	jal	ra,247c <get_mtime>
    100e:	842a                	mv	s0,a0
	assert(current_time > 0);
    1010:	04a05063          	blez	a0,1050 <main+0x4e>
	printf("get_time OK! %d\n", current_time);
    1014:	85a2                	mv	a1,s0
    1016:	00001517          	auipc	a0,0x1
    101a:	76a50513          	addi	a0,a0,1898 # 2780 <enable_deadlock_detect+0xa0>
    101e:	1c2000ef          	jal	ra,11e0 <printf>
	int64 wait_for = current_time + 3000;
    1022:	6785                	lui	a5,0x1
    1024:	bb878793          	addi	a5,a5,-1096 # bb8 <_start-0x448>
    1028:	943e                	add	s0,s0,a5
	while (get_mtime() < wait_for) {
    102a:	a019                	j	1030 <main+0x2e>
		sched_yield();
    102c:	3fe010ef          	jal	ra,242a <sched_yield>
	while (get_mtime() < wait_for) {
    1030:	44c010ef          	jal	ra,247c <get_mtime>
    1034:	fe854ce3          	blt	a0,s0,102c <main+0x2a>
	}
	puts("Test sleep OK!");
    1038:	00001517          	auipc	a0,0x1
    103c:	76050513          	addi	a0,a0,1888 # 2798 <enable_deadlock_detect+0xb8>
    1040:	0b7000ef          	jal	ra,18f6 <puts>
	return 0;
    1044:	60e2                	ld	ra,24(sp)
    1046:	6442                	ld	s0,16(sp)
    1048:	64a2                	ld	s1,8(sp)
    104a:	4501                	li	a0,0
    104c:	6105                	addi	sp,sp,32
    104e:	8082                	ret
	assert(current_time > 0);
    1050:	3c2010ef          	jal	ra,2412 <getpid>
    1054:	84aa                	mv	s1,a0
    1056:	00001517          	auipc	a0,0x1
    105a:	69a50513          	addi	a0,a0,1690 # 26f0 <enable_deadlock_detect+0x10>
    105e:	28a010ef          	jal	ra,22e8 <basename>
    1062:	872a                	mv	a4,a0
    1064:	47b9                	li	a5,14
    1066:	00001517          	auipc	a0,0x1
    106a:	6da50513          	addi	a0,a0,1754 # 2740 <enable_deadlock_detect+0x60>
    106e:	86a6                	mv	a3,s1
    1070:	00001617          	auipc	a2,0x1
    1074:	6c860613          	addi	a2,a2,1736 # 2738 <enable_deadlock_detect+0x58>
    1078:	45fd                	li	a1,31
    107a:	166000ef          	jal	ra,11e0 <printf>
    107e:	557d                	li	a0,-1
    1080:	3c2010ef          	jal	ra,2442 <exit>
    1084:	bf41                	j	1014 <main+0x12>

0000000000001086 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1086:	1141                	addi	sp,sp,-16
    1088:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    108a:	f79ff0ef          	jal	ra,1002 <main>
    108e:	3b4010ef          	jal	ra,2442 <exit>
	return 0;
    1092:	60a2                	ld	ra,8(sp)
    1094:	4501                	li	a0,0
    1096:	0141                	addi	sp,sp,16
    1098:	8082                	ret

000000000000109a <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    109a:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    109c:	4605                	li	a2,1
    109e:	00f10593          	addi	a1,sp,15
    10a2:	4501                	li	a0,0
{
    10a4:	ec06                	sd	ra,24(sp)
	char byte = 0;
    10a6:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    10aa:	354010ef          	jal	ra,23fe <read>
    10ae:	4785                	li	a5,1
    10b0:	00f51763          	bne	a0,a5,10be <getchar+0x24>
		return byte;
    10b4:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    10b8:	60e2                	ld	ra,24(sp)
    10ba:	6105                	addi	sp,sp,32
    10bc:	8082                	ret
		return EOF;
    10be:	557d                	li	a0,-1
    10c0:	bfe5                	j	10b8 <getchar+0x1e>

00000000000010c2 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    10c2:	00001517          	auipc	a0,0x1
    10c6:	7de52503          	lw	a0,2014(a0) # 28a0 <buffer_len>
    10ca:	e111                	bnez	a0,10ce <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    10cc:	8082                	ret
{
    10ce:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    10d0:	862a                	mv	a2,a0
    10d2:	00001597          	auipc	a1,0x1
    10d6:	7d658593          	addi	a1,a1,2006 # 28a8 <buffer>
    10da:	4505                	li	a0,1
{
    10dc:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10de:	32a010ef          	jal	ra,2408 <write>
}
    10e2:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    10e4:	2501                	sext.w	a0,a0
}
    10e6:	0141                	addi	sp,sp,16
    10e8:	8082                	ret

00000000000010ea <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    10ea:	00001797          	auipc	a5,0x1
    10ee:	7a07ab23          	sw	zero,1974(a5) # 28a0 <buffer_len>
}
    10f2:	8082                	ret

00000000000010f4 <__fflush>:
	if (buffer_len == 0)
    10f4:	00001517          	auipc	a0,0x1
    10f8:	7ac52503          	lw	a0,1964(a0) # 28a0 <buffer_len>
    10fc:	e511                	bnez	a0,1108 <__fflush+0x14>
	buffer_len = 0;
    10fe:	00001797          	auipc	a5,0x1
    1102:	7a07a123          	sw	zero,1954(a5) # 28a0 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    1106:	8082                	ret
{
    1108:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    110a:	862a                	mv	a2,a0
    110c:	00001597          	auipc	a1,0x1
    1110:	79c58593          	addi	a1,a1,1948 # 28a8 <buffer>
    1114:	4505                	li	a0,1
{
    1116:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1118:	2f0010ef          	jal	ra,2408 <write>
	return r >= 0 ? 0 : r;
    111c:	0005079b          	sext.w	a5,a0
}
    1120:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    1122:	0017a793          	slti	a5,a5,1
    1126:	40f007bb          	negw	a5,a5
    112a:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    112c:	00001797          	auipc	a5,0x1
    1130:	7607aa23          	sw	zero,1908(a5) # 28a0 <buffer_len>
	return r >= 0 ? 0 : r;
    1134:	2501                	sext.w	a0,a0
}
    1136:	0141                	addi	sp,sp,16
    1138:	8082                	ret

000000000000113a <fflush>:

int fflush(int fd)
{
    113a:	1101                	addi	sp,sp,-32
    113c:	e822                	sd	s0,16(sp)
    113e:	ec06                	sd	ra,24(sp)
    1140:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    1142:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    1144:	4401                	li	s0,0
	if (fd == 1) {
    1146:	00e50863          	beq	a0,a4,1156 <fflush+0x1c>
}
    114a:	60e2                	ld	ra,24(sp)
    114c:	8522                	mv	a0,s0
    114e:	6442                	ld	s0,16(sp)
    1150:	64a2                	ld	s1,8(sp)
    1152:	6105                	addi	sp,sp,32
    1154:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1156:	00001497          	auipc	s1,0x1
    115a:	74a48493          	addi	s1,s1,1866 # 28a0 <buffer_len>
    115e:	1084a703          	lw	a4,264(s1)
    1162:	02a70e63          	beq	a4,a0,119e <fflush+0x64>
	if (buffer_len == 0)
    1166:	4080                	lw	s0,0(s1)
    1168:	c00d                	beqz	s0,118a <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    116a:	8622                	mv	a2,s0
    116c:	00001597          	auipc	a1,0x1
    1170:	73c58593          	addi	a1,a1,1852 # 28a8 <buffer>
    1174:	294010ef          	jal	ra,2408 <write>
	return r >= 0 ? 0 : r;
    1178:	0005079b          	sext.w	a5,a0
    117c:	0017a793          	slti	a5,a5,1
    1180:	40f007bb          	negw	a5,a5
    1184:	8d7d                	and	a0,a0,a5
    1186:	0005041b          	sext.w	s0,a0
}
    118a:	60e2                	ld	ra,24(sp)
    118c:	8522                	mv	a0,s0
    118e:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1190:	00001797          	auipc	a5,0x1
    1194:	7007a823          	sw	zero,1808(a5) # 28a0 <buffer_len>
}
    1198:	64a2                	ld	s1,8(sp)
    119a:	6105                	addi	sp,sp,32
    119c:	8082                	ret
			mutex_lock(buffer_lock);
    119e:	10c4a503          	lw	a0,268(s1)
    11a2:	4de010ef          	jal	ra,2680 <mutex_lock>
	if (buffer_len == 0)
    11a6:	4080                	lw	s0,0(s1)
    11a8:	e811                	bnez	s0,11bc <fflush+0x82>
			mutex_unlock(buffer_lock);
    11aa:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    11ae:	00001797          	auipc	a5,0x1
    11b2:	6e07a923          	sw	zero,1778(a5) # 28a0 <buffer_len>
			mutex_unlock(buffer_lock);
    11b6:	4d6010ef          	jal	ra,268c <mutex_unlock>
    11ba:	bf41                	j	114a <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    11bc:	8622                	mv	a2,s0
    11be:	00001597          	auipc	a1,0x1
    11c2:	6ea58593          	addi	a1,a1,1770 # 28a8 <buffer>
    11c6:	4505                	li	a0,1
    11c8:	240010ef          	jal	ra,2408 <write>
	return r >= 0 ? 0 : r;
    11cc:	0005079b          	sext.w	a5,a0
    11d0:	0017a793          	slti	a5,a5,1
    11d4:	40f007bb          	negw	a5,a5
    11d8:	8d7d                	and	a0,a0,a5
    11da:	0005041b          	sext.w	s0,a0
	return r;
    11de:	b7f1                	j	11aa <fflush+0x70>

00000000000011e0 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    11e0:	7131                	addi	sp,sp,-192
    11e2:	e0da                	sd	s6,64(sp)
    11e4:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    11e6:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    11e8:	013c                	addi	a5,sp,136
{
    11ea:	f0ca                	sd	s2,96(sp)
    11ec:	ecce                	sd	s3,88(sp)
    11ee:	e8d2                	sd	s4,80(sp)
    11f0:	e4d6                	sd	s5,72(sp)
    11f2:	fc86                	sd	ra,120(sp)
    11f4:	f8a2                	sd	s0,112(sp)
    11f6:	f4a6                	sd	s1,104(sp)
    11f8:	89aa                	mv	s3,a0
    11fa:	e52e                	sd	a1,136(sp)
    11fc:	e932                	sd	a2,144(sp)
    11fe:	ed36                	sd	a3,152(sp)
    1200:	f13a                	sd	a4,160(sp)
    1202:	f942                	sd	a6,176(sp)
    1204:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    1206:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    1208:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    120c:	00001a17          	auipc	s4,0x1
    1210:	694a0a13          	addi	s4,s4,1684 # 28a0 <buffer_len>
    1214:	4a85                	li	s5,1
	buf[i++] = '0';
    1216:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    121a:	0009c783          	lbu	a5,0(s3)
    121e:	18078663          	beqz	a5,13aa <printf+0x1ca>
    1222:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    1224:	19278d63          	beq	a5,s2,13be <printf+0x1de>
    1228:	0015c783          	lbu	a5,1(a1)
    122c:	0585                	addi	a1,a1,1
    122e:	fbfd                	bnez	a5,1224 <printf+0x44>
    1230:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    1232:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1236:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    123a:	1b578863          	beq	a5,s5,13ea <printf+0x20a>
		len = out_unlocked(s, l);
    123e:	85a2                	mv	a1,s0
    1240:	854e                	mv	a0,s3
    1242:	42a000ef          	jal	ra,166c <out_unlocked>
		out(f, a, l);
		if (l)
    1246:	1c041063          	bnez	s0,1406 <printf+0x226>
			continue;
		if (s[1] == 0)
    124a:	0014c783          	lbu	a5,1(s1)
    124e:	14078e63          	beqz	a5,13aa <printf+0x1ca>
			break;
		switch (s[1]) {
    1252:	07300713          	li	a4,115
    1256:	1ce78863          	beq	a5,a4,1426 <printf+0x246>
    125a:	1af76863          	bltu	a4,a5,140a <printf+0x22a>
    125e:	06400713          	li	a4,100
    1262:	22e78063          	beq	a5,a4,1482 <printf+0x2a2>
    1266:	07000713          	li	a4,112
    126a:	1ee79563          	bne	a5,a4,1454 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    126e:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1270:	00001797          	auipc	a5,0x1
    1274:	74078793          	addi	a5,a5,1856 # 29b0 <digits>
	buf[i++] = '0';
    1278:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    127c:	6298                	ld	a4,0(a3)
    127e:	06a1                	addi	a3,a3,8
    1280:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1282:	00471393          	slli	t2,a4,0x4
    1286:	00871293          	slli	t0,a4,0x8
    128a:	00c71f93          	slli	t6,a4,0xc
    128e:	01071f13          	slli	t5,a4,0x10
    1292:	01471e93          	slli	t4,a4,0x14
    1296:	01871e13          	slli	t3,a4,0x18
    129a:	01c71893          	slli	a7,a4,0x1c
    129e:	02471813          	slli	a6,a4,0x24
    12a2:	02871513          	slli	a0,a4,0x28
    12a6:	02c71593          	slli	a1,a4,0x2c
    12aa:	03071613          	slli	a2,a4,0x30
    12ae:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    12b2:	03c75413          	srli	s0,a4,0x3c
    12b6:	01c7531b          	srliw	t1,a4,0x1c
    12ba:	03c3d393          	srli	t2,t2,0x3c
    12be:	03c2d293          	srli	t0,t0,0x3c
    12c2:	03cfdf93          	srli	t6,t6,0x3c
    12c6:	03cf5f13          	srli	t5,t5,0x3c
    12ca:	03cede93          	srli	t4,t4,0x3c
    12ce:	03ce5e13          	srli	t3,t3,0x3c
    12d2:	03c8d893          	srli	a7,a7,0x3c
    12d6:	03c85813          	srli	a6,a6,0x3c
    12da:	9171                	srli	a0,a0,0x3c
    12dc:	91f1                	srli	a1,a1,0x3c
    12de:	9271                	srli	a2,a2,0x3c
    12e0:	92f1                	srli	a3,a3,0x3c
    12e2:	95be                	add	a1,a1,a5
    12e4:	963e                	add	a2,a2,a5
    12e6:	96be                	add	a3,a3,a5
    12e8:	943e                	add	s0,s0,a5
    12ea:	93be                	add	t2,t2,a5
    12ec:	92be                	add	t0,t0,a5
    12ee:	9fbe                	add	t6,t6,a5
    12f0:	9f3e                	add	t5,t5,a5
    12f2:	9ebe                	add	t4,t4,a5
    12f4:	9e3e                	add	t3,t3,a5
    12f6:	98be                	add	a7,a7,a5
    12f8:	933e                	add	t1,t1,a5
    12fa:	983e                	add	a6,a6,a5
    12fc:	953e                	add	a0,a0,a5
    12fe:	0005c983          	lbu	s3,0(a1)
    1302:	00044403          	lbu	s0,0(s0)
    1306:	00064583          	lbu	a1,0(a2)
    130a:	0003c383          	lbu	t2,0(t2)
    130e:	0006c603          	lbu	a2,0(a3)
    1312:	0002c283          	lbu	t0,0(t0)
    1316:	000fcf83          	lbu	t6,0(t6)
    131a:	000f4f03          	lbu	t5,0(t5)
    131e:	000ece83          	lbu	t4,0(t4)
    1322:	000e4e03          	lbu	t3,0(t3)
    1326:	0008c883          	lbu	a7,0(a7)
    132a:	00034303          	lbu	t1,0(t1)
    132e:	00084803          	lbu	a6,0(a6)
    1332:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1336:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    133a:	92f1                	srli	a3,a3,0x3c
    133c:	8b3d                	andi	a4,a4,15
    133e:	96be                	add	a3,a3,a5
    1340:	97ba                	add	a5,a5,a4
    1342:	00810d23          	sb	s0,26(sp)
    1346:	00710da3          	sb	t2,27(sp)
    134a:	00510e23          	sb	t0,28(sp)
    134e:	01f10ea3          	sb	t6,29(sp)
    1352:	01e10f23          	sb	t5,30(sp)
    1356:	01d10fa3          	sb	t4,31(sp)
    135a:	03c10023          	sb	t3,32(sp)
    135e:	031100a3          	sb	a7,33(sp)
    1362:	02610123          	sb	t1,34(sp)
    1366:	030101a3          	sb	a6,35(sp)
    136a:	02a10223          	sb	a0,36(sp)
    136e:	033102a3          	sb	s3,37(sp)
    1372:	02b10323          	sb	a1,38(sp)
    1376:	02c103a3          	sb	a2,39(sp)
    137a:	0006c683          	lbu	a3,0(a3)
    137e:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1382:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1386:	02d10423          	sb	a3,40(sp)
    138a:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    138e:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1392:	11578263          	beq	a5,s5,1496 <printf+0x2b6>
		len = out_unlocked(s, l);
    1396:	45c9                	li	a1,18
    1398:	0828                	addi	a0,sp,24
    139a:	2d2000ef          	jal	ra,166c <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    139e:	00248993          	addi	s3,s1,2
		if (!*s)
    13a2:	0009c783          	lbu	a5,0(s3)
    13a6:	e6079ee3          	bnez	a5,1222 <printf+0x42>
	}
	va_end(ap);
    13aa:	70e6                	ld	ra,120(sp)
    13ac:	7446                	ld	s0,112(sp)
    13ae:	74a6                	ld	s1,104(sp)
    13b0:	7906                	ld	s2,96(sp)
    13b2:	69e6                	ld	s3,88(sp)
    13b4:	6a46                	ld	s4,80(sp)
    13b6:	6aa6                	ld	s5,72(sp)
    13b8:	6b06                	ld	s6,64(sp)
    13ba:	6129                	addi	sp,sp,192
    13bc:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    13be:	0005c783          	lbu	a5,0(a1)
    13c2:	84ae                	mv	s1,a1
    13c4:	01278963          	beq	a5,s2,13d6 <printf+0x1f6>
    13c8:	b5ad                	j	1232 <printf+0x52>
    13ca:	0024c783          	lbu	a5,2(s1)
    13ce:	0585                	addi	a1,a1,1
    13d0:	0489                	addi	s1,s1,2
    13d2:	e72790e3          	bne	a5,s2,1232 <printf+0x52>
    13d6:	0014c783          	lbu	a5,1(s1)
    13da:	ff2788e3          	beq	a5,s2,13ca <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    13de:	108a2783          	lw	a5,264(s4)
		l = z - a;
    13e2:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    13e6:	e5579ce3          	bne	a5,s5,123e <printf+0x5e>
		mutex_lock(buffer_lock);
    13ea:	10ca2503          	lw	a0,268(s4)
    13ee:	292010ef          	jal	ra,2680 <mutex_lock>
		len = out_unlocked(s, l);
    13f2:	85a2                	mv	a1,s0
    13f4:	854e                	mv	a0,s3
    13f6:	276000ef          	jal	ra,166c <out_unlocked>
		mutex_unlock(buffer_lock);
    13fa:	10ca2503          	lw	a0,268(s4)
    13fe:	28e010ef          	jal	ra,268c <mutex_unlock>
		if (l)
    1402:	e40404e3          	beqz	s0,124a <printf+0x6a>
    1406:	89a6                	mv	s3,s1
    1408:	bd09                	j	121a <printf+0x3a>
		switch (s[1]) {
    140a:	07800713          	li	a4,120
    140e:	04e79363          	bne	a5,a4,1454 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    1412:	67c2                	ld	a5,16(sp)
    1414:	45c1                	li	a1,16
		s += 2;
    1416:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    141a:	4388                	lw	a0,0(a5)
    141c:	07a1                	addi	a5,a5,8
    141e:	e83e                	sd	a5,16(sp)
    1420:	5f8000ef          	jal	ra,1a18 <printint.constprop.0>
		s += 2;
    1424:	bfbd                	j	13a2 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1426:	67c2                	ld	a5,16(sp)
    1428:	6380                	ld	s0,0(a5)
    142a:	07a1                	addi	a5,a5,8
    142c:	e83e                	sd	a5,16(sp)
    142e:	1c040163          	beqz	s0,15f0 <printf+0x410>
			l = strnlen(a, 200);
    1432:	0c800593          	li	a1,200
    1436:	8522                	mv	a0,s0
    1438:	3f7000ef          	jal	ra,202e <strnlen>
	if (buffer_lock_enabled == 1) {
    143c:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    1440:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    1444:	19578663          	beq	a5,s5,15d0 <printf+0x3f0>
		len = out_unlocked(s, l);
    1448:	8522                	mv	a0,s0
    144a:	222000ef          	jal	ra,166c <out_unlocked>
		s += 2;
    144e:	00248993          	addi	s3,s1,2
    1452:	bf81                	j	13a2 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1454:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1458:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    145c:	0f578663          	beq	a5,s5,1548 <printf+0x368>
		len = out_unlocked(s, l);
    1460:	0828                	addi	a0,sp,24
    1462:	316000ef          	jal	ra,1778 <out_unlocked.constprop.0>
			putchar(s[1]);
    1466:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    146a:	108a2783          	lw	a5,264(s4)
	char byte = c;
    146e:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1472:	05578163          	beq	a5,s5,14b4 <printf+0x2d4>
		len = out_unlocked(s, l);
    1476:	0828                	addi	a0,sp,24
    1478:	300000ef          	jal	ra,1778 <out_unlocked.constprop.0>
		s += 2;
    147c:	00248993          	addi	s3,s1,2
    1480:	b70d                	j	13a2 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1482:	67c2                	ld	a5,16(sp)
    1484:	45a9                	li	a1,10
		s += 2;
    1486:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    148a:	4388                	lw	a0,0(a5)
    148c:	07a1                	addi	a5,a5,8
    148e:	e83e                	sd	a5,16(sp)
    1490:	588000ef          	jal	ra,1a18 <printint.constprop.0>
		s += 2;
    1494:	b739                	j	13a2 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1496:	10ca2503          	lw	a0,268(s4)
		s += 2;
    149a:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    149e:	1e2010ef          	jal	ra,2680 <mutex_lock>
		len = out_unlocked(s, l);
    14a2:	45c9                	li	a1,18
    14a4:	0828                	addi	a0,sp,24
    14a6:	1c6000ef          	jal	ra,166c <out_unlocked>
		mutex_unlock(buffer_lock);
    14aa:	10ca2503          	lw	a0,268(s4)
    14ae:	1de010ef          	jal	ra,268c <mutex_unlock>
		s += 2;
    14b2:	bdc5                	j	13a2 <printf+0x1c2>
		mutex_lock(buffer_lock);
    14b4:	10ca2503          	lw	a0,268(s4)
    14b8:	1c8010ef          	jal	ra,2680 <mutex_lock>
		buffer[buffer_len++] = c;
    14bc:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14c0:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    14c4:	0017861b          	addiw	a2,a5,1
    14c8:	97d2                	add	a5,a5,s4
    14ca:	00ca2023          	sw	a2,0(s4)
    14ce:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    14d2:	00c6cc63          	blt	a3,a2,14ea <printf+0x30a>
    14d6:	47a9                	li	a5,10
    14d8:	06f40663          	beq	s0,a5,1544 <printf+0x364>
		mutex_unlock(buffer_lock);
    14dc:	10ca2503          	lw	a0,268(s4)
		s += 2;
    14e0:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    14e4:	1a8010ef          	jal	ra,268c <mutex_unlock>
		s += 2;
    14e8:	bd6d                	j	13a2 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    14ea:	10000793          	li	a5,256
    14ee:	00f61e63          	bne	a2,a5,150a <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    14f2:	00001597          	auipc	a1,0x1
    14f6:	3b658593          	addi	a1,a1,950 # 28a8 <buffer>
    14fa:	4505                	li	a0,1
    14fc:	70d000ef          	jal	ra,2408 <write>
	buffer_len = 0;
    1500:	00001797          	auipc	a5,0x1
    1504:	3a07a023          	sw	zero,928(a5) # 28a0 <buffer_len>
			if (r < 0) {
    1508:	bfd1                	j	14dc <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    150a:	709000ef          	jal	ra,2412 <getpid>
    150e:	842a                	mv	s0,a0
    1510:	00001517          	auipc	a0,0x1
    1514:	2a050513          	addi	a0,a0,672 # 27b0 <enable_deadlock_detect+0xd0>
    1518:	5d1000ef          	jal	ra,22e8 <basename>
    151c:	872a                	mv	a4,a0
    151e:	00001617          	auipc	a2,0x1
    1522:	21a60613          	addi	a2,a2,538 # 2738 <enable_deadlock_detect+0x58>
    1526:	05400793          	li	a5,84
    152a:	86a2                	mv	a3,s0
    152c:	45fd                	li	a1,31
    152e:	00001517          	auipc	a0,0x1
    1532:	2c250513          	addi	a0,a0,706 # 27f0 <enable_deadlock_detect+0x110>
    1536:	cabff0ef          	jal	ra,11e0 <printf>
    153a:	557d                	li	a0,-1
    153c:	707000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    1540:	000a2603          	lw	a2,0(s4)
    1544:	de41                	beqz	a2,14dc <printf+0x2fc>
    1546:	b775                	j	14f2 <printf+0x312>
		mutex_lock(buffer_lock);
    1548:	10ca2503          	lw	a0,268(s4)
    154c:	134010ef          	jal	ra,2680 <mutex_lock>
		buffer[buffer_len++] = c;
    1550:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1554:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1558:	0017861b          	addiw	a2,a5,1
    155c:	97d2                	add	a5,a5,s4
    155e:	00ca2023          	sw	a2,0(s4)
    1562:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1566:	02c6d163          	bge	a3,a2,1588 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    156a:	10000793          	li	a5,256
    156e:	02f61263          	bne	a2,a5,1592 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1572:	00001597          	auipc	a1,0x1
    1576:	33658593          	addi	a1,a1,822 # 28a8 <buffer>
    157a:	4505                	li	a0,1
    157c:	68d000ef          	jal	ra,2408 <write>
	buffer_len = 0;
    1580:	00001797          	auipc	a5,0x1
    1584:	3207a023          	sw	zero,800(a5) # 28a0 <buffer_len>
		mutex_unlock(buffer_lock);
    1588:	10ca2503          	lw	a0,268(s4)
    158c:	100010ef          	jal	ra,268c <mutex_unlock>
    1590:	bdd9                	j	1466 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1592:	681000ef          	jal	ra,2412 <getpid>
    1596:	842a                	mv	s0,a0
    1598:	00001517          	auipc	a0,0x1
    159c:	21850513          	addi	a0,a0,536 # 27b0 <enable_deadlock_detect+0xd0>
    15a0:	549000ef          	jal	ra,22e8 <basename>
    15a4:	872a                	mv	a4,a0
    15a6:	00001617          	auipc	a2,0x1
    15aa:	19260613          	addi	a2,a2,402 # 2738 <enable_deadlock_detect+0x58>
    15ae:	05400793          	li	a5,84
    15b2:	86a2                	mv	a3,s0
    15b4:	45fd                	li	a1,31
    15b6:	00001517          	auipc	a0,0x1
    15ba:	23a50513          	addi	a0,a0,570 # 27f0 <enable_deadlock_detect+0x110>
    15be:	c23ff0ef          	jal	ra,11e0 <printf>
    15c2:	557d                	li	a0,-1
    15c4:	67f000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    15c8:	000a2603          	lw	a2,0(s4)
    15cc:	de55                	beqz	a2,1588 <printf+0x3a8>
    15ce:	b755                	j	1572 <printf+0x392>
		mutex_lock(buffer_lock);
    15d0:	10ca2503          	lw	a0,268(s4)
    15d4:	e42e                	sd	a1,8(sp)
		s += 2;
    15d6:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    15da:	0a6010ef          	jal	ra,2680 <mutex_lock>
		len = out_unlocked(s, l);
    15de:	65a2                	ld	a1,8(sp)
    15e0:	8522                	mv	a0,s0
    15e2:	08a000ef          	jal	ra,166c <out_unlocked>
		mutex_unlock(buffer_lock);
    15e6:	10ca2503          	lw	a0,268(s4)
    15ea:	0a2010ef          	jal	ra,268c <mutex_unlock>
		s += 2;
    15ee:	bb55                	j	13a2 <printf+0x1c2>
				a = "(null)";
    15f0:	00001417          	auipc	s0,0x1
    15f4:	1b840413          	addi	s0,s0,440 # 27a8 <enable_deadlock_detect+0xc8>
    15f8:	bd2d                	j	1432 <printf+0x252>

00000000000015fa <enable_thread_io_buffer>:
{
    15fa:	1101                	addi	sp,sp,-32
    15fc:	e822                	sd	s0,16(sp)
    15fe:	ec06                	sd	ra,24(sp)
    1600:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    1602:	00001417          	auipc	s0,0x1
    1606:	29e40413          	addi	s0,s0,670 # 28a0 <buffer_len>
    160a:	05a010ef          	jal	ra,2664 <mutex_create>
    160e:	10a42623          	sw	a0,268(s0)
    1612:	00054a63          	bltz	a0,1626 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    1616:	4785                	li	a5,1
}
    1618:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    161a:	10f42423          	sw	a5,264(s0)
}
    161e:	6442                	ld	s0,16(sp)
    1620:	64a2                	ld	s1,8(sp)
    1622:	6105                	addi	sp,sp,32
    1624:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1626:	5ed000ef          	jal	ra,2412 <getpid>
    162a:	84aa                	mv	s1,a0
    162c:	00001517          	auipc	a0,0x1
    1630:	18450513          	addi	a0,a0,388 # 27b0 <enable_deadlock_detect+0xd0>
    1634:	4b5000ef          	jal	ra,22e8 <basename>
    1638:	872a                	mv	a4,a0
    163a:	04800793          	li	a5,72
    163e:	86a6                	mv	a3,s1
    1640:	00001517          	auipc	a0,0x1
    1644:	1f050513          	addi	a0,a0,496 # 2830 <enable_deadlock_detect+0x150>
    1648:	00001617          	auipc	a2,0x1
    164c:	0f060613          	addi	a2,a2,240 # 2738 <enable_deadlock_detect+0x58>
    1650:	45fd                	li	a1,31
    1652:	b8fff0ef          	jal	ra,11e0 <printf>
    1656:	557d                	li	a0,-1
    1658:	5eb000ef          	jal	ra,2442 <exit>
	buffer_lock_enabled = 1;
    165c:	4785                	li	a5,1
}
    165e:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1660:	10f42423          	sw	a5,264(s0)
}
    1664:	6442                	ld	s0,16(sp)
    1666:	64a2                	ld	s1,8(sp)
    1668:	6105                	addi	sp,sp,32
    166a:	8082                	ret

000000000000166c <out_unlocked>:
{
    166c:	7159                	addi	sp,sp,-112
    166e:	f486                	sd	ra,104(sp)
    1670:	f0a2                	sd	s0,96(sp)
    1672:	eca6                	sd	s1,88(sp)
    1674:	e8ca                	sd	s2,80(sp)
    1676:	e4ce                	sd	s3,72(sp)
    1678:	e0d2                	sd	s4,64(sp)
    167a:	fc56                	sd	s5,56(sp)
    167c:	f85a                	sd	s6,48(sp)
    167e:	f45e                	sd	s7,40(sp)
    1680:	f062                	sd	s8,32(sp)
    1682:	ec66                	sd	s9,24(sp)
    1684:	e86a                	sd	s10,16(sp)
    1686:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1688:	0e058663          	beqz	a1,1774 <out_unlocked+0x108>
    168c:	842a                	mv	s0,a0
    168e:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1692:	4981                	li	s3,0
    1694:	00001d17          	auipc	s10,0x1
    1698:	20cd0d13          	addi	s10,s10,524 # 28a0 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    169c:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    16a0:	00001b17          	auipc	s6,0x1
    16a4:	208b0b13          	addi	s6,s6,520 # 28a8 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    16a8:	10000a93          	li	s5,256
    16ac:	00001c97          	auipc	s9,0x1
    16b0:	104c8c93          	addi	s9,s9,260 # 27b0 <enable_deadlock_detect+0xd0>
    16b4:	00001c17          	auipc	s8,0x1
    16b8:	084c0c13          	addi	s8,s8,132 # 2738 <enable_deadlock_detect+0x58>
    16bc:	00001b97          	auipc	s7,0x1
    16c0:	134b8b93          	addi	s7,s7,308 # 27f0 <enable_deadlock_detect+0x110>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16c4:	4a29                	li	s4,10
    16c6:	a031                	j	16d2 <out_unlocked+0x66>
    16c8:	09468863          	beq	a3,s4,1758 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    16cc:	0405                	addi	s0,s0,1
    16ce:	04848163          	beq	s1,s0,1710 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    16d2:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    16d6:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    16da:	0017861b          	addiw	a2,a5,1
    16de:	97ea                	add	a5,a5,s10
    16e0:	00cd2023          	sw	a2,0(s10)
    16e4:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16e8:	fec950e3          	bge	s2,a2,16c8 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    16ec:	05561263          	bne	a2,s5,1730 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    16f0:	85da                	mv	a1,s6
    16f2:	4505                	li	a0,1
    16f4:	515000ef          	jal	ra,2408 <write>
    16f8:	2501                	sext.w	a0,a0
	buffer_len = 0;
    16fa:	00001797          	auipc	a5,0x1
    16fe:	1a07a323          	sw	zero,422(a5) # 28a0 <buffer_len>
			if (r < 0) {
    1702:	06054763          	bltz	a0,1770 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    1706:	0405                	addi	s0,s0,1
			ret += r;
    1708:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    170c:	fc8493e3          	bne	s1,s0,16d2 <out_unlocked+0x66>
}
    1710:	70a6                	ld	ra,104(sp)
    1712:	7406                	ld	s0,96(sp)
    1714:	64e6                	ld	s1,88(sp)
    1716:	6946                	ld	s2,80(sp)
    1718:	6a06                	ld	s4,64(sp)
    171a:	7ae2                	ld	s5,56(sp)
    171c:	7b42                	ld	s6,48(sp)
    171e:	7ba2                	ld	s7,40(sp)
    1720:	7c02                	ld	s8,32(sp)
    1722:	6ce2                	ld	s9,24(sp)
    1724:	6d42                	ld	s10,16(sp)
    1726:	6da2                	ld	s11,8(sp)
    1728:	854e                	mv	a0,s3
    172a:	69a6                	ld	s3,72(sp)
    172c:	6165                	addi	sp,sp,112
    172e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1730:	4e3000ef          	jal	ra,2412 <getpid>
    1734:	8daa                	mv	s11,a0
    1736:	8566                	mv	a0,s9
    1738:	3b1000ef          	jal	ra,22e8 <basename>
    173c:	872a                	mv	a4,a0
    173e:	8662                	mv	a2,s8
    1740:	05400793          	li	a5,84
    1744:	86ee                	mv	a3,s11
    1746:	45fd                	li	a1,31
    1748:	855e                	mv	a0,s7
    174a:	a97ff0ef          	jal	ra,11e0 <printf>
    174e:	557d                	li	a0,-1
    1750:	4f3000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    1754:	000d2603          	lw	a2,0(s10)
    1758:	da35                	beqz	a2,16cc <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    175a:	85da                	mv	a1,s6
    175c:	4505                	li	a0,1
    175e:	4ab000ef          	jal	ra,2408 <write>
    1762:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1764:	00001797          	auipc	a5,0x1
    1768:	1207ae23          	sw	zero,316(a5) # 28a0 <buffer_len>
			if (r < 0) {
    176c:	f8055de3          	bgez	a0,1706 <out_unlocked+0x9a>
    1770:	89aa                	mv	s3,a0
    1772:	bf79                	j	1710 <out_unlocked+0xa4>
	int ret = 0;
    1774:	4981                	li	s3,0
    1776:	bf69                	j	1710 <out_unlocked+0xa4>

0000000000001778 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1778:	1101                	addi	sp,sp,-32
    177a:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    177c:	00001497          	auipc	s1,0x1
    1780:	12448493          	addi	s1,s1,292 # 28a0 <buffer_len>
    1784:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1786:	ec06                	sd	ra,24(sp)
    1788:	e822                	sd	s0,16(sp)
		char c = s[i];
    178a:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    178e:	0017861b          	addiw	a2,a5,1
    1792:	97a6                	add	a5,a5,s1
    1794:	00e78423          	sb	a4,8(a5)
    1798:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    179a:	0ff00793          	li	a5,255
    179e:	00c7cc63          	blt	a5,a2,17b6 <out_unlocked.constprop.0+0x3e>
    17a2:	47a9                	li	a5,10
    17a4:	06f70c63          	beq	a4,a5,181c <out_unlocked.constprop.0+0xa4>
    17a8:	4601                	li	a2,0
}
    17aa:	60e2                	ld	ra,24(sp)
    17ac:	6442                	ld	s0,16(sp)
    17ae:	64a2                	ld	s1,8(sp)
    17b0:	8532                	mv	a0,a2
    17b2:	6105                	addi	sp,sp,32
    17b4:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17b6:	10000793          	li	a5,256
    17ba:	02f61563          	bne	a2,a5,17e4 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    17be:	00001597          	auipc	a1,0x1
    17c2:	0ea58593          	addi	a1,a1,234 # 28a8 <buffer>
    17c6:	4505                	li	a0,1
    17c8:	441000ef          	jal	ra,2408 <write>
}
    17cc:	60e2                	ld	ra,24(sp)
    17ce:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    17d0:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    17d4:	00001797          	auipc	a5,0x1
    17d8:	0c07a623          	sw	zero,204(a5) # 28a0 <buffer_len>
}
    17dc:	64a2                	ld	s1,8(sp)
    17de:	8532                	mv	a0,a2
    17e0:	6105                	addi	sp,sp,32
    17e2:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    17e4:	42f000ef          	jal	ra,2412 <getpid>
    17e8:	842a                	mv	s0,a0
    17ea:	00001517          	auipc	a0,0x1
    17ee:	fc650513          	addi	a0,a0,-58 # 27b0 <enable_deadlock_detect+0xd0>
    17f2:	2f7000ef          	jal	ra,22e8 <basename>
    17f6:	872a                	mv	a4,a0
    17f8:	00001617          	auipc	a2,0x1
    17fc:	f4060613          	addi	a2,a2,-192 # 2738 <enable_deadlock_detect+0x58>
    1800:	05400793          	li	a5,84
    1804:	86a2                	mv	a3,s0
    1806:	45fd                	li	a1,31
    1808:	00001517          	auipc	a0,0x1
    180c:	fe850513          	addi	a0,a0,-24 # 27f0 <enable_deadlock_detect+0x110>
    1810:	9d1ff0ef          	jal	ra,11e0 <printf>
    1814:	557d                	li	a0,-1
    1816:	42d000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    181a:	4090                	lw	a2,0(s1)
    181c:	d659                	beqz	a2,17aa <out_unlocked.constprop.0+0x32>
    181e:	b745                	j	17be <out_unlocked.constprop.0+0x46>

0000000000001820 <putchar>:
{
    1820:	7139                	addi	sp,sp,-64
    1822:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1824:	00001497          	auipc	s1,0x1
    1828:	07c48493          	addi	s1,s1,124 # 28a0 <buffer_len>
    182c:	1084a703          	lw	a4,264(s1)
{
    1830:	f822                	sd	s0,48(sp)
	char byte = c;
    1832:	0ff57413          	zext.b	s0,a0
{
    1836:	fc06                	sd	ra,56(sp)
	char byte = c;
    1838:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    183c:	4785                	li	a5,1
    183e:	00f70d63          	beq	a4,a5,1858 <putchar+0x38>
		len = out_unlocked(s, l);
    1842:	01f10513          	addi	a0,sp,31
    1846:	f33ff0ef          	jal	ra,1778 <out_unlocked.constprop.0>
}
    184a:	70e2                	ld	ra,56(sp)
    184c:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    184e:	862a                	mv	a2,a0
}
    1850:	74a2                	ld	s1,40(sp)
    1852:	8532                	mv	a0,a2
    1854:	6121                	addi	sp,sp,64
    1856:	8082                	ret
		mutex_lock(buffer_lock);
    1858:	10c4a503          	lw	a0,268(s1)
    185c:	625000ef          	jal	ra,2680 <mutex_lock>
		buffer[buffer_len++] = c;
    1860:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1862:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1866:	0017861b          	addiw	a2,a5,1
    186a:	97a6                	add	a5,a5,s1
    186c:	c090                	sw	a2,0(s1)
    186e:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1872:	02c6c263          	blt	a3,a2,1896 <putchar+0x76>
    1876:	47a9                	li	a5,10
    1878:	06f40d63          	beq	s0,a5,18f2 <putchar+0xd2>
    187c:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    187e:	10c4a503          	lw	a0,268(s1)
    1882:	e432                	sd	a2,8(sp)
    1884:	609000ef          	jal	ra,268c <mutex_unlock>
    1888:	6622                	ld	a2,8(sp)
}
    188a:	70e2                	ld	ra,56(sp)
    188c:	7442                	ld	s0,48(sp)
    188e:	74a2                	ld	s1,40(sp)
    1890:	8532                	mv	a0,a2
    1892:	6121                	addi	sp,sp,64
    1894:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1896:	10000793          	li	a5,256
    189a:	02f61063          	bne	a2,a5,18ba <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    189e:	00001597          	auipc	a1,0x1
    18a2:	00a58593          	addi	a1,a1,10 # 28a8 <buffer>
    18a6:	4505                	li	a0,1
    18a8:	361000ef          	jal	ra,2408 <write>
    18ac:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    18b0:	00001797          	auipc	a5,0x1
    18b4:	fe07a823          	sw	zero,-16(a5) # 28a0 <buffer_len>
			if (r < 0) {
    18b8:	b7d9                	j	187e <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    18ba:	359000ef          	jal	ra,2412 <getpid>
    18be:	842a                	mv	s0,a0
    18c0:	00001517          	auipc	a0,0x1
    18c4:	ef050513          	addi	a0,a0,-272 # 27b0 <enable_deadlock_detect+0xd0>
    18c8:	221000ef          	jal	ra,22e8 <basename>
    18cc:	872a                	mv	a4,a0
    18ce:	00001617          	auipc	a2,0x1
    18d2:	e6a60613          	addi	a2,a2,-406 # 2738 <enable_deadlock_detect+0x58>
    18d6:	05400793          	li	a5,84
    18da:	86a2                	mv	a3,s0
    18dc:	45fd                	li	a1,31
    18de:	00001517          	auipc	a0,0x1
    18e2:	f1250513          	addi	a0,a0,-238 # 27f0 <enable_deadlock_detect+0x110>
    18e6:	8fbff0ef          	jal	ra,11e0 <printf>
    18ea:	557d                	li	a0,-1
    18ec:	357000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    18f0:	4090                	lw	a2,0(s1)
    18f2:	d651                	beqz	a2,187e <putchar+0x5e>
    18f4:	b76d                	j	189e <putchar+0x7e>

00000000000018f6 <puts>:
{
    18f6:	7139                	addi	sp,sp,-64
    18f8:	f822                	sd	s0,48(sp)
    18fa:	f426                	sd	s1,40(sp)
    18fc:	fc06                	sd	ra,56(sp)
    18fe:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1900:	00001417          	auipc	s0,0x1
    1904:	fa040413          	addi	s0,s0,-96 # 28a0 <buffer_len>
{
    1908:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    190a:	638000ef          	jal	ra,1f42 <strlen>
	if (buffer_lock_enabled == 1) {
    190e:	10842703          	lw	a4,264(s0)
    1912:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1914:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1916:	04f70563          	beq	a4,a5,1960 <puts+0x6a>
		len = out_unlocked(s, l);
    191a:	8526                	mv	a0,s1
    191c:	d51ff0ef          	jal	ra,166c <out_unlocked>
    1920:	892a                	mv	s2,a0
    1922:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1924:	00095963          	bgez	s2,1936 <puts+0x40>
}
    1928:	70e2                	ld	ra,56(sp)
    192a:	7442                	ld	s0,48(sp)
    192c:	7902                	ld	s2,32(sp)
    192e:	8526                	mv	a0,s1
    1930:	74a2                	ld	s1,40(sp)
    1932:	6121                	addi	sp,sp,64
    1934:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1936:	10842703          	lw	a4,264(s0)
	char byte = c;
    193a:	44a9                	li	s1,10
    193c:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1940:	4785                	li	a5,1
    1942:	02f70e63          	beq	a4,a5,197e <puts+0x88>
		len = out_unlocked(s, l);
    1946:	01f10513          	addi	a0,sp,31
    194a:	e2fff0ef          	jal	ra,1778 <out_unlocked.constprop.0>
}
    194e:	70e2                	ld	ra,56(sp)
    1950:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1952:	41f5549b          	sraiw	s1,a0,0x1f
}
    1956:	7902                	ld	s2,32(sp)
    1958:	8526                	mv	a0,s1
    195a:	74a2                	ld	s1,40(sp)
    195c:	6121                	addi	sp,sp,64
    195e:	8082                	ret
		mutex_lock(buffer_lock);
    1960:	e42a                	sd	a0,8(sp)
    1962:	10c42503          	lw	a0,268(s0)
    1966:	51b000ef          	jal	ra,2680 <mutex_lock>
		len = out_unlocked(s, l);
    196a:	65a2                	ld	a1,8(sp)
    196c:	8526                	mv	a0,s1
    196e:	cffff0ef          	jal	ra,166c <out_unlocked>
    1972:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1974:	10c42503          	lw	a0,268(s0)
    1978:	515000ef          	jal	ra,268c <mutex_unlock>
    197c:	b75d                	j	1922 <puts+0x2c>
		mutex_lock(buffer_lock);
    197e:	10c42503          	lw	a0,268(s0)
    1982:	4ff000ef          	jal	ra,2680 <mutex_lock>
		buffer[buffer_len++] = c;
    1986:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1988:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    198c:	0017861b          	addiw	a2,a5,1
    1990:	97a2                	add	a5,a5,s0
    1992:	c010                	sw	a2,0(s0)
    1994:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1998:	06c6dc63          	bge	a3,a2,1a10 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    199c:	10000793          	li	a5,256
    19a0:	02f61c63          	bne	a2,a5,19d8 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    19a4:	00001597          	auipc	a1,0x1
    19a8:	f0458593          	addi	a1,a1,-252 # 28a8 <buffer>
    19ac:	4505                	li	a0,1
    19ae:	25b000ef          	jal	ra,2408 <write>
			if (r < 0) {
    19b2:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19b4:	00001797          	auipc	a5,0x1
    19b8:	ee07a623          	sw	zero,-276(a5) # 28a0 <buffer_len>
			if (r < 0) {
    19bc:	04054c63          	bltz	a0,1a14 <puts+0x11e>
			if (r < buffer_len) {
    19c0:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    19c2:	10c42503          	lw	a0,268(s0)
    19c6:	4c7000ef          	jal	ra,268c <mutex_unlock>
}
    19ca:	70e2                	ld	ra,56(sp)
    19cc:	7442                	ld	s0,48(sp)
    19ce:	7902                	ld	s2,32(sp)
    19d0:	8526                	mv	a0,s1
    19d2:	74a2                	ld	s1,40(sp)
    19d4:	6121                	addi	sp,sp,64
    19d6:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19d8:	23b000ef          	jal	ra,2412 <getpid>
    19dc:	84aa                	mv	s1,a0
    19de:	00001517          	auipc	a0,0x1
    19e2:	dd250513          	addi	a0,a0,-558 # 27b0 <enable_deadlock_detect+0xd0>
    19e6:	103000ef          	jal	ra,22e8 <basename>
    19ea:	872a                	mv	a4,a0
    19ec:	00001617          	auipc	a2,0x1
    19f0:	d4c60613          	addi	a2,a2,-692 # 2738 <enable_deadlock_detect+0x58>
    19f4:	05400793          	li	a5,84
    19f8:	86a6                	mv	a3,s1
    19fa:	45fd                	li	a1,31
    19fc:	00001517          	auipc	a0,0x1
    1a00:	df450513          	addi	a0,a0,-524 # 27f0 <enable_deadlock_detect+0x110>
    1a04:	fdcff0ef          	jal	ra,11e0 <printf>
    1a08:	557d                	li	a0,-1
    1a0a:	239000ef          	jal	ra,2442 <exit>
	if (buffer_len == 0)
    1a0e:	4010                	lw	a2,0(s0)
    1a10:	da45                	beqz	a2,19c0 <puts+0xca>
    1a12:	bf49                	j	19a4 <puts+0xae>
    1a14:	54fd                	li	s1,-1
    1a16:	b775                	j	19c2 <puts+0xcc>

0000000000001a18 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1a18:	715d                	addi	sp,sp,-80
    1a1a:	e486                	sd	ra,72(sp)
    1a1c:	e0a2                	sd	s0,64(sp)
    1a1e:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1a20:	14054363          	bltz	a0,1b66 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1a24:	02b577bb          	remuw	a5,a0,a1
    1a28:	00001617          	auipc	a2,0x1
    1a2c:	f8860613          	addi	a2,a2,-120 # 29b0 <digits>
	buf[16] = 0;
    1a30:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1a34:	0005871b          	sext.w	a4,a1
    1a38:	1782                	slli	a5,a5,0x20
    1a3a:	9381                	srli	a5,a5,0x20
    1a3c:	97b2                	add	a5,a5,a2
    1a3e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a42:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1a46:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1a4a:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1a4c:	0eb56763          	bltu	a0,a1,1b3a <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a50:	02e877bb          	remuw	a5,a6,a4
    1a54:	1782                	slli	a5,a5,0x20
    1a56:	9381                	srli	a5,a5,0x20
    1a58:	97b2                	add	a5,a5,a2
    1a5a:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1a5e:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1a62:	02f10323          	sb	a5,38(sp)
    1a66:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1a68:	0ce86963          	bltu	a6,a4,1b3a <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1a6c:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1a70:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1a74:	1582                	slli	a1,a1,0x20
    1a76:	9181                	srli	a1,a1,0x20
    1a78:	95b2                	add	a1,a1,a2
    1a7a:	0005c583          	lbu	a1,0(a1)
    1a7e:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1a82:	0007859b          	sext.w	a1,a5
    1a86:	16e6e563          	bltu	a3,a4,1bf0 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1a8a:	02e7f6bb          	remuw	a3,a5,a4
    1a8e:	1682                	slli	a3,a3,0x20
    1a90:	9281                	srli	a3,a3,0x20
    1a92:	96b2                	add	a3,a3,a2
    1a94:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1a98:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1a9c:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1aa0:	16e5e163          	bltu	a1,a4,1c02 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1aa4:	02e876bb          	remuw	a3,a6,a4
    1aa8:	1682                	slli	a3,a3,0x20
    1aaa:	9281                	srli	a3,a3,0x20
    1aac:	96b2                	add	a3,a3,a2
    1aae:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ab2:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1ab6:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1aba:	14e86d63          	bltu	a6,a4,1c14 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1abe:	02e5f6bb          	remuw	a3,a1,a4
    1ac2:	1682                	slli	a3,a3,0x20
    1ac4:	9281                	srli	a3,a3,0x20
    1ac6:	96b2                	add	a3,a3,a2
    1ac8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1acc:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1ad0:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1ad4:	10e5e563          	bltu	a1,a4,1bde <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1ad8:	02e876bb          	remuw	a3,a6,a4
    1adc:	1682                	slli	a3,a3,0x20
    1ade:	9281                	srli	a3,a3,0x20
    1ae0:	96b2                	add	a3,a3,a2
    1ae2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ae6:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1aea:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1aee:	14e86263          	bltu	a6,a4,1c32 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1af2:	02e5f6bb          	remuw	a3,a1,a4
    1af6:	1682                	slli	a3,a3,0x20
    1af8:	9281                	srli	a3,a3,0x20
    1afa:	96b2                	add	a3,a3,a2
    1afc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b00:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1b04:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1b08:	14e5e463          	bltu	a1,a4,1c50 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1b0c:	02e876bb          	remuw	a3,a6,a4
    1b10:	1682                	slli	a3,a3,0x20
    1b12:	9281                	srli	a3,a3,0x20
    1b14:	96b2                	add	a3,a3,a2
    1b16:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1b1a:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1b1e:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1b22:	14e86063          	bltu	a6,a4,1c62 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1b26:	1782                	slli	a5,a5,0x20
    1b28:	9381                	srli	a5,a5,0x20
    1b2a:	97b2                	add	a5,a5,a2
    1b2c:	0007c703          	lbu	a4,0(a5)
    1b30:	4799                	li	a5,6
    1b32:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1b36:	10054763          	bltz	a0,1c44 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1b3a:	00001497          	auipc	s1,0x1
    1b3e:	d6648493          	addi	s1,s1,-666 # 28a0 <buffer_len>
    1b42:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1b46:	0828                	addi	a0,sp,24
    1b48:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1b4a:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1b4c:	00f50433          	add	s0,a0,a5
    1b50:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1b52:	06e68463          	beq	a3,a4,1bba <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1b56:	8522                	mv	a0,s0
    1b58:	b15ff0ef          	jal	ra,166c <out_unlocked>
}
    1b5c:	60a6                	ld	ra,72(sp)
    1b5e:	6406                	ld	s0,64(sp)
    1b60:	74e2                	ld	s1,56(sp)
    1b62:	6161                	addi	sp,sp,80
    1b64:	8082                	ret
		x = -xx;
    1b66:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1b6a:	02b877bb          	remuw	a5,a6,a1
    1b6e:	00001617          	auipc	a2,0x1
    1b72:	e4260613          	addi	a2,a2,-446 # 29b0 <digits>
	buf[16] = 0;
    1b76:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1b7a:	0005871b          	sext.w	a4,a1
    1b7e:	1782                	slli	a5,a5,0x20
    1b80:	9381                	srli	a5,a5,0x20
    1b82:	97b2                	add	a5,a5,a2
    1b84:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1b88:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1b8c:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1b90:	08b86b63          	bltu	a6,a1,1c26 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1b94:	02e8f7bb          	remuw	a5,a7,a4
    1b98:	1782                	slli	a5,a5,0x20
    1b9a:	9381                	srli	a5,a5,0x20
    1b9c:	97b2                	add	a5,a5,a2
    1b9e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1ba2:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1ba6:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1baa:	ece8f1e3          	bgeu	a7,a4,1a6c <printint.constprop.0+0x54>
		buf[i--] = '-';
    1bae:	02d00793          	li	a5,45
    1bb2:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1bb6:	47b5                	li	a5,13
    1bb8:	b749                	j	1b3a <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1bba:	10c4a503          	lw	a0,268(s1)
    1bbe:	e42e                	sd	a1,8(sp)
    1bc0:	2c1000ef          	jal	ra,2680 <mutex_lock>
		len = out_unlocked(s, l);
    1bc4:	65a2                	ld	a1,8(sp)
    1bc6:	8522                	mv	a0,s0
    1bc8:	aa5ff0ef          	jal	ra,166c <out_unlocked>
		mutex_unlock(buffer_lock);
    1bcc:	10c4a503          	lw	a0,268(s1)
    1bd0:	2bd000ef          	jal	ra,268c <mutex_unlock>
}
    1bd4:	60a6                	ld	ra,72(sp)
    1bd6:	6406                	ld	s0,64(sp)
    1bd8:	74e2                	ld	s1,56(sp)
    1bda:	6161                	addi	sp,sp,80
    1bdc:	8082                	ret
		buf[i--] = digits[x % base];
    1bde:	47a9                	li	a5,10
	if (sign)
    1be0:	f4055de3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1be4:	02d00793          	li	a5,45
    1be8:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1bec:	47a5                	li	a5,9
    1bee:	b7b1                	j	1b3a <printint.constprop.0+0x122>
    1bf0:	47b5                	li	a5,13
	if (sign)
    1bf2:	f40554e3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1bf6:	02d00793          	li	a5,45
    1bfa:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1bfe:	47b1                	li	a5,12
    1c00:	bf2d                	j	1b3a <printint.constprop.0+0x122>
    1c02:	47b1                	li	a5,12
	if (sign)
    1c04:	f2055be3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c08:	02d00793          	li	a5,45
    1c0c:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1c10:	47ad                	li	a5,11
    1c12:	b725                	j	1b3a <printint.constprop.0+0x122>
    1c14:	47ad                	li	a5,11
	if (sign)
    1c16:	f20552e3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c1a:	02d00793          	li	a5,45
    1c1e:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1c22:	47a9                	li	a5,10
    1c24:	bf19                	j	1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c26:	02d00793          	li	a5,45
    1c2a:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1c2e:	47b9                	li	a5,14
    1c30:	b729                	j	1b3a <printint.constprop.0+0x122>
    1c32:	47a5                	li	a5,9
	if (sign)
    1c34:	f00553e3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c38:	02d00793          	li	a5,45
    1c3c:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1c40:	47a1                	li	a5,8
    1c42:	bde5                	j	1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c44:	02d00793          	li	a5,45
    1c48:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1c4c:	4795                	li	a5,5
    1c4e:	b5f5                	j	1b3a <printint.constprop.0+0x122>
    1c50:	47a1                	li	a5,8
	if (sign)
    1c52:	ee0554e3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c56:	02d00793          	li	a5,45
    1c5a:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1c5e:	479d                	li	a5,7
    1c60:	bde9                	j	1b3a <printint.constprop.0+0x122>
    1c62:	479d                	li	a5,7
	if (sign)
    1c64:	ec055be3          	bgez	a0,1b3a <printint.constprop.0+0x122>
		buf[i--] = '-';
    1c68:	02d00793          	li	a5,45
    1c6c:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1c70:	4799                	li	a5,6
    1c72:	b5e1                	j	1b3a <printint.constprop.0+0x122>

0000000000001c74 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c74:	02000793          	li	a5,32
    1c78:	00f50663          	beq	a0,a5,1c84 <isspace+0x10>
    1c7c:	355d                	addiw	a0,a0,-9
    1c7e:	00553513          	sltiu	a0,a0,5
    1c82:	8082                	ret
    1c84:	4505                	li	a0,1
}
    1c86:	8082                	ret

0000000000001c88 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1c88:	fd05051b          	addiw	a0,a0,-48
}
    1c8c:	00a53513          	sltiu	a0,a0,10
    1c90:	8082                	ret

0000000000001c92 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c92:	02000613          	li	a2,32
    1c96:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1c98:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1c9c:	ff77869b          	addiw	a3,a5,-9
    1ca0:	04c78c63          	beq	a5,a2,1cf8 <atoi+0x66>
    1ca4:	0007871b          	sext.w	a4,a5
    1ca8:	04d5f863          	bgeu	a1,a3,1cf8 <atoi+0x66>
		s++;
	switch (*s) {
    1cac:	02b00693          	li	a3,43
    1cb0:	04d78963          	beq	a5,a3,1d02 <atoi+0x70>
    1cb4:	02d00693          	li	a3,45
    1cb8:	06d78263          	beq	a5,a3,1d1c <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1cbc:	fd07061b          	addiw	a2,a4,-48
    1cc0:	47a5                	li	a5,9
    1cc2:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1cc4:	4e01                	li	t3,0
	while (isdigit(*s))
    1cc6:	04c7e963          	bltu	a5,a2,1d18 <atoi+0x86>
	int n = 0, neg = 0;
    1cca:	4501                	li	a0,0
	while (isdigit(*s))
    1ccc:	4825                	li	a6,9
    1cce:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1cd2:	0025179b          	slliw	a5,a0,0x2
    1cd6:	9fa9                	addw	a5,a5,a0
    1cd8:	fd07031b          	addiw	t1,a4,-48
    1cdc:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1ce0:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ce4:	0685                	addi	a3,a3,1
    1ce6:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1cea:	0006071b          	sext.w	a4,a2
    1cee:	feb870e3          	bgeu	a6,a1,1cce <atoi+0x3c>
	return neg ? n : -n;
    1cf2:	000e0563          	beqz	t3,1cfc <atoi+0x6a>
}
    1cf6:	8082                	ret
		s++;
    1cf8:	0505                	addi	a0,a0,1
    1cfa:	bf79                	j	1c98 <atoi+0x6>
	return neg ? n : -n;
    1cfc:	4113053b          	subw	a0,t1,a7
    1d00:	8082                	ret
	while (isdigit(*s))
    1d02:	00154703          	lbu	a4,1(a0)
    1d06:	47a5                	li	a5,9
		s++;
    1d08:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d0c:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1d10:	4e01                	li	t3,0
	while (isdigit(*s))
    1d12:	2701                	sext.w	a4,a4
    1d14:	fac7fbe3          	bgeu	a5,a2,1cca <atoi+0x38>
    1d18:	4501                	li	a0,0
}
    1d1a:	8082                	ret
	while (isdigit(*s))
    1d1c:	00154703          	lbu	a4,1(a0)
    1d20:	47a5                	li	a5,9
		s++;
    1d22:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1d26:	fd07061b          	addiw	a2,a4,-48
    1d2a:	2701                	sext.w	a4,a4
    1d2c:	fec7e6e3          	bltu	a5,a2,1d18 <atoi+0x86>
		neg = 1;
    1d30:	4e05                	li	t3,1
    1d32:	bf61                	j	1cca <atoi+0x38>

0000000000001d34 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1d34:	16060d63          	beqz	a2,1eae <memset+0x17a>
    1d38:	40a007b3          	neg	a5,a0
    1d3c:	8b9d                	andi	a5,a5,7
    1d3e:	00778693          	addi	a3,a5,7
    1d42:	482d                	li	a6,11
    1d44:	0ff5f713          	zext.b	a4,a1
    1d48:	fff60593          	addi	a1,a2,-1
    1d4c:	1706e263          	bltu	a3,a6,1eb0 <memset+0x17c>
    1d50:	16d5ea63          	bltu	a1,a3,1ec4 <memset+0x190>
    1d54:	16078563          	beqz	a5,1ebe <memset+0x18a>
    1d58:	00e50023          	sb	a4,0(a0)
    1d5c:	4685                	li	a3,1
    1d5e:	00150593          	addi	a1,a0,1
    1d62:	14d78c63          	beq	a5,a3,1eba <memset+0x186>
    1d66:	00e500a3          	sb	a4,1(a0)
    1d6a:	4689                	li	a3,2
    1d6c:	00250593          	addi	a1,a0,2
    1d70:	14d78d63          	beq	a5,a3,1eca <memset+0x196>
    1d74:	00e50123          	sb	a4,2(a0)
    1d78:	468d                	li	a3,3
    1d7a:	00350593          	addi	a1,a0,3
    1d7e:	12d78b63          	beq	a5,a3,1eb4 <memset+0x180>
    1d82:	00e501a3          	sb	a4,3(a0)
    1d86:	4691                	li	a3,4
    1d88:	00450593          	addi	a1,a0,4
    1d8c:	14d78163          	beq	a5,a3,1ece <memset+0x19a>
    1d90:	00e50223          	sb	a4,4(a0)
    1d94:	4695                	li	a3,5
    1d96:	00550593          	addi	a1,a0,5
    1d9a:	12d78c63          	beq	a5,a3,1ed2 <memset+0x19e>
    1d9e:	00e502a3          	sb	a4,5(a0)
    1da2:	469d                	li	a3,7
    1da4:	00650593          	addi	a1,a0,6
    1da8:	12d79763          	bne	a5,a3,1ed6 <memset+0x1a2>
    1dac:	00750593          	addi	a1,a0,7
    1db0:	00e50323          	sb	a4,6(a0)
    1db4:	481d                	li	a6,7
    1db6:	00871693          	slli	a3,a4,0x8
    1dba:	01071893          	slli	a7,a4,0x10
    1dbe:	8ed9                	or	a3,a3,a4
    1dc0:	01871313          	slli	t1,a4,0x18
    1dc4:	0116e6b3          	or	a3,a3,a7
    1dc8:	0066e6b3          	or	a3,a3,t1
    1dcc:	02071893          	slli	a7,a4,0x20
    1dd0:	02871e13          	slli	t3,a4,0x28
    1dd4:	0116e6b3          	or	a3,a3,a7
    1dd8:	40f60333          	sub	t1,a2,a5
    1ddc:	03071893          	slli	a7,a4,0x30
    1de0:	01c6e6b3          	or	a3,a3,t3
    1de4:	0116e6b3          	or	a3,a3,a7
    1de8:	03871e13          	slli	t3,a4,0x38
    1dec:	97aa                	add	a5,a5,a0
    1dee:	ff837893          	andi	a7,t1,-8
    1df2:	01c6e6b3          	or	a3,a3,t3
    1df6:	98be                	add	a7,a7,a5
    1df8:	e394                	sd	a3,0(a5)
    1dfa:	07a1                	addi	a5,a5,8
    1dfc:	ff179ee3          	bne	a5,a7,1df8 <memset+0xc4>
    1e00:	ff837893          	andi	a7,t1,-8
    1e04:	011587b3          	add	a5,a1,a7
    1e08:	010886bb          	addw	a3,a7,a6
    1e0c:	0b130663          	beq	t1,a7,1eb8 <memset+0x184>
    1e10:	00e78023          	sb	a4,0(a5)
    1e14:	0016859b          	addiw	a1,a3,1
    1e18:	08c5fb63          	bgeu	a1,a2,1eae <memset+0x17a>
    1e1c:	00e780a3          	sb	a4,1(a5)
    1e20:	0026859b          	addiw	a1,a3,2
    1e24:	08c5f563          	bgeu	a1,a2,1eae <memset+0x17a>
    1e28:	00e78123          	sb	a4,2(a5)
    1e2c:	0036859b          	addiw	a1,a3,3
    1e30:	06c5ff63          	bgeu	a1,a2,1eae <memset+0x17a>
    1e34:	00e781a3          	sb	a4,3(a5)
    1e38:	0046859b          	addiw	a1,a3,4
    1e3c:	06c5f963          	bgeu	a1,a2,1eae <memset+0x17a>
    1e40:	00e78223          	sb	a4,4(a5)
    1e44:	0056859b          	addiw	a1,a3,5
    1e48:	06c5f363          	bgeu	a1,a2,1eae <memset+0x17a>
    1e4c:	00e782a3          	sb	a4,5(a5)
    1e50:	0066859b          	addiw	a1,a3,6
    1e54:	04c5fd63          	bgeu	a1,a2,1eae <memset+0x17a>
    1e58:	00e78323          	sb	a4,6(a5)
    1e5c:	0076859b          	addiw	a1,a3,7
    1e60:	04c5f763          	bgeu	a1,a2,1eae <memset+0x17a>
    1e64:	00e783a3          	sb	a4,7(a5)
    1e68:	0086859b          	addiw	a1,a3,8
    1e6c:	04c5f163          	bgeu	a1,a2,1eae <memset+0x17a>
    1e70:	00e78423          	sb	a4,8(a5)
    1e74:	0096859b          	addiw	a1,a3,9
    1e78:	02c5fb63          	bgeu	a1,a2,1eae <memset+0x17a>
    1e7c:	00e784a3          	sb	a4,9(a5)
    1e80:	00a6859b          	addiw	a1,a3,10
    1e84:	02c5f563          	bgeu	a1,a2,1eae <memset+0x17a>
    1e88:	00e78523          	sb	a4,10(a5)
    1e8c:	00b6859b          	addiw	a1,a3,11
    1e90:	00c5ff63          	bgeu	a1,a2,1eae <memset+0x17a>
    1e94:	00e785a3          	sb	a4,11(a5)
    1e98:	00c6859b          	addiw	a1,a3,12
    1e9c:	00c5f963          	bgeu	a1,a2,1eae <memset+0x17a>
    1ea0:	00e78623          	sb	a4,12(a5)
    1ea4:	26b5                	addiw	a3,a3,13
    1ea6:	00c6f463          	bgeu	a3,a2,1eae <memset+0x17a>
    1eaa:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    1eae:	8082                	ret
    1eb0:	46ad                	li	a3,11
    1eb2:	bd79                	j	1d50 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    1eb4:	480d                	li	a6,3
    1eb6:	b701                	j	1db6 <memset+0x82>
    1eb8:	8082                	ret
    1eba:	4805                	li	a6,1
    1ebc:	bded                	j	1db6 <memset+0x82>
    1ebe:	85aa                	mv	a1,a0
    1ec0:	4801                	li	a6,0
    1ec2:	bdd5                	j	1db6 <memset+0x82>
    1ec4:	87aa                	mv	a5,a0
    1ec6:	4681                	li	a3,0
    1ec8:	b7a1                	j	1e10 <memset+0xdc>
    1eca:	4809                	li	a6,2
    1ecc:	b5ed                	j	1db6 <memset+0x82>
    1ece:	4811                	li	a6,4
    1ed0:	b5dd                	j	1db6 <memset+0x82>
    1ed2:	4815                	li	a6,5
    1ed4:	b5cd                	j	1db6 <memset+0x82>
    1ed6:	4819                	li	a6,6
    1ed8:	bdf9                	j	1db6 <memset+0x82>

0000000000001eda <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    1eda:	00054783          	lbu	a5,0(a0)
    1ede:	0005c703          	lbu	a4,0(a1)
    1ee2:	00e79863          	bne	a5,a4,1ef2 <strcmp+0x18>
    1ee6:	0505                	addi	a0,a0,1
    1ee8:	0585                	addi	a1,a1,1
    1eea:	fbe5                	bnez	a5,1eda <strcmp>
    1eec:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    1eee:	9d19                	subw	a0,a0,a4
    1ef0:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    1ef2:	0007851b          	sext.w	a0,a5
    1ef6:	bfe5                	j	1eee <strcmp+0x14>

0000000000001ef8 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    1ef8:	ca15                	beqz	a2,1f2c <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1efa:	00054783          	lbu	a5,0(a0)
	if (!n--)
    1efe:	167d                	addi	a2,a2,-1
    1f00:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    1f04:	eb99                	bnez	a5,1f1a <strncmp+0x22>
    1f06:	a815                	j	1f3a <strncmp+0x42>
    1f08:	00a68e63          	beq	a3,a0,1f24 <strncmp+0x2c>
    1f0c:	0505                	addi	a0,a0,1
    1f0e:	00f71b63          	bne	a4,a5,1f24 <strncmp+0x2c>
    1f12:	00054783          	lbu	a5,0(a0)
    1f16:	cf89                	beqz	a5,1f30 <strncmp+0x38>
    1f18:	85b2                	mv	a1,a2
    1f1a:	0005c703          	lbu	a4,0(a1)
    1f1e:	00158613          	addi	a2,a1,1
    1f22:	f37d                	bnez	a4,1f08 <strncmp+0x10>
		;
	return *l - *r;
    1f24:	0007851b          	sext.w	a0,a5
    1f28:	9d19                	subw	a0,a0,a4
    1f2a:	8082                	ret
		return 0;
    1f2c:	4501                	li	a0,0
}
    1f2e:	8082                	ret
	return *l - *r;
    1f30:	0015c703          	lbu	a4,1(a1)
    1f34:	4501                	li	a0,0
    1f36:	9d19                	subw	a0,a0,a4
    1f38:	8082                	ret
    1f3a:	0005c703          	lbu	a4,0(a1)
    1f3e:	4501                	li	a0,0
    1f40:	b7e5                	j	1f28 <strncmp+0x30>

0000000000001f42 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    1f42:	00757793          	andi	a5,a0,7
    1f46:	cf89                	beqz	a5,1f60 <strlen+0x1e>
    1f48:	87aa                	mv	a5,a0
    1f4a:	a029                	j	1f54 <strlen+0x12>
    1f4c:	0785                	addi	a5,a5,1
    1f4e:	0077f713          	andi	a4,a5,7
    1f52:	cb01                	beqz	a4,1f62 <strlen+0x20>
		if (!*s)
    1f54:	0007c703          	lbu	a4,0(a5)
    1f58:	fb75                	bnez	a4,1f4c <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    1f5a:	40a78533          	sub	a0,a5,a0
}
    1f5e:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    1f60:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    1f62:	6394                	ld	a3,0(a5)
    1f64:	00001597          	auipc	a1,0x1
    1f68:	9245b583          	ld	a1,-1756(a1) # 2888 <enable_deadlock_detect+0x1a8>
    1f6c:	00001617          	auipc	a2,0x1
    1f70:	92463603          	ld	a2,-1756(a2) # 2890 <enable_deadlock_detect+0x1b0>
    1f74:	a019                	j	1f7a <strlen+0x38>
    1f76:	6794                	ld	a3,8(a5)
    1f78:	07a1                	addi	a5,a5,8
    1f7a:	00b68733          	add	a4,a3,a1
    1f7e:	fff6c693          	not	a3,a3
    1f82:	8f75                	and	a4,a4,a3
    1f84:	8f71                	and	a4,a4,a2
    1f86:	db65                	beqz	a4,1f76 <strlen+0x34>
	for (; *s; s++)
    1f88:	0007c703          	lbu	a4,0(a5)
    1f8c:	d779                	beqz	a4,1f5a <strlen+0x18>
    1f8e:	0017c703          	lbu	a4,1(a5)
    1f92:	0785                	addi	a5,a5,1
    1f94:	d379                	beqz	a4,1f5a <strlen+0x18>
    1f96:	0017c703          	lbu	a4,1(a5)
    1f9a:	0785                	addi	a5,a5,1
    1f9c:	fb6d                	bnez	a4,1f8e <strlen+0x4c>
    1f9e:	bf75                	j	1f5a <strlen+0x18>

0000000000001fa0 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1fa0:	00757713          	andi	a4,a0,7
{
    1fa4:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    1fa6:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    1faa:	cb19                	beqz	a4,1fc0 <memchr+0x20>
    1fac:	ce25                	beqz	a2,2024 <memchr+0x84>
    1fae:	0007c703          	lbu	a4,0(a5)
    1fb2:	04b70e63          	beq	a4,a1,200e <memchr+0x6e>
    1fb6:	0785                	addi	a5,a5,1
    1fb8:	0077f713          	andi	a4,a5,7
    1fbc:	167d                	addi	a2,a2,-1
    1fbe:	f77d                	bnez	a4,1fac <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    1fc0:	4501                	li	a0,0
	if (n && *s != c) {
    1fc2:	c235                	beqz	a2,2026 <memchr+0x86>
    1fc4:	0007c703          	lbu	a4,0(a5)
    1fc8:	04b70363          	beq	a4,a1,200e <memchr+0x6e>
		size_t k = ONES * c;
    1fcc:	00001517          	auipc	a0,0x1
    1fd0:	8cc53503          	ld	a0,-1844(a0) # 2898 <enable_deadlock_detect+0x1b8>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fd4:	471d                	li	a4,7
		size_t k = ONES * c;
    1fd6:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1fda:	02c77a63          	bgeu	a4,a2,200e <memchr+0x6e>
    1fde:	00001897          	auipc	a7,0x1
    1fe2:	8aa8b883          	ld	a7,-1878(a7) # 2888 <enable_deadlock_detect+0x1a8>
    1fe6:	00001817          	auipc	a6,0x1
    1fea:	8aa83803          	ld	a6,-1878(a6) # 2890 <enable_deadlock_detect+0x1b0>
    1fee:	431d                	li	t1,7
    1ff0:	a029                	j	1ffa <memchr+0x5a>
		     w++, n -= SS)
    1ff2:	1661                	addi	a2,a2,-8
    1ff4:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    1ff6:	02c37963          	bgeu	t1,a2,2028 <memchr+0x88>
    1ffa:	6398                	ld	a4,0(a5)
    1ffc:	8f29                	xor	a4,a4,a0
    1ffe:	011706b3          	add	a3,a4,a7
    2002:	fff74713          	not	a4,a4
    2006:	8f75                	and	a4,a4,a3
    2008:	01077733          	and	a4,a4,a6
    200c:	d37d                	beqz	a4,1ff2 <memchr+0x52>
{
    200e:	853e                	mv	a0,a5
    2010:	97b2                	add	a5,a5,a2
    2012:	a021                	j	201a <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    2014:	0505                	addi	a0,a0,1
    2016:	00f50763          	beq	a0,a5,2024 <memchr+0x84>
    201a:	00054703          	lbu	a4,0(a0)
    201e:	feb71be3          	bne	a4,a1,2014 <memchr+0x74>
    2022:	8082                	ret
	return n ? (void *)s : 0;
    2024:	4501                	li	a0,0
}
    2026:	8082                	ret
	return n ? (void *)s : 0;
    2028:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    202a:	f275                	bnez	a2,200e <memchr+0x6e>
}
    202c:	8082                	ret

000000000000202e <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    202e:	1101                	addi	sp,sp,-32
    2030:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    2032:	862e                	mv	a2,a1
{
    2034:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2036:	4581                	li	a1,0
{
    2038:	e426                	sd	s1,8(sp)
    203a:	ec06                	sd	ra,24(sp)
    203c:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    203e:	f63ff0ef          	jal	ra,1fa0 <memchr>
	return p ? p - s : n;
    2042:	c519                	beqz	a0,2050 <strnlen+0x22>
}
    2044:	60e2                	ld	ra,24(sp)
    2046:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2048:	8d05                	sub	a0,a0,s1
}
    204a:	64a2                	ld	s1,8(sp)
    204c:	6105                	addi	sp,sp,32
    204e:	8082                	ret
    2050:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2052:	8522                	mv	a0,s0
}
    2054:	6442                	ld	s0,16(sp)
    2056:	64a2                	ld	s1,8(sp)
    2058:	6105                	addi	sp,sp,32
    205a:	8082                	ret

000000000000205c <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    205c:	00a5c7b3          	xor	a5,a1,a0
    2060:	8b9d                	andi	a5,a5,7
    2062:	eb95                	bnez	a5,2096 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2064:	0075f793          	andi	a5,a1,7
    2068:	e7b1                	bnez	a5,20b4 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    206a:	6198                	ld	a4,0(a1)
    206c:	00001617          	auipc	a2,0x1
    2070:	81c63603          	ld	a2,-2020(a2) # 2888 <enable_deadlock_detect+0x1a8>
    2074:	00001817          	auipc	a6,0x1
    2078:	81c83803          	ld	a6,-2020(a6) # 2890 <enable_deadlock_detect+0x1b0>
    207c:	a029                	j	2086 <stpcpy+0x2a>
    207e:	05a1                	addi	a1,a1,8
    2080:	e118                	sd	a4,0(a0)
    2082:	6198                	ld	a4,0(a1)
    2084:	0521                	addi	a0,a0,8
    2086:	00c707b3          	add	a5,a4,a2
    208a:	fff74693          	not	a3,a4
    208e:	8ff5                	and	a5,a5,a3
    2090:	0107f7b3          	and	a5,a5,a6
    2094:	d7ed                	beqz	a5,207e <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2096:	0005c783          	lbu	a5,0(a1)
    209a:	00f50023          	sb	a5,0(a0)
    209e:	c785                	beqz	a5,20c6 <stpcpy+0x6a>
    20a0:	0015c783          	lbu	a5,1(a1)
    20a4:	0505                	addi	a0,a0,1
    20a6:	0585                	addi	a1,a1,1
    20a8:	00f50023          	sb	a5,0(a0)
    20ac:	fbf5                	bnez	a5,20a0 <stpcpy+0x44>
		;
	return d;
}
    20ae:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    20b0:	0505                	addi	a0,a0,1
    20b2:	df45                	beqz	a4,206a <stpcpy+0xe>
			if (!(*d = *s))
    20b4:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    20b8:	0585                	addi	a1,a1,1
    20ba:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    20be:	00f50023          	sb	a5,0(a0)
    20c2:	f7fd                	bnez	a5,20b0 <stpcpy+0x54>
}
    20c4:	8082                	ret
    20c6:	8082                	ret

00000000000020c8 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    20c8:	00a5c7b3          	xor	a5,a1,a0
    20cc:	8b9d                	andi	a5,a5,7
    20ce:	1a079863          	bnez	a5,227e <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    20d2:	0075f793          	andi	a5,a1,7
    20d6:	16078463          	beqz	a5,223e <stpncpy+0x176>
    20da:	ea01                	bnez	a2,20ea <stpncpy+0x22>
    20dc:	a421                	j	22e4 <stpncpy+0x21c>
    20de:	167d                	addi	a2,a2,-1
    20e0:	0505                	addi	a0,a0,1
    20e2:	14070e63          	beqz	a4,223e <stpncpy+0x176>
    20e6:	1a060863          	beqz	a2,2296 <stpncpy+0x1ce>
    20ea:	0005c783          	lbu	a5,0(a1)
    20ee:	0585                	addi	a1,a1,1
    20f0:	0075f713          	andi	a4,a1,7
    20f4:	00f50023          	sb	a5,0(a0)
    20f8:	f3fd                	bnez	a5,20de <stpncpy+0x16>
    20fa:	4805                	li	a6,1
    20fc:	1a061863          	bnez	a2,22ac <stpncpy+0x1e4>
    2100:	40a007b3          	neg	a5,a0
    2104:	8b9d                	andi	a5,a5,7
    2106:	4681                	li	a3,0
    2108:	18061a63          	bnez	a2,229c <stpncpy+0x1d4>
    210c:	00778713          	addi	a4,a5,7
    2110:	45ad                	li	a1,11
    2112:	18b76363          	bltu	a4,a1,2298 <stpncpy+0x1d0>
    2116:	1ae6eb63          	bltu	a3,a4,22cc <stpncpy+0x204>
    211a:	1a078363          	beqz	a5,22c0 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    211e:	00050023          	sb	zero,0(a0)
    2122:	4685                	li	a3,1
    2124:	00150713          	addi	a4,a0,1
    2128:	18d78f63          	beq	a5,a3,22c6 <stpncpy+0x1fe>
    212c:	000500a3          	sb	zero,1(a0)
    2130:	4689                	li	a3,2
    2132:	00250713          	addi	a4,a0,2
    2136:	18d78e63          	beq	a5,a3,22d2 <stpncpy+0x20a>
    213a:	00050123          	sb	zero,2(a0)
    213e:	468d                	li	a3,3
    2140:	00350713          	addi	a4,a0,3
    2144:	16d78c63          	beq	a5,a3,22bc <stpncpy+0x1f4>
    2148:	000501a3          	sb	zero,3(a0)
    214c:	4691                	li	a3,4
    214e:	00450713          	addi	a4,a0,4
    2152:	18d78263          	beq	a5,a3,22d6 <stpncpy+0x20e>
    2156:	00050223          	sb	zero,4(a0)
    215a:	4695                	li	a3,5
    215c:	00550713          	addi	a4,a0,5
    2160:	16d78d63          	beq	a5,a3,22da <stpncpy+0x212>
    2164:	000502a3          	sb	zero,5(a0)
    2168:	469d                	li	a3,7
    216a:	00650713          	addi	a4,a0,6
    216e:	16d79863          	bne	a5,a3,22de <stpncpy+0x216>
    2172:	00750713          	addi	a4,a0,7
    2176:	00050323          	sb	zero,6(a0)
    217a:	40f80833          	sub	a6,a6,a5
    217e:	ff887593          	andi	a1,a6,-8
    2182:	97aa                	add	a5,a5,a0
    2184:	95be                	add	a1,a1,a5
    2186:	0007b023          	sd	zero,0(a5)
    218a:	07a1                	addi	a5,a5,8
    218c:	feb79de3          	bne	a5,a1,2186 <stpncpy+0xbe>
    2190:	ff887593          	andi	a1,a6,-8
    2194:	9ead                	addw	a3,a3,a1
    2196:	00b707b3          	add	a5,a4,a1
    219a:	12b80863          	beq	a6,a1,22ca <stpncpy+0x202>
    219e:	00078023          	sb	zero,0(a5)
    21a2:	0016871b          	addiw	a4,a3,1
    21a6:	0ec77863          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21aa:	000780a3          	sb	zero,1(a5)
    21ae:	0026871b          	addiw	a4,a3,2
    21b2:	0ec77263          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21b6:	00078123          	sb	zero,2(a5)
    21ba:	0036871b          	addiw	a4,a3,3
    21be:	0cc77c63          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21c2:	000781a3          	sb	zero,3(a5)
    21c6:	0046871b          	addiw	a4,a3,4
    21ca:	0cc77663          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21ce:	00078223          	sb	zero,4(a5)
    21d2:	0056871b          	addiw	a4,a3,5
    21d6:	0cc77063          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21da:	000782a3          	sb	zero,5(a5)
    21de:	0066871b          	addiw	a4,a3,6
    21e2:	0ac77a63          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21e6:	00078323          	sb	zero,6(a5)
    21ea:	0076871b          	addiw	a4,a3,7
    21ee:	0ac77463          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21f2:	000783a3          	sb	zero,7(a5)
    21f6:	0086871b          	addiw	a4,a3,8
    21fa:	08c77e63          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    21fe:	00078423          	sb	zero,8(a5)
    2202:	0096871b          	addiw	a4,a3,9
    2206:	08c77863          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    220a:	000784a3          	sb	zero,9(a5)
    220e:	00a6871b          	addiw	a4,a3,10
    2212:	08c77263          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    2216:	00078523          	sb	zero,10(a5)
    221a:	00b6871b          	addiw	a4,a3,11
    221e:	06c77c63          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    2222:	000785a3          	sb	zero,11(a5)
    2226:	00c6871b          	addiw	a4,a3,12
    222a:	06c77663          	bgeu	a4,a2,2296 <stpncpy+0x1ce>
    222e:	00078623          	sb	zero,12(a5)
    2232:	26b5                	addiw	a3,a3,13
    2234:	06c6f163          	bgeu	a3,a2,2296 <stpncpy+0x1ce>
    2238:	000786a3          	sb	zero,13(a5)
    223c:	8082                	ret
			;
		if (!n || !*s)
    223e:	c645                	beqz	a2,22e6 <stpncpy+0x21e>
    2240:	0005c783          	lbu	a5,0(a1)
    2244:	ea078be3          	beqz	a5,20fa <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2248:	479d                	li	a5,7
    224a:	02c7ff63          	bgeu	a5,a2,2288 <stpncpy+0x1c0>
    224e:	00000897          	auipc	a7,0x0
    2252:	63a8b883          	ld	a7,1594(a7) # 2888 <enable_deadlock_detect+0x1a8>
    2256:	00000817          	auipc	a6,0x0
    225a:	63a83803          	ld	a6,1594(a6) # 2890 <enable_deadlock_detect+0x1b0>
    225e:	431d                	li	t1,7
    2260:	6198                	ld	a4,0(a1)
    2262:	011707b3          	add	a5,a4,a7
    2266:	fff74693          	not	a3,a4
    226a:	8ff5                	and	a5,a5,a3
    226c:	0107f7b3          	and	a5,a5,a6
    2270:	ef81                	bnez	a5,2288 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2272:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2274:	1661                	addi	a2,a2,-8
    2276:	05a1                	addi	a1,a1,8
    2278:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    227a:	fec363e3          	bltu	t1,a2,2260 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    227e:	e609                	bnez	a2,2288 <stpncpy+0x1c0>
    2280:	a08d                	j	22e2 <stpncpy+0x21a>
    2282:	167d                	addi	a2,a2,-1
    2284:	0505                	addi	a0,a0,1
    2286:	ca01                	beqz	a2,2296 <stpncpy+0x1ce>
    2288:	0005c783          	lbu	a5,0(a1)
    228c:	0585                	addi	a1,a1,1
    228e:	00f50023          	sb	a5,0(a0)
    2292:	fbe5                	bnez	a5,2282 <stpncpy+0x1ba>
		;
tail:
    2294:	b59d                	j	20fa <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2296:	8082                	ret
    2298:	472d                	li	a4,11
    229a:	bdb5                	j	2116 <stpncpy+0x4e>
    229c:	00778713          	addi	a4,a5,7
    22a0:	45ad                	li	a1,11
    22a2:	fff60693          	addi	a3,a2,-1
    22a6:	e6b778e3          	bgeu	a4,a1,2116 <stpncpy+0x4e>
    22aa:	b7fd                	j	2298 <stpncpy+0x1d0>
    22ac:	40a007b3          	neg	a5,a0
    22b0:	8832                	mv	a6,a2
    22b2:	8b9d                	andi	a5,a5,7
    22b4:	4681                	li	a3,0
    22b6:	e4060be3          	beqz	a2,210c <stpncpy+0x44>
    22ba:	b7cd                	j	229c <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22bc:	468d                	li	a3,3
    22be:	bd75                	j	217a <stpncpy+0xb2>
    22c0:	872a                	mv	a4,a0
    22c2:	4681                	li	a3,0
    22c4:	bd5d                	j	217a <stpncpy+0xb2>
    22c6:	4685                	li	a3,1
    22c8:	bd4d                	j	217a <stpncpy+0xb2>
    22ca:	8082                	ret
    22cc:	87aa                	mv	a5,a0
    22ce:	4681                	li	a3,0
    22d0:	b5f9                	j	219e <stpncpy+0xd6>
    22d2:	4689                	li	a3,2
    22d4:	b55d                	j	217a <stpncpy+0xb2>
    22d6:	4691                	li	a3,4
    22d8:	b54d                	j	217a <stpncpy+0xb2>
    22da:	4695                	li	a3,5
    22dc:	bd79                	j	217a <stpncpy+0xb2>
    22de:	4699                	li	a3,6
    22e0:	bd69                	j	217a <stpncpy+0xb2>
    22e2:	8082                	ret
    22e4:	8082                	ret
    22e6:	8082                	ret

00000000000022e8 <basename>:

char *basename(char *s)
{
    22e8:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    22ea:	c54d                	beqz	a0,2394 <basename+0xac>
    22ec:	00054783          	lbu	a5,0(a0)
		return ".";
    22f0:	00000517          	auipc	a0,0x0
    22f4:	59050513          	addi	a0,a0,1424 # 2880 <enable_deadlock_detect+0x1a0>
	if (!s || !*s)
    22f8:	e391                	bnez	a5,22fc <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    22fa:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    22fc:	0076f713          	andi	a4,a3,7
    2300:	87b6                	mv	a5,a3
    2302:	cf51                	beqz	a4,239e <basename+0xb6>
    2304:	0785                	addi	a5,a5,1
    2306:	0077f713          	andi	a4,a5,7
    230a:	c729                	beqz	a4,2354 <basename+0x6c>
		if (!*s)
    230c:	0007c703          	lbu	a4,0(a5)
    2310:	fb75                	bnez	a4,2304 <basename+0x1c>
	return s - a;
    2312:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    2314:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    2316:	cf8d                	beqz	a5,2350 <basename+0x68>
    2318:	00f68733          	add	a4,a3,a5
    231c:	02f00593          	li	a1,47
    2320:	a031                	j	232c <basename+0x44>
		s[i] = 0;
    2322:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2326:	17fd                	addi	a5,a5,-1
    2328:	177d                	addi	a4,a4,-1
    232a:	c39d                	beqz	a5,2350 <basename+0x68>
    232c:	00074603          	lbu	a2,0(a4)
    2330:	feb609e3          	beq	a2,a1,2322 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    2334:	02f00613          	li	a2,47
    2338:	a011                	j	233c <basename+0x54>
    233a:	cb99                	beqz	a5,2350 <basename+0x68>
    233c:	853e                	mv	a0,a5
    233e:	17fd                	addi	a5,a5,-1
    2340:	00f68733          	add	a4,a3,a5
    2344:	00074703          	lbu	a4,0(a4)
    2348:	fec719e3          	bne	a4,a2,233a <basename+0x52>
	return s + i;
    234c:	9536                	add	a0,a0,a3
    234e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2350:	8536                	mv	a0,a3
    2352:	8082                	ret
    2354:	6390                	ld	a2,0(a5)
    2356:	00000517          	auipc	a0,0x0
    235a:	53253503          	ld	a0,1330(a0) # 2888 <enable_deadlock_detect+0x1a8>
    235e:	00000597          	auipc	a1,0x0
    2362:	5325b583          	ld	a1,1330(a1) # 2890 <enable_deadlock_detect+0x1b0>
    2366:	fff64713          	not	a4,a2
    236a:	962a                	add	a2,a2,a0
    236c:	8f71                	and	a4,a4,a2
    236e:	8f6d                	and	a4,a4,a1
    2370:	eb11                	bnez	a4,2384 <basename+0x9c>
    2372:	6790                	ld	a2,8(a5)
    2374:	07a1                	addi	a5,a5,8
    2376:	00a60733          	add	a4,a2,a0
    237a:	fff64613          	not	a2,a2
    237e:	8f71                	and	a4,a4,a2
    2380:	8f6d                	and	a4,a4,a1
    2382:	db65                	beqz	a4,2372 <basename+0x8a>
	for (; *s; s++)
    2384:	0007c703          	lbu	a4,0(a5)
    2388:	d749                	beqz	a4,2312 <basename+0x2a>
    238a:	0017c703          	lbu	a4,1(a5)
    238e:	0785                	addi	a5,a5,1
    2390:	ff6d                	bnez	a4,238a <basename+0xa2>
    2392:	b741                	j	2312 <basename+0x2a>
		return ".";
    2394:	00000517          	auipc	a0,0x0
    2398:	4ec50513          	addi	a0,a0,1260 # 2880 <enable_deadlock_detect+0x1a0>
    239c:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    239e:	6290                	ld	a2,0(a3)
    23a0:	00000517          	auipc	a0,0x0
    23a4:	4e853503          	ld	a0,1256(a0) # 2888 <enable_deadlock_detect+0x1a8>
    23a8:	00000597          	auipc	a1,0x0
    23ac:	4e85b583          	ld	a1,1256(a1) # 2890 <enable_deadlock_detect+0x1b0>
    23b0:	fff64713          	not	a4,a2
    23b4:	962a                	add	a2,a2,a0
    23b6:	8f71                	and	a4,a4,a2
    23b8:	8f6d                	and	a4,a4,a1
    23ba:	df45                	beqz	a4,2372 <basename+0x8a>
    23bc:	b7f9                	j	238a <basename+0xa2>

00000000000023be <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    23be:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    23c2:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    23c4:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    23c8:	2501                	sext.w	a0,a0
    23ca:	8082                	ret

00000000000023cc <close>:

int close(int fd)
{
	if (fd == 1) {
    23cc:	4785                	li	a5,1
    23ce:	00f50863          	beq	a0,a5,23de <close+0x12>
	register long a7 __asm__("a7") = n;
    23d2:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23d6:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    23da:	2501                	sext.w	a0,a0
    23dc:	8082                	ret
{
    23de:	1101                	addi	sp,sp,-32
    23e0:	ec06                	sd	ra,24(sp)
    23e2:	e42a                	sd	a0,8(sp)
		__write_buffer();
    23e4:	cdffe0ef          	jal	ra,10c2 <__write_buffer>
		__clear_buffer();
    23e8:	d03fe0ef          	jal	ra,10ea <__clear_buffer>
    23ec:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    23ee:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    23f2:	00000073          	ecall
}
    23f6:	60e2                	ld	ra,24(sp)
    23f8:	2501                	sext.w	a0,a0
    23fa:	6105                	addi	sp,sp,32
    23fc:	8082                	ret

00000000000023fe <read>:
	register long a7 __asm__("a7") = n;
    23fe:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2402:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    2406:	8082                	ret

0000000000002408 <write>:
	register long a7 __asm__("a7") = n;
    2408:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    240c:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    2410:	8082                	ret

0000000000002412 <getpid>:
	register long a7 __asm__("a7") = n;
    2412:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    2416:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    241a:	2501                	sext.w	a0,a0
    241c:	8082                	ret

000000000000241e <getppid>:
	register long a7 __asm__("a7") = n;
    241e:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    2422:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2426:	2501                	sext.w	a0,a0
    2428:	8082                	ret

000000000000242a <sched_yield>:
	register long a7 __asm__("a7") = n;
    242a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    242e:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    2432:	2501                	sext.w	a0,a0
    2434:	8082                	ret

0000000000002436 <fork>:
	register long a7 __asm__("a7") = n;
    2436:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    243a:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    243e:	2501                	sext.w	a0,a0
    2440:	8082                	ret

0000000000002442 <exit>:

void exit(int code)
{
    2442:	1141                	addi	sp,sp,-16
    2444:	e406                	sd	ra,8(sp)
    2446:	e022                	sd	s0,0(sp)
    2448:	842a                	mv	s0,a0
	__write_buffer();
    244a:	c79fe0ef          	jal	ra,10c2 <__write_buffer>
	__clear_buffer();
    244e:	c9dfe0ef          	jal	ra,10ea <__clear_buffer>
	register long a7 __asm__("a7") = n;
    2452:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2456:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2458:	00000073          	ecall
	syscall(SYS_exit, code);
}
    245c:	60a2                	ld	ra,8(sp)
    245e:	6402                	ld	s0,0(sp)
    2460:	0141                	addi	sp,sp,16
    2462:	8082                	ret

0000000000002464 <waitpid>:
	register long a7 __asm__("a7") = n;
    2464:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2468:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    246c:	2501                	sext.w	a0,a0
    246e:	8082                	ret

0000000000002470 <exec>:
	register long a7 __asm__("a7") = n;
    2470:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2474:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2478:	2501                	sext.w	a0,a0
    247a:	8082                	ret

000000000000247c <get_mtime>:

int64 get_mtime()
{
    247c:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    247e:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2482:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    2484:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2486:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    248a:	2501                	sext.w	a0,a0
    248c:	ed01                	bnez	a0,24a4 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    248e:	6722                	ld	a4,8(sp)
    2490:	3e800793          	li	a5,1000
    2494:	6682                	ld	a3,0(sp)
    2496:	02f75733          	divu	a4,a4,a5
    249a:	02d78533          	mul	a0,a5,a3
    249e:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    24a0:	0141                	addi	sp,sp,16
    24a2:	8082                	ret
	return -1;
    24a4:	557d                	li	a0,-1
    24a6:	bfed                	j	24a0 <get_mtime+0x24>

00000000000024a8 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    24a8:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24ac:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    24b0:	2501                	sext.w	a0,a0
    24b2:	8082                	ret

00000000000024b4 <sleep>:

int sleep(unsigned long long time)
{
    24b4:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    24b6:	880a                	mv	a6,sp
{
    24b8:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    24ba:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24be:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24c0:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24c2:	00000073          	ecall
	if (err == 0) {
    24c6:	2501                	sext.w	a0,a0
    24c8:	ed31                	bnez	a0,2524 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    24ca:	6722                	ld	a4,8(sp)
    24cc:	3e800793          	li	a5,1000
    24d0:	6682                	ld	a3,0(sp)
    24d2:	02f75733          	divu	a4,a4,a5
    24d6:	02d787b3          	mul	a5,a5,a3
    24da:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    24dc:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24e0:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24e2:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    24e4:	00000073          	ecall
	if (err == 0) {
    24e8:	2501                	sext.w	a0,a0
    24ea:	e915                	bnez	a0,251e <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    24ec:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    24ee:	3e800693          	li	a3,1000
    24f2:	a819                	j	2508 <sleep+0x54>
	__asm_syscall("r"(a7))
    24f4:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    24f8:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    24fc:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    24fe:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2500:	00000073          	ecall
	if (err == 0) {
    2504:	2501                	sext.w	a0,a0
    2506:	ed01                	bnez	a0,251e <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    2508:	6722                	ld	a4,8(sp)
    250a:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    250c:	07c00893          	li	a7,124
    2510:	02d75733          	divu	a4,a4,a3
    2514:	02f687b3          	mul	a5,a3,a5
    2518:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    251a:	fcc7ede3          	bltu	a5,a2,24f4 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    251e:	4501                	li	a0,0
    2520:	0141                	addi	sp,sp,16
    2522:	8082                	ret
    2524:	57fd                	li	a5,-1
    2526:	bf5d                	j	24dc <sleep+0x28>

0000000000002528 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2528:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    252c:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    2530:	2501                	sext.w	a0,a0
    2532:	8082                	ret

0000000000002534 <set_priority>:
	register long a7 __asm__("a7") = n;
    2534:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2538:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    253c:	2501                	sext.w	a0,a0
    253e:	8082                	ret

0000000000002540 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    2540:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2544:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2548:	2501                	sext.w	a0,a0
    254a:	8082                	ret

000000000000254c <munmap>:
	register long a7 __asm__("a7") = n;
    254c:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2550:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    2554:	2501                	sext.w	a0,a0
    2556:	8082                	ret

0000000000002558 <wait>:

int wait(int *code)
{
    2558:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    255a:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    255e:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2560:	00000073          	ecall
	return waitpid(-1, code);
}
    2564:	2501                	sext.w	a0,a0
    2566:	8082                	ret

0000000000002568 <spawn>:
	register long a7 __asm__("a7") = n;
    2568:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    256c:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    2570:	2501                	sext.w	a0,a0
    2572:	8082                	ret

0000000000002574 <pipe>:
	register long a7 __asm__("a7") = n;
    2574:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2578:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    257c:	2501                	sext.w	a0,a0
    257e:	8082                	ret

0000000000002580 <mailread>:
	register long a7 __asm__("a7") = n;
    2580:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2584:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2588:	2501                	sext.w	a0,a0
    258a:	8082                	ret

000000000000258c <mailwrite>:
	register long a7 __asm__("a7") = n;
    258c:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2590:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    2594:	2501                	sext.w	a0,a0
    2596:	8082                	ret

0000000000002598 <fstat>:
	register long a7 __asm__("a7") = n;
    2598:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    259c:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    25a0:	2501                	sext.w	a0,a0
    25a2:	8082                	ret

00000000000025a4 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    25a4:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    25a6:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    25aa:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25ac:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    25b0:	2501                	sext.w	a0,a0
    25b2:	8082                	ret

00000000000025b4 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    25b4:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    25b6:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    25ba:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25bc:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    25c0:	2501                	sext.w	a0,a0
    25c2:	8082                	ret

00000000000025c4 <link>:

int link(char *old_path, char *new_path)
{
    25c4:	87aa                	mv	a5,a0
    25c6:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    25c8:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    25cc:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    25d0:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    25d2:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    25d6:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    25d8:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    25dc:	2501                	sext.w	a0,a0
    25de:	8082                	ret

00000000000025e0 <unlink>:

int unlink(char *path)
{
    25e0:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    25e2:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    25e6:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    25ea:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25ec:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    25f0:	2501                	sext.w	a0,a0
    25f2:	8082                	ret

00000000000025f4 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    25f4:	00000797          	auipc	a5,0x0
    25f8:	3dc7b783          	ld	a5,988(a5) # 29d0 <_GLOBAL_OFFSET_TABLE_+0x8>
    25fc:	439c                	lw	a5,0(a5)
    25fe:	c799                	beqz	a5,260c <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    2600:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2604:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    2608:	2501                	sext.w	a0,a0
    260a:	8082                	ret
{
    260c:	1101                	addi	sp,sp,-32
    260e:	ec06                	sd	ra,24(sp)
    2610:	e42e                	sd	a1,8(sp)
    2612:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    2614:	fe7fe0ef          	jal	ra,15fa <enable_thread_io_buffer>
    2618:	65a2                	ld	a1,8(sp)
    261a:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    261c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2620:	00000073          	ecall
}
    2624:	60e2                	ld	ra,24(sp)
    2626:	2501                	sext.w	a0,a0
    2628:	6105                	addi	sp,sp,32
    262a:	8082                	ret

000000000000262c <gettid>:
	register long a7 __asm__("a7") = n;
    262c:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    2630:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    2634:	2501                	sext.w	a0,a0
    2636:	8082                	ret

0000000000002638 <waittid>:

int waittid(int tid)
{
    2638:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    263a:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    263e:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    2642:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    2644:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2646:	00e51e63          	bne	a0,a4,2662 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    264a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    264e:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    2652:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2656:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2658:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    265c:	2501                	sext.w	a0,a0
	while (ret == -2) {
    265e:	fee506e3          	beq	a0,a4,264a <waittid+0x12>
	}
	return ret;
}
    2662:	8082                	ret

0000000000002664 <mutex_create>:
	register long a7 __asm__("a7") = n;
    2664:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2668:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    266a:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    266e:	2501                	sext.w	a0,a0
    2670:	8082                	ret

0000000000002672 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    2672:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2676:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2678:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    267c:	2501                	sext.w	a0,a0
    267e:	8082                	ret

0000000000002680 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    2680:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    2684:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2688:	2501                	sext.w	a0,a0
    268a:	8082                	ret

000000000000268c <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    268c:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    2690:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    2694:	2501                	sext.w	a0,a0
    2696:	8082                	ret

0000000000002698 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2698:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    269c:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    26a0:	2501                	sext.w	a0,a0
    26a2:	8082                	ret

00000000000026a4 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    26a4:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    26a8:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    26ac:	2501                	sext.w	a0,a0
    26ae:	8082                	ret

00000000000026b0 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    26b0:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    26b4:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    26b8:	2501                	sext.w	a0,a0
    26ba:	8082                	ret

00000000000026bc <condvar_create>:
	register long a7 __asm__("a7") = n;
    26bc:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    26c0:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    26c4:	2501                	sext.w	a0,a0
    26c6:	8082                	ret

00000000000026c8 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    26c8:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    26cc:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    26d0:	2501                	sext.w	a0,a0
    26d2:	8082                	ret

00000000000026d4 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    26d4:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26d8:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    26dc:	2501                	sext.w	a0,a0
    26de:	8082                	ret

00000000000026e0 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    26e0:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    26e4:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    26e8:	2501                	sext.w	a0,a0
    26ea:	8082                	ret
