
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/__ch2_bad_instruction:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a029                	j	100a <__start_main>

0000000000001002 <main>:
#include <stdio.h>
#include <unistd.h>

int main()
{
	asm volatile("sret");
    1002:	10200073          	sret
	return 0;
    1006:	4501                	li	a0,0
    1008:	8082                	ret

000000000000100a <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    100a:	1141                	addi	sp,sp,-16
    100c:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    100e:	ff5ff0ef          	jal	ra,1002 <main>
    1012:	090000ef          	jal	ra,10a2 <exit>
	return 0;
    1016:	60a2                	ld	ra,8(sp)
    1018:	4501                	li	a0,0
    101a:	0141                	addi	sp,sp,16
    101c:	8082                	ret

000000000000101e <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    101e:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    1022:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1024:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    1028:	2501                	sext.w	a0,a0
    102a:	8082                	ret

000000000000102c <close>:

int close(int fd)
{
	if (fd == 1) {
    102c:	4785                	li	a5,1
    102e:	00f50863          	beq	a0,a5,103e <close+0x12>
	register long a7 __asm__("a7") = n;
    1032:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1036:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    103a:	2501                	sext.w	a0,a0
    103c:	8082                	ret
{
    103e:	1101                	addi	sp,sp,-32
    1040:	ec06                	sd	ra,24(sp)
    1042:	e42a                	sd	a0,8(sp)
		__write_buffer();
    1044:	330000ef          	jal	ra,1374 <__write_buffer>
		__clear_buffer();
    1048:	354000ef          	jal	ra,139c <__clear_buffer>
    104c:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    104e:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    1052:	00000073          	ecall
}
    1056:	60e2                	ld	ra,24(sp)
    1058:	2501                	sext.w	a0,a0
    105a:	6105                	addi	sp,sp,32
    105c:	8082                	ret

000000000000105e <read>:
	register long a7 __asm__("a7") = n;
    105e:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    1062:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    1066:	8082                	ret

0000000000001068 <write>:
	register long a7 __asm__("a7") = n;
    1068:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    106c:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    1070:	8082                	ret

0000000000001072 <getpid>:
	register long a7 __asm__("a7") = n;
    1072:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    1076:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    107a:	2501                	sext.w	a0,a0
    107c:	8082                	ret

000000000000107e <getppid>:
	register long a7 __asm__("a7") = n;
    107e:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    1082:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    1086:	2501                	sext.w	a0,a0
    1088:	8082                	ret

000000000000108a <sched_yield>:
	register long a7 __asm__("a7") = n;
    108a:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    108e:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    1092:	2501                	sext.w	a0,a0
    1094:	8082                	ret

0000000000001096 <fork>:
	register long a7 __asm__("a7") = n;
    1096:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    109a:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    109e:	2501                	sext.w	a0,a0
    10a0:	8082                	ret

00000000000010a2 <exit>:

void exit(int code)
{
    10a2:	1141                	addi	sp,sp,-16
    10a4:	e406                	sd	ra,8(sp)
    10a6:	e022                	sd	s0,0(sp)
    10a8:	842a                	mv	s0,a0
	__write_buffer();
    10aa:	2ca000ef          	jal	ra,1374 <__write_buffer>
	__clear_buffer();
    10ae:	2ee000ef          	jal	ra,139c <__clear_buffer>
	register long a7 __asm__("a7") = n;
    10b2:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    10b6:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    10b8:	00000073          	ecall
	syscall(SYS_exit, code);
}
    10bc:	60a2                	ld	ra,8(sp)
    10be:	6402                	ld	s0,0(sp)
    10c0:	0141                	addi	sp,sp,16
    10c2:	8082                	ret

00000000000010c4 <waitpid>:
	register long a7 __asm__("a7") = n;
    10c4:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10c8:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    10cc:	2501                	sext.w	a0,a0
    10ce:	8082                	ret

00000000000010d0 <exec>:
	register long a7 __asm__("a7") = n;
    10d0:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10d4:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    10d8:	2501                	sext.w	a0,a0
    10da:	8082                	ret

00000000000010dc <get_mtime>:

int64 get_mtime()
{
    10dc:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    10de:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    10e2:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    10e4:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    10e6:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    10ea:	2501                	sext.w	a0,a0
    10ec:	ed01                	bnez	a0,1104 <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    10ee:	6722                	ld	a4,8(sp)
    10f0:	3e800793          	li	a5,1000
    10f4:	6682                	ld	a3,0(sp)
    10f6:	02f75733          	divu	a4,a4,a5
    10fa:	02d78533          	mul	a0,a5,a3
    10fe:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    1100:	0141                	addi	sp,sp,16
    1102:	8082                	ret
	return -1;
    1104:	557d                	li	a0,-1
    1106:	bfed                	j	1100 <get_mtime+0x24>

0000000000001108 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    1108:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    110c:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    1110:	2501                	sext.w	a0,a0
    1112:	8082                	ret

0000000000001114 <sleep>:

int sleep(unsigned long long time)
{
    1114:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    1116:	880a                	mv	a6,sp
{
    1118:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    111a:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    111e:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1120:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1122:	00000073          	ecall
	if (err == 0) {
    1126:	2501                	sext.w	a0,a0
    1128:	ed31                	bnez	a0,1184 <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    112a:	6722                	ld	a4,8(sp)
    112c:	3e800793          	li	a5,1000
    1130:	6682                	ld	a3,0(sp)
    1132:	02f75733          	divu	a4,a4,a5
    1136:	02d787b3          	mul	a5,a5,a3
    113a:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    113c:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    1140:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    1142:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1144:	00000073          	ecall
	if (err == 0) {
    1148:	2501                	sext.w	a0,a0
    114a:	e915                	bnez	a0,117e <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    114c:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    114e:	3e800693          	li	a3,1000
    1152:	a819                	j	1168 <sleep+0x54>
	__asm_syscall("r"(a7))
    1154:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    1158:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    115c:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    115e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1160:	00000073          	ecall
	if (err == 0) {
    1164:	2501                	sext.w	a0,a0
    1166:	ed01                	bnez	a0,117e <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    1168:	6722                	ld	a4,8(sp)
    116a:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    116c:	07c00893          	li	a7,124
    1170:	02d75733          	divu	a4,a4,a3
    1174:	02f687b3          	mul	a5,a3,a5
    1178:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    117a:	fcc7ede3          	bltu	a5,a2,1154 <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    117e:	4501                	li	a0,0
    1180:	0141                	addi	sp,sp,16
    1182:	8082                	ret
    1184:	57fd                	li	a5,-1
    1186:	bf5d                	j	113c <sleep+0x28>

0000000000001188 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    1188:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    118c:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    1190:	2501                	sext.w	a0,a0
    1192:	8082                	ret

0000000000001194 <set_priority>:
	register long a7 __asm__("a7") = n;
    1194:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    1198:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    119c:	2501                	sext.w	a0,a0
    119e:	8082                	ret

00000000000011a0 <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    11a0:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    11a4:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    11a8:	2501                	sext.w	a0,a0
    11aa:	8082                	ret

00000000000011ac <munmap>:
	register long a7 __asm__("a7") = n;
    11ac:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11b0:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    11b4:	2501                	sext.w	a0,a0
    11b6:	8082                	ret

00000000000011b8 <wait>:

int wait(int *code)
{
    11b8:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    11ba:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    11be:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11c0:	00000073          	ecall
	return waitpid(-1, code);
}
    11c4:	2501                	sext.w	a0,a0
    11c6:	8082                	ret

00000000000011c8 <spawn>:
	register long a7 __asm__("a7") = n;
    11c8:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    11cc:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    11d0:	2501                	sext.w	a0,a0
    11d2:	8082                	ret

00000000000011d4 <pipe>:
	register long a7 __asm__("a7") = n;
    11d4:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    11d8:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    11dc:	2501                	sext.w	a0,a0
    11de:	8082                	ret

00000000000011e0 <mailread>:
	register long a7 __asm__("a7") = n;
    11e0:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11e4:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    11e8:	2501                	sext.w	a0,a0
    11ea:	8082                	ret

00000000000011ec <mailwrite>:
	register long a7 __asm__("a7") = n;
    11ec:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    11f0:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    11f4:	2501                	sext.w	a0,a0
    11f6:	8082                	ret

00000000000011f8 <fstat>:
	register long a7 __asm__("a7") = n;
    11f8:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    11fc:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    1200:	2501                	sext.w	a0,a0
    1202:	8082                	ret

0000000000001204 <sys_linkat>:
	register long a4 __asm__("a4") = e;
    1204:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    1206:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    120a:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    120c:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    1210:	2501                	sext.w	a0,a0
    1212:	8082                	ret

0000000000001214 <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    1214:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    1216:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    121a:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    121c:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    1220:	2501                	sext.w	a0,a0
    1222:	8082                	ret

0000000000001224 <link>:

int link(char *old_path, char *new_path)
{
    1224:	87aa                	mv	a5,a0
    1226:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    1228:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    122c:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    1230:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    1232:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    1236:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    1238:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    123c:	2501                	sext.w	a0,a0
    123e:	8082                	ret

0000000000001240 <unlink>:

int unlink(char *path)
{
    1240:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    1242:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    1246:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    124a:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    124c:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    1250:	2501                	sext.w	a0,a0
    1252:	8082                	ret

0000000000001254 <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    1254:	00001797          	auipc	a5,0x1
    1258:	64c7b783          	ld	a5,1612(a5) # 28a0 <_GLOBAL_OFFSET_TABLE_+0x8>
    125c:	439c                	lw	a5,0(a5)
    125e:	c799                	beqz	a5,126c <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    1260:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1264:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    1268:	2501                	sext.w	a0,a0
    126a:	8082                	ret
{
    126c:	1101                	addi	sp,sp,-32
    126e:	ec06                	sd	ra,24(sp)
    1270:	e42e                	sd	a1,8(sp)
    1272:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    1274:	638000ef          	jal	ra,18ac <enable_thread_io_buffer>
    1278:	65a2                	ld	a1,8(sp)
    127a:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    127c:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1280:	00000073          	ecall
}
    1284:	60e2                	ld	ra,24(sp)
    1286:	2501                	sext.w	a0,a0
    1288:	6105                	addi	sp,sp,32
    128a:	8082                	ret

000000000000128c <gettid>:
	register long a7 __asm__("a7") = n;
    128c:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    1290:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    1294:	2501                	sext.w	a0,a0
    1296:	8082                	ret

0000000000001298 <waittid>:

int waittid(int tid)
{
    1298:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    129a:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    129e:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    12a2:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    12a4:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12a6:	00e51e63          	bne	a0,a4,12c2 <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    12aa:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    12ae:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    12b2:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    12b6:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    12b8:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    12bc:	2501                	sext.w	a0,a0
	while (ret == -2) {
    12be:	fee506e3          	beq	a0,a4,12aa <waittid+0x12>
	}
	return ret;
}
    12c2:	8082                	ret

00000000000012c4 <mutex_create>:
	register long a7 __asm__("a7") = n;
    12c4:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12c8:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    12ca:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    12ce:	2501                	sext.w	a0,a0
    12d0:	8082                	ret

00000000000012d2 <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    12d2:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    12d6:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    12d8:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    12dc:	2501                	sext.w	a0,a0
    12de:	8082                	ret

00000000000012e0 <mutex_lock>:
	register long a7 __asm__("a7") = n;
    12e0:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    12e4:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    12e8:	2501                	sext.w	a0,a0
    12ea:	8082                	ret

00000000000012ec <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    12ec:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    12f0:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    12f4:	2501                	sext.w	a0,a0
    12f6:	8082                	ret

00000000000012f8 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    12f8:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    12fc:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    1300:	2501                	sext.w	a0,a0
    1302:	8082                	ret

0000000000001304 <semaphore_up>:
	register long a7 __asm__("a7") = n;
    1304:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    1308:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    130c:	2501                	sext.w	a0,a0
    130e:	8082                	ret

0000000000001310 <semaphore_down>:
	register long a7 __asm__("a7") = n;
    1310:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    1314:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    1318:	2501                	sext.w	a0,a0
    131a:	8082                	ret

000000000000131c <condvar_create>:
	register long a7 __asm__("a7") = n;
    131c:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    1320:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    1324:	2501                	sext.w	a0,a0
    1326:	8082                	ret

0000000000001328 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    1328:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    132c:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    1330:	2501                	sext.w	a0,a0
    1332:	8082                	ret

0000000000001334 <condvar_wait>:
	register long a7 __asm__("a7") = n;
    1334:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    1338:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    133c:	2501                	sext.w	a0,a0
    133e:	8082                	ret

0000000000001340 <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    1340:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    1344:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    1348:	2501                	sext.w	a0,a0
    134a:	8082                	ret

000000000000134c <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    134c:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    134e:	4605                	li	a2,1
    1350:	00f10593          	addi	a1,sp,15
    1354:	4501                	li	a0,0
{
    1356:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1358:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    135c:	d03ff0ef          	jal	ra,105e <read>
    1360:	4785                	li	a5,1
    1362:	00f51763          	bne	a0,a5,1370 <getchar+0x24>
		return byte;
    1366:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    136a:	60e2                	ld	ra,24(sp)
    136c:	6105                	addi	sp,sp,32
    136e:	8082                	ret
		return EOF;
    1370:	557d                	li	a0,-1
    1372:	bfe5                	j	136a <getchar+0x1e>

0000000000001374 <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    1374:	00001517          	auipc	a0,0x1
    1378:	3fc52503          	lw	a0,1020(a0) # 2770 <buffer_len>
    137c:	e111                	bnez	a0,1380 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    137e:	8082                	ret
{
    1380:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    1382:	862a                	mv	a2,a0
    1384:	00001597          	auipc	a1,0x1
    1388:	3f458593          	addi	a1,a1,1012 # 2778 <buffer>
    138c:	4505                	li	a0,1
{
    138e:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1390:	cd9ff0ef          	jal	ra,1068 <write>
}
    1394:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    1396:	2501                	sext.w	a0,a0
}
    1398:	0141                	addi	sp,sp,16
    139a:	8082                	ret

000000000000139c <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    139c:	00001797          	auipc	a5,0x1
    13a0:	3c07aa23          	sw	zero,980(a5) # 2770 <buffer_len>
}
    13a4:	8082                	ret

00000000000013a6 <__fflush>:
	if (buffer_len == 0)
    13a6:	00001517          	auipc	a0,0x1
    13aa:	3ca52503          	lw	a0,970(a0) # 2770 <buffer_len>
    13ae:	e511                	bnez	a0,13ba <__fflush+0x14>
	buffer_len = 0;
    13b0:	00001797          	auipc	a5,0x1
    13b4:	3c07a023          	sw	zero,960(a5) # 2770 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    13b8:	8082                	ret
{
    13ba:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    13bc:	862a                	mv	a2,a0
    13be:	00001597          	auipc	a1,0x1
    13c2:	3ba58593          	addi	a1,a1,954 # 2778 <buffer>
    13c6:	4505                	li	a0,1
{
    13c8:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    13ca:	c9fff0ef          	jal	ra,1068 <write>
	return r >= 0 ? 0 : r;
    13ce:	0005079b          	sext.w	a5,a0
}
    13d2:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    13d4:	0017a793          	slti	a5,a5,1
    13d8:	40f007bb          	negw	a5,a5
    13dc:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    13de:	00001797          	auipc	a5,0x1
    13e2:	3807a923          	sw	zero,914(a5) # 2770 <buffer_len>
	return r >= 0 ? 0 : r;
    13e6:	2501                	sext.w	a0,a0
}
    13e8:	0141                	addi	sp,sp,16
    13ea:	8082                	ret

00000000000013ec <fflush>:

int fflush(int fd)
{
    13ec:	1101                	addi	sp,sp,-32
    13ee:	e822                	sd	s0,16(sp)
    13f0:	ec06                	sd	ra,24(sp)
    13f2:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    13f4:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    13f6:	4401                	li	s0,0
	if (fd == 1) {
    13f8:	00e50863          	beq	a0,a4,1408 <fflush+0x1c>
}
    13fc:	60e2                	ld	ra,24(sp)
    13fe:	8522                	mv	a0,s0
    1400:	6442                	ld	s0,16(sp)
    1402:	64a2                	ld	s1,8(sp)
    1404:	6105                	addi	sp,sp,32
    1406:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1408:	00001497          	auipc	s1,0x1
    140c:	36848493          	addi	s1,s1,872 # 2770 <buffer_len>
    1410:	1084a703          	lw	a4,264(s1)
    1414:	02a70e63          	beq	a4,a0,1450 <fflush+0x64>
	if (buffer_len == 0)
    1418:	4080                	lw	s0,0(s1)
    141a:	c00d                	beqz	s0,143c <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    141c:	8622                	mv	a2,s0
    141e:	00001597          	auipc	a1,0x1
    1422:	35a58593          	addi	a1,a1,858 # 2778 <buffer>
    1426:	c43ff0ef          	jal	ra,1068 <write>
	return r >= 0 ? 0 : r;
    142a:	0005079b          	sext.w	a5,a0
    142e:	0017a793          	slti	a5,a5,1
    1432:	40f007bb          	negw	a5,a5
    1436:	8d7d                	and	a0,a0,a5
    1438:	0005041b          	sext.w	s0,a0
}
    143c:	60e2                	ld	ra,24(sp)
    143e:	8522                	mv	a0,s0
    1440:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    1442:	00001797          	auipc	a5,0x1
    1446:	3207a723          	sw	zero,814(a5) # 2770 <buffer_len>
}
    144a:	64a2                	ld	s1,8(sp)
    144c:	6105                	addi	sp,sp,32
    144e:	8082                	ret
			mutex_lock(buffer_lock);
    1450:	10c4a503          	lw	a0,268(s1)
    1454:	e8dff0ef          	jal	ra,12e0 <mutex_lock>
	if (buffer_len == 0)
    1458:	4080                	lw	s0,0(s1)
    145a:	e811                	bnez	s0,146e <fflush+0x82>
			mutex_unlock(buffer_lock);
    145c:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1460:	00001797          	auipc	a5,0x1
    1464:	3007a823          	sw	zero,784(a5) # 2770 <buffer_len>
			mutex_unlock(buffer_lock);
    1468:	e85ff0ef          	jal	ra,12ec <mutex_unlock>
    146c:	bf41                	j	13fc <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    146e:	8622                	mv	a2,s0
    1470:	00001597          	auipc	a1,0x1
    1474:	30858593          	addi	a1,a1,776 # 2778 <buffer>
    1478:	4505                	li	a0,1
    147a:	befff0ef          	jal	ra,1068 <write>
	return r >= 0 ? 0 : r;
    147e:	0005079b          	sext.w	a5,a0
    1482:	0017a793          	slti	a5,a5,1
    1486:	40f007bb          	negw	a5,a5
    148a:	8d7d                	and	a0,a0,a5
    148c:	0005041b          	sext.w	s0,a0
	return r;
    1490:	b7f1                	j	145c <fflush+0x70>

0000000000001492 <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    1492:	7131                	addi	sp,sp,-192
    1494:	e0da                	sd	s6,64(sp)
    1496:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    1498:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    149a:	013c                	addi	a5,sp,136
{
    149c:	f0ca                	sd	s2,96(sp)
    149e:	ecce                	sd	s3,88(sp)
    14a0:	e8d2                	sd	s4,80(sp)
    14a2:	e4d6                	sd	s5,72(sp)
    14a4:	fc86                	sd	ra,120(sp)
    14a6:	f8a2                	sd	s0,112(sp)
    14a8:	f4a6                	sd	s1,104(sp)
    14aa:	89aa                	mv	s3,a0
    14ac:	e52e                	sd	a1,136(sp)
    14ae:	e932                	sd	a2,144(sp)
    14b0:	ed36                	sd	a3,152(sp)
    14b2:	f13a                	sd	a4,160(sp)
    14b4:	f942                	sd	a6,176(sp)
    14b6:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    14b8:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    14ba:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    14be:	00001a17          	auipc	s4,0x1
    14c2:	2b2a0a13          	addi	s4,s4,690 # 2770 <buffer_len>
    14c6:	4a85                	li	s5,1
	buf[i++] = '0';
    14c8:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    14cc:	0009c783          	lbu	a5,0(s3)
    14d0:	18078663          	beqz	a5,165c <printf+0x1ca>
    14d4:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    14d6:	19278d63          	beq	a5,s2,1670 <printf+0x1de>
    14da:	0015c783          	lbu	a5,1(a1)
    14de:	0585                	addi	a1,a1,1
    14e0:	fbfd                	bnez	a5,14d6 <printf+0x44>
    14e2:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    14e4:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    14e8:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    14ec:	1b578863          	beq	a5,s5,169c <printf+0x20a>
		len = out_unlocked(s, l);
    14f0:	85a2                	mv	a1,s0
    14f2:	854e                	mv	a0,s3
    14f4:	42a000ef          	jal	ra,191e <out_unlocked>
		out(f, a, l);
		if (l)
    14f8:	1c041063          	bnez	s0,16b8 <printf+0x226>
			continue;
		if (s[1] == 0)
    14fc:	0014c783          	lbu	a5,1(s1)
    1500:	14078e63          	beqz	a5,165c <printf+0x1ca>
			break;
		switch (s[1]) {
    1504:	07300713          	li	a4,115
    1508:	1ce78863          	beq	a5,a4,16d8 <printf+0x246>
    150c:	1af76863          	bltu	a4,a5,16bc <printf+0x22a>
    1510:	06400713          	li	a4,100
    1514:	22e78063          	beq	a5,a4,1734 <printf+0x2a2>
    1518:	07000713          	li	a4,112
    151c:	1ee79563          	bne	a5,a4,1706 <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1520:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1522:	00001797          	auipc	a5,0x1
    1526:	35e78793          	addi	a5,a5,862 # 2880 <digits>
	buf[i++] = '0';
    152a:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    152e:	6298                	ld	a4,0(a3)
    1530:	06a1                	addi	a3,a3,8
    1532:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1534:	00471393          	slli	t2,a4,0x4
    1538:	00871293          	slli	t0,a4,0x8
    153c:	00c71f93          	slli	t6,a4,0xc
    1540:	01071f13          	slli	t5,a4,0x10
    1544:	01471e93          	slli	t4,a4,0x14
    1548:	01871e13          	slli	t3,a4,0x18
    154c:	01c71893          	slli	a7,a4,0x1c
    1550:	02471813          	slli	a6,a4,0x24
    1554:	02871513          	slli	a0,a4,0x28
    1558:	02c71593          	slli	a1,a4,0x2c
    155c:	03071613          	slli	a2,a4,0x30
    1560:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1564:	03c75413          	srli	s0,a4,0x3c
    1568:	01c7531b          	srliw	t1,a4,0x1c
    156c:	03c3d393          	srli	t2,t2,0x3c
    1570:	03c2d293          	srli	t0,t0,0x3c
    1574:	03cfdf93          	srli	t6,t6,0x3c
    1578:	03cf5f13          	srli	t5,t5,0x3c
    157c:	03cede93          	srli	t4,t4,0x3c
    1580:	03ce5e13          	srli	t3,t3,0x3c
    1584:	03c8d893          	srli	a7,a7,0x3c
    1588:	03c85813          	srli	a6,a6,0x3c
    158c:	9171                	srli	a0,a0,0x3c
    158e:	91f1                	srli	a1,a1,0x3c
    1590:	9271                	srli	a2,a2,0x3c
    1592:	92f1                	srli	a3,a3,0x3c
    1594:	95be                	add	a1,a1,a5
    1596:	963e                	add	a2,a2,a5
    1598:	96be                	add	a3,a3,a5
    159a:	943e                	add	s0,s0,a5
    159c:	93be                	add	t2,t2,a5
    159e:	92be                	add	t0,t0,a5
    15a0:	9fbe                	add	t6,t6,a5
    15a2:	9f3e                	add	t5,t5,a5
    15a4:	9ebe                	add	t4,t4,a5
    15a6:	9e3e                	add	t3,t3,a5
    15a8:	98be                	add	a7,a7,a5
    15aa:	933e                	add	t1,t1,a5
    15ac:	983e                	add	a6,a6,a5
    15ae:	953e                	add	a0,a0,a5
    15b0:	0005c983          	lbu	s3,0(a1)
    15b4:	00044403          	lbu	s0,0(s0)
    15b8:	00064583          	lbu	a1,0(a2)
    15bc:	0003c383          	lbu	t2,0(t2)
    15c0:	0006c603          	lbu	a2,0(a3)
    15c4:	0002c283          	lbu	t0,0(t0)
    15c8:	000fcf83          	lbu	t6,0(t6)
    15cc:	000f4f03          	lbu	t5,0(t5)
    15d0:	000ece83          	lbu	t4,0(t4)
    15d4:	000e4e03          	lbu	t3,0(t3)
    15d8:	0008c883          	lbu	a7,0(a7)
    15dc:	00034303          	lbu	t1,0(t1)
    15e0:	00084803          	lbu	a6,0(a6)
    15e4:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    15e8:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    15ec:	92f1                	srli	a3,a3,0x3c
    15ee:	8b3d                	andi	a4,a4,15
    15f0:	96be                	add	a3,a3,a5
    15f2:	97ba                	add	a5,a5,a4
    15f4:	00810d23          	sb	s0,26(sp)
    15f8:	00710da3          	sb	t2,27(sp)
    15fc:	00510e23          	sb	t0,28(sp)
    1600:	01f10ea3          	sb	t6,29(sp)
    1604:	01e10f23          	sb	t5,30(sp)
    1608:	01d10fa3          	sb	t4,31(sp)
    160c:	03c10023          	sb	t3,32(sp)
    1610:	031100a3          	sb	a7,33(sp)
    1614:	02610123          	sb	t1,34(sp)
    1618:	030101a3          	sb	a6,35(sp)
    161c:	02a10223          	sb	a0,36(sp)
    1620:	033102a3          	sb	s3,37(sp)
    1624:	02b10323          	sb	a1,38(sp)
    1628:	02c103a3          	sb	a2,39(sp)
    162c:	0006c683          	lbu	a3,0(a3)
    1630:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    1634:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1638:	02d10423          	sb	a3,40(sp)
    163c:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1640:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    1644:	11578263          	beq	a5,s5,1748 <printf+0x2b6>
		len = out_unlocked(s, l);
    1648:	45c9                	li	a1,18
    164a:	0828                	addi	a0,sp,24
    164c:	2d2000ef          	jal	ra,191e <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1650:	00248993          	addi	s3,s1,2
		if (!*s)
    1654:	0009c783          	lbu	a5,0(s3)
    1658:	e6079ee3          	bnez	a5,14d4 <printf+0x42>
	}
	va_end(ap);
    165c:	70e6                	ld	ra,120(sp)
    165e:	7446                	ld	s0,112(sp)
    1660:	74a6                	ld	s1,104(sp)
    1662:	7906                	ld	s2,96(sp)
    1664:	69e6                	ld	s3,88(sp)
    1666:	6a46                	ld	s4,80(sp)
    1668:	6aa6                	ld	s5,72(sp)
    166a:	6b06                	ld	s6,64(sp)
    166c:	6129                	addi	sp,sp,192
    166e:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1670:	0005c783          	lbu	a5,0(a1)
    1674:	84ae                	mv	s1,a1
    1676:	01278963          	beq	a5,s2,1688 <printf+0x1f6>
    167a:	b5ad                	j	14e4 <printf+0x52>
    167c:	0024c783          	lbu	a5,2(s1)
    1680:	0585                	addi	a1,a1,1
    1682:	0489                	addi	s1,s1,2
    1684:	e72790e3          	bne	a5,s2,14e4 <printf+0x52>
    1688:	0014c783          	lbu	a5,1(s1)
    168c:	ff2788e3          	beq	a5,s2,167c <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    1690:	108a2783          	lw	a5,264(s4)
		l = z - a;
    1694:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1698:	e5579ce3          	bne	a5,s5,14f0 <printf+0x5e>
		mutex_lock(buffer_lock);
    169c:	10ca2503          	lw	a0,268(s4)
    16a0:	c41ff0ef          	jal	ra,12e0 <mutex_lock>
		len = out_unlocked(s, l);
    16a4:	85a2                	mv	a1,s0
    16a6:	854e                	mv	a0,s3
    16a8:	276000ef          	jal	ra,191e <out_unlocked>
		mutex_unlock(buffer_lock);
    16ac:	10ca2503          	lw	a0,268(s4)
    16b0:	c3dff0ef          	jal	ra,12ec <mutex_unlock>
		if (l)
    16b4:	e40404e3          	beqz	s0,14fc <printf+0x6a>
    16b8:	89a6                	mv	s3,s1
    16ba:	bd09                	j	14cc <printf+0x3a>
		switch (s[1]) {
    16bc:	07800713          	li	a4,120
    16c0:	04e79363          	bne	a5,a4,1706 <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    16c4:	67c2                	ld	a5,16(sp)
    16c6:	45c1                	li	a1,16
		s += 2;
    16c8:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    16cc:	4388                	lw	a0,0(a5)
    16ce:	07a1                	addi	a5,a5,8
    16d0:	e83e                	sd	a5,16(sp)
    16d2:	5f8000ef          	jal	ra,1cca <printint.constprop.0>
		s += 2;
    16d6:	bfbd                	j	1654 <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    16d8:	67c2                	ld	a5,16(sp)
    16da:	6380                	ld	s0,0(a5)
    16dc:	07a1                	addi	a5,a5,8
    16de:	e83e                	sd	a5,16(sp)
    16e0:	1c040163          	beqz	s0,18a2 <printf+0x410>
			l = strnlen(a, 200);
    16e4:	0c800593          	li	a1,200
    16e8:	8522                	mv	a0,s0
    16ea:	3f7000ef          	jal	ra,22e0 <strnlen>
	if (buffer_lock_enabled == 1) {
    16ee:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    16f2:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    16f6:	19578663          	beq	a5,s5,1882 <printf+0x3f0>
		len = out_unlocked(s, l);
    16fa:	8522                	mv	a0,s0
    16fc:	222000ef          	jal	ra,191e <out_unlocked>
		s += 2;
    1700:	00248993          	addi	s3,s1,2
    1704:	bf81                	j	1654 <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    1706:	108a2783          	lw	a5,264(s4)
	char byte = c;
    170a:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    170e:	0f578663          	beq	a5,s5,17fa <printf+0x368>
		len = out_unlocked(s, l);
    1712:	0828                	addi	a0,sp,24
    1714:	316000ef          	jal	ra,1a2a <out_unlocked.constprop.0>
			putchar(s[1]);
    1718:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    171c:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1720:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    1724:	05578163          	beq	a5,s5,1766 <printf+0x2d4>
		len = out_unlocked(s, l);
    1728:	0828                	addi	a0,sp,24
    172a:	300000ef          	jal	ra,1a2a <out_unlocked.constprop.0>
		s += 2;
    172e:	00248993          	addi	s3,s1,2
    1732:	b70d                	j	1654 <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    1734:	67c2                	ld	a5,16(sp)
    1736:	45a9                	li	a1,10
		s += 2;
    1738:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    173c:	4388                	lw	a0,0(a5)
    173e:	07a1                	addi	a5,a5,8
    1740:	e83e                	sd	a5,16(sp)
    1742:	588000ef          	jal	ra,1cca <printint.constprop.0>
		s += 2;
    1746:	b739                	j	1654 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1748:	10ca2503          	lw	a0,268(s4)
		s += 2;
    174c:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1750:	b91ff0ef          	jal	ra,12e0 <mutex_lock>
		len = out_unlocked(s, l);
    1754:	45c9                	li	a1,18
    1756:	0828                	addi	a0,sp,24
    1758:	1c6000ef          	jal	ra,191e <out_unlocked>
		mutex_unlock(buffer_lock);
    175c:	10ca2503          	lw	a0,268(s4)
    1760:	b8dff0ef          	jal	ra,12ec <mutex_unlock>
		s += 2;
    1764:	bdc5                	j	1654 <printf+0x1c2>
		mutex_lock(buffer_lock);
    1766:	10ca2503          	lw	a0,268(s4)
    176a:	b77ff0ef          	jal	ra,12e0 <mutex_lock>
		buffer[buffer_len++] = c;
    176e:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1772:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1776:	0017861b          	addiw	a2,a5,1
    177a:	97d2                	add	a5,a5,s4
    177c:	00ca2023          	sw	a2,0(s4)
    1780:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1784:	00c6cc63          	blt	a3,a2,179c <printf+0x30a>
    1788:	47a9                	li	a5,10
    178a:	06f40663          	beq	s0,a5,17f6 <printf+0x364>
		mutex_unlock(buffer_lock);
    178e:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1792:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    1796:	b57ff0ef          	jal	ra,12ec <mutex_unlock>
		s += 2;
    179a:	bd6d                	j	1654 <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    179c:	10000793          	li	a5,256
    17a0:	00f61e63          	bne	a2,a5,17bc <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    17a4:	00001597          	auipc	a1,0x1
    17a8:	fd458593          	addi	a1,a1,-44 # 2778 <buffer>
    17ac:	4505                	li	a0,1
    17ae:	8bbff0ef          	jal	ra,1068 <write>
	buffer_len = 0;
    17b2:	00001797          	auipc	a5,0x1
    17b6:	fa07af23          	sw	zero,-66(a5) # 2770 <buffer_len>
			if (r < 0) {
    17ba:	bfd1                	j	178e <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    17bc:	8b7ff0ef          	jal	ra,1072 <getpid>
    17c0:	842a                	mv	s0,a0
    17c2:	00001517          	auipc	a0,0x1
    17c6:	eb650513          	addi	a0,a0,-330 # 2678 <basename+0xde>
    17ca:	5d1000ef          	jal	ra,259a <basename>
    17ce:	872a                	mv	a4,a0
    17d0:	00001617          	auipc	a2,0x1
    17d4:	ee860613          	addi	a2,a2,-280 # 26b8 <basename+0x11e>
    17d8:	05400793          	li	a5,84
    17dc:	86a2                	mv	a3,s0
    17de:	45fd                	li	a1,31
    17e0:	00001517          	auipc	a0,0x1
    17e4:	ee050513          	addi	a0,a0,-288 # 26c0 <basename+0x126>
    17e8:	cabff0ef          	jal	ra,1492 <printf>
    17ec:	557d                	li	a0,-1
    17ee:	8b5ff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    17f2:	000a2603          	lw	a2,0(s4)
    17f6:	de41                	beqz	a2,178e <printf+0x2fc>
    17f8:	b775                	j	17a4 <printf+0x312>
		mutex_lock(buffer_lock);
    17fa:	10ca2503          	lw	a0,268(s4)
    17fe:	ae3ff0ef          	jal	ra,12e0 <mutex_lock>
		buffer[buffer_len++] = c;
    1802:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1806:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    180a:	0017861b          	addiw	a2,a5,1
    180e:	97d2                	add	a5,a5,s4
    1810:	00ca2023          	sw	a2,0(s4)
    1814:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1818:	02c6d163          	bge	a3,a2,183a <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    181c:	10000793          	li	a5,256
    1820:	02f61263          	bne	a2,a5,1844 <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    1824:	00001597          	auipc	a1,0x1
    1828:	f5458593          	addi	a1,a1,-172 # 2778 <buffer>
    182c:	4505                	li	a0,1
    182e:	83bff0ef          	jal	ra,1068 <write>
	buffer_len = 0;
    1832:	00001797          	auipc	a5,0x1
    1836:	f207af23          	sw	zero,-194(a5) # 2770 <buffer_len>
		mutex_unlock(buffer_lock);
    183a:	10ca2503          	lw	a0,268(s4)
    183e:	aafff0ef          	jal	ra,12ec <mutex_unlock>
    1842:	bdd9                	j	1718 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    1844:	82fff0ef          	jal	ra,1072 <getpid>
    1848:	842a                	mv	s0,a0
    184a:	00001517          	auipc	a0,0x1
    184e:	e2e50513          	addi	a0,a0,-466 # 2678 <basename+0xde>
    1852:	549000ef          	jal	ra,259a <basename>
    1856:	872a                	mv	a4,a0
    1858:	00001617          	auipc	a2,0x1
    185c:	e6060613          	addi	a2,a2,-416 # 26b8 <basename+0x11e>
    1860:	05400793          	li	a5,84
    1864:	86a2                	mv	a3,s0
    1866:	45fd                	li	a1,31
    1868:	00001517          	auipc	a0,0x1
    186c:	e5850513          	addi	a0,a0,-424 # 26c0 <basename+0x126>
    1870:	c23ff0ef          	jal	ra,1492 <printf>
    1874:	557d                	li	a0,-1
    1876:	82dff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    187a:	000a2603          	lw	a2,0(s4)
    187e:	de55                	beqz	a2,183a <printf+0x3a8>
    1880:	b755                	j	1824 <printf+0x392>
		mutex_lock(buffer_lock);
    1882:	10ca2503          	lw	a0,268(s4)
    1886:	e42e                	sd	a1,8(sp)
		s += 2;
    1888:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    188c:	a55ff0ef          	jal	ra,12e0 <mutex_lock>
		len = out_unlocked(s, l);
    1890:	65a2                	ld	a1,8(sp)
    1892:	8522                	mv	a0,s0
    1894:	08a000ef          	jal	ra,191e <out_unlocked>
		mutex_unlock(buffer_lock);
    1898:	10ca2503          	lw	a0,268(s4)
    189c:	a51ff0ef          	jal	ra,12ec <mutex_unlock>
		s += 2;
    18a0:	bb55                	j	1654 <printf+0x1c2>
				a = "(null)";
    18a2:	00001417          	auipc	s0,0x1
    18a6:	dce40413          	addi	s0,s0,-562 # 2670 <basename+0xd6>
    18aa:	bd2d                	j	16e4 <printf+0x252>

00000000000018ac <enable_thread_io_buffer>:
{
    18ac:	1101                	addi	sp,sp,-32
    18ae:	e822                	sd	s0,16(sp)
    18b0:	ec06                	sd	ra,24(sp)
    18b2:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    18b4:	00001417          	auipc	s0,0x1
    18b8:	ebc40413          	addi	s0,s0,-324 # 2770 <buffer_len>
    18bc:	a09ff0ef          	jal	ra,12c4 <mutex_create>
    18c0:	10a42623          	sw	a0,268(s0)
    18c4:	00054a63          	bltz	a0,18d8 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    18c8:	4785                	li	a5,1
}
    18ca:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    18cc:	10f42423          	sw	a5,264(s0)
}
    18d0:	6442                	ld	s0,16(sp)
    18d2:	64a2                	ld	s1,8(sp)
    18d4:	6105                	addi	sp,sp,32
    18d6:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    18d8:	f9aff0ef          	jal	ra,1072 <getpid>
    18dc:	84aa                	mv	s1,a0
    18de:	00001517          	auipc	a0,0x1
    18e2:	d9a50513          	addi	a0,a0,-614 # 2678 <basename+0xde>
    18e6:	4b5000ef          	jal	ra,259a <basename>
    18ea:	872a                	mv	a4,a0
    18ec:	04800793          	li	a5,72
    18f0:	86a6                	mv	a3,s1
    18f2:	00001517          	auipc	a0,0x1
    18f6:	e0e50513          	addi	a0,a0,-498 # 2700 <basename+0x166>
    18fa:	00001617          	auipc	a2,0x1
    18fe:	dbe60613          	addi	a2,a2,-578 # 26b8 <basename+0x11e>
    1902:	45fd                	li	a1,31
    1904:	b8fff0ef          	jal	ra,1492 <printf>
    1908:	557d                	li	a0,-1
    190a:	f98ff0ef          	jal	ra,10a2 <exit>
	buffer_lock_enabled = 1;
    190e:	4785                	li	a5,1
}
    1910:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    1912:	10f42423          	sw	a5,264(s0)
}
    1916:	6442                	ld	s0,16(sp)
    1918:	64a2                	ld	s1,8(sp)
    191a:	6105                	addi	sp,sp,32
    191c:	8082                	ret

000000000000191e <out_unlocked>:
{
    191e:	7159                	addi	sp,sp,-112
    1920:	f486                	sd	ra,104(sp)
    1922:	f0a2                	sd	s0,96(sp)
    1924:	eca6                	sd	s1,88(sp)
    1926:	e8ca                	sd	s2,80(sp)
    1928:	e4ce                	sd	s3,72(sp)
    192a:	e0d2                	sd	s4,64(sp)
    192c:	fc56                	sd	s5,56(sp)
    192e:	f85a                	sd	s6,48(sp)
    1930:	f45e                	sd	s7,40(sp)
    1932:	f062                	sd	s8,32(sp)
    1934:	ec66                	sd	s9,24(sp)
    1936:	e86a                	sd	s10,16(sp)
    1938:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    193a:	0e058663          	beqz	a1,1a26 <out_unlocked+0x108>
    193e:	842a                	mv	s0,a0
    1940:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    1944:	4981                	li	s3,0
    1946:	00001d17          	auipc	s10,0x1
    194a:	e2ad0d13          	addi	s10,s10,-470 # 2770 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    194e:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    1952:	00001b17          	auipc	s6,0x1
    1956:	e26b0b13          	addi	s6,s6,-474 # 2778 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    195a:	10000a93          	li	s5,256
    195e:	00001c97          	auipc	s9,0x1
    1962:	d1ac8c93          	addi	s9,s9,-742 # 2678 <basename+0xde>
    1966:	00001c17          	auipc	s8,0x1
    196a:	d52c0c13          	addi	s8,s8,-686 # 26b8 <basename+0x11e>
    196e:	00001b97          	auipc	s7,0x1
    1972:	d52b8b93          	addi	s7,s7,-686 # 26c0 <basename+0x126>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1976:	4a29                	li	s4,10
    1978:	a031                	j	1984 <out_unlocked+0x66>
    197a:	09468863          	beq	a3,s4,1a0a <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    197e:	0405                	addi	s0,s0,1
    1980:	04848163          	beq	s1,s0,19c2 <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    1984:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    1988:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    198c:	0017861b          	addiw	a2,a5,1
    1990:	97ea                	add	a5,a5,s10
    1992:	00cd2023          	sw	a2,0(s10)
    1996:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    199a:	fec950e3          	bge	s2,a2,197a <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    199e:	05561263          	bne	a2,s5,19e2 <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    19a2:	85da                	mv	a1,s6
    19a4:	4505                	li	a0,1
    19a6:	ec2ff0ef          	jal	ra,1068 <write>
    19aa:	2501                	sext.w	a0,a0
	buffer_len = 0;
    19ac:	00001797          	auipc	a5,0x1
    19b0:	dc07a223          	sw	zero,-572(a5) # 2770 <buffer_len>
			if (r < 0) {
    19b4:	06054763          	bltz	a0,1a22 <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    19b8:	0405                	addi	s0,s0,1
			ret += r;
    19ba:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    19be:	fc8493e3          	bne	s1,s0,1984 <out_unlocked+0x66>
}
    19c2:	70a6                	ld	ra,104(sp)
    19c4:	7406                	ld	s0,96(sp)
    19c6:	64e6                	ld	s1,88(sp)
    19c8:	6946                	ld	s2,80(sp)
    19ca:	6a06                	ld	s4,64(sp)
    19cc:	7ae2                	ld	s5,56(sp)
    19ce:	7b42                	ld	s6,48(sp)
    19d0:	7ba2                	ld	s7,40(sp)
    19d2:	7c02                	ld	s8,32(sp)
    19d4:	6ce2                	ld	s9,24(sp)
    19d6:	6d42                	ld	s10,16(sp)
    19d8:	6da2                	ld	s11,8(sp)
    19da:	854e                	mv	a0,s3
    19dc:	69a6                	ld	s3,72(sp)
    19de:	6165                	addi	sp,sp,112
    19e0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19e2:	e90ff0ef          	jal	ra,1072 <getpid>
    19e6:	8daa                	mv	s11,a0
    19e8:	8566                	mv	a0,s9
    19ea:	3b1000ef          	jal	ra,259a <basename>
    19ee:	872a                	mv	a4,a0
    19f0:	8662                	mv	a2,s8
    19f2:	05400793          	li	a5,84
    19f6:	86ee                	mv	a3,s11
    19f8:	45fd                	li	a1,31
    19fa:	855e                	mv	a0,s7
    19fc:	a97ff0ef          	jal	ra,1492 <printf>
    1a00:	557d                	li	a0,-1
    1a02:	ea0ff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    1a06:	000d2603          	lw	a2,0(s10)
    1a0a:	da35                	beqz	a2,197e <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1a0c:	85da                	mv	a1,s6
    1a0e:	4505                	li	a0,1
    1a10:	e58ff0ef          	jal	ra,1068 <write>
    1a14:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1a16:	00001797          	auipc	a5,0x1
    1a1a:	d407ad23          	sw	zero,-678(a5) # 2770 <buffer_len>
			if (r < 0) {
    1a1e:	f8055de3          	bgez	a0,19b8 <out_unlocked+0x9a>
    1a22:	89aa                	mv	s3,a0
    1a24:	bf79                	j	19c2 <out_unlocked+0xa4>
	int ret = 0;
    1a26:	4981                	li	s3,0
    1a28:	bf69                	j	19c2 <out_unlocked+0xa4>

0000000000001a2a <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1a2a:	1101                	addi	sp,sp,-32
    1a2c:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1a2e:	00001497          	auipc	s1,0x1
    1a32:	d4248493          	addi	s1,s1,-702 # 2770 <buffer_len>
    1a36:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1a38:	ec06                	sd	ra,24(sp)
    1a3a:	e822                	sd	s0,16(sp)
		char c = s[i];
    1a3c:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1a40:	0017861b          	addiw	a2,a5,1
    1a44:	97a6                	add	a5,a5,s1
    1a46:	00e78423          	sb	a4,8(a5)
    1a4a:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a4c:	0ff00793          	li	a5,255
    1a50:	00c7cc63          	blt	a5,a2,1a68 <out_unlocked.constprop.0+0x3e>
    1a54:	47a9                	li	a5,10
    1a56:	06f70c63          	beq	a4,a5,1ace <out_unlocked.constprop.0+0xa4>
    1a5a:	4601                	li	a2,0
}
    1a5c:	60e2                	ld	ra,24(sp)
    1a5e:	6442                	ld	s0,16(sp)
    1a60:	64a2                	ld	s1,8(sp)
    1a62:	8532                	mv	a0,a2
    1a64:	6105                	addi	sp,sp,32
    1a66:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a68:	10000793          	li	a5,256
    1a6c:	02f61563          	bne	a2,a5,1a96 <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1a70:	00001597          	auipc	a1,0x1
    1a74:	d0858593          	addi	a1,a1,-760 # 2778 <buffer>
    1a78:	4505                	li	a0,1
    1a7a:	deeff0ef          	jal	ra,1068 <write>
}
    1a7e:	60e2                	ld	ra,24(sp)
    1a80:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    1a82:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a86:	00001797          	auipc	a5,0x1
    1a8a:	ce07a523          	sw	zero,-790(a5) # 2770 <buffer_len>
}
    1a8e:	64a2                	ld	s1,8(sp)
    1a90:	8532                	mv	a0,a2
    1a92:	6105                	addi	sp,sp,32
    1a94:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a96:	ddcff0ef          	jal	ra,1072 <getpid>
    1a9a:	842a                	mv	s0,a0
    1a9c:	00001517          	auipc	a0,0x1
    1aa0:	bdc50513          	addi	a0,a0,-1060 # 2678 <basename+0xde>
    1aa4:	2f7000ef          	jal	ra,259a <basename>
    1aa8:	872a                	mv	a4,a0
    1aaa:	00001617          	auipc	a2,0x1
    1aae:	c0e60613          	addi	a2,a2,-1010 # 26b8 <basename+0x11e>
    1ab2:	05400793          	li	a5,84
    1ab6:	86a2                	mv	a3,s0
    1ab8:	45fd                	li	a1,31
    1aba:	00001517          	auipc	a0,0x1
    1abe:	c0650513          	addi	a0,a0,-1018 # 26c0 <basename+0x126>
    1ac2:	9d1ff0ef          	jal	ra,1492 <printf>
    1ac6:	557d                	li	a0,-1
    1ac8:	ddaff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    1acc:	4090                	lw	a2,0(s1)
    1ace:	d659                	beqz	a2,1a5c <out_unlocked.constprop.0+0x32>
    1ad0:	b745                	j	1a70 <out_unlocked.constprop.0+0x46>

0000000000001ad2 <putchar>:
{
    1ad2:	7139                	addi	sp,sp,-64
    1ad4:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    1ad6:	00001497          	auipc	s1,0x1
    1ada:	c9a48493          	addi	s1,s1,-870 # 2770 <buffer_len>
    1ade:	1084a703          	lw	a4,264(s1)
{
    1ae2:	f822                	sd	s0,48(sp)
	char byte = c;
    1ae4:	0ff57413          	zext.b	s0,a0
{
    1ae8:	fc06                	sd	ra,56(sp)
	char byte = c;
    1aea:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1aee:	4785                	li	a5,1
    1af0:	00f70d63          	beq	a4,a5,1b0a <putchar+0x38>
		len = out_unlocked(s, l);
    1af4:	01f10513          	addi	a0,sp,31
    1af8:	f33ff0ef          	jal	ra,1a2a <out_unlocked.constprop.0>
}
    1afc:	70e2                	ld	ra,56(sp)
    1afe:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1b00:	862a                	mv	a2,a0
}
    1b02:	74a2                	ld	s1,40(sp)
    1b04:	8532                	mv	a0,a2
    1b06:	6121                	addi	sp,sp,64
    1b08:	8082                	ret
		mutex_lock(buffer_lock);
    1b0a:	10c4a503          	lw	a0,268(s1)
    1b0e:	fd2ff0ef          	jal	ra,12e0 <mutex_lock>
		buffer[buffer_len++] = c;
    1b12:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b14:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b18:	0017861b          	addiw	a2,a5,1
    1b1c:	97a6                	add	a5,a5,s1
    1b1e:	c090                	sw	a2,0(s1)
    1b20:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b24:	02c6c263          	blt	a3,a2,1b48 <putchar+0x76>
    1b28:	47a9                	li	a5,10
    1b2a:	06f40d63          	beq	s0,a5,1ba4 <putchar+0xd2>
    1b2e:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1b30:	10c4a503          	lw	a0,268(s1)
    1b34:	e432                	sd	a2,8(sp)
    1b36:	fb6ff0ef          	jal	ra,12ec <mutex_unlock>
    1b3a:	6622                	ld	a2,8(sp)
}
    1b3c:	70e2                	ld	ra,56(sp)
    1b3e:	7442                	ld	s0,48(sp)
    1b40:	74a2                	ld	s1,40(sp)
    1b42:	8532                	mv	a0,a2
    1b44:	6121                	addi	sp,sp,64
    1b46:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1b48:	10000793          	li	a5,256
    1b4c:	02f61063          	bne	a2,a5,1b6c <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1b50:	00001597          	auipc	a1,0x1
    1b54:	c2858593          	addi	a1,a1,-984 # 2778 <buffer>
    1b58:	4505                	li	a0,1
    1b5a:	d0eff0ef          	jal	ra,1068 <write>
    1b5e:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1b62:	00001797          	auipc	a5,0x1
    1b66:	c007a723          	sw	zero,-1010(a5) # 2770 <buffer_len>
			if (r < 0) {
    1b6a:	b7d9                	j	1b30 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1b6c:	d06ff0ef          	jal	ra,1072 <getpid>
    1b70:	842a                	mv	s0,a0
    1b72:	00001517          	auipc	a0,0x1
    1b76:	b0650513          	addi	a0,a0,-1274 # 2678 <basename+0xde>
    1b7a:	221000ef          	jal	ra,259a <basename>
    1b7e:	872a                	mv	a4,a0
    1b80:	00001617          	auipc	a2,0x1
    1b84:	b3860613          	addi	a2,a2,-1224 # 26b8 <basename+0x11e>
    1b88:	05400793          	li	a5,84
    1b8c:	86a2                	mv	a3,s0
    1b8e:	45fd                	li	a1,31
    1b90:	00001517          	auipc	a0,0x1
    1b94:	b3050513          	addi	a0,a0,-1232 # 26c0 <basename+0x126>
    1b98:	8fbff0ef          	jal	ra,1492 <printf>
    1b9c:	557d                	li	a0,-1
    1b9e:	d04ff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    1ba2:	4090                	lw	a2,0(s1)
    1ba4:	d651                	beqz	a2,1b30 <putchar+0x5e>
    1ba6:	b76d                	j	1b50 <putchar+0x7e>

0000000000001ba8 <puts>:
{
    1ba8:	7139                	addi	sp,sp,-64
    1baa:	f822                	sd	s0,48(sp)
    1bac:	f426                	sd	s1,40(sp)
    1bae:	fc06                	sd	ra,56(sp)
    1bb0:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1bb2:	00001417          	auipc	s0,0x1
    1bb6:	bbe40413          	addi	s0,s0,-1090 # 2770 <buffer_len>
{
    1bba:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bbc:	638000ef          	jal	ra,21f4 <strlen>
	if (buffer_lock_enabled == 1) {
    1bc0:	10842703          	lw	a4,264(s0)
    1bc4:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bc6:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1bc8:	04f70563          	beq	a4,a5,1c12 <puts+0x6a>
		len = out_unlocked(s, l);
    1bcc:	8526                	mv	a0,s1
    1bce:	d51ff0ef          	jal	ra,191e <out_unlocked>
    1bd2:	892a                	mv	s2,a0
    1bd4:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1bd6:	00095963          	bgez	s2,1be8 <puts+0x40>
}
    1bda:	70e2                	ld	ra,56(sp)
    1bdc:	7442                	ld	s0,48(sp)
    1bde:	7902                	ld	s2,32(sp)
    1be0:	8526                	mv	a0,s1
    1be2:	74a2                	ld	s1,40(sp)
    1be4:	6121                	addi	sp,sp,64
    1be6:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1be8:	10842703          	lw	a4,264(s0)
	char byte = c;
    1bec:	44a9                	li	s1,10
    1bee:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1bf2:	4785                	li	a5,1
    1bf4:	02f70e63          	beq	a4,a5,1c30 <puts+0x88>
		len = out_unlocked(s, l);
    1bf8:	01f10513          	addi	a0,sp,31
    1bfc:	e2fff0ef          	jal	ra,1a2a <out_unlocked.constprop.0>
}
    1c00:	70e2                	ld	ra,56(sp)
    1c02:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1c04:	41f5549b          	sraiw	s1,a0,0x1f
}
    1c08:	7902                	ld	s2,32(sp)
    1c0a:	8526                	mv	a0,s1
    1c0c:	74a2                	ld	s1,40(sp)
    1c0e:	6121                	addi	sp,sp,64
    1c10:	8082                	ret
		mutex_lock(buffer_lock);
    1c12:	e42a                	sd	a0,8(sp)
    1c14:	10c42503          	lw	a0,268(s0)
    1c18:	ec8ff0ef          	jal	ra,12e0 <mutex_lock>
		len = out_unlocked(s, l);
    1c1c:	65a2                	ld	a1,8(sp)
    1c1e:	8526                	mv	a0,s1
    1c20:	cffff0ef          	jal	ra,191e <out_unlocked>
    1c24:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1c26:	10c42503          	lw	a0,268(s0)
    1c2a:	ec2ff0ef          	jal	ra,12ec <mutex_unlock>
    1c2e:	b75d                	j	1bd4 <puts+0x2c>
		mutex_lock(buffer_lock);
    1c30:	10c42503          	lw	a0,268(s0)
    1c34:	eacff0ef          	jal	ra,12e0 <mutex_lock>
		buffer[buffer_len++] = c;
    1c38:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c3a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1c3e:	0017861b          	addiw	a2,a5,1
    1c42:	97a2                	add	a5,a5,s0
    1c44:	c010                	sw	a2,0(s0)
    1c46:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1c4a:	06c6dc63          	bge	a3,a2,1cc2 <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1c4e:	10000793          	li	a5,256
    1c52:	02f61c63          	bne	a2,a5,1c8a <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1c56:	00001597          	auipc	a1,0x1
    1c5a:	b2258593          	addi	a1,a1,-1246 # 2778 <buffer>
    1c5e:	4505                	li	a0,1
    1c60:	c08ff0ef          	jal	ra,1068 <write>
			if (r < 0) {
    1c64:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1c66:	00001797          	auipc	a5,0x1
    1c6a:	b007a523          	sw	zero,-1270(a5) # 2770 <buffer_len>
			if (r < 0) {
    1c6e:	04054c63          	bltz	a0,1cc6 <puts+0x11e>
			if (r < buffer_len) {
    1c72:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1c74:	10c42503          	lw	a0,268(s0)
    1c78:	e74ff0ef          	jal	ra,12ec <mutex_unlock>
}
    1c7c:	70e2                	ld	ra,56(sp)
    1c7e:	7442                	ld	s0,48(sp)
    1c80:	7902                	ld	s2,32(sp)
    1c82:	8526                	mv	a0,s1
    1c84:	74a2                	ld	s1,40(sp)
    1c86:	6121                	addi	sp,sp,64
    1c88:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1c8a:	be8ff0ef          	jal	ra,1072 <getpid>
    1c8e:	84aa                	mv	s1,a0
    1c90:	00001517          	auipc	a0,0x1
    1c94:	9e850513          	addi	a0,a0,-1560 # 2678 <basename+0xde>
    1c98:	103000ef          	jal	ra,259a <basename>
    1c9c:	872a                	mv	a4,a0
    1c9e:	00001617          	auipc	a2,0x1
    1ca2:	a1a60613          	addi	a2,a2,-1510 # 26b8 <basename+0x11e>
    1ca6:	05400793          	li	a5,84
    1caa:	86a6                	mv	a3,s1
    1cac:	45fd                	li	a1,31
    1cae:	00001517          	auipc	a0,0x1
    1cb2:	a1250513          	addi	a0,a0,-1518 # 26c0 <basename+0x126>
    1cb6:	fdcff0ef          	jal	ra,1492 <printf>
    1cba:	557d                	li	a0,-1
    1cbc:	be6ff0ef          	jal	ra,10a2 <exit>
	if (buffer_len == 0)
    1cc0:	4010                	lw	a2,0(s0)
    1cc2:	da45                	beqz	a2,1c72 <puts+0xca>
    1cc4:	bf49                	j	1c56 <puts+0xae>
    1cc6:	54fd                	li	s1,-1
    1cc8:	b775                	j	1c74 <puts+0xcc>

0000000000001cca <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1cca:	715d                	addi	sp,sp,-80
    1ccc:	e486                	sd	ra,72(sp)
    1cce:	e0a2                	sd	s0,64(sp)
    1cd0:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1cd2:	14054363          	bltz	a0,1e18 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1cd6:	02b577bb          	remuw	a5,a0,a1
    1cda:	00001617          	auipc	a2,0x1
    1cde:	ba660613          	addi	a2,a2,-1114 # 2880 <digits>
	buf[16] = 0;
    1ce2:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1ce6:	0005871b          	sext.w	a4,a1
    1cea:	1782                	slli	a5,a5,0x20
    1cec:	9381                	srli	a5,a5,0x20
    1cee:	97b2                	add	a5,a5,a2
    1cf0:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1cf4:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1cf8:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1cfc:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1cfe:	0eb56763          	bltu	a0,a1,1dec <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d02:	02e877bb          	remuw	a5,a6,a4
    1d06:	1782                	slli	a5,a5,0x20
    1d08:	9381                	srli	a5,a5,0x20
    1d0a:	97b2                	add	a5,a5,a2
    1d0c:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d10:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1d14:	02f10323          	sb	a5,38(sp)
    1d18:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1d1a:	0ce86963          	bltu	a6,a4,1dec <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1d1e:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1d22:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1d26:	1582                	slli	a1,a1,0x20
    1d28:	9181                	srli	a1,a1,0x20
    1d2a:	95b2                	add	a1,a1,a2
    1d2c:	0005c583          	lbu	a1,0(a1)
    1d30:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1d34:	0007859b          	sext.w	a1,a5
    1d38:	16e6e563          	bltu	a3,a4,1ea2 <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1d3c:	02e7f6bb          	remuw	a3,a5,a4
    1d40:	1682                	slli	a3,a3,0x20
    1d42:	9281                	srli	a3,a3,0x20
    1d44:	96b2                	add	a3,a3,a2
    1d46:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d4a:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1d4e:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1d52:	16e5e163          	bltu	a1,a4,1eb4 <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1d56:	02e876bb          	remuw	a3,a6,a4
    1d5a:	1682                	slli	a3,a3,0x20
    1d5c:	9281                	srli	a3,a3,0x20
    1d5e:	96b2                	add	a3,a3,a2
    1d60:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d64:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d68:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1d6c:	14e86d63          	bltu	a6,a4,1ec6 <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1d70:	02e5f6bb          	remuw	a3,a1,a4
    1d74:	1682                	slli	a3,a3,0x20
    1d76:	9281                	srli	a3,a3,0x20
    1d78:	96b2                	add	a3,a3,a2
    1d7a:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d7e:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1d82:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1d86:	10e5e563          	bltu	a1,a4,1e90 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1d8a:	02e876bb          	remuw	a3,a6,a4
    1d8e:	1682                	slli	a3,a3,0x20
    1d90:	9281                	srli	a3,a3,0x20
    1d92:	96b2                	add	a3,a3,a2
    1d94:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1d98:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1d9c:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1da0:	14e86263          	bltu	a6,a4,1ee4 <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1da4:	02e5f6bb          	remuw	a3,a1,a4
    1da8:	1682                	slli	a3,a3,0x20
    1daa:	9281                	srli	a3,a3,0x20
    1dac:	96b2                	add	a3,a3,a2
    1dae:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1db2:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1db6:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1dba:	14e5e463          	bltu	a1,a4,1f02 <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1dbe:	02e876bb          	remuw	a3,a6,a4
    1dc2:	1682                	slli	a3,a3,0x20
    1dc4:	9281                	srli	a3,a3,0x20
    1dc6:	96b2                	add	a3,a3,a2
    1dc8:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1dcc:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1dd0:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1dd4:	14e86063          	bltu	a6,a4,1f14 <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1dd8:	1782                	slli	a5,a5,0x20
    1dda:	9381                	srli	a5,a5,0x20
    1ddc:	97b2                	add	a5,a5,a2
    1dde:	0007c703          	lbu	a4,0(a5)
    1de2:	4799                	li	a5,6
    1de4:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1de8:	10054763          	bltz	a0,1ef6 <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1dec:	00001497          	auipc	s1,0x1
    1df0:	98448493          	addi	s1,s1,-1660 # 2770 <buffer_len>
    1df4:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1df8:	0828                	addi	a0,sp,24
    1dfa:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1dfc:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1dfe:	00f50433          	add	s0,a0,a5
    1e02:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1e04:	06e68463          	beq	a3,a4,1e6c <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1e08:	8522                	mv	a0,s0
    1e0a:	b15ff0ef          	jal	ra,191e <out_unlocked>
}
    1e0e:	60a6                	ld	ra,72(sp)
    1e10:	6406                	ld	s0,64(sp)
    1e12:	74e2                	ld	s1,56(sp)
    1e14:	6161                	addi	sp,sp,80
    1e16:	8082                	ret
		x = -xx;
    1e18:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1e1c:	02b877bb          	remuw	a5,a6,a1
    1e20:	00001617          	auipc	a2,0x1
    1e24:	a6060613          	addi	a2,a2,-1440 # 2880 <digits>
	buf[16] = 0;
    1e28:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1e2c:	0005871b          	sext.w	a4,a1
    1e30:	1782                	slli	a5,a5,0x20
    1e32:	9381                	srli	a5,a5,0x20
    1e34:	97b2                	add	a5,a5,a2
    1e36:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e3a:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1e3e:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1e42:	08b86b63          	bltu	a6,a1,1ed8 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1e46:	02e8f7bb          	remuw	a5,a7,a4
    1e4a:	1782                	slli	a5,a5,0x20
    1e4c:	9381                	srli	a5,a5,0x20
    1e4e:	97b2                	add	a5,a5,a2
    1e50:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1e54:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1e58:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1e5c:	ece8f1e3          	bgeu	a7,a4,1d1e <printint.constprop.0+0x54>
		buf[i--] = '-';
    1e60:	02d00793          	li	a5,45
    1e64:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1e68:	47b5                	li	a5,13
    1e6a:	b749                	j	1dec <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1e6c:	10c4a503          	lw	a0,268(s1)
    1e70:	e42e                	sd	a1,8(sp)
    1e72:	c6eff0ef          	jal	ra,12e0 <mutex_lock>
		len = out_unlocked(s, l);
    1e76:	65a2                	ld	a1,8(sp)
    1e78:	8522                	mv	a0,s0
    1e7a:	aa5ff0ef          	jal	ra,191e <out_unlocked>
		mutex_unlock(buffer_lock);
    1e7e:	10c4a503          	lw	a0,268(s1)
    1e82:	c6aff0ef          	jal	ra,12ec <mutex_unlock>
}
    1e86:	60a6                	ld	ra,72(sp)
    1e88:	6406                	ld	s0,64(sp)
    1e8a:	74e2                	ld	s1,56(sp)
    1e8c:	6161                	addi	sp,sp,80
    1e8e:	8082                	ret
		buf[i--] = digits[x % base];
    1e90:	47a9                	li	a5,10
	if (sign)
    1e92:	f4055de3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e96:	02d00793          	li	a5,45
    1e9a:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1e9e:	47a5                	li	a5,9
    1ea0:	b7b1                	j	1dec <printint.constprop.0+0x122>
    1ea2:	47b5                	li	a5,13
	if (sign)
    1ea4:	f40554e3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ea8:	02d00793          	li	a5,45
    1eac:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1eb0:	47b1                	li	a5,12
    1eb2:	bf2d                	j	1dec <printint.constprop.0+0x122>
    1eb4:	47b1                	li	a5,12
	if (sign)
    1eb6:	f2055be3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eba:	02d00793          	li	a5,45
    1ebe:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1ec2:	47ad                	li	a5,11
    1ec4:	b725                	j	1dec <printint.constprop.0+0x122>
    1ec6:	47ad                	li	a5,11
	if (sign)
    1ec8:	f20552e3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ecc:	02d00793          	li	a5,45
    1ed0:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1ed4:	47a9                	li	a5,10
    1ed6:	bf19                	j	1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ed8:	02d00793          	li	a5,45
    1edc:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1ee0:	47b9                	li	a5,14
    1ee2:	b729                	j	1dec <printint.constprop.0+0x122>
    1ee4:	47a5                	li	a5,9
	if (sign)
    1ee6:	f00553e3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1eea:	02d00793          	li	a5,45
    1eee:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1ef2:	47a1                	li	a5,8
    1ef4:	bde5                	j	1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1ef6:	02d00793          	li	a5,45
    1efa:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1efe:	4795                	li	a5,5
    1f00:	b5f5                	j	1dec <printint.constprop.0+0x122>
    1f02:	47a1                	li	a5,8
	if (sign)
    1f04:	ee0554e3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f08:	02d00793          	li	a5,45
    1f0c:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1f10:	479d                	li	a5,7
    1f12:	bde9                	j	1dec <printint.constprop.0+0x122>
    1f14:	479d                	li	a5,7
	if (sign)
    1f16:	ec055be3          	bgez	a0,1dec <printint.constprop.0+0x122>
		buf[i--] = '-';
    1f1a:	02d00793          	li	a5,45
    1f1e:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1f22:	4799                	li	a5,6
    1f24:	b5e1                	j	1dec <printint.constprop.0+0x122>

0000000000001f26 <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f26:	02000793          	li	a5,32
    1f2a:	00f50663          	beq	a0,a5,1f36 <isspace+0x10>
    1f2e:	355d                	addiw	a0,a0,-9
    1f30:	00553513          	sltiu	a0,a0,5
    1f34:	8082                	ret
    1f36:	4505                	li	a0,1
}
    1f38:	8082                	ret

0000000000001f3a <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1f3a:	fd05051b          	addiw	a0,a0,-48
}
    1f3e:	00a53513          	sltiu	a0,a0,10
    1f42:	8082                	ret

0000000000001f44 <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f44:	02000613          	li	a2,32
    1f48:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1f4a:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1f4e:	ff77869b          	addiw	a3,a5,-9
    1f52:	04c78c63          	beq	a5,a2,1faa <atoi+0x66>
    1f56:	0007871b          	sext.w	a4,a5
    1f5a:	04d5f863          	bgeu	a1,a3,1faa <atoi+0x66>
		s++;
	switch (*s) {
    1f5e:	02b00693          	li	a3,43
    1f62:	04d78963          	beq	a5,a3,1fb4 <atoi+0x70>
    1f66:	02d00693          	li	a3,45
    1f6a:	06d78263          	beq	a5,a3,1fce <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1f6e:	fd07061b          	addiw	a2,a4,-48
    1f72:	47a5                	li	a5,9
    1f74:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1f76:	4e01                	li	t3,0
	while (isdigit(*s))
    1f78:	04c7e963          	bltu	a5,a2,1fca <atoi+0x86>
	int n = 0, neg = 0;
    1f7c:	4501                	li	a0,0
	while (isdigit(*s))
    1f7e:	4825                	li	a6,9
    1f80:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1f84:	0025179b          	slliw	a5,a0,0x2
    1f88:	9fa9                	addw	a5,a5,a0
    1f8a:	fd07031b          	addiw	t1,a4,-48
    1f8e:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1f92:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1f96:	0685                	addi	a3,a3,1
    1f98:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1f9c:	0006071b          	sext.w	a4,a2
    1fa0:	feb870e3          	bgeu	a6,a1,1f80 <atoi+0x3c>
	return neg ? n : -n;
    1fa4:	000e0563          	beqz	t3,1fae <atoi+0x6a>
}
    1fa8:	8082                	ret
		s++;
    1faa:	0505                	addi	a0,a0,1
    1fac:	bf79                	j	1f4a <atoi+0x6>
	return neg ? n : -n;
    1fae:	4113053b          	subw	a0,t1,a7
    1fb2:	8082                	ret
	while (isdigit(*s))
    1fb4:	00154703          	lbu	a4,1(a0)
    1fb8:	47a5                	li	a5,9
		s++;
    1fba:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fbe:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1fc2:	4e01                	li	t3,0
	while (isdigit(*s))
    1fc4:	2701                	sext.w	a4,a4
    1fc6:	fac7fbe3          	bgeu	a5,a2,1f7c <atoi+0x38>
    1fca:	4501                	li	a0,0
}
    1fcc:	8082                	ret
	while (isdigit(*s))
    1fce:	00154703          	lbu	a4,1(a0)
    1fd2:	47a5                	li	a5,9
		s++;
    1fd4:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1fd8:	fd07061b          	addiw	a2,a4,-48
    1fdc:	2701                	sext.w	a4,a4
    1fde:	fec7e6e3          	bltu	a5,a2,1fca <atoi+0x86>
		neg = 1;
    1fe2:	4e05                	li	t3,1
    1fe4:	bf61                	j	1f7c <atoi+0x38>

0000000000001fe6 <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1fe6:	16060d63          	beqz	a2,2160 <memset+0x17a>
    1fea:	40a007b3          	neg	a5,a0
    1fee:	8b9d                	andi	a5,a5,7
    1ff0:	00778693          	addi	a3,a5,7
    1ff4:	482d                	li	a6,11
    1ff6:	0ff5f713          	zext.b	a4,a1
    1ffa:	fff60593          	addi	a1,a2,-1
    1ffe:	1706e263          	bltu	a3,a6,2162 <memset+0x17c>
    2002:	16d5ea63          	bltu	a1,a3,2176 <memset+0x190>
    2006:	16078563          	beqz	a5,2170 <memset+0x18a>
    200a:	00e50023          	sb	a4,0(a0)
    200e:	4685                	li	a3,1
    2010:	00150593          	addi	a1,a0,1
    2014:	14d78c63          	beq	a5,a3,216c <memset+0x186>
    2018:	00e500a3          	sb	a4,1(a0)
    201c:	4689                	li	a3,2
    201e:	00250593          	addi	a1,a0,2
    2022:	14d78d63          	beq	a5,a3,217c <memset+0x196>
    2026:	00e50123          	sb	a4,2(a0)
    202a:	468d                	li	a3,3
    202c:	00350593          	addi	a1,a0,3
    2030:	12d78b63          	beq	a5,a3,2166 <memset+0x180>
    2034:	00e501a3          	sb	a4,3(a0)
    2038:	4691                	li	a3,4
    203a:	00450593          	addi	a1,a0,4
    203e:	14d78163          	beq	a5,a3,2180 <memset+0x19a>
    2042:	00e50223          	sb	a4,4(a0)
    2046:	4695                	li	a3,5
    2048:	00550593          	addi	a1,a0,5
    204c:	12d78c63          	beq	a5,a3,2184 <memset+0x19e>
    2050:	00e502a3          	sb	a4,5(a0)
    2054:	469d                	li	a3,7
    2056:	00650593          	addi	a1,a0,6
    205a:	12d79763          	bne	a5,a3,2188 <memset+0x1a2>
    205e:	00750593          	addi	a1,a0,7
    2062:	00e50323          	sb	a4,6(a0)
    2066:	481d                	li	a6,7
    2068:	00871693          	slli	a3,a4,0x8
    206c:	01071893          	slli	a7,a4,0x10
    2070:	8ed9                	or	a3,a3,a4
    2072:	01871313          	slli	t1,a4,0x18
    2076:	0116e6b3          	or	a3,a3,a7
    207a:	0066e6b3          	or	a3,a3,t1
    207e:	02071893          	slli	a7,a4,0x20
    2082:	02871e13          	slli	t3,a4,0x28
    2086:	0116e6b3          	or	a3,a3,a7
    208a:	40f60333          	sub	t1,a2,a5
    208e:	03071893          	slli	a7,a4,0x30
    2092:	01c6e6b3          	or	a3,a3,t3
    2096:	0116e6b3          	or	a3,a3,a7
    209a:	03871e13          	slli	t3,a4,0x38
    209e:	97aa                	add	a5,a5,a0
    20a0:	ff837893          	andi	a7,t1,-8
    20a4:	01c6e6b3          	or	a3,a3,t3
    20a8:	98be                	add	a7,a7,a5
    20aa:	e394                	sd	a3,0(a5)
    20ac:	07a1                	addi	a5,a5,8
    20ae:	ff179ee3          	bne	a5,a7,20aa <memset+0xc4>
    20b2:	ff837893          	andi	a7,t1,-8
    20b6:	011587b3          	add	a5,a1,a7
    20ba:	010886bb          	addw	a3,a7,a6
    20be:	0b130663          	beq	t1,a7,216a <memset+0x184>
    20c2:	00e78023          	sb	a4,0(a5)
    20c6:	0016859b          	addiw	a1,a3,1
    20ca:	08c5fb63          	bgeu	a1,a2,2160 <memset+0x17a>
    20ce:	00e780a3          	sb	a4,1(a5)
    20d2:	0026859b          	addiw	a1,a3,2
    20d6:	08c5f563          	bgeu	a1,a2,2160 <memset+0x17a>
    20da:	00e78123          	sb	a4,2(a5)
    20de:	0036859b          	addiw	a1,a3,3
    20e2:	06c5ff63          	bgeu	a1,a2,2160 <memset+0x17a>
    20e6:	00e781a3          	sb	a4,3(a5)
    20ea:	0046859b          	addiw	a1,a3,4
    20ee:	06c5f963          	bgeu	a1,a2,2160 <memset+0x17a>
    20f2:	00e78223          	sb	a4,4(a5)
    20f6:	0056859b          	addiw	a1,a3,5
    20fa:	06c5f363          	bgeu	a1,a2,2160 <memset+0x17a>
    20fe:	00e782a3          	sb	a4,5(a5)
    2102:	0066859b          	addiw	a1,a3,6
    2106:	04c5fd63          	bgeu	a1,a2,2160 <memset+0x17a>
    210a:	00e78323          	sb	a4,6(a5)
    210e:	0076859b          	addiw	a1,a3,7
    2112:	04c5f763          	bgeu	a1,a2,2160 <memset+0x17a>
    2116:	00e783a3          	sb	a4,7(a5)
    211a:	0086859b          	addiw	a1,a3,8
    211e:	04c5f163          	bgeu	a1,a2,2160 <memset+0x17a>
    2122:	00e78423          	sb	a4,8(a5)
    2126:	0096859b          	addiw	a1,a3,9
    212a:	02c5fb63          	bgeu	a1,a2,2160 <memset+0x17a>
    212e:	00e784a3          	sb	a4,9(a5)
    2132:	00a6859b          	addiw	a1,a3,10
    2136:	02c5f563          	bgeu	a1,a2,2160 <memset+0x17a>
    213a:	00e78523          	sb	a4,10(a5)
    213e:	00b6859b          	addiw	a1,a3,11
    2142:	00c5ff63          	bgeu	a1,a2,2160 <memset+0x17a>
    2146:	00e785a3          	sb	a4,11(a5)
    214a:	00c6859b          	addiw	a1,a3,12
    214e:	00c5f963          	bgeu	a1,a2,2160 <memset+0x17a>
    2152:	00e78623          	sb	a4,12(a5)
    2156:	26b5                	addiw	a3,a3,13
    2158:	00c6f463          	bgeu	a3,a2,2160 <memset+0x17a>
    215c:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2160:	8082                	ret
    2162:	46ad                	li	a3,11
    2164:	bd79                	j	2002 <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2166:	480d                	li	a6,3
    2168:	b701                	j	2068 <memset+0x82>
    216a:	8082                	ret
    216c:	4805                	li	a6,1
    216e:	bded                	j	2068 <memset+0x82>
    2170:	85aa                	mv	a1,a0
    2172:	4801                	li	a6,0
    2174:	bdd5                	j	2068 <memset+0x82>
    2176:	87aa                	mv	a5,a0
    2178:	4681                	li	a3,0
    217a:	b7a1                	j	20c2 <memset+0xdc>
    217c:	4809                	li	a6,2
    217e:	b5ed                	j	2068 <memset+0x82>
    2180:	4811                	li	a6,4
    2182:	b5dd                	j	2068 <memset+0x82>
    2184:	4815                	li	a6,5
    2186:	b5cd                	j	2068 <memset+0x82>
    2188:	4819                	li	a6,6
    218a:	bdf9                	j	2068 <memset+0x82>

000000000000218c <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    218c:	00054783          	lbu	a5,0(a0)
    2190:	0005c703          	lbu	a4,0(a1)
    2194:	00e79863          	bne	a5,a4,21a4 <strcmp+0x18>
    2198:	0505                	addi	a0,a0,1
    219a:	0585                	addi	a1,a1,1
    219c:	fbe5                	bnez	a5,218c <strcmp>
    219e:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    21a0:	9d19                	subw	a0,a0,a4
    21a2:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    21a4:	0007851b          	sext.w	a0,a5
    21a8:	bfe5                	j	21a0 <strcmp+0x14>

00000000000021aa <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    21aa:	ca15                	beqz	a2,21de <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21ac:	00054783          	lbu	a5,0(a0)
	if (!n--)
    21b0:	167d                	addi	a2,a2,-1
    21b2:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    21b6:	eb99                	bnez	a5,21cc <strncmp+0x22>
    21b8:	a815                	j	21ec <strncmp+0x42>
    21ba:	00a68e63          	beq	a3,a0,21d6 <strncmp+0x2c>
    21be:	0505                	addi	a0,a0,1
    21c0:	00f71b63          	bne	a4,a5,21d6 <strncmp+0x2c>
    21c4:	00054783          	lbu	a5,0(a0)
    21c8:	cf89                	beqz	a5,21e2 <strncmp+0x38>
    21ca:	85b2                	mv	a1,a2
    21cc:	0005c703          	lbu	a4,0(a1)
    21d0:	00158613          	addi	a2,a1,1
    21d4:	f37d                	bnez	a4,21ba <strncmp+0x10>
		;
	return *l - *r;
    21d6:	0007851b          	sext.w	a0,a5
    21da:	9d19                	subw	a0,a0,a4
    21dc:	8082                	ret
		return 0;
    21de:	4501                	li	a0,0
}
    21e0:	8082                	ret
	return *l - *r;
    21e2:	0015c703          	lbu	a4,1(a1)
    21e6:	4501                	li	a0,0
    21e8:	9d19                	subw	a0,a0,a4
    21ea:	8082                	ret
    21ec:	0005c703          	lbu	a4,0(a1)
    21f0:	4501                	li	a0,0
    21f2:	b7e5                	j	21da <strncmp+0x30>

00000000000021f4 <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    21f4:	00757793          	andi	a5,a0,7
    21f8:	cf89                	beqz	a5,2212 <strlen+0x1e>
    21fa:	87aa                	mv	a5,a0
    21fc:	a029                	j	2206 <strlen+0x12>
    21fe:	0785                	addi	a5,a5,1
    2200:	0077f713          	andi	a4,a5,7
    2204:	cb01                	beqz	a4,2214 <strlen+0x20>
		if (!*s)
    2206:	0007c703          	lbu	a4,0(a5)
    220a:	fb75                	bnez	a4,21fe <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    220c:	40a78533          	sub	a0,a5,a0
}
    2210:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    2212:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    2214:	6394                	ld	a3,0(a5)
    2216:	00000597          	auipc	a1,0x0
    221a:	5425b583          	ld	a1,1346(a1) # 2758 <basename+0x1be>
    221e:	00000617          	auipc	a2,0x0
    2222:	54263603          	ld	a2,1346(a2) # 2760 <basename+0x1c6>
    2226:	a019                	j	222c <strlen+0x38>
    2228:	6794                	ld	a3,8(a5)
    222a:	07a1                	addi	a5,a5,8
    222c:	00b68733          	add	a4,a3,a1
    2230:	fff6c693          	not	a3,a3
    2234:	8f75                	and	a4,a4,a3
    2236:	8f71                	and	a4,a4,a2
    2238:	db65                	beqz	a4,2228 <strlen+0x34>
	for (; *s; s++)
    223a:	0007c703          	lbu	a4,0(a5)
    223e:	d779                	beqz	a4,220c <strlen+0x18>
    2240:	0017c703          	lbu	a4,1(a5)
    2244:	0785                	addi	a5,a5,1
    2246:	d379                	beqz	a4,220c <strlen+0x18>
    2248:	0017c703          	lbu	a4,1(a5)
    224c:	0785                	addi	a5,a5,1
    224e:	fb6d                	bnez	a4,2240 <strlen+0x4c>
    2250:	bf75                	j	220c <strlen+0x18>

0000000000002252 <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2252:	00757713          	andi	a4,a0,7
{
    2256:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2258:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    225c:	cb19                	beqz	a4,2272 <memchr+0x20>
    225e:	ce25                	beqz	a2,22d6 <memchr+0x84>
    2260:	0007c703          	lbu	a4,0(a5)
    2264:	04b70e63          	beq	a4,a1,22c0 <memchr+0x6e>
    2268:	0785                	addi	a5,a5,1
    226a:	0077f713          	andi	a4,a5,7
    226e:	167d                	addi	a2,a2,-1
    2270:	f77d                	bnez	a4,225e <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    2272:	4501                	li	a0,0
	if (n && *s != c) {
    2274:	c235                	beqz	a2,22d8 <memchr+0x86>
    2276:	0007c703          	lbu	a4,0(a5)
    227a:	04b70363          	beq	a4,a1,22c0 <memchr+0x6e>
		size_t k = ONES * c;
    227e:	00000517          	auipc	a0,0x0
    2282:	4ea53503          	ld	a0,1258(a0) # 2768 <basename+0x1ce>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    2286:	471d                	li	a4,7
		size_t k = ONES * c;
    2288:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    228c:	02c77a63          	bgeu	a4,a2,22c0 <memchr+0x6e>
    2290:	00000897          	auipc	a7,0x0
    2294:	4c88b883          	ld	a7,1224(a7) # 2758 <basename+0x1be>
    2298:	00000817          	auipc	a6,0x0
    229c:	4c883803          	ld	a6,1224(a6) # 2760 <basename+0x1c6>
    22a0:	431d                	li	t1,7
    22a2:	a029                	j	22ac <memchr+0x5a>
		     w++, n -= SS)
    22a4:	1661                	addi	a2,a2,-8
    22a6:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    22a8:	02c37963          	bgeu	t1,a2,22da <memchr+0x88>
    22ac:	6398                	ld	a4,0(a5)
    22ae:	8f29                	xor	a4,a4,a0
    22b0:	011706b3          	add	a3,a4,a7
    22b4:	fff74713          	not	a4,a4
    22b8:	8f75                	and	a4,a4,a3
    22ba:	01077733          	and	a4,a4,a6
    22be:	d37d                	beqz	a4,22a4 <memchr+0x52>
{
    22c0:	853e                	mv	a0,a5
    22c2:	97b2                	add	a5,a5,a2
    22c4:	a021                	j	22cc <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    22c6:	0505                	addi	a0,a0,1
    22c8:	00f50763          	beq	a0,a5,22d6 <memchr+0x84>
    22cc:	00054703          	lbu	a4,0(a0)
    22d0:	feb71be3          	bne	a4,a1,22c6 <memchr+0x74>
    22d4:	8082                	ret
	return n ? (void *)s : 0;
    22d6:	4501                	li	a0,0
}
    22d8:	8082                	ret
	return n ? (void *)s : 0;
    22da:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    22dc:	f275                	bnez	a2,22c0 <memchr+0x6e>
}
    22de:	8082                	ret

00000000000022e0 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    22e0:	1101                	addi	sp,sp,-32
    22e2:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    22e4:	862e                	mv	a2,a1
{
    22e6:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    22e8:	4581                	li	a1,0
{
    22ea:	e426                	sd	s1,8(sp)
    22ec:	ec06                	sd	ra,24(sp)
    22ee:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    22f0:	f63ff0ef          	jal	ra,2252 <memchr>
	return p ? p - s : n;
    22f4:	c519                	beqz	a0,2302 <strnlen+0x22>
}
    22f6:	60e2                	ld	ra,24(sp)
    22f8:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    22fa:	8d05                	sub	a0,a0,s1
}
    22fc:	64a2                	ld	s1,8(sp)
    22fe:	6105                	addi	sp,sp,32
    2300:	8082                	ret
    2302:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    2304:	8522                	mv	a0,s0
}
    2306:	6442                	ld	s0,16(sp)
    2308:	64a2                	ld	s1,8(sp)
    230a:	6105                	addi	sp,sp,32
    230c:	8082                	ret

000000000000230e <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    230e:	00a5c7b3          	xor	a5,a1,a0
    2312:	8b9d                	andi	a5,a5,7
    2314:	eb95                	bnez	a5,2348 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    2316:	0075f793          	andi	a5,a1,7
    231a:	e7b1                	bnez	a5,2366 <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    231c:	6198                	ld	a4,0(a1)
    231e:	00000617          	auipc	a2,0x0
    2322:	43a63603          	ld	a2,1082(a2) # 2758 <basename+0x1be>
    2326:	00000817          	auipc	a6,0x0
    232a:	43a83803          	ld	a6,1082(a6) # 2760 <basename+0x1c6>
    232e:	a029                	j	2338 <stpcpy+0x2a>
    2330:	05a1                	addi	a1,a1,8
    2332:	e118                	sd	a4,0(a0)
    2334:	6198                	ld	a4,0(a1)
    2336:	0521                	addi	a0,a0,8
    2338:	00c707b3          	add	a5,a4,a2
    233c:	fff74693          	not	a3,a4
    2340:	8ff5                	and	a5,a5,a3
    2342:	0107f7b3          	and	a5,a5,a6
    2346:	d7ed                	beqz	a5,2330 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2348:	0005c783          	lbu	a5,0(a1)
    234c:	00f50023          	sb	a5,0(a0)
    2350:	c785                	beqz	a5,2378 <stpcpy+0x6a>
    2352:	0015c783          	lbu	a5,1(a1)
    2356:	0505                	addi	a0,a0,1
    2358:	0585                	addi	a1,a1,1
    235a:	00f50023          	sb	a5,0(a0)
    235e:	fbf5                	bnez	a5,2352 <stpcpy+0x44>
		;
	return d;
}
    2360:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    2362:	0505                	addi	a0,a0,1
    2364:	df45                	beqz	a4,231c <stpcpy+0xe>
			if (!(*d = *s))
    2366:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    236a:	0585                	addi	a1,a1,1
    236c:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2370:	00f50023          	sb	a5,0(a0)
    2374:	f7fd                	bnez	a5,2362 <stpcpy+0x54>
}
    2376:	8082                	ret
    2378:	8082                	ret

000000000000237a <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    237a:	00a5c7b3          	xor	a5,a1,a0
    237e:	8b9d                	andi	a5,a5,7
    2380:	1a079863          	bnez	a5,2530 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    2384:	0075f793          	andi	a5,a1,7
    2388:	16078463          	beqz	a5,24f0 <stpncpy+0x176>
    238c:	ea01                	bnez	a2,239c <stpncpy+0x22>
    238e:	a421                	j	2596 <stpncpy+0x21c>
    2390:	167d                	addi	a2,a2,-1
    2392:	0505                	addi	a0,a0,1
    2394:	14070e63          	beqz	a4,24f0 <stpncpy+0x176>
    2398:	1a060863          	beqz	a2,2548 <stpncpy+0x1ce>
    239c:	0005c783          	lbu	a5,0(a1)
    23a0:	0585                	addi	a1,a1,1
    23a2:	0075f713          	andi	a4,a1,7
    23a6:	00f50023          	sb	a5,0(a0)
    23aa:	f3fd                	bnez	a5,2390 <stpncpy+0x16>
    23ac:	4805                	li	a6,1
    23ae:	1a061863          	bnez	a2,255e <stpncpy+0x1e4>
    23b2:	40a007b3          	neg	a5,a0
    23b6:	8b9d                	andi	a5,a5,7
    23b8:	4681                	li	a3,0
    23ba:	18061a63          	bnez	a2,254e <stpncpy+0x1d4>
    23be:	00778713          	addi	a4,a5,7
    23c2:	45ad                	li	a1,11
    23c4:	18b76363          	bltu	a4,a1,254a <stpncpy+0x1d0>
    23c8:	1ae6eb63          	bltu	a3,a4,257e <stpncpy+0x204>
    23cc:	1a078363          	beqz	a5,2572 <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    23d0:	00050023          	sb	zero,0(a0)
    23d4:	4685                	li	a3,1
    23d6:	00150713          	addi	a4,a0,1
    23da:	18d78f63          	beq	a5,a3,2578 <stpncpy+0x1fe>
    23de:	000500a3          	sb	zero,1(a0)
    23e2:	4689                	li	a3,2
    23e4:	00250713          	addi	a4,a0,2
    23e8:	18d78e63          	beq	a5,a3,2584 <stpncpy+0x20a>
    23ec:	00050123          	sb	zero,2(a0)
    23f0:	468d                	li	a3,3
    23f2:	00350713          	addi	a4,a0,3
    23f6:	16d78c63          	beq	a5,a3,256e <stpncpy+0x1f4>
    23fa:	000501a3          	sb	zero,3(a0)
    23fe:	4691                	li	a3,4
    2400:	00450713          	addi	a4,a0,4
    2404:	18d78263          	beq	a5,a3,2588 <stpncpy+0x20e>
    2408:	00050223          	sb	zero,4(a0)
    240c:	4695                	li	a3,5
    240e:	00550713          	addi	a4,a0,5
    2412:	16d78d63          	beq	a5,a3,258c <stpncpy+0x212>
    2416:	000502a3          	sb	zero,5(a0)
    241a:	469d                	li	a3,7
    241c:	00650713          	addi	a4,a0,6
    2420:	16d79863          	bne	a5,a3,2590 <stpncpy+0x216>
    2424:	00750713          	addi	a4,a0,7
    2428:	00050323          	sb	zero,6(a0)
    242c:	40f80833          	sub	a6,a6,a5
    2430:	ff887593          	andi	a1,a6,-8
    2434:	97aa                	add	a5,a5,a0
    2436:	95be                	add	a1,a1,a5
    2438:	0007b023          	sd	zero,0(a5)
    243c:	07a1                	addi	a5,a5,8
    243e:	feb79de3          	bne	a5,a1,2438 <stpncpy+0xbe>
    2442:	ff887593          	andi	a1,a6,-8
    2446:	9ead                	addw	a3,a3,a1
    2448:	00b707b3          	add	a5,a4,a1
    244c:	12b80863          	beq	a6,a1,257c <stpncpy+0x202>
    2450:	00078023          	sb	zero,0(a5)
    2454:	0016871b          	addiw	a4,a3,1
    2458:	0ec77863          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    245c:	000780a3          	sb	zero,1(a5)
    2460:	0026871b          	addiw	a4,a3,2
    2464:	0ec77263          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    2468:	00078123          	sb	zero,2(a5)
    246c:	0036871b          	addiw	a4,a3,3
    2470:	0cc77c63          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    2474:	000781a3          	sb	zero,3(a5)
    2478:	0046871b          	addiw	a4,a3,4
    247c:	0cc77663          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    2480:	00078223          	sb	zero,4(a5)
    2484:	0056871b          	addiw	a4,a3,5
    2488:	0cc77063          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    248c:	000782a3          	sb	zero,5(a5)
    2490:	0066871b          	addiw	a4,a3,6
    2494:	0ac77a63          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    2498:	00078323          	sb	zero,6(a5)
    249c:	0076871b          	addiw	a4,a3,7
    24a0:	0ac77463          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24a4:	000783a3          	sb	zero,7(a5)
    24a8:	0086871b          	addiw	a4,a3,8
    24ac:	08c77e63          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24b0:	00078423          	sb	zero,8(a5)
    24b4:	0096871b          	addiw	a4,a3,9
    24b8:	08c77863          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24bc:	000784a3          	sb	zero,9(a5)
    24c0:	00a6871b          	addiw	a4,a3,10
    24c4:	08c77263          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24c8:	00078523          	sb	zero,10(a5)
    24cc:	00b6871b          	addiw	a4,a3,11
    24d0:	06c77c63          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24d4:	000785a3          	sb	zero,11(a5)
    24d8:	00c6871b          	addiw	a4,a3,12
    24dc:	06c77663          	bgeu	a4,a2,2548 <stpncpy+0x1ce>
    24e0:	00078623          	sb	zero,12(a5)
    24e4:	26b5                	addiw	a3,a3,13
    24e6:	06c6f163          	bgeu	a3,a2,2548 <stpncpy+0x1ce>
    24ea:	000786a3          	sb	zero,13(a5)
    24ee:	8082                	ret
			;
		if (!n || !*s)
    24f0:	c645                	beqz	a2,2598 <stpncpy+0x21e>
    24f2:	0005c783          	lbu	a5,0(a1)
    24f6:	ea078be3          	beqz	a5,23ac <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    24fa:	479d                	li	a5,7
    24fc:	02c7ff63          	bgeu	a5,a2,253a <stpncpy+0x1c0>
    2500:	00000897          	auipc	a7,0x0
    2504:	2588b883          	ld	a7,600(a7) # 2758 <basename+0x1be>
    2508:	00000817          	auipc	a6,0x0
    250c:	25883803          	ld	a6,600(a6) # 2760 <basename+0x1c6>
    2510:	431d                	li	t1,7
    2512:	6198                	ld	a4,0(a1)
    2514:	011707b3          	add	a5,a4,a7
    2518:	fff74693          	not	a3,a4
    251c:	8ff5                	and	a5,a5,a3
    251e:	0107f7b3          	and	a5,a5,a6
    2522:	ef81                	bnez	a5,253a <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    2524:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    2526:	1661                	addi	a2,a2,-8
    2528:	05a1                	addi	a1,a1,8
    252a:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    252c:	fec363e3          	bltu	t1,a2,2512 <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2530:	e609                	bnez	a2,253a <stpncpy+0x1c0>
    2532:	a08d                	j	2594 <stpncpy+0x21a>
    2534:	167d                	addi	a2,a2,-1
    2536:	0505                	addi	a0,a0,1
    2538:	ca01                	beqz	a2,2548 <stpncpy+0x1ce>
    253a:	0005c783          	lbu	a5,0(a1)
    253e:	0585                	addi	a1,a1,1
    2540:	00f50023          	sb	a5,0(a0)
    2544:	fbe5                	bnez	a5,2534 <stpncpy+0x1ba>
		;
tail:
    2546:	b59d                	j	23ac <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2548:	8082                	ret
    254a:	472d                	li	a4,11
    254c:	bdb5                	j	23c8 <stpncpy+0x4e>
    254e:	00778713          	addi	a4,a5,7
    2552:	45ad                	li	a1,11
    2554:	fff60693          	addi	a3,a2,-1
    2558:	e6b778e3          	bgeu	a4,a1,23c8 <stpncpy+0x4e>
    255c:	b7fd                	j	254a <stpncpy+0x1d0>
    255e:	40a007b3          	neg	a5,a0
    2562:	8832                	mv	a6,a2
    2564:	8b9d                	andi	a5,a5,7
    2566:	4681                	li	a3,0
    2568:	e4060be3          	beqz	a2,23be <stpncpy+0x44>
    256c:	b7cd                	j	254e <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    256e:	468d                	li	a3,3
    2570:	bd75                	j	242c <stpncpy+0xb2>
    2572:	872a                	mv	a4,a0
    2574:	4681                	li	a3,0
    2576:	bd5d                	j	242c <stpncpy+0xb2>
    2578:	4685                	li	a3,1
    257a:	bd4d                	j	242c <stpncpy+0xb2>
    257c:	8082                	ret
    257e:	87aa                	mv	a5,a0
    2580:	4681                	li	a3,0
    2582:	b5f9                	j	2450 <stpncpy+0xd6>
    2584:	4689                	li	a3,2
    2586:	b55d                	j	242c <stpncpy+0xb2>
    2588:	4691                	li	a3,4
    258a:	b54d                	j	242c <stpncpy+0xb2>
    258c:	4695                	li	a3,5
    258e:	bd79                	j	242c <stpncpy+0xb2>
    2590:	4699                	li	a3,6
    2592:	bd69                	j	242c <stpncpy+0xb2>
    2594:	8082                	ret
    2596:	8082                	ret
    2598:	8082                	ret

000000000000259a <basename>:

char *basename(char *s)
{
    259a:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    259c:	c54d                	beqz	a0,2646 <basename+0xac>
    259e:	00054783          	lbu	a5,0(a0)
		return ".";
    25a2:	00000517          	auipc	a0,0x0
    25a6:	1ae50513          	addi	a0,a0,430 # 2750 <basename+0x1b6>
	if (!s || !*s)
    25aa:	e391                	bnez	a5,25ae <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    25ac:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    25ae:	0076f713          	andi	a4,a3,7
    25b2:	87b6                	mv	a5,a3
    25b4:	cf51                	beqz	a4,2650 <basename+0xb6>
    25b6:	0785                	addi	a5,a5,1
    25b8:	0077f713          	andi	a4,a5,7
    25bc:	c729                	beqz	a4,2606 <basename+0x6c>
		if (!*s)
    25be:	0007c703          	lbu	a4,0(a5)
    25c2:	fb75                	bnez	a4,25b6 <basename+0x1c>
	return s - a;
    25c4:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    25c6:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    25c8:	cf8d                	beqz	a5,2602 <basename+0x68>
    25ca:	00f68733          	add	a4,a3,a5
    25ce:	02f00593          	li	a1,47
    25d2:	a031                	j	25de <basename+0x44>
		s[i] = 0;
    25d4:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    25d8:	17fd                	addi	a5,a5,-1
    25da:	177d                	addi	a4,a4,-1
    25dc:	c39d                	beqz	a5,2602 <basename+0x68>
    25de:	00074603          	lbu	a2,0(a4)
    25e2:	feb609e3          	beq	a2,a1,25d4 <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    25e6:	02f00613          	li	a2,47
    25ea:	a011                	j	25ee <basename+0x54>
    25ec:	cb99                	beqz	a5,2602 <basename+0x68>
    25ee:	853e                	mv	a0,a5
    25f0:	17fd                	addi	a5,a5,-1
    25f2:	00f68733          	add	a4,a3,a5
    25f6:	00074703          	lbu	a4,0(a4)
    25fa:	fec719e3          	bne	a4,a2,25ec <basename+0x52>
	return s + i;
    25fe:	9536                	add	a0,a0,a3
    2600:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2602:	8536                	mv	a0,a3
    2604:	8082                	ret
    2606:	6390                	ld	a2,0(a5)
    2608:	00000517          	auipc	a0,0x0
    260c:	15053503          	ld	a0,336(a0) # 2758 <basename+0x1be>
    2610:	00000597          	auipc	a1,0x0
    2614:	1505b583          	ld	a1,336(a1) # 2760 <basename+0x1c6>
    2618:	fff64713          	not	a4,a2
    261c:	962a                	add	a2,a2,a0
    261e:	8f71                	and	a4,a4,a2
    2620:	8f6d                	and	a4,a4,a1
    2622:	eb11                	bnez	a4,2636 <basename+0x9c>
    2624:	6790                	ld	a2,8(a5)
    2626:	07a1                	addi	a5,a5,8
    2628:	00a60733          	add	a4,a2,a0
    262c:	fff64613          	not	a2,a2
    2630:	8f71                	and	a4,a4,a2
    2632:	8f6d                	and	a4,a4,a1
    2634:	db65                	beqz	a4,2624 <basename+0x8a>
	for (; *s; s++)
    2636:	0007c703          	lbu	a4,0(a5)
    263a:	d749                	beqz	a4,25c4 <basename+0x2a>
    263c:	0017c703          	lbu	a4,1(a5)
    2640:	0785                	addi	a5,a5,1
    2642:	ff6d                	bnez	a4,263c <basename+0xa2>
    2644:	b741                	j	25c4 <basename+0x2a>
		return ".";
    2646:	00000517          	auipc	a0,0x0
    264a:	10a50513          	addi	a0,a0,266 # 2750 <basename+0x1b6>
    264e:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2650:	6290                	ld	a2,0(a3)
    2652:	00000517          	auipc	a0,0x0
    2656:	10653503          	ld	a0,262(a0) # 2758 <basename+0x1be>
    265a:	00000597          	auipc	a1,0x0
    265e:	1065b583          	ld	a1,262(a1) # 2760 <basename+0x1c6>
    2662:	fff64713          	not	a4,a2
    2666:	962a                	add	a2,a2,a0
    2668:	8f71                	and	a4,a4,a2
    266a:	8f6d                	and	a4,a4,a1
    266c:	df45                	beqz	a4,2624 <basename+0x8a>
    266e:	b7f9                	j	263c <basename+0xa2>
