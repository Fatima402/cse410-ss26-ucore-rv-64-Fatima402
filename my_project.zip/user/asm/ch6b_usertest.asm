
/workspaces/cse410-ss26-ucore-rv-64-Fatima402/user/build/riscv64/ch6b_usertest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000001000 <_start>:
.section .text.entry
.globl _start
_start:
    tail __start_main
    1000:	a485                	j	1260 <__start_main>

0000000000001002 <run_tests>:
#ifndef USER_TEST
#define USER_TEST

int run_tests(const char *tests[], int n)
{
    1002:	7175                	addi	sp,sp,-144
    1004:	e506                	sd	ra,136(sp)
    1006:	e122                	sd	s0,128(sp)
    1008:	fca6                	sd	s1,120(sp)
    100a:	f8ca                	sd	s2,112(sp)
    100c:	f4ce                	sd	s3,104(sp)
    100e:	f0d2                	sd	s4,96(sp)
    1010:	ecd6                	sd	s5,88(sp)
    1012:	e8da                	sd	s6,80(sp)
    1014:	e4de                	sd	s7,72(sp)
    1016:	e0e2                	sd	s8,64(sp)
    1018:	fc66                	sd	s9,56(sp)
    101a:	f86a                	sd	s10,48(sp)
    101c:	f46e                	sd	s11,40(sp)
	int success = 0;
	for (int i = 0; i < n; ++i) {
    101e:	0eb05c63          	blez	a1,1116 <run_tests+0x114>
    1022:	fff58a1b          	addiw	s4,a1,-1
    1026:	020a1793          	slli	a5,s4,0x20
    102a:	01d7da13          	srli	s4,a5,0x1d
    102e:	00850793          	addi	a5,a0,8
    1032:	84aa                	mv	s1,a0
    1034:	9a3e                	add	s4,s4,a5
	int success = 0;
    1036:	4981                	li	s3,0
    1038:	01c10b93          	addi	s7,sp,28
		const char *test = tests[i];
		printf("Usertests: Running %s\n", test);
    103c:	00002b17          	auipc	s6,0x2
    1040:	88cb0b13          	addi	s6,s6,-1908 # 28c8 <enable_deadlock_detect+0xe>
		}
		int xstate = 0;
		int wait_pid = waitpid(pid, &xstate);
		assert_eq(pid, wait_pid);
		success += (xstate == 0);
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1044:	00002a97          	auipc	s5,0x2
    1048:	924a8a93          	addi	s5,s5,-1756 # 2968 <enable_deadlock_detect+0xae>
		assert_eq(pid, wait_pid);
    104c:	00002d17          	auipc	s10,0x2
    1050:	894d0d13          	addi	s10,s10,-1900 # 28e0 <enable_deadlock_detect+0x26>
    1054:	00002c97          	auipc	s9,0x2
    1058:	8d4c8c93          	addi	s9,s9,-1836 # 2928 <enable_deadlock_detect+0x6e>
    105c:	00002c17          	auipc	s8,0x2
    1060:	8d4c0c13          	addi	s8,s8,-1836 # 2930 <enable_deadlock_detect+0x76>
		const char *test = tests[i];
    1064:	0004b903          	ld	s2,0(s1)
		printf("Usertests: Running %s\n", test);
    1068:	855a                	mv	a0,s6
    106a:	85ca                	mv	a1,s2
    106c:	34e000ef          	jal	ra,13ba <printf>
		int pid = fork();
    1070:	5a0010ef          	jal	ra,2610 <fork>
    1074:	842a                	mv	s0,a0
		if (pid == 0) {
    1076:	c941                	beqz	a0,1106 <run_tests+0x104>
		int wait_pid = waitpid(pid, &xstate);
    1078:	85de                	mv	a1,s7
    107a:	8522                	mv	a0,s0
		int xstate = 0;
    107c:	ce02                	sw	zero,28(sp)
		int wait_pid = waitpid(pid, &xstate);
    107e:	5c0010ef          	jal	ra,263e <waitpid>
    1082:	8daa                	mv	s11,a0
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    1084:	8622                	mv	a2,s0
    1086:	85ca                	mv	a1,s2
    1088:	8556                	mv	a0,s5
		assert_eq(pid, wait_pid);
    108a:	07b40363          	beq	s0,s11,10f0 <run_tests+0xee>
    108e:	55e010ef          	jal	ra,25ec <getpid>
    1092:	86aa                	mv	a3,a0
    1094:	856a                	mv	a0,s10
    1096:	e436                	sd	a3,8(sp)
    1098:	42a010ef          	jal	ra,24c2 <basename>
    109c:	66a2                	ld	a3,8(sp)
    109e:	872a                	mv	a4,a0
    10a0:	47c5                	li	a5,17
    10a2:	8666                	mv	a2,s9
    10a4:	45fd                	li	a1,31
    10a6:	88ee                	mv	a7,s11
    10a8:	8822                	mv	a6,s0
    10aa:	8562                	mv	a0,s8
    10ac:	30e000ef          	jal	ra,13ba <printf>
    10b0:	557d                	li	a0,-1
    10b2:	56a010ef          	jal	ra,261c <exit>
		success += (xstate == 0);
    10b6:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10b8:	04a1                	addi	s1,s1,8
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10ba:	8622                	mv	a2,s0
		success += (xstate == 0);
    10bc:	0016b793          	seqz	a5,a3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c0:	85ca                	mv	a1,s2
    10c2:	8556                	mv	a0,s5
		success += (xstate == 0);
    10c4:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10c8:	2f2000ef          	jal	ra,13ba <printf>
	for (int i = 0; i < n; ++i) {
    10cc:	f89a1ce3          	bne	s4,s1,1064 <run_tests+0x62>
		       test, pid, xstate);
	}
	return success;
}
    10d0:	60aa                	ld	ra,136(sp)
    10d2:	640a                	ld	s0,128(sp)
    10d4:	74e6                	ld	s1,120(sp)
    10d6:	7946                	ld	s2,112(sp)
    10d8:	7a06                	ld	s4,96(sp)
    10da:	6ae6                	ld	s5,88(sp)
    10dc:	6b46                	ld	s6,80(sp)
    10de:	6ba6                	ld	s7,72(sp)
    10e0:	6c06                	ld	s8,64(sp)
    10e2:	7ce2                	ld	s9,56(sp)
    10e4:	7d42                	ld	s10,48(sp)
    10e6:	7da2                	ld	s11,40(sp)
    10e8:	854e                	mv	a0,s3
    10ea:	79a6                	ld	s3,104(sp)
    10ec:	6149                	addi	sp,sp,144
    10ee:	8082                	ret
		success += (xstate == 0);
    10f0:	46f2                	lw	a3,28(sp)
	for (int i = 0; i < n; ++i) {
    10f2:	04a1                	addi	s1,s1,8
		success += (xstate == 0);
    10f4:	0016b793          	seqz	a5,a3
    10f8:	013789bb          	addw	s3,a5,s3
		printf("Usertests: Test %s in Process %d exited with code %d\n",
    10fc:	2be000ef          	jal	ra,13ba <printf>
	for (int i = 0; i < n; ++i) {
    1100:	f74492e3          	bne	s1,s4,1064 <run_tests+0x62>
    1104:	b7f1                	j	10d0 <run_tests+0xce>
			exec(test, NULL);
    1106:	4581                	li	a1,0
    1108:	854a                	mv	a0,s2
    110a:	540010ef          	jal	ra,264a <exec>
			exit(-1);
    110e:	557d                	li	a0,-1
    1110:	50c010ef          	jal	ra,261c <exit>
    1114:	b795                	j	1078 <run_tests+0x76>
	int success = 0;
    1116:	4981                	li	s3,0
    1118:	bf65                	j	10d0 <run_tests+0xce>

000000000000111a <test>:

int test(const char *succs[], int nsucc, const char *fails[], int nfail,
	 const char *message)
{
    111a:	7139                	addi	sp,sp,-64
    111c:	f822                	sd	s0,48(sp)
    111e:	f426                	sd	s1,40(sp)
    1120:	ec4e                	sd	s3,24(sp)
    1122:	fc06                	sd	ra,56(sp)
    1124:	f04a                	sd	s2,32(sp)
    1126:	e852                	sd	s4,16(sp)
    1128:	e456                	sd	s5,8(sp)
    112a:	84b2                	mv	s1,a2
    112c:	89b6                	mv	s3,a3
    112e:	843a                	mv	s0,a4
	if (succs && nsucc > 0) {
    1130:	c501                	beqz	a0,1138 <test+0x1e>
    1132:	892e                	mv	s2,a1
    1134:	06b04763          	bgtz	a1,11a2 <test+0x88>
		int succ_count = run_tests(succs, nsucc);
		assert_eq(succ_count, nsucc);
	}
	if (fails && nfail > 0) {
    1138:	c099                	beqz	s1,113e <test+0x24>
    113a:	03304063          	bgtz	s3,115a <test+0x40>
		int fail_count = run_tests(fails, nfail);
		assert_eq(fail_count, 0);
	}
	if (message)
    113e:	c401                	beqz	s0,1146 <test+0x2c>
		puts(message);
    1140:	8522                	mv	a0,s0
    1142:	18f000ef          	jal	ra,1ad0 <puts>
	return 0;
}
    1146:	70e2                	ld	ra,56(sp)
    1148:	7442                	ld	s0,48(sp)
    114a:	74a2                	ld	s1,40(sp)
    114c:	7902                	ld	s2,32(sp)
    114e:	69e2                	ld	s3,24(sp)
    1150:	6a42                	ld	s4,16(sp)
    1152:	6aa2                	ld	s5,8(sp)
    1154:	4501                	li	a0,0
    1156:	6121                	addi	sp,sp,64
    1158:	8082                	ret
		int fail_count = run_tests(fails, nfail);
    115a:	8526                	mv	a0,s1
    115c:	85ce                	mv	a1,s3
    115e:	ea5ff0ef          	jal	ra,1002 <run_tests>
    1162:	84aa                	mv	s1,a0
		assert_eq(fail_count, 0);
    1164:	dd69                	beqz	a0,113e <test+0x24>
    1166:	486010ef          	jal	ra,25ec <getpid>
    116a:	892a                	mv	s2,a0
    116c:	00001517          	auipc	a0,0x1
    1170:	77450513          	addi	a0,a0,1908 # 28e0 <enable_deadlock_detect+0x26>
    1174:	34e010ef          	jal	ra,24c2 <basename>
    1178:	872a                	mv	a4,a0
    117a:	4881                	li	a7,0
    117c:	00001517          	auipc	a0,0x1
    1180:	7b450513          	addi	a0,a0,1972 # 2930 <enable_deadlock_detect+0x76>
    1184:	8826                	mv	a6,s1
    1186:	02200793          	li	a5,34
    118a:	86ca                	mv	a3,s2
    118c:	00001617          	auipc	a2,0x1
    1190:	79c60613          	addi	a2,a2,1948 # 2928 <enable_deadlock_detect+0x6e>
    1194:	45fd                	li	a1,31
    1196:	224000ef          	jal	ra,13ba <printf>
    119a:	557d                	li	a0,-1
    119c:	480010ef          	jal	ra,261c <exit>
    11a0:	bf79                	j	113e <test+0x24>
		int succ_count = run_tests(succs, nsucc);
    11a2:	e61ff0ef          	jal	ra,1002 <run_tests>
    11a6:	8a2a                	mv	s4,a0
		assert_eq(succ_count, nsucc);
    11a8:	f8a908e3          	beq	s2,a0,1138 <test+0x1e>
    11ac:	440010ef          	jal	ra,25ec <getpid>
    11b0:	8aaa                	mv	s5,a0
    11b2:	00001517          	auipc	a0,0x1
    11b6:	72e50513          	addi	a0,a0,1838 # 28e0 <enable_deadlock_detect+0x26>
    11ba:	308010ef          	jal	ra,24c2 <basename>
    11be:	872a                	mv	a4,a0
    11c0:	88ca                	mv	a7,s2
    11c2:	8852                	mv	a6,s4
    11c4:	00001517          	auipc	a0,0x1
    11c8:	76c50513          	addi	a0,a0,1900 # 2930 <enable_deadlock_detect+0x76>
    11cc:	47f9                	li	a5,30
    11ce:	86d6                	mv	a3,s5
    11d0:	00001617          	auipc	a2,0x1
    11d4:	75860613          	addi	a2,a2,1880 # 2928 <enable_deadlock_detect+0x6e>
    11d8:	45fd                	li	a1,31
    11da:	1e0000ef          	jal	ra,13ba <printf>
    11de:	557d                	li	a0,-1
    11e0:	43c010ef          	jal	ra,261c <exit>
    11e4:	bf91                	j	1138 <test+0x1e>

00000000000011e6 <main>:
	"ch5b_forktest1\0",   "ch5b_forktest2\0", "ch6b_filetest\0",
	"ch6b_exec\0",
};

int main()
{
    11e6:	1101                	addi	sp,sp,-32
	puts("test starts!");
    11e8:	00001517          	auipc	a0,0x1
    11ec:	7b850513          	addi	a0,a0,1976 # 29a0 <enable_deadlock_detect+0xe6>
{
    11f0:	ec06                	sd	ra,24(sp)
    11f2:	e822                	sd	s0,16(sp)
    11f4:	e426                	sd	s1,8(sp)
	puts("test starts!");
    11f6:	0db000ef          	jal	ra,1ad0 <puts>
	int num_test = sizeof(TESTS) / sizeof(char *);
	int succ = run_tests(TESTS, num_test);
    11fa:	45b5                	li	a1,13
    11fc:	00002517          	auipc	a0,0x2
    1200:	b0c50513          	addi	a0,a0,-1268 # 2d08 <TESTS>
    1204:	dffff0ef          	jal	ra,1002 <run_tests>
	assert_eq(succ, num_test);
    1208:	47b5                	li	a5,13
    120a:	02f50f63          	beq	a0,a5,1248 <main+0x62>
    120e:	842a                	mv	s0,a0
    1210:	3dc010ef          	jal	ra,25ec <getpid>
    1214:	84aa                	mv	s1,a0
    1216:	00001517          	auipc	a0,0x1
    121a:	79a50513          	addi	a0,a0,1946 # 29b0 <enable_deadlock_detect+0xf6>
    121e:	2a4010ef          	jal	ra,24c2 <basename>
    1222:	872a                	mv	a4,a0
    1224:	48b5                	li	a7,13
    1226:	00001517          	auipc	a0,0x1
    122a:	70a50513          	addi	a0,a0,1802 # 2930 <enable_deadlock_detect+0x76>
    122e:	8822                	mv	a6,s0
    1230:	47d9                	li	a5,22
    1232:	86a6                	mv	a3,s1
    1234:	00001617          	auipc	a2,0x1
    1238:	6f460613          	addi	a2,a2,1780 # 2928 <enable_deadlock_detect+0x6e>
    123c:	45fd                	li	a1,31
    123e:	17c000ef          	jal	ra,13ba <printf>
    1242:	557d                	li	a0,-1
    1244:	3d8010ef          	jal	ra,261c <exit>
	puts("ch6b Usertests passed!");
    1248:	00001517          	auipc	a0,0x1
    124c:	7b050513          	addi	a0,a0,1968 # 29f8 <enable_deadlock_detect+0x13e>
    1250:	081000ef          	jal	ra,1ad0 <puts>
	return 0;
}
    1254:	60e2                	ld	ra,24(sp)
    1256:	6442                	ld	s0,16(sp)
    1258:	64a2                	ld	s1,8(sp)
    125a:	4501                	li	a0,0
    125c:	6105                	addi	sp,sp,32
    125e:	8082                	ret

0000000000001260 <__start_main>:
#include <unistd.h>

extern int main(int, char **);

int __start_main(int argc, char **argv)
{
    1260:	1141                	addi	sp,sp,-16
    1262:	e406                	sd	ra,8(sp)
	exit(main(argc, argv));
    1264:	f83ff0ef          	jal	ra,11e6 <main>
    1268:	3b4010ef          	jal	ra,261c <exit>
	return 0;
    126c:	60a2                	ld	ra,8(sp)
    126e:	4501                	li	a0,0
    1270:	0141                	addi	sp,sp,16
    1272:	8082                	ret

0000000000001274 <getchar>:

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int getchar()
{
    1274:	1101                	addi	sp,sp,-32
	char byte = 0;
	if (1 == read(stdin, &byte, 1)) {
    1276:	4605                	li	a2,1
    1278:	00f10593          	addi	a1,sp,15
    127c:	4501                	li	a0,0
{
    127e:	ec06                	sd	ra,24(sp)
	char byte = 0;
    1280:	000107a3          	sb	zero,15(sp)
	if (1 == read(stdin, &byte, 1)) {
    1284:	354010ef          	jal	ra,25d8 <read>
    1288:	4785                	li	a5,1
    128a:	00f51763          	bne	a0,a5,1298 <getchar+0x24>
		return byte;
    128e:	00f14503          	lbu	a0,15(sp)
	} else {
		return EOF;
	}
}
    1292:	60e2                	ld	ra,24(sp)
    1294:	6105                	addi	sp,sp,32
    1296:	8082                	ret
		return EOF;
    1298:	557d                	li	a0,-1
    129a:	bfe5                	j	1292 <getchar+0x1e>

000000000000129c <__write_buffer>:

// Returns: number of chars written, negative for failure
// Warn: buffer_len[f] will not be changed
int __write_buffer()
{
	if (buffer_len == 0)
    129c:	00002517          	auipc	a0,0x2
    12a0:	86c52503          	lw	a0,-1940(a0) # 2b08 <buffer_len>
    12a4:	e111                	bnez	a0,12a8 <__write_buffer+0xc>
		return 0;
	int r = write(stdout, buffer, buffer_len);
	return r;
}
    12a6:	8082                	ret
{
    12a8:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12aa:	862a                	mv	a2,a0
    12ac:	00002597          	auipc	a1,0x2
    12b0:	86458593          	addi	a1,a1,-1948 # 2b10 <buffer>
    12b4:	4505                	li	a0,1
{
    12b6:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12b8:	32a010ef          	jal	ra,25e2 <write>
}
    12bc:	60a2                	ld	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12be:	2501                	sext.w	a0,a0
}
    12c0:	0141                	addi	sp,sp,16
    12c2:	8082                	ret

00000000000012c4 <__clear_buffer>:

// Clear buffer_len[f]
void __clear_buffer()
{
	buffer_len = 0;
    12c4:	00002797          	auipc	a5,0x2
    12c8:	8407a223          	sw	zero,-1980(a5) # 2b08 <buffer_len>
}
    12cc:	8082                	ret

00000000000012ce <__fflush>:
	if (buffer_len == 0)
    12ce:	00002517          	auipc	a0,0x2
    12d2:	83a52503          	lw	a0,-1990(a0) # 2b08 <buffer_len>
    12d6:	e511                	bnez	a0,12e2 <__fflush+0x14>
	buffer_len = 0;
    12d8:	00002797          	auipc	a5,0x2
    12dc:	8207a823          	sw	zero,-2000(a5) # 2b08 <buffer_len>
int __fflush()
{
	int r = __write_buffer();
	__clear_buffer();
	return r >= 0 ? 0 : r;
}
    12e0:	8082                	ret
{
    12e2:	1141                	addi	sp,sp,-16
	int r = write(stdout, buffer, buffer_len);
    12e4:	862a                	mv	a2,a0
    12e6:	00002597          	auipc	a1,0x2
    12ea:	82a58593          	addi	a1,a1,-2006 # 2b10 <buffer>
    12ee:	4505                	li	a0,1
{
    12f0:	e406                	sd	ra,8(sp)
	int r = write(stdout, buffer, buffer_len);
    12f2:	2f0010ef          	jal	ra,25e2 <write>
	return r >= 0 ? 0 : r;
    12f6:	0005079b          	sext.w	a5,a0
}
    12fa:	60a2                	ld	ra,8(sp)
	return r >= 0 ? 0 : r;
    12fc:	0017a793          	slti	a5,a5,1
    1300:	40f007bb          	negw	a5,a5
    1304:	8d7d                	and	a0,a0,a5
	buffer_len = 0;
    1306:	00002797          	auipc	a5,0x2
    130a:	8007a123          	sw	zero,-2046(a5) # 2b08 <buffer_len>
	return r >= 0 ? 0 : r;
    130e:	2501                	sext.w	a0,a0
}
    1310:	0141                	addi	sp,sp,16
    1312:	8082                	ret

0000000000001314 <fflush>:

int fflush(int fd)
{
    1314:	1101                	addi	sp,sp,-32
    1316:	e822                	sd	s0,16(sp)
    1318:	ec06                	sd	ra,24(sp)
    131a:	e426                	sd	s1,8(sp)
	if (fd == 1) {
    131c:	4705                	li	a4,1
		} else {
			len = __fflush();
		}
		return len;
	}
	return 0;
    131e:	4401                	li	s0,0
	if (fd == 1) {
    1320:	00e50863          	beq	a0,a4,1330 <fflush+0x1c>
}
    1324:	60e2                	ld	ra,24(sp)
    1326:	8522                	mv	a0,s0
    1328:	6442                	ld	s0,16(sp)
    132a:	64a2                	ld	s1,8(sp)
    132c:	6105                	addi	sp,sp,32
    132e:	8082                	ret
		if (buffer_lock_enabled == 1) {
    1330:	00001497          	auipc	s1,0x1
    1334:	7d848493          	addi	s1,s1,2008 # 2b08 <buffer_len>
    1338:	1084a703          	lw	a4,264(s1)
    133c:	02a70e63          	beq	a4,a0,1378 <fflush+0x64>
	if (buffer_len == 0)
    1340:	4080                	lw	s0,0(s1)
    1342:	c00d                	beqz	s0,1364 <fflush+0x50>
	int r = write(stdout, buffer, buffer_len);
    1344:	8622                	mv	a2,s0
    1346:	00001597          	auipc	a1,0x1
    134a:	7ca58593          	addi	a1,a1,1994 # 2b10 <buffer>
    134e:	294010ef          	jal	ra,25e2 <write>
	return r >= 0 ? 0 : r;
    1352:	0005079b          	sext.w	a5,a0
    1356:	0017a793          	slti	a5,a5,1
    135a:	40f007bb          	negw	a5,a5
    135e:	8d7d                	and	a0,a0,a5
    1360:	0005041b          	sext.w	s0,a0
}
    1364:	60e2                	ld	ra,24(sp)
    1366:	8522                	mv	a0,s0
    1368:	6442                	ld	s0,16(sp)
	buffer_len = 0;
    136a:	00001797          	auipc	a5,0x1
    136e:	7807af23          	sw	zero,1950(a5) # 2b08 <buffer_len>
}
    1372:	64a2                	ld	s1,8(sp)
    1374:	6105                	addi	sp,sp,32
    1376:	8082                	ret
			mutex_lock(buffer_lock);
    1378:	10c4a503          	lw	a0,268(s1)
    137c:	4de010ef          	jal	ra,285a <mutex_lock>
	if (buffer_len == 0)
    1380:	4080                	lw	s0,0(s1)
    1382:	e811                	bnez	s0,1396 <fflush+0x82>
			mutex_unlock(buffer_lock);
    1384:	10c4a503          	lw	a0,268(s1)
	buffer_len = 0;
    1388:	00001797          	auipc	a5,0x1
    138c:	7807a023          	sw	zero,1920(a5) # 2b08 <buffer_len>
			mutex_unlock(buffer_lock);
    1390:	4d6010ef          	jal	ra,2866 <mutex_unlock>
    1394:	bf41                	j	1324 <fflush+0x10>
	int r = write(stdout, buffer, buffer_len);
    1396:	8622                	mv	a2,s0
    1398:	00001597          	auipc	a1,0x1
    139c:	77858593          	addi	a1,a1,1912 # 2b10 <buffer>
    13a0:	4505                	li	a0,1
    13a2:	240010ef          	jal	ra,25e2 <write>
	return r >= 0 ? 0 : r;
    13a6:	0005079b          	sext.w	a5,a0
    13aa:	0017a793          	slti	a5,a5,1
    13ae:	40f007bb          	negw	a5,a5
    13b2:	8d7d                	and	a0,a0,a5
    13b4:	0005041b          	sext.w	s0,a0
	return r;
    13b8:	b7f1                	j	1384 <fflush+0x70>

00000000000013ba <printf>:
	out(stdout, buf, i);
}

// Print to the console. only understands %d, %x, %p, %s.
void printf(const char *fmt, ...)
{
    13ba:	7131                	addi	sp,sp,-192
    13bc:	e0da                	sd	s6,64(sp)
    13be:	f53e                	sd	a5,168(sp)
	buf[i++] = '0';
    13c0:	7b61                	lui	s6,0xffff8
	va_list ap;
	int l = 0;
	char *a, *z, *s = (char *)fmt;
	int f = stdout;

	va_start(ap, fmt);
    13c2:	013c                	addi	a5,sp,136
{
    13c4:	f0ca                	sd	s2,96(sp)
    13c6:	ecce                	sd	s3,88(sp)
    13c8:	e8d2                	sd	s4,80(sp)
    13ca:	e4d6                	sd	s5,72(sp)
    13cc:	fc86                	sd	ra,120(sp)
    13ce:	f8a2                	sd	s0,112(sp)
    13d0:	f4a6                	sd	s1,104(sp)
    13d2:	89aa                	mv	s3,a0
    13d4:	e52e                	sd	a1,136(sp)
    13d6:	e932                	sd	a2,144(sp)
    13d8:	ed36                	sd	a3,152(sp)
    13da:	f13a                	sd	a4,160(sp)
    13dc:	f942                	sd	a6,176(sp)
    13de:	fd46                	sd	a7,184(sp)
	va_start(ap, fmt);
    13e0:	e83e                	sd	a5,16(sp)
	for (;;) {
		if (!*s)
			break;
		for (a = s; *s && *s != '%'; s++)
    13e2:	02500913          	li	s2,37
	if (buffer_lock_enabled == 1) {
    13e6:	00001a17          	auipc	s4,0x1
    13ea:	722a0a13          	addi	s4,s4,1826 # 2b08 <buffer_len>
    13ee:	4a85                	li	s5,1
	buf[i++] = '0';
    13f0:	830b4b13          	xori	s6,s6,-2000
		if (!*s)
    13f4:	0009c783          	lbu	a5,0(s3)
    13f8:	18078663          	beqz	a5,1584 <printf+0x1ca>
    13fc:	85ce                	mv	a1,s3
		for (a = s; *s && *s != '%'; s++)
    13fe:	19278d63          	beq	a5,s2,1598 <printf+0x1de>
    1402:	0015c783          	lbu	a5,1(a1)
    1406:	0585                	addi	a1,a1,1
    1408:	fbfd                	bnez	a5,13fe <printf+0x44>
    140a:	84ae                	mv	s1,a1
	if (buffer_lock_enabled == 1) {
    140c:	108a2783          	lw	a5,264(s4)
			;
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
			;
		l = z - a;
    1410:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    1414:	1b578863          	beq	a5,s5,15c4 <printf+0x20a>
		len = out_unlocked(s, l);
    1418:	85a2                	mv	a1,s0
    141a:	854e                	mv	a0,s3
    141c:	42a000ef          	jal	ra,1846 <out_unlocked>
		out(f, a, l);
		if (l)
    1420:	1c041063          	bnez	s0,15e0 <printf+0x226>
			continue;
		if (s[1] == 0)
    1424:	0014c783          	lbu	a5,1(s1)
    1428:	14078e63          	beqz	a5,1584 <printf+0x1ca>
			break;
		switch (s[1]) {
    142c:	07300713          	li	a4,115
    1430:	1ce78863          	beq	a5,a4,1600 <printf+0x246>
    1434:	1af76863          	bltu	a4,a5,15e4 <printf+0x22a>
    1438:	06400713          	li	a4,100
    143c:	22e78063          	beq	a5,a4,165c <printf+0x2a2>
    1440:	07000713          	li	a4,112
    1444:	1ee79563          	bne	a5,a4,162e <printf+0x274>
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
    1448:	66c2                	ld	a3,16(sp)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    144a:	00002797          	auipc	a5,0x2
    144e:	8a678793          	addi	a5,a5,-1882 # 2cf0 <digits>
	buf[i++] = '0';
    1452:	01611c23          	sh	s6,24(sp)
			printptr(va_arg(ap, uint64));
    1456:	6298                	ld	a4,0(a3)
    1458:	06a1                	addi	a3,a3,8
    145a:	e836                	sd	a3,16(sp)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    145c:	00471393          	slli	t2,a4,0x4
    1460:	00871293          	slli	t0,a4,0x8
    1464:	00c71f93          	slli	t6,a4,0xc
    1468:	01071f13          	slli	t5,a4,0x10
    146c:	01471e93          	slli	t4,a4,0x14
    1470:	01871e13          	slli	t3,a4,0x18
    1474:	01c71893          	slli	a7,a4,0x1c
    1478:	02471813          	slli	a6,a4,0x24
    147c:	02871513          	slli	a0,a4,0x28
    1480:	02c71593          	slli	a1,a4,0x2c
    1484:	03071613          	slli	a2,a4,0x30
    1488:	03471693          	slli	a3,a4,0x34
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    148c:	03c75413          	srli	s0,a4,0x3c
    1490:	01c7531b          	srliw	t1,a4,0x1c
    1494:	03c3d393          	srli	t2,t2,0x3c
    1498:	03c2d293          	srli	t0,t0,0x3c
    149c:	03cfdf93          	srli	t6,t6,0x3c
    14a0:	03cf5f13          	srli	t5,t5,0x3c
    14a4:	03cede93          	srli	t4,t4,0x3c
    14a8:	03ce5e13          	srli	t3,t3,0x3c
    14ac:	03c8d893          	srli	a7,a7,0x3c
    14b0:	03c85813          	srli	a6,a6,0x3c
    14b4:	9171                	srli	a0,a0,0x3c
    14b6:	91f1                	srli	a1,a1,0x3c
    14b8:	9271                	srli	a2,a2,0x3c
    14ba:	92f1                	srli	a3,a3,0x3c
    14bc:	95be                	add	a1,a1,a5
    14be:	963e                	add	a2,a2,a5
    14c0:	96be                	add	a3,a3,a5
    14c2:	943e                	add	s0,s0,a5
    14c4:	93be                	add	t2,t2,a5
    14c6:	92be                	add	t0,t0,a5
    14c8:	9fbe                	add	t6,t6,a5
    14ca:	9f3e                	add	t5,t5,a5
    14cc:	9ebe                	add	t4,t4,a5
    14ce:	9e3e                	add	t3,t3,a5
    14d0:	98be                	add	a7,a7,a5
    14d2:	933e                	add	t1,t1,a5
    14d4:	983e                	add	a6,a6,a5
    14d6:	953e                	add	a0,a0,a5
    14d8:	0005c983          	lbu	s3,0(a1)
    14dc:	00044403          	lbu	s0,0(s0)
    14e0:	00064583          	lbu	a1,0(a2)
    14e4:	0003c383          	lbu	t2,0(t2)
    14e8:	0006c603          	lbu	a2,0(a3)
    14ec:	0002c283          	lbu	t0,0(t0)
    14f0:	000fcf83          	lbu	t6,0(t6)
    14f4:	000f4f03          	lbu	t5,0(t5)
    14f8:	000ece83          	lbu	t4,0(t4)
    14fc:	000e4e03          	lbu	t3,0(t3)
    1500:	0008c883          	lbu	a7,0(a7)
    1504:	00034303          	lbu	t1,0(t1)
    1508:	00084803          	lbu	a6,0(a6)
    150c:	00054503          	lbu	a0,0(a0)
	for (j = 0; j < (sizeof(uint64) * 2); j++, x <<= 4)
    1510:	03871693          	slli	a3,a4,0x38
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1514:	92f1                	srli	a3,a3,0x3c
    1516:	8b3d                	andi	a4,a4,15
    1518:	96be                	add	a3,a3,a5
    151a:	97ba                	add	a5,a5,a4
    151c:	00810d23          	sb	s0,26(sp)
    1520:	00710da3          	sb	t2,27(sp)
    1524:	00510e23          	sb	t0,28(sp)
    1528:	01f10ea3          	sb	t6,29(sp)
    152c:	01e10f23          	sb	t5,30(sp)
    1530:	01d10fa3          	sb	t4,31(sp)
    1534:	03c10023          	sb	t3,32(sp)
    1538:	031100a3          	sb	a7,33(sp)
    153c:	02610123          	sb	t1,34(sp)
    1540:	030101a3          	sb	a6,35(sp)
    1544:	02a10223          	sb	a0,36(sp)
    1548:	033102a3          	sb	s3,37(sp)
    154c:	02b10323          	sb	a1,38(sp)
    1550:	02c103a3          	sb	a2,39(sp)
    1554:	0006c683          	lbu	a3,0(a3)
    1558:	0007c703          	lbu	a4,0(a5)
	if (buffer_lock_enabled == 1) {
    155c:	108a2783          	lw	a5,264(s4)
		buf[i++] = digits[x >> (sizeof(uint64) * 8 - 4)];
    1560:	02d10423          	sb	a3,40(sp)
    1564:	02e104a3          	sb	a4,41(sp)
	buf[i] = 0;
    1568:	02010523          	sb	zero,42(sp)
	if (buffer_lock_enabled == 1) {
    156c:	11578263          	beq	a5,s5,1670 <printf+0x2b6>
		len = out_unlocked(s, l);
    1570:	45c9                	li	a1,18
    1572:	0828                	addi	a0,sp,24
    1574:	2d2000ef          	jal	ra,1846 <out_unlocked>
			// Print unknown % sequence to draw attention.
			putchar('%');
			putchar(s[1]);
			break;
		}
		s += 2;
    1578:	00248993          	addi	s3,s1,2
		if (!*s)
    157c:	0009c783          	lbu	a5,0(s3)
    1580:	e6079ee3          	bnez	a5,13fc <printf+0x42>
	}
	va_end(ap);
    1584:	70e6                	ld	ra,120(sp)
    1586:	7446                	ld	s0,112(sp)
    1588:	74a6                	ld	s1,104(sp)
    158a:	7906                	ld	s2,96(sp)
    158c:	69e6                	ld	s3,88(sp)
    158e:	6a46                	ld	s4,80(sp)
    1590:	6aa6                	ld	s5,72(sp)
    1592:	6b06                	ld	s6,64(sp)
    1594:	6129                	addi	sp,sp,192
    1596:	8082                	ret
		for (z = s; s[0] == '%' && s[1] == '%'; z++, s += 2)
    1598:	0005c783          	lbu	a5,0(a1)
    159c:	84ae                	mv	s1,a1
    159e:	01278963          	beq	a5,s2,15b0 <printf+0x1f6>
    15a2:	b5ad                	j	140c <printf+0x52>
    15a4:	0024c783          	lbu	a5,2(s1)
    15a8:	0585                	addi	a1,a1,1
    15aa:	0489                	addi	s1,s1,2
    15ac:	e72790e3          	bne	a5,s2,140c <printf+0x52>
    15b0:	0014c783          	lbu	a5,1(s1)
    15b4:	ff2788e3          	beq	a5,s2,15a4 <printf+0x1ea>
	if (buffer_lock_enabled == 1) {
    15b8:	108a2783          	lw	a5,264(s4)
		l = z - a;
    15bc:	4135843b          	subw	s0,a1,s3
	if (buffer_lock_enabled == 1) {
    15c0:	e5579ce3          	bne	a5,s5,1418 <printf+0x5e>
		mutex_lock(buffer_lock);
    15c4:	10ca2503          	lw	a0,268(s4)
    15c8:	292010ef          	jal	ra,285a <mutex_lock>
		len = out_unlocked(s, l);
    15cc:	85a2                	mv	a1,s0
    15ce:	854e                	mv	a0,s3
    15d0:	276000ef          	jal	ra,1846 <out_unlocked>
		mutex_unlock(buffer_lock);
    15d4:	10ca2503          	lw	a0,268(s4)
    15d8:	28e010ef          	jal	ra,2866 <mutex_unlock>
		if (l)
    15dc:	e40404e3          	beqz	s0,1424 <printf+0x6a>
    15e0:	89a6                	mv	s3,s1
    15e2:	bd09                	j	13f4 <printf+0x3a>
		switch (s[1]) {
    15e4:	07800713          	li	a4,120
    15e8:	04e79363          	bne	a5,a4,162e <printf+0x274>
			printint(va_arg(ap, int), 16, 1);
    15ec:	67c2                	ld	a5,16(sp)
    15ee:	45c1                	li	a1,16
		s += 2;
    15f0:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 16, 1);
    15f4:	4388                	lw	a0,0(a5)
    15f6:	07a1                	addi	a5,a5,8
    15f8:	e83e                	sd	a5,16(sp)
    15fa:	5f8000ef          	jal	ra,1bf2 <printint.constprop.0>
		s += 2;
    15fe:	bfbd                	j	157c <printf+0x1c2>
			if ((a = va_arg(ap, char *)) == 0)
    1600:	67c2                	ld	a5,16(sp)
    1602:	6380                	ld	s0,0(a5)
    1604:	07a1                	addi	a5,a5,8
    1606:	e83e                	sd	a5,16(sp)
    1608:	1c040163          	beqz	s0,17ca <printf+0x410>
			l = strnlen(a, 200);
    160c:	0c800593          	li	a1,200
    1610:	8522                	mv	a0,s0
    1612:	3f7000ef          	jal	ra,2208 <strnlen>
	if (buffer_lock_enabled == 1) {
    1616:	108a2783          	lw	a5,264(s4)
			out(f, a, l);
    161a:	0005059b          	sext.w	a1,a0
	if (buffer_lock_enabled == 1) {
    161e:	19578663          	beq	a5,s5,17aa <printf+0x3f0>
		len = out_unlocked(s, l);
    1622:	8522                	mv	a0,s0
    1624:	222000ef          	jal	ra,1846 <out_unlocked>
		s += 2;
    1628:	00248993          	addi	s3,s1,2
    162c:	bf81                	j	157c <printf+0x1c2>
	if (buffer_lock_enabled == 1) {
    162e:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1632:	01210c23          	sb	s2,24(sp)
	if (buffer_lock_enabled == 1) {
    1636:	0f578663          	beq	a5,s5,1722 <printf+0x368>
		len = out_unlocked(s, l);
    163a:	0828                	addi	a0,sp,24
    163c:	316000ef          	jal	ra,1952 <out_unlocked.constprop.0>
			putchar(s[1]);
    1640:	0014c403          	lbu	s0,1(s1)
	if (buffer_lock_enabled == 1) {
    1644:	108a2783          	lw	a5,264(s4)
	char byte = c;
    1648:	00810c23          	sb	s0,24(sp)
	if (buffer_lock_enabled == 1) {
    164c:	05578163          	beq	a5,s5,168e <printf+0x2d4>
		len = out_unlocked(s, l);
    1650:	0828                	addi	a0,sp,24
    1652:	300000ef          	jal	ra,1952 <out_unlocked.constprop.0>
		s += 2;
    1656:	00248993          	addi	s3,s1,2
    165a:	b70d                	j	157c <printf+0x1c2>
			printint(va_arg(ap, int), 10, 1);
    165c:	67c2                	ld	a5,16(sp)
    165e:	45a9                	li	a1,10
		s += 2;
    1660:	00248993          	addi	s3,s1,2
			printint(va_arg(ap, int), 10, 1);
    1664:	4388                	lw	a0,0(a5)
    1666:	07a1                	addi	a5,a5,8
    1668:	e83e                	sd	a5,16(sp)
    166a:	588000ef          	jal	ra,1bf2 <printint.constprop.0>
		s += 2;
    166e:	b739                	j	157c <printf+0x1c2>
		mutex_lock(buffer_lock);
    1670:	10ca2503          	lw	a0,268(s4)
		s += 2;
    1674:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    1678:	1e2010ef          	jal	ra,285a <mutex_lock>
		len = out_unlocked(s, l);
    167c:	45c9                	li	a1,18
    167e:	0828                	addi	a0,sp,24
    1680:	1c6000ef          	jal	ra,1846 <out_unlocked>
		mutex_unlock(buffer_lock);
    1684:	10ca2503          	lw	a0,268(s4)
    1688:	1de010ef          	jal	ra,2866 <mutex_unlock>
		s += 2;
    168c:	bdc5                	j	157c <printf+0x1c2>
		mutex_lock(buffer_lock);
    168e:	10ca2503          	lw	a0,268(s4)
    1692:	1c8010ef          	jal	ra,285a <mutex_lock>
		buffer[buffer_len++] = c;
    1696:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    169a:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    169e:	0017861b          	addiw	a2,a5,1
    16a2:	97d2                	add	a5,a5,s4
    16a4:	00ca2023          	sw	a2,0(s4)
    16a8:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    16ac:	00c6cc63          	blt	a3,a2,16c4 <printf+0x30a>
    16b0:	47a9                	li	a5,10
    16b2:	06f40663          	beq	s0,a5,171e <printf+0x364>
		mutex_unlock(buffer_lock);
    16b6:	10ca2503          	lw	a0,268(s4)
		s += 2;
    16ba:	00248993          	addi	s3,s1,2
		mutex_unlock(buffer_lock);
    16be:	1a8010ef          	jal	ra,2866 <mutex_unlock>
		s += 2;
    16c2:	bd6d                	j	157c <printf+0x1c2>
			assert(buffer_len <= __LINE_WIDTH);
    16c4:	10000793          	li	a5,256
    16c8:	00f61e63          	bne	a2,a5,16e4 <printf+0x32a>
	int r = write(stdout, buffer, buffer_len);
    16cc:	00001597          	auipc	a1,0x1
    16d0:	44458593          	addi	a1,a1,1092 # 2b10 <buffer>
    16d4:	4505                	li	a0,1
    16d6:	70d000ef          	jal	ra,25e2 <write>
	buffer_len = 0;
    16da:	00001797          	auipc	a5,0x1
    16de:	4207a723          	sw	zero,1070(a5) # 2b08 <buffer_len>
			if (r < 0) {
    16e2:	bfd1                	j	16b6 <printf+0x2fc>
			assert(buffer_len <= __LINE_WIDTH);
    16e4:	709000ef          	jal	ra,25ec <getpid>
    16e8:	842a                	mv	s0,a0
    16ea:	00001517          	auipc	a0,0x1
    16ee:	32e50513          	addi	a0,a0,814 # 2a18 <enable_deadlock_detect+0x15e>
    16f2:	5d1000ef          	jal	ra,24c2 <basename>
    16f6:	872a                	mv	a4,a0
    16f8:	00001617          	auipc	a2,0x1
    16fc:	23060613          	addi	a2,a2,560 # 2928 <enable_deadlock_detect+0x6e>
    1700:	05400793          	li	a5,84
    1704:	86a2                	mv	a3,s0
    1706:	45fd                	li	a1,31
    1708:	00001517          	auipc	a0,0x1
    170c:	35050513          	addi	a0,a0,848 # 2a58 <enable_deadlock_detect+0x19e>
    1710:	cabff0ef          	jal	ra,13ba <printf>
    1714:	557d                	li	a0,-1
    1716:	707000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    171a:	000a2603          	lw	a2,0(s4)
    171e:	de41                	beqz	a2,16b6 <printf+0x2fc>
    1720:	b775                	j	16cc <printf+0x312>
		mutex_lock(buffer_lock);
    1722:	10ca2503          	lw	a0,268(s4)
    1726:	134010ef          	jal	ra,285a <mutex_lock>
		buffer[buffer_len++] = c;
    172a:	000a2783          	lw	a5,0(s4)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    172e:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1732:	0017861b          	addiw	a2,a5,1
    1736:	97d2                	add	a5,a5,s4
    1738:	00ca2023          	sw	a2,0(s4)
    173c:	01278423          	sb	s2,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1740:	02c6d163          	bge	a3,a2,1762 <printf+0x3a8>
			assert(buffer_len <= __LINE_WIDTH);
    1744:	10000793          	li	a5,256
    1748:	02f61263          	bne	a2,a5,176c <printf+0x3b2>
	int r = write(stdout, buffer, buffer_len);
    174c:	00001597          	auipc	a1,0x1
    1750:	3c458593          	addi	a1,a1,964 # 2b10 <buffer>
    1754:	4505                	li	a0,1
    1756:	68d000ef          	jal	ra,25e2 <write>
	buffer_len = 0;
    175a:	00001797          	auipc	a5,0x1
    175e:	3a07a723          	sw	zero,942(a5) # 2b08 <buffer_len>
		mutex_unlock(buffer_lock);
    1762:	10ca2503          	lw	a0,268(s4)
    1766:	100010ef          	jal	ra,2866 <mutex_unlock>
    176a:	bdd9                	j	1640 <printf+0x286>
			assert(buffer_len <= __LINE_WIDTH);
    176c:	681000ef          	jal	ra,25ec <getpid>
    1770:	842a                	mv	s0,a0
    1772:	00001517          	auipc	a0,0x1
    1776:	2a650513          	addi	a0,a0,678 # 2a18 <enable_deadlock_detect+0x15e>
    177a:	549000ef          	jal	ra,24c2 <basename>
    177e:	872a                	mv	a4,a0
    1780:	00001617          	auipc	a2,0x1
    1784:	1a860613          	addi	a2,a2,424 # 2928 <enable_deadlock_detect+0x6e>
    1788:	05400793          	li	a5,84
    178c:	86a2                	mv	a3,s0
    178e:	45fd                	li	a1,31
    1790:	00001517          	auipc	a0,0x1
    1794:	2c850513          	addi	a0,a0,712 # 2a58 <enable_deadlock_detect+0x19e>
    1798:	c23ff0ef          	jal	ra,13ba <printf>
    179c:	557d                	li	a0,-1
    179e:	67f000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    17a2:	000a2603          	lw	a2,0(s4)
    17a6:	de55                	beqz	a2,1762 <printf+0x3a8>
    17a8:	b755                	j	174c <printf+0x392>
		mutex_lock(buffer_lock);
    17aa:	10ca2503          	lw	a0,268(s4)
    17ae:	e42e                	sd	a1,8(sp)
		s += 2;
    17b0:	00248993          	addi	s3,s1,2
		mutex_lock(buffer_lock);
    17b4:	0a6010ef          	jal	ra,285a <mutex_lock>
		len = out_unlocked(s, l);
    17b8:	65a2                	ld	a1,8(sp)
    17ba:	8522                	mv	a0,s0
    17bc:	08a000ef          	jal	ra,1846 <out_unlocked>
		mutex_unlock(buffer_lock);
    17c0:	10ca2503          	lw	a0,268(s4)
    17c4:	0a2010ef          	jal	ra,2866 <mutex_unlock>
		s += 2;
    17c8:	bb55                	j	157c <printf+0x1c2>
				a = "(null)";
    17ca:	00001417          	auipc	s0,0x1
    17ce:	24640413          	addi	s0,s0,582 # 2a10 <enable_deadlock_detect+0x156>
    17d2:	bd2d                	j	160c <printf+0x252>

00000000000017d4 <enable_thread_io_buffer>:
{
    17d4:	1101                	addi	sp,sp,-32
    17d6:	e822                	sd	s0,16(sp)
    17d8:	ec06                	sd	ra,24(sp)
    17da:	e426                	sd	s1,8(sp)
	assert((buffer_lock = mutex_create()) >= 0);
    17dc:	00001417          	auipc	s0,0x1
    17e0:	32c40413          	addi	s0,s0,812 # 2b08 <buffer_len>
    17e4:	05a010ef          	jal	ra,283e <mutex_create>
    17e8:	10a42623          	sw	a0,268(s0)
    17ec:	00054a63          	bltz	a0,1800 <enable_thread_io_buffer+0x2c>
	buffer_lock_enabled = 1;
    17f0:	4785                	li	a5,1
}
    17f2:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    17f4:	10f42423          	sw	a5,264(s0)
}
    17f8:	6442                	ld	s0,16(sp)
    17fa:	64a2                	ld	s1,8(sp)
    17fc:	6105                	addi	sp,sp,32
    17fe:	8082                	ret
	assert((buffer_lock = mutex_create()) >= 0);
    1800:	5ed000ef          	jal	ra,25ec <getpid>
    1804:	84aa                	mv	s1,a0
    1806:	00001517          	auipc	a0,0x1
    180a:	21250513          	addi	a0,a0,530 # 2a18 <enable_deadlock_detect+0x15e>
    180e:	4b5000ef          	jal	ra,24c2 <basename>
    1812:	872a                	mv	a4,a0
    1814:	04800793          	li	a5,72
    1818:	86a6                	mv	a3,s1
    181a:	00001517          	auipc	a0,0x1
    181e:	27e50513          	addi	a0,a0,638 # 2a98 <enable_deadlock_detect+0x1de>
    1822:	00001617          	auipc	a2,0x1
    1826:	10660613          	addi	a2,a2,262 # 2928 <enable_deadlock_detect+0x6e>
    182a:	45fd                	li	a1,31
    182c:	b8fff0ef          	jal	ra,13ba <printf>
    1830:	557d                	li	a0,-1
    1832:	5eb000ef          	jal	ra,261c <exit>
	buffer_lock_enabled = 1;
    1836:	4785                	li	a5,1
}
    1838:	60e2                	ld	ra,24(sp)
	buffer_lock_enabled = 1;
    183a:	10f42423          	sw	a5,264(s0)
}
    183e:	6442                	ld	s0,16(sp)
    1840:	64a2                	ld	s1,8(sp)
    1842:	6105                	addi	sp,sp,32
    1844:	8082                	ret

0000000000001846 <out_unlocked>:
{
    1846:	7159                	addi	sp,sp,-112
    1848:	f486                	sd	ra,104(sp)
    184a:	f0a2                	sd	s0,96(sp)
    184c:	eca6                	sd	s1,88(sp)
    184e:	e8ca                	sd	s2,80(sp)
    1850:	e4ce                	sd	s3,72(sp)
    1852:	e0d2                	sd	s4,64(sp)
    1854:	fc56                	sd	s5,56(sp)
    1856:	f85a                	sd	s6,48(sp)
    1858:	f45e                	sd	s7,40(sp)
    185a:	f062                	sd	s8,32(sp)
    185c:	ec66                	sd	s9,24(sp)
    185e:	e86a                	sd	s10,16(sp)
    1860:	e46e                	sd	s11,8(sp)
	for (size_t i = 0; i < l; i++) {
    1862:	0e058663          	beqz	a1,194e <out_unlocked+0x108>
    1866:	842a                	mv	s0,a0
    1868:	00b504b3          	add	s1,a0,a1
	int ret = 0;
    186c:	4981                	li	s3,0
    186e:	00001d17          	auipc	s10,0x1
    1872:	29ad0d13          	addi	s10,s10,666 # 2b08 <buffer_len>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1876:	0ff00913          	li	s2,255
	int r = write(stdout, buffer, buffer_len);
    187a:	00001b17          	auipc	s6,0x1
    187e:	296b0b13          	addi	s6,s6,662 # 2b10 <buffer>
			assert(buffer_len <= __LINE_WIDTH);
    1882:	10000a93          	li	s5,256
    1886:	00001c97          	auipc	s9,0x1
    188a:	192c8c93          	addi	s9,s9,402 # 2a18 <enable_deadlock_detect+0x15e>
    188e:	00001c17          	auipc	s8,0x1
    1892:	09ac0c13          	addi	s8,s8,154 # 2928 <enable_deadlock_detect+0x6e>
    1896:	00001b97          	auipc	s7,0x1
    189a:	1c2b8b93          	addi	s7,s7,450 # 2a58 <enable_deadlock_detect+0x19e>
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    189e:	4a29                	li	s4,10
    18a0:	a031                	j	18ac <out_unlocked+0x66>
    18a2:	09468863          	beq	a3,s4,1932 <out_unlocked+0xec>
	for (size_t i = 0; i < l; i++) {
    18a6:	0405                	addi	s0,s0,1
    18a8:	04848163          	beq	s1,s0,18ea <out_unlocked+0xa4>
		buffer[buffer_len++] = c;
    18ac:	000d2783          	lw	a5,0(s10)
		char c = s[i];
    18b0:	00044683          	lbu	a3,0(s0)
		buffer[buffer_len++] = c;
    18b4:	0017861b          	addiw	a2,a5,1
    18b8:	97ea                	add	a5,a5,s10
    18ba:	00cd2023          	sw	a2,0(s10)
    18be:	00d78423          	sb	a3,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    18c2:	fec950e3          	bge	s2,a2,18a2 <out_unlocked+0x5c>
			assert(buffer_len <= __LINE_WIDTH);
    18c6:	05561263          	bne	a2,s5,190a <out_unlocked+0xc4>
	int r = write(stdout, buffer, buffer_len);
    18ca:	85da                	mv	a1,s6
    18cc:	4505                	li	a0,1
    18ce:	515000ef          	jal	ra,25e2 <write>
    18d2:	2501                	sext.w	a0,a0
	buffer_len = 0;
    18d4:	00001797          	auipc	a5,0x1
    18d8:	2207aa23          	sw	zero,564(a5) # 2b08 <buffer_len>
			if (r < 0) {
    18dc:	06054763          	bltz	a0,194a <out_unlocked+0x104>
	for (size_t i = 0; i < l; i++) {
    18e0:	0405                	addi	s0,s0,1
			ret += r;
    18e2:	00a989bb          	addw	s3,s3,a0
	for (size_t i = 0; i < l; i++) {
    18e6:	fc8493e3          	bne	s1,s0,18ac <out_unlocked+0x66>
}
    18ea:	70a6                	ld	ra,104(sp)
    18ec:	7406                	ld	s0,96(sp)
    18ee:	64e6                	ld	s1,88(sp)
    18f0:	6946                	ld	s2,80(sp)
    18f2:	6a06                	ld	s4,64(sp)
    18f4:	7ae2                	ld	s5,56(sp)
    18f6:	7b42                	ld	s6,48(sp)
    18f8:	7ba2                	ld	s7,40(sp)
    18fa:	7c02                	ld	s8,32(sp)
    18fc:	6ce2                	ld	s9,24(sp)
    18fe:	6d42                	ld	s10,16(sp)
    1900:	6da2                	ld	s11,8(sp)
    1902:	854e                	mv	a0,s3
    1904:	69a6                	ld	s3,72(sp)
    1906:	6165                	addi	sp,sp,112
    1908:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    190a:	4e3000ef          	jal	ra,25ec <getpid>
    190e:	8daa                	mv	s11,a0
    1910:	8566                	mv	a0,s9
    1912:	3b1000ef          	jal	ra,24c2 <basename>
    1916:	872a                	mv	a4,a0
    1918:	8662                	mv	a2,s8
    191a:	05400793          	li	a5,84
    191e:	86ee                	mv	a3,s11
    1920:	45fd                	li	a1,31
    1922:	855e                	mv	a0,s7
    1924:	a97ff0ef          	jal	ra,13ba <printf>
    1928:	557d                	li	a0,-1
    192a:	4f3000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    192e:	000d2603          	lw	a2,0(s10)
    1932:	da35                	beqz	a2,18a6 <out_unlocked+0x60>
	int r = write(stdout, buffer, buffer_len);
    1934:	85da                	mv	a1,s6
    1936:	4505                	li	a0,1
    1938:	4ab000ef          	jal	ra,25e2 <write>
    193c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    193e:	00001797          	auipc	a5,0x1
    1942:	1c07a523          	sw	zero,458(a5) # 2b08 <buffer_len>
			if (r < 0) {
    1946:	f8055de3          	bgez	a0,18e0 <out_unlocked+0x9a>
    194a:	89aa                	mv	s3,a0
    194c:	bf79                	j	18ea <out_unlocked+0xa4>
	int ret = 0;
    194e:	4981                	li	s3,0
    1950:	bf69                	j	18ea <out_unlocked+0xa4>

0000000000001952 <out_unlocked.constprop.0>:
static int out_unlocked(const char *s, size_t l)
    1952:	1101                	addi	sp,sp,-32
    1954:	e426                	sd	s1,8(sp)
		buffer[buffer_len++] = c;
    1956:	00001497          	auipc	s1,0x1
    195a:	1b248493          	addi	s1,s1,434 # 2b08 <buffer_len>
    195e:	409c                	lw	a5,0(s1)
static int out_unlocked(const char *s, size_t l)
    1960:	ec06                	sd	ra,24(sp)
    1962:	e822                	sd	s0,16(sp)
		char c = s[i];
    1964:	00054703          	lbu	a4,0(a0)
		buffer[buffer_len++] = c;
    1968:	0017861b          	addiw	a2,a5,1
    196c:	97a6                	add	a5,a5,s1
    196e:	00e78423          	sb	a4,8(a5)
    1972:	c090                	sw	a2,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1974:	0ff00793          	li	a5,255
    1978:	00c7cc63          	blt	a5,a2,1990 <out_unlocked.constprop.0+0x3e>
    197c:	47a9                	li	a5,10
    197e:	06f70c63          	beq	a4,a5,19f6 <out_unlocked.constprop.0+0xa4>
    1982:	4601                	li	a2,0
}
    1984:	60e2                	ld	ra,24(sp)
    1986:	6442                	ld	s0,16(sp)
    1988:	64a2                	ld	s1,8(sp)
    198a:	8532                	mv	a0,a2
    198c:	6105                	addi	sp,sp,32
    198e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1990:	10000793          	li	a5,256
    1994:	02f61563          	bne	a2,a5,19be <out_unlocked.constprop.0+0x6c>
	int r = write(stdout, buffer, buffer_len);
    1998:	00001597          	auipc	a1,0x1
    199c:	17858593          	addi	a1,a1,376 # 2b10 <buffer>
    19a0:	4505                	li	a0,1
    19a2:	441000ef          	jal	ra,25e2 <write>
}
    19a6:	60e2                	ld	ra,24(sp)
    19a8:	6442                	ld	s0,16(sp)
	int r = write(stdout, buffer, buffer_len);
    19aa:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    19ae:	00001797          	auipc	a5,0x1
    19b2:	1407ad23          	sw	zero,346(a5) # 2b08 <buffer_len>
}
    19b6:	64a2                	ld	s1,8(sp)
    19b8:	8532                	mv	a0,a2
    19ba:	6105                	addi	sp,sp,32
    19bc:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    19be:	42f000ef          	jal	ra,25ec <getpid>
    19c2:	842a                	mv	s0,a0
    19c4:	00001517          	auipc	a0,0x1
    19c8:	05450513          	addi	a0,a0,84 # 2a18 <enable_deadlock_detect+0x15e>
    19cc:	2f7000ef          	jal	ra,24c2 <basename>
    19d0:	872a                	mv	a4,a0
    19d2:	00001617          	auipc	a2,0x1
    19d6:	f5660613          	addi	a2,a2,-170 # 2928 <enable_deadlock_detect+0x6e>
    19da:	05400793          	li	a5,84
    19de:	86a2                	mv	a3,s0
    19e0:	45fd                	li	a1,31
    19e2:	00001517          	auipc	a0,0x1
    19e6:	07650513          	addi	a0,a0,118 # 2a58 <enable_deadlock_detect+0x19e>
    19ea:	9d1ff0ef          	jal	ra,13ba <printf>
    19ee:	557d                	li	a0,-1
    19f0:	42d000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    19f4:	4090                	lw	a2,0(s1)
    19f6:	d659                	beqz	a2,1984 <out_unlocked.constprop.0+0x32>
    19f8:	b745                	j	1998 <out_unlocked.constprop.0+0x46>

00000000000019fa <putchar>:
{
    19fa:	7139                	addi	sp,sp,-64
    19fc:	f426                	sd	s1,40(sp)
	if (buffer_lock_enabled == 1) {
    19fe:	00001497          	auipc	s1,0x1
    1a02:	10a48493          	addi	s1,s1,266 # 2b08 <buffer_len>
    1a06:	1084a703          	lw	a4,264(s1)
{
    1a0a:	f822                	sd	s0,48(sp)
	char byte = c;
    1a0c:	0ff57413          	zext.b	s0,a0
{
    1a10:	fc06                	sd	ra,56(sp)
	char byte = c;
    1a12:	00810fa3          	sb	s0,31(sp)
	if (buffer_lock_enabled == 1) {
    1a16:	4785                	li	a5,1
    1a18:	00f70d63          	beq	a4,a5,1a32 <putchar+0x38>
		len = out_unlocked(s, l);
    1a1c:	01f10513          	addi	a0,sp,31
    1a20:	f33ff0ef          	jal	ra,1952 <out_unlocked.constprop.0>
}
    1a24:	70e2                	ld	ra,56(sp)
    1a26:	7442                	ld	s0,48(sp)
		len = out_unlocked(s, l);
    1a28:	862a                	mv	a2,a0
}
    1a2a:	74a2                	ld	s1,40(sp)
    1a2c:	8532                	mv	a0,a2
    1a2e:	6121                	addi	sp,sp,64
    1a30:	8082                	ret
		mutex_lock(buffer_lock);
    1a32:	10c4a503          	lw	a0,268(s1)
    1a36:	625000ef          	jal	ra,285a <mutex_lock>
		buffer[buffer_len++] = c;
    1a3a:	409c                	lw	a5,0(s1)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a3c:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1a40:	0017861b          	addiw	a2,a5,1
    1a44:	97a6                	add	a5,a5,s1
    1a46:	c090                	sw	a2,0(s1)
    1a48:	00878423          	sb	s0,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1a4c:	02c6c263          	blt	a3,a2,1a70 <putchar+0x76>
    1a50:	47a9                	li	a5,10
    1a52:	06f40d63          	beq	s0,a5,1acc <putchar+0xd2>
    1a56:	4601                	li	a2,0
		mutex_unlock(buffer_lock);
    1a58:	10c4a503          	lw	a0,268(s1)
    1a5c:	e432                	sd	a2,8(sp)
    1a5e:	609000ef          	jal	ra,2866 <mutex_unlock>
    1a62:	6622                	ld	a2,8(sp)
}
    1a64:	70e2                	ld	ra,56(sp)
    1a66:	7442                	ld	s0,48(sp)
    1a68:	74a2                	ld	s1,40(sp)
    1a6a:	8532                	mv	a0,a2
    1a6c:	6121                	addi	sp,sp,64
    1a6e:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1a70:	10000793          	li	a5,256
    1a74:	02f61063          	bne	a2,a5,1a94 <putchar+0x9a>
	int r = write(stdout, buffer, buffer_len);
    1a78:	00001597          	auipc	a1,0x1
    1a7c:	09858593          	addi	a1,a1,152 # 2b10 <buffer>
    1a80:	4505                	li	a0,1
    1a82:	361000ef          	jal	ra,25e2 <write>
    1a86:	0005061b          	sext.w	a2,a0
	buffer_len = 0;
    1a8a:	00001797          	auipc	a5,0x1
    1a8e:	0607af23          	sw	zero,126(a5) # 2b08 <buffer_len>
			if (r < 0) {
    1a92:	b7d9                	j	1a58 <putchar+0x5e>
			assert(buffer_len <= __LINE_WIDTH);
    1a94:	359000ef          	jal	ra,25ec <getpid>
    1a98:	842a                	mv	s0,a0
    1a9a:	00001517          	auipc	a0,0x1
    1a9e:	f7e50513          	addi	a0,a0,-130 # 2a18 <enable_deadlock_detect+0x15e>
    1aa2:	221000ef          	jal	ra,24c2 <basename>
    1aa6:	872a                	mv	a4,a0
    1aa8:	00001617          	auipc	a2,0x1
    1aac:	e8060613          	addi	a2,a2,-384 # 2928 <enable_deadlock_detect+0x6e>
    1ab0:	05400793          	li	a5,84
    1ab4:	86a2                	mv	a3,s0
    1ab6:	45fd                	li	a1,31
    1ab8:	00001517          	auipc	a0,0x1
    1abc:	fa050513          	addi	a0,a0,-96 # 2a58 <enable_deadlock_detect+0x19e>
    1ac0:	8fbff0ef          	jal	ra,13ba <printf>
    1ac4:	557d                	li	a0,-1
    1ac6:	357000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    1aca:	4090                	lw	a2,0(s1)
    1acc:	d651                	beqz	a2,1a58 <putchar+0x5e>
    1ace:	b76d                	j	1a78 <putchar+0x7e>

0000000000001ad0 <puts>:
{
    1ad0:	7139                	addi	sp,sp,-64
    1ad2:	f822                	sd	s0,48(sp)
    1ad4:	f426                	sd	s1,40(sp)
    1ad6:	fc06                	sd	ra,56(sp)
    1ad8:	f04a                	sd	s2,32(sp)
	if (buffer_lock_enabled == 1) {
    1ada:	00001417          	auipc	s0,0x1
    1ade:	02e40413          	addi	s0,s0,46 # 2b08 <buffer_len>
{
    1ae2:	84aa                	mv	s1,a0
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1ae4:	638000ef          	jal	ra,211c <strlen>
	if (buffer_lock_enabled == 1) {
    1ae8:	10842703          	lw	a4,264(s0)
    1aec:	4785                	li	a5,1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1aee:	85aa                	mv	a1,a0
	if (buffer_lock_enabled == 1) {
    1af0:	04f70563          	beq	a4,a5,1b3a <puts+0x6a>
		len = out_unlocked(s, l);
    1af4:	8526                	mv	a0,s1
    1af6:	d51ff0ef          	jal	ra,1846 <out_unlocked>
    1afa:	892a                	mv	s2,a0
    1afc:	54fd                	li	s1,-1
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1afe:	00095963          	bgez	s2,1b10 <puts+0x40>
}
    1b02:	70e2                	ld	ra,56(sp)
    1b04:	7442                	ld	s0,48(sp)
    1b06:	7902                	ld	s2,32(sp)
    1b08:	8526                	mv	a0,s1
    1b0a:	74a2                	ld	s1,40(sp)
    1b0c:	6121                	addi	sp,sp,64
    1b0e:	8082                	ret
	if (buffer_lock_enabled == 1) {
    1b10:	10842703          	lw	a4,264(s0)
	char byte = c;
    1b14:	44a9                	li	s1,10
    1b16:	00910fa3          	sb	s1,31(sp)
	if (buffer_lock_enabled == 1) {
    1b1a:	4785                	li	a5,1
    1b1c:	02f70e63          	beq	a4,a5,1b58 <puts+0x88>
		len = out_unlocked(s, l);
    1b20:	01f10513          	addi	a0,sp,31
    1b24:	e2fff0ef          	jal	ra,1952 <out_unlocked.constprop.0>
}
    1b28:	70e2                	ld	ra,56(sp)
    1b2a:	7442                	ld	s0,48(sp)
	r = -(out(stdout, s, strlen(s)) < 0 || putchar('\n') < 0);
    1b2c:	41f5549b          	sraiw	s1,a0,0x1f
}
    1b30:	7902                	ld	s2,32(sp)
    1b32:	8526                	mv	a0,s1
    1b34:	74a2                	ld	s1,40(sp)
    1b36:	6121                	addi	sp,sp,64
    1b38:	8082                	ret
		mutex_lock(buffer_lock);
    1b3a:	e42a                	sd	a0,8(sp)
    1b3c:	10c42503          	lw	a0,268(s0)
    1b40:	51b000ef          	jal	ra,285a <mutex_lock>
		len = out_unlocked(s, l);
    1b44:	65a2                	ld	a1,8(sp)
    1b46:	8526                	mv	a0,s1
    1b48:	cffff0ef          	jal	ra,1846 <out_unlocked>
    1b4c:	892a                	mv	s2,a0
		mutex_unlock(buffer_lock);
    1b4e:	10c42503          	lw	a0,268(s0)
    1b52:	515000ef          	jal	ra,2866 <mutex_unlock>
    1b56:	b75d                	j	1afc <puts+0x2c>
		mutex_lock(buffer_lock);
    1b58:	10c42503          	lw	a0,268(s0)
    1b5c:	4ff000ef          	jal	ra,285a <mutex_lock>
		buffer[buffer_len++] = c;
    1b60:	401c                	lw	a5,0(s0)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b62:	0ff00693          	li	a3,255
		buffer[buffer_len++] = c;
    1b66:	0017861b          	addiw	a2,a5,1
    1b6a:	97a2                	add	a5,a5,s0
    1b6c:	c010                	sw	a2,0(s0)
    1b6e:	00978423          	sb	s1,8(a5)
		if (buffer_len >= __LINE_WIDTH || c == '\n') {
    1b72:	06c6dc63          	bge	a3,a2,1bea <puts+0x11a>
			assert(buffer_len <= __LINE_WIDTH);
    1b76:	10000793          	li	a5,256
    1b7a:	02f61c63          	bne	a2,a5,1bb2 <puts+0xe2>
	int r = write(stdout, buffer, buffer_len);
    1b7e:	00001597          	auipc	a1,0x1
    1b82:	f9258593          	addi	a1,a1,-110 # 2b10 <buffer>
    1b86:	4505                	li	a0,1
    1b88:	25b000ef          	jal	ra,25e2 <write>
			if (r < 0) {
    1b8c:	2501                	sext.w	a0,a0
	buffer_len = 0;
    1b8e:	00001797          	auipc	a5,0x1
    1b92:	f607ad23          	sw	zero,-134(a5) # 2b08 <buffer_len>
			if (r < 0) {
    1b96:	04054c63          	bltz	a0,1bee <puts+0x11e>
			if (r < buffer_len) {
    1b9a:	4481                	li	s1,0
		mutex_unlock(buffer_lock);
    1b9c:	10c42503          	lw	a0,268(s0)
    1ba0:	4c7000ef          	jal	ra,2866 <mutex_unlock>
}
    1ba4:	70e2                	ld	ra,56(sp)
    1ba6:	7442                	ld	s0,48(sp)
    1ba8:	7902                	ld	s2,32(sp)
    1baa:	8526                	mv	a0,s1
    1bac:	74a2                	ld	s1,40(sp)
    1bae:	6121                	addi	sp,sp,64
    1bb0:	8082                	ret
			assert(buffer_len <= __LINE_WIDTH);
    1bb2:	23b000ef          	jal	ra,25ec <getpid>
    1bb6:	84aa                	mv	s1,a0
    1bb8:	00001517          	auipc	a0,0x1
    1bbc:	e6050513          	addi	a0,a0,-416 # 2a18 <enable_deadlock_detect+0x15e>
    1bc0:	103000ef          	jal	ra,24c2 <basename>
    1bc4:	872a                	mv	a4,a0
    1bc6:	00001617          	auipc	a2,0x1
    1bca:	d6260613          	addi	a2,a2,-670 # 2928 <enable_deadlock_detect+0x6e>
    1bce:	05400793          	li	a5,84
    1bd2:	86a6                	mv	a3,s1
    1bd4:	45fd                	li	a1,31
    1bd6:	00001517          	auipc	a0,0x1
    1bda:	e8250513          	addi	a0,a0,-382 # 2a58 <enable_deadlock_detect+0x19e>
    1bde:	fdcff0ef          	jal	ra,13ba <printf>
    1be2:	557d                	li	a0,-1
    1be4:	239000ef          	jal	ra,261c <exit>
	if (buffer_len == 0)
    1be8:	4010                	lw	a2,0(s0)
    1bea:	da45                	beqz	a2,1b9a <puts+0xca>
    1bec:	bf49                	j	1b7e <puts+0xae>
    1bee:	54fd                	li	s1,-1
    1bf0:	b775                	j	1b9c <puts+0xcc>

0000000000001bf2 <printint.constprop.0>:
static void printint(int xx, int base, int sign)
    1bf2:	715d                	addi	sp,sp,-80
    1bf4:	e486                	sd	ra,72(sp)
    1bf6:	e0a2                	sd	s0,64(sp)
    1bf8:	fc26                	sd	s1,56(sp)
	if (sign && (sign = xx < 0))
    1bfa:	14054363          	bltz	a0,1d40 <printint.constprop.0+0x14e>
		buf[i--] = digits[x % base];
    1bfe:	02b577bb          	remuw	a5,a0,a1
    1c02:	00001617          	auipc	a2,0x1
    1c06:	0ee60613          	addi	a2,a2,238 # 2cf0 <digits>
	buf[16] = 0;
    1c0a:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1c0e:	0005871b          	sext.w	a4,a1
    1c12:	1782                	slli	a5,a5,0x20
    1c14:	9381                	srli	a5,a5,0x20
    1c16:	97b2                	add	a5,a5,a2
    1c18:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c1c:	02b5583b          	divuw	a6,a0,a1
		buf[i--] = digits[x % base];
    1c20:	02f103a3          	sb	a5,39(sp)
	i = 15;
    1c24:	47bd                	li	a5,15
	} while ((x /= base) != 0);
    1c26:	0eb56763          	bltu	a0,a1,1d14 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c2a:	02e877bb          	remuw	a5,a6,a4
    1c2e:	1782                	slli	a5,a5,0x20
    1c30:	9381                	srli	a5,a5,0x20
    1c32:	97b2                	add	a5,a5,a2
    1c34:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1c38:	02e856bb          	divuw	a3,a6,a4
		buf[i--] = digits[x % base];
    1c3c:	02f10323          	sb	a5,38(sp)
    1c40:	47b9                	li	a5,14
	} while ((x /= base) != 0);
    1c42:	0ce86963          	bltu	a6,a4,1d14 <printint.constprop.0+0x122>
		buf[i--] = digits[x % base];
    1c46:	02e6f5bb          	remuw	a1,a3,a4
	} while ((x /= base) != 0);
    1c4a:	02e6d7bb          	divuw	a5,a3,a4
		buf[i--] = digits[x % base];
    1c4e:	1582                	slli	a1,a1,0x20
    1c50:	9181                	srli	a1,a1,0x20
    1c52:	95b2                	add	a1,a1,a2
    1c54:	0005c583          	lbu	a1,0(a1)
    1c58:	02b102a3          	sb	a1,37(sp)
	} while ((x /= base) != 0);
    1c5c:	0007859b          	sext.w	a1,a5
    1c60:	16e6e563          	bltu	a3,a4,1dca <printint.constprop.0+0x1d8>
		buf[i--] = digits[x % base];
    1c64:	02e7f6bb          	remuw	a3,a5,a4
    1c68:	1682                	slli	a3,a3,0x20
    1c6a:	9281                	srli	a3,a3,0x20
    1c6c:	96b2                	add	a3,a3,a2
    1c6e:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c72:	02e7d83b          	divuw	a6,a5,a4
		buf[i--] = digits[x % base];
    1c76:	02d10223          	sb	a3,36(sp)
	} while ((x /= base) != 0);
    1c7a:	16e5e163          	bltu	a1,a4,1ddc <printint.constprop.0+0x1ea>
		buf[i--] = digits[x % base];
    1c7e:	02e876bb          	remuw	a3,a6,a4
    1c82:	1682                	slli	a3,a3,0x20
    1c84:	9281                	srli	a3,a3,0x20
    1c86:	96b2                	add	a3,a3,a2
    1c88:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1c8c:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1c90:	02d101a3          	sb	a3,35(sp)
	} while ((x /= base) != 0);
    1c94:	14e86d63          	bltu	a6,a4,1dee <printint.constprop.0+0x1fc>
		buf[i--] = digits[x % base];
    1c98:	02e5f6bb          	remuw	a3,a1,a4
    1c9c:	1682                	slli	a3,a3,0x20
    1c9e:	9281                	srli	a3,a3,0x20
    1ca0:	96b2                	add	a3,a3,a2
    1ca2:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1ca6:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1caa:	02d10123          	sb	a3,34(sp)
	} while ((x /= base) != 0);
    1cae:	10e5e563          	bltu	a1,a4,1db8 <printint.constprop.0+0x1c6>
		buf[i--] = digits[x % base];
    1cb2:	02e876bb          	remuw	a3,a6,a4
    1cb6:	1682                	slli	a3,a3,0x20
    1cb8:	9281                	srli	a3,a3,0x20
    1cba:	96b2                	add	a3,a3,a2
    1cbc:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cc0:	02e855bb          	divuw	a1,a6,a4
		buf[i--] = digits[x % base];
    1cc4:	02d100a3          	sb	a3,33(sp)
	} while ((x /= base) != 0);
    1cc8:	14e86263          	bltu	a6,a4,1e0c <printint.constprop.0+0x21a>
		buf[i--] = digits[x % base];
    1ccc:	02e5f6bb          	remuw	a3,a1,a4
    1cd0:	1682                	slli	a3,a3,0x20
    1cd2:	9281                	srli	a3,a3,0x20
    1cd4:	96b2                	add	a3,a3,a2
    1cd6:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cda:	02e5d83b          	divuw	a6,a1,a4
		buf[i--] = digits[x % base];
    1cde:	02d10023          	sb	a3,32(sp)
	} while ((x /= base) != 0);
    1ce2:	14e5e463          	bltu	a1,a4,1e2a <printint.constprop.0+0x238>
		buf[i--] = digits[x % base];
    1ce6:	02e876bb          	remuw	a3,a6,a4
    1cea:	1682                	slli	a3,a3,0x20
    1cec:	9281                	srli	a3,a3,0x20
    1cee:	96b2                	add	a3,a3,a2
    1cf0:	0006c683          	lbu	a3,0(a3)
	} while ((x /= base) != 0);
    1cf4:	02e857bb          	divuw	a5,a6,a4
		buf[i--] = digits[x % base];
    1cf8:	00d10fa3          	sb	a3,31(sp)
	} while ((x /= base) != 0);
    1cfc:	14e86063          	bltu	a6,a4,1e3c <printint.constprop.0+0x24a>
		buf[i--] = digits[x % base];
    1d00:	1782                	slli	a5,a5,0x20
    1d02:	9381                	srli	a5,a5,0x20
    1d04:	97b2                	add	a5,a5,a2
    1d06:	0007c703          	lbu	a4,0(a5)
    1d0a:	4799                	li	a5,6
    1d0c:	00e10f23          	sb	a4,30(sp)
	if (sign)
    1d10:	10054763          	bltz	a0,1e1e <printint.constprop.0+0x22c>
	if (buffer_lock_enabled == 1) {
    1d14:	00001497          	auipc	s1,0x1
    1d18:	df448493          	addi	s1,s1,-524 # 2b08 <buffer_len>
    1d1c:	1084a683          	lw	a3,264(s1)
	out(stdout, buf + i, 16 - i);
    1d20:	0828                	addi	a0,sp,24
    1d22:	45c1                	li	a1,16
	if (buffer_lock_enabled == 1) {
    1d24:	4705                	li	a4,1
	out(stdout, buf + i, 16 - i);
    1d26:	00f50433          	add	s0,a0,a5
    1d2a:	9d9d                	subw	a1,a1,a5
	if (buffer_lock_enabled == 1) {
    1d2c:	06e68463          	beq	a3,a4,1d94 <printint.constprop.0+0x1a2>
		len = out_unlocked(s, l);
    1d30:	8522                	mv	a0,s0
    1d32:	b15ff0ef          	jal	ra,1846 <out_unlocked>
}
    1d36:	60a6                	ld	ra,72(sp)
    1d38:	6406                	ld	s0,64(sp)
    1d3a:	74e2                	ld	s1,56(sp)
    1d3c:	6161                	addi	sp,sp,80
    1d3e:	8082                	ret
		x = -xx;
    1d40:	40a0083b          	negw	a6,a0
		buf[i--] = digits[x % base];
    1d44:	02b877bb          	remuw	a5,a6,a1
    1d48:	00001617          	auipc	a2,0x1
    1d4c:	fa860613          	addi	a2,a2,-88 # 2cf0 <digits>
	buf[16] = 0;
    1d50:	02010423          	sb	zero,40(sp)
		buf[i--] = digits[x % base];
    1d54:	0005871b          	sext.w	a4,a1
    1d58:	1782                	slli	a5,a5,0x20
    1d5a:	9381                	srli	a5,a5,0x20
    1d5c:	97b2                	add	a5,a5,a2
    1d5e:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d62:	02b858bb          	divuw	a7,a6,a1
		buf[i--] = digits[x % base];
    1d66:	02f103a3          	sb	a5,39(sp)
	} while ((x /= base) != 0);
    1d6a:	08b86b63          	bltu	a6,a1,1e00 <printint.constprop.0+0x20e>
		buf[i--] = digits[x % base];
    1d6e:	02e8f7bb          	remuw	a5,a7,a4
    1d72:	1782                	slli	a5,a5,0x20
    1d74:	9381                	srli	a5,a5,0x20
    1d76:	97b2                	add	a5,a5,a2
    1d78:	0007c783          	lbu	a5,0(a5)
	} while ((x /= base) != 0);
    1d7c:	02e8d6bb          	divuw	a3,a7,a4
		buf[i--] = digits[x % base];
    1d80:	02f10323          	sb	a5,38(sp)
	} while ((x /= base) != 0);
    1d84:	ece8f1e3          	bgeu	a7,a4,1c46 <printint.constprop.0+0x54>
		buf[i--] = '-';
    1d88:	02d00793          	li	a5,45
    1d8c:	02f102a3          	sb	a5,37(sp)
		buf[i--] = digits[x % base];
    1d90:	47b5                	li	a5,13
    1d92:	b749                	j	1d14 <printint.constprop.0+0x122>
		mutex_lock(buffer_lock);
    1d94:	10c4a503          	lw	a0,268(s1)
    1d98:	e42e                	sd	a1,8(sp)
    1d9a:	2c1000ef          	jal	ra,285a <mutex_lock>
		len = out_unlocked(s, l);
    1d9e:	65a2                	ld	a1,8(sp)
    1da0:	8522                	mv	a0,s0
    1da2:	aa5ff0ef          	jal	ra,1846 <out_unlocked>
		mutex_unlock(buffer_lock);
    1da6:	10c4a503          	lw	a0,268(s1)
    1daa:	2bd000ef          	jal	ra,2866 <mutex_unlock>
}
    1dae:	60a6                	ld	ra,72(sp)
    1db0:	6406                	ld	s0,64(sp)
    1db2:	74e2                	ld	s1,56(sp)
    1db4:	6161                	addi	sp,sp,80
    1db6:	8082                	ret
		buf[i--] = digits[x % base];
    1db8:	47a9                	li	a5,10
	if (sign)
    1dba:	f4055de3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dbe:	02d00793          	li	a5,45
    1dc2:	02f100a3          	sb	a5,33(sp)
		buf[i--] = digits[x % base];
    1dc6:	47a5                	li	a5,9
    1dc8:	b7b1                	j	1d14 <printint.constprop.0+0x122>
    1dca:	47b5                	li	a5,13
	if (sign)
    1dcc:	f40554e3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1dd0:	02d00793          	li	a5,45
    1dd4:	02f10223          	sb	a5,36(sp)
		buf[i--] = digits[x % base];
    1dd8:	47b1                	li	a5,12
    1dda:	bf2d                	j	1d14 <printint.constprop.0+0x122>
    1ddc:	47b1                	li	a5,12
	if (sign)
    1dde:	f2055be3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1de2:	02d00793          	li	a5,45
    1de6:	02f101a3          	sb	a5,35(sp)
		buf[i--] = digits[x % base];
    1dea:	47ad                	li	a5,11
    1dec:	b725                	j	1d14 <printint.constprop.0+0x122>
    1dee:	47ad                	li	a5,11
	if (sign)
    1df0:	f20552e3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1df4:	02d00793          	li	a5,45
    1df8:	02f10123          	sb	a5,34(sp)
		buf[i--] = digits[x % base];
    1dfc:	47a9                	li	a5,10
    1dfe:	bf19                	j	1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e00:	02d00793          	li	a5,45
    1e04:	02f10323          	sb	a5,38(sp)
		buf[i--] = digits[x % base];
    1e08:	47b9                	li	a5,14
    1e0a:	b729                	j	1d14 <printint.constprop.0+0x122>
    1e0c:	47a5                	li	a5,9
	if (sign)
    1e0e:	f00553e3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e12:	02d00793          	li	a5,45
    1e16:	02f10023          	sb	a5,32(sp)
		buf[i--] = digits[x % base];
    1e1a:	47a1                	li	a5,8
    1e1c:	bde5                	j	1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e1e:	02d00793          	li	a5,45
    1e22:	00f10ea3          	sb	a5,29(sp)
		buf[i--] = digits[x % base];
    1e26:	4795                	li	a5,5
    1e28:	b5f5                	j	1d14 <printint.constprop.0+0x122>
    1e2a:	47a1                	li	a5,8
	if (sign)
    1e2c:	ee0554e3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e30:	02d00793          	li	a5,45
    1e34:	00f10fa3          	sb	a5,31(sp)
		buf[i--] = digits[x % base];
    1e38:	479d                	li	a5,7
    1e3a:	bde9                	j	1d14 <printint.constprop.0+0x122>
    1e3c:	479d                	li	a5,7
	if (sign)
    1e3e:	ec055be3          	bgez	a0,1d14 <printint.constprop.0+0x122>
		buf[i--] = '-';
    1e42:	02d00793          	li	a5,45
    1e46:	00f10f23          	sb	a5,30(sp)
		buf[i--] = digits[x % base];
    1e4a:	4799                	li	a5,6
    1e4c:	b5e1                	j	1d14 <printint.constprop.0+0x122>

0000000000001e4e <isspace>:
#define HIGHS (ONES * (UCHAR_MAX / 2 + 1))
#define HASZERO(x) (((x)-ONES) & ~(x)&HIGHS)

int isspace(int c)
{
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e4e:	02000793          	li	a5,32
    1e52:	00f50663          	beq	a0,a5,1e5e <isspace+0x10>
    1e56:	355d                	addiw	a0,a0,-9
    1e58:	00553513          	sltiu	a0,a0,5
    1e5c:	8082                	ret
    1e5e:	4505                	li	a0,1
}
    1e60:	8082                	ret

0000000000001e62 <isdigit>:

int isdigit(int c)
{
	return (unsigned)c - '0' < 10;
    1e62:	fd05051b          	addiw	a0,a0,-48
}
    1e66:	00a53513          	sltiu	a0,a0,10
    1e6a:	8082                	ret

0000000000001e6c <atoi>:
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e6c:	02000613          	li	a2,32
    1e70:	4591                	li	a1,4

int atoi(const char *s)
{
	int n = 0, neg = 0;
	while (isspace(*s))
    1e72:	00054783          	lbu	a5,0(a0)
	return c == ' ' || (unsigned)c - '\t' < 5;
    1e76:	ff77869b          	addiw	a3,a5,-9
    1e7a:	04c78c63          	beq	a5,a2,1ed2 <atoi+0x66>
    1e7e:	0007871b          	sext.w	a4,a5
    1e82:	04d5f863          	bgeu	a1,a3,1ed2 <atoi+0x66>
		s++;
	switch (*s) {
    1e86:	02b00693          	li	a3,43
    1e8a:	04d78963          	beq	a5,a3,1edc <atoi+0x70>
    1e8e:	02d00693          	li	a3,45
    1e92:	06d78263          	beq	a5,a3,1ef6 <atoi+0x8a>
		neg = 1;
	case '+':
		s++;
	}
	/* Compute n as a negative number to avoid overflow on INT_MIN */
	while (isdigit(*s))
    1e96:	fd07061b          	addiw	a2,a4,-48
    1e9a:	47a5                	li	a5,9
    1e9c:	86aa                	mv	a3,a0
	int n = 0, neg = 0;
    1e9e:	4e01                	li	t3,0
	while (isdigit(*s))
    1ea0:	04c7e963          	bltu	a5,a2,1ef2 <atoi+0x86>
	int n = 0, neg = 0;
    1ea4:	4501                	li	a0,0
	while (isdigit(*s))
    1ea6:	4825                	li	a6,9
    1ea8:	0016c603          	lbu	a2,1(a3)
		n = 10 * n - (*s++ - '0');
    1eac:	0025179b          	slliw	a5,a0,0x2
    1eb0:	9fa9                	addw	a5,a5,a0
    1eb2:	fd07031b          	addiw	t1,a4,-48
    1eb6:	0017989b          	slliw	a7,a5,0x1
	while (isdigit(*s))
    1eba:	fd06059b          	addiw	a1,a2,-48
		n = 10 * n - (*s++ - '0');
    1ebe:	0685                	addi	a3,a3,1
    1ec0:	4068853b          	subw	a0,a7,t1
	while (isdigit(*s))
    1ec4:	0006071b          	sext.w	a4,a2
    1ec8:	feb870e3          	bgeu	a6,a1,1ea8 <atoi+0x3c>
	return neg ? n : -n;
    1ecc:	000e0563          	beqz	t3,1ed6 <atoi+0x6a>
}
    1ed0:	8082                	ret
		s++;
    1ed2:	0505                	addi	a0,a0,1
    1ed4:	bf79                	j	1e72 <atoi+0x6>
	return neg ? n : -n;
    1ed6:	4113053b          	subw	a0,t1,a7
    1eda:	8082                	ret
	while (isdigit(*s))
    1edc:	00154703          	lbu	a4,1(a0)
    1ee0:	47a5                	li	a5,9
		s++;
    1ee2:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1ee6:	fd07061b          	addiw	a2,a4,-48
	int n = 0, neg = 0;
    1eea:	4e01                	li	t3,0
	while (isdigit(*s))
    1eec:	2701                	sext.w	a4,a4
    1eee:	fac7fbe3          	bgeu	a5,a2,1ea4 <atoi+0x38>
    1ef2:	4501                	li	a0,0
}
    1ef4:	8082                	ret
	while (isdigit(*s))
    1ef6:	00154703          	lbu	a4,1(a0)
    1efa:	47a5                	li	a5,9
		s++;
    1efc:	00150693          	addi	a3,a0,1
	while (isdigit(*s))
    1f00:	fd07061b          	addiw	a2,a4,-48
    1f04:	2701                	sext.w	a4,a4
    1f06:	fec7e6e3          	bltu	a5,a2,1ef2 <atoi+0x86>
		neg = 1;
    1f0a:	4e05                	li	t3,1
    1f0c:	bf61                	j	1ea4 <atoi+0x38>

0000000000001f0e <memset>:

void *memset(void *dest, int c, size_t n)
{
	char *p = dest;
	for (int i = 0; i < n; ++i, *(p++) = c)
    1f0e:	16060d63          	beqz	a2,2088 <memset+0x17a>
    1f12:	40a007b3          	neg	a5,a0
    1f16:	8b9d                	andi	a5,a5,7
    1f18:	00778693          	addi	a3,a5,7
    1f1c:	482d                	li	a6,11
    1f1e:	0ff5f713          	zext.b	a4,a1
    1f22:	fff60593          	addi	a1,a2,-1
    1f26:	1706e263          	bltu	a3,a6,208a <memset+0x17c>
    1f2a:	16d5ea63          	bltu	a1,a3,209e <memset+0x190>
    1f2e:	16078563          	beqz	a5,2098 <memset+0x18a>
    1f32:	00e50023          	sb	a4,0(a0)
    1f36:	4685                	li	a3,1
    1f38:	00150593          	addi	a1,a0,1
    1f3c:	14d78c63          	beq	a5,a3,2094 <memset+0x186>
    1f40:	00e500a3          	sb	a4,1(a0)
    1f44:	4689                	li	a3,2
    1f46:	00250593          	addi	a1,a0,2
    1f4a:	14d78d63          	beq	a5,a3,20a4 <memset+0x196>
    1f4e:	00e50123          	sb	a4,2(a0)
    1f52:	468d                	li	a3,3
    1f54:	00350593          	addi	a1,a0,3
    1f58:	12d78b63          	beq	a5,a3,208e <memset+0x180>
    1f5c:	00e501a3          	sb	a4,3(a0)
    1f60:	4691                	li	a3,4
    1f62:	00450593          	addi	a1,a0,4
    1f66:	14d78163          	beq	a5,a3,20a8 <memset+0x19a>
    1f6a:	00e50223          	sb	a4,4(a0)
    1f6e:	4695                	li	a3,5
    1f70:	00550593          	addi	a1,a0,5
    1f74:	12d78c63          	beq	a5,a3,20ac <memset+0x19e>
    1f78:	00e502a3          	sb	a4,5(a0)
    1f7c:	469d                	li	a3,7
    1f7e:	00650593          	addi	a1,a0,6
    1f82:	12d79763          	bne	a5,a3,20b0 <memset+0x1a2>
    1f86:	00750593          	addi	a1,a0,7
    1f8a:	00e50323          	sb	a4,6(a0)
    1f8e:	481d                	li	a6,7
    1f90:	00871693          	slli	a3,a4,0x8
    1f94:	01071893          	slli	a7,a4,0x10
    1f98:	8ed9                	or	a3,a3,a4
    1f9a:	01871313          	slli	t1,a4,0x18
    1f9e:	0116e6b3          	or	a3,a3,a7
    1fa2:	0066e6b3          	or	a3,a3,t1
    1fa6:	02071893          	slli	a7,a4,0x20
    1faa:	02871e13          	slli	t3,a4,0x28
    1fae:	0116e6b3          	or	a3,a3,a7
    1fb2:	40f60333          	sub	t1,a2,a5
    1fb6:	03071893          	slli	a7,a4,0x30
    1fba:	01c6e6b3          	or	a3,a3,t3
    1fbe:	0116e6b3          	or	a3,a3,a7
    1fc2:	03871e13          	slli	t3,a4,0x38
    1fc6:	97aa                	add	a5,a5,a0
    1fc8:	ff837893          	andi	a7,t1,-8
    1fcc:	01c6e6b3          	or	a3,a3,t3
    1fd0:	98be                	add	a7,a7,a5
    1fd2:	e394                	sd	a3,0(a5)
    1fd4:	07a1                	addi	a5,a5,8
    1fd6:	ff179ee3          	bne	a5,a7,1fd2 <memset+0xc4>
    1fda:	ff837893          	andi	a7,t1,-8
    1fde:	011587b3          	add	a5,a1,a7
    1fe2:	010886bb          	addw	a3,a7,a6
    1fe6:	0b130663          	beq	t1,a7,2092 <memset+0x184>
    1fea:	00e78023          	sb	a4,0(a5)
    1fee:	0016859b          	addiw	a1,a3,1
    1ff2:	08c5fb63          	bgeu	a1,a2,2088 <memset+0x17a>
    1ff6:	00e780a3          	sb	a4,1(a5)
    1ffa:	0026859b          	addiw	a1,a3,2
    1ffe:	08c5f563          	bgeu	a1,a2,2088 <memset+0x17a>
    2002:	00e78123          	sb	a4,2(a5)
    2006:	0036859b          	addiw	a1,a3,3
    200a:	06c5ff63          	bgeu	a1,a2,2088 <memset+0x17a>
    200e:	00e781a3          	sb	a4,3(a5)
    2012:	0046859b          	addiw	a1,a3,4
    2016:	06c5f963          	bgeu	a1,a2,2088 <memset+0x17a>
    201a:	00e78223          	sb	a4,4(a5)
    201e:	0056859b          	addiw	a1,a3,5
    2022:	06c5f363          	bgeu	a1,a2,2088 <memset+0x17a>
    2026:	00e782a3          	sb	a4,5(a5)
    202a:	0066859b          	addiw	a1,a3,6
    202e:	04c5fd63          	bgeu	a1,a2,2088 <memset+0x17a>
    2032:	00e78323          	sb	a4,6(a5)
    2036:	0076859b          	addiw	a1,a3,7
    203a:	04c5f763          	bgeu	a1,a2,2088 <memset+0x17a>
    203e:	00e783a3          	sb	a4,7(a5)
    2042:	0086859b          	addiw	a1,a3,8
    2046:	04c5f163          	bgeu	a1,a2,2088 <memset+0x17a>
    204a:	00e78423          	sb	a4,8(a5)
    204e:	0096859b          	addiw	a1,a3,9
    2052:	02c5fb63          	bgeu	a1,a2,2088 <memset+0x17a>
    2056:	00e784a3          	sb	a4,9(a5)
    205a:	00a6859b          	addiw	a1,a3,10
    205e:	02c5f563          	bgeu	a1,a2,2088 <memset+0x17a>
    2062:	00e78523          	sb	a4,10(a5)
    2066:	00b6859b          	addiw	a1,a3,11
    206a:	00c5ff63          	bgeu	a1,a2,2088 <memset+0x17a>
    206e:	00e785a3          	sb	a4,11(a5)
    2072:	00c6859b          	addiw	a1,a3,12
    2076:	00c5f963          	bgeu	a1,a2,2088 <memset+0x17a>
    207a:	00e78623          	sb	a4,12(a5)
    207e:	26b5                	addiw	a3,a3,13
    2080:	00c6f463          	bgeu	a3,a2,2088 <memset+0x17a>
    2084:	00e786a3          	sb	a4,13(a5)
		;
	return dest;
}
    2088:	8082                	ret
    208a:	46ad                	li	a3,11
    208c:	bd79                	j	1f2a <memset+0x1c>
	for (int i = 0; i < n; ++i, *(p++) = c)
    208e:	480d                	li	a6,3
    2090:	b701                	j	1f90 <memset+0x82>
    2092:	8082                	ret
    2094:	4805                	li	a6,1
    2096:	bded                	j	1f90 <memset+0x82>
    2098:	85aa                	mv	a1,a0
    209a:	4801                	li	a6,0
    209c:	bdd5                	j	1f90 <memset+0x82>
    209e:	87aa                	mv	a5,a0
    20a0:	4681                	li	a3,0
    20a2:	b7a1                	j	1fea <memset+0xdc>
    20a4:	4809                	li	a6,2
    20a6:	b5ed                	j	1f90 <memset+0x82>
    20a8:	4811                	li	a6,4
    20aa:	b5dd                	j	1f90 <memset+0x82>
    20ac:	4815                	li	a6,5
    20ae:	b5cd                	j	1f90 <memset+0x82>
    20b0:	4819                	li	a6,6
    20b2:	bdf9                	j	1f90 <memset+0x82>

00000000000020b4 <strcmp>:

int strcmp(const char *l, const char *r)
{
	for (; *l == *r && *l; l++, r++)
    20b4:	00054783          	lbu	a5,0(a0)
    20b8:	0005c703          	lbu	a4,0(a1)
    20bc:	00e79863          	bne	a5,a4,20cc <strcmp+0x18>
    20c0:	0505                	addi	a0,a0,1
    20c2:	0585                	addi	a1,a1,1
    20c4:	fbe5                	bnez	a5,20b4 <strcmp>
    20c6:	4501                	li	a0,0
		;
	return *(unsigned char *)l - *(unsigned char *)r;
}
    20c8:	9d19                	subw	a0,a0,a4
    20ca:	8082                	ret
	return *(unsigned char *)l - *(unsigned char *)r;
    20cc:	0007851b          	sext.w	a0,a5
    20d0:	bfe5                	j	20c8 <strcmp+0x14>

00000000000020d2 <strncmp>:

int strncmp(const char *_l, const char *_r, size_t n)
{
	const unsigned char *l = (void *)_l, *r = (void *)_r;
	if (!n--)
    20d2:	ca15                	beqz	a2,2106 <strncmp+0x34>
		return 0;
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20d4:	00054783          	lbu	a5,0(a0)
	if (!n--)
    20d8:	167d                	addi	a2,a2,-1
    20da:	00c506b3          	add	a3,a0,a2
	for (; *l && *r && n && *l == *r; l++, r++, n--)
    20de:	eb99                	bnez	a5,20f4 <strncmp+0x22>
    20e0:	a815                	j	2114 <strncmp+0x42>
    20e2:	00a68e63          	beq	a3,a0,20fe <strncmp+0x2c>
    20e6:	0505                	addi	a0,a0,1
    20e8:	00f71b63          	bne	a4,a5,20fe <strncmp+0x2c>
    20ec:	00054783          	lbu	a5,0(a0)
    20f0:	cf89                	beqz	a5,210a <strncmp+0x38>
    20f2:	85b2                	mv	a1,a2
    20f4:	0005c703          	lbu	a4,0(a1)
    20f8:	00158613          	addi	a2,a1,1
    20fc:	f37d                	bnez	a4,20e2 <strncmp+0x10>
		;
	return *l - *r;
    20fe:	0007851b          	sext.w	a0,a5
    2102:	9d19                	subw	a0,a0,a4
    2104:	8082                	ret
		return 0;
    2106:	4501                	li	a0,0
}
    2108:	8082                	ret
	return *l - *r;
    210a:	0015c703          	lbu	a4,1(a1)
    210e:	4501                	li	a0,0
    2110:	9d19                	subw	a0,a0,a4
    2112:	8082                	ret
    2114:	0005c703          	lbu	a4,0(a1)
    2118:	4501                	li	a0,0
    211a:	b7e5                	j	2102 <strncmp+0x30>

000000000000211c <strlen>:
size_t strlen(const char *s)
{
	const char *a = s;
	typedef size_t __attribute__((__may_alias__)) word;
	const word *w;
	for (; (uintptr_t)s % SS; s++)
    211c:	00757793          	andi	a5,a0,7
    2120:	cf89                	beqz	a5,213a <strlen+0x1e>
    2122:	87aa                	mv	a5,a0
    2124:	a029                	j	212e <strlen+0x12>
    2126:	0785                	addi	a5,a5,1
    2128:	0077f713          	andi	a4,a5,7
    212c:	cb01                	beqz	a4,213c <strlen+0x20>
		if (!*s)
    212e:	0007c703          	lbu	a4,0(a5)
    2132:	fb75                	bnez	a4,2126 <strlen+0xa>
	for (w = (const void *)s; !HASZERO(*w); w++)
		;
	s = (const void *)w;
	for (; *s; s++)
		;
	return s - a;
    2134:	40a78533          	sub	a0,a5,a0
}
    2138:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    213a:	87aa                	mv	a5,a0
	for (w = (const void *)s; !HASZERO(*w); w++)
    213c:	6394                	ld	a3,0(a5)
    213e:	00001597          	auipc	a1,0x1
    2142:	9b25b583          	ld	a1,-1614(a1) # 2af0 <enable_deadlock_detect+0x236>
    2146:	00001617          	auipc	a2,0x1
    214a:	9b263603          	ld	a2,-1614(a2) # 2af8 <enable_deadlock_detect+0x23e>
    214e:	a019                	j	2154 <strlen+0x38>
    2150:	6794                	ld	a3,8(a5)
    2152:	07a1                	addi	a5,a5,8
    2154:	00b68733          	add	a4,a3,a1
    2158:	fff6c693          	not	a3,a3
    215c:	8f75                	and	a4,a4,a3
    215e:	8f71                	and	a4,a4,a2
    2160:	db65                	beqz	a4,2150 <strlen+0x34>
	for (; *s; s++)
    2162:	0007c703          	lbu	a4,0(a5)
    2166:	d779                	beqz	a4,2134 <strlen+0x18>
    2168:	0017c703          	lbu	a4,1(a5)
    216c:	0785                	addi	a5,a5,1
    216e:	d379                	beqz	a4,2134 <strlen+0x18>
    2170:	0017c703          	lbu	a4,1(a5)
    2174:	0785                	addi	a5,a5,1
    2176:	fb6d                	bnez	a4,2168 <strlen+0x4c>
    2178:	bf75                	j	2134 <strlen+0x18>

000000000000217a <memchr>:

void *memchr(const void *src, int c, size_t n)
{
	const unsigned char *s = src;
	c = (unsigned char)c;
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    217a:	00757713          	andi	a4,a0,7
{
    217e:	87aa                	mv	a5,a0
	c = (unsigned char)c;
    2180:	0ff5f593          	zext.b	a1,a1
	for (; ((uintptr_t)s & ALIGN) && n && *s != c; s++, n--)
    2184:	cb19                	beqz	a4,219a <memchr+0x20>
    2186:	ce25                	beqz	a2,21fe <memchr+0x84>
    2188:	0007c703          	lbu	a4,0(a5)
    218c:	04b70e63          	beq	a4,a1,21e8 <memchr+0x6e>
    2190:	0785                	addi	a5,a5,1
    2192:	0077f713          	andi	a4,a5,7
    2196:	167d                	addi	a2,a2,-1
    2198:	f77d                	bnez	a4,2186 <memchr+0xc>
			;
		s = (const void *)w;
	}
	for (; n && *s != c; s++, n--)
		;
	return n ? (void *)s : 0;
    219a:	4501                	li	a0,0
	if (n && *s != c) {
    219c:	c235                	beqz	a2,2200 <memchr+0x86>
    219e:	0007c703          	lbu	a4,0(a5)
    21a2:	04b70363          	beq	a4,a1,21e8 <memchr+0x6e>
		size_t k = ONES * c;
    21a6:	00001517          	auipc	a0,0x1
    21aa:	95a53503          	ld	a0,-1702(a0) # 2b00 <enable_deadlock_detect+0x246>
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21ae:	471d                	li	a4,7
		size_t k = ONES * c;
    21b0:	02a58533          	mul	a0,a1,a0
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21b4:	02c77a63          	bgeu	a4,a2,21e8 <memchr+0x6e>
    21b8:	00001897          	auipc	a7,0x1
    21bc:	9388b883          	ld	a7,-1736(a7) # 2af0 <enable_deadlock_detect+0x236>
    21c0:	00001817          	auipc	a6,0x1
    21c4:	93883803          	ld	a6,-1736(a6) # 2af8 <enable_deadlock_detect+0x23e>
    21c8:	431d                	li	t1,7
    21ca:	a029                	j	21d4 <memchr+0x5a>
		     w++, n -= SS)
    21cc:	1661                	addi	a2,a2,-8
    21ce:	07a1                	addi	a5,a5,8
		for (w = (const void *)s; n >= SS && !HASZERO(*w ^ k);
    21d0:	02c37963          	bgeu	t1,a2,2202 <memchr+0x88>
    21d4:	6398                	ld	a4,0(a5)
    21d6:	8f29                	xor	a4,a4,a0
    21d8:	011706b3          	add	a3,a4,a7
    21dc:	fff74713          	not	a4,a4
    21e0:	8f75                	and	a4,a4,a3
    21e2:	01077733          	and	a4,a4,a6
    21e6:	d37d                	beqz	a4,21cc <memchr+0x52>
{
    21e8:	853e                	mv	a0,a5
    21ea:	97b2                	add	a5,a5,a2
    21ec:	a021                	j	21f4 <memchr+0x7a>
	for (; n && *s != c; s++, n--)
    21ee:	0505                	addi	a0,a0,1
    21f0:	00f50763          	beq	a0,a5,21fe <memchr+0x84>
    21f4:	00054703          	lbu	a4,0(a0)
    21f8:	feb71be3          	bne	a4,a1,21ee <memchr+0x74>
    21fc:	8082                	ret
	return n ? (void *)s : 0;
    21fe:	4501                	li	a0,0
}
    2200:	8082                	ret
	return n ? (void *)s : 0;
    2202:	4501                	li	a0,0
	for (; n && *s != c; s++, n--)
    2204:	f275                	bnez	a2,21e8 <memchr+0x6e>
}
    2206:	8082                	ret

0000000000002208 <strnlen>:

size_t strnlen(const char *s, size_t n)
{
    2208:	1101                	addi	sp,sp,-32
    220a:	e822                	sd	s0,16(sp)
	const char *p = memchr(s, 0, n);
    220c:	862e                	mv	a2,a1
{
    220e:	842e                	mv	s0,a1
	const char *p = memchr(s, 0, n);
    2210:	4581                	li	a1,0
{
    2212:	e426                	sd	s1,8(sp)
    2214:	ec06                	sd	ra,24(sp)
    2216:	84aa                	mv	s1,a0
	const char *p = memchr(s, 0, n);
    2218:	f63ff0ef          	jal	ra,217a <memchr>
	return p ? p - s : n;
    221c:	c519                	beqz	a0,222a <strnlen+0x22>
}
    221e:	60e2                	ld	ra,24(sp)
    2220:	6442                	ld	s0,16(sp)
	return p ? p - s : n;
    2222:	8d05                	sub	a0,a0,s1
}
    2224:	64a2                	ld	s1,8(sp)
    2226:	6105                	addi	sp,sp,32
    2228:	8082                	ret
    222a:	60e2                	ld	ra,24(sp)
	return p ? p - s : n;
    222c:	8522                	mv	a0,s0
}
    222e:	6442                	ld	s0,16(sp)
    2230:	64a2                	ld	s1,8(sp)
    2232:	6105                	addi	sp,sp,32
    2234:	8082                	ret

0000000000002236 <stpcpy>:
char *stpcpy(char *restrict d, const char *s)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if ((uintptr_t)s % SS == (uintptr_t)d % SS) {
    2236:	00a5c7b3          	xor	a5,a1,a0
    223a:	8b9d                	andi	a5,a5,7
    223c:	eb95                	bnez	a5,2270 <stpcpy+0x3a>
		for (; (uintptr_t)s % SS; s++, d++)
    223e:	0075f793          	andi	a5,a1,7
    2242:	e7b1                	bnez	a5,228e <stpcpy+0x58>
			if (!(*d = *s))
				return d;
		wd = (void *)d;
		ws = (const void *)s;
		for (; !HASZERO(*ws); *wd++ = *ws++)
    2244:	6198                	ld	a4,0(a1)
    2246:	00001617          	auipc	a2,0x1
    224a:	8aa63603          	ld	a2,-1878(a2) # 2af0 <enable_deadlock_detect+0x236>
    224e:	00001817          	auipc	a6,0x1
    2252:	8aa83803          	ld	a6,-1878(a6) # 2af8 <enable_deadlock_detect+0x23e>
    2256:	a029                	j	2260 <stpcpy+0x2a>
    2258:	05a1                	addi	a1,a1,8
    225a:	e118                	sd	a4,0(a0)
    225c:	6198                	ld	a4,0(a1)
    225e:	0521                	addi	a0,a0,8
    2260:	00c707b3          	add	a5,a4,a2
    2264:	fff74693          	not	a3,a4
    2268:	8ff5                	and	a5,a5,a3
    226a:	0107f7b3          	and	a5,a5,a6
    226e:	d7ed                	beqz	a5,2258 <stpcpy+0x22>
			;
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; (*d = *s); s++, d++)
    2270:	0005c783          	lbu	a5,0(a1)
    2274:	00f50023          	sb	a5,0(a0)
    2278:	c785                	beqz	a5,22a0 <stpcpy+0x6a>
    227a:	0015c783          	lbu	a5,1(a1)
    227e:	0505                	addi	a0,a0,1
    2280:	0585                	addi	a1,a1,1
    2282:	00f50023          	sb	a5,0(a0)
    2286:	fbf5                	bnez	a5,227a <stpcpy+0x44>
		;
	return d;
}
    2288:	8082                	ret
		for (; (uintptr_t)s % SS; s++, d++)
    228a:	0505                	addi	a0,a0,1
    228c:	df45                	beqz	a4,2244 <stpcpy+0xe>
			if (!(*d = *s))
    228e:	0005c783          	lbu	a5,0(a1)
		for (; (uintptr_t)s % SS; s++, d++)
    2292:	0585                	addi	a1,a1,1
    2294:	0075f713          	andi	a4,a1,7
			if (!(*d = *s))
    2298:	00f50023          	sb	a5,0(a0)
    229c:	f7fd                	bnez	a5,228a <stpcpy+0x54>
}
    229e:	8082                	ret
    22a0:	8082                	ret

00000000000022a2 <stpncpy>:
char *stpncpy(char *restrict d, const char *s, size_t n)
{
	typedef size_t __attribute__((__may_alias__)) word;
	word *wd;
	const word *ws;
	if (((uintptr_t)s & ALIGN) == ((uintptr_t)d & ALIGN)) {
    22a2:	00a5c7b3          	xor	a5,a1,a0
    22a6:	8b9d                	andi	a5,a5,7
    22a8:	1a079863          	bnez	a5,2458 <stpncpy+0x1b6>
		for (; ((uintptr_t)s & ALIGN) && n && (*d = *s); n--, s++, d++)
    22ac:	0075f793          	andi	a5,a1,7
    22b0:	16078463          	beqz	a5,2418 <stpncpy+0x176>
    22b4:	ea01                	bnez	a2,22c4 <stpncpy+0x22>
    22b6:	a421                	j	24be <stpncpy+0x21c>
    22b8:	167d                	addi	a2,a2,-1
    22ba:	0505                	addi	a0,a0,1
    22bc:	14070e63          	beqz	a4,2418 <stpncpy+0x176>
    22c0:	1a060863          	beqz	a2,2470 <stpncpy+0x1ce>
    22c4:	0005c783          	lbu	a5,0(a1)
    22c8:	0585                	addi	a1,a1,1
    22ca:	0075f713          	andi	a4,a1,7
    22ce:	00f50023          	sb	a5,0(a0)
    22d2:	f3fd                	bnez	a5,22b8 <stpncpy+0x16>
    22d4:	4805                	li	a6,1
    22d6:	1a061863          	bnez	a2,2486 <stpncpy+0x1e4>
    22da:	40a007b3          	neg	a5,a0
    22de:	8b9d                	andi	a5,a5,7
    22e0:	4681                	li	a3,0
    22e2:	18061a63          	bnez	a2,2476 <stpncpy+0x1d4>
    22e6:	00778713          	addi	a4,a5,7
    22ea:	45ad                	li	a1,11
    22ec:	18b76363          	bltu	a4,a1,2472 <stpncpy+0x1d0>
    22f0:	1ae6eb63          	bltu	a3,a4,24a6 <stpncpy+0x204>
    22f4:	1a078363          	beqz	a5,249a <stpncpy+0x1f8>
	for (int i = 0; i < n; ++i, *(p++) = c)
    22f8:	00050023          	sb	zero,0(a0)
    22fc:	4685                	li	a3,1
    22fe:	00150713          	addi	a4,a0,1
    2302:	18d78f63          	beq	a5,a3,24a0 <stpncpy+0x1fe>
    2306:	000500a3          	sb	zero,1(a0)
    230a:	4689                	li	a3,2
    230c:	00250713          	addi	a4,a0,2
    2310:	18d78e63          	beq	a5,a3,24ac <stpncpy+0x20a>
    2314:	00050123          	sb	zero,2(a0)
    2318:	468d                	li	a3,3
    231a:	00350713          	addi	a4,a0,3
    231e:	16d78c63          	beq	a5,a3,2496 <stpncpy+0x1f4>
    2322:	000501a3          	sb	zero,3(a0)
    2326:	4691                	li	a3,4
    2328:	00450713          	addi	a4,a0,4
    232c:	18d78263          	beq	a5,a3,24b0 <stpncpy+0x20e>
    2330:	00050223          	sb	zero,4(a0)
    2334:	4695                	li	a3,5
    2336:	00550713          	addi	a4,a0,5
    233a:	16d78d63          	beq	a5,a3,24b4 <stpncpy+0x212>
    233e:	000502a3          	sb	zero,5(a0)
    2342:	469d                	li	a3,7
    2344:	00650713          	addi	a4,a0,6
    2348:	16d79863          	bne	a5,a3,24b8 <stpncpy+0x216>
    234c:	00750713          	addi	a4,a0,7
    2350:	00050323          	sb	zero,6(a0)
    2354:	40f80833          	sub	a6,a6,a5
    2358:	ff887593          	andi	a1,a6,-8
    235c:	97aa                	add	a5,a5,a0
    235e:	95be                	add	a1,a1,a5
    2360:	0007b023          	sd	zero,0(a5)
    2364:	07a1                	addi	a5,a5,8
    2366:	feb79de3          	bne	a5,a1,2360 <stpncpy+0xbe>
    236a:	ff887593          	andi	a1,a6,-8
    236e:	9ead                	addw	a3,a3,a1
    2370:	00b707b3          	add	a5,a4,a1
    2374:	12b80863          	beq	a6,a1,24a4 <stpncpy+0x202>
    2378:	00078023          	sb	zero,0(a5)
    237c:	0016871b          	addiw	a4,a3,1
    2380:	0ec77863          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    2384:	000780a3          	sb	zero,1(a5)
    2388:	0026871b          	addiw	a4,a3,2
    238c:	0ec77263          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    2390:	00078123          	sb	zero,2(a5)
    2394:	0036871b          	addiw	a4,a3,3
    2398:	0cc77c63          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    239c:	000781a3          	sb	zero,3(a5)
    23a0:	0046871b          	addiw	a4,a3,4
    23a4:	0cc77663          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23a8:	00078223          	sb	zero,4(a5)
    23ac:	0056871b          	addiw	a4,a3,5
    23b0:	0cc77063          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23b4:	000782a3          	sb	zero,5(a5)
    23b8:	0066871b          	addiw	a4,a3,6
    23bc:	0ac77a63          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23c0:	00078323          	sb	zero,6(a5)
    23c4:	0076871b          	addiw	a4,a3,7
    23c8:	0ac77463          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23cc:	000783a3          	sb	zero,7(a5)
    23d0:	0086871b          	addiw	a4,a3,8
    23d4:	08c77e63          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23d8:	00078423          	sb	zero,8(a5)
    23dc:	0096871b          	addiw	a4,a3,9
    23e0:	08c77863          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23e4:	000784a3          	sb	zero,9(a5)
    23e8:	00a6871b          	addiw	a4,a3,10
    23ec:	08c77263          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23f0:	00078523          	sb	zero,10(a5)
    23f4:	00b6871b          	addiw	a4,a3,11
    23f8:	06c77c63          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    23fc:	000785a3          	sb	zero,11(a5)
    2400:	00c6871b          	addiw	a4,a3,12
    2404:	06c77663          	bgeu	a4,a2,2470 <stpncpy+0x1ce>
    2408:	00078623          	sb	zero,12(a5)
    240c:	26b5                	addiw	a3,a3,13
    240e:	06c6f163          	bgeu	a3,a2,2470 <stpncpy+0x1ce>
    2412:	000786a3          	sb	zero,13(a5)
    2416:	8082                	ret
			;
		if (!n || !*s)
    2418:	c645                	beqz	a2,24c0 <stpncpy+0x21e>
    241a:	0005c783          	lbu	a5,0(a1)
    241e:	ea078be3          	beqz	a5,22d4 <stpncpy+0x32>
			goto tail;
		wd = (void *)d;
		ws = (const void *)s;
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2422:	479d                	li	a5,7
    2424:	02c7ff63          	bgeu	a5,a2,2462 <stpncpy+0x1c0>
    2428:	00000897          	auipc	a7,0x0
    242c:	6c88b883          	ld	a7,1736(a7) # 2af0 <enable_deadlock_detect+0x236>
    2430:	00000817          	auipc	a6,0x0
    2434:	6c883803          	ld	a6,1736(a6) # 2af8 <enable_deadlock_detect+0x23e>
    2438:	431d                	li	t1,7
    243a:	6198                	ld	a4,0(a1)
    243c:	011707b3          	add	a5,a4,a7
    2440:	fff74693          	not	a3,a4
    2444:	8ff5                	and	a5,a5,a3
    2446:	0107f7b3          	and	a5,a5,a6
    244a:	ef81                	bnez	a5,2462 <stpncpy+0x1c0>
		     n -= sizeof(size_t), ws++, wd++)
			*wd = *ws;
    244c:	e118                	sd	a4,0(a0)
		     n -= sizeof(size_t), ws++, wd++)
    244e:	1661                	addi	a2,a2,-8
    2450:	05a1                	addi	a1,a1,8
    2452:	0521                	addi	a0,a0,8
		for (; n >= sizeof(size_t) && !HASZERO(*ws);
    2454:	fec363e3          	bltu	t1,a2,243a <stpncpy+0x198>
		d = (void *)wd;
		s = (const void *)ws;
	}
	for (; n && (*d = *s); n--, s++, d++)
    2458:	e609                	bnez	a2,2462 <stpncpy+0x1c0>
    245a:	a08d                	j	24bc <stpncpy+0x21a>
    245c:	167d                	addi	a2,a2,-1
    245e:	0505                	addi	a0,a0,1
    2460:	ca01                	beqz	a2,2470 <stpncpy+0x1ce>
    2462:	0005c783          	lbu	a5,0(a1)
    2466:	0585                	addi	a1,a1,1
    2468:	00f50023          	sb	a5,0(a0)
    246c:	fbe5                	bnez	a5,245c <stpncpy+0x1ba>
		;
tail:
    246e:	b59d                	j	22d4 <stpncpy+0x32>
	memset(d, 0, n);
	return d;
}
    2470:	8082                	ret
    2472:	472d                	li	a4,11
    2474:	bdb5                	j	22f0 <stpncpy+0x4e>
    2476:	00778713          	addi	a4,a5,7
    247a:	45ad                	li	a1,11
    247c:	fff60693          	addi	a3,a2,-1
    2480:	e6b778e3          	bgeu	a4,a1,22f0 <stpncpy+0x4e>
    2484:	b7fd                	j	2472 <stpncpy+0x1d0>
    2486:	40a007b3          	neg	a5,a0
    248a:	8832                	mv	a6,a2
    248c:	8b9d                	andi	a5,a5,7
    248e:	4681                	li	a3,0
    2490:	e4060be3          	beqz	a2,22e6 <stpncpy+0x44>
    2494:	b7cd                	j	2476 <stpncpy+0x1d4>
	for (int i = 0; i < n; ++i, *(p++) = c)
    2496:	468d                	li	a3,3
    2498:	bd75                	j	2354 <stpncpy+0xb2>
    249a:	872a                	mv	a4,a0
    249c:	4681                	li	a3,0
    249e:	bd5d                	j	2354 <stpncpy+0xb2>
    24a0:	4685                	li	a3,1
    24a2:	bd4d                	j	2354 <stpncpy+0xb2>
    24a4:	8082                	ret
    24a6:	87aa                	mv	a5,a0
    24a8:	4681                	li	a3,0
    24aa:	b5f9                	j	2378 <stpncpy+0xd6>
    24ac:	4689                	li	a3,2
    24ae:	b55d                	j	2354 <stpncpy+0xb2>
    24b0:	4691                	li	a3,4
    24b2:	b54d                	j	2354 <stpncpy+0xb2>
    24b4:	4695                	li	a3,5
    24b6:	bd79                	j	2354 <stpncpy+0xb2>
    24b8:	4699                	li	a3,6
    24ba:	bd69                	j	2354 <stpncpy+0xb2>
    24bc:	8082                	ret
    24be:	8082                	ret
    24c0:	8082                	ret

00000000000024c2 <basename>:

char *basename(char *s)
{
    24c2:	86aa                	mv	a3,a0
	size_t i;
	if (!s || !*s)
    24c4:	c54d                	beqz	a0,256e <basename+0xac>
    24c6:	00054783          	lbu	a5,0(a0)
		return ".";
    24ca:	00000517          	auipc	a0,0x0
    24ce:	61e50513          	addi	a0,a0,1566 # 2ae8 <enable_deadlock_detect+0x22e>
	if (!s || !*s)
    24d2:	e391                	bnez	a5,24d6 <basename+0x14>
	for (; i && s[i] == '/'; i--)
		s[i] = 0;
	for (; i && s[i - 1] != '/'; i--)
		;
	return s + i;
    24d4:	8082                	ret
	for (; (uintptr_t)s % SS; s++)
    24d6:	0076f713          	andi	a4,a3,7
    24da:	87b6                	mv	a5,a3
    24dc:	cf51                	beqz	a4,2578 <basename+0xb6>
    24de:	0785                	addi	a5,a5,1
    24e0:	0077f713          	andi	a4,a5,7
    24e4:	c729                	beqz	a4,252e <basename+0x6c>
		if (!*s)
    24e6:	0007c703          	lbu	a4,0(a5)
    24ea:	fb75                	bnez	a4,24de <basename+0x1c>
	return s - a;
    24ec:	8f95                	sub	a5,a5,a3
	i = strlen(s) - 1;
    24ee:	17fd                	addi	a5,a5,-1
	for (; i && s[i] == '/'; i--)
    24f0:	cf8d                	beqz	a5,252a <basename+0x68>
    24f2:	00f68733          	add	a4,a3,a5
    24f6:	02f00593          	li	a1,47
    24fa:	a031                	j	2506 <basename+0x44>
		s[i] = 0;
    24fc:	00070023          	sb	zero,0(a4)
	for (; i && s[i] == '/'; i--)
    2500:	17fd                	addi	a5,a5,-1
    2502:	177d                	addi	a4,a4,-1
    2504:	c39d                	beqz	a5,252a <basename+0x68>
    2506:	00074603          	lbu	a2,0(a4)
    250a:	feb609e3          	beq	a2,a1,24fc <basename+0x3a>
	for (; i && s[i - 1] != '/'; i--)
    250e:	02f00613          	li	a2,47
    2512:	a011                	j	2516 <basename+0x54>
    2514:	cb99                	beqz	a5,252a <basename+0x68>
    2516:	853e                	mv	a0,a5
    2518:	17fd                	addi	a5,a5,-1
    251a:	00f68733          	add	a4,a3,a5
    251e:	00074703          	lbu	a4,0(a4)
    2522:	fec719e3          	bne	a4,a2,2514 <basename+0x52>
	return s + i;
    2526:	9536                	add	a0,a0,a3
    2528:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    252a:	8536                	mv	a0,a3
    252c:	8082                	ret
    252e:	6390                	ld	a2,0(a5)
    2530:	00000517          	auipc	a0,0x0
    2534:	5c053503          	ld	a0,1472(a0) # 2af0 <enable_deadlock_detect+0x236>
    2538:	00000597          	auipc	a1,0x0
    253c:	5c05b583          	ld	a1,1472(a1) # 2af8 <enable_deadlock_detect+0x23e>
    2540:	fff64713          	not	a4,a2
    2544:	962a                	add	a2,a2,a0
    2546:	8f71                	and	a4,a4,a2
    2548:	8f6d                	and	a4,a4,a1
    254a:	eb11                	bnez	a4,255e <basename+0x9c>
    254c:	6790                	ld	a2,8(a5)
    254e:	07a1                	addi	a5,a5,8
    2550:	00a60733          	add	a4,a2,a0
    2554:	fff64613          	not	a2,a2
    2558:	8f71                	and	a4,a4,a2
    255a:	8f6d                	and	a4,a4,a1
    255c:	db65                	beqz	a4,254c <basename+0x8a>
	for (; *s; s++)
    255e:	0007c703          	lbu	a4,0(a5)
    2562:	d749                	beqz	a4,24ec <basename+0x2a>
    2564:	0017c703          	lbu	a4,1(a5)
    2568:	0785                	addi	a5,a5,1
    256a:	ff6d                	bnez	a4,2564 <basename+0xa2>
    256c:	b741                	j	24ec <basename+0x2a>
		return ".";
    256e:	00000517          	auipc	a0,0x0
    2572:	57a50513          	addi	a0,a0,1402 # 2ae8 <enable_deadlock_detect+0x22e>
    2576:	8082                	ret
	for (w = (const void *)s; !HASZERO(*w); w++)
    2578:	6290                	ld	a2,0(a3)
    257a:	00000517          	auipc	a0,0x0
    257e:	57653503          	ld	a0,1398(a0) # 2af0 <enable_deadlock_detect+0x236>
    2582:	00000597          	auipc	a1,0x0
    2586:	5765b583          	ld	a1,1398(a1) # 2af8 <enable_deadlock_detect+0x23e>
    258a:	fff64713          	not	a4,a2
    258e:	962a                	add	a2,a2,a0
    2590:	8f71                	and	a4,a4,a2
    2592:	8f6d                	and	a4,a4,a1
    2594:	df45                	beqz	a4,254c <basename+0x8a>
    2596:	b7f9                	j	2564 <basename+0xa2>

0000000000002598 <open>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
}

static inline long __syscall3(long n, long a, long b, long c)
{
	register long a7 __asm__("a7") = n;
    2598:	03800893          	li	a7,56
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
    259c:	4609                	li	a2,2
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    259e:	00000073          	ecall
void __clear_buffer();

int open(const char *path, int flags)
{
	return syscall(SYS_openat, path, flags, O_RDWR);
}
    25a2:	2501                	sext.w	a0,a0
    25a4:	8082                	ret

00000000000025a6 <close>:

int close(int fd)
{
	if (fd == 1) {
    25a6:	4785                	li	a5,1
    25a8:	00f50863          	beq	a0,a5,25b8 <close+0x12>
	register long a7 __asm__("a7") = n;
    25ac:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25b0:	00000073          	ecall
		__write_buffer();
		__clear_buffer();
	}
	return syscall(SYS_close, fd);
}
    25b4:	2501                	sext.w	a0,a0
    25b6:	8082                	ret
{
    25b8:	1101                	addi	sp,sp,-32
    25ba:	ec06                	sd	ra,24(sp)
    25bc:	e42a                	sd	a0,8(sp)
		__write_buffer();
    25be:	cdffe0ef          	jal	ra,129c <__write_buffer>
		__clear_buffer();
    25c2:	d03fe0ef          	jal	ra,12c4 <__clear_buffer>
    25c6:	6522                	ld	a0,8(sp)
	register long a7 __asm__("a7") = n;
    25c8:	03900893          	li	a7,57
	__asm_syscall("r"(a7), "0"(a0))
    25cc:	00000073          	ecall
}
    25d0:	60e2                	ld	ra,24(sp)
    25d2:	2501                	sext.w	a0,a0
    25d4:	6105                	addi	sp,sp,32
    25d6:	8082                	ret

00000000000025d8 <read>:
	register long a7 __asm__("a7") = n;
    25d8:	03f00893          	li	a7,63
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25dc:	00000073          	ecall

ssize_t read(int fd, void *buf, size_t len)
{
	return syscall(SYS_read, fd, buf, len);
}
    25e0:	8082                	ret

00000000000025e2 <write>:
	register long a7 __asm__("a7") = n;
    25e2:	04000893          	li	a7,64
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    25e6:	00000073          	ecall

ssize_t write(int fd, const void *buf, size_t len)
{
	return syscall(SYS_write, fd, buf, len);
}
    25ea:	8082                	ret

00000000000025ec <getpid>:
	register long a7 __asm__("a7") = n;
    25ec:	0ac00893          	li	a7,172
	__asm_syscall("r"(a7))
    25f0:	00000073          	ecall

int getpid()
{
	return syscall(SYS_getpid);
}
    25f4:	2501                	sext.w	a0,a0
    25f6:	8082                	ret

00000000000025f8 <getppid>:
	register long a7 __asm__("a7") = n;
    25f8:	0ad00893          	li	a7,173
	__asm_syscall("r"(a7))
    25fc:	00000073          	ecall

int getppid()
{
	return syscall(SYS_getppid);
}
    2600:	2501                	sext.w	a0,a0
    2602:	8082                	ret

0000000000002604 <sched_yield>:
	register long a7 __asm__("a7") = n;
    2604:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2608:	00000073          	ecall

int sched_yield()
{
	return syscall(SYS_sched_yield);
}
    260c:	2501                	sext.w	a0,a0
    260e:	8082                	ret

0000000000002610 <fork>:
	register long a7 __asm__("a7") = n;
    2610:	0dc00893          	li	a7,220
	__asm_syscall("r"(a7))
    2614:	00000073          	ecall

int fork()
{
	return syscall(SYS_clone);
}
    2618:	2501                	sext.w	a0,a0
    261a:	8082                	ret

000000000000261c <exit>:

void exit(int code)
{
    261c:	1141                	addi	sp,sp,-16
    261e:	e406                	sd	ra,8(sp)
    2620:	e022                	sd	s0,0(sp)
    2622:	842a                	mv	s0,a0
	__write_buffer();
    2624:	c79fe0ef          	jal	ra,129c <__write_buffer>
	__clear_buffer();
    2628:	c9dfe0ef          	jal	ra,12c4 <__clear_buffer>
	register long a7 __asm__("a7") = n;
    262c:	05d00893          	li	a7,93
	register long a0 __asm__("a0") = a;
    2630:	8522                	mv	a0,s0
	__asm_syscall("r"(a7), "0"(a0))
    2632:	00000073          	ecall
	syscall(SYS_exit, code);
}
    2636:	60a2                	ld	ra,8(sp)
    2638:	6402                	ld	s0,0(sp)
    263a:	0141                	addi	sp,sp,16
    263c:	8082                	ret

000000000000263e <waitpid>:
	register long a7 __asm__("a7") = n;
    263e:	10400893          	li	a7,260
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2642:	00000073          	ecall

int waitpid(int pid, int *code)
{
	return syscall(SYS_wait4, pid, code);
}
    2646:	2501                	sext.w	a0,a0
    2648:	8082                	ret

000000000000264a <exec>:
	register long a7 __asm__("a7") = n;
    264a:	0dd00893          	li	a7,221
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    264e:	00000073          	ecall

static char **null = { 0 };
int exec(const char *name, char **argv)
{
	return syscall(SYS_execve, name, argv == 0 ? null : argv);
}
    2652:	2501                	sext.w	a0,a0
    2654:	8082                	ret

0000000000002656 <get_mtime>:

int64 get_mtime()
{
    2656:	1141                	addi	sp,sp,-16
	register long a7 __asm__("a7") = n;
    2658:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    265c:	850a                	mv	a0,sp
	register long a1 __asm__("a1") = b;
    265e:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2660:	00000073          	ecall
	TimeVal time;
	int err = sys_get_time(&time, 0);
	if (err == 0) {
    2664:	2501                	sext.w	a0,a0
    2666:	ed01                	bnez	a0,267e <get_mtime+0x28>
		return (time.sec * 1000 + time.usec / 1000);
    2668:	6722                	ld	a4,8(sp)
    266a:	3e800793          	li	a5,1000
    266e:	6682                	ld	a3,0(sp)
    2670:	02f75733          	divu	a4,a4,a5
    2674:	02d78533          	mul	a0,a5,a3
    2678:	953a                	add	a0,a0,a4
	}
	// get_time should never failed.
	return -1;
}
    267a:	0141                	addi	sp,sp,16
    267c:	8082                	ret
	return -1;
    267e:	557d                	li	a0,-1
    2680:	bfed                	j	267a <get_mtime+0x24>

0000000000002682 <sys_get_time>:
	register long a7 __asm__("a7") = n;
    2682:	0a900893          	li	a7,169
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2686:	00000073          	ecall

int sys_get_time(TimeVal *ts, int tz)
{
	return syscall(SYS_gettimeofday, ts, tz);
}
    268a:	2501                	sext.w	a0,a0
    268c:	8082                	ret

000000000000268e <sleep>:

int sleep(unsigned long long time)
{
    268e:	1141                	addi	sp,sp,-16
	return syscall(SYS_gettimeofday, ts, tz);
    2690:	880a                	mv	a6,sp
{
    2692:	862a                	mv	a2,a0
	register long a7 __asm__("a7") = n;
    2694:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    2698:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    269a:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    269c:	00000073          	ecall
	if (err == 0) {
    26a0:	2501                	sext.w	a0,a0
    26a2:	ed31                	bnez	a0,26fe <sleep+0x70>
		return (time.sec * 1000 + time.usec / 1000);
    26a4:	6722                	ld	a4,8(sp)
    26a6:	3e800793          	li	a5,1000
    26aa:	6682                	ld	a3,0(sp)
    26ac:	02f75733          	divu	a4,a4,a5
    26b0:	02d787b3          	mul	a5,a5,a3
    26b4:	97ba                	add	a5,a5,a4
	register long a7 __asm__("a7") = n;
    26b6:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26ba:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26bc:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26be:	00000073          	ecall
	if (err == 0) {
    26c2:	2501                	sext.w	a0,a0
    26c4:	e915                	bnez	a0,26f8 <sleep+0x6a>
	unsigned long long s = get_mtime();
	while (get_mtime() < s + time) {
    26c6:	963e                	add	a2,a2,a5
		return (time.sec * 1000 + time.usec / 1000);
    26c8:	3e800693          	li	a3,1000
    26cc:	a819                	j	26e2 <sleep+0x54>
	__asm_syscall("r"(a7))
    26ce:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    26d2:	0a900893          	li	a7,169
	register long a0 __asm__("a0") = a;
    26d6:	8542                	mv	a0,a6
	register long a1 __asm__("a1") = b;
    26d8:	4581                	li	a1,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    26da:	00000073          	ecall
	if (err == 0) {
    26de:	2501                	sext.w	a0,a0
    26e0:	ed01                	bnez	a0,26f8 <sleep+0x6a>
		return (time.sec * 1000 + time.usec / 1000);
    26e2:	6722                	ld	a4,8(sp)
    26e4:	6782                	ld	a5,0(sp)
	register long a7 __asm__("a7") = n;
    26e6:	07c00893          	li	a7,124
    26ea:	02d75733          	divu	a4,a4,a3
    26ee:	02f687b3          	mul	a5,a3,a5
    26f2:	97ba                	add	a5,a5,a4
	while (get_mtime() < s + time) {
    26f4:	fcc7ede3          	bltu	a5,a2,26ce <sleep+0x40>
		sched_yield();
	}
	return 0;
}
    26f8:	4501                	li	a0,0
    26fa:	0141                	addi	sp,sp,16
    26fc:	8082                	ret
    26fe:	57fd                	li	a5,-1
    2700:	bf5d                	j	26b6 <sleep+0x28>

0000000000002702 <sys_task_info>:
	register long a7 __asm__("a7") = n;
    2702:	19a00893          	li	a7,410
	__asm_syscall("r"(a7), "0"(a0))
    2706:	00000073          	ecall

int sys_task_info(TaskInfo *ti)
{
	return syscall(SYS_task_info, ti);
}
    270a:	2501                	sext.w	a0,a0
    270c:	8082                	ret

000000000000270e <set_priority>:
	register long a7 __asm__("a7") = n;
    270e:	08c00893          	li	a7,140
	__asm_syscall("r"(a7), "0"(a0))
    2712:	00000073          	ecall

int set_priority(int prio)
{
	return syscall(SYS_setpriority, prio);
}
    2716:	2501                	sext.w	a0,a0
    2718:	8082                	ret

000000000000271a <mmap>:
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3))
}

static inline long __syscall5(long n, long a, long b, long c, long d, long e)
{
	register long a7 __asm__("a7") = n;
    271a:	0de00893          	li	a7,222
	register long a0 __asm__("a0") = a;
	register long a1 __asm__("a1") = b;
	register long a2 __asm__("a2") = c;
	register long a3 __asm__("a3") = d;
	register long a4 __asm__("a4") = e;
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    271e:	00000073          	ecall

int mmap(void *start, unsigned long long len, int prot, int flag, int sd)
{
	return syscall(SYS_mmap, start, len, prot, flag, sd);
}
    2722:	2501                	sext.w	a0,a0
    2724:	8082                	ret

0000000000002726 <munmap>:
	register long a7 __asm__("a7") = n;
    2726:	0d700893          	li	a7,215
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    272a:	00000073          	ecall

int munmap(void *start, unsigned long long len)
{
	return syscall(SYS_munmap, start, len);
}
    272e:	2501                	sext.w	a0,a0
    2730:	8082                	ret

0000000000002732 <wait>:

int wait(int *code)
{
    2732:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    2734:	10400893          	li	a7,260
	register long a0 __asm__("a0") = a;
    2738:	557d                	li	a0,-1
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    273a:	00000073          	ecall
	return waitpid(-1, code);
}
    273e:	2501                	sext.w	a0,a0
    2740:	8082                	ret

0000000000002742 <spawn>:
	register long a7 __asm__("a7") = n;
    2742:	19000893          	li	a7,400
	__asm_syscall("r"(a7), "0"(a0))
    2746:	00000073          	ecall

int spawn(const char *file)
{
	return syscall(SYS_spawn, file);
}
    274a:	2501                	sext.w	a0,a0
    274c:	8082                	ret

000000000000274e <pipe>:
	register long a7 __asm__("a7") = n;
    274e:	03b00893          	li	a7,59
	__asm_syscall("r"(a7), "0"(a0))
    2752:	00000073          	ecall

int pipe(void *p)
{
	return syscall(SYS_pipe2, p);
}
    2756:	2501                	sext.w	a0,a0
    2758:	8082                	ret

000000000000275a <mailread>:
	register long a7 __asm__("a7") = n;
    275a:	19100893          	li	a7,401
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    275e:	00000073          	ecall

int mailread(void *buf, int len)
{
	return syscall(SYS_mailread, buf, len);
}
    2762:	2501                	sext.w	a0,a0
    2764:	8082                	ret

0000000000002766 <mailwrite>:
	register long a7 __asm__("a7") = n;
    2766:	19200893          	li	a7,402
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    276a:	00000073          	ecall

int mailwrite(int pid, void *buf, int len)
{
	return syscall(SYS_mailwrite, pid, buf, len);
}
    276e:	2501                	sext.w	a0,a0
    2770:	8082                	ret

0000000000002772 <fstat>:
	register long a7 __asm__("a7") = n;
    2772:	05000893          	li	a7,80
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    2776:	00000073          	ecall

int fstat(int fd, Stat *st)
{
	return syscall(SYS_fstat, fd, st);
}
    277a:	2501                	sext.w	a0,a0
    277c:	8082                	ret

000000000000277e <sys_linkat>:
	register long a4 __asm__("a4") = e;
    277e:	1702                	slli	a4,a4,0x20
	register long a7 __asm__("a7") = n;
    2780:	02500893          	li	a7,37
	register long a4 __asm__("a4") = e;
    2784:	9301                	srli	a4,a4,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    2786:	00000073          	ecall

int sys_linkat(int olddirfd, char *oldpath, int newdirfd, char *newpath,
	       unsigned int flags)
{
	return syscall(SYS_linkat, olddirfd, oldpath, newdirfd, newpath, flags);
}
    278a:	2501                	sext.w	a0,a0
    278c:	8082                	ret

000000000000278e <sys_unlinkat>:
	register long a2 __asm__("a2") = c;
    278e:	1602                	slli	a2,a2,0x20
	register long a7 __asm__("a7") = n;
    2790:	02300893          	li	a7,35
	register long a2 __asm__("a2") = c;
    2794:	9201                	srli	a2,a2,0x20
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    2796:	00000073          	ecall

int sys_unlinkat(int dirfd, char *path, unsigned int flags)
{
	return syscall(SYS_unlinkat, dirfd, path, flags);
}
    279a:	2501                	sext.w	a0,a0
    279c:	8082                	ret

000000000000279e <link>:

int link(char *old_path, char *new_path)
{
    279e:	87aa                	mv	a5,a0
    27a0:	86ae                	mv	a3,a1
	register long a7 __asm__("a7") = n;
    27a2:	02500893          	li	a7,37
	register long a0 __asm__("a0") = a;
    27a6:	f9c00513          	li	a0,-100
	register long a1 __asm__("a1") = b;
    27aa:	85be                	mv	a1,a5
	register long a2 __asm__("a2") = c;
    27ac:	f9c00613          	li	a2,-100
	register long a4 __asm__("a4") = e;
    27b0:	4701                	li	a4,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4))
    27b2:	00000073          	ecall
	return sys_linkat(AT_FDCWD, old_path, AT_FDCWD, new_path, 0);
}
    27b6:	2501                	sext.w	a0,a0
    27b8:	8082                	ret

00000000000027ba <unlink>:

int unlink(char *path)
{
    27ba:	85aa                	mv	a1,a0
	register long a7 __asm__("a7") = n;
    27bc:	02300893          	li	a7,35
	register long a0 __asm__("a0") = a;
    27c0:	f9c00513          	li	a0,-100
	register long a2 __asm__("a2") = c;
    27c4:	4601                	li	a2,0
	__asm_syscall("r"(a7), "0"(a0), "r"(a1), "r"(a2))
    27c6:	00000073          	ecall
	return sys_unlinkat(AT_FDCWD, path, 0);
}
    27ca:	2501                	sext.w	a0,a0
    27cc:	8082                	ret

00000000000027ce <thread_create>:

int thread_create(void *entry, void *arg)
{
	// on first thread create enable, here must be single thread
	if (!buffer_lock_enabled) {
    27ce:	00000797          	auipc	a5,0x0
    27d2:	5aa7b783          	ld	a5,1450(a5) # 2d78 <_GLOBAL_OFFSET_TABLE_+0x8>
    27d6:	439c                	lw	a5,0(a5)
    27d8:	c799                	beqz	a5,27e6 <thread_create+0x18>
	register long a7 __asm__("a7") = n;
    27da:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27de:	00000073          	ecall
		enable_thread_io_buffer();
	}
	return syscall(SYS_thread_create, (uint64)entry, (uint64)arg);
}
    27e2:	2501                	sext.w	a0,a0
    27e4:	8082                	ret
{
    27e6:	1101                	addi	sp,sp,-32
    27e8:	ec06                	sd	ra,24(sp)
    27ea:	e42e                	sd	a1,8(sp)
    27ec:	e02a                	sd	a0,0(sp)
		enable_thread_io_buffer();
    27ee:	fe7fe0ef          	jal	ra,17d4 <enable_thread_io_buffer>
    27f2:	65a2                	ld	a1,8(sp)
    27f4:	6502                	ld	a0,0(sp)
	register long a7 __asm__("a7") = n;
    27f6:	1cc00893          	li	a7,460
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    27fa:	00000073          	ecall
}
    27fe:	60e2                	ld	ra,24(sp)
    2800:	2501                	sext.w	a0,a0
    2802:	6105                	addi	sp,sp,32
    2804:	8082                	ret

0000000000002806 <gettid>:
	register long a7 __asm__("a7") = n;
    2806:	0b200893          	li	a7,178
	__asm_syscall("r"(a7))
    280a:	00000073          	ecall

int gettid(void)
{
	return syscall(SYS_gettid);
}
    280e:	2501                	sext.w	a0,a0
    2810:	8082                	ret

0000000000002812 <waittid>:

int waittid(int tid)
{
    2812:	87aa                	mv	a5,a0
	register long a7 __asm__("a7") = n;
    2814:	1ce00893          	li	a7,462
	__asm_syscall("r"(a7), "0"(a0))
    2818:	00000073          	ecall
	int ret = syscall(SYS_waittid, tid);
	while (ret == -2) {
    281c:	5779                	li	a4,-2
	int ret = syscall(SYS_waittid, tid);
    281e:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2820:	00e51e63          	bne	a0,a4,283c <waittid+0x2a>
	register long a7 __asm__("a7") = n;
    2824:	07c00893          	li	a7,124
	__asm_syscall("r"(a7))
    2828:	00000073          	ecall
	register long a7 __asm__("a7") = n;
    282c:	1ce00893          	li	a7,462
	register long a0 __asm__("a0") = a;
    2830:	853e                	mv	a0,a5
	__asm_syscall("r"(a7), "0"(a0))
    2832:	00000073          	ecall
		sched_yield();
		ret = syscall(SYS_waittid, tid);
    2836:	2501                	sext.w	a0,a0
	while (ret == -2) {
    2838:	fee506e3          	beq	a0,a4,2824 <waittid+0x12>
	}
	return ret;
}
    283c:	8082                	ret

000000000000283e <mutex_create>:
	register long a7 __asm__("a7") = n;
    283e:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2842:	4501                	li	a0,0
	__asm_syscall("r"(a7), "0"(a0))
    2844:	00000073          	ecall

int mutex_create()
{
	return syscall(SYS_mutex_create, 0);
}
    2848:	2501                	sext.w	a0,a0
    284a:	8082                	ret

000000000000284c <mutex_blocking_create>:
	register long a7 __asm__("a7") = n;
    284c:	1cf00893          	li	a7,463
	register long a0 __asm__("a0") = a;
    2850:	4505                	li	a0,1
	__asm_syscall("r"(a7), "0"(a0))
    2852:	00000073          	ecall

int mutex_blocking_create()
{
	return syscall(SYS_mutex_create, 1);
}
    2856:	2501                	sext.w	a0,a0
    2858:	8082                	ret

000000000000285a <mutex_lock>:
	register long a7 __asm__("a7") = n;
    285a:	1d000893          	li	a7,464
	__asm_syscall("r"(a7), "0"(a0))
    285e:	00000073          	ecall

int mutex_lock(int mid)
{
	return syscall(SYS_mutex_lock, mid);
}
    2862:	2501                	sext.w	a0,a0
    2864:	8082                	ret

0000000000002866 <mutex_unlock>:
	register long a7 __asm__("a7") = n;
    2866:	1d200893          	li	a7,466
	__asm_syscall("r"(a7), "0"(a0))
    286a:	00000073          	ecall

int mutex_unlock(int mid)
{
	return syscall(SYS_mutex_unlock, mid);
}
    286e:	2501                	sext.w	a0,a0
    2870:	8082                	ret

0000000000002872 <semaphore_create>:
	register long a7 __asm__("a7") = n;
    2872:	1d300893          	li	a7,467
	__asm_syscall("r"(a7), "0"(a0))
    2876:	00000073          	ecall

int semaphore_create(int res_count)
{
	return syscall(SYS_semaphore_create, res_count);
}
    287a:	2501                	sext.w	a0,a0
    287c:	8082                	ret

000000000000287e <semaphore_up>:
	register long a7 __asm__("a7") = n;
    287e:	1d400893          	li	a7,468
	__asm_syscall("r"(a7), "0"(a0))
    2882:	00000073          	ecall

int semaphore_up(int sid)
{
	return syscall(SYS_semaphore_up, sid);
}
    2886:	2501                	sext.w	a0,a0
    2888:	8082                	ret

000000000000288a <semaphore_down>:
	register long a7 __asm__("a7") = n;
    288a:	1d600893          	li	a7,470
	__asm_syscall("r"(a7), "0"(a0))
    288e:	00000073          	ecall

int semaphore_down(int sid)
{
	return syscall(SYS_semaphore_down, sid);
}
    2892:	2501                	sext.w	a0,a0
    2894:	8082                	ret

0000000000002896 <condvar_create>:
	register long a7 __asm__("a7") = n;
    2896:	1d700893          	li	a7,471
	__asm_syscall("r"(a7))
    289a:	00000073          	ecall

int condvar_create()
{
	return syscall(SYS_condvar_create);
}
    289e:	2501                	sext.w	a0,a0
    28a0:	8082                	ret

00000000000028a2 <condvar_signal>:
	register long a7 __asm__("a7") = n;
    28a2:	1d800893          	li	a7,472
	__asm_syscall("r"(a7), "0"(a0))
    28a6:	00000073          	ecall

int condvar_signal(int cid)
{
	return syscall(SYS_condvar_signal, cid);
}
    28aa:	2501                	sext.w	a0,a0
    28ac:	8082                	ret

00000000000028ae <condvar_wait>:
	register long a7 __asm__("a7") = n;
    28ae:	1d900893          	li	a7,473
	__asm_syscall("r"(a7), "0"(a0), "r"(a1))
    28b2:	00000073          	ecall

int condvar_wait(int cid, int mid)
{
	return syscall(SYS_condvar_wait, cid, mid);
}
    28b6:	2501                	sext.w	a0,a0
    28b8:	8082                	ret

00000000000028ba <enable_deadlock_detect>:
	register long a7 __asm__("a7") = n;
    28ba:	1d500893          	li	a7,469
	__asm_syscall("r"(a7), "0"(a0))
    28be:	00000073          	ecall

int enable_deadlock_detect(int enabled)
{
	return syscall(SYS_enable_deadlock_detect, enabled);
}
    28c2:	2501                	sext.w	a0,a0
    28c4:	8082                	ret
